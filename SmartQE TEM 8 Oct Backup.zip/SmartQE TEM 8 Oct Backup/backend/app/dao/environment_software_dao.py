from typing import List, Optional
from datetime import datetime, timezone
from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.environment_software import EnvironmentSoftware, SoftwareDiagnosisStatus


class EnvironmentSoftwareDAO(BaseDAO[EnvironmentSoftware]):
    def __init__(self):
        super().__init__(EnvironmentSoftware)

    async def get_by_environment_id_or_name(
        self, db: AsyncSession, env_id_or_name: str
    ) -> List[EnvironmentSoftware]:
        query = select(EnvironmentSoftware).where(
            and_(
                EnvironmentSoftware.is_active != False,
                or_(
                    EnvironmentSoftware.environment_id == env_id_or_name,
                    EnvironmentSoftware.environment_name.ilike(env_id_or_name)
                )
            )
        ).order_by(EnvironmentSoftware.software_name.asc())
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_by_env_and_software_name(
        self, db: AsyncSession, env_id: str, software_name: str
    ) -> Optional[EnvironmentSoftware]:
        query = select(EnvironmentSoftware).where(
            and_(
                EnvironmentSoftware.is_active != False,
                EnvironmentSoftware.environment_id == env_id,
                EnvironmentSoftware.software_name.ilike(software_name.strip())
            )
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def update_status_and_checked_time(
        self,
        db: AsyncSession,
        item_id: str,
        status: SoftwareDiagnosisStatus,
        check_details: Optional[str] = None
    ) -> Optional[EnvironmentSoftware]:
        item = await self.get_by_id(db, item_id)
        if item:
            item.status = status
            item.last_checked = datetime.now(timezone.utc)
            if check_details is not None:
                item.check_details = check_details
            await db.commit()
            await db.refresh(item)
        return item


environment_software_dao = EnvironmentSoftwareDAO()
