from typing import List, Optional
from sqlalchemy import select, desc, and_
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.auto_heal import (
    AutoHealRule, AutoHealExecution, AutoHealStatus, AutoHealExecutionMode
)
from app.models.health_check import HealthCheckType, CheckCriticality


class AutoHealDAO(BaseDAO[AutoHealRule]):
    def __init__(self):
        super().__init__(AutoHealRule)

    async def get_rules_by_environment(
        self, db: AsyncSession, environment_id: Optional[str] = None, enabled_only: bool = False
    ) -> List[AutoHealRule]:
        query = select(AutoHealRule).where(AutoHealRule.is_visible == True)
        if environment_id:
            query = query.where(
                (AutoHealRule.environment_id == environment_id) | (AutoHealRule.environment_id.is_(None))
            )
        if enabled_only:
            query = query.where(AutoHealRule.is_enabled == True)
        
        query = query.order_by(desc(AutoHealRule.created_at))
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_rule_by_id(
        self, db: AsyncSession, rule_id: str
    ) -> Optional[AutoHealRule]:
        query = select(AutoHealRule).where(
            AutoHealRule.id == rule_id,
            AutoHealRule.is_visible == True
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def find_matching_rule(
        self,
        db: AsyncSession,
        environment_id: str,
        check_type: Optional[HealthCheckType] = None,
        criticality: Optional[CheckCriticality] = None
    ) -> Optional[AutoHealRule]:
        """Finds the most specific enabled rule for an environment and check condition."""
        # 1. Look for environment-specific rule matching check_type
        query = select(AutoHealRule).where(
            AutoHealRule.environment_id == environment_id,
            AutoHealRule.is_enabled == True,
            AutoHealRule.is_visible == True
        )
        if check_type:
            query = query.where(
                (AutoHealRule.trigger_check_type == check_type) | (AutoHealRule.trigger_check_type.is_(None))
            )
        query = query.order_by(desc(AutoHealRule.trigger_check_type.isnot(None)))
        result = await db.execute(query)
        rule = result.scalars().first()
        if rule:
            return rule

        # 2. Look for global rule (environment_id is None)
        global_query = select(AutoHealRule).where(
            AutoHealRule.environment_id.is_(None),
            AutoHealRule.is_enabled == True,
            AutoHealRule.is_visible == True
        )
        if check_type:
            global_query = global_query.where(
                (AutoHealRule.trigger_check_type == check_type) | (AutoHealRule.trigger_check_type.is_(None))
            )
        global_result = await db.execute(global_query)
        return global_result.scalars().first()

    async def create_execution(
        self, db: AsyncSession, execution: AutoHealExecution
    ) -> AutoHealExecution:
        db.add(execution)
        await db.commit()
        await db.refresh(execution)
        return execution

    async def update_execution(
        self, db: AsyncSession, execution: AutoHealExecution
    ) -> AutoHealExecution:
        await db.commit()
        await db.refresh(execution)
        return execution

    async def get_execution_by_id(
        self, db: AsyncSession, execution_id: str
    ) -> Optional[AutoHealExecution]:
        query = select(AutoHealExecution).where(
            AutoHealExecution.id == execution_id,
            AutoHealExecution.is_visible == True
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_executions_by_environment(
        self, db: AsyncSession, environment_id: Optional[str] = None, limit: int = 20
    ) -> List[AutoHealExecution]:
        query = select(AutoHealExecution).where(AutoHealExecution.is_visible == True)
        if environment_id:
            query = query.where(AutoHealExecution.environment_id == environment_id)
        query = query.order_by(desc(AutoHealExecution.started_at)).limit(limit)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_pending_approvals(
        self, db: AsyncSession, environment_id: Optional[str] = None
    ) -> List[AutoHealExecution]:
        query = select(AutoHealExecution).where(
            AutoHealExecution.status == AutoHealStatus.PENDING_APPROVAL,
            AutoHealExecution.is_visible == True
        )
        if environment_id:
            query = query.where(AutoHealExecution.environment_id == environment_id)
        query = query.order_by(desc(AutoHealExecution.started_at))
        result = await db.execute(query)
        return list(result.scalars().all())


auto_heal_dao = AutoHealDAO()
