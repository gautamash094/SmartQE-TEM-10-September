from typing import List, Optional, Tuple
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from app.dao.base_dao import BaseDAO
from app.models.health_check import (
    HealthCheckDefinition, HealthCheckExecution, HealthCheckResult, HealthStatus
)


class HealthCheckDAO(BaseDAO[HealthCheckDefinition]):
    def __init__(self):
        super().__init__(HealthCheckDefinition)

    async def get_definitions_by_environment(
        self, db: AsyncSession, environment_id: str, enabled_only: bool = False
    ) -> List[HealthCheckDefinition]:
        query = select(HealthCheckDefinition).where(
            HealthCheckDefinition.environment_id == environment_id,
            HealthCheckDefinition.is_visible == True
        )
        if enabled_only:
            query = query.where(HealthCheckDefinition.is_enabled == True)
        
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_definition_by_id(
        self, db: AsyncSession, definition_id: str
    ) -> Optional[HealthCheckDefinition]:
        query = select(HealthCheckDefinition).where(
            HealthCheckDefinition.id == definition_id,
            HealthCheckDefinition.is_visible == True
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def create_execution(
        self, db: AsyncSession, execution: HealthCheckExecution
    ) -> HealthCheckExecution:
        db.add(execution)
        await db.commit()
        await db.refresh(execution)
        return execution

    async def update_execution(
        self, db: AsyncSession, execution: HealthCheckExecution
    ) -> HealthCheckExecution:
        await db.commit()
        await db.refresh(execution)
        return execution

    async def save_results(
        self, db: AsyncSession, results: List[HealthCheckResult]
    ) -> List[HealthCheckResult]:
        db.add_all(results)
        await db.commit()
        return results

    async def get_execution_by_id(
        self, db: AsyncSession, execution_id: str
    ) -> Optional[HealthCheckExecution]:
        query = (
            select(HealthCheckExecution)
            .options(selectinload(HealthCheckExecution.results))
            .where(HealthCheckExecution.id == execution_id)
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_latest_execution_for_env(
        self, db: AsyncSession, environment_id: str
    ) -> Optional[HealthCheckExecution]:
        query = (
            select(HealthCheckExecution)
            .options(selectinload(HealthCheckExecution.results))
            .where(
                HealthCheckExecution.environment_id == environment_id,
                HealthCheckExecution.overall_status != HealthStatus.RUNNING
            )
            .order_by(desc(HealthCheckExecution.started_at))
            .limit(1)
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_executions_history(
        self, db: AsyncSession, environment_id: str, limit: int = 20
    ) -> List[HealthCheckExecution]:
        query = (
            select(HealthCheckExecution)
            .options(selectinload(HealthCheckExecution.results))
            .where(HealthCheckExecution.environment_id == environment_id)
            .order_by(desc(HealthCheckExecution.started_at))
            .limit(limit)
        )
        result = await db.execute(query)
        return list(result.scalars().all())


health_check_dao = HealthCheckDAO()
