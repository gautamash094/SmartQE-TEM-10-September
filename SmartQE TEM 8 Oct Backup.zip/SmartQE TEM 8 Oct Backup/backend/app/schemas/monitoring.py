from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, ConfigDict
from app.models.monitoring import EventSeverity, EventState, MonitoringMetricType


class HealthCategoryScores(BaseModel):
    infrastructure: float = 100.0
    application: float = 100.0
    database: float = 100.0
    services: float = 100.0
    configuration: float = 100.0
    overall_health_score: float = 100.0
    status: str = "HEALTHY"
    status_details: str = "All systems operational"


class EnvironmentReadinessCheck(BaseModel):
    environment_available: bool = True
    servers_online: bool = True
    services_healthy: bool = True
    database_connected: bool = True
    no_version_drift: bool = True
    no_blocking_incidents: bool = True
    no_maintenance_block: bool = True
    no_booking_collision: bool = True


class EnvironmentReadinessResult(BaseModel):
    status: str = "READY_FOR_TESTING"  # READY_FOR_TESTING, PARTIALLY_READY, NOT_READY
    score: int = 100
    passed_count: int = 8
    total_count: int = 8
    checks: EnvironmentReadinessCheck
    reasons: List[str] = []


class SoftwareDriftSummary(BaseModel):
    total_software: int = 0
    matching: int = 0
    version_mismatch: int = 0
    missing: int = 0
    outdated: int = 0
    consistency_health_score: float = 100.0
    has_drift: bool = False


class ReleaseImpactSummary(BaseModel):
    has_active_workload: bool = False
    impacted_application: Optional[str] = None
    impacted_release: Optional[str] = None
    impacted_phase: Optional[str] = None
    active_bookings_count: int = 0
    affected_teams: List[str] = []
    affected_users_count: int = 0
    impact_level: str = "NONE"  # NONE, LOW, MEDIUM, HIGH, CRITICAL


class AutoHealActionSummary(BaseModel):
    is_auto_heal_available: bool = False
    rule_id: Optional[str] = None
    rule_name: Optional[str] = None
    action_type: Optional[str] = None
    action_target: Optional[str] = None
    requires_approval: bool = False
    last_execution_status: Optional[str] = None


class PredictiveInsightOut(BaseModel):
    insight_type: str  # CAPACITY_WARNING, FLAPPING_WARNING, PERFORMANCE_DEGRADATION, DRIFT_RISK
    severity: str  # INFO, WARNING, CRITICAL
    target: str
    message: str
    predicted_breach_timeline: Optional[str] = None
    confidence_score: float = 0.85
    recommended_action: str


class EnvironmentDetailedObservability(BaseModel):
    environment_id: str
    environment_name: str
    tier: str
    owner: str
    team: str
    current_status: str
    uptime: float = 99.9
    
    # Live Health & Tier Breakdown
    health: HealthCategoryScores
    readiness: EnvironmentReadinessResult
    
    # Telemetry Instantaneous Values
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    storage_usage: float = 0.0
    network_latency_ms: float = 25.0
    api_p95_ms: float = 120.0
    error_rate_pct: float = 0.0
    
    # Configuration & Software Drift Summary
    drift_summary: SoftwareDriftSummary
    
    # Business & Release Context
    impact_summary: ReleaseImpactSummary
    
    # Autonomous Healing Integration
    auto_heal: AutoHealActionSummary
    
    # Predictive Analytics
    predictive_insights: List[PredictiveInsightOut] = []
    
    # Active Alerts Count
    active_critical_alerts: int = 0
    active_warning_alerts: int = 0
    last_health_check_time: Optional[datetime] = None


class FleetObservabilityKPIs(BaseModel):
    total_monitored_environments: int = 0
    healthy_environments: int = 0
    degraded_environments: int = 0
    unhealthy_environments: int = 0
    unavailable_environments: int = 0
    maintenance_environments: int = 0
    ready_for_testing_environments: int = 0
    readiness_rate_pct: float = 100.0
    environments_with_drift: int = 0
    environments_with_active_releases: int = 0
    fleet_average_health_score: float = 100.0
    fleet_availability_pct: float = 99.9
    mean_time_to_recovery_minutes: float = 18.5
    auto_heal_success_rate_pct: float = 92.0
    active_critical_events: int = 0
    active_warning_events: int = 0


class FleetObservabilitySummary(BaseModel):
    kpis: FleetObservabilityKPIs
    environments: List[EnvironmentDetailedObservability]
    recent_events: List[Any] = []
    predictive_alerts: List[PredictiveInsightOut] = []


class MetricDataPoint(BaseModel):
    timestamp: str
    value: float


class MetricSeriesOut(BaseModel):
    metric_name: str
    unit: str
    points: List[MetricDataPoint]
    current: float
    avg: float
    peak: float
    min: float


class HistoricalTelemetryOut(BaseModel):
    environment_id: str
    environment_name: str
    timeframe: str
    cpu: MetricSeriesOut
    memory: MetricSeriesOut
    disk: MetricSeriesOut
    network_latency: MetricSeriesOut
    response_time: MetricSeriesOut
    error_rate: MetricSeriesOut
    health_score_trend: MetricSeriesOut


class ThresholdRuleCreate(BaseModel):
    name: str
    environment_id: Optional[str] = None
    metric_type: MonitoringMetricType
    operator: str = ">"
    warning_threshold: float
    critical_threshold: float
    duration_minutes: int = 5
    is_enabled: bool = True
    auto_heal_enabled: bool = False
    auto_heal_runbook_id: Optional[str] = None


class ThresholdRuleOut(BaseModel):
    id: str
    name: str
    environment_id: Optional[str] = None
    metric_type: str
    operator: str
    warning_threshold: float
    critical_threshold: float
    duration_minutes: int
    is_enabled: bool
    auto_heal_enabled: bool
    auto_heal_runbook_id: Optional[str] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class MonitoringEventOut(BaseModel):
    id: str
    environment_id: str
    environment_name: str
    target_type: str
    target_id: Optional[str] = None
    target_name: str
    event_type: str
    severity: str
    state: str
    title: str
    message: str
    current_value: Optional[float] = None
    threshold_value: Optional[float] = None
    triggered_at: datetime
    acknowledged_at: Optional[datetime] = None
    acknowledged_by: Optional[str] = None
    recovered_at: Optional[datetime] = None
    impact_metadata: Dict[str, Any] = {}
    linked_incident_id: Optional[str] = None
    auto_heal_triggered: bool = False
    auto_heal_execution_id: Optional[str] = None
    model_config = ConfigDict(from_attributes=True)


class RemediateEventRequest(BaseModel):
    rule_id: Optional[str] = None
    action_type: Optional[str] = "SERVICE_RESTART"
    notes: Optional[str] = "Manual remediation triggered from Monitoring Observability Console"
