from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class EnvironmentComparisonRequest(BaseModel):
    source_environment_id: str = Field(..., description="ID or exact Name of source environment (e.g. SIT)")
    target_environment_id: str = Field(..., description="ID or exact Name of target environment (e.g. UAT)")
    include_server_check: bool = Field(default=True, description="Whether to include server specs comparison")
    include_health_check: bool = Field(default=True, description="Whether to include health check status")


class ComparisonEnvironmentMeta(BaseModel):
    id: str
    name: str
    tier: str
    status: str
    business_unit: Optional[str] = None
    project: Optional[str] = None
    application: Optional[str] = None
    server_host: Optional[str] = None
    ip_address: Optional[str] = None


class ComparisonSummary(BaseModel):
    total_software: int = 0
    matching: int = 0
    version_mismatch: int = 0
    missing: int = 0
    extra: int = 0
    outdated: int = 0


class ComparisonDiffItem(BaseModel):
    software: str
    category: str = "RUNTIME"
    source_version: Optional[str] = None
    target_version: Optional[str] = None
    status: str = Field(..., description="MATCH | VERSION_MISMATCH | MISSING | EXTRA | OUTDATED")
    difference_type: str = Field(default="EXACT_MATCH", description="MAJOR_MISMATCH, MINOR_MISMATCH, PATCH_MISMATCH, MISSING_IN_TARGET, EXTRA_IN_TARGET, EXACT_MATCH")
    direction: Optional[str] = Field(None, description="TARGET_BEHIND | TARGET_AHEAD | IDENTICAL | MISSING_IN_TARGET | EXTRA_IN_TARGET")
    details: Optional[str] = None
    source_port: Optional[str] = None
    target_port: Optional[str] = None


class ComparisonRecommendation(BaseModel):
    severity: str = Field(..., description="CRITICAL | WARNING | INFO")
    category: str = Field(..., description="SOFTWARE | VERSION | CONFIGURATION | SERVER")
    software: Optional[str] = None
    title: str
    description: str
    recommendation: str
    remediation_cmd: Optional[str] = None


class ServerComparisonDiff(BaseModel):
    attribute: str
    source_value: Optional[Any] = None
    target_value: Optional[Any] = None
    status: str = "MATCH"  # MATCH | MISMATCH
    details: Optional[str] = None


class EnvironmentComparisonResponse(BaseModel):
    source_environment: ComparisonEnvironmentMeta
    target_environment: ComparisonEnvironmentMeta
    consistency_score: float = Field(..., description="Consistency score percentage between 0.0 and 100.0")
    summary: ComparisonSummary
    comparison: List[ComparisonDiffItem]
    server_comparison: List[ServerComparisonDiff] = Field(default_factory=list)
    recommendations: List[ComparisonRecommendation] = Field(default_factory=list)
    compared_at: datetime = Field(default_factory=datetime.utcnow)
