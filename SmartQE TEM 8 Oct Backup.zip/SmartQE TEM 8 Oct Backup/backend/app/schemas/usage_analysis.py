from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime


class UsageClassificationThresholds(BaseModel):
    frequently_used_utilization: float = Field(default=60.0, description="Min utilization % for Frequently Used")
    frequently_used_bookings: int = Field(default=15, description="Min bookings for Frequently Used")
    moderately_used_utilization: float = Field(default=20.0, description="Min utilization % for Moderately Used")
    moderately_used_bookings: int = Field(default=5, description="Min bookings for Moderately Used")
    rarely_used_utilization: float = Field(default=0.01, description="Min utilization % for Rarely Used")
    rarely_used_bookings: int = Field(default=1, description="Min bookings for Rarely Used")


class TrendPoint(BaseModel):
    period_label: str
    month_name: str
    year: int
    utilization_pct: float
    booking_count: int
    hours_booked: float


class EnvironmentUsageItem(BaseModel):
    environment_id: str
    environment_name: str
    environment_type: str  # DEV, QA, SIT, UAT, PROD, etc.
    tier: str
    primary_application: str
    associated_applications: List[str] = Field(default_factory=list)
    associated_projects: List[str] = Field(default_factory=list)
    business_unit: str
    usage_category: str  # "Frequently Used" | "Moderately Used" | "Rarely Used" | "Never Used"
    booking_count: int
    total_usage_hours: float
    total_usage_days: float
    last_used_date: Optional[str] = None
    last_used_formatted: str
    utilization_pct: float
    trend: str  # "Increasing" | "Decreasing" | "Stable" | "No usage"
    trend_pct_change: float
    release_count: int
    associated_releases: List[str] = Field(default_factory=list)
    top_phase: Optional[str] = None
    phase_breakdown: Dict[str, int] = Field(default_factory=dict)
    average_booking_duration_hours: float
    status: str
    is_active: bool


class UsageSummaryKPIs(BaseModel):
    total_environments: int
    frequently_used_count: int
    moderately_used_count: int
    rarely_used_count: int
    never_used_count: int
    overall_utilization_pct: float
    total_bookings_count: int
    total_usage_hours: float
    most_used_environment_name: Optional[str] = None
    most_used_utilization_pct: float = 0.0
    least_used_environment_name: Optional[str] = None
    least_used_utilization_pct: float = 0.0
    unused_environments_count: int = 0
    fleet_usage_trend: str = "Stable"


class ApplicationDemandInsight(BaseModel):
    application_name: str
    phase_name: str
    available_environments_count: int
    total_bookings_in_period: int
    avg_monthly_demand: float
    demand_status: str  # "HIGH_DEMAND" | "BALANCED" | "LOW_DEMAND" | "CAPACITY_SHORTAGE"
    insight_message: str


class UsageRecommendation(BaseModel):
    id: str
    category: str  # "REASSIGNMENT" | "HIGH_DEMAND" | "CONSOLIDATION" | "UNBOOKED" | "CAPACITY"
    severity: str  # "INFO" | "WARNING" | "CRITICAL" | "SUCCESS"
    target_environment: Optional[str] = None
    title: str
    message: str
    actionable_recommendation: str
    impact_score: str


class UsageAnalysisResponse(BaseModel):
    period_type: str  # "30d" | "90d" | "180d" | "365d" | "custom"
    start_date: str
    end_date: str
    total_days: int
    summary_kpis: UsageSummaryKPIs
    thresholds_applied: UsageClassificationThresholds
    environments: List[EnvironmentUsageItem]
    time_series_trend: List[TrendPoint]
    application_demand_insights: List[ApplicationDemandInsight]
    recommendations: List[UsageRecommendation]
