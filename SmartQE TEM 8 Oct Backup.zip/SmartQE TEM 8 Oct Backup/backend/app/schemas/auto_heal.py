from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field
from app.models.health_check import HealthCheckType, CheckCriticality, HealthStatus
from app.models.auto_heal import (
    AutoHealExecutionMode, AutoHealActionType, AutoHealStatus, AutoHealTriggerType,
    AutoHealScriptType
)


class AutoHealRuleBase(BaseModel):
    name: str = Field(..., description="Descriptive name for the auto-heal rule")
    description: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    application_id: Optional[str] = None
    application_name: Optional[str] = None
    
    trigger_type: AutoHealTriggerType = AutoHealTriggerType.HEALTH_CHECK_FAILURE
    trigger_check_type: Optional[HealthCheckType] = None
    trigger_criticality: CheckCriticality = CheckCriticality.CRITICAL
    
    action_type: AutoHealActionType = AutoHealActionType.RESTART_SERVICE
    action_target: str = Field(default="default-service", description="Target service name, runbook identifier, or script")
    runbook_id: Optional[str] = None
    
    # Script-Based Execution
    script_type: Optional[AutoHealScriptType] = None
    script_content: Optional[str] = None
    script_timeout_seconds: int = Field(default=30, ge=1, le=300)
    script_parameters: Dict[str, Any] = Field(default_factory=dict)
    
    execution_mode: AutoHealExecutionMode = AutoHealExecutionMode.AUTOMATIC
    max_retries: int = Field(default=2, ge=1, le=5)
    retry_interval_seconds: int = Field(default=15, ge=1, le=300)
    grace_period_seconds: int = Field(default=5, ge=1, le=120)
    
    is_enabled: bool = True
    create_incident_on_exhaustion: bool = True
    incident_severity: str = "SEV2"


class AutoHealRuleCreate(AutoHealRuleBase):
    pass


class AutoHealRuleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    application_id: Optional[str] = None
    application_name: Optional[str] = None
    trigger_type: Optional[AutoHealTriggerType] = None
    trigger_check_type: Optional[HealthCheckType] = None
    trigger_criticality: Optional[CheckCriticality] = None
    action_type: Optional[AutoHealActionType] = None
    action_target: Optional[str] = None
    runbook_id: Optional[str] = None
    script_type: Optional[AutoHealScriptType] = None
    script_content: Optional[str] = None
    script_timeout_seconds: Optional[int] = None
    script_parameters: Optional[Dict[str, Any]] = None
    execution_mode: Optional[AutoHealExecutionMode] = None
    max_retries: Optional[int] = None
    retry_interval_seconds: Optional[int] = None
    grace_period_seconds: Optional[int] = None
    is_enabled: Optional[bool] = None
    create_incident_on_exhaustion: Optional[bool] = None
    incident_severity: Optional[str] = None


class AutoHealRuleOut(AutoHealRuleBase):
    id: str
    is_visible: bool = True
    created_by: Optional[str] = None
    owner_id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class AutoHealExecutionOut(BaseModel):
    id: str
    rule_id: Optional[str] = None
    rule_name: str
    environment_id: str
    environment_name: str
    application_name: Optional[str] = None
    trigger_source: str
    trigger_reason: str
    action_type: AutoHealActionType
    action_target: str
    execution_mode: AutoHealExecutionMode
    status: AutoHealStatus
    attempt_number: int
    max_retries: int
    before_health_status: HealthStatus
    after_health_status: Optional[HealthStatus] = None
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_seconds: float
    output_log: Optional[str] = None
    error_details: Optional[str] = None
    linked_incident_id: Optional[str] = None
    executed_by: str
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class AutoHealTriggerRequest(BaseModel):
    environment_id: str
    rule_id: Optional[str] = None
    triggered_by: Optional[str] = "SYSTEM"
    reason: Optional[str] = "Manual operator auto-heal trigger"


class AutoHealApprovalRequest(BaseModel):
    approved_by: str = "Operator"
    decision: str = "APPROVE"  # APPROVE or REJECT
    comments: Optional[str] = None


class AutoHealStats(BaseModel):
    total_rules: int
    active_rules: int
    total_executions: int
    successful_recoveries: int
    pending_approvals: int
    exhausted_incidents: int
    recovery_rate_pct: float
