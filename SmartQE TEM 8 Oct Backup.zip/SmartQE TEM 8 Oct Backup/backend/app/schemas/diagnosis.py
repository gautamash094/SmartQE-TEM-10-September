from datetime import datetime
from typing import List, Optional, Any, Dict
from pydantic import BaseModel, Field, ConfigDict
from app.models.environment_software import SoftwareDiagnosisStatus, SoftwareCategory


class EnvironmentSoftwareBase(BaseModel):
    software_name: str = Field(..., description="Name of the software (e.g. Java, Python, Node.js)")
    category: SoftwareCategory = Field(default=SoftwareCategory.RUNTIME, description="Software category")
    installed_version: Optional[str] = Field(None, description="Currently installed/discovered version")
    expected_version: Optional[str] = Field(None, description="Expected/baseline version")
    status: SoftwareDiagnosisStatus = Field(default=SoftwareDiagnosisStatus.NOT_CHECKED, description="Diagnosis status")
    port: Optional[str] = Field(None, description="Listening port if applicable")
    process_path: Optional[str] = Field(None, description="Path where software is deployed/executed")
    service_name: Optional[str] = Field(None, description="Underlying OS service name")
    vendor: Optional[str] = Field(None, description="Vendor or provider")
    check_details: Optional[str] = Field(None, description="Additional diagnosis diagnostics/notes")


class EnvironmentSoftwareCreate(EnvironmentSoftwareBase):
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None


class EnvironmentSoftwareUpdate(BaseModel):
    software_name: Optional[str] = None
    category: Optional[SoftwareCategory] = None
    installed_version: Optional[str] = None
    expected_version: Optional[str] = None
    status: Optional[SoftwareDiagnosisStatus] = None
    port: Optional[str] = None
    process_path: Optional[str] = None
    service_name: Optional[str] = None
    vendor: Optional[str] = None
    check_details: Optional[str] = None


class EnvironmentSoftwareRead(EnvironmentSoftwareBase):
    id: str
    environment_id: str
    environment_name: str
    last_checked: datetime
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class EnvironmentOverview(BaseModel):
    environment_id: str
    environment_name: str
    environment_type: str = Field(..., description="DEV, SIT, UAT, QA, PRE-PROD, PROD, etc.")
    environment_status: str = Field(..., description="HEALTHY, DEGRADED, DOWN, MAINTENANCE")
    application: Optional[str] = Field(None, description="Associated primary application")
    project: Optional[str] = Field(None, description="Associated project")
    business_unit: Optional[str] = Field(None, description="Associated business unit")
    server_host: Optional[str] = Field(None, description="Primary server/hostname")
    ip_address: Optional[str] = Field(None, description="Host IP address")
    operating_system: Optional[str] = Field(None, description="Host OS")
    cpu_cores: Optional[int] = None
    ram_gb: Optional[float] = None
    storage_gb: Optional[float] = None
    last_health_check_time: Optional[datetime] = None
    last_diagnosis_time: Optional[datetime] = None
    uptime: float = 99.9


class DiagnosisCheckerResult(BaseModel):
    checker_name: str
    category: str  # SOFTWARE | SERVER | HEALTH | DATABASE | APPLICATION | SECURITY
    status: str    # PASSED | WARNING | CRITICAL | INFO
    summary: str
    details: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class DiagnosisSummary(BaseModel):
    total_software: int = 0
    matching: int = 0
    version_mismatch: int = 0
    missing: int = 0
    outdated: int = 0
    unknown: int = 0
    not_checked: int = 0
    consistency_health_score: float = 100.0


class DiagnosisRecommendation(BaseModel):
    severity: str = Field(..., description="CRITICAL | WARNING | INFO")
    category: str = Field(..., description="SOFTWARE | CONFIGURATION | HEALTH | SECURITY")
    software: Optional[str] = None
    title: str
    description: str
    recommendation: str
    remediation_cmd: Optional[str] = None


class EnvironmentDiagnosisResponse(BaseModel):
    environment: EnvironmentOverview
    summary: DiagnosisSummary
    software_inventory: List[EnvironmentSoftwareRead]
    checker_results: List[DiagnosisCheckerResult] = Field(default_factory=list)
    recommendations: List[DiagnosisRecommendation] = Field(default_factory=list)
    diagnosed_at: datetime
