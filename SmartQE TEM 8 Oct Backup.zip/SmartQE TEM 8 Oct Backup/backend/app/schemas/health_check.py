from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel, Field
from app.models.health_check import HealthCheckType, CheckCriticality, HealthStatus


class HealthCheckDefinitionBase(BaseModel):
    name: str = Field(..., description="Name of the health check probe")
    check_type: HealthCheckType = Field(default=HealthCheckType.HTTP)
    environment_id: str
    environment_name: Optional[str] = None
    application_id: Optional[str] = None
    application_name: Optional[str] = None
    server_id: Optional[str] = None
    server_name: Optional[str] = None
    
    target_host: Optional[str] = None
    target_port: Optional[int] = None
    target_url: Optional[str] = None
    http_method: str = Field(default="GET")
    
    expected_http_status: Optional[int] = 200
    expected_response_substring: Optional[str] = None
    timeout_seconds: float = Field(default=5.0, ge=0.5, le=30.0)
    retry_count: int = Field(default=1, ge=0, le=5)
    retry_interval_seconds: float = Field(default=1.0, ge=0.1, le=10.0)
    
    criticality: CheckCriticality = Field(default=CheckCriticality.CRITICAL)
    weight: int = Field(default=20, ge=1, le=100)
    is_enabled: bool = True
    auto_heal_runbook_id: Optional[str] = None
    auto_heal_enabled: bool = False


class HealthCheckDefinitionCreate(HealthCheckDefinitionBase):
    pass


class HealthCheckDefinitionUpdate(BaseModel):
    name: Optional[str] = None
    check_type: Optional[HealthCheckType] = None
    environment_name: Optional[str] = None
    application_id: Optional[str] = None
    application_name: Optional[str] = None
    server_id: Optional[str] = None
    server_name: Optional[str] = None
    target_host: Optional[str] = None
    target_port: Optional[int] = None
    target_url: Optional[str] = None
    http_method: Optional[str] = None
    expected_http_status: Optional[int] = None
    expected_response_substring: Optional[str] = None
    timeout_seconds: Optional[float] = None
    retry_count: Optional[int] = None
    retry_interval_seconds: Optional[float] = None
    criticality: Optional[CheckCriticality] = None
    weight: Optional[int] = None
    is_enabled: Optional[bool] = None
    auto_heal_runbook_id: Optional[str] = None
    auto_heal_enabled: Optional[bool] = None


class HealthCheckDefinitionOut(HealthCheckDefinitionBase):
    id: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class HealthCheckResultOut(BaseModel):
    id: str
    execution_id: str
    check_definition_id: Optional[str] = None
    check_name: str
    check_type: HealthCheckType
    criticality: CheckCriticality
    target: Optional[str] = None
    status: HealthStatus
    response_time_ms: int
    output_message: Optional[str] = None
    error_details: Optional[str] = None
    executed_at: datetime

    class Config:
        from_attributes = True


class HealthCheckExecutionOut(BaseModel):
    id: str
    environment_id: str
    environment_name: str
    overall_status: HealthStatus
    health_score: float
    triggered_by: str
    trigger_type: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_ms: int
    total_checks: int
    passed_checks: int
    failed_checks: int
    warning_checks: int
    summary_message: Optional[str] = None
    auto_heal_triggered: bool = False
    linked_incident_id: Optional[str] = None
    results: List[HealthCheckResultOut] = []

    class Config:
        from_attributes = True


class HealthCheckRunRequest(BaseModel):
    triggered_by: Optional[str] = "SYSTEM"
    trigger_type: Optional[str] = "MANUAL"
    auto_heal_if_critical: Optional[bool] = True
    check_definition_ids: Optional[List[str]] = None  # If provided, only runs subset


class HealthCheckRunResponse(BaseModel):
    execution_id: str
    environment_id: str
    environment_name: str
    overall_status: HealthStatus
    health_score: float
    duration_ms: int
    total_checks: int
    passed_checks: int
    failed_checks: int
    warning_checks: int
    auto_heal_triggered: bool
    linked_incident_id: Optional[str] = None
    summary_message: Optional[str] = None
    results: List[HealthCheckResultOut] = []


class EnvironmentTierSummary(BaseModel):
    tier_name: str  # Server, Database, Application, Network, Dependencies
    status: HealthStatus
    passed: int
    total: int
    avg_latency_ms: int


class EnvironmentHealthSummaryOut(BaseModel):
    environment_id: str
    environment_name: str
    overall_status: HealthStatus
    health_score: float
    last_checked_at: Optional[datetime] = None
    last_execution_id: Optional[str] = None
    tier_summaries: List[EnvironmentTierSummary] = []
    latest_results: List[HealthCheckResultOut] = []
