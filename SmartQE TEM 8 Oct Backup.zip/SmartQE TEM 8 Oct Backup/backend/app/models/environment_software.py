import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, Enum as SQLEnum, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
from app.database.base import Base


class SoftwareDiagnosisStatus(str, enum.Enum):
    MATCH = "MATCH"
    VERSION_MISMATCH = "VERSION_MISMATCH"
    MISSING = "MISSING"
    EXTRA = "EXTRA"
    OUTDATED = "OUTDATED"
    UNKNOWN = "UNKNOWN"
    NOT_CHECKED = "NOT_CHECKED"


class SoftwareCategory(str, enum.Enum):
    RUNTIME = "RUNTIME"
    APPLICATION = "APPLICATION"
    DATABASE = "DATABASE"
    QUEUE = "QUEUE"
    WEB_SERVER = "WEB_SERVER"
    CACHE = "CACHE"
    FRAMEWORK = "FRAMEWORK"
    TOOL = "TOOL"
    SERVICE = "SERVICE"
    OTHER = "OTHER"


class EnvironmentSoftware(Base):
    __tablename__ = "environment_softwares"

    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=False, index=True)
    software_name = Column(String, nullable=False, index=True)
    category = Column(
        SQLEnum(SoftwareCategory, values_callable=lambda obj: [e.value for e in obj]),
        default=SoftwareCategory.RUNTIME,
        nullable=False
    )
    installed_version = Column(String, nullable=True)
    expected_version = Column(String, nullable=True)
    status = Column(
        SQLEnum(SoftwareDiagnosisStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=SoftwareDiagnosisStatus.NOT_CHECKED,
        nullable=False,
        index=True
    )
    port = Column(String, nullable=True)
    process_path = Column(String, nullable=True)
    service_name = Column(String, nullable=True)
    vendor = Column(String, nullable=True)
    last_checked = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    check_details = Column(Text, nullable=True)
    
    # Multi-tenancy & ownership
    is_active = Column(Boolean, default=True, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)
