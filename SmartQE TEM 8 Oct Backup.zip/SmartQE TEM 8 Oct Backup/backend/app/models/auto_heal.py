import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, ForeignKey, Enum as SQLEnum, Text, JSON
from sqlalchemy.orm import relationship
from app.database.base import Base
from app.models.health_check import HealthCheckType, CheckCriticality, HealthStatus


class AutoHealExecutionMode(str, enum.Enum):
    AUTOMATIC = "AUTOMATIC"
    APPROVAL_REQUIRED = "APPROVAL_REQUIRED"
    MANUAL = "MANUAL"


class AutoHealScriptType(str, enum.Enum):
    POWERSHELL = "POWERSHELL"
    BASH = "BASH"
    PYTHON = "PYTHON"
    COMMAND = "COMMAND"


class AutoHealActionType(str, enum.Enum):
    RESTART_SERVICE = "RESTART_SERVICE"
    RESTART_APPLICATION = "RESTART_APPLICATION"
    EXECUTE_RUNBOOK = "EXECUTE_RUNBOOK"
    EXECUTE_SCRIPT = "EXECUTE_SCRIPT"
    CLEAR_TEMP_CACHE = "CLEAR_TEMP_CACHE"
    RELOAD_CONFIGURATION = "RELOAD_CONFIGURATION"


class AutoHealStatus(str, enum.Enum):
    PENDING_APPROVAL = "PENDING_APPROVAL"
    IN_PROGRESS = "IN_PROGRESS"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    REJECTED = "REJECTED"
    EXHAUSTED = "EXHAUSTED"


class AutoHealTriggerType(str, enum.Enum):
    HEALTH_CHECK_FAILURE = "HEALTH_CHECK_FAILURE"
    MONITORING_THRESHOLD = "MONITORING_THRESHOLD"
    MANUAL = "MANUAL"


class AutoHealRule(Base):
    """Configuration rule mapping diagnostic failures to controlled remediation actions."""
    __tablename__ = "auto_heal_rules"

    name = Column(String, nullable=False, index=True)
    description = Column(String, nullable=True)
    environment_id = Column(String, ForeignKey("environments.id", ondelete="CASCADE"), nullable=True, index=True)
    environment_name = Column(String, nullable=True)
    application_id = Column(String, nullable=True, index=True)
    application_name = Column(String, nullable=True)
    
    # Trigger Criteria
    trigger_type = Column(
        SQLEnum(AutoHealTriggerType, values_callable=lambda obj: [e.value for e in obj]),
        default=AutoHealTriggerType.HEALTH_CHECK_FAILURE,
        nullable=False
    )
    trigger_check_type = Column(
        SQLEnum(HealthCheckType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=True
    )
    trigger_criticality = Column(
        SQLEnum(CheckCriticality, values_callable=lambda obj: [e.value for e in obj]),
        default=CheckCriticality.CRITICAL,
        nullable=False
    )
    
    # Remediation Action
    action_type = Column(
        SQLEnum(AutoHealActionType, values_callable=lambda obj: [e.value for e in obj]),
        default=AutoHealActionType.RESTART_SERVICE,
        nullable=False
    )
    action_target = Column(String, nullable=False, default="default-service")
    runbook_id = Column(String, ForeignKey("runbooks.id", ondelete="SET NULL"), nullable=True)
    
    # Script-Based Execution Options
    script_type = Column(
        SQLEnum(AutoHealScriptType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=True
    )
    script_content = Column(Text, nullable=True)
    script_timeout_seconds = Column(Integer, default=30, nullable=False)
    script_parameters = Column(JSON, default=dict, nullable=False)
    
    # Execution & Safety Parameters
    execution_mode = Column(
        SQLEnum(AutoHealExecutionMode, values_callable=lambda obj: [e.value for e in obj]),
        default=AutoHealExecutionMode.AUTOMATIC,
        nullable=False
    )
    max_retries = Column(Integer, default=2, nullable=False)
    retry_interval_seconds = Column(Integer, default=15, nullable=False)
    grace_period_seconds = Column(Integer, default=5, nullable=False)
    
    # Governance & Ownership
    is_enabled = Column(Boolean, default=True, nullable=False)
    create_incident_on_exhaustion = Column(Boolean, default=True, nullable=False)
    incident_severity = Column(String, default="SEV2", nullable=False)
    
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)

    executions = relationship("AutoHealExecution", back_populates="rule", cascade="all, delete-orphan")


class AutoHealExecution(Base):
    """Historical audit record of an auto-heal remediation attempt."""
    __tablename__ = "auto_heal_executions"

    rule_id = Column(String, ForeignKey("auto_heal_rules.id", ondelete="SET NULL"), nullable=True, index=True)
    rule_name = Column(String, nullable=False)
    environment_id = Column(String, ForeignKey("environments.id", ondelete="CASCADE"), nullable=False, index=True)
    environment_name = Column(String, nullable=False)
    application_name = Column(String, nullable=True)
    
    trigger_source = Column(String, default="HEALTH_CHECK", nullable=False) # HEALTH_CHECK, MANUAL, MONITORING
    trigger_reason = Column(Text, nullable=False)
    action_type = Column(
        SQLEnum(AutoHealActionType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False
    )
    action_target = Column(String, nullable=False)
    
    execution_mode = Column(
        SQLEnum(AutoHealExecutionMode, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False
    )
    status = Column(
        SQLEnum(AutoHealStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=AutoHealStatus.IN_PROGRESS,
        nullable=False,
        index=True
    )
    attempt_number = Column(Integer, default=1, nullable=False)
    max_retries = Column(Integer, default=2, nullable=False)
    
    before_health_status = Column(
        SQLEnum(HealthStatus, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False
    )
    after_health_status = Column(
        SQLEnum(HealthStatus, values_callable=lambda obj: [e.value for e in obj]),
        nullable=True
    )
    
    started_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    duration_seconds = Column(Float, default=0.0, nullable=False)
    
    output_log = Column(Text, nullable=True)
    error_details = Column(Text, nullable=True)
    linked_incident_id = Column(String, nullable=True)
    
    executed_by = Column(String, default="SYSTEM", nullable=False)
    approved_by = Column(String, nullable=True)
    approved_at = Column(DateTime(timezone=True), nullable=True)
    
    is_visible = Column(Boolean, default=True, nullable=False, index=True)

    rule = relationship("AutoHealRule", back_populates="executions")
