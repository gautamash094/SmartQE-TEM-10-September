import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, ForeignKey, Enum as SQLEnum, Text
from sqlalchemy.orm import relationship
from app.database.base import Base


class HealthCheckType(str, enum.Enum):
    PING = "PING"
    TCP_PORT = "TCP_PORT"
    HTTP = "HTTP"
    DATABASE = "DATABASE"
    PROCESS = "PROCESS"
    SCRIPT = "SCRIPT"


class CheckCriticality(str, enum.Enum):
    CRITICAL = "CRITICAL"   # If failed, overall environment becomes CRITICAL
    HIGH = "HIGH"           # If failed, environment becomes WARNING / DEGRADED
    MEDIUM = "MEDIUM"       # Informational degradation
    LOW = "LOW"             # Best effort


class HealthStatus(str, enum.Enum):
    HEALTHY = "HEALTHY"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    UNKNOWN = "UNKNOWN"
    NOT_CHECKED = "NOT_CHECKED"
    RUNNING = "RUNNING"


class HealthCheckDefinition(Base):
    """Configuration definition for an individual health check probe."""
    __tablename__ = "health_check_definitions"

    name = Column(String, nullable=False, index=True)
    check_type = Column(
        SQLEnum(HealthCheckType, values_callable=lambda obj: [e.value for e in obj]),
        default=HealthCheckType.HTTP,
        nullable=False,
        index=True
    )
    environment_id = Column(String, ForeignKey("environments.id", ondelete="CASCADE"), nullable=False, index=True)
    environment_name = Column(String, nullable=True)
    application_id = Column(String, nullable=True, index=True)
    application_name = Column(String, nullable=True)
    server_id = Column(String, nullable=True, index=True)
    server_name = Column(String, nullable=True)
    
    # Target Configuration (Endpoint URL, Host IP, Port, DB Connection String)
    target_host = Column(String, nullable=True)
    target_port = Column(Integer, nullable=True)
    target_url = Column(String, nullable=True)
    http_method = Column(String, default="GET", nullable=False)
    
    # Assertions & Tuning
    expected_http_status = Column(Integer, default=200, nullable=True)
    expected_response_substring = Column(String, nullable=True)
    timeout_seconds = Column(Float, default=5.0, nullable=False)
    retry_count = Column(Integer, default=1, nullable=False)
    retry_interval_seconds = Column(Float, default=1.0, nullable=False)
    
    # Governance & Weighting
    criticality = Column(
        SQLEnum(CheckCriticality, values_callable=lambda obj: [e.value for e in obj]),
        default=CheckCriticality.CRITICAL,
        nullable=False
    )
    weight = Column(Integer, default=20, nullable=False)
    is_enabled = Column(Boolean, default=True, nullable=False)
    
    # Auto-Heal linkage
    auto_heal_runbook_id = Column(String, nullable=True)
    auto_heal_enabled = Column(Boolean, default=False, nullable=False)

    # Multi-tenancy & ownership
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)

    results = relationship("HealthCheckResult", back_populates="definition", cascade="all, delete-orphan")


class HealthCheckExecution(Base):
    """Execution run instance for an entire environment."""
    __tablename__ = "health_check_executions"

    environment_id = Column(String, ForeignKey("environments.id", ondelete="CASCADE"), nullable=False, index=True)
    environment_name = Column(String, nullable=False)
    
    overall_status = Column(
        SQLEnum(HealthStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=HealthStatus.RUNNING,
        nullable=False,
        index=True
    )
    health_score = Column(Float, default=0.0, nullable=False)
    
    triggered_by = Column(String, default="SYSTEM", nullable=False)  # User email or 'SCHEDULER'
    trigger_type = Column(String, default="MANUAL", nullable=False)   # MANUAL, SCHEDULED, AUTO_HEAL_VERIFY, CI_CD
    
    started_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    duration_ms = Column(Integer, default=0, nullable=False)
    
    total_checks = Column(Integer, default=0, nullable=False)
    passed_checks = Column(Integer, default=0, nullable=False)
    failed_checks = Column(Integer, default=0, nullable=False)
    warning_checks = Column(Integer, default=0, nullable=False)
    
    summary_message = Column(Text, nullable=True)
    auto_heal_triggered = Column(Boolean, default=False, nullable=False)
    linked_incident_id = Column(String, nullable=True)

    # Multi-tenancy & ownership
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)

    results = relationship("HealthCheckResult", back_populates="execution", cascade="all, delete-orphan", lazy="selectin")


class HealthCheckResult(Base):
    """Granular output of a single check within an execution run."""
    __tablename__ = "health_check_results"

    execution_id = Column(String, ForeignKey("health_check_executions.id", ondelete="CASCADE"), nullable=False, index=True)
    check_definition_id = Column(String, ForeignKey("health_check_definitions.id", ondelete="SET NULL"), nullable=True, index=True)
    
    check_name = Column(String, nullable=False)
    check_type = Column(
        SQLEnum(HealthCheckType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False
    )
    criticality = Column(
        SQLEnum(CheckCriticality, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False
    )
    
    target = Column(String, nullable=True)
    status = Column(
        SQLEnum(HealthStatus, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False
    )
    response_time_ms = Column(Integer, default=0, nullable=False)
    
    output_message = Column(Text, nullable=True)
    error_details = Column(Text, nullable=True)
    executed_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    execution = relationship("HealthCheckExecution", back_populates="results")
    definition = relationship("HealthCheckDefinition", back_populates="results")
