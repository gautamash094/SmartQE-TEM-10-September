import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, Enum as SQLEnum, Text, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.database.base import Base


class EventSeverity(str, enum.Enum):
    CRITICAL = "CRITICAL"
    WARNING = "WARNING"
    INFO = "INFO"


class EventState(str, enum.Enum):
    NORMAL = "NORMAL"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    RECOVERED = "RECOVERED"


class MonitoringMetricType(str, enum.Enum):
    CPU = "CPU"
    MEMORY = "MEMORY"
    DISK = "DISK"
    LATENCY = "LATENCY"
    ERROR_RATE = "ERROR_RATE"
    SERVICE_DOWN = "SERVICE_DOWN"
    DRIFT_DETECTED = "DRIFT_DETECTED"
    HEALTH_SCORE_DROP = "HEALTH_SCORE_DROP"


class MonitoringThresholdRule(Base):
    """Configurable threshold rule for environment telemetry metrics."""
    __tablename__ = "monitoring_threshold_rules"

    name = Column(String, nullable=False, index=True)
    environment_id = Column(String, nullable=True, index=True)  # Null or 'ALL' for global
    metric_type = Column(
        SQLEnum(MonitoringMetricType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False,
        index=True
    )
    operator = Column(String, default=">", nullable=False)  # >, >=, <, <=, ==
    warning_threshold = Column(Float, nullable=False)
    critical_threshold = Column(Float, nullable=False)
    duration_minutes = Column(Integer, default=5, nullable=False)
    is_enabled = Column(Boolean, default=True, nullable=False)
    auto_heal_enabled = Column(Boolean, default=False, nullable=False)
    auto_heal_runbook_id = Column(String, nullable=True)

    # Multi-tenancy & governance
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)


class MonitoringEvent(Base):
    """Real-time event record with lifecycle state management (NORMAL -> WARNING -> CRITICAL -> RECOVERED)."""
    __tablename__ = "monitoring_events"

    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=False, index=True)
    target_type = Column(String, default="ENVIRONMENT", nullable=False)  # SERVER, SERVICE, DATABASE, ENVIRONMENT
    target_id = Column(String, nullable=True)
    target_name = Column(String, nullable=False)
    
    event_type = Column(
        SQLEnum(MonitoringMetricType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False,
        index=True
    )
    severity = Column(
        SQLEnum(EventSeverity, values_callable=lambda obj: [e.value for e in obj]),
        default=EventSeverity.WARNING,
        nullable=False
    )
    state = Column(
        SQLEnum(EventState, values_callable=lambda obj: [e.value for e in obj]),
        default=EventState.WARNING,
        nullable=False,
        index=True
    )
    title = Column(String, nullable=False)
    message = Column(Text, nullable=False)
    current_value = Column(Float, nullable=True)
    threshold_value = Column(Float, nullable=True)
    
    # Lifecycle Timestamps
    triggered_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    acknowledged_at = Column(DateTime(timezone=True), nullable=True)
    acknowledged_by = Column(String, nullable=True)
    recovered_at = Column(DateTime(timezone=True), nullable=True)
    
    # Impact & Remediation Linkage
    impact_metadata = Column(JSON, default=dict, nullable=False)
    linked_incident_id = Column(String, nullable=True)
    auto_heal_triggered = Column(Boolean, default=False, nullable=False)
    auto_heal_execution_id = Column(String, nullable=True)

    # Multi-tenancy & governance
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
