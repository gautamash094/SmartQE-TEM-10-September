from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import get_password_hash
from app.dao.user_dao import user_dao
from app.dao.role_dao import role_dao
from app.dao.setting_dao import setting_dao
from app.dao.test_phase_dao import test_phase_dao
from app.models.role import Role


DEFAULT_SYSTEM_TEST_PHASES = [
    {
        "name": "UNIT",
        "display_name": "UNIT",
        "description": "Component and isolated module level unit testing phase.",
        "color": "#3B82F6",  # Enterprise Blue
        "is_system": True,
        "is_active": True,
        "display_order": 1,
    },
    {
        "name": "UAT",
        "display_name": "UAT",
        "description": "User Acceptance Testing phase.",
        "color": "#F59E0B",  # Enterprise Amber
        "is_system": True,
        "is_active": True,
        "display_order": 2,
    },
    {
        "name": "SIT",
        "display_name": "SIT",
        "description": "System Integration Testing phase.",
        "color": "#06B6D4",  # Enterprise Cyan
        "is_system": True,
        "is_active": True,
        "display_order": 3,
    },
    {
        "name": "QA",
        "display_name": "QA",
        "description": "Quality Assurance testing phase.",
        "color": "#10B981",  # Enterprise Emerald
        "is_system": True,
        "is_active": True,
        "display_order": 4,
    },
    {
        "name": "ST",
        "display_name": "ST",
        "description": "System Testing phase.",
        "color": "#8B5CF6",  # Enterprise Violet
        "is_system": True,
        "is_active": True,
        "display_order": 5,
    },
    {
        "name": "PRE PROD",
        "display_name": "PRE PROD",
        "description": "Pre-Production Staging phase.",
        "color": "#F97316",  # Enterprise Orange
        "is_system": True,
        "is_active": True,
        "display_order": 6,
    },
    {
        "name": "PROD",
        "display_name": "PROD",
        "description": "Live production deployment and verification phase.",
        "color": "#F43F5E",  # Enterprise Rose
        "is_system": True,
        "is_active": True,
        "display_order": 7,
    },
]


async def seed_initial_data(db: AsyncSession) -> None:
    """
    Seed initial system administrator accounts, default Super Admin role,
    initial role hierarchy, default configuration, and default Test Phases.
    """
    # 1. Seed Roles (Only Super Admin initial system role)
    super_admin_role = None
    if await role_dao.count(db) == 0:
        super_admin_role = await role_dao.create(db, {
            "name": "Super Admin",
            "description": "Default initial system role with top-level administrative authority across the TEM application.",
            "role_order": 1,
            "is_system": True,
            "is_active": True,
            "status": "ACTIVE"
        })

        # Seed initial default settings pointing to Super Admin
        await setting_dao.set_value(db, "default_role_id", super_admin_role.id, "Default role assigned to new users")
        await setting_dao.set_value(db, "default_role_name", super_admin_role.name, "Default role name")
    else:
        super_admin_role = await role_dao.get_by_name(db, "Super Admin")

    # 2. Seed Initial Administrator User
    if await user_dao.count(db) == 0 and super_admin_role:
        admin_data = {
            "first_name": "System",
            "last_name": "Admin",
            "username": "admin",
            "email": "admin@testops.io",
            "hashed_password": get_password_hash("Admin@123"),
            "is_active": True,
            "status": "ACTIVE",
            "created_by": "System",
            "updated_by": "System",
        }
        await user_dao.create_user_with_roles(db, admin_data, [super_admin_role])

    # 3. Seed Default System Test Phases (Idempotent: inserts or updates system master records)
    for phase_data in DEFAULT_SYSTEM_TEST_PHASES:
        existing = await test_phase_dao.get_by_name(db, phase_data["name"])
        if not existing:
            await test_phase_dao.create(db, {
                **phase_data,
                "created_by": "System",
                "updated_by": "System",
            })
        else:
            await test_phase_dao.update(db, existing, {
                "display_name": phase_data["display_name"],
                "color": phase_data["color"],
                "display_order": phase_data["display_order"],
                "is_active": True,
                "is_system": True,
                "updated_by": "System",
            })

    # 4. Seed Environment Software Inventory Master Baselines
    from app.models.environment_software import EnvironmentSoftware, SoftwareDiagnosisStatus, SoftwareCategory
    from app.models.environment import Environment
    from app.models.environment_profile import EnvironmentProfile
    from app.dao.environment_software_dao import environment_software_dao

    # Check if environment_softwares is empty
    q_sw_count = select(EnvironmentSoftware)
    res_sw = await db.execute(q_sw_count)
    existing_sw = res_sw.scalars().all()

    if len(existing_sw) == 0:
        # Get all environments and profiles
        q_envs = select(Environment)
        envs = (await db.execute(q_envs)).scalars().all()
        q_profs = select(EnvironmentProfile)
        profs = (await db.execute(q_profs)).scalars().all()

        env_targets = []
        for e in envs:
            env_targets.append({"id": e.id, "name": e.name, "tier": getattr(e.tier, "value", str(e.tier))})
        for p in profs:
            if not any(t["name"].lower() == p.name.lower() for t in env_targets):
                env_targets.append({"id": p.id, "name": p.name, "tier": p.type})

        # Base software catalog templates
        sit_sw_template = [
            ("Java", SoftwareCategory.RUNTIME, "17.0.10", "17.0.10", SoftwareDiagnosisStatus.MATCH, "8080", "/opt/java/jdk-17", "Oracle / OpenJDK"),
            ("Python", SoftwareCategory.RUNTIME, "3.11.5", "3.11.5", SoftwareDiagnosisStatus.MATCH, None, "/usr/bin/python3.11", "Python Software Foundation"),
            ("Node.js", SoftwareCategory.RUNTIME, "20.15.0", "20.15.0", SoftwareDiagnosisStatus.MATCH, "3000", "/usr/local/bin/node", "OpenJS Foundation"),
            ("PostgreSQL", SoftwareCategory.DATABASE, "15.4", "15.4", SoftwareDiagnosisStatus.MATCH, "5432", "/var/lib/postgresql/15", "PostgreSQL Global Dev Group"),
            ("Redis", SoftwareCategory.CACHE, "7.0.11", "7.2.0", SoftwareDiagnosisStatus.VERSION_MISMATCH, "6379", "/usr/bin/redis-server", "Redis Ltd"),
            ("Nginx", SoftwareCategory.WEB_SERVER, "1.24.0", "1.24.0", SoftwareDiagnosisStatus.MATCH, "443", "/etc/nginx", "F5 / NGINX"),
            ("RabbitMQ", SoftwareCategory.QUEUE, "3.12.0", "3.12.0", SoftwareDiagnosisStatus.MATCH, "5672", "/usr/lib/rabbitmq", "VMware Tanzu"),
            ("Docker", SoftwareCategory.TOOL, "24.0.7", "24.0.7", SoftwareDiagnosisStatus.MATCH, None, "/usr/bin/docker", "Docker Inc"),
        ]

        uat_sw_template = [
            ("Java", SoftwareCategory.RUNTIME, "17.0.10", "17.0.10", SoftwareDiagnosisStatus.MATCH, "8080", "/opt/java/jdk-17", "Oracle / OpenJDK"),
            ("Python", SoftwareCategory.RUNTIME, "3.10.12", "3.11.5", SoftwareDiagnosisStatus.VERSION_MISMATCH, None, "/usr/bin/python3.10", "Python Software Foundation"),
            ("Node.js", SoftwareCategory.RUNTIME, None, "20.15.0", SoftwareDiagnosisStatus.MISSING, "3000", "/usr/local/bin/node", "OpenJS Foundation"),
            ("PostgreSQL", SoftwareCategory.DATABASE, "15.4", "15.4", SoftwareDiagnosisStatus.MATCH, "5432", "/var/lib/postgresql/15", "PostgreSQL Global Dev Group"),
            ("Redis", SoftwareCategory.CACHE, "7.2.0", "7.2.0", SoftwareDiagnosisStatus.MATCH, "6379", "/usr/bin/redis-server", "Redis Ltd"),
            ("Nginx", SoftwareCategory.WEB_SERVER, "1.22.0", "1.24.0", SoftwareDiagnosisStatus.VERSION_MISMATCH, "443", "/etc/nginx", "F5 / NGINX"),
            ("Kafka", SoftwareCategory.QUEUE, "3.5.1", "3.5.1", SoftwareDiagnosisStatus.MATCH, "9092", "/opt/kafka", "Apache Software Foundation"),
            ("Docker", SoftwareCategory.TOOL, "24.0.7", "24.0.7", SoftwareDiagnosisStatus.MATCH, None, "/usr/bin/docker", "Docker Inc"),
        ]

        dev_sw_template = [
            ("Java", SoftwareCategory.RUNTIME, "21.0.2", "17.0.10", SoftwareDiagnosisStatus.VERSION_MISMATCH, "8080", "/opt/java/jdk-21", "Oracle / OpenJDK"),
            ("Python", SoftwareCategory.RUNTIME, "3.12.1", "3.11.5", SoftwareDiagnosisStatus.VERSION_MISMATCH, None, "/usr/bin/python3.12", "Python Software Foundation"),
            ("Node.js", SoftwareCategory.RUNTIME, "21.6.0", "20.15.0", SoftwareDiagnosisStatus.VERSION_MISMATCH, "3000", "/usr/local/bin/node", "OpenJS Foundation"),
            ("PostgreSQL", SoftwareCategory.DATABASE, "16.1", "15.4", SoftwareDiagnosisStatus.VERSION_MISMATCH, "5432", "/var/lib/postgresql/16", "PostgreSQL Global Dev Group"),
            ("Redis", SoftwareCategory.CACHE, "7.2.4", "7.2.0", SoftwareDiagnosisStatus.MATCH, "6379", "/usr/bin/redis-server", "Redis Ltd"),
            ("Nginx", SoftwareCategory.WEB_SERVER, "1.25.3", "1.24.0", SoftwareDiagnosisStatus.MATCH, "443", "/etc/nginx", "F5 / NGINX"),
        ]

        for target in env_targets:
            tier_upper = (target["tier"] or "").upper()
            if "UAT" in tier_upper or "STAGING" in tier_upper or "STAGE" in tier_upper:
                catalog = uat_sw_template
            elif "SIT" in tier_upper or "PROD" in tier_upper or "TEST" in target["name"].upper():
                catalog = sit_sw_template
            elif "DEV" in tier_upper or "SANDBOX" in tier_upper:
                catalog = dev_sw_template
            else:
                catalog = sit_sw_template

            for sw_name, cat, inst_ver, exp_ver, st, port, path, vendor in catalog:
                sw_item = EnvironmentSoftware(
                    environment_id=target["id"],
                    environment_name=target["name"],
                    software_name=sw_name,
                    category=cat,
                    installed_version=inst_ver,
                    expected_version=exp_ver,
                    status=st,
                    port=port,
                    process_path=path,
                    vendor=vendor,
                    created_by="System Initializer",
                    check_details="Seeded baseline component"
                )
                db.add(sw_item)

        await db.commit()

