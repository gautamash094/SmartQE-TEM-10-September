from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.common import StandardResponse
from app.schemas.health_check import (
    HealthCheckDefinitionCreate, HealthCheckDefinitionUpdate, HealthCheckDefinitionOut,
    HealthCheckExecutionOut, HealthCheckRunRequest, EnvironmentHealthSummaryOut
)
from app.services.health_check_service import health_check_service
from app.dao.health_check_dao import health_check_dao
from app.models.health_check import HealthCheckDefinition
from app.dependencies.auth import get_current_user

router = APIRouter(prefix="", tags=["Enterprise Health Checks"])


@router.post("/environments/{environment_id}/health-checks/run", response_model=StandardResponse[HealthCheckExecutionOut])
async def run_environment_health_check(
    environment_id: str,
    payload: Optional[HealthCheckRunRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Trigger an asynchronous multi-tier health check for the environment."""
    triggered_by = getattr(current_user, "username", "SYSTEM") if current_user else "SYSTEM"
    auto_heal = payload.auto_heal_if_critical if payload else True
    trigger_type = payload.trigger_type if payload else "MANUAL"
    check_ids = payload.check_definition_ids if payload else None

    execution = await health_check_service.execute_environment_health_check(
        db=db,
        environment_id=environment_id,
        triggered_by=triggered_by,
        trigger_type=trigger_type,
        auto_heal_if_critical=auto_heal,
        check_definition_ids=check_ids
    )

    return StandardResponse(
        success=True,
        message=f"Health check execution completed with status {execution.overall_status.value}",
        data=execution
    )


@router.get("/environments/{environment_id}/health-checks/latest", response_model=StandardResponse[EnvironmentHealthSummaryOut])
async def get_latest_health_summary(
    environment_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Retrieve the latest consolidated health score, status, and tier breakdown."""
    summary = await health_check_service.get_latest_summary(db, environment_id)
    return StandardResponse(
        success=True,
        message="Latest health check summary retrieved successfully",
        data=summary
    )


@router.get("/environments/{environment_id}/health-checks/history", response_model=StandardResponse[List[HealthCheckExecutionOut]])
async def get_health_check_history(
    environment_id: str,
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Retrieve historical health check executions for audit and trend tracking."""
    executions = await health_check_dao.get_executions_history(db, environment_id, limit=limit)
    return StandardResponse(
        success=True,
        message="Health check history retrieved successfully",
        data=executions
    )


@router.get("/environments/{environment_id}/health-checks", response_model=StandardResponse[List[HealthCheckDefinitionOut]])
async def list_health_check_definitions(
    environment_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """List all configured health check probes for an environment."""
    definitions = await health_check_dao.get_definitions_by_environment(db, environment_id)
    return StandardResponse(
        success=True,
        message="Health check definitions retrieved successfully",
        data=definitions
    )


@router.post("/environments/{environment_id}/health-checks", response_model=StandardResponse[HealthCheckDefinitionOut])
async def create_health_check_definition(
    environment_id: str,
    payload: HealthCheckDefinitionCreate,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Add a new health check probe configuration for an environment."""
    user_id = str(getattr(current_user, "id", "") or "")
    username = str(getattr(current_user, "username", "") or "SYSTEM")

    defn = HealthCheckDefinition(
        **payload.model_dump(),
        environment_id=environment_id,
        created_by=username,
        owner_id=user_id,
        is_visible=True
    )
    db.add(defn)
    await db.commit()
    await db.refresh(defn)

    return StandardResponse(
        success=True,
        message="Health check definition created successfully",
        data=defn
    )


@router.put("/health-checks/definitions/{check_id}", response_model=StandardResponse[HealthCheckDefinitionOut])
async def update_health_check_definition(
    check_id: str,
    payload: HealthCheckDefinitionUpdate,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update an existing health check probe configuration."""
    defn = await health_check_dao.get_definition_by_id(db, check_id)
    if not defn:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Health check definition not found")

    username = str(getattr(current_user, "username", "") or "SYSTEM")
    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(defn, field, value)
    defn.modified_by = username

    await db.commit()
    await db.refresh(defn)

    return StandardResponse(
        success=True,
        message="Health check definition updated successfully",
        data=defn
    )


@router.delete("/health-checks/definitions/{check_id}", response_model=StandardResponse[dict])
async def delete_health_check_definition(
    check_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete a health check probe definition."""
    defn = await health_check_dao.get_definition_by_id(db, check_id)
    if not defn:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Health check definition not found")

    defn.is_visible = False
    await db.commit()

    return StandardResponse(
        success=True,
        message="Health check definition removed successfully",
        data={"id": check_id}
    )


@router.get("/health-checks/executions/{execution_id}", response_model=StandardResponse[HealthCheckExecutionOut])
async def get_execution_details(
    execution_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Retrieve detailed results of a specific execution run."""
    execution = await health_check_dao.get_execution_by_id(db, execution_id)
    if not execution:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Health check execution not found")

    return StandardResponse(
        success=True,
        message="Execution details retrieved successfully",
        data=execution
    )
