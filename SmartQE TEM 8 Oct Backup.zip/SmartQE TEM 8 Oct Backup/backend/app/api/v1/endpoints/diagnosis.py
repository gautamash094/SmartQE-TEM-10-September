from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.models.environment_software import EnvironmentSoftware, SoftwareDiagnosisStatus, SoftwareCategory
from app.schemas.common import StandardResponse
from app.schemas.diagnosis import (
    EnvironmentDiagnosisResponse,
    EnvironmentSoftwareCreate,
    EnvironmentSoftwareUpdate,
    EnvironmentSoftwareRead
)
from app.schemas.comparison import (
    EnvironmentComparisonRequest,
    EnvironmentComparisonResponse
)
from app.services.diagnosis.diagnosis_service import diagnosis_service
from app.services.comparison_service import environment_comparator
from app.dao.environment_software_dao import environment_software_dao
from app.dao.environment_dao import environment_dao

router = APIRouter(tags=["Environment Diagnosis & Comparison"])


@router.get("/environments/{env_id}/diagnosis", response_model=StandardResponse[EnvironmentDiagnosisResponse])
async def get_environment_diagnosis(
    env_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Diagnoses an individual environment, evaluating complete software/configuration
    inventory against expected baselines, server health, and active probes.
    """
    diagnosis_result = await diagnosis_service.diagnose_environment(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Environment diagnosis completed for '{diagnosis_result.environment.environment_name}'",
        data=diagnosis_result
    )


@router.post("/environments/{env_id}/diagnose", response_model=StandardResponse[EnvironmentDiagnosisResponse])
async def run_environment_diagnosis(
    env_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Triggers an immediate on-demand diagnosis run for the environment,
    refreshing timestamps, checker probe results, and consistency health scores.
    """
    diagnosis_result = await diagnosis_service.diagnose_environment(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Fresh diagnosis executed for '{diagnosis_result.environment.environment_name}'",
        data=diagnosis_result
    )


@router.get("/environments/{env_id}/software", response_model=StandardResponse[List[EnvironmentSoftwareRead]])
async def get_environment_software(
    env_id: str,
    category: Optional[str] = Query(None, description="Filter by category (RUNTIME, DATABASE, etc.)"),
    status: Optional[str] = Query(None, description="Filter by status (MATCH, VERSION_MISMATCH, MISSING, etc.)"),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Retrieves the installed and configured software inventory for a specific environment.
    """
    items = await environment_software_dao.get_by_environment_id_or_name(db, env_id)
    
    if category:
        items = [i for i in items if (str(i.category.value if hasattr(i.category, "value") else i.category).upper() == category.upper())]
    if status:
        items = [i for i in items if (str(i.status.value if hasattr(i.status, "value") else i.status).upper() == status.upper())]

    data = [EnvironmentSoftwareRead.model_validate(i) for i in items]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} software components for environment '{env_id}'",
        data=data
    )


@router.post("/environments/{env_id}/software", response_model=StandardResponse[EnvironmentSoftwareRead], status_code=status.HTTP_201_CREATED)
async def add_environment_software(
    env_id: str,
    payload: EnvironmentSoftwareCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Registers a new software component or runtime package for an environment.
    """
    env = await environment_dao.get_by_id(db, env_id)
    if not env:
        env = await environment_dao.get_by_name(db, env_id)
    
    env_name = env.name if env else (payload.environment_name or env_id)
    real_env_id = env.id if env else env_id

    # Check if duplicate exists
    existing = await environment_software_dao.get_by_env_and_software_name(db, real_env_id, payload.software_name)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Software '{payload.software_name}' already exists in environment '{env_name}'"
        )

    creator = current_user.username if current_user else "System Admin"
    owner_id = str(current_user.id) if current_user else None

    new_item = EnvironmentSoftware(
        environment_id=real_env_id,
        environment_name=env_name,
        software_name=payload.software_name.strip(),
        category=payload.category,
        installed_version=payload.installed_version.strip() if payload.installed_version else None,
        expected_version=payload.expected_version.strip() if payload.expected_version else None,
        status=payload.status or SoftwareDiagnosisStatus.NOT_CHECKED,
        port=payload.port.strip() if payload.port else None,
        process_path=payload.process_path.strip() if payload.process_path else None,
        service_name=payload.service_name.strip() if payload.service_name else None,
        vendor=payload.vendor.strip() if payload.vendor else None,
        check_details=payload.check_details,
        created_by=creator,
        owner_id=owner_id
    )

    db.add(new_item)
    await db.commit()
    await db.refresh(new_item)

    return StandardResponse(
        success=True,
        message=f"Software '{payload.software_name}' registered for environment '{env_name}'",
        data=EnvironmentSoftwareRead.model_validate(new_item)
    )


@router.put("/environments/{env_id}/software/{software_id}", response_model=StandardResponse[EnvironmentSoftwareRead])
async def update_environment_software(
    env_id: str,
    software_id: str,
    payload: EnvironmentSoftwareUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Updates a software inventory item (e.g., updating installed version or expected baseline version).
    """
    item = await environment_software_dao.get_by_id(db, software_id)
    if not item or item.is_active is False:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Software item with ID '{software_id}' not found"
        )

    update_dict = payload.model_dump(exclude_unset=True)
    for field, val in update_dict.items():
        if val is not None and hasattr(item, field):
            setattr(item, field, val)

    item.modified_by = current_user.username if current_user else "System Admin"
    item.last_checked = datetime.now(timezone.utc)

    await db.commit()
    await db.refresh(item)

    return StandardResponse(
        success=True,
        message=f"Software '{item.software_name}' updated successfully",
        data=EnvironmentSoftwareRead.model_validate(item)
    )


@router.delete("/environments/{env_id}/software/{software_id}", response_model=StandardResponse[dict])
async def delete_environment_software(
    env_id: str,
    software_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Deactivates/removes a software inventory item from the environment.
    """
    item = await environment_software_dao.get_by_id(db, software_id)
    if not item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Software item with ID '{software_id}' not found"
        )

    item.is_active = False
    item.modified_by = current_user.username if current_user else "System Admin"
    await db.commit()

    return StandardResponse(
        success=True,
        message=f"Software '{item.software_name}' removed from environment",
        data={"id": software_id, "is_active": False}
    )


@router.post("/environments/compare", response_model=StandardResponse[EnvironmentComparisonResponse])
async def compare_environments(
    request: EnvironmentComparisonRequest,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Compares two environments (e.g., SIT vs UAT), evaluates software & version diffs,
    detects missing/extra components, calculates consistency score, and generates actionable recommendations.
    """
    if request.source_environment_id == request.target_environment_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Source and Target environments must be different."
        )

    comparison_result = await environment_comparator.compare_environments(db, request)
    return StandardResponse(
        success=True,
        message=f"Comparison completed: '{comparison_result.source_environment.name}' vs '{comparison_result.target_environment.name}'",
        data=comparison_result
    )
