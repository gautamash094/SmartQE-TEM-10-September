from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.schemas.common import StandardResponse
from app.schemas.usage_analysis import (
    UsageAnalysisResponse,
    UsageClassificationThresholds,
)
from app.services.usage_analysis_service import usage_analysis_service

router = APIRouter(prefix="/usage-analysis", tags=["Environment Usage Analysis"])


@router.get("", response_model=StandardResponse[UsageAnalysisResponse])
async def get_environment_usage_analysis(
    period: str = Query(default="90d", description="Analysis period: 30d, 90d, 180d, 365d, custom"),
    startDate: Optional[str] = Query(default=None, description="Custom start date (ISO)"),
    endDate: Optional[str] = Query(default=None, description="Custom end date (ISO)"),
    businessUnit: Optional[str] = Query(default=None, description="Filter by Business Unit"),
    project: Optional[str] = Query(default=None, description="Filter by Project"),
    application: Optional[str] = Query(default=None, description="Filter by Application"),
    tier: Optional[str] = Query(default=None, description="Filter by Tier / Environment Type"),
    testPhase: Optional[str] = Query(default=None, description="Filter by Test Phase"),
    category: Optional[str] = Query(default=None, description="Filter by Usage Category"),
    freqUtilThreshold: float = Query(default=60.0, description="Frequently used min utilization %"),
    freqBookingsThreshold: int = Query(default=15, description="Frequently used min bookings"),
    modUtilThreshold: float = Query(default=20.0, description="Moderately used min utilization %"),
    modBookingsThreshold: int = Query(default=5, description="Moderately used min bookings"),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    """
    Intelligent Environment Usage Analysis endpoint.
    Returns calculated utilization, intelligent 4-tier classifications, monthly trend points,
    demand-capacity ratios, and proactive actionable recommendations.
    """
    thresholds = UsageClassificationThresholds(
        frequently_used_utilization=freqUtilThreshold,
        frequently_used_bookings=freqBookingsThreshold,
        moderately_used_utilization=modUtilThreshold,
        moderately_used_bookings=modBookingsThreshold,
    )

    data = await usage_analysis_service.get_usage_analysis(
        db=db,
        period=period,
        start_date_str=startDate,
        end_date_str=endDate,
        business_unit=businessUnit,
        project=project,
        application=application,
        tier=tier,
        test_phase=testPhase,
        category_filter=category,
        thresholds=thresholds,
        current_user=current_user,
    )

    return StandardResponse(
        success=True,
        message="Environment usage analysis computed successfully",
        data=data,
    )
