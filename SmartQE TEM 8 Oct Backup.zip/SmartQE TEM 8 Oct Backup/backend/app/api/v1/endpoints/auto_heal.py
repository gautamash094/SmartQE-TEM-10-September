from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.common import StandardResponse
from app.schemas.auto_heal import (
    AutoHealRuleCreate, AutoHealRuleUpdate, AutoHealRuleOut,
    AutoHealExecutionOut, AutoHealTriggerRequest, AutoHealApprovalRequest, AutoHealStats
)
from app.services.auto_heal_service import auto_heal_service
from app.dao.auto_heal_dao import auto_heal_dao
from app.models.auto_heal import AutoHealRule
from app.dependencies.auth import get_current_user

router = APIRouter(prefix="/auto-heal", tags=["Enterprise Auto-Heal"])


@router.get("/rules", response_model=StandardResponse[List[AutoHealRuleOut]])
async def get_auto_heal_rules(
    environment_id: Optional[str] = Query(None, description="Filter rules by environment ID"),
    enabled_only: bool = Query(False, description="Return only enabled rules"),
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Retrieve all configured auto-heal remediation rules."""
    rules = await auto_heal_dao.get_rules_by_environment(db, environment_id, enabled_only=enabled_only)
    return StandardResponse(
        success=True,
        message="Auto-Heal rules retrieved successfully",
        data=rules
    )


@router.post("/rules", response_model=StandardResponse[AutoHealRuleOut], status_code=status.HTTP_201_CREATED)
async def create_auto_heal_rule(
    payload: AutoHealRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new auto-heal remediation rule."""
    rule_dict = payload.model_dump()
    user_email = getattr(current_user, "username", "admin@smartqe.com") if current_user else "admin@smartqe.com"
    user_id = getattr(current_user, "id", None) if current_user else None
    rule_dict["created_by"] = user_email
    rule_dict["owner_id"] = user_id

    rule = await auto_heal_dao.create(db, rule_dict)
    return StandardResponse(
        success=True,
        message=f"Auto-Heal rule '{rule.name}' created successfully",
        data=rule
    )



@router.put("/rules/{rule_id}", response_model=StandardResponse[AutoHealRuleOut])
async def update_auto_heal_rule(
    rule_id: str,
    payload: AutoHealRuleUpdate,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update an existing auto-heal remediation rule."""
    rule = await auto_heal_dao.get_rule_by_id(db, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Auto-Heal rule not found")

    update_data = payload.model_dump(exclude_unset=True)
    user_email = getattr(current_user, "username", None) if current_user else None
    if user_email:
        update_data["modified_by"] = user_email

    updated_rule = await auto_heal_dao.update(db, rule, update_data)
    return StandardResponse(
        success=True,
        message=f"Auto-Heal rule '{updated_rule.name}' updated successfully",
        data=updated_rule
    )


@router.delete("/rules/{rule_id}", response_model=StandardResponse[dict])
async def delete_auto_heal_rule(
    rule_id: str,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete an auto-heal remediation rule."""
    rule = await auto_heal_dao.get_rule_by_id(db, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Auto-Heal rule not found")

    await auto_heal_dao.delete(db, rule.id)
    return StandardResponse(
        success=True,
        message=f"Auto-Heal rule '{rule.name}' deleted successfully",
        data={"id": rule_id}
    )


@router.get("/executions", response_model=StandardResponse[List[AutoHealExecutionOut]])
async def get_auto_heal_executions(
    environment_id: Optional[str] = Query(None, description="Filter executions by environment ID"),
    limit: int = Query(20, ge=1, le=100, description="Max execution records"),
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Retrieve audit history of auto-heal executions."""
    executions = await auto_heal_dao.get_executions_by_environment(db, environment_id, limit=limit)
    return StandardResponse(
        success=True,
        message="Auto-Heal execution history retrieved successfully",
        data=executions
    )


@router.get("/executions/pending", response_model=StandardResponse[List[AutoHealExecutionOut]])
async def get_pending_auto_heal_approvals(
    environment_id: Optional[str] = Query(None, description="Filter pending approvals by environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Retrieve all pending auto-heal executions awaiting operator approval."""
    pending = await auto_heal_dao.get_pending_approvals(db, environment_id)
    return StandardResponse(
        success=True,
        message="Pending auto-heal approvals retrieved successfully",
        data=pending
    )


@router.post("/executions/{execution_id}/approve", response_model=StandardResponse[AutoHealExecutionOut])
async def approve_auto_heal_execution(
    execution_id: str,
    payload: Optional[AutoHealApprovalRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Approve a pending auto-heal execution and trigger remediation."""
    approved_by = payload.approved_by if payload else (getattr(current_user, "username", "Operator") if current_user else "Operator")
    execution = await auto_heal_service.approve_execution(db, execution_id, approved_by=approved_by)
    if not execution:
        raise HTTPException(status_code=404, detail="Pending execution not found or already processed")

    return StandardResponse(
        success=True,
        message=f"Auto-Heal execution #{execution_id} approved and executed with result: {execution.status.value}",
        data=execution
    )


@router.post("/executions/{execution_id}/reject", response_model=StandardResponse[AutoHealExecutionOut])
async def reject_auto_heal_execution(
    execution_id: str,
    payload: Optional[AutoHealApprovalRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Reject a pending auto-heal execution."""
    rejected_by = payload.approved_by if payload else (getattr(current_user, "username", "Operator") if current_user else "Operator")
    comments = payload.comments if payload else "Rejected by operator"
    execution = await auto_heal_service.reject_execution(db, execution_id, rejected_by=rejected_by, comments=comments)
    if not execution:
        raise HTTPException(status_code=404, detail="Pending execution not found or already processed")

    return StandardResponse(
        success=True,
        message=f"Auto-Heal execution #{execution_id} rejected",
        data=execution
    )


@router.post("/trigger", response_model=StandardResponse[AutoHealExecutionOut])
async def trigger_manual_auto_heal(
    payload: AutoHealTriggerRequest,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Manually invoke Auto-Heal remediation on an environment."""
    triggered_by = payload.triggered_by or (getattr(current_user, "username", "Operator") if current_user else "Operator")
    execution = await auto_heal_service.trigger_manual_heal(
        db,
        environment_id=payload.environment_id,
        rule_id=payload.rule_id,
        triggered_by=triggered_by
    )
    return StandardResponse(
        success=True,
        message=f"Auto-Heal manual remediation completed with status: {execution.status.value}",
        data=execution
    )


@router.get("/stats", response_model=StandardResponse[AutoHealStats])
async def get_auto_heal_stats(
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Retrieve fleet-wide Auto-Heal statistics and recovery rate."""
    stats = await auto_heal_service.get_dashboard_stats(db)
    return StandardResponse(
        success=True,
        message="Auto-Heal statistics retrieved successfully",
        data=stats
    )
