from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.common import StandardResponse
from app.schemas.monitoring import (
    FleetObservabilitySummary, EnvironmentDetailedObservability, HistoricalTelemetryOut,
    ThresholdRuleCreate, ThresholdRuleOut, MonitoringEventOut, RemediateEventRequest
)
from app.services.monitoring_service import monitoring_service
from app.services.health_check_service import health_check_service
from app.dependencies.auth import get_current_user_optional
from app.models.user import User

router = APIRouter(prefix="/monitoring", tags=["Enterprise Environment Observability"])


@router.get("/summary", response_model=StandardResponse[FleetObservabilitySummary])
async def get_fleet_observability_summary(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves fleet-wide executive environment observability summary,
    including health scores, test readiness, drift counts, and operational KPIs.
    """
    summary = await monitoring_service.get_fleet_observability_summary(db)
    return StandardResponse(
        success=True,
        message="Fleet observability summary retrieved successfully",
        data=summary
    )


@router.get("/environments/{env_id}", response_model=StandardResponse[EnvironmentDetailedObservability])
async def get_environment_observability(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves granular environment observability dossier, covering multi-tier health,
    test readiness reasons, configuration drift, active release impact, and auto-heal status.
    """
    dossier = await monitoring_service.get_environment_detailed_observability(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Environment observability retrieved for '{dossier.environment_name}'",
        data=dossier
    )


@router.get("/environments/{env_id}/trends", response_model=StandardResponse[HistoricalTelemetryOut])
async def get_historical_telemetry_trends(
    env_id: str,
    timeframe: str = Query("24h", description="Timeframe: 1h, 6h, 24h, 7d, 30d"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves historical metrics telemetry and health score trends across 1h, 6h, 24h, 7d, 30d timeframes.
    """
    trends = await monitoring_service.get_historical_telemetry(db, env_id, timeframe)
    return StandardResponse(
        success=True,
        message=f"Historical telemetry trends for '{timeframe}' retrieved successfully",
        data=trends
    )


@router.get("/events", response_model=StandardResponse[List[MonitoringEventOut]])
async def list_monitoring_events(
    state: Optional[str] = Query(None, description="Filter by event state: NORMAL, WARNING, CRITICAL, RECOVERED"),
    severity: Optional[str] = Query(None, description="Filter by severity: CRITICAL, WARNING, INFO"),
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists real-time threshold and observability events with state machine transitions.
    """
    events = await monitoring_service.get_monitoring_events(db, state=state, severity=severity, limit=limit)
    data = [MonitoringEventOut.model_validate(e) for e in events]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} monitoring events",
        data=data
    )


@router.post("/events/{event_id}/acknowledge", response_model=StandardResponse[Optional[MonitoringEventOut]])
async def acknowledge_monitoring_event(
    event_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Acknowledges an active threshold alert event.
    """
    user_name = getattr(current_user, "username", "Ops Engineer") if current_user else "Ops Engineer"
    event = await monitoring_service.acknowledge_event(db, event_id, user_name)
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Monitoring event not found")

    return StandardResponse(
        success=True,
        message="Monitoring event acknowledged successfully",
        data=MonitoringEventOut.model_validate(event)
    )


@router.post("/events/{event_id}/remediate", response_model=StandardResponse[dict])
async def remediate_monitoring_event(
    event_id: str,
    payload: Optional[RemediateEventRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Triggers Auto-Heal remediation for the event and performs closed-loop validation.
    """
    user_name = getattr(current_user, "username", "Ops Lead") if current_user else "Ops Lead"
    success, msg = await monitoring_service.remediate_event(db, event_id, user_name)

    return StandardResponse(
        success=success,
        message=msg,
        data={"event_id": event_id, "status": "RECOVERED" if success else "REMEDIATION_FAILED"}
    )


@router.get("/threshold-rules", response_model=StandardResponse[List[ThresholdRuleOut]])
async def list_threshold_rules(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists all configured telemetry threshold rules.
    """
    rules = await monitoring_service.get_threshold_rules(db)
    data = [ThresholdRuleOut.model_validate(r) for r in rules]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} threshold rules",
        data=data
    )


@router.post("/threshold-rules", response_model=StandardResponse[ThresholdRuleOut], status_code=status.HTTP_201_CREATED)
async def create_threshold_rule(
    payload: ThresholdRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Creates a new metric threshold rule.
    """
    rule = await monitoring_service.create_threshold_rule(db, payload)
    return StandardResponse(
        success=True,
        message=f"Threshold rule '{rule.name}' created successfully",
        data=ThresholdRuleOut.model_validate(rule)
    )


@router.post("/environments/{env_id}/health-check", response_model=StandardResponse[EnvironmentDetailedObservability])
async def trigger_environment_health_and_refresh(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Triggers an on-demand synthetic health check run and returns the freshly updated observability dossier.
    """
    user_name = getattr(current_user, "username", "Ops Tester") if current_user else "Ops Tester"
    await health_check_service.execute_environment_health_check(
        db=db,
        environment_id=env_id,
        triggered_by=user_name,
        trigger_type="MANUAL",
        auto_heal_if_critical=True
    )
    dossier = await monitoring_service.get_environment_detailed_observability(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Health check executed and observability refreshed for '{dossier.environment_name}'",
        data=dossier
    )
