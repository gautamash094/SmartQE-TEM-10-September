from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.schemas.test_phase import TestPhaseRead, CustomTestPhaseCreate
from app.schemas.common import StandardResponse
from app.services.test_phase_service import test_phase_service

router = APIRouter(prefix="/test-phases", tags=["Test Phases Master"])


@router.get("", response_model=StandardResponse[List[TestPhaseRead]])
async def get_test_phases(
    only_active: bool = Query(default=True),
    db: AsyncSession = Depends(get_db)
):
    """
    Read-only endpoint to retrieve system-defined and custom test phases ordered by display_order.
    Only active phases are returned by default.
    """
    phases = await test_phase_service.get_all_test_phases(db, only_active=only_active)
    return StandardResponse(
        success=True,
        message="Test phases retrieved successfully",
        data=phases
    )


@router.post("/custom", response_model=StandardResponse[TestPhaseRead], status_code=status.HTTP_201_CREATED)
async def create_custom_test_phase(
    phase_in: CustomTestPhaseCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Create a custom test phase with a unique name and color code.
    Sets is_system=False and automatically assigns display_order.
    """
    creator = "User"
    if current_user and getattr(current_user, "username", None):
        creator = current_user.username

    created_phase = await test_phase_service.create_custom_test_phase(
        db=db,
        phase_in=phase_in,
        created_by=creator
    )
    return StandardResponse(
        success=True,
        message="Custom test phase created successfully",
        data=created_phase
    )


@router.get("/{phase_id}", response_model=StandardResponse[TestPhaseRead])
async def get_test_phase_by_id(
    phase_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Read-only endpoint to retrieve a test phase by its unique identifier.
    """
    phase = await test_phase_service.get_test_phase_by_id(db, phase_id)
    return StandardResponse(
        success=True,
        message="Test phase details retrieved",
        data=phase
    )

