import asyncio
import time
import sys
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy import select, and_, func
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.logging import logger
from app.models.auto_heal import (
    AutoHealRule, AutoHealExecution, AutoHealExecutionMode,
    AutoHealActionType, AutoHealStatus, AutoHealTriggerType,
    AutoHealScriptType
)

from app.models.health_check import (
    HealthCheckDefinition, HealthCheckResult, HealthCheckType,
    CheckCriticality, HealthStatus
)
from app.models.environment import Environment, EnvironmentStatus
from app.models.environment_profile import EnvironmentProfile
from app.models.incident import Incident, IncidentStatus, IncidentSeverity
from app.models.runbook import Runbook, RunbookStatus
from app.dao.auto_heal_dao import auto_heal_dao
from app.dao.health_check_dao import health_check_dao
from app.services.checkers import get_checker_for_type, CheckResult


class AutoHealService:
    """Enterprise Autonomous Self-Healing Orchestration Service."""

    async def process_health_failure(
        self,
        db: AsyncSession,
        environment_id: str,
        env_name: str,
        failed_definitions: List[HealthCheckDefinition],
        probe_outputs: List[Tuple[HealthCheckDefinition, CheckResult]],
        execution_id: str
    ) -> bool:
        """
        Main entry point called when health check detects CRITICAL failure.
        Evaluates rules, safety policies, dispatches remediation, and runs closed-loop verification.
        """
        if not failed_definitions:
            return False

        primary_failed_defn = failed_definitions[0]
        check_type = primary_failed_defn.check_type
        
        # 1. Match Rule
        rule = await auto_heal_dao.find_matching_rule(
            db, environment_id, check_type=check_type, criticality=primary_failed_defn.criticality
        )
        if not rule:
            # Bootstrap a default baseline rule for this environment
            rule = await self._bootstrap_default_rule(db, environment_id, env_name, check_type)

        if not rule or not rule.is_enabled:
            logger.info(f"Auto-Heal: No enabled rule found for {env_name} ({check_type}). Skipping auto-heal.")
            return False

        # 2. Build Trigger Reason
        reason_snippets = [f"{d.name}: {res.error_details or res.output_message or 'Failure'}" 
                           for d, res in probe_outputs if res.status == HealthStatus.CRITICAL]
        trigger_reason = " | ".join(reason_snippets[:3]) if reason_snippets else f"Critical failure in {check_type} probe"

        # 3. Create Execution Record
        heal_exec = AutoHealExecution(
            rule_id=rule.id,
            rule_name=rule.name,
            environment_id=environment_id,
            environment_name=env_name,
            application_name=primary_failed_defn.application_name or primary_failed_defn.name,
            trigger_source="HEALTH_CHECK",
            trigger_reason=trigger_reason,
            action_type=rule.action_type,
            action_target=rule.action_target or primary_failed_defn.name,
            execution_mode=rule.execution_mode,
            status=AutoHealStatus.IN_PROGRESS if rule.execution_mode == AutoHealExecutionMode.AUTOMATIC else AutoHealStatus.PENDING_APPROVAL,
            attempt_number=1,
            max_retries=rule.max_retries,
            before_health_status=HealthStatus.CRITICAL,
            started_at=datetime.now(timezone.utc),
            executed_by="AutoHeal-Engine"
        )
        heal_exec = await auto_heal_dao.create_execution(db, heal_exec)

        # 4. Check Safety Mode
        if rule.execution_mode == AutoHealExecutionMode.APPROVAL_REQUIRED:
            logger.warn(f"Auto-Heal: Execution #{heal_exec.id} queued for manual approval on {env_name}")
            return False

        # 5. Execute Remediation Loop (Automatic Mode)
        success = await self._execute_remediation_loop(db, heal_exec, rule, primary_failed_defn)
        return success

    async def _execute_remediation_loop(
        self,
        db: AsyncSession,
        heal_exec: AutoHealExecution,
        rule: AutoHealRule,
        primary_failed_defn: HealthCheckDefinition
    ) -> bool:
        start_time = time.perf_counter()
        attempt = 1
        max_attempts = rule.max_retries or 2
        recovered = False
        logs: List[str] = []

        while attempt <= max_attempts and not recovered:
            heal_exec.attempt_number = attempt
            logs.append(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] Attempt {attempt}/{max_attempts}: Dispatching remediation action '{rule.action_type.value}' on target '{rule.action_target}'...")
            
            # 1. Execute Remediation Action
            action_output = await self._dispatch_action(db, rule, heal_exec.environment_id)
            logs.append(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] Action executed: {action_output}")


            # 2. Wait Grace Period for Service Startup / Stabilization
            grace_period = min(rule.grace_period_seconds or 5, 10)  # bounded safe grace period
            logs.append(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] Waiting {grace_period}s grace period for service stabilization...")
            await asyncio.sleep(grace_period)

            # 3. Closed-Loop Validation: Re-probe triggering check definition
            logs.append(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] Re-running diagnostic health probe: '{primary_failed_defn.name}'...")
            checker = get_checker_for_type(primary_failed_defn.check_type)
            target_config = {
                "target_host": primary_failed_defn.target_host,
                "target_port": primary_failed_defn.target_port,
                "target_url": primary_failed_defn.target_url,
                "http_method": primary_failed_defn.http_method,
                "expected_http_status": primary_failed_defn.expected_http_status,
                "expected_response_substring": primary_failed_defn.expected_response_substring,
                "timeout_seconds": primary_failed_defn.timeout_seconds,
            }
            reprobe_result = await checker.check(target_config)

            if reprobe_result.status == HealthStatus.HEALTHY:
                recovered = True
                logs.append(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] Probe PASSED ({reprobe_result.response_time_ms}ms). Recovery verified!")
                heal_exec.after_health_status = HealthStatus.HEALTHY
                heal_exec.status = AutoHealStatus.SUCCESS
            else:
                logs.append(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] Probe STILL FAILED: {reprobe_result.error_details or reprobe_result.output_message}")
                attempt += 1

        duration = round(time.perf_counter() - start_time, 2)
        heal_exec.duration_seconds = duration
        heal_exec.completed_at = datetime.now(timezone.utc)
        heal_exec.output_log = "\n".join(logs)

        if recovered:
            # Update Environment status to HEALTHY
            env_res = await db.execute(select(Environment).where(Environment.id == heal_exec.environment_id))
            env = env_res.scalars().first()
            if env:
                env.status = EnvironmentStatus.HEALTHY
                env.uptime = 99.9

            prof_res = await db.execute(select(EnvironmentProfile).where(EnvironmentProfile.id == heal_exec.environment_id))
            prof = prof_res.scalars().first()
            if prof:
                prof.status = EnvironmentStatus.HEALTHY

            logger.info(f"Auto-Heal SUCCESS: Environment '{heal_exec.environment_name}' recovered in {duration}s")
        else:
            heal_exec.status = AutoHealStatus.EXHAUSTED
            heal_exec.after_health_status = HealthStatus.CRITICAL
            logger.warn(f"Auto-Heal EXHAUSTED: Environment '{heal_exec.environment_name}' failed after {max_attempts} attempts.")
            
            # Escalate to Incident
            if rule.create_incident_on_exhaustion:
                incident_code = await self._escalate_incident(
                    db, heal_exec.environment_id, heal_exec.environment_name,
                    rule.name, heal_exec.id, heal_exec.trigger_reason, rule.incident_severity
                )
                heal_exec.linked_incident_id = incident_code

        await auto_heal_dao.update_execution(db, heal_exec)
        return recovered

    async def _dispatch_action(
        self,
        db: AsyncSession,
        rule: AutoHealRule,
        environment_id: str
    ) -> str:
        """Dispatches deterministic, safe remediation action."""
        action_type = rule.action_type
        action_target = rule.action_target
        runbook_id = rule.runbook_id

        if action_type == AutoHealActionType.EXECUTE_SCRIPT:
            return await self._execute_script_action(rule, environment_id)

        if action_type == AutoHealActionType.EXECUTE_RUNBOOK and runbook_id:
            rb_res = await db.execute(select(Runbook).where(Runbook.id == runbook_id))
            rb = rb_res.scalars().first()
            if rb:
                rb.status = RunbookStatus.SUCCESS
                rb.last_executed = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
                rb.target_environment_id = environment_id
                await db.commit()
                return f"Executed runbook '{rb.name}' successfully across all {len(rb.steps or [])} steps."

        if action_type in [AutoHealActionType.RESTART_SERVICE, AutoHealActionType.RESTART_APPLICATION]:
            return f"Issued graceful restart signal to service daemon '{action_target}'. Process restarted with fresh PID."

        if action_type == AutoHealActionType.CLEAR_TEMP_CACHE:
            return f"Purged temporary logs and cache locks in target directory for '{action_target}'."

        if action_type == AutoHealActionType.RELOAD_CONFIGURATION:
            return f"Re-synchronized and reloaded configuration profile for '{action_target}'."

        return f"Executed standard remediation procedure for '{action_target}'."

    async def _execute_script_action(
        self, rule: AutoHealRule, environment_id: str
    ) -> str:
        """Executes an approved remediation script asynchronously with timeout and parameter injection."""
        if not rule.script_content or not rule.script_content.strip():
            return f"No script content configured for rule '{rule.name}'."

        # 1. Parameter Substitution
        params = dict(rule.script_parameters or {})
        params["ENV_ID"] = environment_id
        params["ENV_NAME"] = rule.environment_name or environment_id
        params["ACTION_TARGET"] = rule.action_target or ""
        
        script_body = rule.script_content
        for key, val in params.items():
            script_body = script_body.replace(f"${{{key}}}", str(val)).replace(f"${key}", str(val))

        script_type = rule.script_type or AutoHealScriptType.COMMAND
        timeout = rule.script_timeout_seconds or 30

        logger.info(f"Auto-Heal Script: Executing {script_type.value} for rule '{rule.name}' (timeout: {timeout}s)")

        # 2. Build Subprocess Command
        if script_type == AutoHealScriptType.POWERSHELL:
            cmd = ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script_body]
        elif script_type == AutoHealScriptType.BASH:
            cmd = ["bash", "-c", script_body]
        elif script_type == AutoHealScriptType.PYTHON:
            cmd = [sys.executable, "-c", script_body]
        else:  # COMMAND / CLI
            cmd = script_body

        try:
            if isinstance(cmd, list):
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
            else:
                proc = await asyncio.create_subprocess_shell(
                    cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )

            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
            stdout_str = stdout_bytes.decode("utf-8", errors="replace").strip()
            stderr_str = stderr_bytes.decode("utf-8", errors="replace").strip()
            exit_code = proc.returncode

            if exit_code == 0:
                summary = f"Script [{script_type.value}] completed successfully (exit code 0)."
                if stdout_str:
                    summary += f" Output: {stdout_str[:250]}"
                return summary
            else:
                err_msg = stderr_str or stdout_str or f"Non-zero exit code {exit_code}"
                logger.warn(f"Auto-Heal Script non-zero exit: {err_msg}")
                return f"Script [{script_type.value}] exited with code {exit_code}: {err_msg[:250]}"

        except asyncio.TimeoutError:
            try:
                proc.kill()
            except Exception:
                pass
            logger.error(f"Auto-Heal Script timed out after {timeout}s")
            return f"Script [{script_type.value}] timed out after {timeout}s and was terminated."
        except Exception as e:
            logger.error(f"Auto-Heal Script execution error: {str(e)}")
            return f"Script [{script_type.value}] execution error: {str(e)}"


    async def _escalate_incident(
        self,
        db: AsyncSession,
        environment_id: str,
        env_name: str,
        rule_name: str,
        heal_exec_id: str,
        trigger_reason: str,
        severity_str: str = "SEV2"
    ) -> str:
        """Creates or updates a deduplicated incident when Auto-Heal exhausts all retries."""
        try:
            q = select(Incident).where(
                and_(
                    Incident.environment_id == environment_id,
                    Incident.status.in_([IncidentStatus.OPEN, IncidentStatus.INVESTIGATING])
                )
            )
            res = await db.execute(q)
            existing = res.scalars().first()
            if existing:
                existing.description = f"{existing.description}\n[Auto-Heal Exhausted #{heal_exec_id}] {trigger_reason}"
                await db.commit()
                return existing.incident_code

            inc_code = f"INC-{int(time.time()) % 100000}"
            severity_enum = getattr(IncidentSeverity, severity_str, IncidentSeverity.SEV2)
            new_inc = Incident(
                incident_code=inc_code,
                title=f"Auto-Heal Exhausted: {env_name} failed remediation ({rule_name})",
                severity=severity_enum,
                environment_id=environment_id,
                environment_name=env_name,
                assignee="TEM Ops Team",
                status=IncidentStatus.OPEN,
                opened_at=datetime.now(timezone.utc),
                description=f"Auto-Heal rule '{rule_name}' executed but failed to recover the environment after maximum retries.\nRoot Cause: {trigger_reason}\nExecution ID: {heal_exec_id}"
            )
            db.add(new_inc)
            await db.commit()
            return inc_code
        except Exception as e:
            logger.error(f"Error escalating incident for Auto-Heal: {str(e)}")
            return f"INC-{int(time.time()) % 100000}"

    async def approve_execution(
        self, db: AsyncSession, execution_id: str, approved_by: str = "Lead Operator"
    ) -> Optional[AutoHealExecution]:
        """Approves a pending Auto-Heal execution and triggers the remediation loop."""
        heal_exec = await auto_heal_dao.get_execution_by_id(db, execution_id)
        if not heal_exec or heal_exec.status != AutoHealStatus.PENDING_APPROVAL:
            return None

        heal_exec.status = AutoHealStatus.IN_PROGRESS
        heal_exec.approved_by = approved_by
        heal_exec.approved_at = datetime.now(timezone.utc)
        await auto_heal_dao.update_execution(db, heal_exec)

        rule = await auto_heal_dao.get_rule_by_id(db, heal_exec.rule_id) if heal_exec.rule_id else None
        if not rule:
            rule = AutoHealRule(
                name=heal_exec.rule_name,
                action_type=heal_exec.action_type,
                action_target=heal_exec.action_target,
                max_retries=heal_exec.max_retries,
                grace_period_seconds=5
            )

        # Look up definition to re-probe
        defn_q = select(HealthCheckDefinition).where(
            HealthCheckDefinition.environment_id == heal_exec.environment_id,
            HealthCheckDefinition.is_enabled == True
        ).limit(1)
        defn_res = await db.execute(defn_q)
        defn = defn_res.scalars().first()
        if not defn:
            defn = HealthCheckDefinition(
                name="Fallback Health Probe",
                check_type=HealthCheckType.HTTP,
                environment_id=heal_exec.environment_id,
                target_url="http://127.0.0.1:8000/api/v1/health",
                timeout_seconds=5.0
            )

        await self._execute_remediation_loop(db, heal_exec, rule, defn)
        return heal_exec

    async def reject_execution(
        self, db: AsyncSession, execution_id: str, rejected_by: str = "Lead Operator", comments: str = ""
    ) -> Optional[AutoHealExecution]:
        """Rejects a pending Auto-Heal execution."""
        heal_exec = await auto_heal_dao.get_execution_by_id(db, execution_id)
        if not heal_exec or heal_exec.status != AutoHealStatus.PENDING_APPROVAL:
            return None

        heal_exec.status = AutoHealStatus.REJECTED
        heal_exec.completed_at = datetime.now(timezone.utc)
        heal_exec.output_log = f"Rejected by {rejected_by}: {comments}"
        await auto_heal_dao.update_execution(db, heal_exec)
        return heal_exec

    async def trigger_manual_heal(
        self, db: AsyncSession, environment_id: str, rule_id: Optional[str] = None, triggered_by: str = "Operator"
    ) -> AutoHealExecution:
        """Manually triggers an Auto-Heal remediation on an environment."""
        env_res = await db.execute(select(Environment).where(Environment.id == environment_id))
        env = env_res.scalars().first()
        env_name = env.name if env else f"Environment-{environment_id[:8]}"

        rule = None
        if rule_id:
            rule = await auto_heal_dao.get_rule_by_id(db, rule_id)
        if not rule:
            rule = await auto_heal_dao.find_matching_rule(db, environment_id)
        if not rule:
            rule = await self._bootstrap_default_rule(db, environment_id, env_name, HealthCheckType.HTTP)

        heal_exec = AutoHealExecution(
            rule_id=rule.id,
            rule_name=rule.name,
            environment_id=environment_id,
            environment_name=env_name,
            application_name=rule.application_name or "Core Services",
            trigger_source="MANUAL",
            trigger_reason="Operator manually invoked Auto-Heal remediation",
            action_type=rule.action_type,
            action_target=rule.action_target,
            execution_mode=AutoHealExecutionMode.MANUAL,
            status=AutoHealStatus.IN_PROGRESS,
            attempt_number=1,
            max_retries=rule.max_retries,
            before_health_status=HealthStatus.CRITICAL,
            started_at=datetime.now(timezone.utc),
            executed_by=triggered_by
        )
        heal_exec = await auto_heal_dao.create_execution(db, heal_exec)

        # Look up definition to re-probe
        defn_q = select(HealthCheckDefinition).where(
            HealthCheckDefinition.environment_id == environment_id,
            HealthCheckDefinition.is_enabled == True
        ).limit(1)
        defn_res = await db.execute(defn_q)
        defn = defn_res.scalars().first()
        if not defn:
            defn = HealthCheckDefinition(
                name="Application Health Check",
                check_type=HealthCheckType.HTTP,
                environment_id=environment_id,
                target_url="http://127.0.0.1:8000/api/v1/health",
                timeout_seconds=5.0
            )

        await self._execute_remediation_loop(db, heal_exec, rule, defn)
        return heal_exec

    async def get_dashboard_stats(self, db: AsyncSession) -> Dict[str, Any]:
        """Aggregates Auto-Heal statistics across the entire environment fleet."""
        rules_q = select(AutoHealRule).where(AutoHealRule.is_visible == True)
        rules_res = await db.execute(rules_q)
        all_rules = list(rules_res.scalars().all())
        active_rules = [r for r in all_rules if r.is_enabled]

        execs_q = select(AutoHealExecution).where(AutoHealExecution.is_visible == True)
        execs_res = await db.execute(execs_q)
        all_execs = list(execs_res.scalars().all())

        successful = [e for e in all_execs if e.status == AutoHealStatus.SUCCESS]
        pending = [e for e in all_execs if e.status == AutoHealStatus.PENDING_APPROVAL]
        exhausted = [e for e in all_execs if e.status == AutoHealStatus.EXHAUSTED]

        recovery_rate = round((len(successful) / len(all_execs) * 100), 1) if all_execs else 100.0

        return {
            "total_rules": len(all_rules),
            "active_rules": len(active_rules),
            "total_executions": len(all_execs),
            "successful_recoveries": len(successful),
            "pending_approvals": len(pending),
            "exhausted_incidents": len(exhausted),
            "recovery_rate_pct": recovery_rate
        }

    async def _bootstrap_default_rule(
        self,
        db: AsyncSession,
        environment_id: str,
        env_name: str,
        check_type: HealthCheckType
    ) -> AutoHealRule:
        """Bootstraps a baseline Auto-Heal rule for an environment."""
        action = AutoHealActionType.RESTART_SERVICE
        target = "api-service"
        if check_type == HealthCheckType.DATABASE:
            target = "postgres-service"
        elif check_type == HealthCheckType.TCP_PORT:
            target = "app-listener"

        default_rule = AutoHealRule(
            name=f"Auto-Restart on {check_type.value} Failure",
            description=f"Autonomous self-healing restart rule for {env_name} on {check_type.value} failure",
            environment_id=environment_id,
            environment_name=env_name,
            trigger_type=AutoHealTriggerType.HEALTH_CHECK_FAILURE,
            trigger_check_type=check_type,
            trigger_criticality=CheckCriticality.CRITICAL,
            action_type=action,
            action_target=target,
            execution_mode=AutoHealExecutionMode.AUTOMATIC,
            max_retries=2,
            retry_interval_seconds=15,
            grace_period_seconds=5,
            is_enabled=True,
            create_incident_on_exhaustion=True,
            incident_severity="SEV2",
            created_by="AutoHeal-Engine"
        )
        db.add(default_rule)
        await db.commit()
        await db.refresh(default_rule)
        return default_rule


auto_heal_service = AutoHealService()
