import uuid
from datetime import datetime, timezone, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.environment import Environment
from app.models.environment_profile import EnvironmentProfile
from app.models.reservation import Reservation, ReservationStatus
from app.models.release import Release
from app.models.portfolio import Application
from app.models.user import User
from app.schemas.usage_analysis import (
    UsageClassificationThresholds,
    EnvironmentUsageItem,
    UsageSummaryKPIs,
    TrendPoint,
    ApplicationDemandInsight,
    UsageRecommendation,
    UsageAnalysisResponse,
)


class UsageAnalysisService:
    """
    Intelligent Environment Usage Analytics Engine.
    Processes historical booking/usage data, computes exact duration-based utilization,
    classifies environments into 4 categories, identifies trends, demand vs capacity ratios,
    and generates actionable AI/heuristic recommendations.
    """

    async def get_usage_analysis(
        self,
        db: AsyncSession,
        period: str = "90d",
        start_date_str: Optional[str] = None,
        end_date_str: Optional[str] = None,
        business_unit: Optional[str] = None,
        project: Optional[str] = None,
        application: Optional[str] = None,
        tier: Optional[str] = None,
        test_phase: Optional[str] = None,
        category_filter: Optional[str] = None,
        thresholds: Optional[UsageClassificationThresholds] = None,
        current_user: Optional[User] = None,
    ) -> UsageAnalysisResponse:
        if not thresholds:
            thresholds = UsageClassificationThresholds()

        now = datetime.now(timezone.utc)

        # 1. Determine Window Start and End Dates (includes operational forward planning horizon)
        if period == "30d":
            window_end = now + timedelta(days=30)
            window_start = now - timedelta(days=30)
        elif period == "90d":
            window_end = now + timedelta(days=60)
            window_start = now - timedelta(days=90)
        elif period == "180d" or period == "6m":
            window_end = now + timedelta(days=90)
            window_start = now - timedelta(days=180)
        elif period == "365d" or period == "1y":
            window_end = now + timedelta(days=180)
            window_start = now - timedelta(days=365)
        elif period == "custom" and start_date_str and end_date_str:
            try:
                window_start = datetime.fromisoformat(start_date_str.replace("Z", "+00:00"))
                window_end = datetime.fromisoformat(end_date_str.replace("Z", "+00:00"))
            except Exception:
                window_end = now + timedelta(days=60)
                window_start = now - timedelta(days=90)
        else:
            window_end = now + timedelta(days=60)
            window_start = now - timedelta(days=90)

        if window_start.tzinfo is None:
            window_start = window_start.replace(tzinfo=timezone.utc)
        if window_end.tzinfo is None:
            window_end = window_end.replace(tzinfo=timezone.utc)

        total_window_seconds = max(1.0, (window_end - window_start).total_seconds())
        total_window_hours = total_window_seconds / 3600.0
        total_days = max(1, int(total_window_seconds / 86400.0))

        # 2. Fetch Environments / Environment Profiles
        base_environments_map: Dict[str, Dict[str, Any]] = {}

        # 2a. Profiles
        env_stmt = select(EnvironmentProfile).where(EnvironmentProfile.is_visible == True)
        env_res = await db.execute(env_stmt)
        for ep in env_res.scalars().all():
            base_environments_map[ep.id] = {
                "id": ep.id,
                "name": ep.name,
                "type": ep.type or "QA",
                "tier": ep.type or "QA",
                "status": ep.status or "HEALTHY",
                "is_active": ep.is_active,
                "owner_team": ep.owner_team or "Enterprise QE",
            }

        # 2b. Base Environments (merge any not in profiles)
        base_env_stmt = select(Environment).where(Environment.is_visible == True)
        base_res = await db.execute(base_env_stmt)
        for be in base_res.scalars().all():
            if be.id not in base_environments_map:
                name_exists = any(
                    e["name"].lower().strip() == be.name.lower().strip()
                    for e in base_environments_map.values()
                )
                if not name_exists:
                    base_environments_map[be.id] = {
                        "id": be.id,
                        "name": be.name,
                        "type": be.tier.value if hasattr(be.tier, "value") else str(be.tier),
                        "tier": be.tier.value if hasattr(be.tier, "value") else str(be.tier),
                        "status": be.status.value if hasattr(be.status, "value") else str(be.status),
                        "is_active": be.is_active,
                        "owner_team": be.team or "Enterprise QE",
                    }

        # 3. Fetch All Relevant Reservations/Bookings
        all_res_stmt = select(Reservation).where(Reservation.is_visible == True)
        all_res_records = (await db.execute(all_res_stmt)).scalars().all()

        # 2c. Discover any environment referenced in reservations
        for r in all_res_records:
            r_name = r.environment_name.strip() if r.environment_name else None
            r_id = r.environment_id or (r_name.lower().replace(" ", "-") if r_name else None)
            if r_name and r_id:
                exists = any(
                    e["name"].lower().strip() == r_name.lower().strip() or e["id"] == r.environment_id
                    for e in base_environments_map.values()
                )
                if not exists:
                    base_environments_map[r_id] = {
                        "id": r_id,
                        "name": r_name,
                        "type": r.test_phase_name or "QA",
                        "tier": r.test_phase_name or "QA",
                        "status": "HEALTHY",
                        "is_active": True,
                        "owner_team": r.business_unit or r.team or "QA Guild",
                    }

        # Active reservations for utilization computation (exclude cancelled/rejected)
        res_records = [
            r for r in all_res_records
            if not any(k in str(r.status.value if hasattr(r.status, "value") else r.status).upper() for k in ["CANCEL", "REJECT"])
        ]

        # 4. Fetch Releases
        rel_stmt = select(Release).where(Release.is_visible == True)
        releases = (await db.execute(rel_stmt)).scalars().all()


        # 5. Process Environment Usage Metrics
        environment_usage_list: List[EnvironmentUsageItem] = []

        total_fleet_hours_booked = 0.0
        total_fleet_bookings = 0

        # Sub-period midpoint for trend calculation
        midpoint = window_start + timedelta(seconds=total_window_seconds / 2.0)

        for env_id, env_data in base_environments_map.items():
            env_name = env_data["name"]
            env_name_lower = env_name.lower().strip()
            env_name_norm = env_name_lower.replace(" ", "").replace("_", "").replace("-", "")

            # Filter matching reservations
            matching_res = [
                r for r in res_records
                if (
                    r.environment_id == env_id
                    or (r.environment_name and r.environment_name.lower().strip() == env_name_lower)
                    or (r.environment_name and r.environment_name.lower().replace(" ", "").replace("_", "").replace("-", "") == env_name_norm)
                )
            ]

            # Filter to overlapping reservations with [window_start, window_end]
            active_in_window: List[Reservation] = []
            total_env_seconds = 0.0
            first_half_seconds = 0.0
            second_half_seconds = 0.0
            last_used_dt: Optional[datetime] = None
            apps_set = set()
            proj_set = set()
            bu_set = set()
            releases_set = set()
            phase_counts: Dict[str, int] = {}

            for r in matching_res:
                r_start = r.start_date
                r_end = r.end_date
                if r_start.tzinfo is None:
                    r_start = r_start.replace(tzinfo=timezone.utc)
                if r_end.tzinfo is None:
                    r_end = r_end.replace(tzinfo=timezone.utc)

                # Check overlap
                overlap_start = max(window_start, r_start)
                overlap_end = min(window_end, r_end)

                if overlap_end > overlap_start:
                    active_in_window.append(r)
                    dur_sec = (overlap_end - overlap_start).total_seconds()
                    total_env_seconds += dur_sec

                    # Trend halves
                    # 1st half: [window_start, midpoint]
                    fh_start = max(window_start, r_start)
                    fh_end = min(midpoint, r_end)
                    if fh_end > fh_start:
                        first_half_seconds += (fh_end - fh_start).total_seconds()

                    # 2nd half: [midpoint, window_end]
                    sh_start = max(midpoint, r_start)
                    sh_end = min(window_end, r_end)
                    if sh_end > sh_start:
                        second_half_seconds += (sh_end - sh_start).total_seconds()

                    if r.application:
                        apps_set.add(r.application.strip())
                    if r.project:
                        proj_set.add(r.project.strip())
                    if r.business_unit:
                        bu_set.add(r.business_unit.strip())
                    if r.release_name:
                        releases_set.add(r.release_name.strip())
                    elif r.release_id:
                        releases_set.add(r.release_id.strip())

                    phase_name = r.test_phase_name or "General Testing"
                    phase_counts[phase_name] = phase_counts.get(phase_name, 0) + 1

                # Track latest usage overall
                if last_used_dt is None or r_end > last_used_dt:
                    last_used_dt = r_end

            # Calculate metrics
            usage_hours = round(total_env_seconds / 3600.0, 1)
            usage_days = round(total_env_seconds / 86400.0, 1)
            booking_count = len(active_in_window)

            total_fleet_hours_booked += usage_hours
            total_fleet_bookings += booking_count

            # Utilization %
            raw_util_pct = (total_env_seconds / total_window_seconds) * 100.0
            utilization_pct = min(100.0, round(raw_util_pct, 1))

            # Classification logic with configurable thresholds
            if booking_count == 0 or utilization_pct == 0:
                usage_category = "Never Used"
            elif (
                utilization_pct >= thresholds.frequently_used_utilization
                or booking_count >= thresholds.frequently_used_bookings
            ):
                usage_category = "Frequently Used"
            elif (
                utilization_pct >= thresholds.moderately_used_utilization
                or booking_count >= thresholds.moderately_used_bookings
            ):
                usage_category = "Moderately Used"
            else:
                usage_category = "Rarely Used"

            # Trend calculation
            half_window_sec = total_window_seconds / 2.0
            first_half_util = (first_half_seconds / half_window_sec) * 100.0
            second_half_util = (second_half_seconds / half_window_sec) * 100.0
            trend_diff = round(second_half_util - first_half_util, 1)

            if booking_count == 0:
                trend_str = "No usage"
            elif trend_diff > 0.5:
                trend_str = "Increasing"
            elif trend_diff < -0.5:
                trend_str = "Decreasing"
            else:
                trend_str = "Stable"

            # Formatted Last Used Date vs Active / Scheduled Horizon
            if last_used_dt:
                last_used_date_str = last_used_dt.isoformat()
                date_str = last_used_dt.strftime("%d %b %Y")
                if last_used_dt > now:
                    is_running_now = any(
                        (r.start_date.replace(tzinfo=timezone.utc) if r.start_date.tzinfo is None else r.start_date) <= now <= (r.end_date.replace(tzinfo=timezone.utc) if r.end_date.tzinfo is None else r.end_date)
                        for r in active_in_window
                    )
                    if is_running_now:
                        last_used_formatted = f"Active (until {date_str})"
                    else:
                        last_used_formatted = f"Booked (until {date_str})"
                else:
                    last_used_formatted = date_str
            else:
                last_used_formatted = "Never used"
                last_used_date_str = None

            # Primary Application
            if apps_set:
                primary_app = next(iter(apps_set))
            elif "payment" in env_name_lower:
                primary_app = "Payment Gateway Core"
            elif "ash" in env_name_lower:
                primary_app = "AshApp Services"
            elif "akash" in env_name_lower:
                primary_app = "Akash Portal"
            else:
                primary_app = "Core Platform Services"
            primary_bu = next(iter(bu_set)) if bu_set else env_data["owner_team"]

            # Top Phase
            top_phase = max(phase_counts, key=phase_counts.get) if phase_counts else None

            # Avg duration
            avg_duration = round(usage_hours / booking_count, 1) if booking_count > 0 else 0.0

            # Filter check
            if business_unit and business_unit != "ALL" and primary_bu.lower() != business_unit.lower():
                continue
            if project and project != "ALL" and not any(p.lower() == project.lower() for p in proj_set):
                continue
            if application and application != "ALL" and not any(a.lower() == application.lower() for a in apps_set):
                continue
            if tier and tier != "ALL" and env_data["tier"].lower() != tier.lower():
                continue
            if test_phase and test_phase != "ALL" and test_phase not in phase_counts:
                continue
            if category_filter and category_filter != "ALL" and usage_category.lower() != category_filter.lower():
                continue

            item = EnvironmentUsageItem(
                environment_id=env_id,
                environment_name=env_name,
                environment_type=env_data["type"],
                tier=env_data["tier"],
                primary_application=primary_app,
                associated_applications=list(apps_set),
                associated_projects=list(proj_set),
                business_unit=primary_bu,
                usage_category=usage_category,
                booking_count=booking_count,
                total_usage_hours=usage_hours,
                total_usage_days=usage_days,
                last_used_date=last_used_date_str,
                last_used_formatted=last_used_formatted,
                utilization_pct=utilization_pct,
                trend=trend_str,
                trend_pct_change=trend_diff,
                release_count=len(releases_set),
                associated_releases=list(releases_set),
                top_phase=top_phase,
                phase_breakdown=phase_counts,
                average_booking_duration_hours=avg_duration,
                status=env_data["status"],
                is_active=env_data["is_active"],
            )
            environment_usage_list.append(item)

        # 6. Compute Summary KPIs
        freq_count = sum(1 for e in environment_usage_list if e.usage_category == "Frequently Used")
        mod_count = sum(1 for e in environment_usage_list if e.usage_category == "Moderately Used")
        rare_count = sum(1 for e in environment_usage_list if e.usage_category == "Rarely Used")
        never_count = sum(1 for e in environment_usage_list if e.usage_category == "Never Used")

        total_envs = len(environment_usage_list)
        overall_util = round(
            (sum(e.utilization_pct for e in environment_usage_list) / max(1, total_envs)), 1
        ) if total_envs > 0 else 0.0

        sorted_by_util = sorted(environment_usage_list, key=lambda x: x.utilization_pct, reverse=True)
        most_used = sorted_by_util[0] if sorted_by_util else None
        least_used_candidates = [e for e in sorted_by_util if e.utilization_pct > 0]
        least_used = least_used_candidates[-1] if least_used_candidates else (sorted_by_util[-1] if sorted_by_util else None)

        summary_kpis = UsageSummaryKPIs(
            total_environments=total_envs,
            frequently_used_count=freq_count,
            moderately_used_count=mod_count,
            rarely_used_count=rare_count,
            never_used_count=never_count,
            overall_utilization_pct=overall_util,
            total_bookings_count=total_fleet_bookings,
            total_usage_hours=round(total_fleet_hours_booked, 1),
            most_used_environment_name=most_used.environment_name if most_used else None,
            most_used_utilization_pct=most_used.utilization_pct if most_used else 0.0,
            least_used_environment_name=least_used.environment_name if least_used else None,
            least_used_utilization_pct=least_used.utilization_pct if least_used else 0.0,
            unused_environments_count=never_count,
            fleet_usage_trend="Increasing" if sum(e.trend_pct_change for e in environment_usage_list) > 10 else (
                "Decreasing" if sum(e.trend_pct_change for e in environment_usage_list) < -10 else "Stable"
            ),
        )

        # 7. Time Series Monthly Breakdown (e.g., April to September)
        time_series_trend = self._generate_time_series_trend(window_start, window_end, res_records, total_envs)

        # 8. Application & Test Phase Demand Insights
        app_demand_insights = self._generate_application_demand_insights(
            environment_usage_list, res_records, window_start, window_end
        )

        # 9. Intelligent AI Recommendations
        recommendations = self._generate_intelligent_recommendations(
            environment_usage_list, app_demand_insights, period, total_days
        )

        return UsageAnalysisResponse(
            period_type=period,
            start_date=window_start.strftime("%Y-%m-%d"),
            end_date=window_end.strftime("%Y-%m-%d"),
            total_days=total_days,
            summary_kpis=summary_kpis,
            thresholds_applied=thresholds,
            environments=environment_usage_list,
            time_series_trend=time_series_trend,
            application_demand_insights=app_demand_insights,
            recommendations=recommendations,
        )

    def _generate_time_series_trend(
        self, window_start: datetime, window_end: datetime, reservations: List[Reservation], total_envs: int
    ) -> List[TrendPoint]:
        """
        Generate monthly utilization trend points across the selected analysis period.
        """
        points: List[TrendPoint] = []
        curr = window_start.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        # Iterate month by month
        while curr <= window_end:
            # Next month start
            if curr.month == 12:
                next_m = curr.replace(year=curr.year + 1, month=1)
            else:
                next_m = curr.replace(month=curr.month + 1)

            m_start = max(window_start, curr)
            m_end = min(window_end, next_m)

            m_duration_sec = max(1.0, (m_end - m_start).total_seconds())
            m_hours_capacity = (m_duration_sec / 3600.0) * max(1, total_envs)

            # Sum overlap hours in this month
            m_booked_seconds = 0.0
            m_bookings_count = 0

            for r in reservations:
                r_s = r.start_date.replace(tzinfo=timezone.utc) if r.start_date.tzinfo is None else r.start_date
                r_e = r.end_date.replace(tzinfo=timezone.utc) if r.end_date.tzinfo is None else r.end_date

                ov_s = max(m_start, r_s)
                ov_e = min(m_end, r_e)

                if ov_e > ov_s:
                    m_booked_seconds += (ov_e - ov_s).total_seconds()
                    m_bookings_count += 1

            m_hours_booked = m_booked_seconds / 3600.0
            m_util = min(100.0, round((m_hours_booked / max(1.0, m_hours_capacity)) * 100.0, 1))

            points.append(TrendPoint(
                period_label=curr.strftime("%b %Y"),
                month_name=curr.strftime("%B"),
                year=curr.year,
                utilization_pct=m_util,
                booking_count=m_bookings_count,
                hours_booked=round(m_hours_booked, 1),
            ))

            curr = next_m

        return points

    def _generate_application_demand_insights(
        self,
        env_items: List[EnvironmentUsageItem],
        reservations: List[Reservation],
        window_start: datetime,
        window_end: datetime,
    ) -> List[ApplicationDemandInsight]:
        """
        Calculates demand patterns by Application & Phase.
        """
        app_phase_map: Dict[str, Dict[str, Any]] = {}
        months_in_period = max(1.0, (window_end - window_start).days / 30.0)

        # Group bookings by application + phase
        for r in reservations:
            app = (r.application or "General Platform").strip()
            phase = (r.test_phase_name or "SIT").strip()
            key = f"{app}::{phase}"

            if key not in app_phase_map:
                app_phase_map[key] = {
                    "app": app,
                    "phase": phase,
                    "bookings_count": 0,
                }
            app_phase_map[key]["bookings_count"] += 1

        insights: List[ApplicationDemandInsight] = []

        for key, data in app_phase_map.items():
            app = data["app"]
            phase = data["phase"]
            b_count = data["bookings_count"]
            monthly_demand = round(b_count / months_in_period, 1)

            # Count available environments configured for this app/phase
            matching_envs = [
                e for e in env_items
                if app.lower() in [a.lower() for a in e.associated_applications]
                or e.primary_application.lower() == app.lower()
                or phase.lower() in e.environment_type.lower()
            ]
            avail_count = len(matching_envs) if matching_envs else 1

            # Determine demand status
            if monthly_demand > avail_count * 5:
                status = "HIGH_DEMAND"
                msg = f"Demand for {phase} environments ({monthly_demand} bookings/mo) is significantly higher than available capacity ({avail_count} envs)."
            elif monthly_demand > avail_count * 2.5:
                status = "BALANCED"
                msg = f"{phase} testing demand ({monthly_demand} bookings/mo) is well-balanced across {avail_count} active environments."
            else:
                status = "LOW_DEMAND"
                msg = f"{app} {phase} environment utilization is low with {avail_count} available environments."

            insights.append(ApplicationDemandInsight(
                application_name=app,
                phase_name=phase,
                available_environments_count=avail_count,
                total_bookings_in_period=b_count,
                avg_monthly_demand=monthly_demand,
                demand_status=status,
                insight_message=msg,
            ))

        return insights[:8]

    def _generate_intelligent_recommendations(
        self,
        env_items: List[EnvironmentUsageItem],
        demand_insights: List[ApplicationDemandInsight],
        period: str,
        total_days: int,
    ) -> List[UsageRecommendation]:
        """
        Synthesizes statistical analytics into concrete recommendations.
        """
        recs: List[UsageRecommendation] = []

        # 1. Check for Unused / Never Used Environments
        never_used = [e for e in env_items if e.usage_category == "Never Used"]
        for nu in never_used[:3]:
            recs.append(UsageRecommendation(
                id=f"rec-never-{nu.environment_id}",
                category="UNBOOKED",
                severity="WARNING",
                target_environment=nu.environment_name,
                title=f"{nu.environment_name} has zero bookings in {period}",
                message=f"{nu.environment_name} ({nu.environment_type}) has not been booked or utilized during the last {total_days} days despite being online and active.",
                actionable_recommendation="Consider making this environment available for other high-demand test phases (e.g. SIT/QA) or putting it into scheduled sleep mode.",
                impact_score="Cost & Fleet Optimization",
            ))

        # 2. Check for Frequently Used / High Demand Environments
        frequently_used = [e for e in env_items if e.usage_category == "Frequently Used"]
        for fu in frequently_used[:3]:
            recs.append(UsageRecommendation(
                id=f"rec-freq-{fu.environment_id}",
                category="HIGH_DEMAND",
                severity="INFO",
                target_environment=fu.environment_name,
                title=f"{fu.environment_name} is in peak demand ({fu.utilization_pct}% utilization)",
                message=f"{fu.environment_name} has handled {fu.booking_count} bookings and {fu.total_usage_hours} hours of testing across {fu.release_count} releases with an increasing usage trend.",
                actionable_recommendation="High contention detected. Consider provisioning an additional replica or setting up automated time-sharing slots to prevent pipeline delays.",
                impact_score="High Delivery Velocity",
            ))

        # 3. Check for Rarely Used / Underutilized Reassignments
        rarely_used = [e for e in env_items if e.usage_category == "Rarely Used"]
        for ru in rarely_used[:3]:
            recs.append(UsageRecommendation(
                id=f"rec-rare-{ru.environment_id}",
                category="REASSIGNMENT",
                severity="WARNING",
                target_environment=ru.environment_name,
                title=f"{ru.environment_name} has low utilization ({ru.utilization_pct}%)",
                message=f"{ru.environment_name} recorded only {ru.booking_count} booking(s) ({ru.total_usage_hours} hours) in the last {total_days} days.",
                actionable_recommendation=f"Consider reassigning {ru.environment_name} to higher demand applications like Payment Gateway rather than provisioning fresh infrastructure.",
                impact_score="Resource Efficiency",
            ))

        # 4. Fleet-level Demand Recommendations
        high_demand_apps = [d for d in demand_insights if d.demand_status == "HIGH_DEMAND"]
        for hd in high_demand_apps[:2]:
            recs.append(UsageRecommendation(
                id=f"rec-demand-{uuid.uuid4().hex[:6]}",
                category="CAPACITY",
                severity="CRITICAL",
                target_environment=f"{hd.application_name} ({hd.phase_name})",
                title=f"Environment demand is surging for {hd.application_name}",
                message=f"Current demand is {hd.avg_monthly_demand} bookings/month for {hd.phase_name} testing against only {hd.available_environments_count} dedicated environments.",
                actionable_recommendation="Demand for SIT/QA environments exceeds available capacity. Rebalance underutilized DEV/UAT nodes or trigger on-demand environment provisioning.",
                impact_score="Bottleneck Prevention",
            ))

        return recs


usage_analysis_service = UsageAnalysisService()
