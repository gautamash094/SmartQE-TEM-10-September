from datetime import datetime, timezone
from typing import Dict, Any, List
from app.services.diagnosis.base_checker import BaseDiagnosisChecker
from app.schemas.diagnosis import DiagnosisCheckerResult


class ServerInfrastructureChecker(BaseDiagnosisChecker):
    @property
    def name(self) -> str:
        return "Server & Infrastructure Resource Checker"

    @property
    def category(self) -> str:
        return "SERVER"

    async def run_check(self, context: Dict[str, Any]) -> DiagnosisCheckerResult:
        env = context.get("env")
        assets: List[Any] = context.get("assets", [])

        findings = []
        status = "PASSED"

        # Check CPU / Memory / Storage if environment or assets exist
        cpu_usage = getattr(env, "cpu_usage", 0.0) or 0.0
        memory_usage = getattr(env, "memory_usage", 0.0) or 0.0
        storage_usage = getattr(env, "storage_usage", 0.0) or 0.0
        env_status = str(getattr(env, "status", "HEALTHY") or "HEALTHY")

        if env_status in ("DOWN", "CRITICAL"):
            status = "CRITICAL"
            findings.append(f"Environment status is currently marked as {env_status}")
        elif env_status in ("DEGRADED", "WARNING", "MAINTENANCE"):
            status = "WARNING"
            findings.append(f"Environment is in {env_status} operational state")

        if cpu_usage > 90.0:
            status = "CRITICAL"
            findings.append(f"High CPU utilization: {cpu_usage}% (Threshold: 90%)")
        elif cpu_usage > 75.0 and status != "CRITICAL":
            status = "WARNING"
            findings.append(f"Elevated CPU utilization: {cpu_usage}%")

        if memory_usage > 90.0:
            status = "CRITICAL"
            findings.append(f"High Memory utilization: {memory_usage}% (Threshold: 90%)")
        elif memory_usage > 80.0 and status != "CRITICAL":
            status = "WARNING"
            findings.append(f"Elevated Memory utilization: {memory_usage}%")

        if storage_usage > 90.0:
            status = "CRITICAL"
            findings.append(f"High Storage utilization: {storage_usage}%")

        summary = (
            "Server infrastructure resources are healthy and within operational thresholds."
            if status == "PASSED"
            else f"Infrastructure check returned {status} with {len(findings)} alert(s)."
        )

        return DiagnosisCheckerResult(
            checker_name=self.name,
            category=self.category,
            status=status,
            summary=summary,
            details={
                "cpu_usage_pct": cpu_usage,
                "memory_usage_pct": memory_usage,
                "storage_usage_pct": storage_usage,
                "linked_assets_count": len(assets),
                "findings": findings
            },
            timestamp=datetime.now(timezone.utc)
        )
