from abc import ABC, abstractmethod
from typing import Dict, Any
from app.schemas.diagnosis import DiagnosisCheckerResult


class BaseDiagnosisChecker(ABC):
    """
    Abstract Base Class for modular Environment Diagnosis Checkers.
    New checkers (Database schema diff, Application configs, Security compliance)
    can be plugged in simply by subclassing this base class.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Name of the checker."""
        pass

    @property
    @abstractmethod
    def category(self) -> str:
        """Category: SOFTWARE | SERVER | HEALTH | DATABASE | APPLICATION | SECURITY"""
        pass

    @abstractmethod
    async def run_check(self, context: Dict[str, Any]) -> DiagnosisCheckerResult:
        """
        Executes diagnosis check with provided context containing:
        - db: AsyncSession
        - env: Environment object or dict
        - profile: EnvironmentProfile object (optional)
        - assets: List of linked Asset objects
        - health_executions: Latest HealthCheckExecution objects
        """
        pass
