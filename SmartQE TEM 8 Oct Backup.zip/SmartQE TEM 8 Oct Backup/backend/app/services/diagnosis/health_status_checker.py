from datetime import datetime, timezone
from typing import Dict, Any, List
from app.services.diagnosis.base_checker import BaseDiagnosisChecker
from app.schemas.diagnosis import DiagnosisCheckerResult


class HealthStatusChecker(BaseDiagnosisChecker):
    @property
    def name(self) -> str:
        return "Health Check & Probe Integration Checker"

    @property
    def category(self) -> str:
        return "HEALTH"

    async def run_check(self, context: Dict[str, Any]) -> DiagnosisCheckerResult:
        latest_execution = context.get("latest_health_execution")
        health_definitions: List[Any] = context.get("health_definitions", [])

        if not latest_execution:
            return DiagnosisCheckerResult(
                checker_name=self.name,
                category=self.category,
                status="INFO",
                summary="No automated health check runs recorded yet for this environment.",
                details={
                    "total_definitions": len(health_definitions),
                    "last_run": None
                },
                timestamp=datetime.now(timezone.utc)
            )

        overall_status = str(getattr(latest_execution, "overall_status", "UNKNOWN") or "UNKNOWN")
        passed = getattr(latest_execution, "passed_checks", 0) or 0
        failed = getattr(latest_execution, "failed_checks", 0) or 0
        warning = getattr(latest_execution, "warning_checks", 0) or 0
        total = getattr(latest_execution, "total_checks", 0) or (passed + failed + warning)
        score = getattr(latest_execution, "health_score", 100.0) or 100.0

        if overall_status == "CRITICAL" or failed > 0:
            status = "CRITICAL"
            summary = f"Latest health run reported {failed} failing probe(s). Overall health score: {score}%"
        elif overall_status == "WARNING" or warning > 0:
            status = "WARNING"
            summary = f"Latest health run reported {warning} warning probe(s). Overall health score: {score}%"
        else:
            status = "PASSED"
            summary = f"All {passed} active health check probes passed successfully. Health score: {score}%"

        return DiagnosisCheckerResult(
            checker_name=self.name,
            category=self.category,
            status=status,
            summary=summary,
            details={
                "overall_status": overall_status,
                "health_score": score,
                "total_probes": total,
                "passed_probes": passed,
                "failed_probes": failed,
                "warning_probes": warning,
                "executed_at": (
                    latest_execution.started_at.isoformat()
                    if getattr(latest_execution, "started_at", None)
                    else None
                )
            },
            timestamp=datetime.now(timezone.utc)
        )
