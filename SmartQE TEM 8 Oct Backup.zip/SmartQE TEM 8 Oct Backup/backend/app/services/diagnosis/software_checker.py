from datetime import datetime, timezone
from typing import Dict, Any, List
from app.services.diagnosis.base_checker import BaseDiagnosisChecker
from app.schemas.diagnosis import DiagnosisCheckerResult
from app.models.environment_software import SoftwareDiagnosisStatus, EnvironmentSoftware
from app.services.version_comparator import version_comparator
from app.dao.environment_software_dao import environment_software_dao


class SoftwareInventoryChecker(BaseDiagnosisChecker):
    @property
    def name(self) -> str:
        return "Software Inventory & Baseline Checker"

    @property
    def category(self) -> str:
        return "SOFTWARE"

    async def run_check(self, context: Dict[str, Any]) -> DiagnosisCheckerResult:
        db = context.get("db")
        env_id = context.get("env_id")
        software_items: List[EnvironmentSoftware] = context.get("software_items", [])

        if not software_items and db and env_id:
            software_items = await environment_software_dao.get_by_environment_id_or_name(db, env_id)

        total = len(software_items)
        matching = 0
        mismatched = 0
        missing = 0
        outdated = 0
        not_checked = 0

        findings = []

        for item in software_items:
            installed = item.installed_version
            expected = item.expected_version

            if not installed and expected:
                status = SoftwareDiagnosisStatus.MISSING
                missing += 1
                findings.append(f"{item.software_name}: Missing in environment (Expected v{expected})")
            elif not expected and installed:
                status = SoftwareDiagnosisStatus.MATCH
                matching += 1
            elif not installed and not expected:
                status = SoftwareDiagnosisStatus.NOT_CHECKED
                not_checked += 1
            else:
                cmp_res = version_comparator.compare(installed, expected)
                if cmp_res == 0:
                    status = SoftwareDiagnosisStatus.MATCH
                    matching += 1
                elif cmp_res < 0:
                    status = SoftwareDiagnosisStatus.VERSION_MISMATCH
                    mismatched += 1
                    findings.append(f"{item.software_name}: Version mismatch (Installed v{installed} < Expected v{expected})")
                else:
                    status = SoftwareDiagnosisStatus.VERSION_MISMATCH
                    mismatched += 1
                    findings.append(f"{item.software_name}: Version ahead of baseline (Installed v{installed} > Expected v{expected})")

            # Update item status in db if changed
            if db and item.status != status:
                item.status = status
                item.last_checked = datetime.now(timezone.utc)
                item.check_details = f"Diagnosed at {datetime.now(timezone.utc).isoformat()}"

        if db:
            await db.commit()

        # Determine overall category status
        if missing > 0:
            check_status = "CRITICAL"
            summary = f"Detected {missing} missing component(s) and {mismatched} version mismatch(es)."
        elif mismatched > 0:
            check_status = "WARNING"
            summary = f"Detected {mismatched} software version mismatch(es) against expected baseline."
        else:
            check_status = "PASSED"
            summary = f"All {matching} configured software packages match expected baseline versions."

        return DiagnosisCheckerResult(
            checker_name=self.name,
            category=self.category,
            status=check_status,
            summary=summary,
            details={
                "total_software": total,
                "matching": matching,
                "version_mismatch": mismatched,
                "missing": missing,
                "outdated": outdated,
                "findings": findings
            },
            timestamp=datetime.now(timezone.utc)
        )
