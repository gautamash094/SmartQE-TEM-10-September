from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import EntityNotFoundException, DuplicateEntityException, ValidationException
from app.dao.test_phase_dao import test_phase_dao
from app.schemas.test_phase import TestPhaseRead, CustomTestPhaseCreate


class TestPhaseService:
    async def get_all_test_phases(
        self, db: AsyncSession, only_active: bool = True
    ) -> List[TestPhaseRead]:
        phases = await test_phase_dao.get_all_ordered(db, only_active=only_active)
        return [TestPhaseRead.model_validate(p) for p in phases]

    async def get_test_phase_by_id(self, db: AsyncSession, phase_id: str) -> TestPhaseRead:
        phase = await test_phase_dao.get_by_id(db, phase_id)
        if not phase:
            raise EntityNotFoundException("TestPhase", phase_id)
        return TestPhaseRead.model_validate(phase)

    async def create_custom_test_phase(
        self,
        db: AsyncSession,
        phase_in: CustomTestPhaseCreate,
        created_by: str = "User"
    ) -> TestPhaseRead:
        phase_name = phase_in.get_phase_name()
        if not phase_name:
            raise ValidationException("Test Phase Name is required and cannot be empty.")

        existing = await test_phase_dao.get_by_name(db, phase_name)
        if existing:
            raise DuplicateEntityException(f"A test phase named '{phase_name}' already exists.")

        max_order = await test_phase_dao.get_max_display_order(db)
        next_order = max(max_order + 1, 8)

        new_phase_data = {
            "name": phase_name,
            "display_name": phase_name,
            "description": phase_in.description or f"Custom test phase: {phase_name}",
            "color": phase_in.color,
            "is_system": False,
            "is_active": True,
            "display_order": next_order,
            "created_by": created_by,
            "updated_by": created_by,
        }

        created_phase = await test_phase_dao.create(db, new_phase_data)
        return TestPhaseRead.model_validate(created_phase)


test_phase_service = TestPhaseService()


