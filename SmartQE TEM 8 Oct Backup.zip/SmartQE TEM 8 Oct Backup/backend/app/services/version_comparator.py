import re
from typing import Tuple, List, Optional, Union


class VersionComparator:
    """
    Enterprise Version Parser and Semantic Comparator.
    Handles major.minor.patch, major.minor, build numbers, pre-release suffixes,
    and provides semantic comparison (e.g., 3.10.12 < 3.11.5 and 17.0.9 < 17.0.10).
    """

    @staticmethod
    def clean_version(version_str: Optional[str]) -> str:
        if not version_str:
            return ""
        v = str(version_str).strip()
        # Remove leading 'v' or 'V' (e.g., 'v1.2.3' -> '1.2.3')
        if v.lower().startswith("v") and len(v) > 1 and (v[1].isdigit() or v[1] == "."):
            v = v[1:].strip()
        return v

    @classmethod
    def parse_version(cls, version_str: Optional[str]) -> Tuple[List[int], List[str]]:
        """
        Parses a version string into numeric parts and suffix/build tokens.
        Returns: (numeric_parts, extra_tokens)
        Example:
          '17.0.10_312-b07' -> ([17, 0, 10, 312], ['b07'])
          '3.11.5'          -> ([3, 11, 5], [])
          '20.15'           -> ([20, 15], [])
        """
        cleaned = cls.clean_version(version_str)
        if not cleaned:
            return ([], [])

        # Split primary version and build/metadata (+, -, _)
        # Replace non-digit separators that act like delimiters with dots or dashes
        # Match tokens of digits and letters
        tokens = re.split(r"[\.\-_+~]+", cleaned)
        numeric_parts: List[int] = []
        extra_tokens: List[str] = []

        for token in tokens:
            token = token.strip()
            if not token:
                continue
            if token.isdigit():
                numeric_parts.append(int(token))
            else:
                # Token might have mixed digits and letters like '10beta2' or 'rc1'
                sub_parts = re.findall(r"(\d+|[a-zA-Z]+)", token)
                for sp in sub_parts:
                    if sp.isdigit():
                        numeric_parts.append(int(sp))
                    else:
                        extra_tokens.append(sp.lower())

        return (numeric_parts, extra_tokens)

    @classmethod
    def compare(cls, v1: Optional[str], v2: Optional[str]) -> int:
        """
        Compares two version strings.
        Returns:
          -1 if v1 < v2
           0 if v1 == v2 (or semantically equivalent)
           1 if v1 > v2
        """
        if not v1 and not v2:
            return 0
        if not v1:
            return -1
        if not v2:
            return 1

        s1 = cls.clean_version(v1)
        s2 = cls.clean_version(v2)
        if s1 == s2:
            return 0

        nums1, extras1 = cls.parse_version(s1)
        nums2, extras2 = cls.parse_version(s2)

        # Normalize lengths of numeric parts with trailing zeros (e.g., 20.15 == 20.15.0)
        max_len = max(len(nums1), len(nums2))
        padded1 = nums1 + [0] * (max_len - len(nums1))
        padded2 = nums2 + [0] * (max_len - len(nums2))

        for n1, n2 in zip(padded1, padded2):
            if n1 < n2:
                return -1
            elif n1 > n2:
                return 1

        # If numeric parts are identical, check extra tokens (e.g. release suffixes)
        # Typically a release with no extra token (GA) > pre-release (beta, rc)
        if not extras1 and extras2:
            return 1
        if extras1 and not extras2:
            return -1

        if extras1 != extras2:
            return -1 if extras1 < extras2 else 1

        return 0

    @classmethod
    def is_match(cls, v1: Optional[str], v2: Optional[str]) -> bool:
        """Returns True if versions match exactly or are semantically equivalent."""
        if not v1 or not v2:
            return False
        return cls.compare(v1, v2) == 0

    @classmethod
    def classify_diff(cls, source_ver: Optional[str], target_ver: Optional[str]) -> dict:
        """
        Classifies the difference between source and target versions.
        Returns a dict with diff_level, direction, and explanation.
        """
        if not source_ver and not target_ver:
            return {
                "diff_level": "NONE",
                "direction": "IDENTICAL",
                "message": "Both versions are empty"
            }
        if not source_ver and target_ver:
            return {
                "diff_level": "EXTRA",
                "direction": "EXTRA_IN_TARGET",
                "message": f"Installed in target as v{target_ver} but not in source"
            }
        if source_ver and not target_ver:
            return {
                "diff_level": "MISSING",
                "direction": "MISSING_IN_TARGET",
                "message": f"Required v{source_ver} in source but missing in target"
            }

        cmp_val = cls.compare(source_ver, target_ver)
        if cmp_val == 0:
            return {
                "diff_level": "EXACT_MATCH",
                "direction": "IDENTICAL",
                "message": "Versions match exactly"
            }

        nums_src, _ = cls.parse_version(source_ver)
        nums_tgt, _ = cls.parse_version(target_ver)

        major_src = nums_src[0] if len(nums_src) > 0 else 0
        major_tgt = nums_tgt[0] if len(nums_tgt) > 0 else 0

        minor_src = nums_src[1] if len(nums_src) > 1 else 0
        minor_tgt = nums_tgt[1] if len(nums_tgt) > 1 else 0

        patch_src = nums_src[2] if len(nums_src) > 2 else 0
        patch_tgt = nums_tgt[2] if len(nums_tgt) > 2 else 0

        direction = "TARGET_BEHIND" if cmp_val > 0 else "TARGET_AHEAD"

        if major_src != major_tgt:
            diff_level = "MAJOR_MISMATCH"
            msg = f"Major version mismatch: Source has v{source_ver} while Target has v{target_ver}"
        elif minor_src != minor_tgt:
            diff_level = "MINOR_MISMATCH"
            msg = f"Minor version mismatch: Source has v{source_ver} while Target has v{target_ver}"
        elif patch_src != patch_tgt:
            diff_level = "PATCH_MISMATCH"
            msg = f"Patch version difference: Source has v{source_ver} while Target has v{target_ver}"
        else:
            diff_level = "BUILD_MISMATCH"
            msg = f"Build/suffix difference: Source has v{source_ver} while Target has v{target_ver}"

        return {
            "diff_level": diff_level,
            "direction": direction,
            "message": msg
        }


version_comparator = VersionComparator()
