import re
from datetime import datetime, timezone
from typing import List, Dict, Optional, Tuple, Any
from sqlalchemy import select, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.dao.environment_dao import environment_dao
from app.dao.environment_software_dao import environment_software_dao
from app.models.environment import Environment
from app.models.environment_profile import EnvironmentProfile
from app.models.asset import Asset
from app.models.environment_software import EnvironmentSoftware
from app.schemas.comparison import (
    EnvironmentComparisonRequest,
    EnvironmentComparisonResponse,
    ComparisonEnvironmentMeta,
    ComparisonSummary,
    ComparisonDiffItem,
    ComparisonRecommendation,
    ServerComparisonDiff
)
from app.services.version_comparator import version_comparator
from app.services.diagnosis.diagnosis_service import diagnosis_service


class EnvironmentComparator:
    """
    Enterprise Environment Comparison Engine.
    Performs normalized software matrix matching, semantic version difference analysis,
    drift detection, consistency scoring, and automated remediation generation.
    """

    @staticmethod
    def normalize_name(name: str) -> str:
        """Normalizes software names for comparison (e.g., 'Node.js' -> 'nodejs', 'PostgreSQL' -> 'postgresql')."""
        if not name:
            return ""
        return re.sub(r"[^a-zA-Z0-9]", "", name).lower()

    async def resolve_env_meta(
        self, db: AsyncSession, env_id_or_name: str
    ) -> Tuple[Optional[Environment], ComparisonEnvironmentMeta]:
        meta = await diagnosis_service.resolve_full_metadata(db, env_id_or_name)
        comp_meta = ComparisonEnvironmentMeta(
            id=meta["env_id"],
            name=meta["env_name"],
            tier=meta["env_tier"],
            status=meta["env_status"],
            business_unit=meta["bu"],
            project=meta["project"],
            application=meta["application"],
            server_host=meta["server_host"],
            ip_address=meta["ip_address"]
        )
        return meta["env"], comp_meta

    async def get_software_dict(
        self, db: AsyncSession, env_id: str, env_name: str
    ) -> Dict[str, EnvironmentSoftware]:
        items = await environment_software_dao.get_by_environment_id_or_name(db, env_id)
        if not items and env_name != env_id:
            items = await environment_software_dao.get_by_environment_id_or_name(db, env_name)

        if not items:
            await diagnosis_service.diagnose_environment(db, env_id)
            items = await environment_software_dao.get_by_environment_id_or_name(db, env_id)

        result: Dict[str, EnvironmentSoftware] = {}
        for item in items:
            key = self.normalize_name(item.software_name)
            result[key] = item
        return result

    def calculate_consistency_score(
        self, matching: int, version_mismatches: int, missing: int, extra: int, diff_items: List[ComparisonDiffItem]
    ) -> float:
        """
        Calculates configurable weighted consistency score between 0.0% and 100.0%.
        Weights:
          - MATCH: 100%
          - PATCH_MISMATCH: 85%
          - MINOR_MISMATCH: 50%
          - MAJOR_MISMATCH: 20%
          - EXTRA: 65% (extra software penalty)
          - MISSING: 0% (missing software penalty)
        """
        total = matching + version_mismatches + missing + extra
        if total == 0:
            return 100.0

        score_points = 0.0
        for item in diff_items:
            if item.status == "MATCH":
                score_points += 1.0
            elif item.status == "VERSION_MISMATCH":
                if item.difference_type == "PATCH_MISMATCH":
                    score_points += 0.85
                elif item.difference_type == "MINOR_MISMATCH":
                    score_points += 0.50
                elif item.difference_type == "MAJOR_MISMATCH":
                    score_points += 0.20
                else:
                    score_points += 0.50
            elif item.status == "EXTRA":
                score_points += 0.65
            elif item.status == "MISSING":
                score_points += 0.0

        raw_score = (score_points / total) * 100.0
        return round(max(0.0, min(100.0, raw_score)), 1)

    def generate_recommendations(
        self,
        source_meta: ComparisonEnvironmentMeta,
        target_meta: ComparisonEnvironmentMeta,
        diff_items: List[ComparisonDiffItem]
    ) -> List[ComparisonRecommendation]:
        recs: List[ComparisonRecommendation] = []

        for item in diff_items:
            s_name = source_meta.name
            t_name = target_meta.name
            sw = item.software

            if item.status == "MISSING":
                recs.append(
                    ComparisonRecommendation(
                        severity="CRITICAL",
                        category="SOFTWARE",
                        software=sw,
                        title=f"{sw} is missing in {t_name}",
                        description=f"{sw} (v{item.source_version}) is installed in {s_name} but missing from {t_name}.",
                        recommendation=f"Install {sw} v{item.source_version} in {t_name} before executing the release test cycle.",
                        remediation_cmd=f"tem-agent install {sw.lower()} --version {item.source_version} --env {t_name}"
                    )
                )
            elif item.status == "VERSION_MISMATCH":
                diff_type = item.difference_type
                severity = "CRITICAL" if diff_type == "MAJOR_MISMATCH" else "WARNING"
                recs.append(
                    ComparisonRecommendation(
                        severity=severity,
                        category="VERSION",
                        software=sw,
                        title=f"{sw} version differs between {s_name} and {t_name}",
                        description=f"{s_name} runs v{item.source_version} while {t_name} runs v{item.target_version} ({item.details}).",
                        recommendation=f"Align the {t_name} {sw} version to v{item.source_version} to match {s_name} environment baseline.",
                        remediation_cmd=f"tem-agent update {sw.lower()} --target-version {item.source_version} --env {t_name}"
                    )
                )
            elif item.status == "EXTRA":
                recs.append(
                    ComparisonRecommendation(
                        severity="INFO",
                        category="CONFIGURATION",
                        software=sw,
                        title=f"Extra software present in {t_name}: {sw}",
                        description=f"{sw} (v{item.target_version}) is present in {t_name} but not configured in {s_name}.",
                        recommendation=f"Verify if {sw} is an intentional component of {t_name} or cleanup unused packages.",
                        remediation_cmd=f"tem-agent verify --package {sw.lower()} --env {t_name}"
                    )
                )

        # Sort recommendations: CRITICAL first, then WARNING, then INFO
        order = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
        recs.sort(key=lambda r: order.get(r.severity, 3))
        return recs

    async def compare_environments(
        self, db: AsyncSession, req: EnvironmentComparisonRequest
    ) -> EnvironmentComparisonResponse:
        # 1. Resolve source and target metadata
        src_env, src_meta = await self.resolve_env_meta(db, req.source_environment_id)
        tgt_env, tgt_meta = await self.resolve_env_meta(db, req.target_environment_id)

        # 2. Get software dictionaries
        src_soft_dict = await self.get_software_dict(db, src_meta.id, src_meta.name)
        tgt_soft_dict = await self.get_software_dict(db, tgt_meta.id, tgt_meta.name)

        # Combine all unique software keys
        all_keys = sorted(list(set(list(src_soft_dict.keys()) + list(tgt_soft_dict.keys()))))

        diff_items: List[ComparisonDiffItem] = []
        matching_count = 0
        mismatch_count = 0
        missing_count = 0
        extra_count = 0
        outdated_count = 0

        for key in all_keys:
            src_item = src_soft_dict.get(key)
            tgt_item = tgt_soft_dict.get(key)

            sw_name = src_item.software_name if src_item else (tgt_item.software_name if tgt_item else key.title())
            category = (
                str(src_item.category.value if hasattr(src_item.category, "value") else src_item.category)
                if src_item
                else (
                    str(tgt_item.category.value if hasattr(tgt_item.category, "value") else tgt_item.category)
                    if tgt_item
                    else "RUNTIME"
                )
            )
            src_ver = src_item.installed_version if src_item else None
            tgt_ver = tgt_item.installed_version if tgt_item else None
            src_port = src_item.port if src_item else None
            tgt_port = tgt_item.port if tgt_item else None

            # Compare logic
            if src_ver and not tgt_ver:
                status = "MISSING"
                diff_type = "MISSING_IN_TARGET"
                direction = "MISSING_IN_TARGET"
                details = f"Software '{sw_name}' is installed in {src_meta.name} (v{src_ver}) but missing from {tgt_meta.name}."
                missing_count += 1
            elif not src_ver and tgt_ver:
                status = "EXTRA"
                diff_type = "EXTRA_IN_TARGET"
                direction = "EXTRA_IN_TARGET"
                details = f"Software '{sw_name}' (v{tgt_ver}) is only installed in {tgt_meta.name}."
                extra_count += 1
            else:
                # Both have versions
                diff_info = version_comparator.classify_diff(src_ver, tgt_ver)
                diff_level = diff_info["diff_level"]
                direction = diff_info["direction"]

                if diff_level == "EXACT_MATCH":
                    status = "MATCH"
                    diff_type = "EXACT_MATCH"
                    details = "Installed versions match exactly."
                    matching_count += 1
                else:
                    status = "VERSION_MISMATCH"
                    diff_type = diff_level
                    details = diff_info["message"]
                    mismatch_count += 1
                    if direction == "TARGET_BEHIND":
                        outdated_count += 1

            diff_items.append(
                ComparisonDiffItem(
                    software=sw_name,
                    category=category,
                    source_version=src_ver,
                    target_version=tgt_ver,
                    status=status,
                    difference_type=diff_type,
                    direction=direction,
                    details=details,
                    source_port=src_port,
                    target_port=tgt_port
                )
            )

        # 3. Server Specs & Infrastructure Comparison if requested
        server_diffs: List[ServerComparisonDiff] = []
        if req.include_server_check:
            # Environment Tier
            server_diffs.append(
                ServerComparisonDiff(
                    attribute="Environment Tier",
                    source_value=src_meta.tier,
                    target_value=tgt_meta.tier,
                    status="MATCH" if src_meta.tier.lower() == tgt_meta.tier.lower() else "MISMATCH",
                    details=f"Source: {src_meta.tier} vs Target: {tgt_meta.tier}"
                )
            )
            # Environment Status
            server_diffs.append(
                ServerComparisonDiff(
                    attribute="Operational Status",
                    source_value=src_meta.status,
                    target_value=tgt_meta.status,
                    status="MATCH" if src_meta.status.lower() == tgt_meta.status.lower() else "MISMATCH",
                    details=f"Source: {src_meta.status} vs Target: {tgt_meta.status}"
                )
            )
            # Business Unit
            server_diffs.append(
                ServerComparisonDiff(
                    attribute="Business Unit",
                    source_value=src_meta.business_unit,
                    target_value=tgt_meta.business_unit,
                    status="MATCH" if (src_meta.business_unit or "").lower() == (tgt_meta.business_unit or "").lower() else "MISMATCH",
                    details=f"Source: {src_meta.business_unit} vs Target: {tgt_meta.business_unit}"
                )
            )
            # Primary Host
            server_diffs.append(
                ServerComparisonDiff(
                    attribute="Server Hostname",
                    source_value=src_meta.server_host,
                    target_value=tgt_meta.server_host,
                    status="MATCH" if src_meta.server_host == tgt_meta.server_host else "MISMATCH",
                    details=f"Source: {src_meta.server_host} vs Target: {tgt_meta.server_host}"
                )
            )

            # CPU / Memory / Storage utilization if environment instances exist
            if src_env and tgt_env:
                src_cpu = getattr(src_env, "cpu_usage", 0.0) or 0.0
                tgt_cpu = getattr(tgt_env, "cpu_usage", 0.0) or 0.0
                server_diffs.append(
                    ServerComparisonDiff(
                        attribute="CPU Utilization (%)",
                        source_value=f"{src_cpu}%",
                        target_value=f"{tgt_cpu}%",
                        status="MATCH" if abs(src_cpu - tgt_cpu) < 25.0 else "MISMATCH",
                        details=f"Difference: {round(abs(src_cpu - tgt_cpu), 1)}%"
                    )
                )
                src_mem = getattr(src_env, "memory_usage", 0.0) or 0.0
                tgt_mem = getattr(tgt_env, "memory_usage", 0.0) or 0.0
                server_diffs.append(
                    ServerComparisonDiff(
                        attribute="Memory Utilization (%)",
                        source_value=f"{src_mem}%",
                        target_value=f"{tgt_mem}%",
                        status="MATCH" if abs(src_mem - tgt_mem) < 25.0 else "MISMATCH",
                        details=f"Difference: {round(abs(src_mem - tgt_mem), 1)}%"
                    )
                )

        # 4. Consistency Score
        consistency_score = self.calculate_consistency_score(
            matching=matching_count,
            version_mismatches=mismatch_count,
            missing=missing_count,
            extra=extra_count,
            diff_items=diff_items
        )

        # 5. Recommendations
        recommendations = self.generate_recommendations(src_meta, tgt_meta, diff_items)

        # 6. Build Summary
        summary = ComparisonSummary(
            total_software=len(diff_items),
            matching=matching_count,
            version_mismatch=mismatch_count,
            missing=missing_count,
            extra=extra_count,
            outdated=outdated_count
        )

        return EnvironmentComparisonResponse(
            source_environment=src_meta,
            target_environment=tgt_meta,
            consistency_score=consistency_score,
            summary=summary,
            comparison=diff_items,
            server_comparison=server_diffs,
            recommendations=recommendations,
            compared_at=datetime.now(timezone.utc)
        )


environment_comparator = EnvironmentComparator()
