import asyncio
import time
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.logging import logger
from app.models.health_check import (
    HealthCheckDefinition, HealthCheckExecution, HealthCheckResult,
    HealthCheckType, CheckCriticality, HealthStatus
)
from app.models.environment import Environment, EnvironmentStatus
from app.models.environment_profile import EnvironmentProfile
from app.models.incident import Incident, IncidentStatus, IncidentSeverity
from app.models.runbook import Runbook, RunbookStatus
from app.dao.health_check_dao import health_check_dao
from app.services.checkers import get_checker_for_type, CheckResult
from app.services.auto_heal_service import auto_heal_service


class HealthCheckService:
    """Orchestration service for asynchronous multi-tier health checks."""

    async def execute_environment_health_check(
        self,
        db: AsyncSession,
        environment_id: str,
        triggered_by: str = "SYSTEM",
        trigger_type: str = "MANUAL",
        auto_heal_if_critical: bool = True,
        check_definition_ids: Optional[List[str]] = None
    ) -> HealthCheckExecution:
        start_overall_time = time.perf_counter()

        # 1. Look up Environment
        env_result = await db.execute(select(Environment).where(Environment.id == environment_id))
        environment = env_result.scalars().first()
        env_name = environment.name if environment else f"Environment-{environment_id[:8]}"

        # 2. Get Health Check Definitions
        definitions = await health_check_dao.get_definitions_by_environment(db, environment_id, enabled_only=True)
        if check_definition_ids:
            definitions = [d for d in definitions if d.id in check_definition_ids]

        # If no definitions are configured yet, bootstrap default 5-check suite
        if not definitions:
            definitions = await self._bootstrap_default_definitions(db, environment_id, env_name)

        # 3. Create Execution Record
        execution = HealthCheckExecution(
            environment_id=environment_id,
            environment_name=env_name,
            overall_status=HealthStatus.RUNNING,
            health_score=0.0,
            triggered_by=triggered_by,
            trigger_type=trigger_type,
            started_at=datetime.now(timezone.utc),
            total_checks=len(definitions)
        )
        execution = await health_check_dao.create_execution(db, execution)

        # 4. Asynchronously Execute All Probes Concurrently
        tasks = [self._execute_single_probe(defn) for defn in definitions]
        probe_outputs: List[Tuple[HealthCheckDefinition, CheckResult]] = await asyncio.gather(*tasks)

        # 5. Evaluate Results, Critical Blockers & Weighted Scores
        passed_count = 0
        failed_count = 0
        warning_count = 0
        has_critical_failure = False
        has_warning = False

        total_weight = sum(defn.weight for defn in definitions) or 1
        weighted_earned = 0.0
        result_entities: List[HealthCheckResult] = []

        for defn, res in probe_outputs:
            if res.status == HealthStatus.HEALTHY:
                passed_count += 1
                weighted_earned += defn.weight * 1.0
            elif res.status == HealthStatus.WARNING:
                warning_count += 1
                has_warning = True
                weighted_earned += defn.weight * 0.5
            else:  # CRITICAL / UNKNOWN / FAILED
                failed_count += 1
                if defn.criticality == CheckCriticality.CRITICAL:
                    has_critical_failure = True
                else:
                    has_warning = True

            result_entity = HealthCheckResult(
                execution_id=execution.id,
                check_definition_id=defn.id,
                check_name=defn.name,
                check_type=defn.check_type,
                criticality=defn.criticality,
                target=defn.target_url or (f"{defn.target_host}:{defn.target_port}" if defn.target_host else defn.target_host),
                status=res.status,
                response_time_ms=res.response_time_ms,
                output_message=res.output_message,
                error_details=res.error_details,
                executed_at=datetime.now(timezone.utc)
            )
            result_entities.append(result_entity)

        # 6. Calculate Final Health Score & Status
        raw_score = round((weighted_earned / total_weight) * 100, 1)
        if has_critical_failure:
            final_status = HealthStatus.CRITICAL
            final_score = min(raw_score, 49.0)  # Critical blocker cap
            summary_msg = f"Critical Failure Detected: {failed_count} check(s) failed. Immediate remediation required."
        elif has_warning or failed_count > 0:
            final_status = HealthStatus.WARNING
            final_score = min(raw_score, 85.0)
            summary_msg = f"Environment Degraded: {warning_count} warning(s), {failed_count} minor failure(s)."
        else:
            final_status = HealthStatus.HEALTHY
            final_score = max(raw_score, 100.0)
            summary_msg = f"Environment Healthy: All {passed_count} check(s) passed successfully."

        duration_ms = max(1, int((time.perf_counter() - start_overall_time) * 1000))

        # 7. Persist Results & Update Execution
        await health_check_dao.save_results(db, result_entities)

        execution.overall_status = final_status
        execution.health_score = final_score
        execution.completed_at = datetime.now(timezone.utc)
        execution.duration_ms = duration_ms
        execution.passed_checks = passed_count
        execution.failed_checks = failed_count
        execution.warning_checks = warning_count
        execution.summary_message = summary_msg

        # 8. Sync Environment State
        if environment:
            if final_status == HealthStatus.HEALTHY:
                environment.status = EnvironmentStatus.HEALTHY
                environment.uptime = 99.9
            elif final_status == HealthStatus.WARNING:
                environment.status = EnvironmentStatus.DEGRADED
                environment.uptime = 94.5
            else:
                environment.status = EnvironmentStatus.DOWN
                environment.uptime = 82.0

        # Also sync EnvironmentProfile if present
        prof_res = await db.execute(select(EnvironmentProfile).where(EnvironmentProfile.id == environment_id))
        env_profile = prof_res.scalars().first()
        if env_profile:
            env_profile.status = environment.status if environment else EnvironmentStatus.HEALTHY

        # 9. Auto-Heal & Incident Deduplication Hook
        if has_critical_failure and auto_heal_if_critical:
            auto_healed = await self._attempt_auto_heal(db, environment_id, env_name, definitions, probe_outputs, execution.id)
            execution.auto_heal_triggered = auto_healed
            
            # If auto-heal could not recover or requires approval, manage incident deduplication
            if not auto_healed:
                incident_id = await self._handle_incident_deduplication(db, environment_id, env_name, execution.id, summary_msg)
                execution.linked_incident_id = incident_id


        await health_check_dao.update_execution(db, execution)
        return execution

    async def _execute_single_probe(self, defn: HealthCheckDefinition) -> Tuple[HealthCheckDefinition, CheckResult]:
        checker = get_checker_for_type(defn.check_type)
        target_config = {
            "target_host": defn.target_host,
            "target_port": defn.target_port,
            "target_url": defn.target_url,
            "http_method": defn.http_method,
            "expected_http_status": defn.expected_http_status,
            "expected_response_substring": defn.expected_response_substring,
            "timeout_seconds": defn.timeout_seconds,
        }

        # First attempt
        res = await checker.check(target_config)
        
        # Retry loop if failed and retries configured
        retries_left = defn.retry_count or 0
        while res.status == HealthStatus.CRITICAL and retries_left > 0:
            await asyncio.sleep(defn.retry_interval_seconds or 1.0)
            res = await checker.check(target_config)
            retries_left -= 1

        return (defn, res)

    async def _bootstrap_default_definitions(
        self, db: AsyncSession, environment_id: str, env_name: str
    ) -> List[HealthCheckDefinition]:
        """Creates baseline 5-check suite for environment if none exist."""
        defaults = [
            HealthCheckDefinition(
                name="Server Reachability (Host Ping)",
                check_type=HealthCheckType.PING,
                environment_id=environment_id,
                environment_name=env_name,
                target_host="127.0.0.1",
                timeout_seconds=3.0,
                criticality=CheckCriticality.CRITICAL,
                weight=20,
                is_enabled=True
            ),
            HealthCheckDefinition(
                name="Application Port Check (8000)",
                check_type=HealthCheckType.TCP_PORT,
                environment_id=environment_id,
                environment_name=env_name,
                target_host="127.0.0.1",
                target_port=8000,
                timeout_seconds=3.0,
                criticality=CheckCriticality.CRITICAL,
                weight=25,
                is_enabled=True
            ),
            HealthCheckDefinition(
                name="Application Health Endpoint (/api/v1/health)",
                check_type=HealthCheckType.HTTP,
                environment_id=environment_id,
                environment_name=env_name,
                target_url="http://127.0.0.1:8000/api/v1/health",
                http_method="GET",
                expected_http_status=200,
                timeout_seconds=5.0,
                criticality=CheckCriticality.CRITICAL,
                weight=30,
                is_enabled=True,
                auto_heal_enabled=True
            ),
            HealthCheckDefinition(
                name="Database Connectivity & Query Probe",
                check_type=HealthCheckType.DATABASE,
                environment_id=environment_id,
                environment_name=env_name,
                target_host="127.0.0.1",
                target_port=5432,
                timeout_seconds=5.0,
                criticality=CheckCriticality.CRITICAL,
                weight=25,
                is_enabled=True
            ),
        ]
        db.add_all(defaults)
        await db.commit()
        for d in defaults:
            await db.refresh(d)
        return defaults

    async def _attempt_auto_heal(
        self,
        db: AsyncSession,
        environment_id: str,
        env_name: str,
        definitions: List[HealthCheckDefinition],
        probe_outputs: List[Tuple[HealthCheckDefinition, CheckResult]],
        execution_id: str
    ) -> bool:
        """Invokes the Auto-Heal engine with closed-loop validation."""
        try:
            failed_definitions = [
                defn for defn, res in probe_outputs if res.status == HealthStatus.CRITICAL
            ]
            if not failed_definitions:
                return False

            return await auto_heal_service.process_health_failure(
                db, environment_id, env_name, failed_definitions, probe_outputs, execution_id
            )
        except Exception as e:
            logger.error(f"Auto-Heal Engine execution error: {str(e)}")
            return False


    async def _handle_incident_deduplication(
        self,
        db: AsyncSession,
        environment_id: str,
        env_name: str,
        execution_id: str,
        summary_msg: str
    ) -> Optional[str]:
        """Checks for existing open incident or creates a new deduplicated ticket."""
        try:
            q = select(Incident).where(
                and_(
                    Incident.environment_id == environment_id,
                    Incident.status.in_([IncidentStatus.OPEN, IncidentStatus.INVESTIGATING])
                )
            )
            res = await db.execute(q)
            existing_incident = res.scalars().first()
            if existing_incident:
                existing_incident.description = f"{existing_incident.description}\n[Health Check {execution_id}] {summary_msg}"
                await db.commit()
                return existing_incident.incident_code

            # Generate new Incident
            inc_code = f"INC-{int(time.time()) % 100000}"
            new_inc = Incident(
                incident_code=inc_code,
                title=f"Health Check Failure: {env_name} is DOWN/CRITICAL",
                severity=IncidentSeverity.SEV2,
                environment_id=environment_id,
                environment_name=env_name,
                assignee="TEM Ops Team",
                status=IncidentStatus.OPEN,
                opened_at=datetime.now(timezone.utc),
                description=f"Automated health check execution #{execution_id} failed.\nDetails: {summary_msg}"
            )
            db.add(new_inc)
            await db.commit()
            return inc_code
        except Exception as e:
            logger.error(f"Incident integration error: {str(e)}")
            return None

    async def get_latest_summary(
        self, db: AsyncSession, environment_id: str
    ) -> Dict[str, Any]:
        """Returns consolidated health summary for environment with tier breakdown."""
        env_res = await db.execute(select(Environment).where(Environment.id == environment_id))
        env = env_res.scalars().first()
        env_name = env.name if env else environment_id

        latest_exec = await health_check_dao.get_latest_execution_for_env(db, environment_id)
        if not latest_exec:
            return {
                "environment_id": environment_id,
                "environment_name": env_name,
                "overall_status": HealthStatus.NOT_CHECKED,
                "health_score": 0.0,
                "last_checked_at": None,
                "last_execution_id": None,
                "tier_summaries": [],
                "latest_results": []
            }

        # Calculate Tier Breakdown
        tier_map = {
            "Server": {"status": HealthStatus.HEALTHY, "passed": 0, "total": 0, "latencies": []},
            "Database": {"status": HealthStatus.HEALTHY, "passed": 0, "total": 0, "latencies": []},
            "Application": {"status": HealthStatus.HEALTHY, "passed": 0, "total": 0, "latencies": []},
            "Network": {"status": HealthStatus.HEALTHY, "passed": 0, "total": 0, "latencies": []},
        }

        for r in latest_exec.results:
            cat = "Application"
            if r.check_type in [HealthCheckType.PING]:
                cat = "Server"
            elif r.check_type in [HealthCheckType.DATABASE]:
                cat = "Database"
            elif r.check_type in [HealthCheckType.TCP_PORT]:
                cat = "Network"

            tier = tier_map[cat]
            tier["total"] += 1
            tier["latencies"].append(r.response_time_ms)
            if r.status == HealthStatus.HEALTHY:
                tier["passed"] += 1
            elif r.status == HealthStatus.CRITICAL:
                tier["status"] = HealthStatus.CRITICAL
            elif r.status == HealthStatus.WARNING and tier["status"] != HealthStatus.CRITICAL:
                tier["status"] = HealthStatus.WARNING

        tier_summaries = []
        for name, data in tier_map.items():
            if data["total"] > 0:
                avg_lat = int(sum(data["latencies"]) / len(data["latencies"])) if data["latencies"] else 0
                tier_summaries.append({
                    "tier_name": name,
                    "status": data["status"],
                    "passed": data["passed"],
                    "total": data["total"],
                    "avg_latency_ms": avg_lat
                })

        return {
            "environment_id": environment_id,
            "environment_name": env_name,
            "overall_status": latest_exec.overall_status,
            "health_score": latest_exec.health_score,
            "last_checked_at": latest_exec.completed_at or latest_exec.started_at,
            "last_execution_id": latest_exec.id,
            "tier_summaries": tier_summaries,
            "latest_results": latest_exec.results
        }


health_check_service = HealthCheckService()
