from abc import ABC, abstractmethod
from typing import Optional, NamedTuple
from app.models.health_check import HealthStatus


class CheckResult(NamedTuple):
    status: HealthStatus
    response_time_ms: int
    output_message: str
    error_details: Optional[str] = None


class BaseHealthChecker(ABC):
    """Abstract Base Class for all asynchronous health check adapters."""

    @abstractmethod
    async def check(self, target_config: dict) -> CheckResult:
        """
        Executes probe asynchronously against target configuration.
        Returns CheckResult with status, latency, output, and error.
        """
        pass
