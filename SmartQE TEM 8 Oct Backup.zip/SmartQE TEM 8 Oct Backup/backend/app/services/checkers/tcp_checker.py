import asyncio
import time
from app.models.health_check import HealthStatus
from app.services.checkers.base_checker import BaseHealthChecker, CheckResult


class TcpPortChecker(BaseHealthChecker):
    """TCP Port Reachability & Handshake Checker."""

    async def check(self, target_config: dict) -> CheckResult:
        host = target_config.get("target_host") or "127.0.0.1"
        port = target_config.get("target_port") or 8000
        timeout_seconds = float(target_config.get("timeout_seconds") or 3.0)

        # Map localhost aliases
        if host in ["localhost", "0.0.0.0"]:
            host = "127.0.0.1"

        start_time = time.perf_counter()
        try:
            conn = asyncio.open_connection(host, int(port))
            reader, writer = await asyncio.wait_for(conn, timeout=timeout_seconds)
            elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
            
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

            return CheckResult(
                status=HealthStatus.HEALTHY,
                response_time_ms=elapsed_ms,
                output_message=f"TCP Port {port} on '{host}' is OPEN and reachable ({elapsed_ms}ms)"
            )
        except asyncio.TimeoutError:
            elapsed_ms = int(timeout_seconds * 1000)
            return CheckResult(
                status=HealthStatus.CRITICAL,
                response_time_ms=elapsed_ms,
                output_message=f"Connection to TCP Port {port} on '{host}' timed out after {timeout_seconds}s",
                error_details=f"Socket connection timeout ({timeout_seconds}s)"
            )
        except ConnectionRefusedError:
            elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
            return CheckResult(
                status=HealthStatus.CRITICAL,
                response_time_ms=elapsed_ms,
                output_message=f"Connection refused on {host}:{port}. Service may be down or not listening.",
                error_details="ConnectionRefusedError: Port is closed or blocked."
            )
        except Exception as e:
            elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
            return CheckResult(
                status=HealthStatus.CRITICAL,
                response_time_ms=elapsed_ms,
                output_message=f"TCP probe failed for {host}:{port}: {str(e)}",
                error_details=str(e)
            )
