import asyncio
import time
from sqlalchemy import text
from app.database.session import AsyncSessionLocal
from app.models.health_check import HealthStatus
from app.services.checkers.base_checker import BaseHealthChecker, CheckResult


class DatabaseChecker(BaseHealthChecker):
    """Database Connectivity & Synthetic Query Execution Checker."""

    async def check(self, target_config: dict) -> CheckResult:
        host = target_config.get("target_host") or "127.0.0.1"
        port = int(target_config.get("target_port") or 5432)
        timeout_seconds = float(target_config.get("timeout_seconds") or 5.0)

        # Normalize localhost
        if host in ["localhost", "0.0.0.0"]:
            host = "127.0.0.1"

        start_time = time.perf_counter()

        # If it's testing primary app DB connection or local test DB
        if host in ["127.0.0.1", "db", "postgres"]:
            try:
                # Test synthetic SELECT 1 via SQLAlchemy session with timeout
                async with asyncio.timeout(timeout_seconds):
                    async with AsyncSessionLocal() as session:
                        result = await session.execute(text("SELECT 1"))
                        row = result.scalar()
                        elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
                        
                        return CheckResult(
                            status=HealthStatus.HEALTHY,
                            response_time_ms=elapsed_ms,
                            output_message=f"Database connected successfully. Query 'SELECT 1' returned '{row}' ({elapsed_ms}ms)"
                        )
            except asyncio.TimeoutError:
                elapsed_ms = int(timeout_seconds * 1000)
                return CheckResult(
                    status=HealthStatus.CRITICAL,
                    response_time_ms=elapsed_ms,
                    output_message=f"Database query timed out after {timeout_seconds}s",
                    error_details="DB Timeout: Session query hung or connection pool exhausted."
                )
            except Exception as e:
                # Fallback to TCP socket check on DB port
                try:
                    conn = asyncio.open_connection(host, port)
                    _, writer = await asyncio.wait_for(conn, timeout=timeout_seconds)
                    writer.close()
                    await writer.wait_closed()
                    elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
                    return CheckResult(
                        status=HealthStatus.HEALTHY,
                        response_time_ms=elapsed_ms,
                        output_message=f"Database TCP socket on {host}:{port} is reachable ({elapsed_ms}ms)"
                    )
                except Exception as ex:
                    elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
                    return CheckResult(
                        status=HealthStatus.CRITICAL,
                        response_time_ms=elapsed_ms,
                        output_message=f"Database connection failed on {host}:{port}: {str(e)}",
                        error_details=f"DB Error: {str(e)} | Socket Error: {str(ex)}"
                    )

        # For remote target DBs, perform socket verification
        try:
            conn = asyncio.open_connection(host, port)
            _, writer = await asyncio.wait_for(conn, timeout=timeout_seconds)
            writer.close()
            await writer.wait_closed()
            elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
            return CheckResult(
                status=HealthStatus.HEALTHY,
                response_time_ms=elapsed_ms,
                output_message=f"Database port {port} on '{host}' is open and accepting connections ({elapsed_ms}ms)"
            )
        except Exception as e:
            elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
            return CheckResult(
                status=HealthStatus.CRITICAL,
                response_time_ms=elapsed_ms,
                output_message=f"Failed to connect to Database {host}:{port}: {str(e)}",
                error_details=str(e)
            )
