import httpx
import time
from app.models.health_check import HealthStatus
from app.services.checkers.base_checker import BaseHealthChecker, CheckResult


class HttpChecker(BaseHealthChecker):
    """HTTP/HTTPS Synthetic Endpoint Checker."""

    async def check(self, target_config: dict) -> CheckResult:
        url = target_config.get("target_url") or target_config.get("target") or "http://127.0.0.1:8000/api/v1/health"
        http_method = (target_config.get("http_method") or "GET").upper()
        expected_status = int(target_config.get("expected_http_status") or 200)
        expected_substring = target_config.get("expected_response_substring")
        timeout_seconds = float(target_config.get("timeout_seconds") or 5.0)

        start_time = time.perf_counter()
        try:
            async with httpx.AsyncClient(verify=False, timeout=timeout_seconds) as client:
                if http_method == "POST":
                    response = await client.post(url)
                elif http_method == "HEAD":
                    response = await client.head(url)
                else:
                    response = await client.get(url)

                elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))

                # Check HTTP Status Code
                if response.status_code != expected_status:
                    return CheckResult(
                        status=HealthStatus.CRITICAL if response.status_code >= 500 else HealthStatus.WARNING,
                        response_time_ms=elapsed_ms,
                        output_message=f"HTTP Status mismatch: Expected {expected_status}, received {response.status_code}",
                        error_details=f"Response Body: {response.text[:500]}"
                    )

                # Check substring if configured
                if expected_substring and expected_substring.lower() not in response.text.lower():
                    return CheckResult(
                        status=HealthStatus.WARNING,
                        response_time_ms=elapsed_ms,
                        output_message=f"Response body did not contain expected substring '{expected_substring}'",
                        error_details=f"Response Body: {response.text[:500]}"
                    )

                # Check latency SLA warning threshold (e.g. > 2000ms)
                status = HealthStatus.HEALTHY
                msg = f"HTTP {response.status_code} OK ({elapsed_ms}ms)"
                if elapsed_ms > 2000:
                    status = HealthStatus.WARNING
                    msg += " - Latency SLA warning (>2000ms)"

                return CheckResult(
                    status=status,
                    response_time_ms=elapsed_ms,
                    output_message=msg
                )

        except httpx.TimeoutException:
            elapsed_ms = int(timeout_seconds * 1000)
            return CheckResult(
                status=HealthStatus.CRITICAL,
                response_time_ms=elapsed_ms,
                output_message=f"HTTP request to '{url}' timed out after {timeout_seconds}s",
                error_details=f"HTTP Timeout exceeded ({timeout_seconds}s)"
            )
        except httpx.ConnectError as e:
            elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
            return CheckResult(
                status=HealthStatus.CRITICAL,
                response_time_ms=elapsed_ms,
                output_message=f"Failed to connect to '{url}' (Connection Refused / Host Unreachable)",
                error_details=str(e)
            )
        except Exception as e:
            elapsed_ms = max(1, int((time.perf_counter() - start_time) * 1000))
            return CheckResult(
                status=HealthStatus.CRITICAL,
                response_time_ms=elapsed_ms,
                output_message=f"HTTP probe failed for '{url}': {str(e)}",
                error_details=str(e)
            )
