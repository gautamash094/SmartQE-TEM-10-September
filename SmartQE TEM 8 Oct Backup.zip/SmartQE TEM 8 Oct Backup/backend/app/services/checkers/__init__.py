from app.models.health_check import HealthCheckType
from app.services.checkers.base_checker import BaseHealthChecker, CheckResult
from app.services.checkers.ping_checker import PingChecker
from app.services.checkers.tcp_checker import TcpPortChecker
from app.services.checkers.http_checker import HttpChecker
from app.services.checkers.db_checker import DatabaseChecker

CHECKER_REGISTRY = {
    HealthCheckType.PING: PingChecker(),
    HealthCheckType.TCP_PORT: TcpPortChecker(),
    HealthCheckType.HTTP: HttpChecker(),
    HealthCheckType.DATABASE: DatabaseChecker(),
}


def get_checker_for_type(check_type: HealthCheckType) -> BaseHealthChecker:
    return CHECKER_REGISTRY.get(check_type, HttpChecker())
