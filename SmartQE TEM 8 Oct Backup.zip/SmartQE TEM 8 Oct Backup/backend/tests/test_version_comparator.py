import pytest
from app.services.version_comparator import version_comparator


def test_version_comparator_basic():
    # Identical
    assert version_comparator.compare("17.0.10", "17.0.10") == 0
    assert version_comparator.is_match("17.0.10", "17.0.10") is True

    # Less than (Semver: 3.10.12 < 3.11.5)
    assert version_comparator.compare("3.10.12", "3.11.5") == -1
    assert version_comparator.compare("3.11.5", "3.10.12") == 1

    # Patch version: 17.0.9 < 17.0.10
    assert version_comparator.compare("17.0.9", "17.0.10") == -1
    assert version_comparator.compare("17.0.10", "17.0.9") == 1

    # Trailing zeros equivalence: 20.15 == 20.15.0
    assert version_comparator.compare("20.15", "20.15.0") == 0
    assert version_comparator.is_match("20.15", "20.15.0") is True

    # Prefix stripping: v1.2.3 == 1.2.3
    assert version_comparator.compare("v1.2.3", "1.2.3") == 0
    assert version_comparator.is_match("v1.2.3", "1.2.3") is True


def test_version_comparator_build_and_suffixes():
    # Build tokens: 1.8.0_312 vs 1.8.0_322
    assert version_comparator.compare("1.8.0_312", "1.8.0_322") == -1

    # Major differences
    assert version_comparator.compare("16.0", "17.0.10") == -1
    assert version_comparator.compare("21.0.2", "17.0.10") == 1


def test_version_classification():
    # Match
    diff1 = version_comparator.classify_diff("17.0.10", "17.0.10")
    assert diff1["diff_level"] == "EXACT_MATCH"

    # Missing in target
    diff2 = version_comparator.classify_diff("20.15", None)
    assert diff2["diff_level"] == "MISSING"

    # Extra in target
    diff3 = version_comparator.classify_diff(None, "7.2.0")
    assert diff3["diff_level"] == "EXTRA"

    # Minor mismatch: Source 3.11.5 vs Target 3.10.12
    diff4 = version_comparator.classify_diff("3.11.5", "3.10.12")
    assert diff4["diff_level"] == "MINOR_MISMATCH"
    assert diff4["direction"] == "TARGET_BEHIND"

    # Major mismatch
    diff5 = version_comparator.classify_diff("17.0.10", "21.0.2")
    assert diff5["diff_level"] == "MAJOR_MISMATCH"
    assert diff5["direction"] == "TARGET_AHEAD"
