import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.environment import Environment, EnvironmentStatus, EnvironmentTier
from app.models.environment_software import EnvironmentSoftware, SoftwareDiagnosisStatus, SoftwareCategory
from app.models.incident import Incident, IncidentStatus, IncidentSeverity
from app.models.reservation import Reservation, ReservationStatus
from app.models.monitoring import MonitoringThresholdRule, MonitoringMetricType, MonitoringEvent, EventState, EventSeverity
from app.services.monitoring_service import monitoring_service


@pytest.mark.asyncio
async def test_monitoring_fleet_summary_and_detailed_endpoints(client: AsyncClient, db_session: AsyncSession):
    # 1. Setup Environment
    env = Environment(
        name="TEST-OBS-ENV-01",
        tier=EnvironmentTier.SIT,
        team="Digital Payments",
        owner="Observability Lead",
        region="us-east-1",
        status=EnvironmentStatus.HEALTHY,
        cpu_usage=45.0,
        memory_usage=60.0,
        storage_usage=55.0
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # 2. Add Software Component with Match
    sw1 = EnvironmentSoftware(
        environment_id=env.id,
        environment_name=env.name,
        software_name="Payment Gateway API",
        category=SoftwareCategory.APPLICATION,
        installed_version="2.4.0",
        expected_version="2.4.0",
        status=SoftwareDiagnosisStatus.MATCH
    )
    # Add Software Component with Version Mismatch (Drift)
    sw2 = EnvironmentSoftware(
        environment_id=env.id,
        environment_name=env.name,
        software_name="Java Runtime",
        category=SoftwareCategory.RUNTIME,
        installed_version="17.0.8",
        expected_version="17.0.10",
        status=SoftwareDiagnosisStatus.VERSION_MISMATCH
    )
    db_session.add_all([sw1, sw2])
    await db_session.commit()

    # 3. Test GET /api/v1/monitoring/summary
    summary_resp = await client.get("/api/v1/monitoring/summary")
    assert summary_resp.status_code == 200
    summary_data = summary_resp.json()["data"]
    assert "kpis" in summary_data
    assert "environments" in summary_data
    assert summary_data["kpis"]["total_monitored_environments"] >= 1
    assert summary_data["kpis"]["environments_with_drift"] >= 1

    # 4. Test GET /api/v1/monitoring/environments/{env_id}
    detail_resp = await client.get(f"/api/v1/monitoring/environments/{env.id}")
    assert detail_resp.status_code == 200
    dossier = detail_resp.json()["data"]
    assert dossier["environment_name"] == "TEST-OBS-ENV-01"
    assert "health" in dossier
    assert "readiness" in dossier
    assert "drift_summary" in dossier
    assert "impact_summary" in dossier
    assert "auto_heal" in dossier
    assert "predictive_insights" in dossier
    assert dossier["drift_summary"]["has_drift"] is True
    assert dossier["drift_summary"]["version_mismatch"] == 1

    # 5. Test GET /api/v1/monitoring/environments/{env_id}/trends
    trends_resp = await client.get(f"/api/v1/monitoring/environments/{env.id}/trends?timeframe=24h")
    assert trends_resp.status_code == 200
    trends_data = trends_resp.json()["data"]
    assert trends_data["timeframe"] == "24h"
    assert len(trends_data["cpu"]["points"]) == 24
    assert len(trends_data["memory"]["points"]) == 24
    assert len(trends_data["health_score_trend"]["points"]) == 24

    # 6. Test GET /api/v1/monitoring/threshold-rules
    rules_resp = await client.get("/api/v1/monitoring/threshold-rules")
    assert rules_resp.status_code == 200
    rules = rules_resp.json()["data"]
    assert len(rules) >= 1

    # 7. Test POST /api/v1/monitoring/threshold-rules
    new_rule_payload = {
        "name": "Custom Error Rate Alert",
        "environment_id": env.id,
        "metric_type": "ERROR_RATE",
        "operator": ">",
        "warning_threshold": 4.0,
        "critical_threshold": 9.0,
        "duration_minutes": 3,
        "is_enabled": True,
        "auto_heal_enabled": True
    }
    create_rule_resp = await client.post("/api/v1/monitoring/threshold-rules", json=new_rule_payload)
    assert create_rule_resp.status_code == 201
    created_rule = create_rule_resp.json()["data"]
    assert created_rule["name"] == "Custom Error Rate Alert"


@pytest.mark.asyncio
async def test_monitoring_event_lifecycle_and_remediation(client: AsyncClient, db_session: AsyncSession):
    # 1. Setup Environment
    env = Environment(
        name="TEST-EVENT-ENV",
        tier=EnvironmentTier.UAT,
        team="Core Banking",
        owner="UAT Lead",
        region="eu-west-1",
        status=EnvironmentStatus.DEGRADED
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # 2. Create Monitoring Event
    event = MonitoringEvent(
        environment_id=env.id,
        environment_name=env.name,
        target_type="SERVICE",
        target_name="Core Account Service",
        event_type=MonitoringMetricType.SERVICE_DOWN,
        severity=EventSeverity.CRITICAL,
        state=EventState.CRITICAL,
        title="Core Account Service Offline",
        message="TCP port probe failed on port 8080",
        current_value=0.0,
        threshold_value=1.0,
        impact_metadata={"impacted_release": "Release 2026.Q4"}
    )
    db_session.add(event)
    await db_session.commit()
    await db_session.refresh(event)

    # 3. Test GET /api/v1/monitoring/events
    events_resp = await client.get("/api/v1/monitoring/events?state=CRITICAL")
    assert events_resp.status_code == 200
    events = events_resp.json()["data"]
    assert len(events) >= 1
    found_event = next(e for e in events if e["id"] == event.id)
    assert found_event["state"] == "CRITICAL"
    assert found_event["title"] == "Core Account Service Offline"

    # 4. Test POST /api/v1/monitoring/events/{id}/acknowledge
    ack_resp = await client.post(f"/api/v1/monitoring/events/{event.id}/acknowledge")
    assert ack_resp.status_code == 200
    ack_data = ack_resp.json()["data"]
    assert ack_data["acknowledged_at"] is not None

    # 5. Test POST /api/v1/monitoring/events/{id}/remediate
    rem_resp = await client.post(f"/api/v1/monitoring/events/{event.id}/remediate", json={"notes": "Testing self-heal"})
    assert rem_resp.status_code == 200
    rem_data = rem_resp.json()
    assert rem_data["success"] is True
