import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_get_initial_test_phases(client: AsyncClient):
    response = await client.get("/api/v1/test-phases")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert isinstance(data["data"], list)
    assert len(data["data"]) >= 7

    # Verify standard system phases are present
    phase_names = [p["name"] for p in data["data"]]
    for sys_phase in ["UNIT", "UAT", "SIT", "QA", "ST", "PRE PROD", "PROD"]:
        assert sys_phase in phase_names


@pytest.mark.asyncio
async def test_create_custom_test_phase_success(client: AsyncClient):
    payload = {
        "phaseName": "Performance Testing",
        "color": "#8B5CF6",
        "description": "Load and stress testing phase"
    }
    response = await client.post("/api/v1/test-phases/custom", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["success"] is True
    created = data["data"]
    assert created["name"] == "Performance Testing"
    assert created["display_name"] == "Performance Testing" or created.get("displayName") == "Performance Testing"
    assert created["color"] == "#8B5CF6"
    assert created.get("is_system") is False or created.get("isSystem") is False
    assert "id" in created

    # Verify it now appears in GET /test-phases
    get_res = await client.get("/api/v1/test-phases")
    assert get_res.status_code == 200
    all_phases = get_res.json()["data"]
    names = [p["name"] for p in all_phases]
    assert "Performance Testing" in names


@pytest.mark.asyncio
async def test_create_custom_test_phase_duplicate_rejected(client: AsyncClient):
    # 1. Attempting to create duplicate of existing system phase (case-insensitive)
    dup_system = {
        "phaseName": "qa",
        "color": "#10B981"
    }
    response = await client.post("/api/v1/test-phases/custom", json=dup_system)
    assert response.status_code == 409
    data = response.json()
    assert data["success"] is False
    assert "already exists" in data["message"].lower()

    # 2. Create custom phase first
    first_res = await client.post("/api/v1/test-phases/custom", json={
        "phaseName": "Security Testing",
        "color": "#EC4899"
    })
    assert first_res.status_code == 201

    # 3. Attempting to create duplicate of custom phase
    dup_custom = {
        "phaseName": "security testing",
        "color": "#3B82F6"
    }
    response2 = await client.post("/api/v1/test-phases/custom", json=dup_custom)
    assert response2.status_code == 409
    data2 = response2.json()
    assert data2["success"] is False
    assert "already exists" in data2["message"].lower()


@pytest.mark.asyncio
async def test_create_custom_test_phase_empty_name_rejected(client: AsyncClient):
    payload = {
        "phaseName": "   ",
        "color": "#F43F5E"
    }
    response = await client.post("/api/v1/test-phases/custom", json=payload)
    assert response.status_code in (400, 422)
