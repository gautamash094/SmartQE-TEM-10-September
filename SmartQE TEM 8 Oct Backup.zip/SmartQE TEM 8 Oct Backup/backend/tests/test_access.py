import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_get_screens_list(client: AsyncClient):
    """
    Verify /api/v1/access/screens returns application screens registry with all 29 modules and submodules.
    """
    res = await client.get("/api/v1/access/screens")
    assert res.status_code == 200
    data = res.json()["data"]
    assert len(data) == 29
    keys = [s["key"] for s in data]
    
    # Standalone & Core
    assert "dashboard" in keys
    assert "entity_management" in keys
    assert "environment_details" in keys
    assert "worklist" in keys
    assert "bookings" in keys
    assert "incidents" in keys
    assert "integrations" in keys
    assert "runbooks" in keys

    # Releases
    assert "releases" in keys
    assert "release_management" in keys
    assert "release_calendar" in keys

    # Provisioning
    assert "provisioning" in keys
    assert "provisioning_dashboard" in keys
    assert "provisioning_requests" in keys
    assert "provisioning_new" in keys
    assert "provisioning_templates" in keys
    assert "provisioning_history" in keys

    # Resource Management
    assert "resource_management" in keys
    assert "inventory" in keys
    assert "topology" in keys
    assert "monitoring" in keys
    assert "predictive_demand" in keys
    assert "environment_usage_analysis" in keys

    # Settings
    assert "settings" in keys
    assert "settings_users" in keys
    assert "settings_roles" in keys
    assert "settings_access" in keys
    assert "settings_user_groups" in keys
    assert "settings_define_workflow" in keys


@pytest.mark.asyncio
async def test_super_admin_full_access_and_immutability(client: AsyncClient):
    """
    Verify Super Admin role always returns has_access=True for all screens,
    and rejects attempts to restrict its access.
    """
    roles_res = await client.get("/api/v1/roles")
    roles = roles_res.json()["data"]
    super_admin_role = next(r for r in roles if r["name"] == "Super Admin")

    # Get role access
    access_res = await client.get(f"/api/v1/access/roles/{super_admin_role['id']}")
    assert access_res.status_code == 200
    access_data = access_res.json()["data"]
    assert access_data["is_super_admin"] is True
    for s in access_data["screens"]:
        assert s["has_access"] is True

    # Try modifying super admin access -> Must be rejected with 400
    update_res = await client.put(
        f"/api/v1/access/roles/{super_admin_role['id']}",
        json={"screen_ids": []},
    )
    assert update_res.status_code == 400
    assert "Super Admin" in update_res.json().get("detail", "")


@pytest.mark.asyncio
async def test_configure_custom_role_access(client: AsyncClient):
    """
    Verify configuring screen access for a custom non-admin role.
    """
    # Create custom role
    create_role_res = await client.post("/api/v1/roles", json={
        "name": "QA Tester",
        "description": "QA tester role with limited screen access"
    })
    role_id = create_role_res.json()["data"]["id"]

    # Get screens
    screens_res = await client.get("/api/v1/access/screens")
    screens = screens_res.json()["data"]
    dashboard_screen = next(s for s in screens if s["key"] == "dashboard")
    bookings_screen = next(s for s in screens if s["key"] == "bookings")

    # Grant access to only Dashboard and Bookings
    update_res = await client.put(
        f"/api/v1/access/roles/{role_id}",
        json={"screen_ids": [dashboard_screen["id"], bookings_screen["id"]]},
    )
    assert update_res.status_code == 200
    updated_data = update_res.json()["data"]
    for s in updated_data["screens"]:
        if s["screen_id"] in [dashboard_screen["id"], bookings_screen["id"]]:
            assert s["has_access"] is True
        else:
            assert s["has_access"] is False


@pytest.mark.asyncio
async def test_single_active_super_admin_rule(client: AsyncClient):
    """
    Verify that only ONE active Super Admin user is allowed in the system.
    """
    roles_res = await client.get("/api/v1/roles")
    super_admin_role = next(r for r in roles_res.json()["data"] if r["name"] == "Super Admin")

    # Existing active admin user already exists from seed data.
    # Attempt to create a second user with the Super Admin role -> Must fail with 400.
    dup_super_res = await client.post("/api/v1/users", json={
        "first_name": "Second",
        "last_name": "SuperAdmin",
        "username": "second.superadmin",
        "email": "second.superadmin@company.com",
        "role_ids": [super_admin_role["id"]],
        "is_active": True,
    })
    assert dup_super_res.status_code == 400
    err_detail = dup_super_res.json().get("detail", "")
    assert "A Super Admin already exists" in err_detail
