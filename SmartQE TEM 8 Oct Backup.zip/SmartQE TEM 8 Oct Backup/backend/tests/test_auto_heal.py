import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.environment import Environment, EnvironmentStatus, EnvironmentTier
from app.models.auto_heal import AutoHealRule, AutoHealActionType, AutoHealScriptType, AutoHealExecutionMode
from app.services.auto_heal_service import auto_heal_service


@pytest.mark.asyncio
async def test_auto_heal_rule_crud(client: AsyncClient, db_session: AsyncSession):
    # 1. Create Environment
    env = Environment(
        name="TEST-PAY-01",
        tier=EnvironmentTier.QA,
        team="QA Guild",
        owner="Lead Tester",
        region="us-east-1",
        status=EnvironmentStatus.HEALTHY
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # 2. Create Auto-Heal Rule
    rule_payload = {
        "name": "Auto-Restart Payment App",
        "description": "Restarts payment API on HTTP 5xx error",
        "environment_id": env.id,
        "environment_name": env.name,
        "trigger_type": "HEALTH_CHECK_FAILURE",
        "trigger_check_type": "HTTP",
        "trigger_criticality": "CRITICAL",
        "action_type": "RESTART_SERVICE",
        "action_target": "payment-api-service",
        "execution_mode": "AUTOMATIC",
        "max_retries": 2,
        "retry_interval_seconds": 10,
        "grace_period_seconds": 2,
        "is_enabled": True,
        "create_incident_on_exhaustion": True,
        "incident_severity": "SEV2"
    }

    resp = await client.post("/api/v1/auto-heal/rules", json=rule_payload)
    assert resp.status_code in [200, 201]
    data = resp.json()["data"]
    rule_id = data["id"]
    assert data["name"] == "Auto-Restart Payment App"

    # 3. Get Rules for Environment
    get_resp = await client.get(f"/api/v1/auto-heal/rules?environment_id={env.id}")
    assert get_resp.status_code == 200
    rules = get_resp.json()["data"]
    assert len(rules) >= 1

    # 4. Update Rule
    update_resp = await client.put(
        f"/api/v1/auto-heal/rules/{rule_id}",
        json={"execution_mode": "APPROVAL_REQUIRED", "max_retries": 3}
    )
    assert update_resp.status_code == 200
    assert update_resp.json()["data"]["execution_mode"] == "APPROVAL_REQUIRED"

    # 5. Stats
    stats_resp = await client.get("/api/v1/auto-heal/stats")
    assert stats_resp.status_code == 200
    stats = stats_resp.json()["data"]
    assert stats["total_rules"] >= 1


@pytest.mark.asyncio
async def test_script_based_auto_heal_rule(client: AsyncClient, db_session: AsyncSession):
    # Create Environment
    env = Environment(
        name="TEST-SCRIPT-ENV-01",
        tier=EnvironmentTier.SIT,
        team="DevOps",
        owner="Lead",
        region="us-west-2",
        status=EnvironmentStatus.HEALTHY
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # Create Script-Based Rule
    script_payload = {
        "name": "Python Clean Logs and Reset Daemon",
        "description": "Custom script remediation executing Python subprocess",
        "environment_id": env.id,
        "environment_name": env.name,
        "trigger_type": "HEALTH_CHECK_FAILURE",
        "trigger_check_type": "HTTP",
        "trigger_criticality": "CRITICAL",
        "action_type": "EXECUTE_SCRIPT",
        "action_target": "log-cleaner",
        "script_type": "PYTHON",
        "script_content": "import sys; print('Log cleanup complete for ${ENV_NAME}')",
        "script_timeout_seconds": 15,
        "script_parameters": {"CLEAN_DIR": "/tmp/test"},
        "execution_mode": "AUTOMATIC",
        "max_retries": 2,
        "retry_interval_seconds": 5,
        "grace_period_seconds": 1,
        "is_enabled": True
    }

    resp = await client.post("/api/v1/auto-heal/rules", json=script_payload)
    assert resp.status_code in [200, 201]
    rule_data = resp.json()["data"]
    assert rule_data["action_type"] == "EXECUTE_SCRIPT"
    assert rule_data["script_type"] == "PYTHON"

    # Direct execution test of the script action runner
    rule_obj = AutoHealRule(
        name=rule_data["name"],
        environment_id=env.id,
        environment_name=env.name,
        action_type=AutoHealActionType.EXECUTE_SCRIPT,
        action_target="log-cleaner",
        script_type=AutoHealScriptType.PYTHON,
        script_content="import sys; print('Testing script runner output')",
        script_timeout_seconds=10,
        script_parameters={}
    )

    output = await auto_heal_service._execute_script_action(rule_obj, env.id)
    assert "completed successfully" in output or "Testing script runner output" in output


@pytest.mark.asyncio
async def test_manual_auto_heal_trigger(client: AsyncClient, db_session: AsyncSession):
    env = Environment(
        name="TEST-PAY-02",
        tier=EnvironmentTier.SIT,
        team="Core Team",
        owner="DevOps",
        region="us-east-1",
        status=EnvironmentStatus.DEGRADED
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    trigger_payload = {
        "environment_id": env.id,
        "triggered_by": "Test-Lead",
        "reason": "Test manual heal trigger"
    }

    resp = await client.post("/api/v1/auto-heal/trigger", json=trigger_payload)
    assert resp.status_code == 200
    exec_data = resp.json()["data"]
    assert exec_data["status"] in ["SUCCESS", "IN_PROGRESS", "EXHAUSTED"]
    assert exec_data["environment_id"] == env.id
