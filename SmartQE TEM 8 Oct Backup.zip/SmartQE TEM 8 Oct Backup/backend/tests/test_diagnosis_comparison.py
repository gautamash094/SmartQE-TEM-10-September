import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.environment import Environment, EnvironmentTier, EnvironmentStatus
from app.models.environment_software import EnvironmentSoftware, SoftwareDiagnosisStatus, SoftwareCategory


@pytest.mark.asyncio
async def test_diagnosis_and_software_crud(client: AsyncClient, db_session: AsyncSession):
    # 1. Create a test environment
    env = Environment(
        name="TEST-DIAG-ENV-01",
        tier=EnvironmentTier.QA,
        team="Digital QE",
        owner="lead.tester@smartqe.io",
        region="us-east-1",
        status=EnvironmentStatus.HEALTHY,
        cpu_usage=25.0,
        memory_usage=45.0,
        storage_usage=30.0,
        uptime=99.9,
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # 2. Add software components
    sw_java = {
        "software_name": "Java",
        "category": "RUNTIME",
        "installed_version": "17.0.10",
        "expected_version": "17.0.10",
        "port": "8080"
    }
    sw_py = {
        "software_name": "Python",
        "category": "RUNTIME",
        "installed_version": "3.10.12",
        "expected_version": "3.11.5"
    }

    add_res1 = await client.post(f"/api/v1/environments/{env.id}/software", json=sw_java)
    assert add_res1.status_code == 201
    assert add_res1.json()["data"]["software_name"] == "Java"

    add_res2 = await client.post(f"/api/v1/environments/{env.id}/software", json=sw_py)
    assert add_res2.status_code == 201

    # 3. Get software inventory
    soft_list_res = await client.get(f"/api/v1/environments/{env.id}/software")
    assert soft_list_res.status_code == 200
    assert len(soft_list_res.json()["data"]) == 2

    # 4. Run Diagnosis
    diag_res = await client.get(f"/api/v1/environments/{env.id}/diagnosis")
    assert diag_res.status_code == 200
    diag_data = diag_res.json()["data"]

    # Verify environment overview
    assert diag_data["environment"]["environment_name"] == "TEST-DIAG-ENV-01"
    assert diag_data["environment"]["environment_type"] == "QA"
    assert diag_data["summary"]["total_software"] == 2
    assert diag_data["summary"]["matching"] == 1
    assert diag_data["summary"]["version_mismatch"] == 1

    # Verify recommendations generated
    assert len(diag_data["recommendations"]) >= 1
    rec = diag_data["recommendations"][0]
    assert rec["software"] == "Python"
    assert "Version Mismatch" in rec["title"]

    # 5. On-demand run diagnosis
    refresh_res = await client.post(f"/api/v1/environments/{env.id}/diagnose")
    assert refresh_res.status_code == 200


@pytest.mark.asyncio
async def test_environment_comparison_sit_vs_uat(client: AsyncClient, db_session: AsyncSession):
    # 1. Create SIT and UAT environments
    sit_env = Environment(
        name="SIT-ENV-COMPARE",
        tier=EnvironmentTier.SIT,
        team="Platform Core",
        owner="sit.lead@smartqe.io",
        region="us-east-1",
        status=EnvironmentStatus.HEALTHY,
        cpu_usage=20.0,
        memory_usage=40.0,
        uptime=99.9,
    )
    uat_env = Environment(
        name="UAT-ENV-COMPARE",
        tier=EnvironmentTier.UAT,
        team="Platform Core",
        owner="uat.lead@smartqe.io",
        region="us-east-1",
        status=EnvironmentStatus.HEALTHY,
        cpu_usage=22.0,
        memory_usage=42.0,
        uptime=99.9,
    )
    db_session.add_all([sit_env, uat_env])
    await db_session.commit()
    await db_session.refresh(sit_env)
    await db_session.refresh(uat_env)

    # 2. Add Software in SIT
    # Java 17.0.10, Python 3.11.5, Node.js 20.15.0
    await client.post(f"/api/v1/environments/{sit_env.id}/software", json={
        "software_name": "Java",
        "category": "RUNTIME",
        "installed_version": "17.0.10",
        "expected_version": "17.0.10"
    })
    await client.post(f"/api/v1/environments/{sit_env.id}/software", json={
        "software_name": "Python",
        "category": "RUNTIME",
        "installed_version": "3.11.5",
        "expected_version": "3.11.5"
    })
    await client.post(f"/api/v1/environments/{sit_env.id}/software", json={
        "software_name": "Node.js",
        "category": "RUNTIME",
        "installed_version": "20.15.0",
        "expected_version": "20.15.0"
    })

    # 3. Add Software in UAT
    # Java 17.0.10 (MATCH), Python 3.10.12 (MISMATCH), Redis 7.2.0 (EXTRA)
    # Node.js missing from UAT
    await client.post(f"/api/v1/environments/{uat_env.id}/software", json={
        "software_name": "Java",
        "category": "RUNTIME",
        "installed_version": "17.0.10",
        "expected_version": "17.0.10"
    })
    await client.post(f"/api/v1/environments/{uat_env.id}/software", json={
        "software_name": "Python",
        "category": "RUNTIME",
        "installed_version": "3.10.12",
        "expected_version": "3.11.5"
    })
    await client.post(f"/api/v1/environments/{uat_env.id}/software", json={
        "software_name": "Redis",
        "category": "CACHE",
        "installed_version": "7.2.0",
        "expected_version": "7.2.0"
    })

    # 4. Execute Comparison
    comp_res = await client.post("/api/v1/environments/compare", json={
        "source_environment_id": sit_env.id,
        "target_environment_id": uat_env.id,
        "include_server_check": True
    })
    assert comp_res.status_code == 200
    comp_data = comp_res.json()["data"]

    # Verify Summary counts
    assert comp_data["source_environment"]["name"] == "SIT-ENV-COMPARE"
    assert comp_data["target_environment"]["name"] == "UAT-ENV-COMPARE"
    assert comp_data["summary"]["total_software"] == 4
    assert comp_data["summary"]["matching"] == 1        # Java
    assert comp_data["summary"]["version_mismatch"] == 1 # Python
    assert comp_data["summary"]["missing"] == 1         # Node.js
    assert comp_data["summary"]["extra"] == 1           # Redis

    # Verify comparison items
    items_by_sw = {i["software"]: i for i in comp_data["comparison"]}
    assert items_by_sw["Java"]["status"] == "MATCH"
    assert items_by_sw["Python"]["status"] == "VERSION_MISMATCH"
    assert items_by_sw["Node.js"]["status"] == "MISSING"
    assert items_by_sw["Redis"]["status"] == "EXTRA"

    # Verify consistency score calculation
    assert 0.0 <= comp_data["consistency_score"] <= 100.0

    # Verify recommendations
    recs = comp_data["recommendations"]
    assert len(recs) >= 2
    critical_recs = [r for r in recs if r["severity"] == "CRITICAL"]
    assert any("Node.js" in r["title"] for r in critical_recs)
