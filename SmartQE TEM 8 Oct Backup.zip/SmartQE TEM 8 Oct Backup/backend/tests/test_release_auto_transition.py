import pytest
from datetime import datetime, timezone, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from app.services.release_service import release_service
from app.dao.release_dao import release_dao
from app.schemas.release import ReleaseCreate, ReleasePhaseCreate
from app.models.release import ReleaseStatus


@pytest.mark.asyncio
async def test_auto_transition_on_create_past_start_date(db_session: AsyncSession):
    now = datetime.now(timezone.utc)
    past_start = now - timedelta(days=2)
    future_end = now + timedelta(days=5)

    rel_create = ReleaseCreate(
        name="Auto-Transition Past Release",
        version="v1.0.1",
        risk="LOW RISK",
        risk_type="Minor",
        status=ReleaseStatus.SCHEDULED,
        start_date=past_start,
        end_date=future_end,
        initial_phases=[
            ReleasePhaseCreate(
                phase_name="QA Testing",
                start_date=past_start,
                end_date=future_end,
                status="NOT_STARTED"
            )
        ]
    )

    created = await release_service.create_release(db_session, rel_create)
    assert created.status == ReleaseStatus.IN_PROGRESS
    assert len(created.phases) == 1
    assert created.phases[0].status == "IN_PROGRESS"


@pytest.mark.asyncio
async def test_future_release_remains_scheduled(db_session: AsyncSession):
    now = datetime.now(timezone.utc)
    future_start = now + timedelta(days=5)
    future_end = now + timedelta(days=10)

    rel_create = ReleaseCreate(
        name="Future Scheduled Release",
        version="v2.0.0",
        risk="LOW RISK",
        risk_type="Major",
        status=ReleaseStatus.SCHEDULED,
        start_date=future_start,
        end_date=future_end,
        initial_phases=[
            ReleasePhaseCreate(
                phase_name="SIT",
                start_date=future_start,
                end_date=future_end,
                status="NOT_STARTED"
            )
        ]
    )

    created = await release_service.create_release(db_session, rel_create)
    assert created.status == ReleaseStatus.SCHEDULED
    assert created.phases[0].status == "NOT_STARTED"


@pytest.mark.asyncio
async def test_kanban_and_list_reconciles_scheduled_releases(db_session: AsyncSession):
    now = datetime.now(timezone.utc)
    future_start = now + timedelta(days=1)
    future_end = now + timedelta(days=3)

    # 1. Create a release scheduled for slightly in the future
    rel_create = ReleaseCreate(
        name="Transition To Kanban Release",
        version="v3.0.0",
        risk="LOW RISK",
        risk_type="Standard",
        status=ReleaseStatus.SCHEDULED,
        start_date=future_start,
        end_date=future_end
    )
    created = await release_service.create_release(db_session, rel_create)
    assert created.status == ReleaseStatus.SCHEDULED

    # 2. Simulate time passing by manually shifting the release's start date to the past in DB
    raw_rel = await release_dao.get_by_id(db_session, created.id)
    assert raw_rel is not None
    raw_rel.start_date = now - timedelta(hours=2)
    raw_rel.scheduled_date = now - timedelta(hours=2)
    raw_rel.status = ReleaseStatus.SCHEDULED
    await db_session.commit()

    # 3. Fetch kanban board - auto transition should move it to IN_PROGRESS column
    kanban = await release_service.get_kanban_board(db_session)
    in_progress_ids = [r.id for r in kanban.get(ReleaseStatus.IN_PROGRESS.value, [])]
    scheduled_ids = [r.id for r in kanban.get(ReleaseStatus.SCHEDULED.value, [])]

    assert created.id in in_progress_ids
    assert created.id not in scheduled_ids

    # 4. Fetch release by id
    fetched = await release_service.get_release_by_id(db_session, created.id)
    assert fetched.status == ReleaseStatus.IN_PROGRESS
