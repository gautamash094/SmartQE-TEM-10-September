import { Booking, Environment, Release, ReleasePhase } from '../types';
import { EnvironmentProfile } from '../types/environmentDetails';
import { BusinessUnit, ApplicationEntity, Project } from './portfolioService';
import {
  UsagePeriod,
  UsageCategory,
  UsageTrendType,
  UsageClassificationThresholds,
  TrendPoint,
  EnvironmentUsageItem,
  UsageSummaryKPIs,
  ApplicationDemandInsight,
  UsageRecommendation,
  UsageAnalysisData,
  UsageFilterOptions,
} from '../types/environmentUsage';
import { fetchApi } from './apiClient';

const THRESHOLDS_STORAGE_KEY = 'smartqe_tem_usage_thresholds_v1';

export const DEFAULT_USAGE_THRESHOLDS: UsageClassificationThresholds = {
  frequentlyUsedUtilization: 60,
  frequentlyUsedBookings: 15,
  moderatelyUsedUtilization: 20,
  moderatelyUsedBookings: 5,
  rarelyUsedUtilization: 0.01,
  rarelyUsedBookings: 1,
};

export const environmentUsageService = {
  getStoredThresholds(): UsageClassificationThresholds {
    try {
      const raw = localStorage.getItem(THRESHOLDS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.frequentlyUsedUtilization === 'number') {
          return parsed;
        }
      }
    } catch {}
    return { ...DEFAULT_USAGE_THRESHOLDS };
  },

  saveStoredThresholds(thresholds: UsageClassificationThresholds): void {
    try {
      localStorage.setItem(THRESHOLDS_STORAGE_KEY, JSON.stringify(thresholds));
    } catch {}
  },

  resetThresholds(): UsageClassificationThresholds {
    try {
      localStorage.removeItem(THRESHOLDS_STORAGE_KEY);
    } catch {}
    return { ...DEFAULT_USAGE_THRESHOLDS };
  },

  /**
   * Fetch from backend API with fallback to client-side analytical calculation
   */
  async getUsageAnalysis(
    options: Partial<UsageFilterOptions>,
    contextData?: {
      bookings: Booking[];
      environments: Environment[];
      environmentProfiles: EnvironmentProfile[];
      softwareList?: any[];
      releases: Release[];
      applications: ApplicationEntity[];
      projects: Project[];
      businessUnits: BusinessUnit[];
    }
  ): Promise<UsageAnalysisData> {
    const period = options.period || '90d';
    const thresholds = this.getStoredThresholds();

    const queryParams = new URLSearchParams({
      period,
      freqUtilThreshold: String(thresholds.frequentlyUsedUtilization),
      freqBookingsThreshold: String(thresholds.frequentlyUsedBookings),
      modUtilThreshold: String(thresholds.moderatelyUsedUtilization),
      modBookingsThreshold: String(thresholds.moderatelyUsedBookings),
    });

    if (options.customStartDate) queryParams.set('startDate', options.customStartDate);
    if (options.customEndDate) queryParams.set('endDate', options.customEndDate);
    if (options.businessUnit && options.businessUnit !== 'ALL') queryParams.set('businessUnit', options.businessUnit);
    if (options.project && options.project !== 'ALL') queryParams.set('project', options.project);
    if (options.application && options.application !== 'ALL') queryParams.set('application', options.application);
    if (options.tier && options.tier !== 'ALL') queryParams.set('tier', options.tier);
    if (options.testPhase && options.testPhase !== 'ALL') queryParams.set('testPhase', options.testPhase);
    if (options.category && options.category !== 'ALL') queryParams.set('category', options.category);

    try {
      const apiRes = await fetchApi<any>(`/usage-analysis?${queryParams.toString()}`);
      if (apiRes && apiRes.environments && Array.isArray(apiRes.environments)) {
        return {
          periodType: apiRes.period_type || period,
          startDate: apiRes.start_date,
          endDate: apiRes.end_date,
          totalDays: apiRes.total_days,
          summaryKpis: {
            totalEnvironments: apiRes.summary_kpis?.total_environments ?? apiRes.environments.length,
            frequentlyUsedCount: apiRes.summary_kpis?.frequently_used_count ?? 0,
            moderatelyUsedCount: apiRes.summary_kpis?.moderately_used_count ?? 0,
            rarelyUsedCount: apiRes.summary_kpis?.rarely_used_count ?? 0,
            neverUsedCount: apiRes.summary_kpis?.never_used_count ?? 0,
            overallUtilizationPct: apiRes.summary_kpis?.overall_utilization_pct ?? 0,
            totalBookingsCount: apiRes.summary_kpis?.total_bookings_count ?? 0,
            totalUsageHours: apiRes.summary_kpis?.total_usage_hours ?? 0,
            mostUsedEnvironmentName: apiRes.summary_kpis?.most_used_environment_name,
            mostUsedUtilizationPct: apiRes.summary_kpis?.most_used_utilization_pct ?? 0,
            leastUsedEnvironmentName: apiRes.summary_kpis?.least_used_environment_name,
            leastUsedUtilizationPct: apiRes.summary_kpis?.least_used_utilization_pct ?? 0,
            unusedEnvironmentsCount: apiRes.summary_kpis?.unused_environments_count ?? 0,
            fleetUsageTrend: apiRes.summary_kpis?.fleet_usage_trend || 'Stable',
          },
          thresholdsApplied: {
            frequentlyUsedUtilization: apiRes.thresholds_applied?.frequently_used_utilization ?? thresholds.frequentlyUsedUtilization,
            frequentlyUsedBookings: apiRes.thresholds_applied?.frequently_used_bookings ?? thresholds.frequentlyUsedBookings,
            moderatelyUsedUtilization: apiRes.thresholds_applied?.moderately_used_utilization ?? thresholds.moderatelyUsedUtilization,
            moderatelyUsedBookings: apiRes.thresholds_applied?.moderately_used_bookings ?? thresholds.moderatelyUsedBookings,
            rarelyUsedUtilization: apiRes.thresholds_applied?.rarely_used_utilization ?? thresholds.rarelyUsedUtilization,
            rarelyUsedBookings: apiRes.thresholds_applied?.rarely_used_bookings ?? thresholds.rarelyUsedBookings,
          },
          environments: apiRes.environments.map((e: any) => ({
            environmentId: e.environment_id,
            environmentName: e.environment_name,
            environmentType: e.environment_type,
            tier: e.tier,
            primaryApplication: e.primary_application,
            associatedApplications: e.associated_applications || [],
            associatedProjects: e.associated_projects || [],
            businessUnit: e.business_unit,
            usageCategory: e.usage_category,
            bookingCount: e.booking_count,
            totalUsageHours: e.total_usage_hours,
            totalUsageDays: e.total_usage_days,
            lastUsedDate: e.last_used_date,
            lastUsedFormatted: e.last_used_formatted,
            utilizationPct: e.utilization_pct,
            trend: e.trend,
            trendPctChange: e.trend_pct_change,
            releaseCount: e.release_count,
            associatedReleases: e.associated_releases || [],
            topPhase: e.top_phase,
            phaseBreakdown: e.phase_breakdown || {},
            averageBookingDurationHours: e.average_booking_duration_hours,
            status: e.status,
            isActive: e.is_active,
          })),
          timeSeriesTrend: (apiRes.time_series_trend || []).map((t: any) => ({
            periodLabel: t.period_label,
            monthName: t.month_name,
            year: t.year,
            utilizationPct: t.utilization_pct,
            bookingCount: t.booking_count,
            hoursBooked: t.hours_booked,
          })),
          applicationDemandInsights: (apiRes.application_demand_insights || []).map((a: any) => ({
            applicationName: a.application_name,
            phaseName: a.phase_name,
            availableEnvironmentsCount: a.available_environments_count,
            totalBookingsInPeriod: a.total_bookings_in_period,
            avgMonthlyDemand: a.avg_monthly_demand,
            demandStatus: a.demand_status,
            insightMessage: a.insight_message,
          })),
          recommendations: (apiRes.recommendations || []).map((r: any) => ({
            id: r.id,
            category: r.category,
            severity: r.severity,
            targetEnvironment: r.target_environment,
            title: r.title,
            message: r.message,
            actionableRecommendation: r.actionable_recommendation,
            impactScore: r.impact_score,
          })),
        };
      }
    } catch (e) {
      console.warn('Backend API endpoint fallback to local analysis calculation:', e);
    }

    // Client-side analytical calculation engine fallback
    if (contextData) {
      return this.calculateClientSideAnalysis(options, contextData, thresholds);
    }

    return this.getEmptyAnalysisData(period, thresholds);
  },

  /**
   * Deterministic client-side analysis computation from active TEMContext state.
   */
  calculateClientSideAnalysis(
    options: Partial<UsageFilterOptions>,
    contextData: {
      bookings: Booking[];
      environments: Environment[];
      environmentProfiles: EnvironmentProfile[];
      softwareList?: any[];
      releases: Release[];
      applications: ApplicationEntity[];
      projects: Project[];
      businessUnits: BusinessUnit[];
    },
    thresholds: UsageClassificationThresholds
  ): UsageAnalysisData {
    const period = options.period || '90d';
    const now = new Date();
    let windowStart = new Date();
    let windowEnd = new Date();

    if (period === '30d') {
      windowStart.setDate(now.getDate() - 30);
      windowEnd.setDate(now.getDate() + 30);
    } else if (period === '90d') {
      windowStart.setDate(now.getDate() - 90);
      windowEnd.setDate(now.getDate() + 60);
    } else if (period === '180d') {
      windowStart.setDate(now.getDate() - 180);
      windowEnd.setDate(now.getDate() + 90);
    } else if (period === '365d') {
      windowStart.setDate(now.getDate() - 365);
      windowEnd.setDate(now.getDate() + 180);
    } else if (period === 'custom' && options.customStartDate && options.customEndDate) {
      windowStart = new Date(options.customStartDate);
      windowEnd = new Date(options.customEndDate);
      windowEnd.setHours(23, 59, 59, 999);
    } else {
      windowStart.setDate(now.getDate() - 90);
      windowEnd.setDate(now.getDate() + 60);
    }

    const windowStartMs = windowStart.getTime();
    const windowEndMs = windowEnd.getTime();
    const totalWindowMs = Math.max(1000, windowEndMs - windowStartMs);
    const totalWindowHours = totalWindowMs / (1000 * 60 * 60);
    const totalDays = Math.max(1, Math.round(totalWindowMs / (1000 * 60 * 60 * 24)));
    const midpointMs = windowStartMs + totalWindowMs / 2;

    const parseDateMs = (d: any): number => {
      if (!d) return NaN;
      if (d instanceof Date) return d.getTime();
      if (typeof d === 'number') return d;
      const str = String(d).trim();
      const withT = str.replace(' ', 'T');
      const t = new Date(withT).getTime();
      if (!isNaN(t)) return t;
      return new Date(str).getTime();
    };

    const norm = (s?: string) => (s || '').toLowerCase().replace(/[\s_\-]+/g, '').trim();

    // Map software catalog by id for instant application resolution
    const softwareById = new Map<string, string>();
    (contextData.softwareList || []).forEach((s: any) => {
      if (s && s.id && s.name) softwareById.set(s.id, s.name);
    });

    // Collect all unique environments from profiles, environments list, and bookings
    const envMap = new Map<
      string,
      { id: string; name: string; type: string; status: string; isActive: boolean; team: string; softwareIds: string[] }
    >();

    // 1. Primary from environment profiles
    (contextData.environmentProfiles || []).forEach((ep) => {
      envMap.set(ep.id, {
        id: ep.id,
        name: ep.name,
        type: ep.type || 'QA',
        status: ep.status || 'HEALTHY',
        isActive: ep.isActive !== false,
        team: ep.ownerTeam || 'Enterprise QE',
        softwareIds: ep.softwareIds || [],
      });
    });

    // 2. Base environments if profile missing
    (contextData.environments || []).forEach((env) => {
      const exists = Array.from(envMap.values()).some(
        (e) => norm(e.name) === norm(env.name) || e.id === env.id
      );
      if (!exists) {
        envMap.set(env.id, {
          id: env.id,
          name: env.name,
          type: env.tier || 'DEV',
          status: env.status || 'HEALTHY',
          isActive: env.isActive !== false,
          team: env.team || 'Core Platform',
          softwareIds: [],
        });
      }
    });

    // 3. Discover any environment referenced in bookings
    (contextData.bookings || []).forEach((b) => {
      const bName = b.environmentName?.trim();
      if (bName) {
        const exists = Array.from(envMap.values()).some(
          (e) => norm(e.name) === norm(bName) || (b.environmentId && (e.id === b.environmentId || norm(e.id) === norm(b.environmentId)))
        );
        if (!exists) {
          const bId = b.environmentId || `env-${norm(bName)}`;
          envMap.set(bId, {
            id: bId,
            name: bName,
            type: b.testPhaseName || 'QA',
            status: 'HEALTHY',
            isActive: true,
            team: b.businessUnit || b.team || 'QA Guild',
            softwareIds: [],
          });
        }
      }
    });

    // Filter valid bookings (exclude cancelled/rejected for active utilization)
    const allBookings = contextData.bookings || [];
    const validBookings = allBookings.filter((b) => {
      const st = String(b.status || '').toUpperCase();
      return !st.includes('CANCEL') && !st.includes('REJECT');
    });

    const envUsageItems: EnvironmentUsageItem[] = [];
    let totalFleetHours = 0;
    let totalFleetBookings = 0;

    envMap.forEach((envData, envId) => {
      const envNorm = norm(envData.name);
      const envIdNorm = norm(envId);

      // Find valid active bookings for this environment
      const matchedBookings = validBookings.filter((b) => {
        const bEnvId = b.environmentId ? norm(b.environmentId) : '';
        const bEnvName = norm(b.environmentName);
        return (
          (bEnvId && (bEnvId === envIdNorm || bEnvId === envNorm)) ||
          (bEnvName && (bEnvName === envNorm || bEnvName === envIdNorm)) ||
          (b.environmentId && envData.id && String(b.environmentId).trim() === String(envData.id).trim()) ||
          (b.environmentName && envData.name && norm(b.environmentName) === norm(envData.name))
        );
      });

      // Find ALL historical booking records (including Auto-Rejected/Conflicts) for drilldowns
      const allMatchedBookings = allBookings.filter((b) => {
        const bEnvId = b.environmentId ? norm(b.environmentId) : '';
        const bEnvName = norm(b.environmentName);
        return (
          (bEnvId && (bEnvId === envIdNorm || bEnvId === envNorm)) ||
          (bEnvName && (bEnvName === envNorm || bEnvName === envIdNorm)) ||
          (b.environmentId && envData.id && String(b.environmentId).trim() === String(envData.id).trim()) ||
          (b.environmentName && envData.name && norm(b.environmentName) === norm(envData.name))
        );
      });

      let totalDurationMs = 0;
      let firstHalfDurationMs = 0;
      let secondHalfDurationMs = 0;
      let latestUsedDate: Date | null = null;
      const apps = new Set<string>();
      const projs = new Set<string>();
      const bus = new Set<string>();
      const rels = new Set<string>();
      const phaseCountMap: Record<string, number> = {};
      const activeWindowBookings: Booking[] = [];

      for (const b of matchedBookings) {
        const bStart = parseDateMs(b.startDate);
        const bEnd = parseDateMs(b.endDate);

        if (isNaN(bStart) || isNaN(bEnd)) continue;

        const overlapStart = Math.max(windowStartMs, bStart);
        const overlapEnd = Math.min(windowEndMs, bEnd);

        if (overlapEnd > overlapStart) {
          activeWindowBookings.push(b);
          const dur = overlapEnd - overlapStart;
          totalDurationMs += dur;

          // Halves for trend
          const fhStart = Math.max(windowStartMs, bStart);
          const fhEnd = Math.min(midpointMs, bEnd);
          if (fhEnd > fhStart) firstHalfDurationMs += (fhEnd - fhStart);

          const shStart = Math.max(midpointMs, bStart);
          const shEnd = Math.min(windowEndMs, bEnd);
          if (shEnd > shStart) secondHalfDurationMs += (shEnd - shStart);

          const bApp = b.application || (b as any).applicationName || (b as any).appName || (b as any).application_name;
          if (bApp) apps.add(bApp.trim());
          if (b.project) projs.add(b.project.trim());
          if (b.businessUnit) bus.add(b.businessUnit.trim());
          if (b.releaseName) rels.add(b.releaseName.trim());
          else if (b.releaseId) rels.add(b.releaseId.trim());

          const phase = b.testPhaseName || (b as any).test_phase || 'General Testing';
          phaseCountMap[phase] = (phaseCountMap[phase] || 0) + 1;
        }

        // Track past completion vs active/scheduled
        const bStartMs = isNaN(bStart) ? 0 : bStart;
        const bEndMs = isNaN(bEnd) ? 0 : bEnd;
        const nowMs = now.getTime();

        if (bEndMs <= nowMs) {
          const endObj = new Date(bEndMs);
          if (!latestUsedDate || endObj > latestUsedDate) {
            latestUsedDate = endObj;
          }
        } else {
          // Ongoing or scheduled booking
          const endObj = new Date(bEndMs);
          if (!latestUsedDate || endObj > latestUsedDate) {
            latestUsedDate = endObj;
          }
        }
      }

      // Also gather metadata from any booking if apps/bus were empty
      allMatchedBookings.forEach((b) => {
        const bApp = b.application || (b as any).applicationName || (b as any).appName || (b as any).application_name;
        if (bApp) apps.add(bApp.trim());
        if (b.project) projs.add(b.project.trim());
        if (b.businessUnit) bus.add(b.businessUnit.trim());
        if (b.releaseName) rels.add(b.releaseName.trim());
      });

      // Enrich applications from linked software catalog
      (envData.softwareIds || []).forEach((sId) => {
        const sName = softwareById.get(sId);
        if (sName) apps.add(sName);
      });

      // Enrich from portfolio applications
      (contextData.applications || []).forEach((app) => {
        const appEnvIds = (app as any).environmentIds || (app as any).environments || [];
        if (
          appEnvIds.includes(envData.id) ||
          appEnvIds.includes(envId) ||
          (app.name && envData.name.toLowerCase().includes(app.name.toLowerCase()))
        ) {
          apps.add(app.name);
        }
      });

      // Name inference if no applications found
      if (apps.size === 0) {
        if (envData.name.toLowerCase().includes('payment')) apps.add('Payment Gateway Core');
        else if (envData.name.toLowerCase().includes('ash')) apps.add('AshApp Services');
        else if (envData.name.toLowerCase().includes('akash')) apps.add('Akash Portal');
        else apps.add('Core Platform Services');
      }

      const usageHours = Math.round((totalDurationMs / (1000 * 60 * 60)) * 10) / 10;
      const usageDays = Math.round((totalDurationMs / (1000 * 60 * 60 * 24)) * 10) / 10;
      const bookingCount = activeWindowBookings.length;

      totalFleetHours += usageHours;
      totalFleetBookings += bookingCount;

      const rawUtil = (totalDurationMs / totalWindowMs) * 100;
      const utilizationPct = Math.min(100, Math.round(rawUtil * 10) / 10);

      // Classification
      let usageCategory: UsageCategory = 'Never Used';
      if (bookingCount === 0 || utilizationPct === 0) {
        usageCategory = 'Never Used';
      } else if (
        utilizationPct >= thresholds.frequentlyUsedUtilization ||
        bookingCount >= thresholds.frequentlyUsedBookings
      ) {
        usageCategory = 'Frequently Used';
      } else if (
        utilizationPct >= thresholds.moderatelyUsedUtilization ||
        bookingCount >= thresholds.moderatelyUsedBookings
      ) {
        usageCategory = 'Moderately Used';
      } else {
        usageCategory = 'Rarely Used';
      }

      // Trend Calculation
      const halfWindowMs = totalWindowMs / 2;
      const firstHalfUtil = (firstHalfDurationMs / halfWindowMs) * 100;
      const secondHalfUtil = (secondHalfDurationMs / halfWindowMs) * 100;
      const trendDiff = Math.round((secondHalfUtil - firstHalfUtil) * 10) / 10;

      let trendStr: UsageTrendType = 'No usage';
      if (bookingCount === 0) {
        trendStr = 'No usage';
      } else if (trendDiff > 0.5) {
        trendStr = 'Increasing';
      } else if (trendDiff < -0.5) {
        trendStr = 'Decreasing';
      } else {
        trendStr = 'Stable';
      }

      const primaryApp = apps.size > 0 ? Array.from(apps)[0] : 'Core Platform Services';
      const primaryBU = bus.size > 0 ? Array.from(bus)[0] : envData.team;

      // Find top phase
      let topPhase: string | null = null;
      let maxPhaseCount = 0;
      Object.entries(phaseCountMap).forEach(([pName, count]) => {
        if (count > maxPhaseCount) {
          maxPhaseCount = count;
          topPhase = pName;
        }
      });

      const avgDuration = bookingCount > 0 ? Math.round((usageHours / bookingCount) * 10) / 10 : 0;

      // Smart Format for Last Used date vs Active/Scheduled horizon
      let lastUsedFormatted = 'Never used';
      if (latestUsedDate instanceof Date) {
        const nowMs = now.getTime();
        const dateMs = latestUsedDate.getTime();
        const formattedDate = latestUsedDate.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
        });

        if (dateMs > nowMs) {
          // Booking extends into the future
          const isCurrentlyRunning = activeWindowBookings.some((b) => {
            const s = parseDateMs(b.startDate);
            const e = parseDateMs(b.endDate);
            return s <= nowMs && e >= nowMs;
          });

          if (isCurrentlyRunning) {
            lastUsedFormatted = `Active (until ${formattedDate})`;
          } else {
            lastUsedFormatted = `Booked (until ${formattedDate})`;
          }
        } else {
          lastUsedFormatted = formattedDate;
        }
      }

      // Apply Filters
      if (options.searchQuery) {
        const q = options.searchQuery.toLowerCase().trim();
        const matchName = envData.name.toLowerCase().includes(q);
        const matchApp = primaryApp.toLowerCase().includes(q);
        const matchType = envData.type.toLowerCase().includes(q);
        if (!matchName && !matchApp && !matchType) return;
      }
      if (options.businessUnit && options.businessUnit !== 'ALL' && primaryBU.toLowerCase() !== options.businessUnit.toLowerCase()) return;
      if (options.project && options.project !== 'ALL' && !Array.from(projs).some(p => p.toLowerCase() === options.project?.toLowerCase())) return;
      if (options.application && options.application !== 'ALL' && !Array.from(apps).some(a => a.toLowerCase() === options.application?.toLowerCase())) return;
      if (options.tier && options.tier !== 'ALL' && envData.type.toLowerCase() !== options.tier.toLowerCase()) return;
      if (options.testPhase && options.testPhase !== 'ALL' && !phaseCountMap[options.testPhase]) return;
      if (options.category && options.category !== 'ALL' && usageCategory.toLowerCase() !== options.category.toLowerCase()) return;

      envUsageItems.push({
        environmentId: envId,
        environmentName: envData.name,
        environmentType: envData.type,
        tier: envData.type,
        primaryApplication: primaryApp,
        associatedApplications: Array.from(apps),
        associatedProjects: Array.from(projs),
        businessUnit: primaryBU,
        usageCategory,
        bookingCount,
        totalUsageHours: usageHours,
        totalUsageDays: usageDays,
        lastUsedDate: latestUsedDate instanceof Date ? latestUsedDate.toISOString() : null,
        lastUsedFormatted,
        utilizationPct,
        trend: trendStr,
        trendPctChange: trendDiff,
        releaseCount: rels.size,
        associatedReleases: Array.from(rels),
        topPhase,
        phaseBreakdown: phaseCountMap,


        averageBookingDurationHours: avgDuration,
        status: envData.status,
        isActive: envData.isActive,
      });
    });

    // Sorting
    const sortBy = options.sortBy || 'utilization';
    const sortOrder = options.sortOrder || 'desc';
    envUsageItems.sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'utilization') comparison = a.utilizationPct - b.utilizationPct;
      else if (sortBy === 'bookings') comparison = a.bookingCount - b.bookingCount;
      else if (sortBy === 'hours') comparison = a.totalUsageHours - b.totalUsageHours;
      else if (sortBy === 'name') comparison = a.environmentName.localeCompare(b.environmentName);
      else if (sortBy === 'lastUsed') {
        const timeA = a.lastUsedDate ? new Date(a.lastUsedDate).getTime() : 0;
        const timeB = b.lastUsedDate ? new Date(b.lastUsedDate).getTime() : 0;
        comparison = timeA - timeB;
      }
      return sortOrder === 'desc' ? -comparison : comparison;
    });

    // Summary KPIs
    const freqCount = envUsageItems.filter(e => e.usageCategory === 'Frequently Used').length;
    const modCount = envUsageItems.filter(e => e.usageCategory === 'Moderately Used').length;
    const rareCount = envUsageItems.filter(e => e.usageCategory === 'Rarely Used').length;
    const neverCount = envUsageItems.filter(e => e.usageCategory === 'Never Used').length;

    const totalEnvs = envUsageItems.length;
    const overallUtil = totalEnvs > 0
      ? Math.round((envUsageItems.reduce((acc, curr) => acc + curr.utilizationPct, 0) / totalEnvs) * 10) / 10
      : 0;

    const sortedByUtil = [...envUsageItems].sort((a, b) => b.utilizationPct - a.utilizationPct);
    const mostUsed = sortedByUtil[0] || null;
    const candidatesWithUsage = sortedByUtil.filter(e => e.utilizationPct > 0);
    const leastUsed = candidatesWithUsage.length > 0 ? candidatesWithUsage[candidatesWithUsage.length - 1] : (sortedByUtil[sortedByUtil.length - 1] || null);

    const sumTrends = envUsageItems.reduce((acc, curr) => acc + curr.trendPctChange, 0);
    const fleetTrend: UsageTrendType = sumTrends > 10 ? 'Increasing' : (sumTrends < -10 ? 'Decreasing' : 'Stable');

    const summaryKpis: UsageSummaryKPIs = {
      totalEnvironments: totalEnvs,
      frequentlyUsedCount: freqCount,
      moderatelyUsedCount: modCount,
      rarelyUsedCount: rareCount,
      neverUsedCount: neverCount,
      overallUtilizationPct: overallUtil,
      totalBookingsCount: totalFleetBookings,
      totalUsageHours: Math.round(totalFleetHours * 10) / 10,
      mostUsedEnvironmentName: mostUsed?.environmentName || null,
      mostUsedUtilizationPct: mostUsed?.utilizationPct || 0,
      leastUsedEnvironmentName: leastUsed?.environmentName || null,
      leastUsedUtilizationPct: leastUsed?.utilizationPct || 0,
      unusedEnvironmentsCount: neverCount,
      fleetUsageTrend: fleetTrend,
    };

    // Time series monthly breakdown
    const timeSeriesTrend = this.computeMonthlyTimeSeriesTrend(windowStart, windowEnd, validBookings, totalEnvs);

    // Application & Phase Demand insights
    const applicationDemandInsights = this.computeDemandInsights(envUsageItems, validBookings, windowStart, windowEnd);

    // Recommendations
    const recommendations = this.computeRecommendations(envUsageItems, applicationDemandInsights, period, totalDays);

    return {
      periodType: period,
      startDate: windowStart.toISOString().split('T')[0],
      endDate: windowEnd.toISOString().split('T')[0],
      totalDays,
      summaryKpis,
      thresholdsApplied: thresholds,
      environments: envUsageItems,
      timeSeriesTrend,
      applicationDemandInsights,
      recommendations,
    };
  },

  computeMonthlyTimeSeriesTrend(
    windowStart: Date,
    windowEnd: Date,
    bookings: Booking[],
    totalEnvs: number
  ): TrendPoint[] {
    const points: TrendPoint[] = [];
    const curr = new Date(windowStart.getFullYear(), windowStart.getMonth(), 1);

    while (curr <= windowEnd) {
      const nextMonth = new Date(curr.getFullYear(), curr.getMonth() + 1, 1);
      const mStart = new Date(Math.max(windowStart.getTime(), curr.getTime()));
      const mEnd = new Date(Math.min(windowEnd.getTime(), nextMonth.getTime()));

      const mDurSec = Math.max(1, (mEnd.getTime() - mStart.getTime()) / 1000);
      const mCapacityHours = (mDurSec / 3600) * Math.max(1, totalEnvs);

      let mBookedSec = 0;
      let mBookingsCount = 0;

      bookings.forEach((b) => {
        const bStart = new Date(b.startDate).getTime();
        const bEnd = new Date(b.endDate).getTime();
        if (isNaN(bStart) || isNaN(bEnd)) return;

        const ovStart = Math.max(mStart.getTime(), bStart);
        const ovEnd = Math.min(mEnd.getTime(), bEnd);

        if (ovEnd > ovStart) {
          mBookedSec += (ovEnd - ovStart) / 1000;
          mBookingsCount++;
        }
      });

      const mHoursBooked = mBookedSec / 3600;
      const mUtil = Math.min(100, Math.round((mHoursBooked / Math.max(1, mCapacityHours)) * 1000) / 10);

      points.push({
        periodLabel: curr.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        monthName: curr.toLocaleDateString('en-US', { month: 'long' }),
        year: curr.getFullYear(),
        utilizationPct: mUtil,
        bookingCount: mBookingsCount,
        hoursBooked: Math.round(mHoursBooked * 10) / 10,
      });

      curr.setMonth(curr.getMonth() + 1);
    }

    return points;
  },

  computeDemandInsights(
    envItems: EnvironmentUsageItem[],
    bookings: Booking[],
    windowStart: Date,
    windowEnd: Date
  ): ApplicationDemandInsight[] {
    const map = new Map<string, { app: string; phase: string; count: number }>();
    const months = Math.max(1, (windowEnd.getTime() - windowStart.getTime()) / (1000 * 60 * 60 * 24 * 30));

    bookings.forEach((b) => {
      const app = (b.application || 'General Platform').trim();
      const phase = (b.testPhaseName || (b as any).test_phase || 'SIT').trim();
      const key = `${app}::${phase}`;
      if (!map.has(key)) {
        map.set(key, { app, phase, count: 0 });
      }
      map.get(key)!.count++;
    });

    const list: ApplicationDemandInsight[] = [];
    map.forEach((data) => {
      const monthlyDemand = Math.round((data.count / months) * 10) / 10;
      const matchingEnvs = envItems.filter(
        (e) =>
          e.associatedApplications.some((a) => a.toLowerCase() === data.app.toLowerCase()) ||
          e.primaryApplication.toLowerCase() === data.app.toLowerCase() ||
          e.environmentType.toLowerCase().includes(data.phase.toLowerCase())
      );
      const availCount = Math.max(1, matchingEnvs.length);

      let status: 'HIGH_DEMAND' | 'BALANCED' | 'LOW_DEMAND' = 'BALANCED';
      let msg = `${data.phase} testing demand (${monthlyDemand} bookings/mo) is balanced across ${availCount} environments.`;

      if (monthlyDemand > availCount * 4) {
        status = 'HIGH_DEMAND';
        msg = `Demand for ${data.phase} environments (${monthlyDemand} bookings/mo) is higher than available capacity (${availCount} envs).`;
      } else if (monthlyDemand < availCount * 1.5) {
        status = 'LOW_DEMAND';
        msg = `${data.app} ${data.phase} environment utilization is moderate with ${availCount} available environments.`;
      }

      list.push({
        applicationName: data.app,
        phaseName: data.phase,
        availableEnvironmentsCount: availCount,
        totalBookingsInPeriod: data.count,
        avgMonthlyDemand: monthlyDemand,
        demandStatus: status,
        insightMessage: msg,
      });
    });

    return list.slice(0, 8);
  },

  computeRecommendations(
    envItems: EnvironmentUsageItem[],
    demandInsights: ApplicationDemandInsight[],
    period: string,
    totalDays: number
  ): UsageRecommendation[] {
    const recs: UsageRecommendation[] = [];

    // 1. Unused environments
    const neverUsed = envItems.filter((e) => e.usageCategory === 'Never Used');
    neverUsed.slice(0, 3).forEach((nu) => {
      recs.push({
        id: `rec-nu-${nu.environmentId}`,
        category: 'UNBOOKED',
        severity: 'WARNING',
        targetEnvironment: nu.environmentName,
        title: `${nu.environmentName} has zero bookings in ${period}`,
        message: `${nu.environmentName} (${nu.environmentType}) has not been booked or used in the last ${totalDays} days despite being active.`,
        actionableRecommendation: 'Consider making this environment available for other high-demand applications (e.g. Payment Gateway) or scheduling auto-hibernation.',
        impactScore: 'Cost & Fleet Optimization',
      });
    });

    // 2. High Demand environments
    const freqUsed = envItems.filter((e) => e.usageCategory === 'Frequently Used');
    freqUsed.slice(0, 3).forEach((fu) => {
      recs.push({
        id: `rec-fu-${fu.environmentId}`,
        category: 'HIGH_DEMAND',
        severity: 'INFO',
        targetEnvironment: fu.environmentName,
        title: `${fu.environmentName} is frequently used with high booking demand`,
        message: `${fu.environmentName} handled ${fu.bookingCount} bookings (${fu.totalUsageHours} hours) across ${fu.releaseCount} releases with ${fu.utilizationPct}% utilization.`,
        actionableRecommendation: 'High contention detected. Consider provisioning an additional replica or setting up automated time-sharing slots to prevent pipeline delays.',
        impactScore: 'Delivery Acceleration',
      });
    });

    // 3. Rarely Used environments
    const rarelyUsed = envItems.filter((e) => e.usageCategory === 'Rarely Used');
    rarelyUsed.slice(0, 3).forEach((ru) => {
      recs.push({
        id: `rec-ru-${ru.environmentId}`,
        category: 'REASSIGNMENT',
        severity: 'WARNING',
        targetEnvironment: ru.environmentName,
        title: `${ru.environmentName} has low utilization and may be suitable for reassignment`,
        message: `${ru.environmentName} recorded only ${ru.bookingCount} booking(s) (${ru.totalUsageHours} hours) and ${ru.utilizationPct}% utilization in the last ${totalDays} days.`,
        actionableRecommendation: `Consider making ${ru.environmentName} available for other compatible applications rather than provisioning fresh QA/SIT infrastructure.`,
        impactScore: 'Resource Reallocation',
      });
    });

    // 4. Demand Surges
    const highDemandApps = demandInsights.filter((d) => d.demandStatus === 'HIGH_DEMAND');
    highDemandApps.slice(0, 2).forEach((hd, idx) => {
      recs.push({
        id: `rec-hd-${idx}`,
        category: 'CAPACITY',
        severity: 'CRITICAL',
        targetEnvironment: `${hd.applicationName} (${hd.phaseName})`,
        title: `Environment demand is increasing for ${hd.applicationName}`,
        message: `Demand for ${hd.phaseName} testing is ${hd.avgMonthlyDemand} bookings/month against ${hd.availableEnvironmentsCount} available environment(s).`,
        actionableRecommendation: 'Demand for SIT/QA environments is higher than available capacity. Recommend provisioning additional environments or rebalancing rarely used nodes.',
        impactScore: 'Capacity Risk Mitigation',
      });
    });

    return recs;
  },

  getEmptyAnalysisData(period: UsagePeriod, thresholds: UsageClassificationThresholds): UsageAnalysisData {
    return {
      periodType: period,
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      totalDays: 90,
      summaryKpis: {
        totalEnvironments: 0,
        frequentlyUsedCount: 0,
        moderatelyUsedCount: 0,
        rarelyUsedCount: 0,
        neverUsedCount: 0,
        overallUtilizationPct: 0,
        totalBookingsCount: 0,
        totalUsageHours: 0,
        unusedEnvironmentsCount: 0,
        fleetUsageTrend: 'Stable',
        mostUsedUtilizationPct: 0,
        leastUsedUtilizationPct: 0,
      },
      thresholdsApplied: thresholds,
      environments: [],
      timeSeriesTrend: [],
      applicationDemandInsights: [],
      recommendations: [],
    };
  },
};
