import { ServerDetail, SoftwareDetail, EnvironmentProfile } from '../types/environmentDetails';
import { fetchApi, fetchApiStrict } from './apiClient';
import { authService } from './authService';

const SERVERS_STORAGE_KEY = 'smartqe_tem_servers_v3';
const SOFTWARE_STORAGE_KEY = 'smartqe_tem_software_v3';
const PROFILES_STORAGE_KEY = 'smartqe_tem_env_profiles_v3';

export const INITIAL_SERVERS: ServerDetail[] = [];

export const INITIAL_SOFTWARE: SoftwareDetail[] = [];

export const INITIAL_ENVIRONMENT_PROFILES: EnvironmentProfile[] = [];

export const environmentDetailsService = {
  getServers(): ServerDetail[] {
    const sessionUser = authService.getCurrentSessionUser();
    const isSuperAdmin = sessionUser?.isSuperAdmin || sessionUser?.username?.toLowerCase() === 'admin';
    const keys = [SERVERS_STORAGE_KEY, 'smartqe_tem_servers_v2', 'smartqe_tem_servers_v1'];
    const serverMap = new Map<string, ServerDetail>();

    // 1. Seed baseline servers ONLY for Super Admin or matching creator
    if (isSuperAdmin) {
      INITIAL_SERVERS.forEach((s) => serverMap.set(s.id, { ...s, isActive: s.isActive !== false }));
    } else if (sessionUser) {
      INITIAL_SERVERS.forEach((s) => {
        if (
          s.createdBy?.toLowerCase() === sessionUser.username.toLowerCase() ||
          s.createdBy?.toLowerCase() === sessionUser.fullName?.toLowerCase()
        ) {
          serverMap.set(s.id, { ...s, isActive: s.isActive !== false });
        }
      });
    }

    // 2. Load from storage versions
    for (const key of keys) {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            parsed.forEach((s: ServerDetail) => {
              if (s && s.id) {
                if (isSuperAdmin) {
                  serverMap.set(s.id, { ...s, isActive: s.isActive !== false });
                } else if (sessionUser) {
                  const sOwner = (s as any).ownerId || '';
                  const sCreatedBy = (s.createdBy || '').toLowerCase();
                  if (
                    sOwner === sessionUser.id ||
                    sCreatedBy === sessionUser.username.toLowerCase() ||
                    sCreatedBy === sessionUser.fullName?.toLowerCase()
                  ) {
                    serverMap.set(s.id, { ...s, isActive: s.isActive !== false });
                  }
                }
              }
            });
          }
        } catch (e) {}
      }
    }

    return Array.from(serverMap.values());
  },

  async fetchServers(): Promise<ServerDetail[]> {
    return this.getServers();
  },

  async createServer(serverData: Omit<ServerDetail, 'id'>): Promise<ServerDetail> {
    const sessionUser = authService.getCurrentSessionUser();
    const newServer: ServerDetail = {
      ...serverData,
      isActive: serverData.isActive !== false,
      id: `srv-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      createdBy: sessionUser?.fullName || sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id,
    } as any;
    const current = this.getServers();
    const updated = [newServer, ...current.filter(s => s.id !== newServer.id)];
    this.saveServers(updated);
    return newServer;
  },

  async updateServer(id: string, serverData: Partial<ServerDetail>): Promise<void> {
    const current = this.getServers();
    const updated = current.map((s) =>
      s.id === id
        ? {
            ...s,
            ...serverData,
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          }
        : s
    );
    this.saveServers(updated);
  },

  async toggleServer(id: string): Promise<ServerDetail[]> {
    const current = this.getServers();
    const updated = current.map((s) =>
      s.id === id
        ? { ...s, isActive: !(s.isActive !== false), updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) }
        : s
    );
    this.saveServers(updated);
    return updated;
  },

  async deleteServer(id: string): Promise<void> {
    const current = this.getServers();
    const updated = current.map((s) => (s.id === id ? { ...s, isActive: false } : s));
    this.saveServers(updated);
  },

  saveServers(servers: ServerDetail[]): void {
    const sanitized = servers.map((s) => ({
      ...s,
      isActive: s.isActive !== false,
    }));
    try {
      localStorage.setItem(SERVERS_STORAGE_KEY, JSON.stringify(sanitized));
    } catch {}
  },

  // SOFTWARE
  getSoftware(): SoftwareDetail[] {
    const sessionUser = authService.getCurrentSessionUser();
    const isSuperAdmin = sessionUser?.isSuperAdmin || sessionUser?.username?.toLowerCase() === 'admin';
    const keys = [SOFTWARE_STORAGE_KEY, 'smartqe_tem_software_v2', 'smartqe_tem_software_v1'];
    const softMap = new Map<string, SoftwareDetail>();

    // 1. Seed baseline software ONLY for Super Admin or matching creator
    if (isSuperAdmin) {
      INITIAL_SOFTWARE.forEach((s) => softMap.set(s.id, { ...s, isActive: s.isActive !== false }));
    } else if (sessionUser) {
      INITIAL_SOFTWARE.forEach((s) => {
        if (
          s.createdBy?.toLowerCase() === sessionUser.username.toLowerCase() ||
          s.createdBy?.toLowerCase() === sessionUser.fullName?.toLowerCase()
        ) {
          softMap.set(s.id, { ...s, isActive: s.isActive !== false });
        }
      });
    }

    // 2. Load from storage versions
    for (const key of keys) {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            parsed.forEach((s: SoftwareDetail) => {
              if (s && s.id) {
                if (isSuperAdmin) {
                  softMap.set(s.id, { ...s, isActive: s.isActive !== false });
                } else if (sessionUser) {
                  const sOwner = (s as any).ownerId || '';
                  const sCreatedBy = (s.createdBy || '').toLowerCase();
                  if (
                    sOwner === sessionUser.id ||
                    sCreatedBy === sessionUser.username.toLowerCase() ||
                    sCreatedBy === sessionUser.fullName?.toLowerCase()
                  ) {
                    softMap.set(s.id, { ...s, isActive: s.isActive !== false });
                  }
                }
              }
            });
          }
        } catch (e) {}
      }
    }

    return Array.from(softMap.values());
  },

  async fetchSoftware(): Promise<SoftwareDetail[]> {
    return this.getSoftware();
  },

  async createSoftware(softwareData: Omit<SoftwareDetail, 'id'>): Promise<SoftwareDetail> {
    const sessionUser = authService.getCurrentSessionUser();
    const newSoftware: SoftwareDetail = {
      ...softwareData,
      isActive: softwareData.isActive !== false,
      id: `soft-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      createdBy: sessionUser?.fullName || sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id,
    } as any;
    const current = this.getSoftware();
    const updated = [newSoftware, ...current.filter(s => s.id !== newSoftware.id)];
    this.saveSoftware(updated);
    return newSoftware;
  },

  async updateSoftware(id: string, softwareData: Partial<SoftwareDetail>): Promise<void> {
    const current = this.getSoftware();
    const updated = current.map((s) =>
      s.id === id
        ? {
            ...s,
            ...softwareData,
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          }
        : s
    );
    this.saveSoftware(updated);
  },

  async toggleSoftware(id: string): Promise<SoftwareDetail[]> {
    const current = this.getSoftware();
    const updated = current.map((s) =>
      s.id === id
        ? { ...s, isActive: !(s.isActive !== false), updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) }
        : s
    );
    this.saveSoftware(updated);
    return updated;
  },

  async deleteSoftware(id: string): Promise<void> {
    const current = this.getSoftware();
    const updated = current.map((s) => (s.id === id ? { ...s, isActive: false } : s));
    this.saveSoftware(updated);
  },

  saveSoftware(software: SoftwareDetail[]): void {
    const sanitized = software.map((s) => ({
      ...s,
      isActive: s.isActive !== false,
    }));
    try {
      localStorage.setItem(SOFTWARE_STORAGE_KEY, JSON.stringify(sanitized));
    } catch {}
  },

  // ENVIRONMENT PROFILES
  getProfiles(): EnvironmentProfile[] {
    return this.getAllProfiles();
  },

  getAllProfiles(): EnvironmentProfile[] {
    const keys = [PROFILES_STORAGE_KEY, 'smartqe_tem_env_profiles_v2', 'smartqe_tem_env_profiles_v1'];
    const profileMap = new Map<string, EnvironmentProfile>();

    // Seed baseline profiles
    INITIAL_ENVIRONMENT_PROFILES.forEach((p) => profileMap.set(p.id, { ...p, isActive: p.isActive !== false }));

    for (const key of keys) {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            parsed.forEach((p: EnvironmentProfile) => {
              if (p && p.id) {
                profileMap.set(p.id, { ...p, isActive: p.isActive !== false });
              }
            });
          }
        } catch (e) {}
      }
    }

    return Array.from(profileMap.values());
  },

  async fetchProfiles(): Promise<EnvironmentProfile[]> {
    try {
      const apiData = await fetchApi<any[]>('/environment-profiles');
      if (apiData && Array.isArray(apiData)) {
        const profiles: EnvironmentProfile[] = apiData.map((p) => ({
          id: p.id,
          name: p.name,
          type: p.type,
          description: p.description || '',
          status: p.status,
          isActive: p.isActive !== undefined ? Boolean(p.isActive) : (p.is_active !== undefined ? (p.is_active !== null ? Boolean(p.is_active) : true) : true),
          ownerTeam: p.ownerTeam || p.owner_team || '',
          networkZone: p.networkZone || p.network_zone || '',
          serverIds: p.serverIds || p.server_ids || [],
          softwareIds: p.softwareIds || p.software_ids || [],
          createdBy: p.createdBy || p.created_by,
          ownerId: p.ownerId || p.owner_id,
          updatedAt: p.updatedAt || p.updated_at
            ? new Date(p.updatedAt || p.updated_at).toISOString().replace('T', ' ').substring(0, 19)
            : new Date().toISOString().replace('T', ' ').substring(0, 19),
        }));
        this.saveProfiles(profiles);
        return profiles;
      }
    } catch (e) {
      console.warn('Failed to fetch environment profiles from API, using cached state', e);
    }
    return this.getAllProfiles();
  },

  async createProfile(profileData: Omit<EnvironmentProfile, 'id' | 'updatedAt'>): Promise<EnvironmentProfile> {
    const sessionUser = authService.getCurrentSessionUser();
    const apiData = await fetchApi<any>('/environment-profiles', {
      method: 'POST',
      body: JSON.stringify({
        name: profileData.name,
        type: profileData.type,
        description: profileData.description,
        status: profileData.status,
        isActive: profileData.isActive !== false,
        ownerTeam: profileData.ownerTeam,
        networkZone: profileData.networkZone,
        serverIds: profileData.serverIds,
        softwareIds: profileData.softwareIds,
      }),
    });

    if (apiData) {
      const created: EnvironmentProfile = {
        id: apiData.id,
        name: apiData.name,
        type: apiData.type,
        description: apiData.description || '',
        status: apiData.status,
        isActive: apiData.isActive !== undefined ? apiData.isActive : (apiData.is_active !== undefined ? apiData.is_active : true),
        ownerTeam: apiData.ownerTeam || apiData.owner_team || '',
        networkZone: apiData.networkZone || apiData.network_zone || '',
        serverIds: apiData.serverIds || apiData.server_ids || [],
        softwareIds: apiData.softwareIds || apiData.software_ids || [],
        createdBy: apiData.createdBy || apiData.created_by || sessionUser?.username || 'Super Admin',
        ownerId: apiData.ownerId || apiData.owner_id || sessionUser?.id,
        updatedAt: apiData.updatedAt || apiData.updated_at
          ? new Date(apiData.updatedAt || apiData.updated_at).toISOString().replace('T', ' ').substring(0, 19)
          : new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
      this.saveProfiles([created]);
      return created;
    }

    const newProfile: EnvironmentProfile = {
      ...profileData,
      isActive: profileData.isActive !== false,
      id: `env-prof-${Date.now().toString().slice(-4)}`,
      createdBy: sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id,
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    } as any;
    this.saveProfiles([newProfile]);
    return newProfile;
  },

  async updateProfile(id: string, profileData: Partial<EnvironmentProfile>): Promise<void> {
    await fetchApi(`/environment-profiles/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: profileData.name,
        type: profileData.type,
        description: profileData.description,
        status: profileData.status,
        isActive: profileData.isActive,
        ownerTeam: profileData.ownerTeam,
        networkZone: profileData.networkZone,
        serverIds: profileData.serverIds,
        softwareIds: profileData.softwareIds,
      }),
    });
  },

  async toggleProfile(id: string): Promise<EnvironmentProfile[]> {
    const current = this.getProfiles();
    const target = current.find((p) => p.id === id);
    if (!target) return current;

    const newActive = !(target.isActive !== false);
    try {
      await fetchApiStrict(`/environment-profiles/${id}/toggle-status`, {
        method: 'PATCH',
      });
    } catch (err: any) {
      if (err.message && !err.message.includes('Failed to fetch') && !err.message.includes('NetworkError')) {
        throw err;
      }
    }

    const updated = current.map((p) =>
      p.id === id
        ? { ...p, isActive: newActive, updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) }
        : p
    );
    this.saveProfiles(updated);
    return updated;
  },

  async deleteProfile(id: string): Promise<void> {
    try {
      await fetchApi(`/environment-profiles/${id}`, {
        method: 'DELETE',
      });
    } catch {}
    const current = this.getProfiles();
    const updated = current.map((p) => (p.id === id ? { ...p, isActive: false } : p));
    this.saveProfiles(updated);
  },

  saveProfiles(profiles: EnvironmentProfile[]): void {
    const keys = [PROFILES_STORAGE_KEY, 'smartqe_tem_env_profiles_v2', 'smartqe_tem_env_profiles_v1'];
    const profileMap = new Map<string, EnvironmentProfile>();
    INITIAL_ENVIRONMENT_PROFILES.forEach((p) => profileMap.set(p.id, { ...p, isActive: p.isActive !== false }));
    for (const key of keys) {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            parsed.forEach((p: EnvironmentProfile) => {
              if (p && p.id) profileMap.set(p.id, { ...p, isActive: p.isActive !== false });
            });
          }
        } catch (e) {}
      }
    }
    profiles.forEach((p) => {
      if (p && p.id) profileMap.set(p.id, { ...p, isActive: p.isActive !== false });
    });

    try {
      localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(Array.from(profileMap.values())));
    } catch {}
  }
};
