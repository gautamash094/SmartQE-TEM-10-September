import { Booking, Release, Environment, Incident } from '../types';
import { EnvironmentProfile } from '../types/environmentDetails';
import { ReleaseCalendarPhase, ReleaseCalendarRelease } from '../types/releaseCalendar';

export interface PhaseReservationCheckResult {
  isReserved: boolean;
  reservationStatus: 'RESERVED' | 'NOT_RESERVED' | 'MULTIPLE_RESERVED';
  matchedBookings: Booking[];
  primaryBooking?: Booking;
  reservedEnvironmentNames: string[];
  reservedEnvironmentIds: string[];
}

export interface EnvironmentRecommendationItem {
  environmentId: string;
  environmentName: string;
  environmentType: string;
  status: 'HEALTHY' | 'DEGRADED' | 'DOWN' | 'MAINTENANCE';
  isAvailable: boolean;
  compatibilityScore: number; // 0 - 100
  reasons: string[];
  availablePeriod: string;
  matchedApplication: boolean;
  matchedProjectBU: boolean;
  matchedType: boolean;
  existingBookingsCount: number;
}

export interface ConflictingEnvironmentItem {
  environmentId: string;
  environmentName: string;
  environmentType: string;
  status: string;
  conflictStartDate: string;
  conflictEndDate: string;
  conflictingBookingId?: string;
  conflictingPurpose?: string;
  conflictingRequestedBy?: string;
}

export interface PhaseRecommendationAnalysis {
  releaseId: string;
  releaseName: string;
  version?: string;
  phaseId: string;
  phaseName: string;
  applicationName?: string;
  businessUnit?: string;
  projectName?: string;
  startDate: string;
  endDate: string;
  reservationCheck: PhaseReservationCheckResult;
  recommendedEnvironments: EnvironmentRecommendationItem[];
  conflictingEnvironments: ConflictingEnvironmentItem[];
  hasAvailableRecommendation: boolean;
  summaryMessage: string;
}

/**
 * Normalizes date string to epoch ms for reliable comparison
 */
const parseDateMs = (dStr?: string): number => {
  if (!dStr) return 0;
  const isoStr = String(dStr).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d.getTime();
  const raw = new Date(dStr);
  return isNaN(raw.getTime()) ? 0 : raw.getTime();
};

/**
 * Format human-readable date
 */
const formatReadableDate = (dStr?: string) => {
  if (!dStr) return '';
  try {
    const d = new Date(dStr);
    return d.toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' });
  } catch {
    return dStr;
  }
};

class EnvironmentRecommendationService {
  /**
   * Checks if an environment has already been reserved for a specific Release + Phase
   */
  public checkPhaseReservation(
    release: { id?: string; releaseId?: string; name?: string; releaseName?: string; application?: string; applicationName?: string },
    phase: { id?: string; phaseId?: string; phaseName: string; testPhaseId?: string; startDate?: string; endDate?: string },
    bookings: Booking[]
  ): PhaseReservationCheckResult {
    const relId = release.releaseId || release.id || '';
    const relName = (release.releaseName || release.name || '').toLowerCase().trim();
    const phId = phase.phaseId || phase.id || '';
    const phTestId = phase.testPhaseId || '';
    const phName = (phase.phaseName || '').toLowerCase().trim();

    const phStartMs = parseDateMs(phase.startDate);
    const phEndMs = parseDateMs(phase.endDate);

    // Filter active bookings (exclude rejected, cancelled, auto-rejected)
    const activeBookings = bookings.filter(
      (b) =>
        b.status !== 'CANCELLED' &&
        b.status !== 'REJECTED' &&
        b.status !== 'AUTO_REJECTED'
    );

    const matchedBookings = activeBookings.filter((b) => {
      // Direct Release Match
      const matchesRelease =
        (relId && b.releaseId === relId) ||
        (relName && (b.releaseName || '').toLowerCase().trim() === relName);

      // Direct Phase Match
      const matchesPhase =
        (phId && (b.releasePhaseId === phId || b.testPhaseId === phId)) ||
        (phTestId && (b.testPhaseId === phTestId || b.releasePhaseId === phTestId)) ||
        (phName && (b.testPhaseName || '').toLowerCase().trim() === phName);

      if (matchesRelease && matchesPhase) {
        return true;
      }

      // If release matches and booking dates substantially overlap with phase dates
      if (matchesRelease && phStartMs > 0 && phEndMs > 0 && b.startDate && b.endDate) {
        const bStartMs = parseDateMs(b.startDate);
        const bEndMs = parseDateMs(b.endDate);
        if (bStartMs < phEndMs && bEndMs > phStartMs) {
          return true;
        }
      }

      return false;
    });

    const envNames = Array.from(
      new Set(matchedBookings.map((b) => b.environmentName || b.environmentId).filter(Boolean))
    );
    const envIds = Array.from(
      new Set(matchedBookings.map((b) => b.environmentId).filter(Boolean))
    );

    const isReserved = matchedBookings.length > 0;
    const reservationStatus: 'RESERVED' | 'NOT_RESERVED' | 'MULTIPLE_RESERVED' =
      matchedBookings.length > 1
        ? 'MULTIPLE_RESERVED'
        : matchedBookings.length === 1
        ? 'RESERVED'
        : 'NOT_RESERVED';

    return {
      isReserved,
      reservationStatus,
      matchedBookings,
      primaryBooking: matchedBookings[0],
      reservedEnvironmentNames: envNames,
      reservedEnvironmentIds: envIds,
    };
  }

  /**
   * Analyzes all environment profiles against the phase period, application, and project
   * to recommend available environments and flag conflicting ones with explainable reasons.
   */
  public getEnvironmentRecommendations(
    release: ReleaseCalendarRelease | Release,
    phase: ReleaseCalendarPhase | { id?: string; phaseId?: string; phaseName: string; testPhaseId?: string; startDate?: string; endDate?: string },
    profiles: EnvironmentProfile[],
    bookings: Booking[],
    environments: Environment[] = [],
    incidents: Incident[] = []
  ): PhaseRecommendationAnalysis {
    const relId = (release as any).releaseId || (release as any).id || '';
    const relName = (release as any).releaseName || (release as any).name || 'Unnamed Release';
    const version = (release as any).version || 'v1.0.0';
    const appName = (release as any).applicationName || (release as any).application || '';
    const buName = (release as any).businessUnit || '';
    const projName = (release as any).projectName || (release as any).project || '';

    const phId = (phase as any).phaseId || (phase as any).id || '';
    const phName = phase.phaseName || 'Phase';
    const startDate = phase.startDate || (release as any).startDate || '';
    const endDate = phase.endDate || (release as any).endDate || '';

    const reqStartMs = parseDateMs(startDate);
    const reqEndMs = parseDateMs(endDate);

    // 1. Check if already reserved
    const reservationCheck = this.checkPhaseReservation(release, phase, bookings);

    const activeBookings = bookings.filter(
      (b) =>
        b.status !== 'CANCELLED' &&
        b.status !== 'REJECTED' &&
        b.status !== 'AUTO_REJECTED'
    );

    const recommendedList: EnvironmentRecommendationItem[] = [];
    const conflictingList: ConflictingEnvironmentItem[] = [];

    // Derive effective candidate list from profiles & environments
    const candidateEnvs: Array<{
      id: string;
      name: string;
      type: string;
      status: 'HEALTHY' | 'DEGRADED' | 'DOWN' | 'MAINTENANCE';
      businessUnit?: string;
      project?: string;
      application?: string;
      associatedApps?: string[];
    }> = [];

    const seenIds = new Set<string>();

    profiles.forEach((p) => {
      const pAny = p as any;
      seenIds.add(p.id);
      candidateEnvs.push({
        id: p.id,
        name: p.name,
        type: String(p.type || 'SIT'),
        status: (p.status as any) || 'HEALTHY',
        businessUnit: pAny.businessUnit,
        project: pAny.project,
        application: pAny.application,
        associatedApps: pAny.associatedApps || (pAny.application ? [pAny.application] : []),
      });
    });

    environments.forEach((e) => {
      const eAny = e as any;
      if (!seenIds.has(e.id)) {
        seenIds.add(e.id);
        candidateEnvs.push({
          id: e.id,
          name: e.name,
          type: String(e.tier || eAny.type || 'SIT'),
          status: e.status === 'HEALTHY' ? 'HEALTHY' : e.status === 'DEGRADED' ? 'DEGRADED' : 'DOWN',
          businessUnit: eAny.businessUnit,
          project: eAny.project,
          application: eAny.application,
          associatedApps: eAny.associatedApps || (eAny.application ? [eAny.application] : []),
        });
      }
    });

    // Determine target phase type (e.g. SIT, QA, UAT, PERF, PROD)
    const normalizedPhase = phName.toUpperCase();

    candidateEnvs.forEach((env) => {
      // Exclude totally offline/DOWN environments
      if (env.status === 'DOWN') {
        return;
      }

      // 2. Check for overlapping bookings on this environment
      const envOverlaps = activeBookings.filter((b) => {
        const isSameEnv =
          b.environmentId === env.id ||
          (b.environmentName && b.environmentName.toLowerCase() === env.name.toLowerCase());
        if (!isSameEnv || !b.startDate || !b.endDate) return false;

        const bStartMs = parseDateMs(b.startDate);
        const bEndMs = parseDateMs(b.endDate);

        if (reqStartMs > 0 && reqEndMs > 0) {
          return reqStartMs < bEndMs && reqEndMs > bStartMs;
        }
        return false;
      });

      if (envOverlaps.length > 0) {
        // Environment has booking collision during phase dates
        const primaryCollision = envOverlaps[0];
        conflictingList.push({
          environmentId: env.id,
          environmentName: env.name,
          environmentType: env.type,
          status: env.status,
          conflictStartDate: primaryCollision.startDate,
          conflictEndDate: primaryCollision.endDate,
          conflictingBookingId: primaryCollision.id,
          conflictingPurpose: primaryCollision.purpose,
          conflictingRequestedBy: primaryCollision.requestedBy,
        });
      } else {
        // Environment is 100% available during this phase window!
        // 3. Compute Compatibility & Reasons
        let score = 70;
        const reasons: string[] = [];

        // Reason 1: Full phase availability
        reasons.push(`Available for the complete ${phName} phase window (${formatReadableDate(startDate)} – ${formatReadableDate(endDate)}).`);
        reasons.push('No conflicting reservations or scheduled locks detected.');

        // Reason 2: Application match
        let matchedApp = false;
        if (appName) {
          const appMatch =
            (env.application && env.application.toLowerCase() === appName.toLowerCase()) ||
            (env.associatedApps && env.associatedApps.some((a) => a.toLowerCase() === appName.toLowerCase()));

          if (appMatch) {
            score += 15;
            matchedApp = true;
            reasons.push(`Compatible & pre-configured for the "${appName}" application.`);
          }
        }

        // Reason 3: Project / Business Unit match
        let matchedProjBU = false;
        if (buName && env.businessUnit && env.businessUnit.toLowerCase() === buName.toLowerCase()) {
          score += 5;
          matchedProjBU = true;
          reasons.push(`Aligned with ${buName} Business Unit.`);
        }
        if (projName && env.project && env.project.toLowerCase() === projName.toLowerCase()) {
          score += 5;
          matchedProjBU = true;
          reasons.push(`Designated for ${projName} project.`);
        }

        // Reason 4: Environment Type / Tier Match
        let matchedType = false;
        const envTypeUpper = (env.type || '').toUpperCase();
        if (
          (normalizedPhase.includes('SIT') && envTypeUpper.includes('SIT')) ||
          (normalizedPhase.includes('QA') && (envTypeUpper.includes('QA') || envTypeUpper.includes('TEST'))) ||
          (normalizedPhase.includes('UAT') && envTypeUpper.includes('UAT')) ||
          (normalizedPhase.includes('DEV') && envTypeUpper.includes('DEV')) ||
          (normalizedPhase.includes('PERF') && (envTypeUpper.includes('PERF') || envTypeUpper.includes('STAGE'))) ||
          (normalizedPhase.includes('PROD') && envTypeUpper.includes('PROD'))
        ) {
          score += 10;
          matchedType = true;
          reasons.push(`Dedicated ${env.type} environment type suited for ${phName} test execution.`);
        } else {
          reasons.push(`Operational ${env.type} tier environment.`);
        }

        // Reason 5: Health Status
        if (env.status === 'HEALTHY') {
          score += 5;
          reasons.push('Environment status is Healthy with 100% telemetry online.');
        } else if (env.status === 'DEGRADED') {
          score -= 10;
          reasons.push('Note: Environment health is currently Degraded.');
        }

        score = Math.max(50, Math.min(99, score));

        // Count total existing bookings for historical context
        const existingCount = activeBookings.filter(
          (b) => b.environmentId === env.id || b.environmentName?.toLowerCase() === env.name.toLowerCase()
        ).length;

        recommendedList.push({
          environmentId: env.id,
          environmentName: env.name,
          environmentType: env.type,
          status: env.status,
          isAvailable: true,
          compatibilityScore: score,
          reasons,
          availablePeriod: `${formatReadableDate(startDate)} – ${formatReadableDate(endDate)}`,
          matchedApplication: matchedApp,
          matchedProjectBU: matchedProjBU,
          matchedType: matchedType,
          existingBookingsCount: existingCount,
        });
      }
    });

    // Sort recommendations: highest compatibility score first, then matching type
    recommendedList.sort((a, b) => {
      if (b.compatibilityScore !== a.compatibilityScore) {
        return b.compatibilityScore - a.compatibilityScore;
      }
      return (b.matchedType ? 1 : 0) - (a.matchedType ? 1 : 0);
    });

    const hasAvailable = recommendedList.length > 0;
    let summaryMessage = '';
    if (reservationCheck.isReserved) {
      summaryMessage = `Environment already reserved (${reservationCheck.reservedEnvironmentNames.join(', ')}).`;
    } else if (hasAvailable) {
      summaryMessage = `No environment reserved. ${recommendedList.length} compatible environment(s) available for booking.`;
    } else {
      summaryMessage = `No environment reserved. No suitable environment is currently available for this Release Phase.`;
    }

    return {
      releaseId: relId,
      releaseName: relName,
      version,
      phaseId: phId,
      phaseName: phName,
      applicationName: appName,
      businessUnit: buName,
      projectName: projName,
      startDate,
      endDate,
      reservationCheck,
      recommendedEnvironments: recommendedList,
      conflictingEnvironments: conflictingList,
      hasAvailableRecommendation: hasAvailable,
      summaryMessage,
    };
  }
}

export const environmentRecommendationService = new EnvironmentRecommendationService();
