import React from 'react';
import { Booking } from '../../types';
import { useTEM } from '../../context/TEMContext';
import {
  Clock,
  AlertTriangle,
  Zap,
  Users,
  CheckCircle2,
  Ban
} from 'lucide-react';
import { getBookingColorStyle, getModeBadgeStyle } from './bookingColorHelper';

interface MonthlyViewProps {
  currentDate: Date;
  bookings: Booking[];
  conflictMap: Map<string, string[]>;
  onSelectBooking: (booking: Booking) => void;
}

const safeParseDate = (dateVal: string | Date | undefined | null): Date | null => {
  if (!dateVal) return null;
  if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
  const isoStr = String(dateVal).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d;
  const dRaw = new Date(dateVal);
  return isNaN(dRaw.getTime()) ? null : dRaw;
};

export const MonthlyView: React.FC<MonthlyViewProps> = ({
  currentDate,
  bookings,
  conflictMap,
  onSelectBooking,
}) => {
  const { getTestPhaseColor } = useTEM();
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const startDayOfWeek = (firstDayOfMonth.getDay() + 6) % 7;
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const calendarCells: { date: Date; isCurrentMonth: boolean; key: string }[] = [];

  for (let i = startDayOfWeek - 1; i >= 0; i--) {
    const d = new Date(year, month - 1, daysInPrevMonth - i);
    calendarCells.push({
      date: d,
      isCurrentMonth: false,
      key: `prev-${i}`,
    });
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const curr = new Date(year, month, d);
    calendarCells.push({
      date: curr,
      isCurrentMonth: true,
      key: `curr-${d}`,
    });
  }

  const totalCellsNeeded = calendarCells.length > 35 ? 42 : 35;
  const remainingCells = totalCellsNeeded - calendarCells.length;
  for (let d = 1; d <= remainingCells; d++) {
    const next = new Date(year, month + 1, d);
    calendarCells.push({
      date: next,
      isCurrentMonth: false,
      key: `next-${d}`,
    });
  }

  const isSameDay = (d1: Date, d2: Date) => {
    return (
      d1.getFullYear() === d2.getFullYear() &&
      d1.getMonth() === d2.getMonth() &&
      d1.getDate() === d2.getDate()
    );
  };

  const isToday = (d: Date) => isSameDay(d, new Date());

  const dayHeaders = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const weeks: { date: Date; isCurrentMonth: boolean; key: string }[][] = [];
  for (let i = 0; i < calendarCells.length; i += 7) {
    weeks.push(calendarCells.slice(i, i + 7));
  }

  const formatShortRange = (sStr: string, eStr: string) => {
    try {
      const s = safeParseDate(sStr);
      const e = safeParseDate(eStr);
      if (!s || !e) return '';
      const sM = s.toLocaleString('default', { month: 'short' });
      const eM = e.toLocaleString('default', { month: 'short' });
      if (sM === eM && s.getDate() === e.getDate()) {
        return `${sM} ${s.getDate()}`;
      }
      if (sM === eM) return `${sM} ${s.getDate()}–${e.getDate()}`;
      return `${sM} ${s.getDate()} – ${eM} ${e.getDate()}`;
    } catch {
      return '';
    }
  };

  return (
    <div className="bg-[#0b1019] border border-slate-800 rounded-xl overflow-hidden shadow-2xl font-mono text-xs w-full">
      {/* 7-Day Header Grid */}
      <div className="grid grid-cols-7 border-b border-slate-800 bg-[#090d14] text-center font-bold text-slate-400 py-3 text-[11px] uppercase tracking-wider divide-x divide-slate-800/80">
        {dayHeaders.map((dayName, idx) => (
          <div key={idx} className="px-2">
            <span className="hidden sm:inline">{dayName}</span>
            <span className="sm:hidden">{dayName.slice(0, 3)}</span>
          </div>
        ))}
      </div>

      {/* Monthly Grid */}
      <div className="bg-[#080d14] p-3 space-y-3">
        {weeks.map((weekCells, wIdx) => {
          const weekStartMs = new Date(weekCells[0].date).setHours(0, 0, 0, 0);
          const weekEndMs = new Date(weekCells[6].date).setHours(23, 59, 59, 999);

          const weekBookings = (bookings || []).filter((b) => {
            const sDate = safeParseDate(b.startDate);
            const eDate = safeParseDate(b.endDate);
            if (!sDate || !eDate) return false;
            return sDate.getTime() <= weekEndMs && eDate.getTime() >= weekStartMs;
          });

          return (
            <div key={wIdx} className="border border-slate-800/80 rounded-xl bg-[#070a10] overflow-hidden shadow-sm">
              {/* Date Header Row across 7 columns */}
              <div className="grid grid-cols-7 divide-x divide-slate-800/50 bg-[#090d14]/80 py-2 border-b border-slate-800/60">
                {weekCells.map((cell) => {
                  const today = isToday(cell.date);

                  return (
                    <div
                      key={cell.key}
                      className={`px-2 text-center flex flex-col items-center justify-center relative ${
                        !cell.isCurrentMonth
                          ? 'opacity-30 bg-slate-900/30'
                          : today
                          ? 'bg-orange-950/30'
                          : ''
                      }`}
                    >
                      {today && (
                        <span className="text-[8px] uppercase tracking-wider font-black text-orange-400 bg-orange-950/80 px-1 py-0.2 rounded border border-orange-800/80">
                          TODAY
                        </span>
                      )}
                      <span
                        className={`text-sm font-extrabold mt-0.5 ${
                          today
                            ? 'text-orange-400 font-black'
                            : cell.isCurrentMonth
                            ? 'text-slate-200'
                            : 'text-slate-600'
                        }`}
                      >
                        {cell.date.getDate()}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Grid Body */}
              <div className="relative p-2 min-h-[110px] bg-[#070b12]">
                <div className="absolute inset-0 grid grid-cols-7 pointer-events-none divide-x divide-slate-800/40">
                  {weekCells.map((_, i) => (
                    <div key={i} className="h-full" />
                  ))}
                </div>

                <div className="relative z-10 space-y-1.5">
                  {weekBookings.length === 0 ? (
                    <div className="text-slate-700 text-[10px] italic text-center py-6">
                      No scheduled allocations for this week
                    </div>
                  ) : (
                    weekBookings.map((b) => {
                      const bStart = safeParseDate(b.startDate) || new Date();
                      const bEnd = safeParseDate(b.endDate) || bStart;

                      let startIndex = weekCells.findIndex((c) => isSameDay(c.date, bStart));
                      if (startIndex === -1) {
                        startIndex = bStart.getTime() < weekStartMs ? 0 : 6;
                      }

                      let endIndex = weekCells.findIndex((c) => isSameDay(c.date, bEnd));
                      if (endIndex === -1) {
                        endIndex = bEnd.getTime() > weekEndMs ? 6 : startIndex;
                      }

                      const colStart = Math.max(1, Math.min(7, startIndex + 1));
                      const rawSpan = Math.max(1, endIndex - startIndex + 1);
                      const maxAllowedSpan = 7 - colStart + 1;
                      const colSpan = Math.max(1, Math.min(maxAllowedSpan, rawSpan));
                      const isConflict = conflictMap.has(b.id);
                      const colorStyle = getBookingColorStyle(b, isConflict);
                      const modeBadge = getModeBadgeStyle(b.reservationMode);

                      return (
                        <div key={b.id} className="grid grid-cols-7">
                          <div
                            style={{
                              gridColumn: `${colStart} / span ${colSpan}`,
                            }}
                            onClick={() => onSelectBooking(b)}
                            title={`${b.purpose}\nEnvironment: ${b.environmentName || b.application}\nMode: ${b.reservationMode}\nStatus: ${b.status}\nDates: ${formatShortRange(b.startDate, b.endDate)}`}
                            className={`h-9 px-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between gap-1.5 overflow-hidden min-w-0 group hover:scale-[1.005] hover:brightness-110 ${colorStyle.containerClass}`}
                          >
                            <div className="flex items-center gap-1.5 min-w-0 truncate">
                              {colorStyle.iconType === 'conflict' ? (
                                <AlertTriangle className={`w-3.5 h-3.5 ${colorStyle.iconColorClass} shrink-0`} />
                              ) : colorStyle.iconType === 'cancelled' ? (
                                <Ban className={`w-3.5 h-3.5 ${colorStyle.iconColorClass} shrink-0`} />
                              ) : colorStyle.iconType === 'rejected' ? (
                                <AlertTriangle className={`w-3.5 h-3.5 ${colorStyle.iconColorClass} shrink-0`} />
                              ) : colorStyle.iconType === 'pending' ? (
                                <Clock className={`w-3.5 h-3.5 ${colorStyle.iconColorClass} shrink-0`} />
                              ) : colorStyle.iconType === 'disruptive' ? (
                                <Zap className={`w-3.5 h-3.5 ${colorStyle.iconColorClass} shrink-0`} />
                              ) : colorStyle.iconType === 'approved' ? (
                                <CheckCircle2 className={`w-3.5 h-3.5 ${colorStyle.iconColorClass} shrink-0`} />
                              ) : (
                                <Users className={`w-3.5 h-3.5 ${colorStyle.iconColorClass} shrink-0`} />
                              )}
                              <span className={`text-xs truncate font-medium ${colorStyle.titleClass}`}>
                                {b.purpose}
                              </span>
                              {(b.testPhaseName || b.testPhaseId) && (
                                <span
                                  className="inline-flex items-center px-1.5 py-0.2 rounded text-[7.5px] font-bold text-white shadow-sm shrink-0"
                                  style={{ backgroundColor: getTestPhaseColor(b.testPhaseName || b.testPhaseId) }}
                                >
                                  {b.testPhaseName || b.testPhaseId}
                                </span>
                              )}
                              {colSpan >= 3 && (
                                <span className={`text-[10px] font-sans truncate ${colorStyle.subtextClass}`}>
                                  ({b.application || b.environmentName}{b.releaseName ? ` • ${b.releaseName}` : ''})
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-1 shrink-0 text-[10px] font-mono font-bold">
                              {/* Status Badge */}
                              <span className={`text-[8px] px-1.5 py-0.5 rounded border uppercase flex items-center gap-1 ${colorStyle.statusBadge.badgeClass}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${colorStyle.statusBadge.dotClass} shrink-0`} />
                                {colorStyle.statusBadge.label}
                              </span>

                              {/* Mode Badge - Solid Orange for Disruptive, Solid Cyan for Shared */}
                              <span className={`text-[8px] px-1.5 py-0.5 rounded border uppercase ${modeBadge.badgeClass}`}>
                                {colSpan === 1 ? (b.reservationMode === 'DISRUPTIVE' ? '⚡' : '👥') : modeBadge.label}
                              </span>

                              {/* Date Range - displayed when span is 2 or more columns */}
                              {colSpan >= 2 && (
                                <span className={`px-1.5 py-0.5 rounded border text-[8px] whitespace-nowrap ${colorStyle.tagClass}`}>
                                  {formatShortRange(b.startDate, b.endDate)}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
