import React, { useMemo } from 'react';
import {
  X,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Cpu,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck,
  Zap,
  Info,
  ExternalLink,
  PlusCircle,
} from 'lucide-react';
import { ReleaseCalendarRelease, ReleaseCalendarPhase } from '../../types/releaseCalendar';
import { useTEM } from '../../context/TEMContext';
import {
  environmentRecommendationService,
  EnvironmentRecommendationItem,
  PhaseRecommendationAnalysis,
} from '../../services/environmentRecommendationService';
import { Booking } from '../../types';

interface EnvironmentRecommendationModalProps {
  isOpen: boolean;
  onClose: () => void;
  release: ReleaseCalendarRelease | null;
  phase: ReleaseCalendarPhase | null;
  onBookEnvironment: (env: EnvironmentRecommendationItem, analysis: PhaseRecommendationAnalysis) => void;
  onViewBooking?: (booking: Booking) => void;
  getPhaseColor?: (phaseName: string, defaultColor?: string) => string;
}

export const EnvironmentRecommendationModal: React.FC<EnvironmentRecommendationModalProps> = ({
  isOpen,
  onClose,
  release,
  phase,
  onBookEnvironment,
  onViewBooking,
  getPhaseColor,
}) => {
  const { environmentProfiles, bookings, environments, incidents } = useTEM();

  const analysis: PhaseRecommendationAnalysis | null = useMemo(() => {
    if (!isOpen || !release || !phase) return null;
    return environmentRecommendationService.getEnvironmentRecommendations(
      release,
      phase,
      environmentProfiles,
      bookings,
      environments,
      incidents
    );
  }, [isOpen, release, phase, environmentProfiles, bookings, environments, incidents]);

  if (!isOpen || !release || !phase || !analysis) return null;

  const formatDate = (dStr?: string) => {
    if (!dStr) return '-';
    try {
      return new Date(dStr).toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dStr;
    }
  };

  const phaseColor = phase.color || (getPhaseColor ? getPhaseColor(phase.phaseName, '#3B82F6') : '#3B82F6');
  const { reservationCheck, recommendedEnvironments, conflictingEnvironments, hasAvailableRecommendation } = analysis;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs font-mono text-xs animate-in fade-in duration-150">
      <div className="bg-[#0b111e] border border-slate-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden text-slate-200">
        {/* Header */}
        <div className="px-6 py-4 bg-[#080d16] border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-orange-500/10 border border-orange-500/30 text-orange-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-orange-400 font-bold uppercase tracking-widest">
                  ENVIRONMENT BOOKING RECOMMENDATION
                </span>
                <span
                  className="px-2 py-0.5 rounded text-[10px] font-bold text-white shadow-xs"
                  style={{ backgroundColor: phaseColor }}
                >
                  {phase.phaseName}
                </span>
              </div>
              <h2 className="text-base font-bold text-white tracking-tight font-sans flex items-center gap-2">
                <span>{release.releaseName}</span>
                <span className="text-xs font-mono text-orange-400">({release.version || 'v1.0.0'})</span>
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Phase Context Bar */}
        <div className="px-6 py-2.5 bg-[#0e1626] border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-[11px] shrink-0">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5 text-slate-400">
              <Calendar className="w-3.5 h-3.5 text-orange-400" />
              <span>Phase Period:</span>
              <span className="font-bold text-slate-200">
                {formatDate(phase.startDate)} &ndash; {formatDate(phase.endDate)}
              </span>
            </div>

            {release.applicationName && (
              <div className="flex items-center gap-1.5 text-slate-400">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                <span>Application:</span>
                <span className="font-bold text-purple-300">{release.applicationName}</span>
              </div>
            )}

            {release.businessUnit && (
              <div className="flex items-center gap-1.5 text-slate-400">
                <span>BU:</span>
                <span className="font-bold text-slate-200">{release.businessUnit}</span>
              </div>
            )}
          </div>

          <div>
            {reservationCheck.isReserved ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-[10px]">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {reservationCheck.reservationStatus === 'MULTIPLE_RESERVED'
                  ? `${reservationCheck.matchedBookings.length} Environments Reserved`
                  : 'Environment Reserved'}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 font-bold text-[10px]">
                <AlertTriangle className="w-3.5 h-3.5" />
                No Environment Reserved
              </span>
            )}
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Section 1: Existing Reservation Status */}
          {reservationCheck.isReserved ? (
            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm font-sans">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Existing Environment Reservation Active</span>
                </div>
                <span className="text-[10px] text-emerald-300 font-mono">
                  {reservationCheck.matchedBookings.length} booking(s) found
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {reservationCheck.matchedBookings.map((b) => (
                  <div
                    key={b.id}
                    className="bg-[#090e17] border border-emerald-500/20 rounded-lg p-3 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Cpu className="w-4 h-4 text-emerald-400" />
                        <span className="font-bold text-white text-xs">{b.environmentName || b.environmentId}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                        {b.status}
                      </span>
                    </div>

                    <div className="text-[10px] text-slate-400 space-y-1">
                      <div>
                        <span className="text-slate-500">Period: </span>
                        <span className="text-slate-300">{formatDate(b.startDate)} &ndash; {formatDate(b.endDate)}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Purpose: </span>
                        <span className="text-slate-300">{b.purpose || 'Release testing'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Requested By: </span>
                        <span className="text-slate-300">{b.requestedBy}</span>
                      </div>
                    </div>

                    {onViewBooking && (
                      <button
                        onClick={() => onViewBooking(b)}
                        className="w-full mt-2 py-1.5 px-3 rounded bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 font-bold text-[10px] flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <ExternalLink className="w-3 h-3" />
                        View Booking Details
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1 font-sans">
                <h4 className="text-sm font-bold text-amber-300">
                  No Environment Reserved for {phase.phaseName} Phase
                </h4>
                <p className="text-xs text-slate-300 font-normal">
                  An environment has not been booked for this release phase ({formatDate(phase.startDate)} &ndash; {formatDate(phase.endDate)}).
                  Please review the AI recommendations below and reserve an available environment to ensure release readiness.
                </p>
              </div>
            </div>
          )}

          {/* Section 2: Recommended Environments */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-orange-400" />
                <h3 className="text-sm font-bold text-white font-sans">
                  Recommended Environments
                </h3>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                {recommendedEnvironments.length} Available Candidate(s)
              </span>
            </div>

            {recommendedEnvironments.length > 0 ? (
              <div className="grid grid-cols-1 gap-3">
                {recommendedEnvironments.map((env) => (
                  <div
                    key={env.environmentId}
                    className="bg-[#0f1726] border border-slate-800 hover:border-orange-500/50 rounded-xl p-4 transition-all shadow-md group"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-lg bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400 font-bold shrink-0">
                          <Cpu className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-white text-sm font-sans">
                              {env.environmentName}
                            </h4>
                            <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                              {env.environmentType}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                                env.status === 'HEALTHY'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                              }`}
                            >
                              {env.status}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400">
                            Availability: <strong className="text-emerald-400">{env.availablePeriod}</strong>
                          </span>
                        </div>
                      </div>

                      {/* Match Score & CTA Button */}
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-[10px] text-slate-500 block uppercase font-bold">
                            Match Score
                          </span>
                          <span className="text-sm font-bold text-emerald-400 font-sans">
                            {env.compatibilityScore}%
                          </span>
                        </div>

                        <button
                          onClick={() => onBookEnvironment(env, analysis)}
                          className="px-4 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs font-mono shadow-md flex items-center gap-1.5 transition-colors cursor-pointer group-hover:shadow-orange-600/30"
                        >
                          <PlusCircle className="w-3.5 h-3.5" />
                          <span>Book Environment</span>
                        </button>
                      </div>
                    </div>

                    {/* Explainable Reasons */}
                    <div className="pt-3 space-y-1.5">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                        Reason for Recommendation:
                      </span>
                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
                        {env.reasons.map((r, idx) => (
                          <li
                            key={idx}
                            className="flex items-start gap-1.5 text-[11px] text-slate-300 font-sans"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{r}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-[#0f1726] border border-red-500/30 rounded-xl p-6 text-center space-y-2">
                <XCircle className="w-8 h-8 text-red-400 mx-auto" />
                <h4 className="text-sm font-bold text-white font-sans">
                  No Suitable Environment is Currently Available
                </h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto font-sans">
                  All potential environments for application &ldquo;{release.applicationName || 'N/A'}&rdquo; have active reservation conflicts or are offline during {formatDate(phase.startDate)} &ndash; {formatDate(phase.endDate)}.
                </p>
              </div>
            )}
          </div>

          {/* Section 3: Conflicting / Occupied Environments */}
          {conflictingEnvironments.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-400">
                  <XCircle className="w-4 h-4 text-red-400" />
                  <h3 className="text-xs font-bold uppercase tracking-wider">
                    Unavailable / Conflicting Environments ({conflictingEnvironments.length})
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {conflictingEnvironments.map((c) => (
                  <div
                    key={c.environmentId}
                    className="bg-[#0a0e17] border border-slate-800 rounded-lg p-3 space-y-1.5 text-[10px]"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-300 font-mono">{c.environmentName}</span>
                      <span className="px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/30 font-bold">
                        Conflict Detected
                      </span>
                    </div>
                    <div className="text-slate-400">
                      <span>Conflict Period: </span>
                      <span className="text-red-300 font-semibold font-mono">
                        {formatDate(c.conflictStartDate)} &ndash; {formatDate(c.conflictEndDate)}
                      </span>
                    </div>
                    {c.conflictingPurpose && (
                      <div className="text-slate-500 truncate">
                        Existing purpose: {c.conflictingPurpose}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#080d16] border-t border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-slate-400 text-[10px]">
            <Info className="w-3.5 h-3.5 text-orange-400" />
            <span>Clicking &ldquo;Book Environment&rdquo; pre-fills the standard booking form for confirmation.</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
