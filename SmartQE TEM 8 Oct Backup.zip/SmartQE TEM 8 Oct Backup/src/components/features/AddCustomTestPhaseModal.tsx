import React, { useState, useEffect } from 'react';
import { Layers, X, AlertCircle, Check, Palette } from 'lucide-react';
import { TestPhase } from '../../types';
import { useTEM } from '../../context/TEMContext';

interface AddCustomTestPhaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newPhase: TestPhase) => void;
  existingPhases: TestPhase[];
}

const PRESET_COLORS = [
  '#3B82F6', // Blue
  '#6366F1', // Indigo
  '#8B5CF6', // Violet
  '#A855F7', // Purple
  '#EC4899', // Pink
  '#F43F5E', // Rose
  '#EF4444', // Red
  '#F97316', // Orange
  '#F59E0B', // Amber
  '#EAB308', // Yellow
  '#10B981', // Emerald
  '#14B8A6', // Teal
  '#06B6D4', // Cyan
  '#0EA5E9', // Sky
];

export const AddCustomTestPhaseModal: React.FC<AddCustomTestPhaseModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  existingPhases,
}) => {
  const { createCustomTestPhase } = useTEM();
  const [phaseName, setPhaseName] = useState('');
  const [color, setColor] = useState('#8B5CF6');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (isOpen) {
      setPhaseName('');
      setColor('#8B5CF6');
      setErrorMessage('');
      setIsSubmitting(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const trimmed = phaseName.trim();
    if (!trimmed) {
      setErrorMessage('Test Phase Name is required and cannot be empty.');
      return;
    }

    // Check duplicate name against existing system and custom phases (case-insensitive)
    const isDuplicate = existingPhases.some(
      (p) => p.name.trim().toLowerCase() === trimmed.toLowerCase() ||
             p.displayName.trim().toLowerCase() === trimmed.toLowerCase()
    );

    if (isDuplicate) {
      setErrorMessage(`A test phase with the name '${trimmed}' already exists. Please choose a unique name.`);
      return;
    }

    if (!color || !color.trim()) {
      setErrorMessage('Color is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      const created = await createCustomTestPhase(trimmed, color);
      onSuccess(created);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save custom test phase.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#0f1724] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#131b28]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-950/60 border border-orange-500/40 flex items-center justify-center text-orange-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wide">
                Add Custom Test Phase
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">
                Define a custom milestone phase and color identifier
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {errorMessage && (
            <div className="p-3 bg-rose-950/40 border border-rose-800/80 rounded-xl flex items-start gap-2.5 text-xs text-rose-300 animate-fadeIn">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Test Phase Name Field */}
          <div>
            <label className="block text-xs font-mono font-semibold text-slate-300 mb-1.5 uppercase">
              Test Phase Name <span className="text-orange-500">*</span>
            </label>
            <input
              type="text"
              required
              autoFocus
              value={phaseName}
              onChange={(e) => {
                setPhaseName(e.target.value);
                if (errorMessage) setErrorMessage('');
              }}
              placeholder="e.g. Performance Testing"
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-3.5 py-2.5 text-xs text-white font-mono placeholder:text-slate-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-all"
            />
          </div>

          {/* Color Picker Field */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-mono font-semibold text-slate-300 uppercase flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-orange-400" /> Color <span className="text-orange-500">*</span>
              </label>
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">{color}</span>
            </div>

            {/* Selected Color & Picker Input */}
            <div className="flex items-center gap-3 p-2.5 bg-[#161f2e] border border-slate-700/80 rounded-lg mb-3">
              <div className="relative flex items-center justify-center">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-9 h-9 rounded cursor-pointer opacity-0 absolute inset-0 z-10"
                />
                <span
                  className="w-9 h-9 rounded-lg border border-white/20 shadow-md flex items-center justify-center shrink-0 transition-transform hover:scale-105"
                  style={{ backgroundColor: color }}
                />
              </div>
              <div className="flex-1 text-xs font-mono text-slate-300">
                <span className="block text-[10px] text-slate-400 uppercase">Selected Hex</span>
                <input
                  type="text"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full bg-transparent border-none p-0 text-xs font-mono text-white focus:outline-none"
                />
              </div>
            </div>

            {/* Color Swatch Palette */}
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase mb-2">Preset Palette</span>
              <div className="flex flex-wrap gap-2">
                {PRESET_COLORS.map((c) => {
                  const isSelected = color.toLowerCase() === c.toLowerCase();
                  return (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`w-7 h-7 rounded-lg border transition-all flex items-center justify-center ${
                        isSelected
                          ? 'border-white scale-110 shadow-lg ring-2 ring-orange-500/60'
                          : 'border-transparent hover:scale-105 opacity-80 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: c }}
                      title={c}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 text-white drop-shadow" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 rounded-lg text-xs font-mono text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !phaseName.trim()}
              className="flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_12px_rgba(249,115,22,0.35)]"
            >
              {isSubmitting ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Saving...
                </>
              ) : (
                'Add Phase'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
