import React, { useState } from 'react';
import { HealthCheckDefinition, HealthCheckType, CheckCriticality } from '../../types/healthCheck';
import { X, Plus, Shield, CheckCircle2, AlertTriangle, Layers, Settings, Globe, Database, Terminal, Server } from 'lucide-react';

interface HealthCheckConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  environmentId: string;
  environmentName: string;
  definitions: HealthCheckDefinition[];
  onSaveDefinition: (def: Partial<HealthCheckDefinition>) => Promise<void>;
}

export const HealthCheckConfigModal: React.FC<HealthCheckConfigModalProps> = ({
  isOpen,
  onClose,
  environmentId,
  environmentName,
  definitions,
  onSaveDefinition,
}) => {
  const [selectedDef, setSelectedDef] = useState<Partial<HealthCheckDefinition> | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Form states
  const [name, setName] = useState('');
  const [checkType, setCheckType] = useState<HealthCheckType>('HTTP');
  const [criticality, setCriticality] = useState<CheckCriticality>('CRITICAL');
  const [targetUrl, setTargetUrl] = useState('');
  const [targetHost, setTargetHost] = useState('127.0.0.1');
  const [targetPort, setTargetPort] = useState<number>(8000);
  const [expectedStatus, setExpectedStatus] = useState<number>(200);
  const [timeoutSeconds, setTimeoutSeconds] = useState<number>(5);
  const [weight, setWeight] = useState<number>(25);
  const [autoHealEnabled, setAutoHealEnabled] = useState(false);

  if (!isOpen) return null;

  const handleOpenCreate = () => {
    setSelectedDef(null);
    setName('');
    setCheckType('HTTP');
    setCriticality('CRITICAL');
    setTargetUrl('http://127.0.0.1:8000/api/v1/health');
    setTargetHost('127.0.0.1');
    setTargetPort(8000);
    setExpectedStatus(200);
    setTimeoutSeconds(5);
    setWeight(25);
    setAutoHealEnabled(false);
    setIsEditing(true);
  };

  const handleOpenEdit = (def: HealthCheckDefinition) => {
    setSelectedDef(def);
    setName(def.name);
    setCheckType(def.checkType);
    setCriticality(def.criticality);
    setTargetUrl(def.targetUrl || '');
    setTargetHost(def.targetHost || '127.0.0.1');
    setTargetPort(def.targetPort || 8000);
    setExpectedStatus(def.expectedHttpStatus || 200);
    setTimeoutSeconds(def.timeoutSeconds || 5);
    setWeight(def.weight || 20);
    setAutoHealEnabled(def.autoHealEnabled || false);
    setIsEditing(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSaveDefinition({
        id: selectedDef?.id,
        name,
        checkType,
        criticality,
        environmentId,
        environmentName,
        targetUrl: checkType === 'HTTP' ? targetUrl : undefined,
        targetHost: checkType !== 'HTTP' ? targetHost : undefined,
        targetPort: checkType === 'TCP_PORT' || checkType === 'DATABASE' ? Number(targetPort) : undefined,
        expectedHttpStatus: checkType === 'HTTP' ? Number(expectedStatus) : undefined,
        timeoutSeconds: Number(timeoutSeconds),
        weight: Number(weight),
        autoHealEnabled,
        httpMethod: 'GET',
        retryCount: 1,
        isEnabled: true
      });
      setIsEditing(false);
    } catch (err) {
      console.error('Failed to save definition:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0f172a] border border-slate-700/80 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">Health Check Configuration</h2>
              <p className="text-xs text-slate-400">
                Configure synthetic probes and assertions for <span className="text-blue-400 font-medium">{environmentName}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {!isEditing ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-slate-300">
                  Configured Probes ({definitions.length})
                </h3>
                <button
                  onClick={handleOpenCreate}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-blue-600 text-white hover:bg-blue-500 transition-colors shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Probe
                </button>
              </div>

              <div className="space-y-2.5">
                {definitions.map((def) => (
                  <div
                    key={def.id}
                    className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60 hover:border-slate-600/80 transition-all flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-700/50 text-slate-300">
                        {def.checkType === 'HTTP' && <Globe className="w-4 h-4 text-emerald-400" />}
                        {def.checkType === 'PING' && <Server className="w-4 h-4 text-blue-400" />}
                        {def.checkType === 'TCP_PORT' && <Terminal className="w-4 h-4 text-cyan-400" />}
                        {def.checkType === 'DATABASE' && <Database className="w-4 h-4 text-amber-400" />}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-white truncate">{def.name}</span>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                              def.criticality === 'CRITICAL'
                                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            }`}
                          >
                            {def.criticality}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 truncate mt-0.5">
                          {def.targetUrl || `${def.targetHost}${def.targetPort ? `:${def.targetPort}` : ''}`} &bull; Timeout: {def.timeoutSeconds}s &bull; Weight: {def.weight}%
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleOpenEdit(def)}
                      className="px-3 py-1 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors shrink-0"
                    >
                      Edit
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <form onSubmit={handleSave} className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h3 className="text-sm font-semibold text-white">
                  {selectedDef ? 'Edit Health Check Probe' : 'New Health Check Probe'}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="text-xs text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Probe Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Core Payment API Health"
                    className="w-full px-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Check Type</label>
                  <select
                    value={checkType}
                    onChange={(e) => setCheckType(e.target.value as HealthCheckType)}
                    className="w-full px-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="HTTP">HTTP / HTTPS Endpoint</option>
                    <option value="PING">Host Reachability (Ping)</option>
                    <option value="TCP_PORT">TCP Socket Port</option>
                    <option value="DATABASE">Database Connection & Query</option>
                  </select>
                </div>
              </div>

              {checkType === 'HTTP' && (
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Target URL</label>
                  <input
                    type="text"
                    required
                    value={targetUrl}
                    onChange={(e) => setTargetUrl(e.target.value)}
                    placeholder="https://qa-app.internal/api/v1/health"
                    className="w-full px-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>
              )}

              {checkType !== 'HTTP' && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-300">Target Host / IP</label>
                    <input
                      type="text"
                      required
                      value={targetHost}
                      onChange={(e) => setTargetHost(e.target.value)}
                      placeholder="127.0.0.1 or db.qa.internal"
                      className="w-full px-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  {(checkType === 'TCP_PORT' || checkType === 'DATABASE') && (
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-300">Port</label>
                      <input
                        type="number"
                        required
                        value={targetPort}
                        onChange={(e) => setTargetPort(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Criticality</label>
                  <select
                    value={criticality}
                    onChange={(e) => setCriticality(e.target.value as CheckCriticality)}
                    className="w-full px-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="CRITICAL">CRITICAL (Blocker)</option>
                    <option value="HIGH">HIGH (Degradation)</option>
                    <option value="MEDIUM">MEDIUM</option>
                    <option value="LOW">LOW</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Timeout (Seconds)</label>
                  <input
                    type="number"
                    min="1"
                    max="30"
                    value={timeoutSeconds}
                    onChange={(e) => setTimeoutSeconds(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Scoring Weight</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={weight}
                    onChange={(e) => setWeight(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                  <input
                    type="checkbox"
                    checked={autoHealEnabled}
                    onChange={(e) => setAutoHealEnabled(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-blue-600 focus:ring-0"
                  />
                  <span>Enable Auto-Heal runbook trigger on failure</span>
                </label>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    {isSaving ? 'Saving...' : 'Save Configuration'}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-800 bg-slate-900/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
