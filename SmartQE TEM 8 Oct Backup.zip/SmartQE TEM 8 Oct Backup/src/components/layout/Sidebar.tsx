import React, { useState, useEffect, useRef } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutGrid,
  ClipboardList,
  Rocket,
  AlertTriangle,
  Settings,
  Shield,
  Users,
  KeyRound,
  BookOpen,
  Briefcase,
  Cpu,
  Zap,
  Boxes,
  Layers,
  ChevronDown,
  ChevronRight,
  Compass,
  Activity,
  Sparkles,
  BarChart3,
  User,
  Webhook,
  Calendar,
  GitFork,
  Server,
  PlayCircle,
  FilePlus2,
  History,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface NavItemChild {
  name: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface NavItem {
  name: string;
  path?: string;
  icon: React.ComponentType<{ className?: string }>;
  children?: NavItemChild[];
}

interface SidebarProps {
  mobileOpen?: boolean;
  onMobileClose?: () => void;
  isCollapsed?: boolean;
}

interface HoveredItemState {
  name: string;
  path?: string;
  icon: React.ComponentType<{ className?: string }>;
  children?: NavItemChild[];
  top: number;
}

const SIDEBAR_STORAGE_KEY = 'smartqe_tem_sidebar_expanded_menus';

export const Sidebar: React.FC<SidebarProps> = ({
  mobileOpen,
  onMobileClose,
  isCollapsed,
}) => {
  const location = useLocation();
  const { currentUser, hasPermission } = useAuth();

  const [hoveredItem, setHoveredItem] = useState<HoveredItemState | null>(null);
  const [hoveredProfile, setHoveredProfile] = useState<boolean>(false);
  const leaveTimerRef = useRef<NodeJS.Timeout | null>(null);

  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>(() => {
    const isProvisioningChildActive =
      location.pathname === '/provisioning' ||
      location.pathname.startsWith('/provisioning/') ||
      location.pathname.startsWith('/provisioning');

    const isResourceChildActive =
      location.pathname === '/environment-usage-analysis' ||
      location.pathname === '/usage-analysis' ||
      location.pathname === '/environment-usage' ||
      location.pathname === '/ai-predictive-demand' ||
      location.pathname === '/environment-monitoring' ||
      location.pathname.startsWith('/environment-monitoring/') ||
      location.pathname === '/monitoring' ||
      location.pathname === '/inventory' ||
      location.pathname.startsWith('/inventory/') ||
      location.pathname === '/environment-topology' ||
      location.pathname.startsWith('/environment-topology/') ||
      location.pathname === '/topology';

    const isSettingsChildActive =
      location.pathname === '/settings' ||
      location.pathname.startsWith('/settings/') ||
      location.pathname === '/settings/users' ||
      location.pathname === '/settings/roles' ||
      location.pathname === '/settings/access';

    const isReleasesChildActive =
      location.pathname === '/releases' ||
      location.pathname.startsWith('/releases/') ||
      location.pathname === '/release-calendar';

    if (isReleasesChildActive) {
      return {
        Settings: false,
        'Resource Management': false,
        'Environment Provisioning': false,
        Releases: true,
      };
    }

    if (isProvisioningChildActive) {
      return {
        Settings: false,
        'Resource Management': false,
        'Environment Provisioning': true,
        Releases: false,
      };
    }

    if (isSettingsChildActive) {
      return {
        Settings: true,
        'Resource Management': false,
        'Environment Provisioning': false,
        Releases: false,
      };
    }

    if (isResourceChildActive) {
      return {
        Settings: false,
        'Resource Management': true,
        'Environment Provisioning': false,
        Releases: false,
      };
    }

    return {
      Settings: false,
      'Resource Management': false,
      'Environment Provisioning': false,
      Releases: false,
    };
  });

  useEffect(() => {
    const isProvisioningChildActive =
      location.pathname === '/provisioning' ||
      location.pathname.startsWith('/provisioning/') ||
      location.pathname.startsWith('/provisioning');

    const isResourceChildActive =
      location.pathname === '/environment-usage-analysis' ||
      location.pathname === '/usage-analysis' ||
      location.pathname === '/environment-usage' ||
      location.pathname === '/ai-predictive-demand' ||
      location.pathname === '/environment-monitoring' ||
      location.pathname.startsWith('/environment-monitoring/') ||
      location.pathname === '/monitoring' ||
      location.pathname === '/inventory' ||
      location.pathname.startsWith('/inventory/') ||
      location.pathname === '/environment-topology' ||
      location.pathname.startsWith('/environment-topology/') ||
      location.pathname === '/topology';

    const isSettingsChildActive =
      location.pathname === '/settings' ||
      location.pathname.startsWith('/settings/') ||
      location.pathname === '/settings/users' ||
      location.pathname === '/settings/roles' ||
      location.pathname === '/settings/access';

    const isReleasesChildActive =
      location.pathname === '/releases' ||
      location.pathname.startsWith('/releases/') ||
      location.pathname === '/release-calendar';

    if (isReleasesChildActive) {
      setExpandedMenus({
        Settings: false,
        'Resource Management': false,
        'Environment Provisioning': false,
        Releases: true,
      });
      try {
        localStorage.setItem(
          SIDEBAR_STORAGE_KEY,
          JSON.stringify({ Settings: false, 'Resource Management': false, 'Environment Provisioning': false, Releases: true })
        );
      } catch {}
    } else if (isProvisioningChildActive) {
      setExpandedMenus({
        Settings: false,
        'Resource Management': false,
        'Environment Provisioning': true,
        Releases: false,
      });
      try {
        localStorage.setItem(
          SIDEBAR_STORAGE_KEY,
          JSON.stringify({ Settings: false, 'Resource Management': false, 'Environment Provisioning': true, Releases: false })
        );
      } catch {}
    } else if (isSettingsChildActive) {
      setExpandedMenus({
        Settings: true,
        'Resource Management': false,
        'Environment Provisioning': false,
        Releases: false,
      });
      try {
        localStorage.setItem(
          SIDEBAR_STORAGE_KEY,
          JSON.stringify({ Settings: true, 'Resource Management': false, 'Environment Provisioning': false, Releases: false })
        );
      } catch {}
    } else if (isResourceChildActive) {
      setExpandedMenus({
        Settings: false,
        'Resource Management': true,
        'Environment Provisioning': false,
        Releases: false,
      });
      try {
        localStorage.setItem(
          SIDEBAR_STORAGE_KEY,
          JSON.stringify({ Settings: false, 'Resource Management': true, 'Environment Provisioning': false, Releases: false })
        );
      } catch {}
    } else {
      setExpandedMenus({
        Settings: false,
        'Resource Management': false,
        'Environment Provisioning': false,
        Releases: false,
      });
      try {
        localStorage.setItem(
          SIDEBAR_STORAGE_KEY,
          JSON.stringify({ Settings: false, 'Resource Management': false, 'Environment Provisioning': false, Releases: false })
        );
      } catch {}
    }
  }, [location.pathname]);

  const toggleMenu = (name: string) => {
    setExpandedMenus((prev) => {
      const willBeOpen = !prev[name];
      const next: Record<string, boolean> = { ...prev };
      if (willBeOpen) {
        Object.keys(next).forEach((key) => {
          if (key !== name) {
            next[key] = false;
          }
        });
      }
      next[name] = willBeOpen;
      try {
        localStorage.setItem(SIDEBAR_STORAGE_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const isSuperAdmin =
    Boolean(currentUser?.isSuperAdmin) ||
    currentUser?.username?.toLowerCase() === 'admin' ||
    (currentUser?.roles || []).some((r) => r.name?.toLowerCase().trim() === 'super admin');

  const isItemVisible = (itemPath?: string, children?: NavItemChild[]): boolean => {
    if (!currentUser) return false;
    if (isSuperAdmin) return true;
    if (itemPath && hasPermission(itemPath)) return true;
    if (children && children.some((c) => hasPermission(c.path))) return true;
    return false;
  };

  const rawMainModules: NavItem[] = [
    { name: 'TEM Dashboard', path: '/tem-dashboard', icon: LayoutGrid },
    {
      name: 'Settings',
      icon: Settings,
      children: [
        { name: 'User Management', path: '/settings/users', icon: User },
        { name: 'Role Management', path: '/settings/roles', icon: Shield },
        { name: 'Access Management', path: '/settings/access', icon: KeyRound },
        { name: 'User Group Management', path: '/settings/user-groups', icon: Users },
        { name: 'Define Workflow', path: '/settings/define-workflow', icon: GitFork },
      ],
    },
    { name: 'Entity Management', path: '/entity-management', icon: Briefcase },
    { name: 'Environment Details', path: '/environment-details', icon: Cpu },
    { name: 'Worklist', path: '/worklist', icon: ClipboardList },
    { name: 'Bookings Grid', path: '/bookings', icon: Calendar },
    {
      name: 'Environment Provisioning',
      icon: Server,
      children: [
        { name: 'Provisioning Dashboard', path: '/provisioning/dashboard', icon: LayoutGrid },
        { name: 'Provisioning Requests', path: '/provisioning/requests', icon: PlayCircle },
        { name: 'New Request (Wizard)', path: '/provisioning/new', icon: FilePlus2 },
        { name: 'Templates', path: '/provisioning/templates', icon: Sparkles },
        { name: 'Provisioning History', path: '/provisioning/history', icon: History },
      ],
    },
    {
      name: 'Releases',
      icon: Rocket,
      children: [
        { name: 'Release Management', path: '/releases', icon: Rocket },
        { name: 'Release Calendar', path: '/releases/calendar', icon: Calendar },
      ],
    },
    { name: 'Incidents', path: '/incidents', icon: AlertTriangle },
    {
      name: 'Resource Management',
      icon: Layers,
      children: [
        { name: 'Inventory Management', path: '/inventory', icon: Boxes },
        { name: 'Environment Topology', path: '/environment-topology', icon: Compass },
        { name: 'Environment Monitoring', path: '/environment-monitoring', icon: Activity },
        { name: 'AI Predictive Demand', path: '/ai-predictive-demand', icon: Sparkles },
        { name: 'Usage Analysis', path: '/environment-usage-analysis', icon: BarChart3 },
      ],
    },
    { name: 'External Integrations', path: '/external-integrations', icon: Webhook },
  ];

  const mainModules: NavItem[] = rawMainModules
    .filter((item) => isItemVisible(item.path, item.children))
    .map((item) => ({
      ...item,
      children: item.children?.filter((c) => isSuperAdmin || hasPermission(c.path)),
    }))
    .filter((item) => (item.children ? item.children.length > 0 : true));

  const systemModules: NavItem[] = [
    { name: 'Runbooks', path: '/runbooks', icon: BookOpen },
  ].filter((item) => isItemVisible(item.path));

  const handleMouseEnter = (
    item: NavItem,
    event: React.MouseEvent<HTMLElement>
  ) => {
    if (!isCollapsed || mobileOpen) return;
    if (leaveTimerRef.current) {
      clearTimeout(leaveTimerRef.current);
      leaveTimerRef.current = null;
    }
    const rect = event.currentTarget.getBoundingClientRect();
    setHoveredItem({
      name: item.name,
      path: item.path,
      icon: item.icon,
      children: item.children,
      top: rect.top + rect.height / 2,
    });
  };

  const handleMouseLeave = () => {
    if (!isCollapsed || mobileOpen) return;
    leaveTimerRef.current = setTimeout(() => {
      setHoveredItem(null);
    }, 120);
  };

  const handleFlyoutMouseEnter = () => {
    if (leaveTimerRef.current) {
      clearTimeout(leaveTimerRef.current);
      leaveTimerRef.current = null;
    }
  };

  // Close floating popover when navigating
  useEffect(() => {
    setHoveredItem(null);
    setHoveredProfile(false);
  }, [location.pathname]);

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {mobileOpen && (
        <div
          onClick={onMobileClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden cursor-pointer"
          aria-hidden="true"
        />
      )}

      {/* 1. BRAND LOGO HEADER */}
      <div
        className={`fixed top-0 left-0 z-50 h-16 bg-white dark:bg-[#090d14] border-r border-b border-slate-200 dark:border-slate-800/80 flex items-center select-none transition-all duration-300 ease-in-out overflow-hidden ${
          isCollapsed ? 'w-16 px-3.5' : 'w-64 px-4'
        } ${
          mobileOpen
            ? 'translate-x-0 opacity-100 pointer-events-auto'
            : '-translate-x-full lg:translate-x-0 opacity-100 pointer-events-auto'
        }`}
      >
        <NavLink
          to="/tem-dashboard"
          onClick={onMobileClose}
          className="flex items-center w-full group cursor-pointer overflow-hidden"
          title="SmartQE TEM Control"
        >
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white shadow-[0_0_12px_rgba(249,115,22,0.4)] shrink-0 group-hover:scale-105 transition-transform">
            <Zap className="w-5 h-5 fill-current text-white" />
          </div>
          <div
            className={`ml-3 transition-all duration-300 overflow-hidden whitespace-nowrap ${
              isCollapsed && !mobileOpen ? 'opacity-0 max-w-0 pointer-events-none' : 'opacity-100 max-w-[180px]'
            }`}
          >
            <h1 className="text-sm font-bold tracking-wider text-slate-900 dark:text-white uppercase font-mono truncate group-hover:text-orange-500 dark:group-hover:text-orange-400 transition-colors">
              SmartQE
            </h1>
            <p className="text-[10px] font-mono tracking-widest text-slate-500 dark:text-slate-400 truncate group-hover:text-slate-700 dark:group-hover:text-slate-200 transition-colors">
              TEM CONTROL
            </p>
          </div>
        </NavLink>
      </div>

      {/* 2. SIDEBAR DRAWER (Below Logo Header) */}
      <aside
        className={`fixed top-16 left-0 bottom-0 z-50 bg-white dark:bg-[#090d14] border-r border-slate-200 dark:border-slate-800/80 flex flex-col transition-all duration-300 ease-in-out shadow-sm overflow-hidden ${
          isCollapsed ? 'w-16' : 'w-64'
        } ${
          mobileOpen
            ? 'translate-x-0 opacity-100 pointer-events-auto'
            : '-translate-x-full lg:translate-x-0 opacity-100 pointer-events-auto'
        }`}
      >
        {/* Navigation Links Area */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-2.5 space-y-4">
          {/* MODULES Section */}
          <div>
            <div className="px-2 mb-2 transition-all duration-300 overflow-hidden">
              <h2
                className={`text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400 dark:text-slate-500 whitespace-nowrap transition-all duration-300 ${
                  isCollapsed && !mobileOpen ? 'opacity-0 max-h-0 mb-0' : 'opacity-100 max-h-6 mb-1'
                }`}
              >
                MODULES
              </h2>
              {isCollapsed && !mobileOpen && (
                <div className="w-8 h-[1px] bg-slate-800/80 mx-auto my-1 transition-opacity duration-300" />
              )}
            </div>

            <nav className="space-y-1">
              {mainModules.map((item) => {
                const Icon = item.icon;
                const hasChildren = Boolean(item.children && item.children.length > 0);

                // Check active state
                const isItemActive = item.path
                  ? location.pathname === item.path || location.pathname.startsWith(item.path + '/')
                  : false;
                const isChildActive = Boolean(
                  item.children?.some(
                    (child) =>
                      location.pathname === child.path ||
                      location.pathname.startsWith(child.path + '/')
                  )
                );
                const isActive = isItemActive || isChildActive;

                // Parent with children
                if (hasChildren && item.children) {
                  const isExpanded = !!expandedMenus[item.name];

                  return (
                    <div
                      key={item.name}
                      onMouseEnter={(e) => handleMouseEnter(item, e)}
                      onMouseLeave={handleMouseLeave}
                      className="relative"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          if (!isCollapsed || mobileOpen) {
                            toggleMenu(item.name);
                          }
                        }}
                        className={`flex items-center justify-between w-full h-10 px-2.5 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer overflow-hidden ${
                          isActive
                            ? 'text-orange-400 bg-orange-500/20 font-bold border border-orange-500/40 shadow-[0_0_10px_rgba(249,115,22,0.2)]'
                            : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70 border border-transparent hover:border-slate-700/50'
                        }`}
                      >
                        <div className="flex items-center min-w-0 flex-1 overflow-hidden">
                          <div className="w-5 h-5 shrink-0 flex items-center justify-center">
                            <Icon
                              className={`w-5 h-5 shrink-0 ${
                                isActive ? 'text-orange-400' : 'text-slate-400'
                              }`}
                            />
                          </div>
                          <span
                            className={`ml-3 whitespace-nowrap text-xs font-medium transition-all duration-300 overflow-hidden truncate ${
                              isCollapsed && !mobileOpen
                                ? 'opacity-0 max-w-0 pointer-events-none'
                                : 'opacity-100 max-w-[140px]'
                            }`}
                          >
                            {item.name}
                          </span>
                        </div>
                        <div
                          className={`shrink-0 transition-all duration-300 overflow-hidden ${
                            isCollapsed && !mobileOpen ? 'opacity-0 max-w-0' : 'opacity-100 max-w-6'
                          }`}
                        >
                          {isExpanded ? (
                            <ChevronDown className="w-4 h-4 text-slate-400 shrink-0 ml-1 transition-transform duration-200" />
                          ) : (
                            <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 ml-1 transition-transform duration-200" />
                          )}
                        </div>
                      </button>

                      {/* Sub-items in expanded mode */}
                      <div
                        className={`transition-all duration-300 overflow-hidden ${
                          !isCollapsed || mobileOpen
                            ? isExpanded
                              ? 'max-h-60 opacity-100 pl-3 pr-1 mt-1 space-y-1 border-l border-slate-800/80 ml-5 animate-in fade-in duration-150'
                              : 'max-h-0 opacity-0 pointer-events-none'
                            : 'max-h-0 opacity-0 pointer-events-none'
                        }`}
                      >
                        {item.children.map((child) => {
                          const ChildIcon = child.icon;
                          return (
                            <NavLink
                              key={child.path}
                              to={child.path}
                              end
                              onClick={onMobileClose}
                              className={({ isActive: isChildActiveRoute }) =>
                                `flex items-center gap-2 px-2.5 py-2 rounded-md text-xs font-medium transition-all ${
                                  isChildActiveRoute
                                    ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30 font-bold shadow-sm'
                                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
                                }`
                              }
                            >
                              <ChildIcon className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                              <span className="whitespace-nowrap truncate">{child.name}</span>
                            </NavLink>
                          );
                        })}
                      </div>
                    </div>
                  );
                }

                // Single Navigation Item
                return (
                  <div
                    key={item.name}
                    onMouseEnter={(e) => handleMouseEnter(item, e)}
                    onMouseLeave={handleMouseLeave}
                    className="relative"
                  >
                    <NavLink
                      key={item.path}
                      to={item.path!}
                      end
                      onClick={onMobileClose}
                      className={({ isActive: isLinkActive }) =>
                        `flex items-center h-10 px-2.5 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer overflow-hidden ${
                          isLinkActive
                            ? 'bg-orange-500/20 text-orange-400 font-bold border border-orange-500/40 shadow-[0_0_10px_rgba(249,115,22,0.2)]'
                            : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70 border border-transparent hover:border-slate-700/50'
                        }`
                      }
                    >
                      <div className="w-5 h-5 shrink-0 flex items-center justify-center">
                        <Icon className="w-5 h-5 shrink-0" />
                      </div>
                      <span
                        className={`ml-3 whitespace-nowrap text-xs font-medium transition-all duration-300 overflow-hidden truncate ${
                          isCollapsed && !mobileOpen
                            ? 'opacity-0 max-w-0 pointer-events-none'
                            : 'opacity-100 max-w-[170px]'
                        }`}
                      >
                        {item.name}
                      </span>
                    </NavLink>
                  </div>
                );
              })}
            </nav>
          </div>

          {/* SYSTEM Section */}
          <div>
            <div className="px-2 mb-2 transition-all duration-300 overflow-hidden">
              <h2
                className={`text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400 dark:text-slate-500 whitespace-nowrap transition-all duration-300 ${
                  isCollapsed && !mobileOpen ? 'opacity-0 max-h-0 mb-0' : 'opacity-100 max-h-6 mb-1'
                }`}
              >
                SYSTEM
              </h2>
              {isCollapsed && !mobileOpen && (
                <div className="w-8 h-[1px] bg-slate-800/80 mx-auto my-1 transition-opacity duration-300" />
              )}
            </div>

            <nav className="space-y-1">
              {systemModules.map((item) => {
                const Icon = item.icon;
                const isLinkActive = item.path
                  ? location.pathname === item.path || location.pathname.startsWith(item.path + '/')
                  : false;

                return (
                  <div
                    key={item.name}
                    onMouseEnter={(e) => handleMouseEnter(item, e)}
                    onMouseLeave={handleMouseLeave}
                    className="relative"
                  >
                    <NavLink
                      key={item.path}
                      to={item.path!}
                      onClick={onMobileClose}
                      className={`flex items-center h-10 px-2.5 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer overflow-hidden ${
                        isLinkActive
                          ? 'bg-orange-500/20 text-orange-400 font-bold border border-orange-500/40 shadow-[0_0_10px_rgba(249,115,22,0.2)]'
                          : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70 border border-transparent hover:border-slate-700/50'
                      }`}
                    >
                      <div className="w-5 h-5 shrink-0 flex items-center justify-center">
                        <Icon className="w-5 h-5 shrink-0" />
                      </div>
                      <span
                        className={`ml-3 whitespace-nowrap text-xs font-medium transition-all duration-300 overflow-hidden truncate ${
                          isCollapsed && !mobileOpen
                            ? 'opacity-0 max-w-0 pointer-events-none'
                            : 'opacity-100 max-w-[170px]'
                        }`}
                      >
                        {item.name}
                      </span>
                    </NavLink>
                  </div>
                );
              })}
            </nav>
          </div>
        </div>

        {/* User Footer Profile Card */}
        <div
          onMouseEnter={() => {
            if (isCollapsed && !mobileOpen) setHoveredProfile(true);
          }}
          onMouseLeave={() => setHoveredProfile(false)}
          className="p-2.5 border-t border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-slate-950/40 transition-colors duration-150 overflow-hidden"
        >
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-xl bg-orange-600/20 border border-orange-500/40 text-orange-400 font-bold text-xs flex items-center justify-center shrink-0 shadow-sm cursor-pointer hover:bg-orange-600/30 transition-colors">
              {(currentUser?.fullName || currentUser?.username || 'U')
                .split(' ')
                .map((n) => n[0])
                .join('')
                .substring(0, 2)
                .toUpperCase()}
            </div>
            <div
              className={`flex-1 overflow-hidden transition-all duration-300 whitespace-nowrap ${
                isCollapsed && !mobileOpen
                  ? 'opacity-0 max-w-0 pointer-events-none'
                  : 'opacity-100 max-w-[170px]'
              }`}
            >
              <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                {currentUser?.fullName || currentUser?.username || 'User'}
              </p>
              <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
                {currentUser?.email || (currentUser?.username ? `${currentUser.username}@smartqe.io` : '')}
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Floating Hover Tooltips & Submenu Flyouts for Collapsed Sidebar */}
      {isCollapsed && !mobileOpen && hoveredItem && (
        <>
          {hoveredItem.children && hoveredItem.children.length > 0 ? (
            /* Interactive Flyout with Sub-Module links */
            <div
              onMouseEnter={handleFlyoutMouseEnter}
              onMouseLeave={handleMouseLeave}
              className="fixed left-[70px] z-[9999] w-64 rounded-xl bg-[#0d131f] border border-slate-700/90 shadow-[0_10px_35px_rgba(0,0,0,0.65)] p-2.5 space-y-1 animate-in fade-in zoom-in-95 duration-100"
              style={{
                top: Math.max(16, Math.min(hoveredItem.top - 28, window.innerHeight - 340)),
              }}
            >
              {/* Arrow Indicator */}
              <div
                className="absolute -left-1.5 w-3 h-3 bg-[#0d131f] border-l border-b border-slate-700/90 rotate-45 pointer-events-none"
                style={{
                  top: Math.max(
                    12,
                    Math.min(
                      hoveredItem.top - Math.max(16, Math.min(hoveredItem.top - 28, window.innerHeight - 340)) - 6,
                      300
                    )
                  ),
                }}
              />
              {/* Header with Module Name */}
              <div className="px-2.5 py-1.5 mb-1.5 border-b border-slate-800/90 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <hoveredItem.icon className="w-4 h-4 text-orange-400 shrink-0" />
                  <span className="text-xs font-bold text-white font-mono tracking-wide truncate">
                    {hoveredItem.name}
                  </span>
                </div>
                <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest px-1.5 py-0.5 rounded bg-slate-800/80 border border-slate-700/60">
                  MENU
                </span>
              </div>
              {/* Child Nav Links */}
              <div className="space-y-0.5 max-h-[300px] overflow-y-auto">
                {hoveredItem.children.map((child) => {
                  const ChildIcon = child.icon;
                  return (
                    <NavLink
                      key={child.path}
                      to={child.path}
                      end
                      onClick={() => {
                        setHoveredItem(null);
                        if (onMobileClose) onMobileClose();
                      }}
                      className={({ isActive: isChildActiveRoute }) =>
                        `flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-all ${
                          isChildActiveRoute
                            ? 'bg-orange-500/20 text-orange-400 font-bold border border-orange-500/30 shadow-sm'
                            : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                        }`
                      }
                    >
                      <ChildIcon className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                      <span className="truncate">{child.name}</span>
                    </NavLink>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Simple Single Tooltip Bubble */
            <div
              className="fixed left-[70px] z-[9999] px-3 py-1.5 rounded-lg bg-[#0d131f] border border-slate-700/90 text-white text-xs font-semibold shadow-[0_8px_25px_rgba(0,0,0,0.6)] pointer-events-none flex items-center gap-2 animate-in fade-in zoom-in-95 duration-100"
              style={{
                top: hoveredItem.top,
                transform: 'translateY(-50%)',
              }}
            >
              {/* Arrow Indicator */}
              <div className="absolute -left-1.5 top-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-[#0d131f] border-l border-b border-slate-700/90 rotate-45" />
              <hoveredItem.icon className="w-3.5 h-3.5 text-orange-400 shrink-0" />
              <span className="relative z-10 whitespace-nowrap font-mono">{hoveredItem.name}</span>
            </div>
          )}
        </>
      )}

      {/* Floating Hover Tooltip for Collapsed Profile */}
      {isCollapsed && !mobileOpen && hoveredProfile && (
        <div className="fixed left-[70px] bottom-3 z-[9999] px-3.5 py-2.5 rounded-xl bg-[#0d131f] border border-slate-700/90 text-white shadow-[0_10px_35px_rgba(0,0,0,0.65)] pointer-events-none animate-in fade-in zoom-in-95 duration-100 min-w-[180px]">
          <div className="absolute -left-1.5 bottom-4 w-2.5 h-2.5 bg-[#0d131f] border-l border-b border-slate-700/90 rotate-45" />
          <p className="text-xs font-bold text-white leading-tight truncate">
            {currentUser?.fullName || currentUser?.username || 'User'}
          </p>
          <p className="text-[11px] font-mono text-slate-400 mt-0.5 truncate">
            {currentUser?.email || (currentUser?.username ? `${currentUser.username}@smartqe.io` : '')}
          </p>
          <span className="inline-block mt-1.5 text-[9px] font-mono font-semibold px-2 py-0.5 rounded bg-orange-950/70 text-orange-400 border border-orange-800/70">
            {currentUser?.isSuperAdmin ? 'Super Admin' : (currentUser?.roles?.[0]?.name || 'Standard User')}
          </span>
        </div>
      )}
    </>
  );
};