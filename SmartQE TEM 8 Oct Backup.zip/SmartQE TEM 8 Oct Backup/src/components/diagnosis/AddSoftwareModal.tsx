import React, { useState } from 'react';
import { X, Plus, Package, Server } from 'lucide-react';
import { SoftwareCategory, SoftwareDiagnosisStatus, EnvironmentSoftwareItem } from '../../types/diagnosis';
import { ButtonLoader } from '../common/ButtonLoader';

interface AddSoftwareModalProps {
  isOpen: boolean;
  onClose: () => void;
  environmentName: string;
  onAdd: (softwareData: Partial<EnvironmentSoftwareItem>) => Promise<void>;
}

export const AddSoftwareModal: React.FC<AddSoftwareModalProps> = ({
  isOpen,
  onClose,
  environmentName,
  onAdd,
}) => {
  const [softwareName, setSoftwareName] = useState('');
  const [category, setCategory] = useState<SoftwareCategory>('RUNTIME');
  const [installedVersion, setInstalledVersion] = useState('');
  const [expectedVersion, setExpectedVersion] = useState('');
  const [port, setPort] = useState('');
  const [processPath, setProcessPath] = useState('');
  const [vendor, setVendor] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!softwareName.trim()) {
      setError('Software name is required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await onAdd({
        software_name: softwareName.trim(),
        category,
        installed_version: installedVersion.trim() || null,
        expected_version: expectedVersion.trim() || null,
        port: port.trim() || null,
        process_path: processPath.trim() || null,
        vendor: vendor.trim() || null,
        status: !installedVersion.trim() && expectedVersion.trim()
          ? 'MISSING'
          : (installedVersion.trim() === expectedVersion.trim() ? 'MATCH' : 'VERSION_MISMATCH'),
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to add software package.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 font-mono text-xs">
      <div className="bg-[#0f1724] border border-slate-700 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-[#161f2e]">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-orange-400" />
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Add Software to {environmentName}
              </h2>
              <p className="text-[10px] text-slate-400">Configure runtime or database inventory baseline</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          {error && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 rounded text-xs">
              {error}
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">
                Software Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={softwareName}
                onChange={(e) => setSoftwareName(e.target.value)}
                placeholder="e.g. Java, Python, Redis, PostgreSQL"
                required
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as SoftwareCategory)}
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              >
                <option value="RUNTIME">Runtime / Language</option>
                <option value="DATABASE">Database</option>
                <option value="QUEUE">Message Queue</option>
                <option value="CACHE">Cache</option>
                <option value="WEB_SERVER">Web Server / Proxy</option>
                <option value="FRAMEWORK">Framework</option>
                <option value="TOOL">Tool / Agent</option>
                <option value="SERVICE">Service</option>
                <option value="OTHER">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">Port</label>
              <input
                type="text"
                value={port}
                onChange={(e) => setPort(e.target.value)}
                placeholder="e.g. 8080, 5432"
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">
                Installed Version
              </label>
              <input
                type="text"
                value={installedVersion}
                onChange={(e) => setInstalledVersion(e.target.value)}
                placeholder="e.g. 17.0.10, 3.11.5"
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">
                Expected Version
              </label>
              <input
                type="text"
                value={expectedVersion}
                onChange={(e) => setExpectedVersion(e.target.value)}
                placeholder="e.g. 17.0.10"
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">
                Installation / Process Path
              </label>
              <input
                type="text"
                value={processPath}
                onChange={(e) => setProcessPath(e.target.value)}
                placeholder="e.g. /opt/java/jdk-17 or /usr/bin/python3"
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">Vendor / Organization</label>
              <input
                type="text"
                value={vendor}
                onChange={(e) => setVendor(e.target.value)}
                placeholder="e.g. Oracle, OpenJDK, Redis Ltd, Apache"
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <ButtonLoader
              type="submit"
              isLoading={isSubmitting}
              loadingText="SAVING..."
              icon={<Plus className="w-4 h-4" />}
              className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold uppercase tracking-wider shadow-[0_0_12px_rgba(249,115,22,0.4)]"
            >
              Add Software
            </ButtonLoader>
          </div>
        </form>

      </div>
    </div>
  );
};
