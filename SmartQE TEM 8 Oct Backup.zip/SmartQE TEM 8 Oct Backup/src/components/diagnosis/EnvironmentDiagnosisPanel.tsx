import React, { useState, useEffect, useMemo } from 'react';
import {
  Activity,
  RefreshCw,
  Search,
  Plus,
  ArrowRightLeft,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Server,
  Package,
  Layers,
  Shield,
  Database,
  Globe,
  Cpu,
  HardDrive,
  Copy,
  Check,
  Edit2,
  Trash2,
  Terminal,
  ExternalLink,
  ChevronRight,
  Info,
  Sliders
} from 'lucide-react';
import {
  EnvironmentDiagnosisResult,
  EnvironmentSoftwareItem,
  SoftwareDiagnosisStatus
} from '../../types/diagnosis';
import { diagnosisService } from '../../services/diagnosisService';
import { useTEM } from '../../context/TEMContext';
import { AddSoftwareModal } from './AddSoftwareModal';
import { EditExpectedVersionModal } from './EditExpectedVersionModal';
import { LoadingSpinner } from '../common/LoadingSpinner';

interface EnvironmentDiagnosisPanelProps {
  environmentsList: Array<{ id: string; name: string; tier?: string; status?: string }>;
  initialEnvId?: string;
  onNavigateToCompare?: (sourceEnvId: string, targetEnvId?: string) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const EnvironmentDiagnosisPanel: React.FC<EnvironmentDiagnosisPanelProps> = ({
  environmentsList,
  initialEnvId,
  onNavigateToCompare,
  showToast,
}) => {
  const { servers, environmentProfiles } = useTEM();

  const [selectedEnvId, setSelectedEnvId] = useState<string>(
    initialEnvId || (environmentsList[0]?.id || environmentsList[0]?.name || 'SIT')
  );

  const [diagnosisData, setDiagnosisData] = useState<EnvironmentDiagnosisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isDiagnosing, setIsDiagnosing] = useState<boolean>(false);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modals
  const [addModalOpen, setAddModalOpen] = useState<boolean>(false);
  const [editModalOpen, setEditModalOpen] = useState<boolean>(false);
  const [selectedSoftwareForEdit, setSelectedSoftwareForEdit] = useState<EnvironmentSoftwareItem | null>(null);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  // Load diagnosis
  const loadDiagnosis = async (envId: string, fresh: boolean = false) => {
    if (fresh) setIsDiagnosing(true);
    else setIsLoading(true);

    try {
      const result = fresh
        ? await diagnosisService.runDiagnosis(envId)
        : await diagnosisService.getDiagnosis(envId);
      setDiagnosisData(result);
      if (fresh) {
        showToast(`Diagnosis refreshed successfully for ${result.environment.environment_name}.`, 'success');
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to load diagnosis data.', 'error');
    } finally {
      setIsLoading(false);
      setIsDiagnosing(false);
    }
  };

  useEffect(() => {
    if (selectedEnvId) {
      loadDiagnosis(selectedEnvId);
    }
  }, [selectedEnvId]);

  useEffect(() => {
    if (initialEnvId && initialEnvId !== selectedEnvId) {
      setSelectedEnvId(initialEnvId);
    }
  }, [initialEnvId]);

  // Handlers for Software items
  const handleAddSoftware = async (data: Partial<EnvironmentSoftwareItem>) => {
    await diagnosisService.addSoftware(selectedEnvId, data);
    showToast(`Software '${data.software_name}' registered successfully.`, 'success');
    await loadDiagnosis(selectedEnvId, true);
  };

  const handleUpdateSoftware = async (
    softwareId: string,
    updates: Partial<EnvironmentSoftwareItem>
  ) => {
    await diagnosisService.updateSoftware(selectedEnvId, softwareId, updates);
    showToast('Software baseline configuration updated.', 'success');
    await loadDiagnosis(selectedEnvId, true);
  };

  const handleDeleteSoftware = async (softwareId: string, name: string) => {
    if (confirm(`Remove software '${name}' from ${selectedEnvId}?`)) {
      await diagnosisService.deleteSoftware(selectedEnvId, softwareId);
      showToast(`Software '${name}' removed.`, 'info');
      await loadDiagnosis(selectedEnvId, true);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(text);
    setTimeout(() => setCopiedCmd(null), 2000);
    showToast('Remediation command copied to clipboard.', 'info');
  };

  // Filtered software list
  const filteredSoftware = useMemo(() => {
    if (!diagnosisData?.software_inventory) return [];
    return diagnosisData.software_inventory.filter((sw) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        sw.software_name.toLowerCase().includes(q) ||
        (sw.vendor && sw.vendor.toLowerCase().includes(q)) ||
        (sw.category && sw.category.toLowerCase().includes(q)) ||
        (sw.port && sw.port.includes(q)) ||
        (sw.installed_version && sw.installed_version.includes(q));

      const matchStatus = statusFilter === 'ALL' || sw.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [diagnosisData?.software_inventory, searchQuery, statusFilter]);

  // Resolve current profile and mapped servers
  const currentProfile = useMemo(() => {
    return environmentProfiles.find(
      (p) =>
        p.id === selectedEnvId ||
        p.name.toLowerCase() === selectedEnvId.toLowerCase() ||
        (diagnosisData?.environment?.environment_name &&
          p.name.toLowerCase() === diagnosisData.environment.environment_name.toLowerCase())
    );
  }, [environmentProfiles, selectedEnvId, diagnosisData?.environment?.environment_name]);

  const linkedServers = useMemo(() => {
    if (!currentProfile || !currentProfile.serverIds) return [];
    return servers.filter((s) => currentProfile.serverIds.includes(s.id));
  }, [currentProfile, servers]);

  const primaryServer = linkedServers[0] || null;

  const displayServerHost = useMemo(() => {
    if (linkedServers.length > 0) {
      return linkedServers.map((s) => (s.hostIp ? `${s.name} (${s.hostIp})` : s.name)).join(', ');
    }
    return diagnosisData?.environment?.server_host || 'Unassigned';
  }, [linkedServers, diagnosisData?.environment?.server_host]);

  const displayIp = useMemo(() => {
    if (primaryServer?.hostIp) return primaryServer.hostIp;
    if (primaryServer?.privateIp) return primaryServer.privateIp;
    return diagnosisData?.environment?.ip_address || 'Unassigned';
  }, [primaryServer, diagnosisData?.environment?.ip_address]);

  const displayOs = useMemo(() => {
    if (primaryServer?.operatingSystem) return primaryServer.operatingSystem;
    return diagnosisData?.environment?.operating_system || 'Linux';
  }, [primaryServer, diagnosisData?.environment?.operating_system]);

  const displayCores = primaryServer?.cpuCores || diagnosisData?.environment?.cpu_cores || 8;
  const displayRam = primaryServer?.ramGb || diagnosisData?.environment?.ram_gb || 32;
  const displayStorage = primaryServer?.storageGb || diagnosisData?.environment?.storage_gb || 250;

  // Status Badge Helper
  const renderStatusBadge = (status: SoftwareDiagnosisStatus) => {
    switch (status) {
      case 'MATCH':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-700/80">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Match
          </span>
        );
      case 'VERSION_MISMATCH':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-700/80">
            <AlertTriangle className="w-3 h-3 text-amber-400" /> Version Mismatch
          </span>
        );
      case 'MISSING':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-bold bg-rose-950/80 text-rose-300 border border-rose-700/80">
            <XCircle className="w-3 h-3 text-rose-400" /> Missing
          </span>
        );
      case 'OUTDATED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-bold bg-purple-950/80 text-purple-300 border border-purple-700/80">
            <Clock className="w-3 h-3 text-purple-400" /> Outdated
          </span>
        );
      case 'UNKNOWN':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
            <Info className="w-3 h-3 text-slate-400" /> Unknown
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-bold bg-slate-900 text-slate-400 border border-slate-800">
            <Clock className="w-3 h-3 text-slate-500" /> Not Checked
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Bar: Environment Selector & Action Buttons */}
      <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="p-2.5 rounded-lg bg-orange-950/60 border border-orange-800/80 text-orange-400">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-400">SELECT ENVIRONMENT TO DIAGNOSE</div>
            <select
              value={selectedEnvId}
              onChange={(e) => setSelectedEnvId(e.target.value)}
              className="mt-0.5 bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white font-bold text-sm focus:outline-none focus:border-orange-500 min-w-[240px]"
            >
              {environmentsList.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.name} ({env.tier || 'Environment'})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-end">
          <button
            onClick={() => loadDiagnosis(selectedEnvId, true)}
            disabled={isDiagnosing}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold uppercase tracking-wider transition-colors border border-slate-700 disabled:opacity-50"
            title="Execute on-demand diagnosis check"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-orange-400 ${isDiagnosing ? 'animate-spin' : ''}`} />
            <span>{isDiagnosing ? 'DIAGNOSING...' : 'RUN DIAGNOSIS'}</span>
          </button>

          {onNavigateToCompare && (
            <button
              onClick={() => onNavigateToCompare(selectedEnvId)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded bg-blue-950/80 hover:bg-blue-900 text-sky-300 font-bold uppercase tracking-wider transition-colors border border-blue-800"
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>COMPARE ENV</span>
            </button>
          )}

          <button
            onClick={() => setAddModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold uppercase tracking-wider transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>ADD SOFTWARE</span>
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-16 flex flex-col items-center justify-center gap-3">
          <LoadingSpinner size="lg" variant="primary" />
          <p className="text-slate-400">Diagnosing environment components and software baseline...</p>
        </div>
      ) : diagnosisData ? (
        <>
          {/* Section 1: Environment Overview Card */}
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 shadow-xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-orange-950/80 text-orange-400 border border-orange-800/80">
                  {diagnosisData.environment.environment_type}
                </span>
                <h2 className="text-xl font-extrabold text-white">
                  {diagnosisData.environment.environment_name}
                </h2>
                <span
                  className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${
                    diagnosisData.environment.environment_status === 'HEALTHY'
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80'
                      : diagnosisData.environment.environment_status === 'DEGRADED'
                      ? 'bg-amber-950/80 text-amber-300 border-amber-700/80'
                      : 'bg-rose-950/80 text-rose-300 border-rose-700/80'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${diagnosisData.environment.environment_status === 'HEALTHY' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                  {diagnosisData.environment.environment_status}
                </span>
              </div>

              <div className="flex items-center gap-3 text-[11px] text-slate-400">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  Last Diagnosis:{' '}
                  <strong className="text-slate-200">
                    {diagnosisData.environment.last_diagnosis_time
                      ? new Date(diagnosisData.environment.last_diagnosis_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                      : 'Just now'}
                  </strong>
                </span>
                <span>•</span>
                <span>
                  Uptime: <strong className="text-emerald-400">{diagnosisData.environment.uptime}%</strong>
                </span>
              </div>
            </div>

            {/* Overview Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px]">
              <div className="bg-black/40 p-3 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[9px] uppercase tracking-wider">BUSINESS UNIT</span>
                <span className="text-white font-bold">{diagnosisData.environment.business_unit || 'Unassigned'}</span>
              </div>
              <div className="bg-black/40 p-3 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[9px] uppercase tracking-wider">PROJECT</span>
                <span className="text-white font-bold">{diagnosisData.environment.project || 'Unassigned'}</span>
              </div>
              <div className="bg-black/40 p-3 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[9px] uppercase tracking-wider">PRIMARY APPLICATION</span>
                <span className="text-orange-400 font-bold">{diagnosisData.environment.application || 'Unassigned'}</span>
              </div>
              <div className="bg-black/40 p-3 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[9px] uppercase tracking-wider">SERVER / HOSTNAME</span>
                <span className="text-sky-300 font-mono font-bold truncate block" title={displayServerHost}>
                  {displayServerHost}
                </span>
              </div>

              <div className="bg-black/40 p-3 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[9px] uppercase tracking-wider">IP ADDRESS</span>
                <span className="text-white font-mono font-bold">{displayIp}</span>
              </div>
              <div className="bg-black/40 p-3 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[9px] uppercase tracking-wider">OPERATING SYSTEM</span>
                <span className="text-slate-200">{displayOs}</span>
              </div>
              <div className="bg-black/40 p-3 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[9px] uppercase tracking-wider">HARDWARE SPECS</span>
                <span className="text-slate-200">
                  {displayCores} Cores / {displayRam}GB RAM / {displayStorage}GB Disk
                </span>
              </div>
              <div className="bg-black/40 p-3 rounded border border-slate-800/80">
                <span className="text-slate-500 block text-[9px] uppercase tracking-wider">LAST HEALTH CHECK</span>
                <span className="text-slate-200">
                  {diagnosisData.environment.last_health_check_time
                    ? new Date(diagnosisData.environment.last_health_check_time).toLocaleDateString()
                    : 'Today'}
                </span>
              </div>
            </div>

            {/* Mapped Servers Badges */}
            {linkedServers.length > 0 && (
              <div className="pt-2 border-t border-slate-800/60 flex flex-wrap items-center gap-2 text-[11px]">
                <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1">
                  <Server className="w-3 h-3 text-orange-400" /> MAPPED SERVERS ({linkedServers.length}):
                </span>
                {linkedServers.map((s) => (
                  <span
                    key={s.id}
                    className="px-2 py-0.5 rounded bg-[#162032] border border-slate-700 text-slate-200 text-[10px] flex items-center gap-1.5 font-mono"
                  >
                    <span className="font-bold text-white">{s.name}</span>
                    {s.hostIp && <span className="text-orange-400">({s.hostIp})</span>}
                    <span className="text-slate-500">[{s.serverType}]</span>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Section 2: Summary Metrics Gauges */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-[#0f1724] border border-slate-800 p-3.5 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">CONSISTENCY SCORE</span>
                <span className="text-2xl font-black text-orange-400">
                  {diagnosisData.summary.consistency_health_score}%
                </span>
              </div>
              <Shield className="w-7 h-7 text-orange-500/40" />
            </div>

            <div className="bg-[#0f1724] border border-slate-800 p-3.5 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">TOTAL PACKAGES</span>
                <span className="text-2xl font-black text-white">
                  {diagnosisData.summary.total_software}
                </span>
              </div>
              <Package className="w-7 h-7 text-slate-600" />
            </div>

            <div className="bg-[#0f1724] border border-slate-800 p-3.5 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[9px] text-emerald-400 uppercase block">MATCHING</span>
                <span className="text-2xl font-black text-emerald-400">
                  {diagnosisData.summary.matching}
                </span>
              </div>
              <CheckCircle2 className="w-7 h-7 text-emerald-500/40" />
            </div>

            <div className="bg-[#0f1724] border border-slate-800 p-3.5 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[9px] text-amber-400 uppercase block">MISMATCHES</span>
                <span className="text-2xl font-black text-amber-400">
                  {diagnosisData.summary.version_mismatch}
                </span>
              </div>
              <AlertTriangle className="w-7 h-7 text-amber-500/40" />
            </div>

            <div className="bg-[#0f1724] border border-slate-800 p-3.5 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[9px] text-rose-400 uppercase block">MISSING</span>
                <span className="text-2xl font-black text-rose-400">
                  {diagnosisData.summary.missing}
                </span>
              </div>
              <XCircle className="w-7 h-7 text-rose-500/40" />
            </div>

            <div className="bg-[#0f1724] border border-slate-800 p-3.5 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[9px] text-purple-400 uppercase block">OUTDATED</span>
                <span className="text-2xl font-black text-purple-400">
                  {diagnosisData.summary.outdated}
                </span>
              </div>
              <Clock className="w-7 h-7 text-purple-500/40" />
            </div>
          </div>

          {/* Section 3: Actionable Recommendations Panel (if any) */}
          {diagnosisData.recommendations.length > 0 && (
            <div className="bg-[#0f1724] border border-amber-900/60 rounded-lg p-4 shadow-xl space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4" />
                <span>Diagnosis Findings & Actionable Recommendations ({diagnosisData.recommendations.length})</span>
              </div>
              <div className="space-y-2.5">
                {diagnosisData.recommendations.map((rec, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-lg border flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                      rec.severity === 'CRITICAL'
                        ? 'bg-rose-950/40 border-rose-800/80 text-rose-200'
                        : rec.severity === 'WARNING'
                        ? 'bg-amber-950/40 border-amber-800/80 text-amber-200'
                        : 'bg-slate-900/60 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded ${
                            rec.severity === 'CRITICAL'
                              ? 'bg-rose-600 text-white'
                              : rec.severity === 'WARNING'
                              ? 'bg-amber-600 text-black font-bold'
                              : 'bg-slate-700 text-white'
                          }`}
                        >
                          {rec.severity}
                        </span>
                        <span className="font-bold text-white text-xs">{rec.title}</span>
                      </div>
                      <p className="text-[11px] text-slate-300">{rec.description}</p>
                      <p className="text-[11px] font-semibold text-orange-300">
                        Recommendation: {rec.recommendation}
                      </p>
                    </div>

                    {rec.remediation_cmd && (
                      <button
                        onClick={() => handleCopy(rec.remediation_cmd!)}
                        className="px-3 py-1.5 rounded bg-black/60 hover:bg-black/90 border border-slate-700 text-slate-300 hover:text-white flex items-center gap-1.5 self-start md:self-center shrink-0"
                        title="Copy CLI Remediation Command"
                      >
                        <Terminal className="w-3.5 h-3.5 text-orange-400" />
                        <span className="text-[10px] font-mono font-bold">
                          {copiedCmd === rec.remediation_cmd ? 'COPIED!' : 'COPY FIX CMD'}
                        </span>
                        {copiedCmd === rec.remediation_cmd ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3 text-slate-400" />
                        )}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section 4: Software Inventory Table */}
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg shadow-xl overflow-hidden space-y-3 p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-orange-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Software Inventory & Version Baseline
                </h3>
                <span className="px-2 py-0.2 rounded bg-slate-800 text-slate-300 text-[10px]">
                  {filteredSoftware.length} items
                </span>
              </div>

              {/* Search & Status Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search software, port, category..."
                    className="bg-[#161f2e] border border-slate-700 rounded pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 w-52"
                  />
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="bg-[#161f2e] border border-slate-700 rounded px-2.5 py-1.5 text-white text-xs focus:outline-none focus:border-orange-500"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="MATCH">Match</option>
                  <option value="VERSION_MISMATCH">Version Mismatch</option>
                  <option value="MISSING">Missing</option>
                  <option value="OUTDATED">Outdated</option>
                  <option value="NOT_CHECKED">Not Checked</option>
                </select>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#161f2e] text-slate-400 uppercase text-[9px] tracking-wider border-b border-slate-800">
                    <th className="py-2.5 px-3">Software</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">Installed Version</th>
                    <th className="py-2.5 px-3">Expected Baseline</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Port / Path</th>
                    <th className="py-2.5 px-3">Last Checked</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 text-[11px]">
                  {filteredSoftware.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        No software inventory matching criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredSoftware.map((sw) => (
                      <tr key={sw.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-white flex items-center gap-1.5">
                            <span>{sw.software_name}</span>
                            {sw.vendor && (
                              <span className="text-[9px] text-slate-500">({sw.vendor})</span>
                            )}
                          </div>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-mono">
                            {sw.category}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          {sw.installed_version ? (
                            <span className="font-bold text-white font-mono">{sw.installed_version}</span>
                          ) : (
                            <span className="text-rose-400 italic">Not Installed</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3">
                          {sw.expected_version ? (
                            <span className="text-orange-400 font-mono font-bold">{sw.expected_version}</span>
                          ) : (
                            <span className="text-slate-500 italic">Not specified</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3">{renderStatusBadge(sw.status)}</td>
                        <td className="py-2.5 px-3 text-slate-400 font-mono">
                          {sw.port ? (
                            <span className="text-sky-300 font-bold">:{sw.port}</span>
                          ) : sw.process_path ? (
                            <span className="truncate max-w-[120px] block" title={sw.process_path}>
                              {sw.process_path}
                            </span>
                          ) : (
                            '—'
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-slate-400 text-[10px]">
                          {sw.last_checked ? new Date(sw.last_checked).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Today'}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setSelectedSoftwareForEdit(sw);
                                setEditModalOpen(true);
                              }}
                              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                              title="Edit Expected Baseline"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteSoftware(sw.id, sw.software_name)}
                              className="p-1 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300"
                              title="Remove Component"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 5: Modular Diagnosis Checkers Cards */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-orange-400" />
              <span>Modular Diagnosis Checker Probes</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {diagnosisData.checker_results.map((checker, idx) => (
                <div
                  key={idx}
                  className="bg-[#0f1724] border border-slate-800 p-4 rounded-lg space-y-2 shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {checker.category} CHECKER
                    </span>
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded ${
                        checker.status === 'PASSED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : checker.status === 'WARNING'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {checker.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-white text-xs">{checker.checker_name}</h4>
                  <p className="text-[11px] text-slate-300">{checker.summary}</p>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : null}

      {/* Modals */}
      <AddSoftwareModal
        isOpen={addModalOpen}
        onClose={() => setAddModalOpen(false)}
        environmentName={diagnosisData?.environment.environment_name || selectedEnvId}
        onAdd={handleAddSoftware}
      />

      <EditExpectedVersionModal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        software={selectedSoftwareForEdit}
        onSave={handleUpdateSoftware}
      />
    </div>
  );
};
