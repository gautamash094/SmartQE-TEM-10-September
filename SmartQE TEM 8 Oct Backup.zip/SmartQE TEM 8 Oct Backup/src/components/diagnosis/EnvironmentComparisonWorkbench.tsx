import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowRightLeft,
  Search,
  Download,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Package,
  Layers,
  Shield,
  Clock,
  Terminal,
  Copy,
  Check,
  Filter,
  RefreshCw,
  Server,
  PlusCircle,
  HelpCircle,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import {
  EnvironmentComparisonResult,
  ComparisonDiffItem,
  EnvironmentComparisonRequest
} from '../../types/diagnosis';
import { diagnosisService } from '../../services/diagnosisService';
import { LoadingSpinner } from '../common/LoadingSpinner';

interface EnvironmentComparisonWorkbenchProps {
  environmentsList: Array<{ id: string; name: string; tier?: string; status?: string }>;
  initialSourceId?: string;
  initialTargetId?: string;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const EnvironmentComparisonWorkbench: React.FC<EnvironmentComparisonWorkbenchProps> = ({
  environmentsList,
  initialSourceId,
  initialTargetId,
  showToast,
}) => {
  const [sourceEnvId, setSourceEnvId] = useState<string>(
    initialSourceId || environmentsList[0]?.id || environmentsList[0]?.name || 'SIT'
  );
  const [targetEnvId, setTargetEnvId] = useState<string>(
    initialTargetId || environmentsList[1]?.id || environmentsList[1]?.name || 'UAT'
  );

  const [comparisonResult, setComparisonResult] = useState<EnvironmentComparisonResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Filters & Search
  const [activeFilterTab, setActiveFilterTab] = useState<'ALL' | 'MATCH' | 'VERSION_MISMATCH' | 'MISSING' | 'EXTRA' | 'OUTDATED'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const handleCompare = async () => {
    if (!sourceEnvId || !targetEnvId) {
      showToast('Please select both Source and Target environments.', 'error');
      return;
    }
    if (sourceEnvId === targetEnvId) {
      showToast('Source and Target environments must be different.', 'error');
      return;
    }

    setIsLoading(true);
    try {
      const result = await diagnosisService.compareEnvironments({
        source_environment_id: sourceEnvId,
        target_environment_id: targetEnvId,
        include_server_check: true,
      });
      setComparisonResult(result);
    } catch (err: any) {
      showToast(err.message || 'Failed to compare environments.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    handleCompare();
  }, [sourceEnvId, targetEnvId]);

  const handleSwap = () => {
    const temp = sourceEnvId;
    setSourceEnvId(targetEnvId);
    setTargetEnvId(temp);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(text);
    setTimeout(() => setCopiedCmd(null), 2000);
    showToast('Remediation command copied to clipboard.', 'info');
  };

  // Export as JSON
  const handleExportJSON = () => {
    if (!comparisonResult) return;
    const blob = new Blob([JSON.stringify(comparisonResult, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tem_comparison_${comparisonResult.source_environment.name}_vs_${comparisonResult.target_environment.name}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Comparison report exported as JSON.', 'success');
  };

  // Export as CSV
  const handleExportCSV = () => {
    if (!comparisonResult) return;
    const headers = ['Software', 'Category', 'Source Version', 'Target Version', 'Comparison Status', 'Details'];
    const rows = comparisonResult.comparison.map((item) => [
      `"${item.software}"`,
      `"${item.category}"`,
      `"${item.source_version || 'Not Installed'}"`,
      `"${item.target_version || 'Not Installed'}"`,
      `"${item.status}"`,
      `"${item.details || ''}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tem_comparison_${comparisonResult.source_environment.name}_vs_${comparisonResult.target_environment.name}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Comparison report exported as CSV.', 'success');
  };

  // Filtered diff items
  const filteredItems = useMemo(() => {
    if (!comparisonResult?.comparison) return [];
    return comparisonResult.comparison.filter((item) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        item.software.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        (item.source_version && item.source_version.includes(q)) ||
        (item.target_version && item.target_version.includes(q));

      const matchFilter =
        activeFilterTab === 'ALL'
          ? true
          : activeFilterTab === 'OUTDATED'
          ? item.status === 'VERSION_MISMATCH' && item.direction === 'TARGET_BEHIND'
          : item.status === activeFilterTab;

      return matchSearch && matchFilter;
    });
  }, [comparisonResult?.comparison, searchQuery, activeFilterTab]);

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Selector Card */}
      <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 shadow-xl space-y-4">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          {/* Source Environment */}
          <div className="flex-1 bg-[#161f2e] border border-slate-700 rounded-lg p-3.5 space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-500" /> SOURCE ENVIRONMENT (BASELINE)
            </span>
            <select
              value={sourceEnvId}
              onChange={(e) => setSourceEnvId(e.target.value)}
              className="w-full bg-[#0f1724] border border-slate-700 rounded px-3 py-2 text-white font-bold text-sm focus:outline-none focus:border-blue-500"
            >
              {environmentsList.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.name} ({env.tier || 'Environment'})
                </option>
              ))}
            </select>
          </div>

          {/* Swap Button */}
          <div className="flex items-center justify-center">
            <button
              onClick={handleSwap}
              className="p-3 rounded-full bg-slate-800 hover:bg-orange-600 text-slate-300 hover:text-white border border-slate-700 transition-all shadow-lg hover:scale-110"
              title="Swap Source and Target Environments"
            >
              <ArrowRightLeft className="w-5 h-5" />
            </button>
          </div>

          {/* Target Environment */}
          <div className="flex-1 bg-[#161f2e] border border-slate-700 rounded-lg p-3.5 space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-orange-500" /> TARGET ENVIRONMENT (TO VALIDATE)
            </span>
            <select
              value={targetEnvId}
              onChange={(e) => setTargetEnvId(e.target.value)}
              className="w-full bg-[#0f1724] border border-slate-700 rounded px-3 py-2 text-white font-bold text-sm focus:outline-none focus:border-orange-500"
            >
              {environmentsList.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.name} ({env.tier || 'Environment'})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Presets & Export Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] uppercase font-bold text-slate-500">COMMON PRESETS:</span>
            {environmentsList.length >= 2 && (
              <>
                <button
                  onClick={() => {
                    const sit = environmentsList.find((e) => e.name.toUpperCase().includes('SIT') || (e.tier && e.tier.toUpperCase().includes('SIT'))) || environmentsList[0];
                    const uat = environmentsList.find((e) => e.name.toUpperCase().includes('UAT') || (e.tier && e.tier.toUpperCase().includes('UAT'))) || environmentsList[1];
                    if (sit && uat) {
                      setSourceEnvId(sit.id);
                      setTargetEnvId(uat.id);
                    }
                  }}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold border border-slate-700"
                >
                  SIT vs UAT
                </button>
                <button
                  onClick={() => {
                    const dev = environmentsList.find((e) => e.name.toUpperCase().includes('DEV') || (e.tier && e.tier.toUpperCase().includes('DEV'))) || environmentsList[0];
                    const qa = environmentsList.find((e) => e.name.toUpperCase().includes('QA') || (e.tier && e.tier.toUpperCase().includes('QA'))) || environmentsList[1];
                    if (dev && qa) {
                      setSourceEnvId(dev.id);
                      setTargetEnvId(qa.id);
                    }
                  }}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold border border-slate-700"
                >
                  DEV vs QA
                </button>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportJSON}
              disabled={!comparisonResult}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-[10px] border border-slate-700 disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-orange-400" /> EXPORT JSON
            </button>
            <button
              onClick={handleExportCSV}
              disabled={!comparisonResult}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-[10px] border border-slate-700 disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-sky-400" /> EXPORT CSV
            </button>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-16 flex flex-col items-center justify-center gap-3">
          <LoadingSpinner size="lg" variant="primary" />
          <p className="text-slate-400">Comparing software matrices, semantic versions, and configurations...</p>
        </div>
      ) : comparisonResult ? (
        <>
          {/* Consistency Score Header & Summary KPIs */}
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-5 w-full lg:w-auto">
              {/* Score Circular Metric */}
              <div className="relative flex items-center justify-center w-24 h-24 rounded-full bg-black/60 border-4 border-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.3)] shrink-0">
                <div className="text-center">
                  <span className="text-2xl font-black text-white">{comparisonResult.consistency_score}%</span>
                  <span className="text-[8px] uppercase tracking-widest text-orange-400 block font-bold">MATCH</span>
                </div>
              </div>

              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">ENVIRONMENT CONSISTENCY SCORE</span>
                <h3 className="text-xl font-black text-white flex items-center gap-2 mt-0.5">
                  <span>{comparisonResult.source_environment.name}</span>
                  <ArrowRight className="w-4 h-4 text-orange-500" />
                  <span>{comparisonResult.target_environment.name}</span>
                </h3>
                <p className="text-[11px] text-slate-400 mt-1">
                  {comparisonResult.consistency_score >= 90
                    ? 'Environments are highly consistent with minimal configuration drift.'
                    : comparisonResult.consistency_score >= 75
                    ? 'Minor version mismatches detected. Review recommendations prior to execution.'
                    : 'Significant drift and missing packages detected. Alignment required.'}
                </p>
              </div>
            </div>

            {/* KPI Stat Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 w-full lg:w-auto">
              <div className="bg-black/40 p-2.5 rounded border border-slate-800 text-center">
                <span className="text-[9px] uppercase text-slate-500 block">TOTAL</span>
                <span className="text-lg font-bold text-white">{comparisonResult.summary.total_software}</span>
              </div>
              <div className="bg-black/40 p-2.5 rounded border border-slate-800 text-center">
                <span className="text-[9px] uppercase text-emerald-400 block">MATCHING</span>
                <span className="text-lg font-bold text-emerald-400">{comparisonResult.summary.matching}</span>
              </div>
              <div className="bg-black/40 p-2.5 rounded border border-slate-800 text-center">
                <span className="text-[9px] uppercase text-amber-400 block">MISMATCHES</span>
                <span className="text-lg font-bold text-amber-400">{comparisonResult.summary.version_mismatch}</span>
              </div>
              <div className="bg-black/40 p-2.5 rounded border border-slate-800 text-center">
                <span className="text-[9px] uppercase text-rose-400 block">MISSING</span>
                <span className="text-lg font-bold text-rose-400">{comparisonResult.summary.missing}</span>
              </div>
              <div className="bg-black/40 p-2.5 rounded border border-slate-800 text-center">
                <span className="text-[9px] uppercase text-sky-400 block">EXTRA</span>
                <span className="text-lg font-bold text-sky-400">{comparisonResult.summary.extra}</span>
              </div>
            </div>
          </div>

          {/* Actionable Recommendations Panel */}
          {comparisonResult.recommendations.length > 0 && (
            <div className="bg-[#0f1724] border border-orange-900/60 rounded-lg p-5 shadow-xl space-y-3.5">
              <div className="flex items-center gap-2 text-orange-400 font-bold uppercase tracking-wider">
                <Sparkles className="w-4 h-4" />
                <span>Actionable Environment Alignment Recommendations ({comparisonResult.recommendations.length})</span>
              </div>

              <div className="space-y-3">
                {comparisonResult.recommendations.map((rec, idx) => (
                  <div
                    key={idx}
                    className={`p-3.5 rounded-lg border flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                      rec.severity === 'CRITICAL'
                        ? 'bg-rose-950/40 border-rose-800/80 text-rose-200'
                        : rec.severity === 'WARNING'
                        ? 'bg-amber-950/40 border-amber-800/80 text-amber-200'
                        : 'bg-slate-900/60 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded ${
                            rec.severity === 'CRITICAL'
                              ? 'bg-rose-600 text-white'
                              : rec.severity === 'WARNING'
                              ? 'bg-amber-600 text-black font-bold'
                              : 'bg-slate-700 text-white'
                          }`}
                        >
                          {rec.severity}
                        </span>
                        <span className="font-bold text-white text-xs">{rec.title}</span>
                      </div>
                      <p className="text-[11px] text-slate-300">{rec.description}</p>
                      <p className="text-[11px] font-semibold text-orange-300">
                        Remediation Action: {rec.recommendation}
                      </p>
                    </div>

                    {rec.remediation_cmd && (
                      <button
                        onClick={() => handleCopy(rec.remediation_cmd!)}
                        className="px-3 py-1.5 rounded bg-black/70 hover:bg-black border border-slate-700 text-slate-300 hover:text-white flex items-center gap-1.5 self-start md:self-center shrink-0"
                        title="Copy CLI Remediation Command"
                      >
                        <Terminal className="w-3.5 h-3.5 text-orange-400" />
                        <span className="text-[10px] font-mono font-bold">
                          {copiedCmd === rec.remediation_cmd ? 'COPIED!' : 'COPY CLI CMD'}
                        </span>
                        {copiedCmd === rec.remediation_cmd ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3 text-slate-400" />
                        )}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Comparison Matrix & Filter Bar */}
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg shadow-xl overflow-hidden space-y-4 p-5">
            {/* Filter Tabs & Search */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-800">
              {/* Filter Tabs */}
              <div className="flex flex-wrap items-center gap-1 bg-black/40 p-1 rounded-lg border border-slate-800">
                <button
                  onClick={() => setActiveFilterTab('ALL')}
                  className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-colors ${
                    activeFilterTab === 'ALL'
                      ? 'bg-orange-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All ({comparisonResult.summary.total_software})
                </button>
                <button
                  onClick={() => setActiveFilterTab('MATCH')}
                  className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-colors ${
                    activeFilterTab === 'MATCH'
                      ? 'bg-emerald-700 text-white'
                      : 'text-slate-400 hover:text-emerald-300'
                  }`}
                >
                  Matching ({comparisonResult.summary.matching})
                </button>
                <button
                  onClick={() => setActiveFilterTab('VERSION_MISMATCH')}
                  className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-colors ${
                    activeFilterTab === 'VERSION_MISMATCH'
                      ? 'bg-amber-700 text-white'
                      : 'text-slate-400 hover:text-amber-300'
                  }`}
                >
                  Mismatch ({comparisonResult.summary.version_mismatch})
                </button>
                <button
                  onClick={() => setActiveFilterTab('MISSING')}
                  className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-colors ${
                    activeFilterTab === 'MISSING'
                      ? 'bg-rose-700 text-white'
                      : 'text-slate-400 hover:text-rose-300'
                  }`}
                >
                  Missing ({comparisonResult.summary.missing})
                </button>
                <button
                  onClick={() => setActiveFilterTab('EXTRA')}
                  className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-colors ${
                    activeFilterTab === 'EXTRA'
                      ? 'bg-sky-700 text-white'
                      : 'text-slate-400 hover:text-sky-300'
                  }`}
                >
                  Extra ({comparisonResult.summary.extra})
                </button>
                <button
                  onClick={() => setActiveFilterTab('OUTDATED')}
                  className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-colors ${
                    activeFilterTab === 'OUTDATED'
                      ? 'bg-purple-700 text-white'
                      : 'text-slate-400 hover:text-purple-300'
                  }`}
                >
                  Outdated ({comparisonResult.summary.outdated})
                </button>
              </div>

              {/* Search Box */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search software or version..."
                  className="bg-[#161f2e] border border-slate-700 rounded pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500 w-60"
                />
              </div>
            </div>

            {/* Comparison Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#161f2e] text-slate-400 uppercase text-[9px] tracking-wider border-b border-slate-800">
                    <th className="py-3 px-4">Software Component</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4 text-blue-300 font-bold">
                      {comparisonResult.source_environment.name} (Source)
                    </th>
                    <th className="py-3 px-4 text-orange-300 font-bold">
                      {comparisonResult.target_environment.name} (Target)
                    </th>
                    <th className="py-3 px-4">Comparison Result</th>
                    <th className="py-3 px-4">Diagnostic Difference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 text-[11px]">
                  {filteredItems.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        No software comparison records match the selected filter.
                      </td>
                    </tr>
                  ) : (
                    filteredItems.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-4">
                          <span className="font-bold text-white text-xs">{item.software}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                            {item.category}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          {item.source_version ? (
                            <span className="font-mono font-bold text-blue-300 bg-blue-950/60 px-2 py-0.5 rounded border border-blue-900/60">
                              v{item.source_version}
                            </span>
                          ) : (
                            <span className="text-slate-500 italic">Not Installed</span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {item.target_version ? (
                            <span
                              className={`font-mono font-bold px-2 py-0.5 rounded border ${
                                item.status === 'MATCH'
                                  ? 'text-emerald-300 bg-emerald-950/60 border-emerald-900/60'
                                  : 'text-orange-300 bg-orange-950/60 border-orange-900/60'
                              }`}
                            >
                              v{item.target_version}
                            </span>
                          ) : (
                            <span className="text-rose-400 font-bold italic bg-rose-950/60 px-2 py-0.5 rounded border border-rose-900/60">
                              Not Installed
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {item.status === 'MATCH' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" /> MATCH
                            </span>
                          )}
                          {item.status === 'VERSION_MISMATCH' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-700">
                              <AlertTriangle className="w-3 h-3 text-amber-400" /> VERSION MISMATCH
                            </span>
                          )}
                          {item.status === 'MISSING' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-700">
                              <XCircle className="w-3 h-3 text-rose-400" /> MISSING IN TARGET
                            </span>
                          )}
                          {item.status === 'EXTRA' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-sky-950 text-sky-300 border border-sky-700">
                              <PlusCircle className="w-3 h-3 text-sky-400" /> EXTRA IN TARGET
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-slate-300">
                          <span className="text-[11px]">{item.details || '—'}</span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section: Server Infrastructure Comparison */}
          {comparisonResult.server_comparison.length > 0 && (
            <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 shadow-xl space-y-3">
              <div className="flex items-center gap-2 text-slate-300 font-bold uppercase tracking-wider">
                <Server className="w-4 h-4 text-orange-400" />
                <span>Host & Server Infrastructure Difference</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {comparisonResult.server_comparison.map((diff, idx) => (
                  <div key={idx} className="bg-black/40 p-3 rounded border border-slate-800 space-y-1">
                    <span className="text-[9px] uppercase text-slate-500 font-bold block">{diff.attribute}</span>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-blue-300 font-bold">{diff.source_value}</span>
                      <ArrowRight className="w-3 h-3 text-slate-600" />
                      <span className="text-orange-300 font-bold">{diff.target_value}</span>
                    </div>
                    <span
                      className={`text-[9px] font-bold inline-block mt-1 ${
                        diff.status === 'MATCH' ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {diff.details}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      ) : null}
    </div>
  );
};
