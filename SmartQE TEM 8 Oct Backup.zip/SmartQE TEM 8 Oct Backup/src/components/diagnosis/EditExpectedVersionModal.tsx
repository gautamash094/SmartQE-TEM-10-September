import React, { useState, useEffect } from 'react';
import { X, Check, Edit3, Package } from 'lucide-react';
import { EnvironmentSoftwareItem } from '../../types/diagnosis';
import { ButtonLoader } from '../common/ButtonLoader';

interface EditExpectedVersionModalProps {
  isOpen: boolean;
  onClose: () => void;
  software: EnvironmentSoftwareItem | null;
  onSave: (softwareId: string, updates: Partial<EnvironmentSoftwareItem>) => Promise<void>;
}

export const EditExpectedVersionModal: React.FC<EditExpectedVersionModalProps> = ({
  isOpen,
  onClose,
  software,
  onSave,
}) => {
  const [expectedVersion, setExpectedVersion] = useState('');
  const [installedVersion, setInstalledVersion] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (software) {
      setExpectedVersion(software.expected_version || '');
      setInstalledVersion(software.installed_version || '');
    }
  }, [software]);

  if (!isOpen || !software) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const exp = expectedVersion.trim() || null;
      const inst = installedVersion.trim() || null;

      let newStatus = software.status;
      if (!inst && exp) {
        newStatus = 'MISSING';
      } else if (inst && exp) {
        newStatus = inst === exp ? 'MATCH' : 'VERSION_MISMATCH';
      } else if (inst && !exp) {
        newStatus = 'MATCH';
      }

      await onSave(software.id, {
        expected_version: exp,
        installed_version: inst,
        status: newStatus,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update software versions.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 font-mono text-xs">
      <div className="bg-[#0f1724] border border-slate-700 rounded-xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-[#161f2e]">
          <div className="flex items-center gap-2">
            <Edit3 className="w-5 h-5 text-orange-400" />
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Configure Version Baseline
              </h2>
              <p className="text-[10px] text-slate-400">{software.software_name} in {software.environment_name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 rounded text-xs">
              {error}
            </div>
          )}

          <div className="bg-black/30 p-3 rounded border border-slate-800 space-y-1 text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-400">Package:</span>
              <span className="text-white font-bold">{software.software_name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Category:</span>
              <span className="text-orange-400 font-bold">{software.category}</span>
            </div>
            {software.port && (
              <div className="flex justify-between">
                <span className="text-slate-400">Port:</span>
                <span className="text-sky-400 font-mono">:{software.port}</span>
              </div>
            )}
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">
                Installed Version
              </label>
              <input
                type="text"
                value={installedVersion}
                onChange={(e) => setInstalledVersion(e.target.value)}
                placeholder="e.g. 17.0.10 or leave blank if not installed"
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1">
                Expected Baseline Version
              </label>
              <input
                type="text"
                value={expectedVersion}
                onChange={(e) => setExpectedVersion(e.target.value)}
                placeholder="e.g. 17.0.10"
                className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
              <p className="text-[10px] text-slate-500 mt-1">
                The expected baseline against which diagnosis mismatches will be detected.
              </p>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <ButtonLoader
              type="submit"
              isLoading={isSubmitting}
              loadingText="SAVING..."
              icon={<Check className="w-4 h-4" />}
              className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold uppercase tracking-wider shadow-[0_0_12px_rgba(249,115,22,0.4)]"
            >
              Save Baseline
            </ButtonLoader>
          </div>
        </form>
      </div>

    </div>
  );
};
