import React, { useState, useEffect } from 'react';
import { EnvironmentProfile } from '../../types/environmentDetails';
import { MaintenanceWindow } from '../../types/monitoring';
import { DateTimePicker } from '../common/DateTimePicker';
import {
  X,
  Clock,
  ShieldCheck,
  AlertTriangle,
  Server,
  Calendar,
  Layers,
  BellOff,
  CheckCircle2,
} from 'lucide-react';

interface ScheduleMaintenanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (window: MaintenanceWindow) => void;
  environments: EnvironmentProfile[];
  initialEnvironmentId?: string;
}

export const ScheduleMaintenanceModal: React.FC<ScheduleMaintenanceModalProps> = ({
  isOpen,
  onClose,
  onSave,
  environments,
  initialEnvironmentId,
}) => {
  const [environmentId, setEnvironmentId] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [scheduledStart, setScheduledStart] = useState<string>('');
  const [scheduledEnd, setScheduledEnd] = useState<string>('');
  const [suppressAlerts, setSuppressAlerts] = useState<boolean>(true);
  const [maintenanceType, setMaintenanceType] = useState<string>('INFRASTRUCTURE_PATCH');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (isOpen) {
      const now = new Date();
      const inOneHour = new Date(now.getTime() + 60 * 60 * 1000);
      const inThreeHours = new Date(now.getTime() + 3 * 60 * 60 * 1000);

      const targetEnv = initialEnvironmentId || environments[0]?.id || '';
      setEnvironmentId(targetEnv);
      setTitle('');
      setDescription('');
      setScheduledStart(inOneHour.toISOString().slice(0, 19).replace('T', ' '));
      setScheduledEnd(inThreeHours.toISOString().slice(0, 19).replace('T', ' '));
      setSuppressAlerts(true);
      setMaintenanceType('INFRASTRUCTURE_PATCH');
      setErrors({});
    }
  }, [isOpen, initialEnvironmentId, environments]);

  if (!isOpen) return null;

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!environmentId) errs.environmentId = 'Please select a target environment.';
    if (!title.trim()) errs.title = 'Maintenance title is required.';
    if (!scheduledStart) errs.scheduledStart = 'Start date and time is required.';
    if (!scheduledEnd) errs.scheduledEnd = 'End date and time is required.';
    if (scheduledStart && scheduledEnd) {
      const startMs = new Date(scheduledStart.replace(' ', 'T')).getTime();
      const endMs = new Date(scheduledEnd.replace(' ', 'T')).getTime();
      if (endMs <= startMs) {
        errs.scheduledEnd = 'End time must be after start time.';
      }
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const matchedEnv = environments.find((e) => e.id === environmentId);
    const envName = matchedEnv?.name || 'Environment';

    const startIso = new Date(scheduledStart.replace(' ', 'T')).toISOString();
    const endIso = new Date(scheduledEnd.replace(' ', 'T')).toISOString();
    const nowMs = Date.now();
    const startMs = new Date(startIso).getTime();
    const endMs = new Date(endIso).getTime();

    let status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' = 'SCHEDULED';
    if (nowMs >= startMs && nowMs <= endMs) {
      status = 'IN_PROGRESS';
    } else if (nowMs > endMs) {
      status = 'COMPLETED';
    }

    const newWindow: MaintenanceWindow = {
      id: `maint-${environmentId.toLowerCase()}-${Date.now().toString().slice(-4)}`,
      environmentId,
      environmentName: envName,
      title: title.trim(),
      description: description.trim() || `Scheduled ${maintenanceType.replace('_', ' ').toLowerCase()} for ${envName}.`,
      scheduledStart: startIso,
      scheduledEnd: endIso,
      createdBy: 'Ops Engineer',
      suppressAlerts,
      status,
    };

    onSave(newWindow);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150 p-4">
      <div className="w-full max-w-xl bg-[#090d14] border border-slate-700/80 rounded-2xl overflow-hidden shadow-2xl font-mono text-xs text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-[#0d1420] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-950/80 border border-blue-800 text-blue-400 shadow-sm">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-blue-400 font-bold uppercase tracking-widest">
                TEM OBSERVABILITY & GOVERNANCE
              </span>
              <h2 className="text-lg font-extrabold text-white">Schedule Maintenance Window</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Target Environment */}
          <div className="space-y-1.5">
            <label className="block text-slate-400 font-bold uppercase text-[11px]">
              Target Environment <span className="text-rose-400">*</span>
            </label>
            <select
              value={environmentId}
              onChange={(e) => setEnvironmentId(e.target.value)}
              className="w-full bg-[#161f2e] border border-slate-700 rounded-lg px-3 py-2 text-white font-bold text-xs focus:outline-none focus:border-blue-500"
            >
              {environments.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.name} ({env.type}) · {env.ownerTeam || 'QA'}
                </option>
              ))}
            </select>
            {errors.environmentId && <p className="text-[10px] text-rose-400">{errors.environmentId}</p>}
          </div>

          {/* Maintenance Title */}
          <div className="space-y-1.5">
            <label className="block text-slate-400 font-bold uppercase text-[11px]">
              Maintenance Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., OS Kernel Patching & DB Migration"
              className="w-full bg-[#161f2e] border border-slate-700 rounded-lg px-3 py-2 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
            />
            {errors.title && <p className="text-[10px] text-rose-400">{errors.title}</p>}
          </div>

          {/* Type / Category */}
          <div className="space-y-1.5">
            <label className="block text-slate-400 font-bold uppercase text-[11px]">
              Maintenance Category
            </label>
            <select
              value={maintenanceType}
              onChange={(e) => setMaintenanceType(e.target.value)}
              className="w-full bg-[#161f2e] border border-slate-700 rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-blue-500"
            >
              <option value="INFRASTRUCTURE_PATCH">Infrastructure & OS Patching</option>
              <option value="DATABASE_MIGRATION">Database Schema & Engine Migration</option>
              <option value="APPLICATION_DEPLOYMENT">Application Major Deployment</option>
              <option value="NETWORK_RECONFIGURATION">Network & Firewall Configuration</option>
              <option value="HARDWARE_REBOOT">Host Node Maintenance & Reboot</option>
            </select>
          </div>

          {/* Start & End Date Pickers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <DateTimePicker
              label="START DATE & TIME"
              required
              value={scheduledStart}
              onChange={(val) => setScheduledStart(val)}
              error={errors.scheduledStart}
            />
            <DateTimePicker
              label="END DATE & TIME"
              required
              value={scheduledEnd}
              onChange={(val) => setScheduledEnd(val)}
              error={errors.scheduledEnd}
            />
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="block text-slate-400 font-bold uppercase text-[11px]">
              Operational Scope & Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Detail services being updated, teams notified, and expected impact duration..."
              className="w-full bg-[#161f2e] border border-slate-700 rounded-lg px-3 py-2 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          {/* Alert Suppression Toggle Box */}
          <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-800/60 flex items-start gap-3">
            <input
              type="checkbox"
              id="suppressAlerts"
              checked={suppressAlerts}
              onChange={(e) => setSuppressAlerts(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded bg-slate-800 border-slate-700 text-blue-600 focus:ring-0 focus:ring-offset-0 cursor-pointer"
            />
            <label htmlFor="suppressAlerts" className="cursor-pointer space-y-0.5">
              <span className="font-bold text-white text-[11px] flex items-center gap-1.5">
                <BellOff className="w-3.5 h-3.5 text-blue-400" /> Suppress Probes & Threshold Alert Storms
              </span>
              <p className="text-[10px] text-slate-400">
                During this window, environment status transitions to <code className="text-blue-300">MAINTENANCE</code> and automated alert escalations will be muted.
              </p>
            </label>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-blue-950/40 transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Schedule Window</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
