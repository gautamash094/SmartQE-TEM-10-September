import React, { useState } from 'react';
import {
  AutoHealRule,
  AutoHealActionType,
  AutoHealExecutionMode,
  AutoHealScriptType
} from '../../types/autoHeal';
import { HealthCheckType } from '../../types/healthCheck';
import { PREAPPROVED_SCRIPT_TEMPLATES, ScriptTemplate } from '../../services/autoHealService';
import {
  ShieldCheck,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Zap,
  Play,
  Lock,
  RefreshCw,
  Terminal,
  Code,
  FileCode,
  Layers,
  Sparkles,
  HelpCircle
} from 'lucide-react';

interface AutoHealRulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  environmentId: string;
  environmentName: string;
  rules: AutoHealRule[];
  onSaveRule: (rule: Partial<AutoHealRule>) => Promise<void>;
  onDeleteRule: (ruleId: string) => Promise<void>;
}

export const AutoHealRulesModal: React.FC<AutoHealRulesModalProps> = ({
  isOpen,
  onClose,
  environmentId,
  environmentName,
  rules,
  onSaveRule,
  onDeleteRule
}) => {
  const [editingRule, setEditingRule] = useState<Partial<AutoHealRule> | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');

  if (!isOpen) return null;

  const handleStartAdd = () => {
    setSelectedTemplateId('');
    setEditingRule({
      name: '',
      description: '',
      environmentId,
      environmentName,
      triggerType: 'HEALTH_CHECK_FAILURE',
      triggerCheckType: 'HTTP',
      triggerCriticality: 'CRITICAL',
      actionType: 'RESTART_SERVICE',
      actionTarget: 'service-daemon',
      scriptType: 'POWERSHELL',
      scriptContent: `# Auto-Heal Remediation Script\nWrite-Output "Restarting target \${ACTION_TARGET} on \${ENV_NAME}..."\nStart-Sleep -Seconds 1\nWrite-Output "Remediation verified."`,
      scriptTimeoutSeconds: 30,
      scriptParameters: {},
      executionMode: 'AUTOMATIC',
      maxRetries: 2,
      retryIntervalSeconds: 15,
      gracePeriodSeconds: 5,
      isEnabled: true,
      createIncidentOnExhaustion: true,
      incidentSeverity: 'SEV2'
    });
  };

  const handleApplyTemplate = (templateId: string) => {
    setSelectedTemplateId(templateId);
    const tpl = PREAPPROVED_SCRIPT_TEMPLATES.find((t) => t.id === templateId);
    if (tpl && editingRule) {
      setEditingRule({
        ...editingRule,
        name: editingRule.name || tpl.name,
        description: editingRule.description || tpl.description,
        actionType: 'EXECUTE_SCRIPT',
        actionTarget: tpl.defaultTarget,
        scriptType: tpl.scriptType,
        scriptContent: tpl.code,
        scriptParameters: tpl.parameters
      });
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRule || !editingRule.name) return;

    setIsSaving(true);
    try {
      await onSaveRule(editingRule);
      setEditingRule(null);
    } catch (err) {
      console.error('Failed to save rule:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0f172a] border border-slate-700/80 rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Auto-Heal Remediation Governance Rules
              </h2>
              <p className="text-xs text-slate-400">
                Configure autonomous runbooks, services, and script-based remediation for <strong className="text-slate-200">{environmentName}</strong>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {editingRule ? (
            /* Rule Edit Form */
            <form onSubmit={handleSave} className="space-y-4 bg-slate-950/70 p-5 rounded-xl border border-slate-800 animate-in fade-in duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-white">
                    {editingRule.id ? 'Edit Auto-Heal Rule' : 'Create New Auto-Heal Rule'}
                  </span>
                  {editingRule.actionType === 'EXECUTE_SCRIPT' && (
                    <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/30">
                      Script-Based
                    </span>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setEditingRule(null)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Rule Name *</label>
                  <input
                    type="text"
                    required
                    value={editingRule.name || ''}
                    onChange={(e) => setEditingRule({ ...editingRule, name: e.target.value })}
                    placeholder="e.g. Restart Payment API on HTTP 5xx"
                    className="w-full px-3 py-2 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Safety Execution Mode *</label>
                  <select
                    value={editingRule.executionMode || 'AUTOMATIC'}
                    onChange={(e) => setEditingRule({ ...editingRule, executionMode: e.target.value as AutoHealExecutionMode })}
                    className="w-full px-3 py-2 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="AUTOMATIC">AUTOMATIC (Immediate Autonomous Execution)</option>
                    <option value="APPROVAL_REQUIRED">APPROVAL_REQUIRED (Operator Sign-off Needed)</option>
                    <option value="MANUAL">MANUAL (Recommendation Only)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Trigger Check Type</label>
                  <select
                    value={editingRule.triggerCheckType || 'HTTP'}
                    onChange={(e) => setEditingRule({ ...editingRule, triggerCheckType: e.target.value as HealthCheckType })}
                    className="w-full px-3 py-2 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="HTTP">HTTP (Status != 200 or Endpoint Timeout)</option>
                    <option value="DATABASE">DATABASE (Pool Exhaustion / Query Drop)</option>
                    <option value="TCP_PORT">TCP_PORT (Port Closed / Refused)</option>
                    <option value="PING">PING (Host Unreachable)</option>
                    <option value="PROCESS">PROCESS (Process Zombie / Dead)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Remediation Action Type *</label>
                  <select
                    value={editingRule.actionType || 'RESTART_SERVICE'}
                    onChange={(e) => setEditingRule({ ...editingRule, actionType: e.target.value as AutoHealActionType })}
                    className="w-full px-3 py-2 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="EXECUTE_SCRIPT">EXECUTE_SCRIPT (PowerShell / Bash / Python Script)</option>
                    <option value="RESTART_SERVICE">RESTART_SERVICE (Bounce Service Daemon)</option>
                    <option value="RESTART_APPLICATION">RESTART_APPLICATION (Restart App Process)</option>
                    <option value="EXECUTE_RUNBOOK">EXECUTE_RUNBOOK (Execute TEM Runbook)</option>
                    <option value="CLEAR_TEMP_CACHE">CLEAR_TEMP_CACHE (Purge Logs & Locks)</option>
                    <option value="RELOAD_CONFIGURATION">RELOAD_CONFIGURATION (Re-sync Config)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Action Target *</label>
                  <input
                    type="text"
                    required
                    value={editingRule.actionTarget || ''}
                    onChange={(e) => setEditingRule({ ...editingRule, actionTarget: e.target.value })}
                    placeholder="e.g. payment-api-service"
                    className="w-full px-3 py-2 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Max Retries</label>
                    <input
                      type="number"
                      min={1}
                      max={5}
                      value={editingRule.maxRetries || 2}
                      onChange={(e) => setEditingRule({ ...editingRule, maxRetries: parseInt(e.target.value) || 2 })}
                      className="w-full px-3 py-2 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Grace Period (s)</label>
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={editingRule.gracePeriodSeconds || 5}
                      onChange={(e) => setEditingRule({ ...editingRule, gracePeriodSeconds: parseInt(e.target.value) || 5 })}
                      className="w-full px-3 py-2 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {/* SCRIPT CONFIGURATION SECTION */}
                {editingRule.actionType === 'EXECUTE_SCRIPT' && (
                  <div className="md:col-span-2 p-4 rounded-xl bg-slate-900/90 border border-blue-500/30 space-y-3">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-2 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        <Terminal className="w-4 h-4 text-blue-400" />
                        <span className="text-xs font-bold text-white uppercase tracking-wider">
                          Remediation Script Configuration
                        </span>
                      </div>

                      {/* Template Quick Loader */}
                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <span className="text-[11px] text-slate-400 shrink-0">Pre-Approved Template:</span>
                        <select
                          value={selectedTemplateId}
                          onChange={(e) => handleApplyTemplate(e.target.value)}
                          className="px-2.5 py-1 text-xs bg-slate-950 border border-slate-700 rounded text-blue-300 focus:outline-none focus:border-blue-500"
                        >
                          <option value="">-- Choose Vetted Template --</option>
                          {PREAPPROVED_SCRIPT_TEMPLATES.map((t) => (
                            <option key={t.id} value={t.id}>
                              {t.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">Script Runtime *</label>
                        <select
                          value={editingRule.scriptType || 'POWERSHELL'}
                          onChange={(e) => setEditingRule({ ...editingRule, scriptType: e.target.value as AutoHealScriptType })}
                          className="w-full px-3 py-1.5 text-xs bg-slate-950 border border-slate-700 rounded text-white focus:outline-none focus:border-blue-500"
                        >
                          <option value="POWERSHELL">PowerShell (.ps1 / Windows)</option>
                          <option value="BASH">Bash / Shell (.sh / Linux)</option>
                          <option value="PYTHON">Python 3 (Embedded Runner)</option>
                          <option value="COMMAND">Direct Command CLI (Shell Exec)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">Script Timeout (Seconds)</label>
                        <input
                          type="number"
                          min={5}
                          max={300}
                          value={editingRule.scriptTimeoutSeconds || 30}
                          onChange={(e) => setEditingRule({ ...editingRule, scriptTimeoutSeconds: parseInt(e.target.value) || 30 })}
                          className="w-full px-3 py-1.5 text-xs bg-slate-950 border border-slate-700 rounded text-white focus:outline-none focus:border-blue-500"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-medium text-slate-400">
                          Script Body * <span className="text-slate-500 font-normal">(Variables: {'${ACTION_TARGET}'}, {'${ENV_NAME}'}, {'${ENV_ID}'})</span>
                        </label>
                      </div>
                      <textarea
                        rows={6}
                        required
                        value={editingRule.scriptContent || ''}
                        onChange={(e) => setEditingRule({ ...editingRule, scriptContent: e.target.value })}
                        placeholder="# Write remediation script commands here..."
                        className="w-full p-3 font-mono text-xs bg-black/90 border border-slate-700 rounded-lg text-emerald-400 focus:outline-none focus:border-blue-500 leading-relaxed"
                      />
                    </div>
                  </div>
                )}

                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-slate-400 mb-1">Rule Description</label>
                  <textarea
                    rows={2}
                    value={editingRule.description || ''}
                    onChange={(e) => setEditingRule({ ...editingRule, description: e.target.value })}
                    placeholder="Explain what this rule remediates and when it executes..."
                    className="w-full px-3 py-2 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="md:col-span-2 flex items-center justify-between pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                    <input
                      type="checkbox"
                      checked={editingRule.createIncidentOnExhaustion ?? true}
                      onChange={(e) => setEditingRule({ ...editingRule, createIncidentOnExhaustion: e.target.checked })}
                      className="rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-0"
                    />
                    Automatically create SEV2 Incident if retries exhaust
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                    <input
                      type="checkbox"
                      checked={editingRule.isEnabled ?? true}
                      onChange={(e) => setEditingRule({ ...editingRule, isEnabled: e.target.checked })}
                      className="rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-0"
                    />
                    Rule Active / Enabled
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingRule(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white bg-slate-800 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-md flex items-center gap-1.5"
                >
                  {isSaving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                  Save Rule
                </button>
              </div>
            </form>
          ) : (
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">Active Auto-Heal Policies</h3>
                <p className="text-xs text-slate-400">Rules are automatically evaluated when health probes fail.</p>
              </div>
              <button
                onClick={handleStartAdd}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add Auto-Heal Rule
              </button>
            </div>
          )}

          {/* Rules List Table */}
          <div className="space-y-3">
            {rules.length === 0 ? (
              <div className="text-center py-10 border border-dashed border-slate-800 rounded-xl">
                <ShieldCheck className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                <p className="text-sm text-slate-400">No Auto-Heal rules configured for this environment yet.</p>
                <p className="text-xs text-slate-500 mt-1">Default baseline restart rules will be applied upon failure.</p>
              </div>
            ) : (
              rules.map((rule) => (
                <div
                  key={rule.id}
                  className={`p-4 rounded-xl border transition-all ${
                    rule.isEnabled
                      ? 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      : 'bg-slate-950/40 border-slate-900 opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div
                        className={`p-2 rounded-lg mt-0.5 ${
                          rule.actionType === 'EXECUTE_SCRIPT'
                            ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                            : rule.executionMode === 'AUTOMATIC'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : rule.executionMode === 'APPROVAL_REQUIRED'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {rule.actionType === 'EXECUTE_SCRIPT' ? (
                          <Terminal className="w-4 h-4" />
                        ) : rule.executionMode === 'AUTOMATIC' ? (
                          <Zap className="w-4 h-4" />
                        ) : rule.executionMode === 'APPROVAL_REQUIRED' ? (
                          <Lock className="w-4 h-4" />
                        ) : (
                          <Play className="w-4 h-4" />
                        )}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-semibold text-white">{rule.name}</h4>
                          <span
                            className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border ${
                              rule.executionMode === 'AUTOMATIC'
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                                : rule.executionMode === 'APPROVAL_REQUIRED'
                                ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                                : 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                            }`}
                          >
                            {rule.executionMode}
                          </span>
                          {rule.actionType === 'EXECUTE_SCRIPT' && (
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                              {rule.scriptType || 'SCRIPT'}
                            </span>
                          )}
                          {!rule.isEnabled && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                              DISABLED
                            </span>
                          )}
                        </div>

                        {rule.description && (
                          <p className="text-xs text-slate-400 mt-1">{rule.description}</p>
                        )}

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-2 font-mono">
                          <span>Trigger: <strong>{rule.triggerCheckType || 'ANY'} Probe</strong></span>
                          <span>&bull;</span>
                          <span>Action: <strong className="text-emerald-400">{rule.actionType}</strong> ({rule.actionTarget})</span>
                          <span>&bull;</span>
                          <span>Retries: <strong>{rule.maxRetries}</strong> (Grace: {rule.gracePeriodSeconds}s)</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setEditingRule(rule)}
                        className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                        title="Edit Rule"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteRule(rule.id)}
                        className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                        title="Delete Rule"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 flex items-center justify-between bg-slate-900/40 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Closed-Loop Health Verification Enforced for all rules</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
