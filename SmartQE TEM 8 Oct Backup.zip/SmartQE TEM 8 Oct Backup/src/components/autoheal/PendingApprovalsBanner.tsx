import React, { useState } from 'react';
import { AutoHealExecution } from '../../types/autoHeal';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldAlert,
  Zap,
  RefreshCw
} from 'lucide-react';

interface PendingApprovalsBannerProps {
  pendingExecutions: AutoHealExecution[];
  onApprove: (executionId: string) => Promise<void>;
  onReject: (executionId: string) => Promise<void>;
}

export const PendingApprovalsBanner: React.FC<PendingApprovalsBannerProps> = ({
  pendingExecutions,
  onApprove,
  onReject
}) => {
  const [processingId, setProcessingId] = useState<string | null>(null);

  if (pendingExecutions.length === 0) return null;

  const handleApprove = async (id: string) => {
    setProcessingId(id);
    try {
      await onApprove(id);
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (id: string) => {
    setProcessingId(id);
    try {
      await onReject(id);
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-slate-900 border border-amber-500/30 shadow-lg animate-in fade-in duration-200">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 mt-0.5">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-white tracking-tight">
                Auto-Heal Remediation Awaiting Operator Approval ({pendingExecutions.length})
              </h4>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                Action Required
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Safety policy requires manual authorization before dispatching remediation in this environment tier.
            </p>

            <div className="mt-3 space-y-2">
              {pendingExecutions.map((exec) => (
                <div
                  key={exec.id}
                  className="p-3 rounded-lg bg-slate-950/70 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">{exec.environmentName}</span>
                      <span className="text-xs text-slate-400">&bull;</span>
                      <span className="text-xs text-amber-300 font-semibold">{exec.ruleName}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-400">
                        {exec.actionType} ({exec.actionTarget})
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Issue: <span className="text-slate-300">{exec.triggerReason}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                    <button
                      onClick={() => handleReject(exec.id)}
                      disabled={processingId === exec.id}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                    >
                      Reject
                    </button>
                    <button
                      onClick={() => handleApprove(exec.id)}
                      disabled={processingId === exec.id}
                      className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-md flex items-center gap-1.5 transition-colors"
                    >
                      {processingId === exec.id ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      Approve & Heal
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
