import React, { useState } from 'react';
import { AutoHealExecution, AutoHealStatus } from '../../types/autoHeal';
import {
  History,
  CheckCircle2,
  XCircle,
  Clock,
  Zap,
  AlertTriangle,
  FileText,
  Lock,
  ChevronDown,
  ChevronUp,
  Terminal,
  ExternalLink
} from 'lucide-react';

interface AutoHealAuditDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  environmentName: string;
  executions: AutoHealExecution[];
}

export const AutoHealAuditDrawer: React.FC<AutoHealAuditDrawerProps> = ({
  isOpen,
  onClose,
  environmentName,
  executions
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const getStatusBadge = (status: AutoHealStatus) => {
    switch (status) {
      case 'SUCCESS':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" />
            RECOVERED
          </span>
        );
      case 'EXHAUSTED':
      case 'FAILED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/30">
            <XCircle className="w-3.5 h-3.5" />
            EXHAUSTED / FAILED
          </span>
        );
      case 'PENDING_APPROVAL':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Clock className="w-3.5 h-3.5" />
            PENDING APPROVAL
          </span>
        );
      case 'IN_PROGRESS':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/30">
            <Zap className="w-3.5 h-3.5 animate-pulse" />
            REMEDIATING...
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700">
            <Lock className="w-3.5 h-3.5" />
            REJECTED
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-400">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0f172a] border border-slate-700/80 rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400">
              <History className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Auto-Heal Remediation Execution Audit History
              </h2>
              <p className="text-xs text-slate-400">
                Immutable audit log of self-healing actions, re-check results, and incident escalations for <strong className="text-slate-200">{environmentName}</strong>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {executions.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-slate-800 rounded-xl">
              <History className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <p className="text-sm text-slate-400">No Auto-Heal executions recorded for this environment yet.</p>
              <p className="text-xs text-slate-500 mt-1">Executions are automatically logged when remediation actions trigger.</p>
            </div>
          ) : (
            executions.map((exec) => {
              const isExpanded = expandedId === exec.id;
              return (
                <div
                  key={exec.id}
                  className="rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all overflow-hidden"
                >
                  <div
                    onClick={() => setExpandedId(isExpanded ? null : exec.id)}
                    className="p-4 flex items-center justify-between gap-4 cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-4">
                      <div className="text-center min-w-[70px]">
                        <div className="text-xs font-bold text-slate-300">
                          {new Date(exec.startedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {new Date(exec.startedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </div>
                      </div>

                      <div className="h-8 w-px bg-slate-800" />

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-white">
                            {exec.ruleName}
                          </span>
                          {getStatusBadge(exec.status)}
                          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                            {exec.actionType}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">
                          Trigger: <span className="text-slate-300">{exec.triggerReason}</span> &bull; Attempt: <strong className="text-slate-200">{exec.attemptNumber}/{exec.maxRetries}</strong> &bull; Duration: {exec.durationSeconds}s
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {exec.linkedIncidentId && (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/30">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          {exec.linkedIncidentId}
                        </span>
                      )}
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-slate-400" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                  </div>

                  {/* Expanded Execution Details & Logs */}
                  {isExpanded && (
                    <div className="p-4 bg-slate-950/80 border-t border-slate-800 space-y-3 animate-in fade-in duration-150">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                        <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">Execution Mode</span>
                          <span className="font-semibold text-slate-200">{exec.executionMode}</span>
                        </div>
                        <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">Before Health</span>
                          <span className="font-semibold text-rose-400">{exec.beforeHealthStatus}</span>
                        </div>
                        <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">After Health</span>
                          <span className={`font-semibold ${exec.afterHealthStatus === 'HEALTHY' ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {exec.afterHealthStatus || 'UNRESOLVED'}
                          </span>
                        </div>
                        <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">Executed By</span>
                          <span className="font-semibold text-slate-200">{exec.executedBy}</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <Terminal className="w-3.5 h-3.5 text-slate-400" />
                          <span className="text-xs font-semibold text-slate-300">Execution Output & Re-probe Log</span>
                        </div>
                        <pre className="p-3 bg-black/70 border border-slate-800 rounded-lg text-xs font-mono text-emerald-400 overflow-x-auto whitespace-pre-wrap leading-relaxed">
                          {exec.outputLog || 'No detailed stdout available.'}
                        </pre>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 flex items-center justify-between bg-slate-900/40 text-xs text-slate-400">
          <span>Total Recorded Events: {executions.length}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
