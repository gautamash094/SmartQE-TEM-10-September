export type HealthCheckType = 'PING' | 'TCP_PORT' | 'HTTP' | 'DATABASE' | 'PROCESS' | 'SCRIPT';

export type CheckCriticality = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export type HealthStatus = 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'UNKNOWN' | 'NOT_CHECKED' | 'RUNNING';

export interface HealthCheckDefinition {
  id: string;
  name: string;
  checkType: HealthCheckType;
  environmentId: string;
  environmentName?: string;
  applicationId?: string;
  applicationName?: string;
  serverId?: string;
  serverName?: string;
  
  targetHost?: string;
  targetPort?: number;
  targetUrl?: string;
  httpMethod: string;
  
  expectedHttpStatus?: number;
  expectedResponseSubstring?: string;
  timeoutSeconds: number;
  retryCount: number;
  retryIntervalSeconds?: number;
  
  criticality: CheckCriticality;
  weight: number;
  isEnabled: boolean;
  autoHealRunbookId?: string;
  autoHealEnabled: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface HealthCheckResult {
  id: string;
  executionId: string;
  checkDefinitionId?: string;
  checkName: string;
  checkType: HealthCheckType;
  criticality: CheckCriticality;
  target?: string;
  status: HealthStatus;
  responseTimeMs: number;
  outputMessage?: string;
  errorDetails?: string;
  executedAt: string;
}

export interface HealthCheckExecution {
  id: string;
  environmentId: string;
  environmentName: string;
  overallStatus: HealthStatus;
  healthScore: number;
  triggeredBy: string;
  triggerType: string;
  startedAt: string;
  completedAt?: string;
  durationMs: number;
  totalChecks: number;
  passedChecks: number;
  failedChecks: number;
  warningChecks: number;
  summaryMessage?: string;
  autoHealTriggered: boolean;
  linkedIncidentId?: string;
  results: HealthCheckResult[];
}

export interface EnvironmentTierSummary {
  tierName: string; // Server, Database, Application, Network, Dependencies
  status: HealthStatus;
  passed: number;
  total: number;
  avgLatencyMs: number;
}

export interface EnvironmentHealthSummary {
  environmentId: string;
  environmentName: string;
  overallStatus: HealthStatus;
  healthScore: number;
  lastCheckedAt?: string;
  lastExecutionId?: string;
  tierSummaries: EnvironmentTierSummary[];
  latestResults: HealthCheckResult[];
}
