import { EnvironmentProfile, ServerDetail, SoftwareDetail } from './environmentDetails';
import { Incident, Booking } from './index';

export type EnvironmentHealthStatus =
  | 'HEALTHY'
  | 'DEGRADED'
  | 'UNHEALTHY'
  | 'UNAVAILABLE'
  | 'MAINTENANCE'
  | 'UNKNOWN';

export type TestReadinessStatus =
  | 'READY_FOR_TESTING'
  | 'PARTIALLY_READY'
  | 'NOT_READY'
  | 'UNKNOWN';

export type AlertSeverity = 'CRITICAL' | 'WARNING' | 'INFO';
export type AlertStatus = 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED';
export type EventState = 'NORMAL' | 'WARNING' | 'CRITICAL' | 'RECOVERED';
export type TimeframeOption = '1h' | '6h' | '24h' | '7d' | '30d';

export interface HealthCategoryScores {
  infrastructure: number;
  application: number;
  database: number;
  services: number;
  configuration: number;
  overall_health_score: number;
  status: EnvironmentHealthStatus;
  status_details: string;
}

export interface MetricPoint {
  timestamp: string; // ISO string
  value: number;
}

export interface MetricSeries {
  metricName: string;
  unit: string;
  points: MetricPoint[];
  current: number;
  avg: number;
  peak: number;
}

export interface HistoricalTelemetry {
  environmentId: string;
  timeframe: TimeframeOption;
  cpu: MetricSeries;
  memory: MetricSeries;
  disk: MetricSeries;
  networkLatency: MetricSeries;
  responseTime: MetricSeries;
  errorRate: MetricSeries;
  throughput: MetricSeries;
  healthScoreTrend?: MetricSeries;
}

export interface ReadinessCheckResult {
  environmentId: string;
  environmentName: string;
  status: TestReadinessStatus;
  score: number; // 0 to 100
  checks: {
    environmentAvailable: boolean;
    serversOnline: boolean;
    servicesHealthy: boolean;
    databaseConnected?: boolean;
    noVersionDrift?: boolean;
    noBlockingIncidents: boolean;
    noMaintenanceBlock: boolean;
    noBookingCollision: boolean;
  };
  reasons: string[];
}

export interface SoftwareDriftSummary {
  total_software: number;
  matching: number;
  version_mismatch: number;
  missing: number;
  outdated: number;
  consistency_health_score: number;
  has_drift: boolean;
}

export interface ReleaseImpactSummary {
  has_active_workload: boolean;
  impacted_application?: string;
  impacted_release?: string;
  impacted_phase?: string;
  active_bookings_count: number;
  affected_teams: string[];
  affected_users_count: number;
  impact_level: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export interface AutoHealActionSummary {
  is_auto_heal_available: boolean;
  rule_id?: string;
  rule_name?: string;
  action_type?: string;
  action_target?: string;
  requires_approval: boolean;
  last_execution_status?: string;
}

export interface PredictiveInsight {
  insight_type: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  target: string;
  message: string;
  predicted_breach_timeline?: string;
  confidence_score: number;
  recommended_action: string;
}

export interface EnvironmentDetailedObservability {
  environment_id: string;
  environment_name: string;
  tier: string;
  owner: string;
  team: string;
  current_status: EnvironmentHealthStatus;
  uptime: number;
  health: HealthCategoryScores;
  readiness: ReadinessCheckResult;
  cpu_usage: number;
  memory_usage: number;
  storage_usage: number;
  network_latency_ms: number;
  api_p95_ms: number;
  error_rate_pct: number;
  drift_summary: SoftwareDriftSummary;
  impact_summary: ReleaseImpactSummary;
  auto_heal: AutoHealActionSummary;
  predictive_insights: PredictiveInsight[];
  active_critical_alerts: number;
  active_warning_alerts: number;
  last_health_check_time?: string;
}

export interface FleetObservabilityKPIs {
  total_monitored_environments: number;
  healthy_environments: number;
  degraded_environments: number;
  unhealthy_environments: number;
  unavailable_environments: number;
  maintenance_environments: number;
  ready_for_testing_environments: number;
  readiness_rate_pct: number;
  environments_with_drift: number;
  environments_with_active_releases: number;
  fleet_average_health_score: number;
  fleet_availability_pct: number;
  mean_time_to_recovery_minutes: number;
  auto_heal_success_rate_pct: number;
  active_critical_events: number;
  active_warning_events: number;
}

export interface FleetObservabilitySummary {
  kpis: FleetObservabilityKPIs;
  environments: EnvironmentDetailedObservability[];
  recent_events: MonitoringAlert[];
  predictive_alerts: PredictiveInsight[];
}

export interface MonitoringAlert {
  id: string;
  environmentId: string;
  environmentName: string;
  targetType: 'SERVER' | 'SERVICE' | 'APPLICATION' | 'ENVIRONMENT' | 'DATABASE';
  targetId?: string;
  targetName: string;
  title: string;
  message: string;
  severity: AlertSeverity;
  status: AlertStatus;
  state?: EventState;
  currentValue?: number;
  thresholdValue?: number;
  triggeredAt: string;
  acknowledgedAt?: string;
  acknowledgedBy?: string;
  resolvedAt?: string;
  linkedIncidentId?: string;
  autoHealTriggered?: boolean;
}

export interface AlertRule {
  id: string;
  name: string;
  environmentId?: string; // 'ALL' or specific
  metricName: 'CPU' | 'MEMORY' | 'DISK' | 'LATENCY' | 'ERROR_RATE' | 'SERVICE_DOWN';
  operator: '>' | '>=' | '<' | '==';
  threshold: number;
  warningThreshold?: number;
  criticalThreshold?: number;
  durationMinutes: number;
  severity: AlertSeverity;
  autoEscalateIncident: boolean;
  autoHealEnabled?: boolean;
  enabled: boolean;
}

export interface MaintenanceWindow {
  id: string;
  environmentId: string;
  environmentName: string;
  title: string;
  description: string;
  scheduledStart: string;
  scheduledEnd: string;
  createdBy: string;
  suppressAlerts: boolean;
  status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED';
}

export interface TelemetryLog {
  id: string;
  environmentId: string;
  timestamp: string;
  level: 'ERROR' | 'WARN' | 'INFO' | 'DEBUG';
  serviceName: string;
  serverName: string;
  message: string;
  traceId?: string;
}

export interface TelemetryTraceSpan {
  id: string;
  serviceName: string;
  name: string;
  durationMs: number;
  startTimeOffsetMs: number;
  status: 'OK' | 'ERROR';
  tags: Record<string, string>;
}

export interface TelemetryTrace {
  traceId: string;
  environmentId: string;
  rootService: string;
  operationName: string;
  totalDurationMs: number;
  timestamp: string;
  status: 'OK' | 'ERROR';
  spans: TelemetryTraceSpan[];
}

export interface MonitoringSourceIntegration {
  id: string;
  name: string;
  type: 'PROMETHEUS' | 'GRAFANA' | 'DATADOG' | 'DYNATRACE' | 'AWS_CLOUDWATCH' | 'OPENTELEMETRY';
  status: 'CONNECTED' | 'DEGRADED' | 'DISCONNECTED';
  endpoint: string;
  lastSyncAt: string;
  activeMetricsCount: number;
}
