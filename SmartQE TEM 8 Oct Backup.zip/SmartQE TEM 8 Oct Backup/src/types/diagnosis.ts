export type SoftwareDiagnosisStatus =
  | 'MATCH'
  | 'VERSION_MISMATCH'
  | 'MISSING'
  | 'EXTRA'
  | 'OUTDATED'
  | 'UNKNOWN'
  | 'NOT_CHECKED';

export type SoftwareCategory =
  | 'RUNTIME'
  | 'APPLICATION'
  | 'DATABASE'
  | 'QUEUE'
  | 'WEB_SERVER'
  | 'CACHE'
  | 'FRAMEWORK'
  | 'TOOL'
  | 'SERVICE'
  | 'OTHER';

export interface EnvironmentSoftwareItem {
  id: string;
  environment_id: string;
  environment_name: string;
  software_name: string;
  category: SoftwareCategory;
  installed_version?: string | null;
  expected_version?: string | null;
  status: SoftwareDiagnosisStatus;
  port?: string | null;
  process_path?: string | null;
  service_name?: string | null;
  vendor?: string | null;
  last_checked: string;
  check_details?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface EnvironmentOverviewData {
  environment_id: string;
  environment_name: string;
  environment_type: string;
  environment_status: string;
  application?: string | null;
  project?: string | null;
  business_unit?: string | null;
  server_host?: string | null;
  ip_address?: string | null;
  operating_system?: string | null;
  cpu_cores?: number | null;
  ram_gb?: number | null;
  storage_gb?: number | null;
  last_health_check_time?: string | null;
  last_diagnosis_time?: string | null;
  uptime: number;
}

export interface DiagnosisCheckerResult {
  checker_name: string;
  category: string;
  status: 'PASSED' | 'WARNING' | 'CRITICAL' | 'INFO';
  summary: string;
  details: Record<string, any>;
  timestamp: string;
}

export interface DiagnosisSummaryData {
  total_software: number;
  matching: number;
  version_mismatch: number;
  missing: number;
  outdated: number;
  unknown: number;
  not_checked: number;
  consistency_health_score: number;
}

export interface DiagnosisRecommendationItem {
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  category: string;
  software?: string | null;
  title: string;
  description: string;
  recommendation: string;
  remediation_cmd?: string | null;
}

export interface EnvironmentDiagnosisResult {
  environment: EnvironmentOverviewData;
  summary: DiagnosisSummaryData;
  software_inventory: EnvironmentSoftwareItem[];
  checker_results: DiagnosisCheckerResult[];
  recommendations: DiagnosisRecommendationItem[];
  diagnosed_at: string;
}

export interface ComparisonEnvironmentMeta {
  id: string;
  name: string;
  tier: string;
  status: string;
  business_unit?: string | null;
  project?: string | null;
  application?: string | null;
  server_host?: string | null;
  ip_address?: string | null;
}

export interface ComparisonSummaryData {
  total_software: number;
  matching: number;
  version_mismatch: number;
  missing: number;
  extra: number;
  outdated: number;
}

export interface ComparisonDiffItem {
  software: string;
  category: string;
  source_version?: string | null;
  target_version?: string | null;
  status: 'MATCH' | 'VERSION_MISMATCH' | 'MISSING' | 'EXTRA' | 'OUTDATED';
  difference_type: string;
  direction?: 'TARGET_BEHIND' | 'TARGET_AHEAD' | 'IDENTICAL' | 'MISSING_IN_TARGET' | 'EXTRA_IN_TARGET' | null;
  details?: string | null;
  source_port?: string | null;
  target_port?: string | null;
}

export interface ServerComparisonDiff {
  attribute: string;
  source_value?: any;
  target_value?: any;
  status: 'MATCH' | 'MISMATCH';
  details?: string | null;
}

export interface ComparisonRecommendationItem {
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  category: string;
  software?: string | null;
  title: string;
  description: string;
  recommendation: string;
  remediation_cmd?: string | null;
}

export interface EnvironmentComparisonResult {
  source_environment: ComparisonEnvironmentMeta;
  target_environment: ComparisonEnvironmentMeta;
  consistency_score: number;
  summary: ComparisonSummaryData;
  comparison: ComparisonDiffItem[];
  server_comparison: ServerComparisonDiff[];
  recommendations: ComparisonRecommendationItem[];
  compared_at: string;
}

export interface EnvironmentComparisonRequest {
  source_environment_id: string;
  target_environment_id: string;
  include_server_check?: boolean;
  include_health_check?: boolean;
}
