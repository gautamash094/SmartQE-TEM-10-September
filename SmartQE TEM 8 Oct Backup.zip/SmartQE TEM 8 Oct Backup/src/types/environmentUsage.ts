export type UsagePeriod = '30d' | '90d' | '180d' | '365d' | 'custom';

export type UsageCategory = 'Frequently Used' | 'Moderately Used' | 'Rarely Used' | 'Never Used';

export type UsageTrendType = 'Increasing' | 'Decreasing' | 'Stable' | 'No usage';

export interface UsageClassificationThresholds {
  frequentlyUsedUtilization: number; // default: 60
  frequentlyUsedBookings: number;    // default: 15
  moderatelyUsedUtilization: number; // default: 20
  moderatelyUsedBookings: number;    // default: 5
  rarelyUsedUtilization: number;     // default: 0.01
  rarelyUsedBookings: number;        // default: 1
}

export interface TrendPoint {
  periodLabel: string;
  monthName: string;
  year: number;
  utilizationPct: number;
  bookingCount: number;
  hoursBooked: number;
}

export interface EnvironmentUsageItem {
  environmentId: string;
  environmentName: string;
  environmentType: string;
  tier: string;
  primaryApplication: string;
  associatedApplications: string[];
  associatedProjects: string[];
  businessUnit: string;
  usageCategory: UsageCategory;
  bookingCount: number;
  totalUsageHours: number;
  totalUsageDays: number;
  lastUsedDate?: string | null;
  lastUsedFormatted: string;
  utilizationPct: number;
  trend: UsageTrendType;
  trendPctChange: number;
  releaseCount: number;
  associatedReleases: string[];
  topPhase?: string | null;
  phaseBreakdown: Record<string, number>;
  averageBookingDurationHours: number;
  status: string;
  isActive: boolean;
}

export interface UsageSummaryKPIs {
  totalEnvironments: number;
  frequentlyUsedCount: number;
  moderatelyUsedCount: number;
  rarelyUsedCount: number;
  neverUsedCount: number;
  overallUtilizationPct: number;
  totalBookingsCount: number;
  totalUsageHours: number;
  mostUsedEnvironmentName?: string | null;
  mostUsedUtilizationPct: number;
  leastUsedEnvironmentName?: string | null;
  leastUsedUtilizationPct: number;
  unusedEnvironmentsCount: number;
  fleetUsageTrend: UsageTrendType;
}

export interface ApplicationDemandInsight {
  applicationName: string;
  phaseName: string;
  availableEnvironmentsCount: number;
  totalBookingsInPeriod: number;
  avgMonthlyDemand: number;
  demandStatus: 'HIGH_DEMAND' | 'BALANCED' | 'LOW_DEMAND' | 'CAPACITY_SHORTAGE';
  insightMessage: string;
}

export interface UsageRecommendation {
  id: string;
  category: 'REASSIGNMENT' | 'HIGH_DEMAND' | 'CONSOLIDATION' | 'UNBOOKED' | 'CAPACITY';
  severity: 'INFO' | 'WARNING' | 'CRITICAL' | 'SUCCESS';
  targetEnvironment?: string;
  title: string;
  message: string;
  actionableRecommendation: string;
  impactScore: string;
}

export interface UsageAnalysisData {
  periodType: UsagePeriod;
  startDate: string;
  endDate: string;
  totalDays: number;
  summaryKpis: UsageSummaryKPIs;
  thresholdsApplied: UsageClassificationThresholds;
  environments: EnvironmentUsageItem[];
  timeSeriesTrend: TrendPoint[];
  applicationDemandInsights: ApplicationDemandInsight[];
  recommendations: UsageRecommendation[];
}

export interface UsageFilterOptions {
  period: UsagePeriod;
  customStartDate?: string;
  customEndDate?: string;
  searchQuery: string;
  businessUnit: string;
  project: string;
  application: string;
  tier: string;
  testPhase: string;
  category: string;
  sortBy: 'utilization' | 'bookings' | 'hours' | 'name' | 'lastUsed';
  sortOrder: 'asc' | 'desc';
}
