import { HealthCheckType, CheckCriticality, HealthStatus } from './healthCheck';

export type AutoHealExecutionMode = 'AUTOMATIC' | 'APPROVAL_REQUIRED' | 'MANUAL';

export type AutoHealScriptType = 'POWERSHELL' | 'BASH' | 'PYTHON' | 'COMMAND';

export type AutoHealActionType =
  | 'RESTART_SERVICE'
  | 'RESTART_APPLICATION'
  | 'EXECUTE_RUNBOOK'
  | 'EXECUTE_SCRIPT'
  | 'CLEAR_TEMP_CACHE'
  | 'RELOAD_CONFIGURATION';

export type AutoHealStatus =
  | 'PENDING_APPROVAL'
  | 'IN_PROGRESS'
  | 'SUCCESS'
  | 'FAILED'
  | 'REJECTED'
  | 'EXHAUSTED';

export type AutoHealTriggerType =
  | 'HEALTH_CHECK_FAILURE'
  | 'MONITORING_THRESHOLD'
  | 'MANUAL';

export interface AutoHealRule {
  id: string;
  name: string;
  description?: string;
  environmentId?: string;
  environmentName?: string;
  applicationId?: string;
  applicationName?: string;

  triggerType: AutoHealTriggerType;
  triggerCheckType?: HealthCheckType;
  triggerCriticality: CheckCriticality;

  actionType: AutoHealActionType;
  actionTarget: string;
  runbookId?: string;

  // Script-based execution options
  scriptType?: AutoHealScriptType;
  scriptContent?: string;
  scriptTimeoutSeconds?: number;
  scriptParameters?: Record<string, any>;

  executionMode: AutoHealExecutionMode;
  maxRetries: number;
  retryIntervalSeconds: number;
  gracePeriodSeconds: number;

  isEnabled: boolean;
  createIncidentOnExhaustion: boolean;
  incidentSeverity: string;

  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
}

export interface AutoHealExecution {
  id: string;
  ruleId?: string;
  ruleName: string;
  environmentId: string;
  environmentName: string;
  applicationName?: string;

  triggerSource: string;
  triggerReason: string;
  actionType: AutoHealActionType;
  actionTarget: string;

  executionMode: AutoHealExecutionMode;
  status: AutoHealStatus;
  attemptNumber: number;
  maxRetries: number;

  beforeHealthStatus: HealthStatus;
  afterHealthStatus?: HealthStatus;

  startedAt: string;
  completedAt?: string;
  durationSeconds: number;

  outputLog?: string;
  errorDetails?: string;
  linkedIncidentId?: string;

  executedBy: string;
  approvedBy?: string;
  approvedAt?: string;
}

export interface AutoHealStats {
  totalRules: number;
  activeRules: number;
  totalExecutions: number;
  successfulRecoveries: number;
  pendingApprovals: number;
  exhaustedIncidents: number;
  recoveryRatePct: number;
}
