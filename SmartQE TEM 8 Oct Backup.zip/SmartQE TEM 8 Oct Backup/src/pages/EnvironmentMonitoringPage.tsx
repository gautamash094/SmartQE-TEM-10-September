import React, { useState, useMemo, useEffect } from 'react';
import { useTEM } from '../context/TEMContext';
import { monitoringService } from '../services/monitoringService';
import { diagnosisService } from '../services/diagnosisService';
import {
  EnvironmentHealthStatus,
  TestReadinessStatus,
  TimeframeOption,
  MonitoringAlert,
  AlertRule,
  MaintenanceWindow,
  FleetObservabilitySummary,
  EnvironmentDetailedObservability,
  PredictiveInsight,
} from '../types/monitoring';
import { EnvironmentSoftwareItem } from '../types/diagnosis';
import { EnvironmentReadinessBadge } from '../components/monitoring/EnvironmentReadinessBadge';
import { ImpactAnalysisDrawer } from '../components/monitoring/ImpactAnalysisDrawer';
import { ScheduleMaintenanceModal } from '../components/monitoring/ScheduleMaintenanceModal';
import { CardSkeleton, TableSkeleton } from '../components/common/Skeleton';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import {
  Activity,
  Server,
  Cpu,
  Layers,
  Clock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ShieldCheck,
  Filter,
  Plus,
  Search,
  Bell,
  Sliders,
  Database,
  Terminal,
  Zap,
  Globe,
  Radio,
  ExternalLink,
  GitCompare,
  TrendingUp,
  Sparkles,
  ArrowUpRight,
  ShieldAlert,
  Play,
  RotateCcw,
  Trash2,
  StopCircle,
  CalendarCheck,
  Check,
  BellOff,
} from 'lucide-react';
import { HealthCheckSection } from '../components/health/HealthCheckSection';

export const EnvironmentMonitoringPage: React.FC = () => {
  const { environmentProfiles, incidents, bookings, showToast, isLoading } = useTEM();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'health' | 'telemetry' | 'drift' | 'alerts' | 'predictive' | 'maintenance' | 'sources'
  >('overview');

  const [selectedEnvId, setSelectedEnvId] = useState<string>(
    environmentProfiles[0]?.id || ''
  );

  useEffect(() => {
    if (!selectedEnvId && environmentProfiles.length > 0) {
      setSelectedEnvId(environmentProfiles[0].id);
    }
  }, [environmentProfiles, selectedEnvId]);

  const [selectedTimeframe, setSelectedTimeframe] = useState<TimeframeOption>('24h');
  const [logLevelFilter, setLogLevelFilter] = useState<string>('ALL');
  const [logSearch, setLogSearch] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Backend Observability State
  const [fleetSummary, setFleetSummary] = useState<FleetObservabilitySummary | null>(null);
  const [softwareInventory, setSoftwareInventory] = useState<EnvironmentSoftwareItem[]>([]);
  const [isLoadingObservability, setIsLoadingObservability] = useState<boolean>(false);

  // Alerts & Rules state
  const [alerts, setAlerts] = useState<MonitoringAlert[]>(() => monitoringService.getAlerts());
  const [alertRules, setAlertRules] = useState<AlertRule[]>(() => monitoringService.getAlertRules());
  const [maintenanceList, setMaintenanceList] = useState<MaintenanceWindow[]>(() =>
    monitoringService.getMaintenanceWindows()
  );
  const [isScheduleMaintenanceOpen, setIsScheduleMaintenanceOpen] = useState<boolean>(false);
  const [maintenanceFilter, setMaintenanceFilter] = useState<'ALL' | 'IN_PROGRESS' | 'SCHEDULED' | 'COMPLETED'>('ALL');

  // Impact Analysis Drawer state
  const [impactDrawerNode, setImpactDrawerNode] = useState<{
    type: 'SERVER' | 'SOFTWARE' | 'ENVIRONMENT';
    name: string;
    id: string;
    environmentName?: string;
  } | null>(null);

  // Fetch backend observability data on mount
  const loadFleetData = async () => {
    setIsLoadingObservability(true);
    try {
      const summary = await monitoringService.getFleetSummary();
      if (summary) {
        setFleetSummary(summary);
      }
    } catch (err) {
      console.warn('Could not load fleet summary:', err);
    } finally {
      setIsLoadingObservability(false);
    }
  };

  useEffect(() => {
    loadFleetData();
  }, []);

  // Fetch software inventory when selectedEnvId changes or drift tab active
  useEffect(() => {
    if (selectedEnvId) {
      diagnosisService.getSoftwareInventory(selectedEnvId).then((items) => {
        setSoftwareInventory(items || []);
      });
    }
  }, [selectedEnvId, activeTab]);

  // Fallback Computed Environment Monitoring Summaries
  const fleetHealthList = useMemo(() => {
    return (environmentProfiles || []).map((env) => {
      const health = monitoringService.calculateEnvironmentHealth(env, incidents);
      const readiness = monitoringService.evaluateTestReadiness(env, incidents, bookings);
      return { env, health, readiness };
    });
  }, [environmentProfiles, incidents, bookings]);

  const metricsSummary = useMemo(() => {
    if (fleetSummary && fleetSummary.kpis) {
      const k = fleetSummary.kpis;
      return {
        total: k.total_monitored_environments,
        healthy: k.healthy_environments,
        degraded: k.degraded_environments,
        unhealthy: k.unhealthy_environments,
        maintenance: k.maintenance_environments,
        readyForTesting: k.ready_for_testing_environments,
        driftCount: k.environments_with_drift,
        fleetAvailability: k.fleet_availability_pct,
        mttr: k.mean_time_to_recovery_minutes,
      };
    }

    const total = fleetHealthList.length;
    const healthy = fleetHealthList.filter((f) => f.health.status === 'HEALTHY').length;
    const degraded = fleetHealthList.filter((f) => f.health.status === 'DEGRADED').length;
    const unhealthy = fleetHealthList.filter((f) => f.health.status === 'UNHEALTHY').length;
    const maintenance = fleetHealthList.filter((f) => f.health.status === 'MAINTENANCE').length;
    const readyForTesting = fleetHealthList.filter(
      (f) => f.readiness.status === 'READY_FOR_TESTING'
    ).length;

    return {
      total,
      healthy,
      degraded,
      unhealthy,
      maintenance,
      readyForTesting,
      driftCount: 1,
      fleetAvailability: 99.8,
      mttr: 18.5,
    };
  }, [fleetSummary, fleetHealthList]);

  // Selected Environment Data
  const currentEnvProfile = useMemo(() => {
    return environmentProfiles.find((e) => e.id === selectedEnvId) || environmentProfiles[0];
  }, [environmentProfiles, selectedEnvId]);

  const currentTelemetry = useMemo(() => {
    return monitoringService.getHistoricalTelemetry(selectedEnvId, selectedTimeframe);
  }, [selectedEnvId, selectedTimeframe]);

  const currentLogs = useMemo(() => {
    const raw = monitoringService.getCorrelatedLogs(selectedEnvId, logLevelFilter);
    if (!logSearch) return raw;
    const q = logSearch.toLowerCase();
    return raw.filter(
      (l) =>
        l.message.toLowerCase().includes(q) ||
        l.serviceName.toLowerCase().includes(q) ||
        l.serverName.toLowerCase().includes(q)
    );
  }, [selectedEnvId, logLevelFilter, logSearch]);

  const currentTraces = useMemo(() => {
    return monitoringService.getCorrelatedTraces(selectedEnvId);
  }, [selectedEnvId]);

  // Alert Actions
  const handleAcknowledgeAlert = (id: string) => {
    const updated = monitoringService.acknowledgeAlert(id, 'Ops Engineer');
    setAlerts(updated);
    showToast('Monitoring Alert acknowledged', 'info');
  };

  const handleResolveAlert = (id: string) => {
    const updated = monitoringService.resolveAlert(id);
    setAlerts(updated);
    showToast('Monitoring Alert resolved', 'success');
  };

  const handleRemediateAlert = async (alertId: string) => {
    setIsRefreshing(true);
    showToast('Dispatching Auto-Heal remediation...', 'info');
    const res = await monitoringService.remediateEvent(alertId);
    if (res.success) {
      handleResolveAlert(alertId);
      showToast(res.message, 'success');
      loadFleetData();
    } else {
      showToast(res.message, 'error');
    }
    setIsRefreshing(false);
  };

  const handleTriggerHealthCheck = async (envId: string) => {
    setIsRefreshing(true);
    showToast('Running multi-tier synthetic health check...', 'info');
    const updated = await monitoringService.triggerHealthCheckAndRefresh(envId);
    if (updated) {
      showToast(`Health check complete for ${updated.environment_name}. Status: ${updated.current_status}`, 'success');
      loadFleetData();
    } else {
      showToast('Health check triggered', 'info');
    }
    setIsRefreshing(false);
  };

  const handleSaveMaintenanceWindow = (window: MaintenanceWindow) => {
    const updated = monitoringService.saveMaintenanceWindow(window);
    setMaintenanceList(updated);
    showToast(`Scheduled maintenance for ${window.environmentName}`, 'success');
    loadFleetData();
  };

  const handleEndMaintenanceWindow = (windowId: string) => {
    const updated = monitoringService.endMaintenanceWindow(windowId);
    setMaintenanceList(updated);
    showToast('Maintenance window marked as completed', 'info');
    loadFleetData();
  };

  const handleDeleteMaintenanceWindow = (windowId: string) => {
    const updated = monitoringService.deleteMaintenanceWindow(windowId);
    setMaintenanceList(updated);
    showToast('Maintenance window removed', 'info');
    loadFleetData();
  };

  const integrations = useMemo(() => monitoringService.getIntegrations(), []);

  // Predictive Insights
  const predictiveAlerts: PredictiveInsight[] = useMemo(() => {
    if (fleetSummary && fleetSummary.predictive_alerts && fleetSummary.predictive_alerts.length > 0) {
      return fleetSummary.predictive_alerts;
    }
    return [
      {
        insight_type: 'CAPACITY_WARNING',
        severity: 'WARNING',
        target: 'Memory Saturation Trend',
        message: 'Memory utilization on SIT-03 has increased consistently over the last 14 days. Predicted to exceed 90% threshold within 3 days.',
        predicted_breach_timeline: '3 days',
        confidence_score: 0.92,
        recommended_action: 'Recycle Java application pool or allocate additional container memory.',
      },
      {
        insight_type: 'DRIFT_RISK',
        severity: 'WARNING',
        target: 'Software Version Drift',
        message: 'Java Runtime on SIT is v17.0.8 while expected baseline is v17.0.10. Regression tests may exhibit incompatible behavior.',
        predicted_breach_timeline: 'Immediate',
        confidence_score: 0.96,
        recommended_action: 'Execute automated upgrade runbook to align versions before test cycle.',
      },
    ];
  }, [fleetSummary]);

  return (
    <div className="space-y-6 font-sans w-full min-w-0">
      {/* Top Banner Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              ENTERPRISE OBSERVABILITY
            </span>
            <span className="text-slate-600">/</span>
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-orange-400 flex items-center gap-1">
              <Activity className="w-3 h-3" /> TEM MONITORING & READINESS
            </span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight flex items-center gap-3 mt-1">
            Environment Observability
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Enterprise health scoring, multi-dimensional test readiness, version drift, threshold state machines, and closed-loop auto-healing.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              loadFleetData();
              showToast('Refreshed fleet telemetry & readiness pipelines', 'success');
            }}
            disabled={isRefreshing}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-xs font-mono font-bold text-slate-300 transition-colors shadow-sm disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-orange-400 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>SYNC TELEMETRY</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'overview'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Fleet Overview & Readiness ({metricsSummary.total})</span>
        </button>

        <button
          onClick={() => setActiveTab('health')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'health'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Synthetic Health Checks</span>
        </button>

        <button
          onClick={() => setActiveTab('telemetry')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'telemetry'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Metrics & Historical Trends</span>
        </button>

        <button
          onClick={() => setActiveTab('drift')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'drift'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <GitCompare className="w-4 h-4 text-amber-400" />
          <span>Configuration & Version Drift ({metricsSummary.driftCount})</span>
        </button>

        <button
          onClick={() => setActiveTab('alerts')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'alerts'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Bell className="w-4 h-4 text-rose-400" />
          <span>Active Alerts & Events ({alerts.filter((a) => a.status === 'ACTIVE').length})</span>
        </button>

        <button
          onClick={() => setActiveTab('predictive')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'predictive'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span>Predictive Health & AI ({predictiveAlerts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('maintenance')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'maintenance'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Maintenance Windows ({maintenanceList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('sources')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'sources'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Radio className="w-4 h-4" />
          <span>Telemetry Sources</span>
        </button>
      </div>

      {/* TAB 1: EXECUTIVE FLEET HEALTH & READINESS */}
      {activeTab === 'overview' && (
        isLoading || isLoadingObservability ? (
          <div className="space-y-4">
            <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 flex items-center justify-center shadow-xl">
              <LoadingSpinner size="md" variant="primary" />
            </div>
            <CardSkeleton count={6} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Enterprise TEM Operational KPI Summary Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 font-mono text-xs">
              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-slate-500 uppercase font-bold block">MONITORED ENVS</span>
                <span className="text-2xl font-extrabold text-white block">{metricsSummary.total}</span>
                <span className="text-[10px] text-slate-400">100% Covered</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-emerald-400 uppercase font-bold block">HEALTHY ENVS</span>
                <span className="text-2xl font-extrabold text-emerald-400 block">{metricsSummary.healthy}</span>
                <span className="text-[10px] text-emerald-500">Nominal State</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-amber-400 uppercase font-bold block">DEGRADED</span>
                <span className="text-2xl font-extrabold text-amber-400 block">{metricsSummary.degraded}</span>
                <span className="text-[10px] text-amber-500">Elevated Latency</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-rose-400 uppercase font-bold block">UNHEALTHY</span>
                <span className="text-2xl font-extrabold text-rose-400 block">{metricsSummary.unhealthy}</span>
                <span className="text-[10px] text-rose-500">Action Required</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl space-y-1 shadow-lg bg-gradient-to-br from-emerald-950/40 to-slate-900">
                <span className="text-[10px] text-emerald-400 uppercase font-bold block">READY FOR TEST</span>
                <span className="text-2xl font-extrabold text-white block">{metricsSummary.readyForTesting}</span>
                <span className="text-[10px] text-emerald-400 font-bold">Passed Checks</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-amber-300 uppercase font-bold block">DRIFT DETECTED</span>
                <span className="text-2xl font-extrabold text-amber-300 block">{metricsSummary.driftCount}</span>
                <span className="text-[10px] text-amber-400">Version Mismatch</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-blue-400 uppercase font-bold block">FLEET AVAIL %</span>
                <span className="text-2xl font-extrabold text-blue-400 block">{metricsSummary.fleetAvailability}%</span>
                <span className="text-[10px] text-blue-500">SLA: 99.5%</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-purple-400 uppercase font-bold block">AVG MTTR</span>
                <span className="text-2xl font-extrabold text-purple-400 block">{metricsSummary.mttr}m</span>
                <span className="text-[10px] text-purple-500">Auto-Heal Active</span>
              </div>
            </div>

            {/* Fleet Health & Test Readiness Dossiers */}
            <div className="space-y-3">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                <span>ENTERPRISE ENVIRONMENT HEALTH & READINESS DOSSIERS</span>
                <span className="text-slate-500 text-[11px] normal-case">Weighted Health Score: Infra (30%) + App (25%) + DB (20%) + Services (15%) + Config (10%)</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {fleetHealthList.map(({ env, health, readiness }) => (
                  <div
                    key={env.id}
                    className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 hover:border-slate-700 rounded-xl p-5 space-y-4 transition-all shadow-xl font-mono text-xs group"
                  >
                    {/* Top Header */}
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-500 font-bold uppercase block">{env.type}</span>
                          <span className="text-slate-600">·</span>
                          <span className="text-[10px] text-orange-400 font-bold uppercase">SIT / Active</span>
                        </div>
                        <h4 className="text-base font-extrabold text-white group-hover:text-orange-400 transition-colors">
                          {env.name}
                        </h4>
                        <p className="text-[10px] text-slate-500 mt-0.5">ID: {env.id} · Team: {env.ownerTeam || 'TEM Lead'}</p>
                      </div>

                      <EnvironmentReadinessBadge status={readiness.status} result={readiness} size="md" />
                    </div>

                    {/* Weighted Health Score Gauge */}
                    <div className="space-y-1.5 bg-slate-950/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800/80">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400 font-bold">Overall Health Score</span>
                        <span className={`font-extrabold ${health.score >= 90 ? 'text-emerald-400' : health.score >= 65 ? 'text-amber-400' : 'text-rose-400'}`}>
                          {health.score}%
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            health.score >= 90
                              ? 'bg-emerald-500'
                              : health.score >= 65
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${health.score}%` }}
                        />
                      </div>
                      
                      {/* Category Breakdown Bar */}
                      {health.breakdown && (
                        <div className="grid grid-cols-5 gap-1 text-[9px] pt-1 text-slate-400 border-t border-slate-900 mt-2">
                          <div>Infra: <strong className="text-white">{health.breakdown.infrastructure}%</strong></div>
                          <div>App: <strong className="text-white">{health.breakdown.application}%</strong></div>
                          <div>DB: <strong className="text-white">{health.breakdown.database}%</strong></div>
                          <div>Svc: <strong className="text-white">{health.breakdown.services}%</strong></div>
                          <div>Cfg: <strong className="text-white">{health.breakdown.configuration}%</strong></div>
                        </div>
                      )}
                    </div>

                    {/* Readiness Blocking Reasons */}
                    {readiness.status !== 'READY_FOR_TESTING' && readiness.reasons && (
                      <div className="bg-amber-950/30 border border-amber-800/50 rounded-lg p-2.5 space-y-1">
                        <span className="text-[10px] text-amber-300 font-bold uppercase flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3 text-amber-400" /> Readiness Blockers
                        </span>
                        <ul className="text-[10px] text-slate-300 list-disc list-inside space-y-0.5">
                          {readiness.reasons.slice(0, 2).map((r, i) => (
                            <li key={i}>{r}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Action Bar */}
                    <div className="pt-2 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleTriggerHealthCheck(env.id)}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold flex items-center gap-1 border border-slate-700"
                        >
                          <Play className="w-3 h-3 text-emerald-400" /> Check Health
                        </button>

                        <button
                          onClick={() => {
                            setSelectedEnvId(env.id);
                            setActiveTab('drift');
                          }}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold flex items-center gap-1 border border-slate-700"
                        >
                          <GitCompare className="w-3 h-3 text-amber-400" /> Drift
                        </button>
                      </div>

                      <button
                        onClick={() =>
                          setImpactDrawerNode({
                            type: 'ENVIRONMENT',
                            id: env.id,
                            name: env.name,
                            environmentName: env.name,
                          })
                        }
                        className="text-orange-400 hover:text-orange-300 font-bold text-[11px] flex items-center gap-1"
                      >
                        <Zap className="w-3.5 h-3.5 text-amber-400" /> BLAST RADIUS
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )
      )}

      {/* TAB 2: SYNTHETIC HEALTH CHECKS */}
      {activeTab === 'health' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl flex flex-wrap items-center justify-between gap-4 shadow-lg">
            <div className="flex items-center gap-3">
              <span className="text-slate-400 font-bold">SELECT ENVIRONMENT:</span>
              <select
                value={selectedEnvId}
                onChange={(e) => setSelectedEnvId(e.target.value)}
                className="bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white font-bold text-xs focus:outline-none focus:border-orange-500"
              >
                {environmentProfiles.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} ({e.type})
                  </option>
                ))}
                {environmentProfiles.length === 0 && (
                  <option value="env-001">PAY-QA-01 (QA / Testing)</option>
                )}
              </select>
            </div>

            <div className="text-slate-400 text-xs flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Enterprise Health Check Engine Connected</span>
            </div>
          </div>

          <HealthCheckSection
            environmentId={selectedEnvId || (environmentProfiles[0]?.id || 'env-001')}
            environmentName={
              environmentProfiles.find((e) => e.id === selectedEnvId)?.name || 'PAY-QA-01'
            }
          />
        </div>
      )}

      {/* TAB 3: METRICS & HISTORICAL TRENDS */}
      {activeTab === 'telemetry' && (
        <div className="space-y-6 font-mono text-xs">
          {/* Controls Bar */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl flex flex-wrap items-center justify-between gap-4 shadow-lg">
            <div className="flex items-center gap-3">
              <span className="text-slate-400 font-bold">SELECT ENVIRONMENT:</span>
              <select
                value={selectedEnvId}
                onChange={(e) => setSelectedEnvId(e.target.value)}
                className="bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white font-bold text-xs focus:outline-none focus:border-orange-500"
              >
                {environmentProfiles.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} ({e.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-slate-400 font-bold">TIMEFRAME:</span>
              {(['1h', '6h', '24h', '7d', '30d'] as TimeframeOption[]).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setSelectedTimeframe(tf)}
                  className={`px-2.5 py-1 rounded font-bold transition-colors ${
                    selectedTimeframe === tf
                      ? 'bg-orange-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>

          {/* Historical Telemetry Metric Charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* CPU */}
            <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold uppercase text-[10px]">CPU SATURATION</span>
                <Server className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-extrabold text-white">
                {currentTelemetry.cpu.current}%
              </div>
              <p className="text-[10px] text-slate-500">
                Avg: {currentTelemetry.cpu.avg}% · Peak: {currentTelemetry.cpu.peak}%
              </p>
            </div>

            {/* RAM */}
            <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold uppercase text-[10px]">MEMORY UTILIZATION</span>
                <Cpu className="w-4 h-4 text-rose-400" />
              </div>
              <div className="text-2xl font-extrabold text-white">
                {currentTelemetry.memory.current}%
              </div>
              <p className="text-[10px] text-slate-500">
                Avg: {currentTelemetry.memory.avg}% · Peak: {currentTelemetry.memory.peak}%
              </p>
            </div>

            {/* Response Time */}
            <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold uppercase text-[10px]">API P95 RESPONSE TIME</span>
                <Clock className="w-4 h-4 text-orange-400" />
              </div>
              <div className="text-2xl font-extrabold text-white">
                {currentTelemetry.responseTime.current}ms
              </div>
              <p className="text-[10px] text-slate-500">
                Avg: {currentTelemetry.responseTime.avg}ms · Peak: {currentTelemetry.responseTime.peak}ms
              </p>
            </div>

            {/* Error Rate */}
            <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold uppercase text-[10px]">APPLICATION ERROR RATE</span>
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-extrabold text-white">
                {currentTelemetry.errorRate.current}%
              </div>
              <p className="text-[10px] text-slate-500">
                Avg: {currentTelemetry.errorRate.avg}% · Peak: {currentTelemetry.errorRate.peak}%
              </p>
            </div>
          </div>

          {/* Correlated Log Streams Viewer */}
          <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Terminal className="w-4 h-4 text-orange-400" /> CORRELATED TELEMETRY LOG STREAM ({currentLogs.length})
              </h3>

              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    autoComplete="off"
                    data-lpignore="true"
                    type="text"
                    value={logSearch}
                    onChange={(e) => setLogSearch(e.target.value)}
                    placeholder="Search logs..."
                    className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded pl-8 pr-3 py-1 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                  />
                </div>

                <select
                  value={logLevelFilter}
                  onChange={(e) => setLogLevelFilter(e.target.value)}
                  className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-1 text-white text-xs"
                >
                  <option value="ALL">All Severities</option>
                  <option value="ERROR">ERROR Only</option>
                  <option value="WARN">WARN Only</option>
                  <option value="INFO">INFO Only</option>
                </select>
              </div>
            </div>

            <div className="bg-black/60 dark:bg-black/80 rounded-lg p-3 space-y-2 font-mono text-[11px] max-h-72 overflow-y-auto border border-slate-900 divide-y divide-slate-900">
              {currentLogs.length === 0 ? (
                <p className="text-slate-600 italic text-center py-6">No telemetry logs matched filter criteria.</p>
              ) : (
                currentLogs.map((log) => (
                  <div key={log.id} className="pt-2 flex items-start gap-3">
                    <span className="text-slate-500 shrink-0">{log.timestamp.replace('T', ' ').substring(11, 19)}</span>
                    <span
                      className={`font-bold shrink-0 px-1.5 py-0.2 rounded text-[10px] ${
                        log.level === 'ERROR'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : log.level === 'WARN'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {log.level}
                    </span>
                    <span className="text-orange-400 font-bold shrink-0">[{log.serviceName}]</span>
                    <span className="text-slate-300 flex-1">{log.message}</span>
                    {log.traceId && (
                      <span className="text-[10px] text-slate-500 font-mono bg-slate-900 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-800 shrink-0">
                        Trace: {log.traceId}
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: CONFIGURATION & VERSION DRIFT */}
      {activeTab === 'drift' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl flex flex-wrap items-center justify-between gap-4 shadow-lg">
            <div className="flex items-center gap-3">
              <span className="text-slate-400 font-bold">SELECT ENVIRONMENT:</span>
              <select
                value={selectedEnvId}
                onChange={(e) => setSelectedEnvId(e.target.value)}
                className="bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white font-bold text-xs focus:outline-none focus:border-orange-500"
              >
                {environmentProfiles.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} ({e.type})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => showToast('Dispatched configuration baseline sync', 'info')}
              className="px-3.5 py-1.5 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" /> SYNC EXPECTED BASELINE
            </button>
          </div>

          <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <GitCompare className="w-4 h-4 text-amber-400" /> DEPLOYED SOFTWARE & RUNTIME VERSION DRIFT ({softwareInventory.length})
            </h3>

            {softwareInventory.length === 0 ? (
              <p className="text-slate-500 italic text-center py-6">No software packages registered for this environment.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-[11px] text-slate-400">
                      <th className="py-2.5 px-3">Software Component</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3">Installed Version</th>
                      <th className="py-2.5 px-3">Expected Baseline</th>
                      <th className="py-2.5 px-3">Drift Status</th>
                      <th className="py-2.5 px-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {softwareInventory.map((sw) => {
                      const isMatch = sw.status === 'MATCH';
                      const isMismatch = sw.status === 'VERSION_MISMATCH';
                      return (
                        <tr key={sw.id || sw.software_name} className="hover:bg-slate-900/40">
                          <td className="py-3 px-3 font-bold text-white">{sw.software_name}</td>
                          <td className="py-3 px-3 text-slate-400">{sw.category}</td>
                          <td className="py-3 px-3 font-bold text-orange-400">{sw.installed_version || 'Not Detected'}</td>
                          <td className="py-3 px-3 text-slate-300">{sw.expected_version || 'None'}</td>
                          <td className="py-3 px-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                isMatch
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                  : isMismatch
                                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                  : 'bg-rose-950 text-rose-300 border border-rose-800'
                              }`}
                            >
                              {sw.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right">
                            {isMismatch && (
                              <button
                                onClick={() => showToast(`Auto-aligning ${sw.software_name} to v${sw.expected_version}`, 'info')}
                                className="px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-500 text-white font-bold text-[10px]"
                              >
                                Align Version
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: ACTIVE ALERTS & EVENTS */}
      {activeTab === 'alerts' && (
        <div className="space-y-6 font-mono text-xs">
          {/* Active Alerts Feed */}
          <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <Bell className="w-4 h-4 text-rose-400" /> REAL-TIME MONITORING EVENTS & THRESHOLD BREACHES ({alerts.length})
            </h3>

            <div className="space-y-3">
              {alerts.length === 0 ? (
                <p className="text-slate-500 italic text-center py-6">No active monitoring alerts.</p>
              ) : (
                alerts.map((alt) => (
                  <div
                    key={alt.id}
                    className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg ${
                      alt.severity === 'CRITICAL'
                        ? 'bg-[#1f0b0e] border-rose-800 text-rose-100'
                        : alt.severity === 'WARNING'
                        ? 'bg-[#1c1409] border-amber-800 text-amber-100'
                        : 'bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-200'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-white text-sm">{alt.title}</span>
                        <span className="px-2 py-0.2 rounded text-[10px] font-bold uppercase bg-black/60 border border-slate-200 dark:border-slate-800">
                          {alt.severity}
                        </span>
                        <span className="text-[10px] text-slate-400">{alt.environmentName}</span>
                      </div>
                      <p className="text-xs text-slate-300">{alt.message}</p>
                      <p className="text-[10px] text-slate-500">
                        Triggered: {alt.triggeredAt.replace('T', ' ').substring(0, 19)} · Target: {alt.targetName}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {alt.status === 'ACTIVE' && (
                        <button
                          onClick={() => handleAcknowledgeAlert(alt.id)}
                          className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700"
                        >
                          Acknowledge
                        </button>
                      )}
                      <button
                        onClick={() => handleRemediateAlert(alt.id)}
                        className="px-3 py-1.5 rounded bg-emerald-700 hover:bg-emerald-600 text-xs font-bold text-white border border-emerald-600 flex items-center gap-1"
                      >
                        <Zap className="w-3.5 h-3.5" /> 1-Click Auto-Heal
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: PREDICTIVE HEALTH & AI */}
      {activeTab === 'predictive' && (
        <div className="space-y-6 font-mono text-xs">
          <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <Sparkles className="w-4 h-4 text-purple-400" /> INTELLIGENT HEALTH FORECASTS & CAPACITY PREDICTIONS ({predictiveAlerts.length})
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {predictiveAlerts.map((pred, i) => (
                <div key={i} className="bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-white text-sm flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-purple-400" /> {pred.target}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-800">
                      {Math.round(pred.confidence_score * 100)}% Confidence
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">{pred.message}</p>
                  <div className="bg-black/40 p-2.5 rounded border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block">RECOMMENDED ACTION</span>
                    <p className="text-[11px] text-emerald-400">{pred.recommended_action}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: MAINTENANCE WINDOWS */}
      {activeTab === 'maintenance' && (
        <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-400" /> SCHEDULED ENVIRONMENT MAINTENANCE WINDOWS ({maintenanceList.length})
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Manage planned downtime windows, suppress monitoring false-positives, and notify test teams.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center bg-[#161f2e] border border-slate-700 rounded-lg p-0.5">
                {(['ALL', 'IN_PROGRESS', 'SCHEDULED', 'COMPLETED'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setMaintenanceFilter(st)}
                    className={`px-2.5 py-1 rounded text-[10px] font-bold transition-colors ${
                      maintenanceFilter === st
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {st.replace('_', ' ')}
                  </button>
                ))}
              </div>

              <button
                onClick={() => setIsScheduleMaintenanceOpen(true)}
                className="px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-blue-950/40 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>SCHEDULE MAINTENANCE</span>
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {maintenanceList.filter((m) => maintenanceFilter === 'ALL' || m.status === maintenanceFilter).length === 0 ? (
              <div className="text-center py-12 border border-dashed border-slate-800 rounded-xl space-y-3">
                <div className="w-10 h-10 rounded-full bg-blue-950/60 border border-blue-800 flex items-center justify-center text-blue-400 mx-auto">
                  <CalendarCheck className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <p className="text-white font-bold text-sm">No Maintenance Windows Scheduled</p>
                  <p className="text-slate-500 text-[11px]">
                    All environments are running active workloads. Click Schedule Maintenance to plan downtime.
                  </p>
                </div>
                <button
                  onClick={() => setIsScheduleMaintenanceOpen(true)}
                  className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
                >
                  + Schedule Window
                </button>
              </div>
            ) : (
              maintenanceList
                .filter((m) => maintenanceFilter === 'ALL' || m.status === maintenanceFilter)
                .map((m) => {
                  const isInProgress = m.status === 'IN_PROGRESS';
                  const isScheduled = m.status === 'SCHEDULED';
                  const isCompleted = m.status === 'COMPLETED';

                  return (
                    <div
                      key={m.id}
                      className={`p-4 rounded-xl border space-y-3 transition-all ${
                        isInProgress
                          ? 'bg-blue-950/30 border-blue-800 shadow-lg shadow-blue-950/20'
                          : isScheduled
                          ? 'bg-purple-950/20 border-purple-800/80'
                          : 'bg-slate-900/60 border-slate-800 opacity-80'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-white text-sm">{m.title}</span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                isInProgress
                                  ? 'bg-blue-950 text-blue-300 border border-blue-700 animate-pulse'
                                  : isScheduled
                                  ? 'bg-purple-950 text-purple-300 border border-purple-700'
                                  : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              }`}
                            >
                              {m.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-300">{m.description}</p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {(isInProgress || isScheduled) && (
                            <button
                              onClick={() => handleEndMaintenanceWindow(m.id)}
                              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold border border-slate-700 flex items-center gap-1"
                            >
                              <StopCircle className="w-3.5 h-3.5 text-amber-400" /> End Window
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteMaintenanceWindow(m.id)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-rose-950 hover:text-rose-400 text-slate-400 text-[10px] border border-slate-700 transition-colors"
                            title="Delete Maintenance Window"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 text-[10px] text-slate-400 pt-2 border-t border-slate-800/80">
                        <div>
                          Target Environment: <strong className="text-orange-400">{m.environmentName}</strong>
                        </div>
                        <div>
                          Start: <span className="text-slate-200">{m.scheduledStart?.replace('T', ' ').substring(0, 16)}</span>
                        </div>
                        <div>
                          End: <span className="text-slate-200">{m.scheduledEnd?.replace('T', ' ').substring(0, 16)}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <BellOff className="w-3 h-3 text-blue-400" />
                          Alert Suppression:{' '}
                          <strong className={m.suppressAlerts ? 'text-emerald-400' : 'text-slate-400'}>
                            {m.suppressAlerts ? 'Active (Alerts Muted)' : 'Disabled'}
                          </strong>
                        </div>
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </div>
      )}

      {/* TAB 8: TELEMETRY SOURCES */}
      {activeTab === 'sources' && (
        <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
            <Radio className="w-4 h-4 text-orange-400" /> TELEMETRY ADAPTERS & SOURCES ({integrations.length})
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {integrations.map((integ) => (
              <div key={integ.id} className="bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-white">{integ.name}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                    {integ.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{integ.endpoint}</p>
                <p className="text-[10px] text-slate-500">
                  Active Metrics: <strong className="text-orange-400">{integ.activeMetricsCount}</strong> · Last Sync: {integ.lastSyncAt.replace('T', ' ').substring(11, 19)} UTC
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Impact Analysis Drawer Modal */}
      <ImpactAnalysisDrawer
        isOpen={!!impactDrawerNode}
        onClose={() => setImpactDrawerNode(null)}
        targetNode={impactDrawerNode}
        environments={environmentProfiles}
        bookings={bookings}
      />

      {/* Schedule Maintenance Window Modal */}
      <ScheduleMaintenanceModal
        isOpen={isScheduleMaintenanceOpen}
        onClose={() => setIsScheduleMaintenanceOpen(false)}
        onSave={handleSaveMaintenanceWindow}
        environments={environmentProfiles}
        initialEnvironmentId={selectedEnvId}
      />
    </div>
  );
};
