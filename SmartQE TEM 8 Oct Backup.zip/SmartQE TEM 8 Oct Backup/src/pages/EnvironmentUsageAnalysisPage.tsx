import React, { useState, useEffect, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import {
  environmentUsageService,
  DEFAULT_USAGE_THRESHOLDS,
} from '../services/environmentUsageService';
import {
  UsagePeriod,
  UsageCategory,
  UsageTrendType,
  UsageClassificationThresholds,
  EnvironmentUsageItem,
  UsageFilterOptions,
  UsageRecommendation,
  ApplicationDemandInsight,
} from '../types/environmentUsage';
import { Booking, Release } from '../types';
import { Pagination } from '../components/common/Pagination';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { CardSkeleton, TableSkeleton } from '../components/common/Skeleton';
import {
  Activity,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Clock,
  Calendar,
  Layers,
  Sparkles,
  Sliders,
  Filter,
  Search,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Info,
  ChevronRight,
  RefreshCw,
  Zap,
  Server,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  HelpCircle,
  FolderGit2,
  ExternalLink,
  ShieldCheck,
  Building2,
  Boxes,
  Maximize2,
  RotateCcw,
} from 'lucide-react';

export const EnvironmentUsageAnalysisPage: React.FC = () => {
  const {
    environments,
    environmentProfiles,
    softwareList,
    bookings,
    releases,
    applications,
    projects,
    businessUnits,
    showToast,
    isLoading: isContextLoading,
  } = useTEM();

  // Active Main Tab: 'GRID' | 'TRENDS' | 'DEMAND' | 'RECOMMENDATIONS'
  const [activeTab, setActiveTab] = useState<'GRID' | 'TRENDS' | 'DEMAND' | 'RECOMMENDATIONS'>('GRID');

  // Filters State
  const [filters, setFilters] = useState<UsageFilterOptions>({
    period: '90d',
    customStartDate: '',
    customEndDate: '',
    searchQuery: '',
    businessUnit: 'ALL',
    project: 'ALL',
    application: 'ALL',
    tier: 'ALL',
    testPhase: 'ALL',
    category: 'ALL',
    sortBy: 'utilization',
    sortOrder: 'desc',
  });

  // Thresholds State
  const [thresholds, setThresholds] = useState<UsageClassificationThresholds>(() =>
    environmentUsageService.getStoredThresholds()
  );
  const [isThresholdModalOpen, setIsThresholdModalOpen] = useState(false);
  const [thresholdForm, setThresholdForm] = useState<UsageClassificationThresholds>(thresholds);

  // Drilldown Modal State
  const [selectedEnvForDrilldown, setSelectedEnvForDrilldown] = useState<EnvironmentUsageItem | null>(null);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Analytical Data State
  const [isCalculating, setIsCalculating] = useState(false);
  const [analysisData, setAnalysisData] = useState(() =>
    environmentUsageService.calculateClientSideAnalysis(
      filters,
      {
        bookings,
        environments,
        environmentProfiles,
        softwareList,
        releases,
        applications,
        projects,
        businessUnits,
      },
      thresholds
    )
  );

  // Re-run analytics when dependencies or filters change
  const refreshAnalysis = async () => {
    setIsCalculating(true);
    try {
      const data = await environmentUsageService.getUsageAnalysis(filters, {
        bookings,
        environments,
        environmentProfiles,
        softwareList,
        releases,
        applications,
        projects,
        businessUnits,
      });
      setAnalysisData(data);
    } catch (e) {
      console.error('Failed to compute usage analysis:', e);
    } finally {
      setIsCalculating(false);
    }
  };

  useEffect(() => {
    refreshAnalysis();
  }, [
    filters.period,
    filters.customStartDate,
    filters.customEndDate,
    filters.businessUnit,
    filters.project,
    filters.application,
    filters.tier,
    filters.testPhase,
    filters.category,
    filters.searchQuery,
    filters.sortBy,
    filters.sortOrder,
    bookings,
    environments,
    environmentProfiles,
    releases,
    thresholds,
  ]);

  // Handle Threshold Save
  const handleSaveThresholds = () => {
    environmentUsageService.saveStoredThresholds(thresholdForm);
    setThresholds(thresholdForm);
    setIsThresholdModalOpen(false);
    showToast('Classification thresholds updated successfully!', 'success');
  };

  const handleResetThresholds = () => {
    const defaultVals = environmentUsageService.resetThresholds();
    setThresholdForm(defaultVals);
    setThresholds(defaultVals);
    setIsThresholdModalOpen(false);
    showToast('Classification thresholds reset to system defaults', 'info');
  };

  // Reset Filters
  const handleResetFilters = () => {
    setFilters({
      period: '90d',
      customStartDate: '',
      customEndDate: '',
      searchQuery: '',
      businessUnit: 'ALL',
      project: 'ALL',
      application: 'ALL',
      tier: 'ALL',
      testPhase: 'ALL',
      category: 'ALL',
      sortBy: 'utilization',
      sortOrder: 'desc',
    });
    setCurrentPage(1);
    showToast('Filters reset to default', 'info');
  };

  // Helper Badge Renderers
  const renderCategoryBadge = (category: UsageCategory) => {
    switch (category) {
      case 'Frequently Used':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-700/80 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Frequently Used
          </span>
        );
      case 'Moderately Used':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-blue-950/80 text-blue-400 border border-blue-700/80 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
            Moderately Used
          </span>
        );
      case 'Rarely Used':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-950/80 text-amber-400 border border-amber-700/80 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            Rarely Used
          </span>
        );
      case 'Never Used':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-rose-950/80 text-rose-400 border border-rose-700/80 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
            Never Used
          </span>
        );
    }
  };

  const renderTrendIndicator = (trend: UsageTrendType, pctChange: number) => {
    switch (trend) {
      case 'Increasing':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-mono font-bold text-emerald-400">
            <ArrowUpRight className="w-4 h-4" />
            Increasing ({pctChange > 0 ? `+${pctChange}%` : `${pctChange}%`})
          </span>
        );
      case 'Decreasing':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-mono font-bold text-rose-400">
            <ArrowDownRight className="w-4 h-4" />
            Decreasing ({pctChange}%)
          </span>
        );
      case 'Stable':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-mono font-bold text-blue-400">
            <Minus className="w-4 h-4" />
            Stable
          </span>
        );
      case 'No usage':
      default:
        return (
          <span className="inline-flex items-center gap-1 text-xs font-mono font-medium text-slate-500">
            <Minus className="w-4 h-4" />
            No usage
          </span>
        );
    }
  };

  // Pagination slice
  const paginatedEnvironments = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return analysisData.environments.slice(startIndex, startIndex + pageSize);
  }, [analysisData.environments, currentPage, pageSize]);

  // Drilldown Bookings
  const drilldownBookings = useMemo(() => {
    if (!selectedEnvForDrilldown) return [];
    const envId = selectedEnvForDrilldown.environmentId;
    const envNameLower = selectedEnvForDrilldown.environmentName.toLowerCase().trim();

    return (bookings || []).filter((b) => {
      const bEnvId = b.environmentId;
      const bEnvName = (b.environmentName || '').toLowerCase().trim();
      return (bEnvId && bEnvId === envId) || (bEnvName && bEnvName === envNameLower);
    });
  }, [selectedEnvForDrilldown, bookings]);

  // Unique lists for filters
  const uniqueBUs = useMemo(() => {
    const s = new Set<string>();
    (businessUnits || []).forEach((b) => b.name && s.add(b.name));
    (analysisData.environments || []).forEach((e) => e.businessUnit && s.add(e.businessUnit));
    return Array.from(s);
  }, [businessUnits, analysisData.environments]);

  const uniqueApps = useMemo(() => {
    const s = new Set<string>();
    (applications || []).forEach((a) => a.name && s.add(a.name));
    (analysisData.environments || []).forEach((e) => {
      if (e.primaryApplication) s.add(e.primaryApplication);
      e.associatedApplications.forEach((a) => s.add(a));
    });
    return Array.from(s);
  }, [applications, analysisData.environments]);

  const uniqueTiers = useMemo(() => {
    const s = new Set<string>();
    (analysisData.environments || []).forEach((e) => e.tier && s.add(e.tier));
    return Array.from(s);
  }, [analysisData.environments]);

  return (
    <div className="space-y-8 w-full min-w-0 font-sans pb-12">
      {/* 1. Header Banner & Period Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-slate-900/90 via-[#0f1724] to-slate-900/90 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xl relative overflow-hidden">
        <div className="space-y-1.5 z-10">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-orange-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" /> INTELLIGENT CAPACITY & USAGE ANALYTICS
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold">
              LIVE DATA ENGINE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <Activity className="w-8 h-8 text-orange-500" /> Intelligent Environment Usage Analysis
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-3xl">
            Analyze historical booking patterns, classify environments by actual utilization, detect utilization trends, and optimize capacity allocation across releases and test phases.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2.5 z-10">
          {/* Period Selector Tabs */}
          <div className="bg-slate-950/80 p-1 rounded-lg border border-slate-800 flex items-center gap-1 font-mono text-xs">
            {(
              [
                { key: '30d', label: 'Last 30 Days' },
                { key: '90d', label: 'Last 90 Days' },
                { key: '180d', label: 'Last 6 Months' },
                { key: '365d', label: 'Last 1 Year' },
                { key: 'custom', label: 'Custom' },
              ] as { key: UsagePeriod; label: string }[]
            ).map((p) => (
              <button
                key={p.key}
                onClick={() => {
                  setFilters({ ...filters, period: p.key });
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-md font-bold transition-all ${
                  filters.period === p.key
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Threshold Settings Modal Trigger */}
          <button
            onClick={() => {
              setThresholdForm(thresholds);
              setIsThresholdModalOpen(true);
            }}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-mono text-xs font-bold transition-all flex items-center gap-1.5"
            title="Configure Usage Classification Thresholds"
          >
            <Sliders className="w-3.5 h-3.5 text-orange-400" />
            <span>THRESHOLDS</span>
          </button>

          {/* Re-calculate button */}
          <button
            onClick={() => {
              refreshAnalysis();
              showToast('Usage analytics recalculated across all historical records', 'success');
            }}
            disabled={isCalculating}
            className="px-3.5 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-mono text-xs font-bold transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(249,115,22,0.3)] disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isCalculating ? 'animate-spin' : ''}`} />
            <span>{isCalculating ? 'ANALYZING...' : 'RE-RUN ANALYSIS'}</span>
          </button>
        </div>
      </div>

      {/* Custom Date Range Row if 'custom' is selected */}
      {filters.period === 'custom' && (
        <div className="bg-[#0f1724] border border-orange-500/40 p-4 rounded-xl flex flex-wrap items-center gap-4 animate-in fade-in duration-200">
          <span className="text-xs font-mono font-bold text-orange-400 uppercase flex items-center gap-1.5">
            <Calendar className="w-4 h-4" /> SELECT CUSTOM DATE RANGE:
          </span>
          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-slate-400">FROM:</span>
            <input
              type="date"
              value={filters.customStartDate || ''}
              onChange={(e) => setFilters({ ...filters, customStartDate: e.target.value })}
              className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-white focus:outline-none focus:border-orange-500"
            />
          </div>
          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-slate-400">TO:</span>
            <input
              type="date"
              value={filters.customEndDate || ''}
              onChange={(e) => setFilters({ ...filters, customEndDate: e.target.value })}
              className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-white focus:outline-none focus:border-orange-500"
            />
          </div>
          <button
            onClick={refreshAnalysis}
            className="px-3 py-1 bg-orange-600 hover:bg-orange-500 text-white rounded text-xs font-mono font-bold"
          >
            Apply Range
          </button>
        </div>
      )}

      {/* 2. Top Summary KPI Cards (4 Categories + Fleet Utilization Metrics) */}
      {isCalculating || isContextLoading ? (
        <CardSkeleton count={4} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" />
      ) : (
        <div className="space-y-4">
          {/* 4 Classification Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Card 1: Frequently Used */}
            <div
              onClick={() => {
                setFilters({ ...filters, category: filters.category === 'Frequently Used' ? 'ALL' : 'Frequently Used' });
                setCurrentPage(1);
              }}
              className={`p-5 rounded-xl border transition-all cursor-pointer shadow-lg ${
                filters.category === 'Frequently Used'
                  ? 'bg-emerald-950/40 border-emerald-500 ring-2 ring-emerald-500/30'
                  : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-emerald-700/60'
              }`}
            >
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-emerald-400" /> FREQUENTLY USED
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  {analysisData.summaryKpis.totalEnvironments > 0
                    ? `${Math.round((analysisData.summaryKpis.frequentlyUsedCount / analysisData.summaryKpis.totalEnvironments) * 100)}%`
                    : '0%'}
                </span>
              </div>
              <div className="text-3xl font-extrabold text-white font-mono flex items-baseline gap-2">
                {analysisData.summaryKpis.frequentlyUsedCount}
                <span className="text-xs font-normal text-slate-400">environments</span>
              </div>
              <p className="text-[11px] font-mono text-emerald-400/90 mt-2">
                Utilization &ge; {thresholds.frequentlyUsedUtilization}% or &ge; {thresholds.frequentlyUsedBookings} bookings
              </p>
            </div>

            {/* Card 2: Moderately Used */}
            <div
              onClick={() => {
                setFilters({ ...filters, category: filters.category === 'Moderately Used' ? 'ALL' : 'Moderately Used' });
                setCurrentPage(1);
              }}
              className={`p-5 rounded-xl border transition-all cursor-pointer shadow-lg ${
                filters.category === 'Moderately Used'
                  ? 'bg-blue-950/40 border-blue-500 ring-2 ring-blue-500/30'
                  : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-blue-700/60'
              }`}
            >
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-blue-400" /> MODERATELY USED
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-950 text-blue-400 border border-blue-800">
                  {analysisData.summaryKpis.totalEnvironments > 0
                    ? `${Math.round((analysisData.summaryKpis.moderatelyUsedCount / analysisData.summaryKpis.totalEnvironments) * 100)}%`
                    : '0%'}
                </span>
              </div>
              <div className="text-3xl font-extrabold text-white font-mono flex items-baseline gap-2">
                {analysisData.summaryKpis.moderatelyUsedCount}
                <span className="text-xs font-normal text-slate-400">environments</span>
              </div>
              <p className="text-[11px] font-mono text-blue-400/90 mt-2">
                Utilization {thresholds.moderatelyUsedUtilization}-{thresholds.frequentlyUsedUtilization}% or {thresholds.moderatelyUsedBookings}-{thresholds.frequentlyUsedBookings} bookings
              </p>
            </div>

            {/* Card 3: Rarely Used */}
            <div
              onClick={() => {
                setFilters({ ...filters, category: filters.category === 'Rarely Used' ? 'ALL' : 'Rarely Used' });
                setCurrentPage(1);
              }}
              className={`p-5 rounded-xl border transition-all cursor-pointer shadow-lg ${
                filters.category === 'Rarely Used'
                  ? 'bg-amber-950/40 border-amber-500 ring-2 ring-amber-500/30'
                  : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-amber-700/60'
              }`}
            >
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" /> RARELY USED
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950 text-amber-400 border border-amber-800">
                  {analysisData.summaryKpis.totalEnvironments > 0
                    ? `${Math.round((analysisData.summaryKpis.rarelyUsedCount / analysisData.summaryKpis.totalEnvironments) * 100)}%`
                    : '0%'}
                </span>
              </div>
              <div className="text-3xl font-extrabold text-white font-mono flex items-baseline gap-2">
                {analysisData.summaryKpis.rarelyUsedCount}
                <span className="text-xs font-normal text-slate-400">environments</span>
              </div>
              <p className="text-[11px] font-mono text-amber-400/90 mt-2">
                Low utilization (&lt;{thresholds.moderatelyUsedUtilization}%) · Ready for Reassignment
              </p>
            </div>

            {/* Card 4: Never Used */}
            <div
              onClick={() => {
                setFilters({ ...filters, category: filters.category === 'Never Used' ? 'ALL' : 'Never Used' });
                setCurrentPage(1);
              }}
              className={`p-5 rounded-xl border transition-all cursor-pointer shadow-lg ${
                filters.category === 'Never Used'
                  ? 'bg-rose-950/40 border-rose-500 ring-2 ring-rose-500/30'
                  : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-rose-700/60'
              }`}
            >
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                  <Minus className="w-4 h-4 text-rose-400" /> NEVER USED
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950 text-rose-400 border border-rose-800">
                  {analysisData.summaryKpis.totalEnvironments > 0
                    ? `${Math.round((analysisData.summaryKpis.neverUsedCount / analysisData.summaryKpis.totalEnvironments) * 100)}%`
                    : '0%'}
                </span>
              </div>
              <div className="text-3xl font-extrabold text-white font-mono flex items-baseline gap-2">
                {analysisData.summaryKpis.neverUsedCount}
                <span className="text-xs font-normal text-slate-400">environments</span>
              </div>
              <p className="text-[11px] font-mono text-rose-400/90 mt-2">
                0 bookings during selected period ({analysisData.totalDays} days)
              </p>
            </div>
          </div>

          {/* Secondary Fleet Summary Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 bg-slate-900/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-mono">
            <div>
              <span className="text-slate-500 text-[10px] uppercase block">TOTAL FLEET</span>
              <strong className="text-white text-base">{analysisData.summaryKpis.totalEnvironments} Envs</strong>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase block">OVERALL UTILIZATION</span>
              <strong className="text-orange-400 text-base">{analysisData.summaryKpis.overallUtilizationPct}%</strong>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase block">TOTAL BOOKINGS</span>
              <strong className="text-blue-400 text-base">{analysisData.summaryKpis.totalBookingsCount} Bookings</strong>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase block">TOTAL USAGE TIME</span>
              <strong className="text-emerald-400 text-base">{analysisData.summaryKpis.totalUsageHours} hrs</strong>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase block">MOST USED NODE</span>
              <strong className="text-white truncate block" title={analysisData.summaryKpis.mostUsedEnvironmentName || 'None'}>
                {analysisData.summaryKpis.mostUsedEnvironmentName || 'N/A'} ({analysisData.summaryKpis.mostUsedUtilizationPct}%)
              </strong>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase block">USAGE TREND</span>
              <div className="mt-0.5">
                {renderTrendIndicator(analysisData.summaryKpis.fleetUsageTrend, 0)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. Sub-Tab Navigation Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-2">
        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setActiveTab('GRID')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-bold transition-all ${
              activeTab === 'GRID'
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Server className="w-4 h-4" /> ENVIRONMENT UTILIZATION GRID
          </button>

          <button
            onClick={() => setActiveTab('TRENDS')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-bold transition-all ${
              activeTab === 'TRENDS'
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <TrendingUp className="w-4 h-4" /> USAGE TRENDS & TIME SERIES
          </button>

          <button
            onClick={() => setActiveTab('DEMAND')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-bold transition-all ${
              activeTab === 'DEMAND'
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <BarChart3 className="w-4 h-4" /> APP & TEST PHASE DEMAND
          </button>

          <button
            onClick={() => setActiveTab('RECOMMENDATIONS')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-bold transition-all ${
              activeTab === 'RECOMMENDATIONS'
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Sparkles className="w-4 h-4" /> INTELLIGENT RECOMMENDATIONS ({analysisData.recommendations.length})
          </button>
        </div>

        {/* Quick Search in Bar */}
        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search environment, app, tier..."
            value={filters.searchQuery}
            onChange={(e) => {
              setFilters({ ...filters, searchQuery: e.target.value });
              setCurrentPage(1);
            }}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 font-mono"
          />
        </div>
      </div>

      {/* 4. Multi-Dimension Filters Panel (Always accessible) */}
      <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-3 font-mono text-xs">
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-slate-400 uppercase font-bold flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-orange-400" /> MULTI-DIMENSIONAL DRILLDOWN FILTERS
          </span>
          <button
            onClick={handleResetFilters}
            className="text-[11px] text-slate-400 hover:text-orange-400 flex items-center gap-1 transition-colors"
          >
            <RotateCcw className="w-3 h-3" /> Reset Filters
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Filter 1: Business Unit */}
          <div>
            <label className="text-[9px] text-slate-500 uppercase block mb-1">BUSINESS UNIT</label>
            <select
              value={filters.businessUnit}
              onChange={(e) => {
                setFilters({ ...filters, businessUnit: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500 text-xs truncate"
            >
              <option value="ALL">All Business Units</option>
              {uniqueBUs.map((bu) => (
                <option key={bu} value={bu}>
                  {bu}
                </option>
              ))}
            </select>
          </div>

          {/* Filter 2: Application */}
          <div>
            <label className="text-[9px] text-slate-500 uppercase block mb-1">APPLICATION</label>
            <select
              value={filters.application}
              onChange={(e) => {
                setFilters({ ...filters, application: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500 text-xs truncate"
            >
              <option value="ALL">All Applications</option>
              {uniqueApps.map((app) => (
                <option key={app} value={app}>
                  {app}
                </option>
              ))}
            </select>
          </div>

          {/* Filter 3: Environment Tier */}
          <div>
            <label className="text-[9px] text-slate-500 uppercase block mb-1">TIER / TYPE</label>
            <select
              value={filters.tier}
              onChange={(e) => {
                setFilters({ ...filters, tier: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500 text-xs truncate"
            >
              <option value="ALL">All Tiers</option>
              {uniqueTiers.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* Filter 4: Test Phase */}
          <div>
            <label className="text-[9px] text-slate-500 uppercase block mb-1">TEST PHASE</label>
            <select
              value={filters.testPhase}
              onChange={(e) => {
                setFilters({ ...filters, testPhase: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500 text-xs truncate"
            >
              <option value="ALL">All Test Phases</option>
              <option value="SIT">SIT</option>
              <option value="QA">QA</option>
              <option value="UAT">UAT</option>
              <option value="UNIT">UNIT</option>
              <option value="PERF">PERF</option>
              <option value="PROD">PROD</option>
            </select>
          </div>

          {/* Filter 5: Usage Category */}
          <div>
            <label className="text-[9px] text-slate-500 uppercase block mb-1">USAGE CATEGORY</label>
            <select
              value={filters.category}
              onChange={(e) => {
                setFilters({ ...filters, category: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500 text-xs truncate"
            >
              <option value="ALL">All Categories</option>
              <option value="Frequently Used">Frequently Used</option>
              <option value="Moderately Used">Moderately Used</option>
              <option value="Rarely Used">Rarely Used</option>
              <option value="Never Used">Never Used</option>
            </select>
          </div>

          {/* Filter 6: Sort By */}
          <div>
            <label className="text-[9px] text-slate-500 uppercase block mb-1">SORT BY</label>
            <select
              value={`${filters.sortBy}-${filters.sortOrder}`}
              onChange={(e) => {
                const [by, ord] = e.target.value.split('-') as [any, any];
                setFilters({ ...filters, sortBy: by, sortOrder: ord });
              }}
              className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500 text-xs truncate"
            >
              <option value="utilization-desc">Utilization % (High → Low)</option>
              <option value="utilization-asc">Utilization % (Low → High)</option>
              <option value="bookings-desc">Bookings (High → Low)</option>
              <option value="hours-desc">Total Usage (High → Low)</option>
              <option value="name-asc">Environment Name (A → Z)</option>
              <option value="lastUsed-desc">Last Used (Recent First)</option>
            </select>
          </div>
        </div>
      </div>

      {/* 5. TAB 1: ENVIRONMENT UTILIZATION GRID */}
      {activeTab === 'GRID' && (
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xl space-y-4">
          <div className="p-5 pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
                <Server className="w-4 h-4 text-orange-400" /> Historical Environment Utilization Matrix ({analysisData.environments.length})
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluated across active bookings in the selected window ({analysisData.startDate} to {analysisData.endDate}).
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Showing page {currentPage} of {Math.max(1, Math.ceil(analysisData.environments.length / pageSize))}
            </span>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400">
                  <th className="p-3.5 uppercase text-[10px]">Environment</th>
                  <th className="p-3.5 uppercase text-[10px]">Application</th>
                  <th className="p-3.5 uppercase text-[10px]">Tier / Type</th>
                  <th className="p-3.5 uppercase text-[10px]">Usage Category</th>
                  <th className="p-3.5 text-center uppercase text-[10px]">Bookings</th>
                  <th className="p-3.5 text-center uppercase text-[10px]">Total Hours</th>
                  <th className="p-3.5 uppercase text-[10px]">Last Used</th>
                  <th className="p-3.5 uppercase text-[10px]">Utilization %</th>
                  <th className="p-3.5 uppercase text-[10px]">Trend</th>
                  <th className="p-3.5 text-center uppercase text-[10px]">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {paginatedEnvironments.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="p-8 text-center text-slate-500">
                      No environments found matching current filters.
                    </td>
                  </tr>
                ) : (
                  paginatedEnvironments.map((env) => (
                    <tr
                      key={env.environmentId}
                      className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                      onClick={() => setSelectedEnvForDrilldown(env)}
                    >
                      {/* Environment Name */}
                      <td className="p-3.5">
                        <div className="font-bold text-white group-hover:text-orange-400 transition-colors flex items-center gap-1.5">
                          {env.environmentName}
                          {!env.isActive && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] bg-red-950 text-red-400 border border-red-800">
                              INACTIVE
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500">{env.businessUnit}</span>
                      </td>

                      {/* Primary Application */}
                      <td className="p-3.5">
                        <span className="text-slate-200 font-medium block truncate max-w-[200px]" title={env.primaryApplication}>
                          {env.primaryApplication}
                        </span>
                        {env.associatedApplications.length > 1 && (
                          <span className="text-[10px] text-slate-400 block truncate max-w-[200px]" title={env.associatedApplications.join(', ')}>
                            +{env.associatedApplications.length - 1} other app{env.associatedApplications.length > 2 ? 's' : ''} ({env.associatedApplications.slice(1).join(', ')})
                          </span>
                        )}
                      </td>

                      {/* Tier / Type */}
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 text-[10px]">
                          {env.tier}
                        </span>
                      </td>

                      {/* Usage Category */}
                      <td className="p-3.5">{renderCategoryBadge(env.usageCategory)}</td>

                      {/* Booking Count */}
                      <td className="p-3.5 text-center">
                        <span className="font-bold text-white">{env.bookingCount}</span>
                        {env.releaseCount > 0 && (
                          <span className="text-[10px] text-slate-500 block">
                            {env.releaseCount} rels
                          </span>
                        )}
                      </td>

                      {/* Total Duration */}
                      <td className="p-3.5 text-center">
                        <span className="font-bold text-slate-200">{env.totalUsageHours} hrs</span>
                        <span className="text-[10px] text-slate-500 block">
                          ({env.totalUsageDays} days)
                        </span>
                      </td>

                      {/* Last Used / Active Horizon */}
                      <td className="p-3.5">
                        {env.lastUsedFormatted?.startsWith('Active') ? (
                          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-950/90 text-emerald-300 border border-emerald-700/80">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            {env.lastUsedFormatted}
                          </span>
                        ) : env.lastUsedFormatted?.startsWith('Booked') ? (
                          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-bold bg-blue-950/90 text-blue-300 border border-blue-700/80">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                            {env.lastUsedFormatted}
                          </span>
                        ) : env.lastUsedFormatted === 'Never used' ? (
                          <span className="text-slate-500 italic">Never used</span>
                        ) : (
                          <span className="text-slate-300 font-mono">{env.lastUsedFormatted}</span>
                        )}
                      </td>

                      {/* Utilization % */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-800 h-2 rounded-full overflow-hidden shrink-0">
                            <div
                              style={{ width: `${Math.min(100, env.utilizationPct)}%` }}
                              className={`h-full ${
                                env.utilizationPct >= 60
                                  ? 'bg-emerald-500'
                                  : env.utilizationPct >= 20
                                  ? 'bg-blue-500'
                                  : env.utilizationPct > 0
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                            />
                          </div>
                          <span
                            className={`font-bold ${
                              env.utilizationPct >= 60
                                ? 'text-emerald-400'
                                : env.utilizationPct >= 20
                                ? 'text-blue-400'
                                : env.utilizationPct > 0
                                ? 'text-amber-400'
                                : 'text-slate-500'
                            }`}
                          >
                            {env.utilizationPct}%
                          </span>
                        </div>
                      </td>

                      {/* Trend */}
                      <td className="p-3.5">{renderTrendIndicator(env.trend, env.trendPctChange)}</td>

                      {/* Actions */}
                      <td className="p-3.5 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedEnvForDrilldown(env);
                          }}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-orange-600 hover:text-white text-slate-300 text-[11px] font-bold transition-all border border-slate-700 flex items-center gap-1 mx-auto"
                        >
                          <Maximize2 className="w-3 h-3" /> DRILLDOWN
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {analysisData.environments.length > 0 && (
            <div className="p-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400">
                Total {analysisData.environments.length} environments analyzed
              </span>
              <Pagination
                currentPage={currentPage}
                totalItems={analysisData.environments.length}
                pageSize={pageSize}
                onPageChange={(page) => setCurrentPage(page)}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1);
                }}
              />

            </div>
          )}
        </div>
      )}

      {/* 6. TAB 2: USAGE TRENDS & TIME SERIES */}
      {activeTab === 'TRENDS' && (
        <div className="space-y-6">
          {/* Time Series Monthly Utilization Chart */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-xl space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-orange-400" /> Historical Monthly Fleet Utilization Trend
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Monthly progression of overall fleet utilization % and total hours booked across all active test environments.
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs font-mono">
                <span className="flex items-center gap-1.5 text-orange-400">
                  <span className="w-3 h-3 rounded bg-orange-500 inline-block" /> Utilization %
                </span>
                <span className="flex items-center gap-1.5 text-blue-400">
                  <span className="w-3 h-3 rounded bg-blue-500/60 inline-block" /> Hours Booked
                </span>
              </div>
            </div>

            {/* Custom SVG Bar Chart */}
            <div className="w-full overflow-x-auto pt-10 pb-4">
              <div className="min-w-[700px] h-72 flex items-end justify-between gap-3 px-6 pb-6 border-b border-l border-slate-700 relative">
                {/* Horizontal reference lines */}
                <div className="absolute left-0 right-0 top-6 border-b border-slate-800 text-[10px] font-mono text-slate-600 pl-1">
                  100% Target
                </div>
                <div className="absolute left-0 right-0 top-[50%] border-b border-slate-800 text-[10px] font-mono text-slate-600 pl-1">
                  50% Mid
                </div>

                {analysisData.timeSeriesTrend.map((pt, idx) => {
                  const maxHours = Math.max(1, Math.max(...analysisData.timeSeriesTrend.map((t) => t.hoursBooked)));
                  const utilHeightPct = Math.min(100, Math.max(8, pt.utilizationPct));
                  const hoursHeightPct = Math.round((pt.hoursBooked / maxHours) * 80);

                  return (
                    <div key={idx} className="flex-1 h-full flex flex-col justify-end items-center gap-2 group relative">
                      {/* Tooltip on hover */}
                      <div className="absolute top-0 hidden group-hover:block bg-slate-950 border border-slate-700 text-white p-2.5 rounded-lg text-[10px] font-mono z-30 whitespace-nowrap shadow-2xl pointer-events-none -translate-x-1/2 left-1/2">
                        <p className="font-bold text-orange-400">{pt.monthName} {pt.year}</p>
                        <p>Utilization: <span className="font-bold text-white">{pt.utilizationPct}%</span></p>
                        <p>Hours Booked: <span className="text-blue-300 font-bold">{pt.hoursBooked} hrs</span></p>
                        <p>Bookings: <span className="text-slate-300">{pt.bookingCount}</span></p>
                      </div>

                      <div className="w-full flex items-end justify-center gap-1.5 h-48">
                        {/* Utilization Bar */}
                        <div
                          style={{ height: `${utilHeightPct}%` }}
                          className="w-5 bg-gradient-to-t from-orange-600 to-amber-400 rounded-t shadow-[0_0_8px_rgba(249,115,22,0.3)] transition-all group-hover:brightness-125"
                        />
                        {/* Hours Booked Bar */}
                        <div
                          style={{ height: `${hoursHeightPct}%` }}
                          className="w-3 bg-blue-500/70 rounded-t transition-all group-hover:bg-blue-400"
                        />
                      </div>

                      <span className="text-[11px] font-mono font-bold text-slate-300 truncate text-center">
                        {pt.periodLabel}
                      </span>
                      <span className="text-[10px] font-mono text-orange-400 font-bold">
                        {pt.utilizationPct}%
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Top 5 Most Used vs Top 5 Least Used Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top 5 Most Utilized */}
            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-xl space-y-4 shadow-xl">
              <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2 border-b border-slate-800 pb-3">
                <Flame className="w-4 h-4 text-emerald-400" /> Top Most Utilized Environments
              </h3>
              <div className="space-y-3">
                {[...analysisData.environments]
                  .sort((a, b) => b.utilizationPct - a.utilizationPct)
                  .slice(0, 5)
                  .map((env, idx) => (
                    <div
                      key={env.environmentId}
                      onClick={() => setSelectedEnvForDrilldown(env)}
                      className="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 hover:border-emerald-700/60 transition-all flex items-center justify-between cursor-pointer group"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 text-xs font-mono font-bold flex items-center justify-center">
                          #{idx + 1}
                        </span>
                        <div>
                          <div className="font-bold text-white group-hover:text-emerald-400 transition-colors font-mono">
                            {env.environmentName}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {env.primaryApplication} · {env.bookingCount} bookings ({env.totalUsageHours} hrs)
                          </div>
                        </div>
                      </div>
                      <div className="text-right font-mono">
                        <span className="text-base font-bold text-emerald-400">{env.utilizationPct}%</span>
                        <span className="text-[10px] text-slate-500 block">{env.trend}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            {/* Top 5 Least / Underutilized */}
            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-xl space-y-4 shadow-xl">
              <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2 border-b border-slate-800 pb-3">
                <AlertTriangle className="w-4 h-4 text-amber-400" /> Least Utilized & Idle Candidates
              </h3>
              <div className="space-y-3">
                {[...analysisData.environments]
                  .sort((a, b) => a.utilizationPct - b.utilizationPct)
                  .slice(0, 5)
                  .map((env, idx) => (
                    <div
                      key={env.environmentId}
                      onClick={() => setSelectedEnvForDrilldown(env)}
                      className="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 hover:border-amber-700/60 transition-all flex items-center justify-between cursor-pointer group"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-amber-950 text-amber-400 border border-amber-800 text-xs font-mono font-bold flex items-center justify-center">
                          #{idx + 1}
                        </span>
                        <div>
                          <div className="font-bold text-white group-hover:text-amber-400 transition-colors font-mono">
                            {env.environmentName}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {env.primaryApplication} · Last used: {env.lastUsedFormatted}
                          </div>
                        </div>
                      </div>
                      <div className="text-right font-mono">
                        <span className={`text-base font-bold ${env.utilizationPct === 0 ? 'text-rose-400' : 'text-amber-400'}`}>
                          {env.utilizationPct}%
                        </span>
                        <span className="text-[10px] text-slate-500 block">{renderCategoryBadge(env.usageCategory)}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. TAB 3: APP & TEST PHASE DEMAND */}
      {activeTab === 'DEMAND' && (
        <div className="space-y-6">
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-xl space-y-4 shadow-xl">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-orange-400" /> Application & Test Phase Booking Demand vs Capacity
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluation of booking frequency and demand volume compared against available environment fleet capacity.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {analysisData.applicationDemandInsights.map((insight, idx) => (
                <div
                  key={idx}
                  className={`p-5 rounded-xl border space-y-3 font-mono shadow-md ${
                    insight.demandStatus === 'HIGH_DEMAND'
                      ? 'bg-rose-950/20 border-rose-800/80'
                      : insight.demandStatus === 'BALANCED'
                      ? 'bg-blue-950/20 border-blue-800/80'
                      : 'bg-slate-900/60 border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">{insight.applicationName}</span>
                      <span className="text-[10px] text-orange-400 font-bold uppercase">{insight.phaseName} PHASE</span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                        insight.demandStatus === 'HIGH_DEMAND'
                          ? 'bg-rose-950 text-rose-400 border-rose-800'
                          : insight.demandStatus === 'BALANCED'
                          ? 'bg-blue-950 text-blue-400 border-blue-800'
                          : 'bg-emerald-950 text-emerald-400 border-emerald-800'
                      }`}
                    >
                      {insight.demandStatus.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs bg-black/40 p-2.5 rounded border border-slate-800">
                    <div>
                      <span className="text-[9px] text-slate-500 uppercase block">AVAILABLE ENVS</span>
                      <strong className="text-white">{insight.availableEnvironmentsCount}</strong>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 uppercase block">AVG MONTHLY DEMAND</span>
                      <strong className="text-orange-400">{insight.avgMonthlyDemand} bk/mo</strong>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-300 font-sans leading-relaxed">
                    {insight.insightMessage}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 8. TAB 4: INTELLIGENT AI RECOMMENDATIONS */}
      {activeTab === 'RECOMMENDATIONS' && (
        <div className="space-y-4">
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-xl shadow-xl space-y-4">
            <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-orange-400" /> Actionable Capacity & Fleet Recommendations
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Generated through statistical analysis of actual historical bookings, contention spikes, and idle periods.
                </p>
              </div>
              <span className="px-2.5 py-1 rounded bg-orange-950 text-orange-400 border border-orange-800 text-xs font-mono font-bold">
                {analysisData.recommendations.length} Active Insights
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {analysisData.recommendations.map((rec) => (
                <div
                  key={rec.id}
                  className="bg-slate-900/90 p-5 rounded-xl border border-slate-800 space-y-3 font-mono shadow-md"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div
                        className={`p-2 rounded-lg ${
                          rec.severity === 'CRITICAL'
                            ? 'bg-rose-950 text-rose-400 border border-rose-800'
                            : rec.severity === 'WARNING'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800'
                            : 'bg-blue-950 text-blue-400 border border-blue-800'
                        }`}
                      >
                        <Zap className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white">{rec.title}</h4>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Target: {rec.targetEnvironment || 'Fleet Wide'}
                        </span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-emerald-400 border border-slate-700">
                      {rec.impactScore}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 font-sans leading-relaxed">
                    {rec.message}
                  </p>

                  <div className="text-[11px] font-mono text-orange-300 bg-black/60 p-3 rounded-lg border border-slate-800">
                    <strong className="text-orange-400 uppercase text-[10px] block mb-0.5">Recommended Action:</strong>
                    {rec.actionableRecommendation}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 9. DRILLDOWN INSPECTOR MODAL */}
      {selectedEnvForDrilldown && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-orange-500/60 rounded-xl max-w-4xl w-full font-mono text-xs relative shadow-[0_0_50px_rgba(249,115,22,0.2)] max-h-[90vh] flex flex-col overflow-hidden">
            {/* Header */}
            <div className="shrink-0 p-6 pb-4 border-b border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => setSelectedEnvForDrilldown(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>

              <span className="text-[10px] text-orange-400 uppercase font-bold tracking-widest flex items-center gap-1.5">
                <Boxes className="w-3.5 h-3.5" /> ENVIRONMENT USAGE DRILLDOWN DOSSIER
              </span>
              <div className="flex flex-wrap items-center gap-3 mt-1.5">
                <h2 className="text-2xl font-bold text-white">{selectedEnvForDrilldown.environmentName}</h2>
                {renderCategoryBadge(selectedEnvForDrilldown.usageCategory)}
                <span className="px-2.5 py-0.5 rounded bg-slate-800 text-slate-300 text-xs font-bold border border-slate-700">
                  {selectedEnvForDrilldown.tier}
                </span>
                <span className="px-2.5 py-0.5 rounded bg-orange-950 text-orange-400 text-xs font-bold border border-orange-800">
                  {selectedEnvForDrilldown.utilizationPct}% Utilization
                </span>
              </div>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Top Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-black/40 p-4 rounded-xl border border-slate-800">
                <div>
                  <span className="text-slate-500 text-[10px] uppercase block">TOTAL BOOKINGS</span>
                  <span className="text-white text-base font-bold">{selectedEnvForDrilldown.bookingCount} Bookings</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] uppercase block">USAGE TIME</span>
                  <span className="text-orange-400 text-base font-bold">
                    {selectedEnvForDrilldown.totalUsageHours} hrs ({selectedEnvForDrilldown.totalUsageDays} days)
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] uppercase block">LAST USED DATE</span>
                  <span className="text-slate-200 text-base font-bold">{selectedEnvForDrilldown.lastUsedFormatted}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] uppercase block">USAGE TREND</span>
                  <div className="mt-1">
                    {renderTrendIndicator(selectedEnvForDrilldown.trend, selectedEnvForDrilldown.trendPctChange)}
                  </div>
                </div>
              </div>

              {/* Context Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-900/70 p-4 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-1.5 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-blue-400" /> Primary Application & BU Association
                  </h4>
                  <div className="space-y-1.5 text-xs">
                    <p><strong className="text-slate-400">Primary App:</strong> <span className="text-white font-bold">{selectedEnvForDrilldown.primaryApplication}</span></p>
                    <p><strong className="text-slate-400">Owner Team / BU:</strong> <span className="text-slate-300">{selectedEnvForDrilldown.businessUnit}</span></p>
                    <p>
                      <strong className="text-slate-400">All Associated Apps:</strong>{' '}
                      <span className="text-slate-300">
                        {selectedEnvForDrilldown.associatedApplications.join(', ') || 'None'}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="bg-slate-900/70 p-4 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-1.5 flex items-center gap-1.5">
                    <FolderGit2 className="w-3.5 h-3.5 text-orange-400" /> Releases & Test Phase Distribution
                  </h4>
                  <div className="space-y-1.5 text-xs">
                    <p><strong className="text-slate-400">Total Releases:</strong> <span className="text-white font-bold">{selectedEnvForDrilldown.releaseCount} Releases</span></p>
                    <p><strong className="text-slate-400">Top Test Phase:</strong> <span className="text-orange-400 font-bold">{selectedEnvForDrilldown.topPhase || 'General'}</span></p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {Object.entries(selectedEnvForDrilldown.phaseBreakdown).map(([phase, count]) => (
                        <span key={phase} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] border border-slate-700">
                          {phase}: {count}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Historical Bookings Table */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-white uppercase flex items-center gap-1.5 border-b border-slate-800 pb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-orange-400" /> Associated Historical Bookings ({drilldownBookings.length})
                </h4>
                <div className="max-h-60 overflow-y-auto border border-slate-800 rounded-lg">
                  <table className="w-full text-left font-mono text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 bg-slate-900 text-slate-400">
                        <th className="p-2.5 uppercase text-[10px]">Purpose</th>
                        <th className="p-2.5 uppercase text-[10px]">App / Phase</th>
                        <th className="p-2.5 uppercase text-[10px]">Requested By</th>
                        <th className="p-2.5 uppercase text-[10px]">Timeline</th>
                        <th className="p-2.5 uppercase text-[10px]">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {drilldownBookings.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="p-4 text-center text-slate-500">
                            No booking records found for this environment.
                          </td>
                        </tr>
                      ) : (
                        drilldownBookings.map((b) => (
                          <tr key={b.id} className="hover:bg-slate-800/40 transition-colors">
                            <td className="p-2.5 font-bold text-white">{b.purpose}</td>
                            <td className="p-2.5 text-slate-300">
                              {b.application || 'General'} · <span className="text-orange-400">{b.testPhaseName || (b as any).test_phase || 'SIT'}</span>
                            </td>
                            <td className="p-2.5 text-slate-400">{b.requestedBy}</td>
                            <td className="p-2.5 text-slate-400 text-[11px]">
                              {new Date(b.startDate).toLocaleDateString('en-GB')} → {new Date(b.endDate).toLocaleDateString('en-GB')}
                            </td>
                            <td className="p-2.5">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-emerald-400 border border-slate-700">
                                {b.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-800 flex items-center justify-end z-10">
              <button
                onClick={() => setSelectedEnvForDrilldown(null)}
                className="px-5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                CLOSE DOSSIER
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 10. THRESHOLD CONFIGURATION MODAL */}
      {isThresholdModalOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-orange-500/60 rounded-xl max-w-xl w-full font-mono text-xs relative shadow-[0_0_50px_rgba(249,115,22,0.2)] p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] text-orange-400 uppercase font-bold">SYSTEM CLASSIFICATION ENGINE</span>
                <h3 className="text-base font-bold text-white mt-0.5">
                  Configure Environment Usage Thresholds
                </h3>
              </div>
              <button
                onClick={() => setIsThresholdModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300 font-sans">
              Adjust the analytical utilization percentage and booking count thresholds used by the classification engine to categorize environments.
            </p>

            <div className="space-y-4">
              {/* Frequently Used Threshold */}
              <div className="bg-slate-900/80 p-4 rounded-lg border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-emerald-400 uppercase block">
                  Frequently Used Thresholds
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-slate-400 block mb-1">Min Utilization %:</span>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={thresholdForm.frequentlyUsedUtilization}
                      onChange={(e) =>
                        setThresholdForm({ ...thresholdForm, frequentlyUsedUtilization: parseFloat(e.target.value) || 0 })
                      }
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block mb-1">Min Bookings Count:</span>
                    <input
                      type="number"
                      min="1"
                      value={thresholdForm.frequentlyUsedBookings}
                      onChange={(e) =>
                        setThresholdForm({ ...thresholdForm, frequentlyUsedBookings: parseInt(e.target.value) || 0 })
                      }
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Moderately Used Threshold */}
              <div className="bg-slate-900/80 p-4 rounded-lg border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-blue-400 uppercase block">
                  Moderately Used Thresholds
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-slate-400 block mb-1">Min Utilization %:</span>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={thresholdForm.moderatelyUsedUtilization}
                      onChange={(e) =>
                        setThresholdForm({ ...thresholdForm, moderatelyUsedUtilization: parseFloat(e.target.value) || 0 })
                      }
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block mb-1">Min Bookings Count:</span>
                    <input
                      type="number"
                      min="1"
                      value={thresholdForm.moderatelyUsedBookings}
                      onChange={(e) =>
                        setThresholdForm({ ...thresholdForm, moderatelyUsedBookings: parseInt(e.target.value) || 0 })
                      }
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <button
                type="button"
                onClick={handleResetThresholds}
                className="px-3.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
              >
                Reset to Defaults
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsThresholdModalOpen(false)}
                  className="px-3.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveThresholds}
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold shadow-[0_0_12px_rgba(249,115,22,0.4)]"
                >
                  Save Thresholds
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
