from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy import func, select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.environment import Environment, EnvironmentStatus, EnvironmentTier, ComponentTopology


class EnvironmentDAO:
    """Legacy EnvironmentDAO - deprecated in favor of EnvironmentProfileDAO."""
    pass

environment_dao = EnvironmentDAO()
