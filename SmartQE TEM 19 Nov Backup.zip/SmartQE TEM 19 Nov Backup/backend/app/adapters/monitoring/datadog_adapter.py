import time
import httpx
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from app.core.logging import logger
from app.adapters.monitoring.base import (
    BaseMonitoringAdapter,
    ProviderHealth,
    UnifiedTarget,
    ConnectionTestResult
)
from app.schemas.unified_monitoring import (
    UnifiedMetricSample,
    UnifiedHistoricalTelemetry,
    HistoricalSeries,
    HistoricalDataPoint,
    MetricAvailabilityState
)
from app.adapters.monitoring.factory import AdapterFactory


class DatadogMonitoringAdapter(BaseMonitoringAdapter):
    """
    Enterprise Datadog Monitoring Adapter for SmartQE TEM.
    Interacts with Datadog REST APIs (v1 & v2) for live metrics, hosts, monitors, and APM.
    Demonstrates frictionless integration of multi-cloud SaaS telemetry.
    """

    def __init__(
        self,
        provider_id: str = "datadog-prod",
        provider_name: str = "Datadog Cloud Observability",
        base_url: str = "https://api.datadoghq.com",
        capabilities: Optional[List[str]] = None,
        timeout: float = 8.0,
        tool_parameters: Optional[Dict[str, Any]] = None,
        credentials: Optional[Dict[str, Any]] = None
    ):
        super().__init__(
            provider_id=provider_id,
            provider_name=provider_name,
            provider_type="DATADOG",
            base_url=base_url or "https://api.datadoghq.com",
            capabilities=capabilities or ["INFRASTRUCTURE", "SERVER", "APPLICATION", "ALERTS", "HISTORICAL_METRICS"],
            timeout=timeout,
            tool_parameters=tool_parameters or {}
        )
        self.credentials = credentials or {}
        self.api_key = self.credentials.get("api_key", "")
        self.app_key = self.credentials.get("app_key", "")
        self.site = self.tool_parameters.get("site", "datadoghq.com")

        self._headers = {
            "DD-API-KEY": self.api_key,
            "DD-APPLICATION-KEY": self.app_key,
            "Content-Type": "application/json"
        }

    async def test_connection(self) -> ConnectionTestResult:
        """Validates credentials using Datadog's API key validation endpoint."""
        start = time.perf_counter()
        if not self.api_key:
            return ConnectionTestResult(
                success=False,
                latency_ms=0.0,
                message="Datadog API key is required"
            )
        try:
            url = f"{self.base_url}/api/v1/validate"
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self._headers)
                latency = (time.perf_counter() - start) * 1000.0

                if resp.status_code == 200 and resp.json().get("valid") is True:
                    return ConnectionTestResult(
                        success=True,
                        latency_ms=round(latency, 2),
                        message="Successfully authenticated with Datadog API",
                        discovered_capabilities=self.capabilities,
                        raw_probe_details={"site": self.site, "valid": True}
                    )
                return ConnectionTestResult(
                    success=False,
                    latency_ms=round(latency, 2),
                    message=f"Datadog authentication failed (HTTP {resp.status_code}): {resp.text}"
                )
        except Exception as exc:
            latency = (time.perf_counter() - start) * 1000.0
            return ConnectionTestResult(success=False, latency_ms=round(latency, 2), message=str(exc))

    async def get_health(self) -> ProviderHealth:
        """Checks Datadog API liveness and active host count."""
        test_res = await self.test_connection()
        if not test_res.success:
            return ProviderHealth(
                provider_id=self.provider_id,
                provider_name=self.provider_name,
                provider_type=self.provider_type,
                is_healthy=False,
                status="DOWN",
                latency_ms=test_res.latency_ms,
                data_freshness_seconds=999.0,
                error_message=test_res.message
            )

        active_hosts = 0
        try:
            url = f"{self.base_url}/api/v1/hosts/totals"
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(url, headers=self._headers)
                if res.status_code == 200:
                    active_hosts = res.json().get("total_active", 0)
        except Exception:
            pass

        return ProviderHealth(
            provider_id=self.provider_id,
            provider_name=self.provider_name,
            provider_type=self.provider_type,
            is_healthy=True,
            status="HEALTHY",
            latency_ms=test_res.latency_ms,
            data_freshness_seconds=2.0,
            active_targets_count=active_hosts,
            capabilities_online=self.capabilities
        )

    async def get_targets(self, environment_id: Optional[str] = None) -> List[UnifiedTarget]:
        """Discovers active infrastructure hosts tracked in Datadog."""
        url = f"{self.base_url}/api/v1/hosts"
        targets: List[UnifiedTarget] = []
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self._headers, params={"count": 50})
                if resp.status_code == 200:
                    host_list = resp.json().get("host_list", [])
                    for h in host_list:
                        host_name = h.get("name", "dd-host")
                        is_up = not h.get("is_muted", False) and h.get("up", True)
                        targets.append(UnifiedTarget(
                            id=f"dd-{host_name}",
                            name=host_name,
                            environment_id=environment_id or "env-cloud",
                            environment_name="Cloud Environment / Datadog",
                            target_type="SERVER",
                            endpoint_url=f"datadog://host/{host_name}",
                            is_up=is_up,
                            status="UP" if is_up else "DOWN",
                            labels={"apps": ",".join(h.get("apps", []))},
                            source_tool_id=self.provider_id
                        ))
        except Exception as exc:
            logger.warning(f"Datadog get_targets failed: {exc}")
        return targets

    async def get_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None
    ) -> List[UnifiedMetricSample]:
        """Queries Datadog metric series via /api/v1/query and normalizes to UnifiedMetricSample."""
        now = int(datetime.now(timezone.utc).timestamp())
        start = now - 300
        query = "avg:system.cpu.idle{*} by {host}"

        samples: List[UnifiedMetricSample] = []
        try:
            url = f"{self.base_url}/api/v1/query"
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self._headers, params={"from": start, "to": now, "query": query})
                if resp.status_code == 200:
                    series = resp.json().get("series", [])
                    for s in series:
                        point_list = s.get("pointlist", [])
                        if point_list:
                            last_point = point_list[-1]
                            idle_pct = float(last_point[1]) if last_point[1] is not None else 100.0
                            cpu_utilization = max(0.0, 100.0 - idle_pct)
                            host_tag = s.get("scope", "host:unknown").replace("host:", "")

                            samples.append(UnifiedMetricSample(
                                environment=environment_id,
                                environment_id=environment_id,
                                target=host_tag,
                                target_type="SERVER",
                                metric="server_cpu_utilization",
                                value=round(cpu_utilization, 2),
                                unit="percent",
                                availability_state=MetricAvailabilityState.ACTIVE_VALUE,
                                source=self.provider_id,
                                provider=self.__class__.__name__,
                                source_metric_name="system.cpu.idle"
                            ))
        except Exception as exc:
            logger.warning(f"Datadog metric query failed: {exc}")
        return samples

    async def get_historical_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None,
        timeframe: str = "1h"
    ) -> UnifiedHistoricalTelemetry:
        """Retrieves historical Datadog points formatted for Apache ECharts."""
        timeframe_secs = 3600 if timeframe == "1h" else 86400
        now = int(datetime.now(timezone.utc).timestamp())
        start = now - timeframe_secs

        query = "avg:system.cpu.user{*} by {host}"
        series_dict: Dict[str, HistoricalSeries] = {}

        try:
            url = f"{self.base_url}/api/v1/query"
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self._headers, params={"from": start, "to": now, "query": query})
                if resp.status_code == 200:
                    data = resp.json().get("series", [])
                    for s in data:
                        metric_label = s.get("metric", "cpu")
                        points = [
                            HistoricalDataPoint(
                                timestamp=datetime.fromtimestamp(p[0] / 1000.0, tz=timezone.utc).strftime("%H:%M:%S"),
                                value=round(float(p[1]), 2)
                            )
                            for p in s.get("pointlist", [])
                            if p[1] is not None
                        ]
                        vals = [p.value for p in points]
                        series_dict[metric_label] = HistoricalSeries(
                            name=metric_label,
                            unit="percent",
                            points=points,
                            current=vals[-1] if vals else 0.0,
                            avg=round(sum(vals) / len(vals), 2) if vals else 0.0,
                            peak=max(vals) if vals else 0.0,
                            min_val=min(vals) if vals else 0.0
                        )
        except Exception as exc:
            logger.warning(f"Datadog historical telemetry query failed: {exc}")

        return UnifiedHistoricalTelemetry(
            environment_id=environment_id,
            target_id=target_id,
            timeframe=timeframe,
            series=series_dict
        )

    async def get_alerts(self, environment_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Retrieves active alerts from Datadog Monitors API."""
        url = f"{self.base_url}/api/v1/monitor"
        alerts = []
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self._headers, params={"monitor_tags": "env:production"})
                if resp.status_code == 200:
                    monitors = resp.json()
                    for m in monitors:
                        if m.get("overall_state") in ["Alert", "Warn"]:
                            alerts.append({
                                "alert_id": str(m.get("id")),
                                "title": m.get("name"),
                                "severity": "CRITICAL" if m.get("overall_state") == "Alert" else "WARNING",
                                "source": self.provider_id,
                                "message": m.get("message", "")
                            })
        except Exception as exc:
            logger.warning(f"Datadog alerts query failed: {exc}")
        return alerts


AdapterFactory.register_adapter_class("DATADOG", DatadogMonitoringAdapter)
