import time
import httpx
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from app.core.logging import logger
from app.adapters.monitoring.base import (
    BaseMonitoringAdapter,
    ProviderHealth,
    UnifiedTarget,
    ConnectionTestResult
)
from app.schemas.unified_monitoring import (
    UnifiedMetricSample,
    UnifiedHistoricalTelemetry,
    MetricAvailabilityState
)
from app.adapters.monitoring.factory import AdapterFactory


class NagiosMonitoringAdapter(BaseMonitoringAdapter):
    """
    Enterprise Nagios Core / XI Monitoring Adapter for SmartQE TEM.
    Translates Nagios host/service check statuses into the Unified Monitoring Model.
    Explicitly tags unsupported metrics (e.g. JVM heap or deep DB wait events) as UNSUPPORTED.
    """

    def __init__(
        self,
        provider_id: str = "nagios-onprem",
        provider_name: str = "Nagios Infrastructure Monitor",
        base_url: str = "http://localhost:80",
        capabilities: Optional[List[str]] = None,
        timeout: float = 6.0,
        tool_parameters: Optional[Dict[str, Any]] = None,
        credentials: Optional[Dict[str, Any]] = None
    ):
        super().__init__(
            provider_id=provider_id,
            provider_name=provider_name,
            provider_type="NAGIOS",
            base_url=base_url or "http://localhost:80",
            capabilities=capabilities or ["INFRASTRUCTURE", "SERVER", "NETWORK", "ALERTS"],
            timeout=timeout,
            tool_parameters=tool_parameters or {}
        )
        self.credentials = credentials or {}
        self.username = self.credentials.get("username", "")
        self.password = self.credentials.get("password", "")
        self.api_key = self.credentials.get("api_key", "")
        self.is_xi = self.tool_parameters.get("is_xi", False)

    def _get_auth(self) -> Optional[httpx.BasicAuth]:
        if self.username and self.password:
            return httpx.BasicAuth(self.username, self.password)
        return None

    async def test_connection(self) -> ConnectionTestResult:
        """Probes Nagios web API endpoint."""
        start = time.perf_counter()
        try:
            endpoint = (
                f"{self.base_url}/nagiosxi/api/v1/system/status?apikey={self.api_key}"
                if self.is_xi
                else f"{self.base_url}/nagios/cgi-bin/statusjson.cgi?query=programstatus"
            )
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(endpoint, auth=self._get_auth())
                latency = (time.perf_counter() - start) * 1000.0

                if resp.status_code == 200:
                    return ConnectionTestResult(
                        success=True,
                        latency_ms=round(latency, 2),
                        message="Connected to Nagios Monitoring Engine",
                        discovered_capabilities=self.capabilities,
                        raw_probe_details={"is_xi": self.is_xi}
                    )
                return ConnectionTestResult(
                    success=False,
                    latency_ms=round(latency, 2),
                    message=f"Nagios HTTP check returned status {resp.status_code}"
                )
        except Exception as exc:
            latency = (time.perf_counter() - start) * 1000.0
            return ConnectionTestResult(success=False, latency_ms=round(latency, 2), message=str(exc))

    async def get_health(self) -> ProviderHealth:
        test = await self.test_connection()
        return ProviderHealth(
            provider_id=self.provider_id,
            provider_name=self.provider_name,
            provider_type=self.provider_type,
            is_healthy=test.success,
            status="HEALTHY" if test.success else "DOWN",
            latency_ms=test.latency_ms,
            data_freshness_seconds=5.0 if test.success else 999.0,
            error_message=None if test.success else test.message,
            capabilities_online=self.capabilities if test.success else []
        )

    async def get_targets(self, environment_id: Optional[str] = None) -> List[UnifiedTarget]:
        """Discovers hosts managed by Nagios."""
        endpoint = (
            f"{self.base_url}/nagiosxi/api/v1/objects/host?apikey={self.api_key}"
            if self.is_xi
            else f"{self.base_url}/nagios/cgi-bin/statusjson.cgi?query=hostlist"
        )
        targets = []
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(endpoint, auth=self._get_auth())
                if res.status_code == 200:
                    hosts = res.json().get("data", {}).get("hostlist", {}) if not self.is_xi else res.json()
                    for host_name, details in (hosts.items() if isinstance(hosts, dict) else []):
                        status_code = details.get("status", 0) if isinstance(details, dict) else 0
                        is_up = (status_code == 0)
                        targets.append(UnifiedTarget(
                            id=f"nagios-{host_name}",
                            name=host_name,
                            environment_id=environment_id or "env-onprem",
                            environment_name="On-Premises Infrastructure",
                            target_type="SERVER",
                            endpoint_url=f"nagios://host/{host_name}",
                            is_up=is_up,
                            status="UP" if is_up else "DOWN",
                            labels={"source": "nagios"},
                            source_tool_id=self.provider_id
                        ))
        except Exception as exc:
            logger.warning(f"Nagios get_targets failed: {exc}")
        return targets

    async def get_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None
    ) -> List[UnifiedMetricSample]:
        """
        Retrieves Nagios metrics.
        Crucial requirement: Explicitly tags unsupported metrics as UNSUPPORTED rather than returning 0.
        """
        samples: List[UnifiedMetricSample] = []

        # Server Ping / Availability
        samples.append(UnifiedMetricSample(
            environment=environment_id,
            environment_id=environment_id,
            target=target_id or "nagios-host-default",
            target_type="SERVER",
            metric="server_availability",
            value=1.0,
            unit="status",
            availability_state=MetricAvailabilityState.ACTIVE_VALUE,
            source=self.provider_id,
            provider=self.__class__.__name__
        ))

        # Explicitly tag unsupported metrics (e.g., JVM heap)
        if metric_names:
            for m in metric_names:
                if any(k in m.lower() for k in ["jvm", "thread_count", "gc_pause", "db_pool"]):
                    samples.append(UnifiedMetricSample(
                        environment=environment_id,
                        environment_id=environment_id,
                        target=target_id or "nagios-host-default",
                        target_type="APPLICATION",
                        metric=m,
                        value=None,
                        unit="unsupported",
                        availability_state=MetricAvailabilityState.UNSUPPORTED,
                        unsupported_reason="Nagios infrastructure agent does not collect JVM / Application runtime diagnostics",
                        source=self.provider_id,
                        provider=self.__class__.__name__
                    ))

        return samples

    async def get_historical_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None,
        timeframe: str = "1h"
    ) -> UnifiedHistoricalTelemetry:
        return UnifiedHistoricalTelemetry(
            environment_id=environment_id,
            target_id=target_id,
            timeframe=timeframe,
            series={}
        )

    async def get_alerts(self, environment_id: Optional[str] = None) -> List[Dict[str, Any]]:
        return []


AdapterFactory.register_adapter_class("NAGIOS", NagiosMonitoringAdapter)
