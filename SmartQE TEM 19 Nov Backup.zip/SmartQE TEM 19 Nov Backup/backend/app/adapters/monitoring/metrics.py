import time
from typing import Dict, Any, List
from collections import defaultdict
import threading


class MonitoringOperationalMetrics:
    """
    In-memory, thread-safe operational metrics collector for the
    Enterprise Monitoring Integration Layer.
    
    Tracks API traffic, query latencies, provider errors, and data freshness.
    Can export both structured JSON summary and OpenMetrics/Prometheus exposition text.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self.start_time = time.time()
        
        # Counters
        self.api_requests_total: Dict[str, int] = defaultdict(int)
        self.provider_requests_total: Dict[str, int] = defaultdict(int)
        self.provider_errors_total: Dict[str, int] = defaultdict(int)
        self.cache_hits_total: int = 0
        self.cache_misses_total: int = 0
        
        # Timing / Latencies (Sum & Count)
        self.api_duration_sum: float = 0.0
        self.api_duration_count: int = 0
        self.provider_query_duration_sum: float = 0.0
        self.provider_query_duration_count: int = 0
        
        # Gauges
        self.data_freshness_seconds: float = 0.0

    def record_api_request(self, endpoint: str, status_code: int, duration_seconds: float):
        with self._lock:
            key = f"{endpoint}_{status_code}"
            self.api_requests_total[key] += 1
            self.api_duration_sum += duration_seconds
            self.api_duration_count += 1

    def record_provider_query(self, provider: str, operation: str, duration_seconds: float, is_error: bool = False, error_type: str = "none"):
        with self._lock:
            key = f"{provider}_{operation}"
            self.provider_requests_total[key] += 1
            self.provider_query_duration_sum += duration_seconds
            self.provider_query_duration_count += 1
            if is_error:
                err_key = f"{provider}_{error_type}"
                self.provider_errors_total[err_key] += 1

    def record_data_freshness(self, age_seconds: float):
        with self._lock:
            self.data_freshness_seconds = round(age_seconds, 2)

    def record_cache_hit(self):
        with self._lock:
            self.cache_hits_total += 1

    def record_cache_miss(self):
        with self._lock:
            self.cache_misses_total += 1

    def get_summary(self) -> Dict[str, Any]:
        with self._lock:
            uptime = round(time.time() - self.start_time, 1)
            api_avg_ms = round((self.api_duration_sum / max(1, self.api_duration_count)) * 1000, 2)
            prov_avg_ms = round((self.provider_query_duration_sum / max(1, self.provider_query_duration_count)) * 1000, 2)
            total_cache = self.cache_hits_total + self.cache_misses_total
            cache_ratio = round((self.cache_hits_total / total_cache) * 100, 1) if total_cache > 0 else 0.0

            return {
                "uptime_seconds": uptime,
                "total_api_requests": sum(self.api_requests_total.values()),
                "api_request_duration_avg_ms": api_avg_ms,
                "total_provider_queries": sum(self.provider_requests_total.values()),
                "provider_query_errors": sum(self.provider_errors_total.values()),
                "provider_query_duration_avg_ms": prov_avg_ms,
                "cache_hit_ratio_pct": cache_ratio,
                "last_data_freshness_seconds": self.data_freshness_seconds,
                "details": {
                    "api_requests": dict(self.api_requests_total),
                    "provider_requests": dict(self.provider_requests_total),
                    "provider_errors": dict(self.provider_errors_total)
                }
            }

    def to_openmetrics_text(self) -> str:
        with self._lock:
            lines = [
                "# HELP monitoring_layer_uptime_seconds Total running seconds of the integration layer",
                "# TYPE monitoring_layer_uptime_seconds counter",
                f"monitoring_layer_uptime_seconds {round(time.time() - self.start_time, 1)}",
                "",
                "# HELP monitoring_api_requests_total Total API requests processed by monitoring layer",
                "# TYPE monitoring_api_requests_total counter"
            ]
            for key, val in self.api_requests_total.items():
                parts = key.rsplit("_", 1)
                endpoint = parts[0]
                status_code = parts[1] if len(parts) > 1 else "200"
                lines.append(f'monitoring_api_requests_total{{endpoint="{endpoint}",status="{status_code}"}} {val}')

            lines.extend([
                "",
                "# HELP monitoring_provider_requests_total Total requests dispatched to monitoring adapters",
                "# TYPE monitoring_provider_requests_total counter"
            ])
            for key, val in self.provider_requests_total.items():
                parts = key.split("_", 1)
                provider = parts[0]
                op = parts[1] if len(parts) > 1 else "query"
                lines.append(f'monitoring_provider_requests_total{{provider="{provider}",operation="{op}"}} {val}')

            lines.extend([
                "",
                "# HELP monitoring_provider_errors_total Total errors encountered querying adapters",
                "# TYPE monitoring_provider_errors_total counter"
            ])
            for key, val in self.provider_errors_total.items():
                parts = key.split("_", 1)
                provider = parts[0]
                err_type = parts[1] if len(parts) > 1 else "error"
                lines.append(f'monitoring_provider_errors_total{{provider="{provider}",error_type="{err_type}"}} {val}')

            lines.extend([
                "",
                "# HELP monitoring_data_freshness_seconds Current data freshness in seconds",
                "# TYPE monitoring_data_freshness_seconds gauge",
                f"monitoring_data_freshness_seconds {self.data_freshness_seconds}",
                "",
                "# HELP monitoring_cache_hits_total Total query cache hits",
                "# TYPE monitoring_cache_hits_total counter",
                f"monitoring_cache_hits_total {self.cache_hits_total}",
                "",
                "# HELP monitoring_cache_misses_total Total query cache misses",
                "# TYPE monitoring_cache_misses_total counter",
                f"monitoring_cache_misses_total {self.cache_misses_total}",
                ""
            ])
            return "\n".join(lines)


operational_metrics = MonitoringOperationalMetrics()
