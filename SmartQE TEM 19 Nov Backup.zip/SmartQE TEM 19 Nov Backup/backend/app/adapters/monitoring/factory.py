from typing import Dict, Type, Any, Optional, List
from app.core.logging import logger
from app.adapters.monitoring.base import BaseMonitoringAdapter
from app.models.monitoring_config import MonitoringToolConfig


class AdapterFactory:
    """
    Extensible factory responsible for instantiating concrete monitoring adapters
    based on centralized configuration records and decrypted credentials.
    Allows adding new monitoring tools dynamically without touching existing adapters.
    """
    _registry: Dict[str, Type[BaseMonitoringAdapter]] = {}

    @classmethod
    def register_adapter_class(cls, tool_type: str, adapter_cls: Type[BaseMonitoringAdapter]):
        """Registers a new adapter class for a given tool type string."""
        cls._registry[tool_type.upper()] = adapter_cls
        logger.info(f"Registered monitoring adapter class '{adapter_cls.__name__}' for tool type '{tool_type}'")

    @classmethod
    def get_adapter_class(cls, tool_type: str) -> Optional[Type[BaseMonitoringAdapter]]:
        """Returns the adapter class registered for a given tool type."""
        return cls._registry.get(tool_type.upper())

    @classmethod
    def list_supported_tool_types(cls) -> List[str]:
        """Lists all registered tool type identifiers."""
        return list(cls._registry.keys())

    @classmethod
    def create_adapter(
        cls,
        config: MonitoringToolConfig,
        decrypted_credentials: Optional[Dict[str, Any]] = None
    ) -> BaseMonitoringAdapter:
        """Instantiates an adapter instance using its registered class and decrypted credentials."""
        tool_type_key = config.tool_type.value if hasattr(config.tool_type, "value") else str(config.tool_type)
        tool_type_key = tool_type_key.upper()

        adapter_cls = cls._registry.get(tool_type_key)
        if not adapter_cls:
            raise ValueError(
                f"No monitoring adapter class registered for tool type '{tool_type_key}'. "
                f"Registered tool types: {list(cls._registry.keys())}"
            )

        init_kwargs: Dict[str, Any] = {
            "provider_id": config.tool_identifier,
            "provider_name": config.display_name,
            "base_url": config.base_url,
            "capabilities": config.capabilities or [],
            "timeout": config.timeout_seconds or 5.0,
            "tool_parameters": config.tool_parameters or {}
        }

        if decrypted_credentials:
            init_kwargs["credentials"] = decrypted_credentials

        return adapter_cls(**init_kwargs)
