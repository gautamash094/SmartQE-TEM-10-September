"""
Monitoring Integration Layer - Provider Adapter Pattern.
Exposes tool-agnostic monitoring interfaces decoupling TEM from specific collection technologies.
"""
from app.adapters.monitoring.base import BaseMonitoringAdapter, ProviderHealth, UnifiedTarget
from app.adapters.monitoring.prometheus_client import (
    PrometheusClient,
    PrometheusClientError,
    PrometheusConnectionError,
    PrometheusTimeoutError,
    PrometheusQueryError
)
from app.adapters.monitoring.normalizer import MonitoringNormalizer, normalizer
from app.adapters.monitoring.metrics import MonitoringOperationalMetrics, operational_metrics
from app.adapters.monitoring.prometheus_adapter import PrometheusAdapter
from app.adapters.monitoring.application_adapter import ApplicationMonitoringAdapter
from app.adapters.monitoring.server_adapter import ServerMonitoringAdapter
from app.adapters.monitoring.custom_adapter import CustomMonitoringAdapter
from app.adapters.monitoring.registry import MonitoringAdapterRegistry, adapter_registry

__all__ = [
    "BaseMonitoringAdapter",
    "ProviderHealth",
    "UnifiedTarget",
    "PrometheusClient",
    "PrometheusClientError",
    "PrometheusConnectionError",
    "PrometheusTimeoutError",
    "PrometheusQueryError",
    "MonitoringNormalizer",
    "normalizer",
    "MonitoringOperationalMetrics",
    "operational_metrics",
    "PrometheusAdapter",
    "ApplicationMonitoringAdapter",
    "ServerMonitoringAdapter",
    "CustomMonitoringAdapter",
    "MonitoringAdapterRegistry",
    "adapter_registry",
]
