import time
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timezone

from app.schemas.normalized_monitoring import (
    NormalizedMetric,
    NormalizedResource,
    DataFreshness,
    DiscoveredMetric
)
from app.schemas.unified_monitoring import UnifiedMetricSample


class MonitoringNormalizer:
    """
    Monitoring Normalization Engine.
    Transforms heterogeneous, provider-specific telemetry (Prometheus vector/matrix,
    OpenMetrics samples, database stats) into normalized, tool-agnostic data models.
    """

    # Semantic metric dictionary mapping raw metric names to normalized TEM metadata
    METRIC_SEMANTIC_MAP = {
        # --- SQLite Database Exporter Metrics ---
        "sqlite_database_up": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_availability",
            "unit": "status",
            "healthy_value": 1.0,
        },
        "sqlite_database_size_bytes": {
            "resource_type": "database",
            "metric_category": "STORAGE",
            "metric_name": "database_size",
            "unit": "bytes",
        },
        "sqlite_database_used_bytes": {
            "resource_type": "database",
            "metric_category": "STORAGE",
            "metric_name": "database_used_storage",
            "unit": "bytes",
        },
        "sqlite_database_page_count": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_page_count",
            "unit": "pages",
        },
        "sqlite_database_page_size_bytes": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_page_size",
            "unit": "bytes",
        },
        "sqlite_database_freelist_pages": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_free_pages",
            "unit": "pages",
        },
        "sqlite_database_tables_total": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_tables_count",
            "unit": "count",
        },
        "sqlite_database_query_duration_seconds": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_query_duration",
            "unit": "seconds",
        },
        "sqlite_database_wal_size_bytes": {
            "resource_type": "database",
            "metric_category": "STORAGE",
            "metric_name": "database_wal_size",
            "unit": "bytes",
        },
        "sqlite_database_errors_total": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_errors_count",
            "unit": "count",
        },
        # --- SQLite Table-Level Metrics ---
        "sqlite_table_rows_total": {
            "resource_type": "database_table",
            "metric_category": "DATABASE",
            "metric_name": "table_row_count",
            "unit": "rows",
        },
        "sqlite_table_size_bytes": {
            "resource_type": "database_table",
            "metric_category": "STORAGE",
            "metric_name": "table_size",
            "unit": "bytes",
        },
        "sqlite_table_indexes_total": {
            "resource_type": "database_table",
            "metric_category": "DATABASE",
            "metric_name": "table_indexes_count",
            "unit": "count",
        },
        "sqlite_table_columns_total": {
            "resource_type": "database_table",
            "metric_category": "DATABASE",
            "metric_name": "table_columns_count",
            "unit": "count",
        },
        # --- PostgreSQL Database Exporter Metrics ---
        "pg_up": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_availability",
            "unit": "status",
            "healthy_value": 1.0,
        },
        "pg_database_up": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_availability",
            "unit": "status",
            "healthy_value": 1.0,
        },
        "pg_connection_status": {
            "resource_type": "database",
            "metric_category": "CONNECTION",
            "metric_name": "connection_status",
            "unit": "status",
            "healthy_value": 1.0,
        },
        "pg_settings_max_connections": {
            "resource_type": "database",
            "metric_category": "CONNECTION",
            "metric_name": "max_connections",
            "unit": "count",
        },
        "pg_stat_activity_count": {
            "resource_type": "database",
            "metric_category": "CONNECTION",
            "metric_name": "connections_count",
            "unit": "count",
        },
        "pg_connection_utilization_ratio": {
            "resource_type": "database",
            "metric_category": "CONNECTION",
            "metric_name": "connection_utilization",
            "unit": "%",
            "warning_threshold": 75.0,
            "critical_threshold": 90.0,
        },
        "pg_connection_errors_total": {
            "resource_type": "database",
            "metric_category": "CONNECTION",
            "metric_name": "connection_errors_count",
            "unit": "count",
        },
        "pg_stat_database_xact_commit": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "transaction_commits",
            "unit": "count",
        },
        "pg_stat_database_xact_rollback": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "transaction_rollbacks",
            "unit": "count",
        },
        "pg_stat_statements_calls_total": {
            "resource_type": "database",
            "metric_category": "QUERY",
            "metric_name": "query_execution_count",
            "unit": "count",
        },
        "pg_stat_statements_total_time_seconds": {
            "resource_type": "database",
            "metric_category": "QUERY",
            "metric_name": "query_total_time",
            "unit": "seconds",
        },
        "pg_stat_statements_mean_time_seconds": {
            "resource_type": "database",
            "metric_category": "QUERY",
            "metric_name": "query_average_time",
            "unit": "seconds",
        },
        "pg_stat_statements_rows_total": {
            "resource_type": "database",
            "metric_category": "QUERY",
            "metric_name": "query_rows",
            "unit": "rows",
        },
        "pg_slow_queries_total": {
            "resource_type": "database",
            "metric_category": "QUERY",
            "metric_name": "slow_queries_count",
            "unit": "count",
            "warning_threshold": 1.0,
            "critical_threshold": 10.0,
        },
        "pg_slow_query_max_duration_seconds": {
            "resource_type": "database",
            "metric_category": "QUERY",
            "metric_name": "slow_query_max_duration",
            "unit": "seconds",
        },
        "pg_slow_query_avg_duration_seconds": {
            "resource_type": "database",
            "metric_category": "QUERY",
            "metric_name": "slow_query_average_duration",
            "unit": "seconds",
        },
        "pg_locks_count": {
            "resource_type": "database",
            "metric_category": "LOCK",
            "metric_name": "locks_count",
            "unit": "count",
        },
        "pg_locks_waiting_total": {
            "resource_type": "database",
            "metric_category": "LOCK",
            "metric_name": "waiting_locks",
            "unit": "count",
            "warning_threshold": 1.0,
            "critical_threshold": 5.0,
        },
        "pg_stat_database_deadlocks": {
            "resource_type": "database",
            "metric_category": "LOCK",
            "metric_name": "deadlocks_count",
            "unit": "count",
            "warning_threshold": 1.0,
            "critical_threshold": 5.0,
        },
        "pg_blocked_queries_count": {
            "resource_type": "database",
            "metric_category": "LOCK",
            "metric_name": "blocked_queries",
            "unit": "count",
            "warning_threshold": 1.0,
            "critical_threshold": 5.0,
        },
        "pg_blocking_queries_count": {
            "resource_type": "database",
            "metric_category": "LOCK",
            "metric_name": "blocking_queries",
            "unit": "count",
        },
        "pg_lock_wait_duration_seconds": {
            "resource_type": "database",
            "metric_category": "LOCK",
            "metric_name": "lock_wait_duration",
            "unit": "seconds",
        },
        "pg_database_size_bytes": {
            "resource_type": "database",
            "metric_category": "STORAGE",
            "metric_name": "database_size",
            "unit": "bytes",
        },
        "pg_database_tables_total": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_tables_count",
            "unit": "count",
        },
        "pg_database_indexes_total": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "database_indexes_count",
            "unit": "count",
        },
        "pg_table_size_bytes": {
            "resource_type": "database_table",
            "metric_category": "STORAGE",
            "metric_name": "table_size",
            "unit": "bytes",
        },
        "pg_table_rows_total": {
            "resource_type": "database_table",
            "metric_category": "DATABASE",
            "metric_name": "table_row_count",
            "unit": "rows",
        },
        "pg_stat_database_blks_hit": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "blocks_hit",
            "unit": "count",
        },
        "pg_stat_database_blks_read": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "blocks_read",
            "unit": "count",
        },
        "pg_cache_hit_ratio": {
            "resource_type": "database",
            "metric_category": "DATABASE",
            "metric_name": "cache_hit_ratio",
            "unit": "%",
        },
        "pg_wal_bytes_total": {
            "resource_type": "database",
            "metric_category": "STORAGE",
            "metric_name": "wal_size",
            "unit": "bytes",
        },
        "pg_exporter_scrape_duration_seconds": {
            "resource_type": "exporter",
            "metric_category": "INFRASTRUCTURE",
            "metric_name": "scrape_duration",
            "unit": "seconds",
        },
        "pg_exporter_scrape_success": {
            "resource_type": "exporter",
            "metric_category": "INFRASTRUCTURE",
            "metric_name": "scrape_success",
            "unit": "status",
            "healthy_value": 1.0,
        },
        "pg_last_successful_collection_timestamp_seconds": {
            "resource_type": "exporter",
            "metric_category": "INFRASTRUCTURE",
            "metric_name": "last_collection_timestamp",
            "unit": "seconds",
        },
        "pg_monitoring_errors_total": {
            "resource_type": "exporter",
            "metric_category": "INFRASTRUCTURE",
            "metric_name": "monitoring_errors",
            "unit": "count",
        },
        # --- Target / Node Health Metrics ---
        "up": {
            "resource_type": "target",
            "metric_category": "INFRASTRUCTURE",
            "metric_name": "target_up",
            "unit": "status",
            "healthy_value": 1.0,
        },
        "scrape_duration_seconds": {
            "resource_type": "exporter",
            "metric_category": "INFRASTRUCTURE",
            "metric_name": "scrape_duration",
            "unit": "seconds",
        },
        # --- System Indicators ---
        "cpu_utilization": {
            "resource_type": "server",
            "metric_category": "INFRASTRUCTURE",
            "metric_name": "cpu_utilization",
            "unit": "%",
            "warning_threshold": 75.0,
            "critical_threshold": 90.0,
        },
        "memory_utilization": {
            "resource_type": "server",
            "metric_category": "INFRASTRUCTURE",
            "metric_name": "memory_utilization",
            "unit": "%",
            "warning_threshold": 80.0,
            "critical_threshold": 92.0,
        },
        "disk_utilization": {
            "resource_type": "server",
            "metric_category": "STORAGE",
            "metric_name": "disk_utilization",
            "unit": "%",
            "warning_threshold": 80.0,
            "critical_threshold": 90.0,
        },
        "http_response_time_ms": {
            "resource_type": "application",
            "metric_category": "APPLICATION",
            "metric_name": "response_time",
            "unit": "ms",
            "warning_threshold": 250.0,
            "critical_threshold": 600.0,
        },
        "http_error_rate_pct": {
            "resource_type": "application",
            "metric_category": "APPLICATION",
            "metric_name": "error_rate",
            "unit": "%",
            "warning_threshold": 2.0,
            "critical_threshold": 5.0,
        },
        # --- Windows Exporter Infrastructure Metrics ---
        "windows_cpu_logical_processor": {
            "resource_type": "server",
            "metric_category": "CPU",
            "metric_name": "cpu_core_count",
            "unit": "cores",
        },
        "windows_cs_logical_processors": {
            "resource_type": "server",
            "metric_category": "CPU",
            "metric_name": "cpu_core_count",
            "unit": "cores",
        },
        "windows_cpu_time_seconds_total": {
            "resource_type": "server",
            "metric_category": "CPU",
            "metric_name": "cpu_time_seconds",
            "unit": "seconds",
        },
        "windows_cpu_time_total": {
            "resource_type": "server",
            "metric_category": "CPU",
            "metric_name": "cpu_time_seconds",
            "unit": "seconds",
        },
        "windows_cpu_utilization": {
            "resource_type": "server",
            "metric_category": "CPU",
            "metric_name": "cpu_utilization",
            "unit": "%",
            "warning_threshold": 75.0,
            "critical_threshold": 90.0,
        },
        "windows_memory_physical_total_bytes": {
            "resource_type": "server",
            "metric_category": "MEMORY",
            "metric_name": "memory_total_bytes",
            "unit": "bytes",
        },
        "windows_cs_physical_memory_bytes": {
            "resource_type": "server",
            "metric_category": "MEMORY",
            "metric_name": "memory_total_bytes",
            "unit": "bytes",
        },
        "windows_memory_physical_free_bytes": {
            "resource_type": "server",
            "metric_category": "MEMORY",
            "metric_name": "memory_free_bytes",
            "unit": "bytes",
        },
        "windows_os_physical_memory_free_bytes": {
            "resource_type": "server",
            "metric_category": "MEMORY",
            "metric_name": "memory_free_bytes",
            "unit": "bytes",
        },
        "windows_memory_swap_pages_read_total": {
            "resource_type": "server",
            "metric_category": "MEMORY",
            "metric_name": "swap_pages_read",
            "unit": "pages",
        },
        "windows_memory_swap_pages_written_total": {
            "resource_type": "server",
            "metric_category": "MEMORY",
            "metric_name": "swap_pages_written",
            "unit": "pages",
        },
        "windows_logical_disk_size_bytes": {
            "resource_type": "server",
            "metric_category": "STORAGE",
            "metric_name": "disk_size_bytes",
            "unit": "bytes",
        },
        "windows_logical_disk_free_bytes": {
            "resource_type": "server",
            "metric_category": "STORAGE",
            "metric_name": "disk_free_bytes",
            "unit": "bytes",
        },
        "windows_logical_disk_read_bytes_total": {
            "resource_type": "server",
            "metric_category": "STORAGE",
            "metric_name": "disk_read_bytes",
            "unit": "bytes",
        },
        "windows_logical_disk_write_bytes_total": {
            "resource_type": "server",
            "metric_category": "STORAGE",
            "metric_name": "disk_write_bytes",
            "unit": "bytes",
        },
        "windows_logical_disk_reads_total": {
            "resource_type": "server",
            "metric_category": "STORAGE",
            "metric_name": "disk_reads_total",
            "unit": "count",
        },
        "windows_logical_disk_writes_total": {
            "resource_type": "server",
            "metric_category": "STORAGE",
            "metric_name": "disk_writes_total",
            "unit": "count",
        },
        "windows_net_bytes_received_total": {
            "resource_type": "server",
            "metric_category": "NETWORK",
            "metric_name": "network_bytes_rx",
            "unit": "bytes",
        },
        "windows_net_bytes_sent_total": {
            "resource_type": "server",
            "metric_category": "NETWORK",
            "metric_name": "network_bytes_tx",
            "unit": "bytes",
        },
        "windows_net_packets_received_errors_total": {
            "resource_type": "server",
            "metric_category": "NETWORK",
            "metric_name": "network_rx_errors",
            "unit": "count",
            "warning_threshold": 1.0,
            "critical_threshold": 10.0,
        },
        "windows_net_packets_outbound_errors_total": {
            "resource_type": "server",
            "metric_category": "NETWORK",
            "metric_name": "network_tx_errors",
            "unit": "count",
            "warning_threshold": 1.0,
            "critical_threshold": 10.0,
        },
        "windows_net_current_bandwidth_bytes": {
            "resource_type": "server",
            "metric_category": "NETWORK",
            "metric_name": "network_bandwidth",
            "unit": "bytes",
        },
        "windows_system_boot_time_timestamp": {
            "resource_type": "server",
            "metric_category": "SYSTEM",
            "metric_name": "system_boot_time",
            "unit": "timestamp",
        },
        "windows_system_system_up_time": {
            "resource_type": "server",
            "metric_category": "SYSTEM",
            "metric_name": "system_uptime_seconds",
            "unit": "seconds",
        },
        "windows_system_processes": {
            "resource_type": "server",
            "metric_category": "SYSTEM",
            "metric_name": "processes_count",
            "unit": "count",
        },
        "windows_system_threads": {
            "resource_type": "server",
            "metric_category": "SYSTEM",
            "metric_name": "threads_count",
            "unit": "count",
        },
        "windows_system_context_switches_total": {
            "resource_type": "server",
            "metric_category": "SYSTEM",
            "metric_name": "context_switches",
            "unit": "count",
        },
        "windows_os_info": {
            "resource_type": "server",
            "metric_category": "SYSTEM",
            "metric_name": "os_info",
            "unit": "status",
        },
        "windows_os_hostname": {
            "resource_type": "server",
            "metric_category": "SYSTEM",
            "metric_name": "os_hostname",
            "unit": "status",
        },
        "windows_service_state": {
            "resource_type": "server",
            "metric_category": "SERVICE",
            "metric_name": "service_state",
            "unit": "status",
        },
        "windows_service_status": {
            "resource_type": "server",
            "metric_category": "SERVICE",
            "metric_name": "service_status",
            "unit": "status",
        },
        "windows_process_cpu_time_total": {
            "resource_type": "server",
            "metric_category": "PROCESS",
            "metric_name": "process_cpu_seconds",
            "unit": "seconds",
        },
        "windows_process_working_set_bytes": {
            "resource_type": "server",
            "metric_category": "PROCESS",
            "metric_name": "process_memory_bytes",
            "unit": "bytes",
        },
    }

    @staticmethod
    def calculate_freshness(timestamp: float, stale_threshold_seconds: float = 60.0) -> DataFreshness:
        """Computes age and freshness classification."""
        now = time.time()
        age = max(0.0, round(now - timestamp, 1))
        status = "FRESH" if age <= stale_threshold_seconds else "STALE"
        return DataFreshness(
            age_seconds=age,
            status=status,
            threshold_seconds=stale_threshold_seconds
        )

    def normalize_metric(
        self,
        raw_name: str,
        value: float,
        timestamp: float,
        labels: Dict[str, str],
        source: str = "prometheus",
        provider: str = "PrometheusAdapter",
        environment_id: Optional[str] = None,
        environment_name: Optional[str] = None
    ) -> NormalizedMetric:
        """
        Normalizes a raw metric sample into a NormalizedMetric object.
        """
        semantic = self.METRIC_SEMANTIC_MAP.get(raw_name, {
            "resource_type": "generic",
            "metric_category": "GENERAL",
            "metric_name": raw_name,
            "unit": "value"
        })

        res_type = semantic["resource_type"]
        category = semantic["metric_category"]
        norm_name = semantic["metric_name"]
        unit = semantic["unit"]

        # Derive resource name, resource ID, and technology from labels and metric names
        table_label = labels.get("table")
        job_label = labels.get("job")
        instance_label = labels.get("instance")
        db_label = labels.get("database")
        tech_label = labels.get("technology")
        os_label = labels.get("os")
        hostname_label = labels.get("hostname")

        is_windows = (
            raw_name.startswith("windows_") or
            tech_label == "windows" or
            os_label == "windows" or
            (job_label and "windows" in str(job_label).lower()) or
            provider in ["WindowsExporter", "ServerMonitoringAdapter"]
        )

        is_postgres = (
            raw_name.startswith("pg_") or
            tech_label == "postgresql" or
            (job_label and "postgres" in str(job_label).lower()) or
            provider == "PostgreSQLAdapter"
        )
        is_sqlite = (
            raw_name.startswith("sqlite_") or
            tech_label == "sqlite" or
            (job_label and "sqlite" in str(job_label).lower())
        )

        if is_windows:
            tech = "windows"
        elif is_postgres:
            tech = "postgresql"
        elif is_sqlite:
            tech = "sqlite"
        else:
            tech = "generic"

        db_name = db_label or ("smartqe_tem" if is_postgres else "sqlite")

        if table_label:
            resource_name = f"{db_name}:{table_label}"
            resource_id = f"table-pg-{db_name}-{table_label}" if is_postgres else f"table-{table_label}"
            res_type = "database_table"
        elif is_windows:
            host = hostname_label or instance_label or "windows-host"
            resource_name = f"windows-server-{host}"
            resource_id = f"server-{host.replace(':', '_')}"
            res_type = "server"
        elif is_postgres:
            resource_name = f"postgresql-{db_name}"
            resource_id = f"resource-postgres-db-{db_name}"
            res_type = "database"
        elif is_sqlite or "sqlite" in raw_name or db_label:
            resource_name = f"sqlite-{db_name}"
            resource_id = f"db-{db_name}"
            res_type = "database"
        elif instance_label:
            resource_name = instance_label
            resource_id = f"target-{instance_label.replace(':', '_')}"
        else:
            resource_name = job_label or "unknown-resource"
            resource_id = f"res-{resource_name}"

        # Determine health & status
        status = "HEALTHY"
        severity = "INFO"

        if raw_name == "pg_cache_hit_ratio":
            if value < 70.0:
                status = "CRITICAL"
                severity = "CRITICAL"
            elif value < 85.0:
                status = "WARNING"
                severity = "MEDIUM"
        elif "healthy_value" in semantic:
            if value != semantic["healthy_value"]:
                status = "DOWN"
                severity = "CRITICAL"
        elif "critical_threshold" in semantic and value >= semantic["critical_threshold"]:
            status = "CRITICAL"
            severity = "CRITICAL"
        elif "warning_threshold" in semantic and value >= semantic["warning_threshold"]:
            status = "WARNING"
            severity = "MEDIUM"

        freshness = self.calculate_freshness(timestamp)

        dt = datetime.fromtimestamp(timestamp, tz=timezone.utc)

        norm_labels = dict(labels)
        if "technology" not in norm_labels and tech:
            norm_labels["technology"] = tech

        return NormalizedMetric(
            source=source,
            provider=provider,
            environment=environment_name or labels.get("environment", "Default"),
            environment_id=environment_id or labels.get("environment_id"),
            resource=resource_name,
            resource_id=resource_id,
            resource_type=res_type,
            metric_category=category,
            metric_name=norm_name,
            value=value,
            unit=unit,
            timestamp=dt,
            labels=norm_labels,
            status=status,
            severity=severity,
            data_freshness=freshness
        )

    def to_unified_metric_sample(self, norm: NormalizedMetric) -> UnifiedMetricSample:
        """
        Converts NormalizedMetric into UnifiedMetricSample to maintain 100%
        compatibility with existing TEM frontend dashboards.
        """
        return UnifiedMetricSample(
            environment=norm.environment or "Default",
            environment_id=norm.environment_id or "env-01",
            target=norm.resource,
            target_type=norm.resource_type.upper(),
            server=norm.server or (norm.resource if norm.resource_type == "server" else None),
            application=norm.application,
            service=norm.service,
            metric=norm.metric_name,
            metric_type="GAUGE",
            value=norm.value,
            unit=norm.unit,
            timestamp=norm.timestamp,
            status=norm.status,
            severity=norm.severity,
            source=norm.source,
            provider=norm.provider,
            labels=norm.labels,
            data_freshness_seconds=norm.data_freshness.age_seconds,
            freshness_status=norm.data_freshness.status
        )

    def extract_resources_from_metrics(
        self,
        metrics: List[NormalizedMetric],
        monitoring_source: str = "prometheus"
    ) -> List[NormalizedResource]:
        """
        Aggregates normalized metrics into distinct resource abstractions.
        """
        res_map: Dict[str, NormalizedResource] = {}

        for m in metrics:
            res_id = m.resource_id or f"res-{m.resource}"
            if res_id not in res_map:
                is_pg = (
                    "postgres" in res_id or
                    "pg" in res_id or
                    m.labels.get("technology") == "postgresql" or
                    m.provider == "PostgreSQLAdapter"
                )
                if is_pg:
                    tech = "postgresql"
                elif "sqlite" in res_id or "table" in res_id or m.labels.get("technology") == "sqlite":
                    tech = "sqlite"
                else:
                    tech = "generic"
                res_is_up = (m.status != "DOWN" and m.status != "CRITICAL")
                res_map[res_id] = NormalizedResource(
                    id=res_id,
                    name=m.resource,
                    type=m.resource_type,
                    technology=tech,
                    monitoring_source=monitoring_source,
                    status=m.status,
                    is_up=res_is_up,
                    environment_id=m.environment_id,
                    environment_name=m.environment,
                    labels=m.labels,
                    data_freshness=m.data_freshness,
                    metrics_summary={m.metric_name: m.value}
                )
            else:
                # Update status if more severe
                existing = res_map[res_id]
                existing.metrics_summary[m.metric_name] = m.value
                if m.status in ["CRITICAL", "DOWN"]:
                    existing.status = m.status
                    existing.is_up = False
                elif m.status == "WARNING" and existing.status == "HEALTHY":
                    existing.status = "WARNING"

        return list(res_map.values())


normalizer = MonitoringNormalizer()
