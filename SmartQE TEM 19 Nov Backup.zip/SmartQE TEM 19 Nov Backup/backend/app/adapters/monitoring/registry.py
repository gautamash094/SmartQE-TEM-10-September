import asyncio
from typing import Dict, List, Optional, Any
from app.core.config import settings
from app.adapters.monitoring.base import BaseMonitoringAdapter, ProviderHealth, UnifiedTarget
from app.adapters.monitoring.prometheus_adapter import PrometheusAdapter
from app.adapters.monitoring.postgres_adapter import PostgreSQLAdapter
from app.adapters.monitoring.application_adapter import ApplicationMonitoringAdapter
from app.adapters.monitoring.server_adapter import ServerMonitoringAdapter
from app.adapters.monitoring.custom_adapter import CustomMonitoringAdapter
from app.adapters.monitoring.datadog_adapter import DatadogMonitoringAdapter
from app.adapters.monitoring.nagios_adapter import NagiosMonitoringAdapter
from app.schemas.normalized_monitoring import NormalizedResource, DiscoveredMetric
from app.schemas.unified_monitoring import (
    MonitoringSourceHealth,
    UnifiedMetricSample,
    UnifiedHistoricalTelemetry
)


class MonitoringAdapterRegistry:
    """
    Central Dynamic Registry and Dispatcher for Monitoring Provider Adapters.
    Decouples SmartQE TEM from concrete monitoring tools and allows dynamic registration
    of new monitoring backends (Prometheus, Datadog, Nagios, OTel, PostgreSQL, Custom).
    """

    def __init__(self):
        self._adapters: Dict[str, BaseMonitoringAdapter] = {}
        self._register_default_adapters()

    def _register_default_adapters(self):
        """Initializes default enterprise monitoring adapters with externalized configuration."""
        prom_url = getattr(settings, "PROMETHEUS_URL", "http://localhost:9090")
        prom_timeout = getattr(settings, "PROMETHEUS_TIMEOUT", 5.0)
        self.register_adapter(PrometheusAdapter(base_url=prom_url, timeout=prom_timeout))
        if getattr(settings, "POSTGRES_ENABLED", True):
            self.register_adapter(PostgreSQLAdapter())
        self.register_adapter(ServerMonitoringAdapter(base_url=prom_url, timeout=prom_timeout))
        self.register_adapter(ApplicationMonitoringAdapter(base_url=prom_url, timeout=prom_timeout))

    def register_adapter(self, adapter: BaseMonitoringAdapter):
        """Registers a new monitoring provider adapter."""
        self._adapters[adapter.provider_id] = adapter

    def unregister_adapter(self, provider_id: str) -> Optional[BaseMonitoringAdapter]:
        """Removes a monitoring adapter from the registry."""
        return self._adapters.pop(provider_id, None)

    def get_adapter(self, provider_id: str) -> Optional[BaseMonitoringAdapter]:
        """Retrieves a registered adapter by provider ID."""
        return self._adapters.get(provider_id)

    def has_adapter(self, provider_id: str) -> bool:
        """Checks if an adapter is registered in memory."""
        return provider_id in self._adapters

    def list_adapters(self) -> List[BaseMonitoringAdapter]:
        """Lists all registered monitoring adapters."""
        return list(self._adapters.values())

    def get_adapters_by_capability(self, capability: str) -> List[BaseMonitoringAdapter]:
        """Returns all enabled adapters that support a given capability."""
        return [
            a for a in self._adapters.values()
            if getattr(a, "is_enabled", True) and (a.supports_capability(capability) if hasattr(a, "supports_capability") else True)
        ]

    async def get_all_sources_health(self) -> List[MonitoringSourceHealth]:
        """
        Polls health and liveness for all registered monitoring sources concurrently.
        CRITICAL ARCHITECTURAL PRINCIPLE:
        Monitoring source failures are isolated and distinguished from actual
        server, application, or database downtime.
        """
        async def fetch_one(adapter: BaseMonitoringAdapter) -> MonitoringSourceHealth:
            try:
                p_health = await asyncio.wait_for(adapter.get_health(), timeout=getattr(adapter, "timeout", 5.0) + 1.5)
                return adapter.to_source_health(p_health)
            except Exception as exc:
                return MonitoringSourceHealth(
                    source_id=adapter.provider_id,
                    source_name=adapter.provider_name,
                    adapter_name=adapter.__class__.__name__,
                    source_type=adapter.provider_type,
                    status="DOWN",
                    connectivity=False,
                    api_available=False,
                    latency_ms=0.0,
                    data_freshness_seconds=999.0,
                    error_message=f"Monitoring source unreachable: {str(exc)}"
                )

        adapters = [a for a in self._adapters.values() if getattr(a, "is_enabled", True)]
        tasks = [fetch_one(adapter) for adapter in adapters]
        results = await asyncio.gather(*tasks, return_exceptions=False)
        return list(results)

    async def get_all_targets(self, environment_id: Optional[str] = None) -> List[UnifiedTarget]:
        """Collects targets across all registered adapters concurrently."""
        async def fetch_targets(adapter: BaseMonitoringAdapter) -> List[UnifiedTarget]:
            if not getattr(adapter, "is_enabled", True):
                return []
            try:
                return await adapter.get_targets(environment_id)
            except Exception:
                return []

        tasks = [fetch_targets(adapter) for adapter in self._adapters.values()]
        results = await asyncio.gather(*tasks)
        targets: List[UnifiedTarget] = []
        for res in results:
            targets.extend(res)
        return targets

    async def get_all_resources(self, environment_id: Optional[str] = None) -> List[NormalizedResource]:
        """Collects normalized resources across all registered adapters concurrently with fast timeout."""
        async def fetch_one(adapter: BaseMonitoringAdapter) -> List[NormalizedResource]:
            if not getattr(adapter, "is_enabled", True):
                return []
            try:
                return await asyncio.wait_for(adapter.get_resources(environment_id), timeout=max(float(getattr(adapter, "timeout", 5.0)) + 5.0, 10.0))
            except Exception:
                return []

        adapters = [a for a in self._adapters.values() if getattr(a, "is_enabled", True)]
        results = await asyncio.gather(*(fetch_one(a) for a in adapters), return_exceptions=True)
        resources: List[NormalizedResource] = []
        for r in results:
            if isinstance(r, list):
                resources.extend(r)
        return resources

    async def get_all_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        target_type: Optional[str] = None
    ) -> List[UnifiedMetricSample]:
        """Aggregates unified metrics across all registered adapters concurrently with fast timeout."""
        async def fetch_one(adapter: BaseMonitoringAdapter) -> List[UnifiedMetricSample]:
            if not getattr(adapter, "is_enabled", True):
                return []
            try:
                return await asyncio.wait_for(adapter.get_metrics(environment_id, target_id=target_id), timeout=max(float(getattr(adapter, "timeout", 5.0)) + 5.0, 10.0))
            except Exception:
                return []

        adapters = [a for a in self._adapters.values() if getattr(a, "is_enabled", True)]
        results = await asyncio.gather(*(fetch_one(a) for a in adapters), return_exceptions=True)
        all_metrics: List[UnifiedMetricSample] = []
        for r in results:
            if isinstance(r, list):
                all_metrics.extend(r)
        return all_metrics

    async def discover_all_metrics(self) -> List[DiscoveredMetric]:
        """Discovers metrics available across all registered monitoring providers concurrently with fast timeout."""
        async def fetch_one(adapter: BaseMonitoringAdapter) -> List[DiscoveredMetric]:
            if not getattr(adapter, "is_enabled", True):
                return []
            try:
                return await asyncio.wait_for(adapter.discover_metrics(), timeout=max(float(getattr(adapter, "timeout", 5.0)) + 5.0, 10.0))
            except Exception:
                return []

        adapters = [a for a in self._adapters.values() if getattr(a, "is_enabled", True)]
        results = await asyncio.gather(*(fetch_one(a) for a in adapters), return_exceptions=True)
        all_discovered: List[DiscoveredMetric] = []
        seen = set()
        for r in results:
            if isinstance(r, list):
                for item in r:
                    if item.name not in seen:
                        seen.add(item.name)
                        all_discovered.append(item)
        return all_discovered

    async def get_historical_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        timeframe: str = "1h"
    ) -> UnifiedHistoricalTelemetry:
        """Retrieves historical metrics from appropriate adapter."""
        # 1. Check if an active dynamic adapter (e.g. Datadog or Prometheus) matches the target or environment
        if target_id:
            for adapter in self._adapters.values():
                if not getattr(adapter, "is_enabled", True):
                    continue
                # If target is owned by this adapter (e.g. starts with dd- or prom-)
                if target_id.startswith(f"{adapter.provider_id}-") or (adapter.provider_id == "datadog-prod" and "dd-" in target_id):
                    try:
                        res = await adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)
                        if res and res.series:
                            return res
                    except Exception:
                        pass

        # 2. PostgreSQL target specifically
        if target_id and "postgres" in target_id.lower():
            prom_adapter = self.get_adapter("prometheus-core")
            if prom_adapter:
                res = await prom_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)
                if res and res.series:
                    return res
            pg_adapter = self.get_adapter("postgres-core")
            if pg_adapter:
                return await pg_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        # 3. Database or SQLite target
        if target_id and ("database" in target_id.lower() or "sqlite" in target_id.lower() or "db" in target_id.lower()):
            prom_adapter = self.get_adapter("prometheus-core")
            if prom_adapter:
                return await prom_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        # 4. Application target
        is_app_target = target_id and (
            target_id.lower().startswith("app-")
            or "smartqe" in target_id.lower()
            or any(k in target_id.lower() for k in ["service", "app", "backend", "fastapi", "python", "web", "api"])
        ) and not target_id.lower().startswith("srv-") and not target_id.lower().startswith("server-")
        if is_app_target:
            app_adapter = self.get_adapter("app-monitor-apm")
            if app_adapter:
                return await app_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        # 5. Server target
        server_adapter = self.get_adapter("server-monitor-infra")
        is_server_target = target_id and any(k in target_id.lower() for k in ["server", "srv", "win", "node", "infra"]) and not target_id.lower().startswith("app-")
        if server_adapter and is_server_target:
            return await server_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        # 6. Default: Aggregate Prometheus metrics + Server metrics
        prom_adapter = self.get_adapter("prometheus-core")
        if prom_adapter:
            return await prom_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        return UnifiedHistoricalTelemetry(
            environment_id=environment_id,
            target_id=target_id,
            timeframe=timeframe,
            series={}
        )


adapter_registry = MonitoringAdapterRegistry()
