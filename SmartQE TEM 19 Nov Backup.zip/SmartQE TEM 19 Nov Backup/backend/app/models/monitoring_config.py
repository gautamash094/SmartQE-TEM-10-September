import enum
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from sqlalchemy import Column, String, Boolean, Integer, Float, DateTime, Text, JSON, Enum as SQLEnum
from app.database.base import Base, generate_uuid


class MonitoringToolType(str, enum.Enum):
    PROMETHEUS = "PROMETHEUS"
    DATADOG = "DATADOG"
    NAGIOS = "NAGIOS"
    OPENTELEMETRY = "OPENTELEMETRY"
    NEW_RELIC = "NEW_RELIC"
    DYNATRACE = "DYNATRACE"
    CLOUDWATCH = "CLOUDWATCH"
    CUSTOM = "CUSTOM"


class MonitoringAuthType(str, enum.Enum):
    NONE = "NONE"
    BASIC_AUTH = "BASIC_AUTH"
    BEARER_TOKEN = "BEARER_TOKEN"
    API_KEY = "API_KEY"
    OAUTH2 = "OAUTH2"
    CUSTOM_HEADERS = "CUSTOM_HEADERS"


class MonitoringCapability(str, enum.Enum):
    INFRASTRUCTURE = "INFRASTRUCTURE"
    SERVER = "SERVER"
    APPLICATION = "APPLICATION"
    DATABASE = "DATABASE"
    NETWORK = "NETWORK"
    ALERTS = "ALERTS"
    HISTORICAL_METRICS = "HISTORICAL_METRICS"
    CUSTOM_TELEMETRY = "CUSTOM_TELEMETRY"


class MonitoringToolConfig(Base):
    """
    Centralized Single Source of Truth for all monitoring integrations in SmartQE TEM.
    Supports multi-instance configurations (e.g., prod-prom-01, staging-prom-02, datadog-global).
    """
    __tablename__ = "monitoring_tool_configs"

    # Identity & Tool Definition
    tool_identifier = Column(String(64), unique=True, nullable=False, index=True)
    tool_type = Column(
        SQLEnum(MonitoringToolType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False,
        index=True
    )
    display_name = Column(String(128), nullable=False)
    description = Column(Text, nullable=True)
    is_enabled = Column(Boolean, default=True, nullable=False, index=True)

    # Network & Connectivity
    base_url = Column(String(512), nullable=False)
    tls_verify = Column(Boolean, default=True, nullable=False)
    ca_cert_path = Column(String(512), nullable=True)
    timeout_seconds = Column(Float, default=5.0, nullable=False)
    retry_count = Column(Integer, default=3, nullable=False)
    retry_backoff_factor = Column(Float, default=0.5, nullable=False)

    # Secure Authentication
    auth_type = Column(
        SQLEnum(MonitoringAuthType, values_callable=lambda obj: [e.value for e in obj]),
        default=MonitoringAuthType.NONE,
        nullable=False
    )
    # Encrypted payload containing sensitive credentials (API keys, passwords, bearer tokens)
    encrypted_credentials = Column(Text, nullable=True)
    # Non-sensitive custom headers (or references like "X-Env-Key: ${ENV_REF}")
    custom_headers = Column(JSON, default=dict, nullable=False)

    # Capabilities & Metrics Mapping
    capabilities = Column(JSON, default=list, nullable=False)
    metric_mappings = Column(JSON, default=dict, nullable=False)

    # Scope & Environment Assignment
    environment_scope = Column(JSON, default=lambda: ["ALL"], nullable=False)
    priority = Column(Integer, default=1, nullable=False)
    is_default_for_scope = Column(Boolean, default=False, nullable=False)

    # Polling & Scrape Schedules
    scrape_interval_seconds = Column(Integer, default=15, nullable=False)
    health_check_path = Column(String(256), default="/health", nullable=False)
    health_check_interval_seconds = Column(Integer, default=30, nullable=False)

    # Tool-Specific Parameter Extensions (e.g. Datadog site='datadoghq.com', Nagios livestatus path)
    tool_parameters = Column(JSON, default=dict, nullable=False)

    # Target Assignment Rules
    target_assignments = Column(JSON, default=dict, nullable=False)

    # Governance & Optimistic Locking
    version = Column(Integer, default=1, nullable=False)
    modified_by = Column(String(128), nullable=True)


class MonitoringConfigAuditLog(Base):
    """
    Immutable audit trail for monitoring tool configuration changes.
    Guarantees compliance and observability over who changed endpoints or credentials.
    """
    __tablename__ = "monitoring_config_audit_logs"

    config_id = Column(String(64), nullable=False, index=True)
    tool_identifier = Column(String(64), nullable=False, index=True)
    action = Column(String(32), nullable=False)  # CREATED, UPDATED, ENABLED, DISABLED, DELETED, TEST_CONNECTION
    changed_fields = Column(JSON, default=dict, nullable=False)
    performed_by = Column(String(128), default="system", nullable=False)
    ip_address = Column(String(64), nullable=True)
