import enum
from sqlalchemy import Column, String, Float, JSON, Enum as SQLEnum, ForeignKey, Boolean
from sqlalchemy.orm import relationship, foreign
from app.database.base import Base


class EnvironmentStatus(str, enum.Enum):
    HEALTHY = "HEALTHY"
    DOWN = "DOWN"
    DEGRADED = "DEGRADED"
    MAINTENANCE = "MAINTENANCE"


class EnvironmentTier(str, enum.Enum):
    DEV = "DEV"
    SIT = "SIT"
    UAT = "UAT"
    PRE_PROD = "PRE-PROD"
    PERF = "PERF"
    QA = "QA"


# NOTE: Legacy Environment and ComponentTopology database tables have been deprecated and removed.
# All system environments are now managed authoritatively via EnvironmentProfile ('environment_profiles').
Environment = None
ComponentTopology = None
