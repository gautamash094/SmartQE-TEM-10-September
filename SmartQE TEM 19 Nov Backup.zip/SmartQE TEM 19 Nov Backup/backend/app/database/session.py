import socket
from pathlib import Path
from typing import AsyncGenerator
from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from app.core.config import settings
from app.core.logging import logger

BASE_DIR = Path(__file__).resolve().parent.parent.parent
SQLITE_DB_PATH = BASE_DIR / "smartqe_tem.db"

sqlite_url = f"sqlite+aiosqlite:///{SQLITE_DB_PATH.as_posix()}"


def is_postgres_available() -> bool:
    try:
        host = settings.POSTGRES_SERVER or "localhost"
        port = settings.POSTGRES_PORT or 5432
        with socket.create_connection((host, port), timeout=0.15):
            return True
    except (OSError, Exception):
        return False


def _configure_engine_pragmas(eng):
    """Enables WAL mode and concurrency optimizations on SQLite engines."""
    if "sqlite" in str(eng.url):
        @event.listens_for(eng.sync_engine, "connect")
        def set_sqlite_pragma(dbapi_connection, connection_record):
            cursor = dbapi_connection.cursor()
            try:
                cursor.execute("PRAGMA journal_mode=WAL;")
                cursor.execute("PRAGMA synchronous=NORMAL;")
                cursor.execute("PRAGMA busy_timeout=10000;")
            except Exception:
                pass
            finally:
                cursor.close()


# Use PostgreSQL if available, otherwise immediately fallback to SQLite
if settings.DATABASE_URL and is_postgres_available():
    db_url = settings.DATABASE_URL
    connect_args = {}
else:
    logger.info(f"PostgreSQL on port {settings.POSTGRES_PORT} not reachable. Using local SQLite engine ({SQLITE_DB_PATH.name}).")
    db_url = sqlite_url
    connect_args = {"timeout": 20.0}

# Create primary engine
engine = create_async_engine(
    db_url,
    echo=False,
    future=True,
    connect_args=connect_args
)
_configure_engine_pragmas(engine)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)


def fallback_to_sqlite():
    global engine, AsyncSessionLocal
    logger.warning("Switching engine and AsyncSessionLocal to SQLite fallback (./smartqe_tem.db).")
    engine = create_async_engine(
        sqlite_url,
        echo=False,
        future=True,
        connect_args={"timeout": 20.0}
    )
    _configure_engine_pragmas(engine)
    AsyncSessionLocal.configure(bind=engine)
    return engine


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
