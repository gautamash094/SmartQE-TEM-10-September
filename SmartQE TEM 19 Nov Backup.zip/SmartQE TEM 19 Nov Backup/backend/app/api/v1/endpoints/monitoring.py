import time
import httpx
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query, Header, status
from fastapi.responses import PlainTextResponse
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.database.session import get_db
from app.schemas.common import StandardResponse
from app.schemas.monitoring import (
    FleetObservabilitySummary, EnvironmentDetailedObservability, HistoricalTelemetryOut,
    ThresholdRuleCreate, ThresholdRuleOut, MonitoringEventOut, RemediateEventRequest,
    MonitoringTargetCreate, MonitoringTargetOut, MonitoringExporterOut,
    CorrelatedIncidentOut, CorrelatedIncidentAcknowledgeRequest, CorrelatedIncidentResolveRequest,
    NotificationRuleCreate, NotificationRuleOut, CapacityForecastOut,
    TestExecutionCorrelationCreate, TestExecutionCorrelationOut, MonitoringSelfHealthOut,
    PrometheusTargetSD, PromQLInstantQueryRequest, PromQLRangeQueryRequest, PromQLQueryResponse,
    UnifiedMetricSample,
    ApplicationMonitoringDossier,
    ServerMonitoringDossier,
    AppServerTopologyMap,
    EnvironmentReadinessAssessment,
    MonitoringSourceHealth,
    TestCorrelationAnalysis,
    UnifiedHistoricalTelemetry
)
from app.schemas.normalized_monitoring import (
    NormalizedOverview,
    NormalizedResource,
    NormalizedMetric,
    DiscoveredMetric,
    DynamicMetricCatalog,
    OperationalMetricsSummary,
    Server,
    ServerMetric,
    ServerResource,
    ServerHealth,
    ServerThreshold,
    ServerThresholdCreate,
    ServerAlert,
    ServerAvailability
)
from app.services.threshold_rule_compiler import threshold_rule_compiler
from app.services.prometheus_target_compiler import prometheus_target_compiler
from app.adapters.monitoring.metrics import operational_metrics
from app.services.monitoring_service import monitoring_service
from app.services.health_check_service import health_check_service
from app.services.monitoring_config_service import monitoring_config_service
from app.schemas.monitoring_config import (
    MonitoringToolConfigCreate,
    MonitoringToolConfigUpdate,
    MonitoringToolConfigOut,
    ConnectionTestResult,
    MonitoringConfigToggleRequest,
    MonitoringConfigAuditLogOut
)
from app.dependencies.auth import get_current_user_optional
from app.models.user import User


router = APIRouter(prefix="/monitoring", tags=["Enterprise Environment Observability"])


@router.get("/summary", response_model=StandardResponse[FleetObservabilitySummary])
async def get_fleet_observability_summary(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves fleet-wide executive environment observability summary,
    including health scores, test readiness, drift counts, and operational KPIs.
    """
    summary = await monitoring_service.get_fleet_observability_summary(db)
    return StandardResponse(
        success=True,
        message="Fleet observability summary retrieved successfully",
        data=summary
    )


@router.get("/environments/{env_id}", response_model=StandardResponse[EnvironmentDetailedObservability])
async def get_environment_observability(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves granular environment observability dossier, covering multi-tier health,
    test readiness reasons, configuration drift, active release impact, and auto-heal status.
    """
    dossier = await monitoring_service.get_environment_detailed_observability(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Environment observability retrieved for '{dossier.environment_name}'",
        data=dossier
    )


@router.get("/environments/{env_id}/trends", response_model=StandardResponse[HistoricalTelemetryOut])
async def get_historical_telemetry_trends(
    env_id: str,
    timeframe: str = Query("24h", description="Timeframe: 1h, 6h, 24h, 7d, 30d"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves historical metrics telemetry and health score trends across 1h, 6h, 24h, 7d, 30d timeframes.
    """
    trends = await monitoring_service.get_historical_telemetry(db, env_id, timeframe)
    return StandardResponse(
        success=True,
        message=f"Historical telemetry trends for '{timeframe}' retrieved successfully",
        data=trends
    )


@router.get("/events", response_model=StandardResponse[List[MonitoringEventOut]])
async def list_monitoring_events(
    state: Optional[str] = Query(None, description="Filter by event state: NORMAL, WARNING, CRITICAL, RECOVERED"),
    severity: Optional[str] = Query(None, description="Filter by severity: CRITICAL, WARNING, INFO"),
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists real-time threshold and observability events with state machine transitions.
    """
    events = await monitoring_service.get_monitoring_events(db, state=state, severity=severity, limit=limit)
    data = [MonitoringEventOut.model_validate(e) for e in events]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} monitoring events",
        data=data
    )


@router.post("/events/{event_id}/acknowledge", response_model=StandardResponse[Optional[MonitoringEventOut]])
async def acknowledge_monitoring_event(
    event_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Acknowledges an active threshold alert event.
    """
    user_name = getattr(current_user, "username", "Ops Engineer") if current_user else "Ops Engineer"
    event = await monitoring_service.acknowledge_event(db, event_id, user_name)
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Monitoring event not found")

    return StandardResponse(
        success=True,
        message="Monitoring event acknowledged successfully",
        data=MonitoringEventOut.model_validate(event)
    )


@router.post("/events/{event_id}/remediate", response_model=StandardResponse[dict])
async def remediate_monitoring_event(
    event_id: str,
    payload: Optional[RemediateEventRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Triggers Auto-Heal remediation for the event and performs closed-loop validation.
    """
    user_name = getattr(current_user, "username", "Ops Lead") if current_user else "Ops Lead"
    success, msg = await monitoring_service.remediate_event(db, event_id, user_name)

    return StandardResponse(
        success=success,
        message=msg,
        data={"event_id": event_id, "status": "RECOVERED" if success else "REMEDIATION_FAILED"}
    )


@router.get("/threshold-rules", response_model=StandardResponse[List[ThresholdRuleOut]])
async def list_threshold_rules(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists all configured telemetry threshold rules.
    """
    rules = await monitoring_service.get_threshold_rules(db)
    data = [ThresholdRuleOut.model_validate(r) for r in rules]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} threshold rules",
        data=data
    )


@router.post("/threshold-rules", response_model=StandardResponse[ThresholdRuleOut], status_code=status.HTTP_201_CREATED)
async def create_threshold_rule(
    payload: ThresholdRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Creates a new metric threshold rule.
    """
    rule = await monitoring_service.create_threshold_rule(db, payload)
    return StandardResponse(
        success=True,
        message=f"Threshold rule '{rule.name}' created successfully",
        data=ThresholdRuleOut.model_validate(rule)
    )


@router.post("/environments/{env_id}/health-check", response_model=StandardResponse[EnvironmentDetailedObservability])
async def trigger_environment_health_and_refresh(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Triggers an on-demand synthetic health check run and returns the freshly updated observability dossier.
    """
    user_name = getattr(current_user, "username", "Ops Tester") if current_user else "Ops Tester"
    await health_check_service.execute_environment_health_check(
        db=db,
        environment_id=env_id,
        triggered_by=user_name,
        trigger_type="MANUAL",
        auto_heal_if_critical=True
    )
    dossier = await monitoring_service.get_environment_detailed_observability(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Health check executed and observability refreshed for '{dossier.environment_name}'",
        data=dossier
    )


# =========================================================================
# MONITORING TARGETS & EXPORTERS ENDPOINTS
# =========================================================================

@router.get("/targets", response_model=StandardResponse[List[MonitoringTargetOut]])
async def list_monitoring_targets(
    environment_id: Optional[str] = Query(None, description="Filter by environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists registered monitoring targets, their scrape health, and attached exporters."""
    targets = await monitoring_service.get_targets(db, environment_id=environment_id)
    data = [MonitoringTargetOut.model_validate(t) for t in targets]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} monitoring targets",
        data=data
    )


@router.post("/targets", response_model=StandardResponse[MonitoringTargetOut], status_code=status.HTTP_201_CREATED)
async def register_monitoring_target(
    payload: MonitoringTargetCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Registers a new monitoring target with initial exporter."""
    target = await monitoring_service.register_target(db, payload)
    try:
        await prometheus_target_compiler.sync_to_prometheus(db)
    except Exception as exc:
        pass
    return StandardResponse(
        success=True,
        message=f"Monitoring target '{target.name}' registered successfully",
        data=MonitoringTargetOut.model_validate(target)
    )


@router.delete("/targets/{target_id}", response_model=StandardResponse[dict])
async def delete_monitoring_target(
    target_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Deletes a monitoring target and attached exporters."""
    deleted = await monitoring_service.delete_target(db, target_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Target not found")
    try:
        await prometheus_target_compiler.sync_to_prometheus(db)
    except Exception as exc:
        pass
    return StandardResponse(
        success=True,
        message="Monitoring target deleted successfully",
        data={"target_id": target_id}
    )


@router.get("/exporters", response_model=StandardResponse[List[MonitoringExporterOut]])
async def list_monitoring_exporters(
    target_id: Optional[str] = Query(None, description="Filter by target ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists monitoring exporters with health status."""
    exporters = await monitoring_service.get_exporters(db, target_id=target_id)
    data = [MonitoringExporterOut.model_validate(e) for e in exporters]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} exporters",
        data=data
    )


# =========================================================================
# METRICS SCRAPING ENDPOINTS
# =========================================================================

@router.post("/scrape/execute", response_model=StandardResponse[dict])
async def execute_metrics_scrape(
    target_id: Optional[str] = Query(None, description="Specific target ID to scrape; omit to scrape all targets"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Executes on-demand pull-based metrics scrape with error isolation."""
    if target_id:
        success, msg, data = await monitoring_service.scrape_target(db, target_id)
        return StandardResponse(
            success=success,
            message=msg,
            data=data
        )
    else:
        summary = await monitoring_service.scrape_all_active_targets(db)
        return StandardResponse(
            success=True,
            message=f"Scraped {summary['scraped_count']} active targets ({summary['success_count']} succeeded)",
            data=summary
        )


# =========================================================================
# INTELLIGENT CORRELATED INCIDENTS ENDPOINTS
# =========================================================================

@router.get("/incidents", response_model=StandardResponse[List[CorrelatedIncidentOut]])
async def list_correlated_incidents(
    environment_id: Optional[str] = Query(None, description="Filter by environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists correlated multi-tier incidents with automated root-cause analysis."""
    incidents = await monitoring_service.get_correlated_incidents(db, environment_id=environment_id)
    data = [CorrelatedIncidentOut.model_validate(i) for i in incidents]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} correlated incidents",
        data=data
    )


@router.post("/incidents/{incident_id}/acknowledge", response_model=StandardResponse[CorrelatedIncidentOut])
async def acknowledge_correlated_incident(
    incident_id: str,
    payload: Optional[CorrelatedIncidentAcknowledgeRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Acknowledges an active correlated incident."""
    user_name = payload.user_name if payload else (getattr(current_user, "username", "Ops Engineer") if current_user else "Ops Engineer")
    inc = await monitoring_service.acknowledge_correlated_incident(db, incident_id, user_name)
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Correlated incident not found")
    return StandardResponse(
        success=True,
        message=f"Correlated incident '{inc.incident_code}' acknowledged",
        data=CorrelatedIncidentOut.model_validate(inc)
    )


@router.post("/incidents/{incident_id}/resolve", response_model=StandardResponse[CorrelatedIncidentOut])
async def resolve_correlated_incident(
    incident_id: str,
    payload: Optional[CorrelatedIncidentResolveRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Resolves a correlated incident and records resolution notes."""
    user_name = payload.user_name if payload else (getattr(current_user, "username", "Ops Lead") if current_user else "Ops Lead")
    notes = payload.resolution_notes if payload else ""
    inc = await monitoring_service.resolve_correlated_incident(db, incident_id, user_name, notes)
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Correlated incident not found")
    return StandardResponse(
        success=True,
        message=f"Correlated incident '{inc.incident_code}' resolved",
        data=CorrelatedIncidentOut.model_validate(inc)
    )


# =========================================================================
# NOTIFICATION RULES ENDPOINTS
# =========================================================================

@router.get("/notification-rules", response_model=StandardResponse[List[NotificationRuleOut]])
async def list_notification_rules(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists alert notification routing rules."""
    rules = await monitoring_service.get_notification_rules(db)
    data = [NotificationRuleOut.model_validate(r) for r in rules]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} notification rules",
        data=data
    )


@router.post("/notification-rules", response_model=StandardResponse[NotificationRuleOut], status_code=status.HTTP_201_CREATED)
async def create_notification_rule(
    payload: NotificationRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Creates a new alert notification routing rule."""
    rule = await monitoring_service.create_notification_rule(db, payload)
    return StandardResponse(
        success=True,
        message=f"Notification rule '{rule.name}' created",
        data=NotificationRuleOut.model_validate(rule)
    )


# =========================================================================
# CAPACITY FORECASTING ENDPOINTS
# =========================================================================

@router.get("/environments/{env_id}/capacity", response_model=StandardResponse[List[CapacityForecastOut]])
async def get_environment_capacity_forecast(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Retrieves growth trend models and days-to-breach forecasts for Disk, Memory, and DB Pools."""
    forecasts = await monitoring_service.get_capacity_forecast(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(forecasts)} capacity forecasts",
        data=forecasts
    )


# =========================================================================
# TEST EXECUTION CORRELATION ENDPOINTS
# =========================================================================

@router.get("/test-executions", response_model=StandardResponse[List[TestExecutionCorrelationOut]])
async def list_test_execution_correlations(
    environment_id: Optional[str] = Query(None, description="Filter by environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists test suite executions correlated with environment telemetry."""
    records = await monitoring_service.get_test_execution_correlations(db, env_id=environment_id)
    data = [TestExecutionCorrelationOut.model_validate(r) for r in records]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} test execution correlations",
        data=data
    )


@router.post("/test-executions/correlate", response_model=StandardResponse[TestExecutionCorrelationOut], status_code=status.HTTP_201_CREATED)
@router.post("/test-executions/webhook", response_model=StandardResponse[TestExecutionCorrelationOut], status_code=status.HTTP_201_CREATED)
async def record_test_execution_correlation(
    payload: TestExecutionCorrelationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Records a test suite execution and diagnoses whether test failures were environment-caused."""
    record = await monitoring_service.record_test_execution_correlation(db, payload)
    return StandardResponse(
        success=True,
        message=f"Test execution '{record.test_run_id}' correlated with environment telemetry",
        data=TestExecutionCorrelationOut.model_validate(record)
    )


@router.delete("/test-executions/{record_id}", response_model=StandardResponse[Dict[str, bool]])
async def delete_test_execution_correlation(
    record_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Deletes a test execution correlation record by ID or test_run_id."""
    deleted = await monitoring_service.delete_test_execution_correlation(db, record_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Test execution correlation not found")
    return StandardResponse(
        success=True,
        message="Test execution correlation record deleted",
        data={"deleted": True}
    )


# =========================================================================
# MONITORING SELF-HEALTH ENDPOINTS
# =========================================================================

@router.get("/self-health", response_model=StandardResponse[MonitoringSelfHealthOut])
async def get_monitoring_self_health(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Returns self-observability metrics of the monitoring platform itself."""
    health = await monitoring_service.get_self_health(db)
    return StandardResponse(
        success=True,
        message="Monitoring self-health retrieved successfully",
        data=health
    )


# =========================================================================
# PROMETHEUS SCRAPING, SD & PROMQL QUERY ENDPOINTS
# =========================================================================

@router.get("/prometheus/targets.json")
async def get_prometheus_http_service_discovery(
    db: AsyncSession = Depends(get_db)
):
    """
    Standard Prometheus HTTP Service Discovery endpoint (http_sd_config compatible).
    Enables external Prometheus servers to auto-discover all TEM test environments and exporter targets.
    """
    return await monitoring_service.get_prometheus_targets_sd(db)


@router.get("/prometheus/metrics", response_class=PlainTextResponse)
async def export_prometheus_metrics(
    db: AsyncSession = Depends(get_db)
):
    """
    Exposes TEM's own platform observability metrics in standard OpenMetrics/Prometheus exposition text format.
    Allows external Prometheus instances to scrape TEM fleet health, scraper duration, and active alert counters.
    """
    metrics_text = await monitoring_service.export_prometheus_metrics(db)
    return PlainTextResponse(content=metrics_text, media_type="text/plain; version=0.0.4; charset=utf-8")


@router.post("/prometheus/query", response_model=PromQLQueryResponse)
async def query_promql_instant(
    payload: PromQLInstantQueryRequest,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Evaluates instant PromQL expressions against live and historical time-series metrics.
    """
    return await monitoring_service.query_promql_instant(
        db, query=payload.query, time_val=payload.time, env_id=payload.environment_id
    )


@router.post("/prometheus/query_range", response_model=PromQLQueryResponse)
async def query_promql_range(
    payload: PromQLRangeQueryRequest,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Evaluates range PromQL expressions across a specified time window with step intervals.
    """
    import time
    start = payload.start or (time.time() - 3600.0)
    end = payload.end or time.time()
    step = payload.step or "15s"
    return await monitoring_service.query_promql_range(
        db, query=payload.query, start=start, end=end, step=step, env_id=payload.environment_id
    )


# =========================================================================
# UNIFIED MONITORING API ENDPOINTS (APACHE ECHARTS & IN-HOUSE DASHBOARDS)
# =========================================================================

@router.get("/sources", response_model=StandardResponse[List[MonitoringSourceHealth]])
async def list_monitoring_sources(
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves health, connectivity, and freshness of all registered monitoring sources (Prometheus, APM, Server Tools).
    Allows TEM to isolate and distinguish monitoring-source failures from actual application/server down events.
    """
    sources = await monitoring_service.get_monitoring_sources_health()
    return StandardResponse(
        success=True,
        message=f"Retrieved health status for {len(sources)} monitoring sources",
        data=sources
    )


@router.get("/unified/metrics", response_model=StandardResponse[List[UnifiedMetricSample]])
async def get_unified_metrics(
    environment_id: str = Query("env-01", description="Target environment ID"),
    target_type: Optional[str] = Query(None, description="Filter by target type: SERVER, APPLICATION, DATABASE, SERVICE"),
    target_id: Optional[str] = Query(None, description="Specific target ID"),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Exposes tool-independent normalized metrics conforming to the Unified Monitoring Model.
    Consumed by Apache ECharts visualization layer without tool-specific logic.
    """
    metrics = await monitoring_service.get_unified_metrics(
        environment_id=environment_id,
        target_type=target_type,
        target_id=target_id
    )
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(metrics)} unified metric samples",
        data=metrics
    )


@router.get("/applications", response_model=StandardResponse[List[ApplicationMonitoringDossier]])
async def list_applications_monitoring(
    environment_id: str = Query("env-01", description="Target environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists all monitored applications in the environment with availability, performance (latency, throughput, errors),
    runtime JVM/thread resources, downstream dependencies, and host server relationship.
    """
    apps = await monitoring_service.get_all_applications(environment_id=environment_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(apps)} monitored applications",
        data=apps
    )


@router.get("/applications/{app_id}", response_model=StandardResponse[ApplicationMonitoringDossier])
async def get_application_monitoring_dossier(
    app_id: str,
    environment_id: str = Query("env-01", description="Target environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves detailed application monitoring dossier for deep troubleshooting and dependency health inspection.
    """
    app = await monitoring_service.get_application_dossier(environment_id=environment_id, app_id=app_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Retrieved application monitoring dossier for '{app.name}'",
        data=app
    )


@router.get("/servers", response_model=StandardResponse[List[ServerMonitoringDossier]])
async def list_servers_monitoring(
    environment_id: str = Query("env-01", description="Target environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists all monitored Linux & Windows servers with CPU, Memory, Disk, Network, process count,
    and hosted applications list.
    """
    servers = await monitoring_service.get_all_servers(environment_id=environment_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(servers)} monitored servers",
        data=servers
    )


@router.get("/servers/{server_id}", response_model=StandardResponse[ServerMonitoringDossier])
async def get_server_monitoring_dossier(
    server_id: str,
    environment_id: str = Query("env-01", description="Target environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves detailed server monitoring dossier including process lists and hosted applications.
    """
    server = await monitoring_service.get_server_dossier(environment_id=environment_id, server_id=server_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Retrieved server monitoring dossier for '{server.name}'",
        data=server
    )


@router.get("/topology/app-server-map", response_model=StandardResponse[AppServerTopologyMap])
async def get_app_server_relationship_map(
    environment_id: str = Query("env-01", description="Target environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Exposes bidirectional application-to-server relationship mapping.
    Enables drill-down navigation from Application -> Host Server -> Server Metrics,
    and Server -> Hosted Applications -> Application Health.
    """
    top_map = await monitoring_service.get_app_server_relationship_map(environment_id=environment_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Retrieved application-to-server map ({top_map.total_servers} servers, {top_map.total_applications} applications)",
        data=top_map
    )


@router.get("/readiness/{env_id}", response_model=StandardResponse[EnvironmentReadinessAssessment])
async def evaluate_environment_readiness(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Evaluates whether the test environment is ready for test execution based on normalized telemetry:
    servers available, applications healthy, monitoring sources online, no blocking incidents, etc.
    """
    assessment = await monitoring_service.get_environment_readiness_assessment(environment_id=env_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Environment readiness evaluated: status={assessment.status} score={assessment.overall_readiness_score}%",
        data=assessment
    )


@router.get("/historical-unified", response_model=StandardResponse[UnifiedHistoricalTelemetry])
async def get_unified_historical_telemetry(
    environment_id: str = Query("env-01", description="Target environment ID"),
    target_id: Optional[str] = Query(None, description="Target entity ID"),
    timeframe: str = Query("1h", description="Timeframe: 15m, 1h, 6h, 24h, 7d, custom"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves normalized historical telemetry series optimized for direct Apache ECharts rendering.
    """
    data = await monitoring_service.get_unified_historical_telemetry(
        environment_id=environment_id,
        target_id=target_id,
        timeframe=timeframe,
        db=db
    )
    return StandardResponse(
        success=True,
        message=f"Historical telemetry for '{timeframe}' retrieved",
        data=data
    )


@router.get("/test-correlation-analysis/{test_run_id}", response_model=StandardResponse[TestCorrelationAnalysis])
async def get_test_execution_correlation_analysis(
    test_run_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Correlates test execution run with application and server telemetry to diagnose whether failures
    were caused by infrastructure resource saturation or genuine application defects.
    """
    analysis = await monitoring_service.get_test_correlation_analysis(test_run_id=test_run_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Test correlation analysis retrieved for '{test_run_id}'",
        data=analysis
    )


# =========================================================================
# NORMALIZED ENTERPRISE MONITORING INTEGRATION LAYER ENDPOINTS
# =========================================================================

@router.get("/overview", response_model=StandardResponse[NormalizedOverview])
async def get_monitoring_overview(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Normalized monitoring overview endpoint.
    Aggregates environment statuses, active alerts, targets, and data freshness
    derived strictly from live telemetry and database records.
    """
    operational_metrics.record_api_request("/overview", 200, 0.01)
    overview = await monitoring_service.get_monitoring_overview(db)
    return StandardResponse(
        success=True,
        message="Normalized monitoring overview retrieved successfully",
        data=overview
    )


@router.get("/providers", response_model=StandardResponse[List[MonitoringSourceHealth]])
async def list_monitoring_providers(
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists all registered monitoring adapters and their connectivity/health status.
    Decoupled from specific monitoring technologies.
    """
    operational_metrics.record_api_request("/providers", 200, 0.005)
    sources = await monitoring_service.get_monitoring_sources_health()
    return StandardResponse(
        success=True,
        message=f"Retrieved health status for {len(sources)} monitoring providers",
        data=sources
    )


@router.get("/resources", response_model=StandardResponse[List[NormalizedResource]])
async def list_normalized_resources(
    environment_id: Optional[str] = Query(None, description="Optional environment filter"),
    resource_type: Optional[str] = Query(None, description="Optional type filter (database, database_table, server, application)"),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Discovers and lists normalized resources (databases, tables, servers, applications).
    Provides stable identity and metadata independent of underlying monitoring provider.
    """
    operational_metrics.record_api_request("/resources", 200, 0.02)
    resources = await monitoring_service.get_normalized_resources(environment_id=environment_id)
    if resource_type:
        resources = [r for r in resources if r.type.lower() == resource_type.lower()]

    return StandardResponse(
        success=True,
        message=f"Discovered {len(resources)} normalized resources",
        data=resources
    )


@router.get("/resources/{resource_id}", response_model=StandardResponse[NormalizedResource])
async def get_normalized_resource(
    resource_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves detailed normalized resource by ID with current metrics summary.
    """
    operational_metrics.record_api_request(f"/resources/{resource_id}", 200, 0.01)
    resource = await monitoring_service.get_normalized_resource_by_id(resource_id)
    if not resource:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Normalized resource '{resource_id}' not found"
        )
    return StandardResponse(
        success=True,
        message=f"Retrieved normalized resource '{resource.name}'",
        data=resource
    )


@router.get("/metrics", response_model=StandardResponse[DynamicMetricCatalog])
async def list_discovered_metrics(
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Dynamically discovers and catalogs all metrics available from active monitoring sources.
    Avoids hardcoded metric names.
    """
    operational_metrics.record_api_request("/metrics", 200, 0.015)
    catalog = await monitoring_service.get_dynamic_metrics_catalog()
    return StandardResponse(
        success=True,
        message=f"Discovered {catalog.total_count} metrics across monitoring providers",
        data=catalog
    )


@router.get("/metrics/{name}", response_model=StandardResponse[List[UnifiedMetricSample]])
async def get_metric_samples(
    name: str,
    environment_id: str = Query("env-01", description="Target environment ID"),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves live metric samples by metric name across monitored resources.
    """
    operational_metrics.record_api_request(f"/metrics/{name}", 200, 0.02)
    metrics = await monitoring_service.get_unified_metrics(
        environment_id=environment_id,
        metric_names=[name]
    )
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(metrics)} samples for metric '{name}'",
        data=metrics
    )


@router.get("/timeseries", response_model=StandardResponse[UnifiedHistoricalTelemetry])
async def get_normalized_timeseries(
    resource_id: Optional[str] = Query(None, description="Resource or target ID"),
    environment_id: str = Query("env-01", description="Target environment ID"),
    timeframe: str = Query("1h", description="Timeframe: 15m, 1h, 6h, 24h, 7d, 30d"),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves normalized time-series data formatted for Apache ECharts.
    """
    operational_metrics.record_api_request("/timeseries", 200, 0.025)
    data = await monitoring_service.get_unified_historical_telemetry(
        environment_id=environment_id,
        target_id=resource_id,
        timeframe=timeframe
    )
    return StandardResponse(
        success=True,
        message=f"Historical telemetry for '{timeframe}' retrieved",
        data=data
    )


@router.get("/readiness", response_model=StandardResponse[List[EnvironmentReadinessAssessment]])
async def list_fleet_readiness(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Evaluates test environment readiness across all active environments.
    """
    operational_metrics.record_api_request("/readiness", 200, 0.03)
    assessments = []
    # Query all visible environments
    from app.models.environment_profile import EnvironmentProfile
    from sqlalchemy import select, or_
    res = await db.execute(
        select(EnvironmentProfile).where(
            or_(EnvironmentProfile.is_visible == True, EnvironmentProfile.is_visible.is_(None))
        )
    )
    profiles = list(res.scalars().all())
    for p in profiles:
        try:
            assessment = await monitoring_service.get_environment_readiness_assessment(
                environment_id=p.id, db=db
            )
            assessments.append(assessment)
        except Exception:
            continue

    return StandardResponse(
        success=True,
        message=f"Evaluated readiness for {len(assessments)} environments",
        data=assessments
    )


@router.get("/operational-metrics", response_model=StandardResponse[OperationalMetricsSummary])
async def get_integration_layer_operational_metrics(
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves operational self-telemetry of the Monitoring Integration Layer itself:
    API request counts, latencies, provider queries, error counts, and data freshness.
    """
    metrics_summary = monitoring_service.get_operational_metrics_summary()
    return StandardResponse(
        success=True,
        message="Monitoring integration layer operational metrics retrieved",
        data=metrics_summary
    )


@router.get("/operational-metrics/raw")
async def export_operational_metrics_raw():
    """
    Exposes operational metrics of the monitoring integration layer in OpenMetrics format.
    """
    text_content = operational_metrics.to_openmetrics_text()
    return PlainTextResponse(content=text_content, media_type="text/plain; version=0.0.4; charset=utf-8")


@router.get("/databases", response_model=StandardResponse[List[NormalizedResource]])
async def list_monitored_databases(
    environment_id: Optional[str] = Query(None, description="Optional environment filter"),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists all monitored databases (SQLite, PostgreSQL, MySQL) across environments.
    Provides database availability, connection utilization, storage footprint, and freshness.
    """
    start = time.perf_counter()
    databases = await monitoring_service.get_monitored_databases(environment_id=environment_id)
    operational_metrics.record_api_request("/databases", 200, time.perf_counter() - start)
    return StandardResponse(
        success=True,
        message=f"Discovered {len(databases)} monitored databases",
        data=databases
    )


@router.get("/postgres/metrics")
async def export_postgres_metrics_raw():
    """
    Exposes live PostgreSQL Prometheus exporter metrics in OpenMetrics exposition format.
    Allows Prometheus to scrape directly without requiring external daemon processes.
    """
    try:
        from monitoring.postgres_exporter import collector, get_metrics_text
        await collector.collect()
        text_content = get_metrics_text()
    except Exception as exc:
        text_content = f"# HELP pg_up PostgreSQL server availability\n# TYPE pg_up gauge\npg_up 0\n# PostgreSQL probe error: {str(exc)}\n"

    return PlainTextResponse(content=text_content, media_type="text/plain; version=0.0.4; charset=utf-8")


# =========================================================================
# NORMALIZED SERVER & THRESHOLD MONITORING API ENDPOINTS
# =========================================================================

@router.get("/normalized/servers", response_model=StandardResponse[List[Server]])
async def list_normalized_servers(
    environment_id: Optional[str] = Query(None, description="Optional environment filter"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Discovers and lists all monitored servers via Normalized Monitoring Layer.
    Returns provider-independent Server models with live status and freshness.
    """
    start = time.perf_counter()
    servers = await monitoring_service.get_normalized_servers(environment_id=environment_id, db=db)
    operational_metrics.record_api_request("/normalized/servers", 200, time.perf_counter() - start)
    return StandardResponse(
        success=True,
        message=f"Discovered {len(servers)} normalized servers",
        data=servers
    )


@router.get("/normalized/servers/{server_id}", response_model=StandardResponse[Server])
async def get_normalized_server(
    server_id: str,
    environment_id: Optional[str] = Query(None, description="Optional environment filter"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves a single server by ID as a normalized provider-independent Server model.
    """
    start = time.perf_counter()
    server = await monitoring_service.get_normalized_server(server_id=server_id, environment_id=environment_id, db=db)
    operational_metrics.record_api_request(f"/normalized/servers/{server_id}", 200, time.perf_counter() - start)
    if not server:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Normalized server '{server_id}' not found"
        )
    return StandardResponse(
        success=True,
        message=f"Retrieved server '{server.name}'",
        data=server
    )


@router.get("/normalized/servers/{server_id}/resources", response_model=StandardResponse[List[ServerResource]])
async def get_normalized_server_resources(
    server_id: str,
    environment_id: Optional[str] = Query(None, description="Optional environment filter"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Discovers all hardware and software sub-resources for a server:
    Logical cores, storage volumes (no hardcoded drive letters), network interfaces, services, processes.
    """
    start = time.perf_counter()
    resources = await monitoring_service.get_normalized_server_resources(server_id=server_id, environment_id=environment_id, db=db)
    operational_metrics.record_api_request(f"/normalized/servers/{server_id}/resources", 200, time.perf_counter() - start)
    return StandardResponse(
        success=True,
        message=f"Discovered {len(resources)} sub-resources for server '{server_id}'",
        data=resources
    )


@router.get("/normalized/servers/{server_id}/health", response_model=StandardResponse[ServerHealth])
async def get_normalized_server_health(
    server_id: str,
    environment_id: Optional[str] = Query(None, description="Optional environment filter"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Returns multi-dimensional health assessment (health score 0-100, dimension statuses, alert counts).
    """
    start = time.perf_counter()
    health = await monitoring_service.get_normalized_server_health(server_id=server_id, environment_id=environment_id, db=db)
    operational_metrics.record_api_request(f"/normalized/servers/{server_id}/health", 200, time.perf_counter() - start)
    return StandardResponse(
        success=True,
        message=f"Evaluated health for server '{server_id}' (Score: {health.health_score})",
        data=health
    )


@router.get("/normalized/servers/{server_id}/availability", response_model=StandardResponse[ServerAvailability])
async def get_normalized_server_availability(
    server_id: str,
    environment_id: Optional[str] = Query(None, description="Optional environment filter"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves server reachability, exporter availability, uptime, and reboot detection.
    """
    start = time.perf_counter()
    availability = await monitoring_service.get_normalized_server_availability(server_id=server_id, environment_id=environment_id, db=db)
    operational_metrics.record_api_request(f"/normalized/servers/{server_id}/availability", 200, time.perf_counter() - start)
    return StandardResponse(
        success=True,
        message=f"Retrieved availability for server '{server_id}'",
        data=availability
    )


@router.get("/normalized/servers/{server_id}/thresholds", response_model=StandardResponse[List[ServerThreshold]])
async def get_server_thresholds(
    server_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists configured threshold rules applicable to this server or fleet-wide.
    """
    rules = await monitoring_service.get_server_thresholds(server_id=server_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(rules)} threshold rules",
        data=rules
    )


@router.post("/normalized/servers/{server_id}/thresholds", response_model=StandardResponse[ServerThreshold])
async def create_or_update_server_threshold(
    server_id: str,
    payload: ServerThresholdCreate,
    rule_id: Optional[str] = Query(None, description="Optional rule ID to update"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Saves a threshold rule, compiles PromQL alert expressions, and hot-reloads Prometheus.
    """
    if not payload.server_id:
        payload.server_id = server_id
    saved = await monitoring_service.save_server_threshold(payload=payload, rule_id=rule_id, db=db)
    return StandardResponse(
        success=True,
        message=f"Threshold rule '{saved.name}' saved and synced to Prometheus successfully",
        data=saved
    )


@router.delete("/normalized/servers/{server_id}/thresholds/{rule_id}", response_model=StandardResponse[Dict[str, bool]])
async def delete_server_threshold(
    server_id: str,
    rule_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Deletes a threshold rule from database and syncs updated configuration to Prometheus.
    """
    deleted = await monitoring_service.delete_server_threshold(rule_id=rule_id, db=db)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Threshold rule '{rule_id}' not found")
    return StandardResponse(
        success=True,
        message=f"Threshold rule '{rule_id}' deleted and Prometheus reloaded",
        data={"deleted": True}
    )


@router.get("/normalized/servers/{server_id}/alerts", response_model=StandardResponse[List[ServerAlert]])
async def get_server_alerts(
    server_id: str,
    status_filter: Optional[str] = Query("ALL", alias="status", description="ALL, ACTIVE, or RESOLVED"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves active or historical alerts for a given server.
    """
    alerts = await monitoring_service.get_server_alerts(server_id=server_id, status=status_filter, db=db)
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(alerts)} alerts for server '{server_id}'",
        data=alerts
    )


@router.post("/normalized/alerts/{alert_id}/acknowledge", response_model=StandardResponse[ServerAlert])
async def acknowledge_server_alert(
    alert_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Acknowledges an active server alert.
    """
    user_name = current_user.username if current_user else "Admin"
    alert = await monitoring_service.acknowledge_server_alert(alert_id=alert_id, db=db, user_id=user_name)
    if not alert:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Alert '{alert_id}' not found")
    return StandardResponse(
        success=True,
        message=f"Alert '{alert_id}' acknowledged",
        data=alert
    )


@router.post("/normalized/alerts/{alert_id}/resolve", response_model=StandardResponse[ServerAlert])
async def resolve_server_alert(
    alert_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Manually marks an alert as resolved.
    """
    alert = await monitoring_service.resolve_server_alert(alert_id=alert_id, db=db)
    if not alert:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Alert '{alert_id}' not found")
    return StandardResponse(
        success=True,
        message=f"Alert '{alert_id}' resolved",
        data=alert
    )


@router.post("/alertmanager/webhook")
async def alertmanager_webhook(
    payload: Dict[str, Any],
    authorization: Optional[str] = Header(None),
    x_webhook_token: Optional[str] = Header(None, alias="X-Webhook-Token"),
    db: AsyncSession = Depends(get_db)
):
    """
    Webhook receiver for Prometheus Alertmanager notifications.
    Ingests firing and resolved alerts, deduplicates by fingerprint, and records to MonitoringEvent lifecycle.
    Enforces Bearer token / X-Webhook-Token authentication if ALERTMANAGER_WEBHOOK_SECRET is set.
    """
    if settings.ALERTMANAGER_WEBHOOK_SECRET:
        token = None
        if authorization:
            parts = authorization.split()
            if len(parts) == 2 and parts[0].lower() == "bearer":
                token = parts[1]
            elif len(parts) == 1:
                token = parts[0]
        elif x_webhook_token:
            token = x_webhook_token

        if not token or token != settings.ALERTMANAGER_WEBHOOK_SECRET:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Unauthorized Alertmanager webhook access: Invalid or missing bearer token"
            )

    result = await monitoring_service.handle_alertmanager_webhook(payload=payload, db=db)
    return {
        "status": "success",
        "processed": result.get("processed", 0),
        "total": result.get("total", 0)
    }


@router.post("/thresholds/sync-prometheus", response_model=StandardResponse[Dict[str, Any]])
async def sync_thresholds_to_prometheus(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Forces immediate re-compilation of all enabled threshold rules to PromQL alert_rules.yml
    and triggers Prometheus hot reload via the lifecycle API.
    """
    result = await threshold_rule_compiler.sync_to_prometheus(db)
    return StandardResponse(
        success=result["success"],
        message=f"Compiled {result['rules_count']} rules and synced to Prometheus ({result['reload_message']})",
        data=result
    )


@router.post("/targets/sync-prometheus", response_model=StandardResponse[Dict[str, Any]])
async def sync_targets_to_prometheus(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Forces immediate re-compilation of all active server inventory assets and environment
    targets into standard Prometheus scrape configs (prometheus.yml) and triggers hot reload.
    """
    result = await prometheus_target_compiler.sync_to_prometheus(db)
    return StandardResponse(
        success=result["success"],
        message=f"Compiled {result['targets_count']} targets across {result['jobs_count']} scrape jobs and synced to Prometheus ({result['reload_message']})",
        data=result
    )


@router.get("/probe", response_model=StandardResponse[Dict[str, Any]])
async def probe_service_endpoint(
    url: str = Query(..., description="Target service URL to probe")
):
    """
    Performs a real HTTP probe against any service endpoint and measures true roundtrip latency.
    """
    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=4.0, follow_redirects=True) as client:
            resp = await client.get(url)
            latency_ms = round((time.perf_counter() - t0) * 1000, 1)
            try:
                body = resp.json()
            except Exception:
                body = {"raw": resp.text[:500]}
                
            return StandardResponse(
                success=True,
                message=f"Probe to {url} completed with HTTP {resp.status_code}",
                data={
                    "url": url,
                    "is_up": resp.is_success,
                    "http_status": resp.status_code,
                    "latency_ms": latency_ms,
                    "payload": body,
                    "error": None
                }
            )
    except Exception as e:
        latency_ms = round((time.perf_counter() - t0) * 1000, 1)
        return StandardResponse(
            success=False,
            message=f"Probe to {url} failed: {str(e)}",
            data={
                "url": url,
                "is_up": False,
                "http_status": 0,
                "latency_ms": latency_ms,
                "payload": None,
                "error": str(e)
            }
        )


# =========================================================================
# CENTRALIZED MONITORING CONFIGURATION & INTEGRATION MANAGEMENT
# =========================================================================

@router.get("/integrations", response_model=StandardResponse[List[MonitoringToolConfigOut]])
async def list_monitoring_integrations(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves all centralized monitoring tool integrations with masked credentials.
    Single Source of Truth for all monitoring tools in SmartQE TEM.
    """
    configs = await monitoring_config_service.list_configs(db)
    if not configs:
        # Bootstrap if database was just initialized
        await monitoring_config_service.bootstrap_default_configs(db)
        configs = await monitoring_config_service.list_configs(db)

    results = []
    for c in configs:
        creds = monitoring_config_service.decrypt_credentials(c.encrypted_credentials)
        masked = monitoring_config_service.mask_credentials(creds)
        
        # Build schema output
        out = MonitoringToolConfigOut(
            id=c.id,
            tool_identifier=c.tool_identifier,
            tool_type=c.tool_type,
            display_name=c.display_name,
            description=c.description,
            is_enabled=c.is_enabled,
            base_url=c.base_url,
            tls_verify=c.tls_verify,
            ca_cert_path=c.ca_cert_path,
            timeout_seconds=c.timeout_seconds,
            retry_count=c.retry_count,
            retry_backoff_factor=c.retry_backoff_factor,
            auth_type=c.auth_type,
            custom_headers=c.custom_headers or {},
            capabilities=c.capabilities or [],
            metric_mappings=c.metric_mappings or {},
            environment_scope=c.environment_scope or ["ALL"],
            priority=c.priority,
            is_default_for_scope=c.is_default_for_scope,
            scrape_interval_seconds=c.scrape_interval_seconds,
            health_check_path=c.health_check_path,
            health_check_interval_seconds=c.health_check_interval_seconds,
            tool_parameters=c.tool_parameters or {},
            target_assignments=c.target_assignments or {},
            masked_credentials=masked,
            version=c.version,
            modified_by=c.modified_by,
            created_at=c.created_at,
            updated_at=c.updated_at
        )
        results.append(out)

    return StandardResponse(
        success=True,
        message=f"Retrieved {len(results)} centralized monitoring tool configurations",
        data=results
    )


@router.post("/integrations", response_model=StandardResponse[MonitoringToolConfigOut], status_code=status.HTTP_201_CREATED)
async def register_monitoring_integration(
    payload: MonitoringToolConfigCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Registers a new monitoring platform into the Centralized Configuration Layer.
    Requires no code modification or backend restart.
    """
    user_id = current_user.username if current_user else "admin"
    raw_payload = payload.model_dump()
    raw_credentials = raw_payload.pop("credentials", None)

    # Check for existing identifier
    existing = await monitoring_config_service.get_config_by_identifier(db, payload.tool_identifier)
    if existing:
        raise HTTPException(status_code=400, detail=f"Monitoring tool '{payload.tool_identifier}' already exists")

    config = await monitoring_config_service.create_or_register_tool(
        db=db,
        payload=raw_payload,
        raw_credentials=raw_credentials,
        performed_by=user_id
    )

    creds = monitoring_config_service.decrypt_credentials(config.encrypted_credentials)
    out = MonitoringToolConfigOut(
        id=config.id,
        tool_identifier=config.tool_identifier,
        tool_type=config.tool_type,
        display_name=config.display_name,
        description=config.description,
        is_enabled=config.is_enabled,
        base_url=config.base_url,
        tls_verify=config.tls_verify,
        ca_cert_path=config.ca_cert_path,
        timeout_seconds=config.timeout_seconds,
        retry_count=config.retry_count,
        retry_backoff_factor=config.retry_backoff_factor,
        auth_type=config.auth_type,
        custom_headers=config.custom_headers or {},
        capabilities=config.capabilities or [],
        metric_mappings=config.metric_mappings or {},
        environment_scope=config.environment_scope or ["ALL"],
        priority=config.priority,
        is_default_for_scope=config.is_default_for_scope,
        scrape_interval_seconds=config.scrape_interval_seconds,
        health_check_path=config.health_check_path,
        health_check_interval_seconds=config.health_check_interval_seconds,
        tool_parameters=config.tool_parameters or {},
        target_assignments=config.target_assignments or {},
        masked_credentials=monitoring_config_service.mask_credentials(creds),
        version=config.version,
        modified_by=config.modified_by,
        created_at=config.created_at,
        updated_at=config.updated_at
    )
    return StandardResponse(
        success=True,
        message=f"Monitoring integration '{config.tool_identifier}' registered and hot-loaded",
        data=out
    )


@router.get("/integrations/{tool_identifier}", response_model=StandardResponse[MonitoringToolConfigOut])
async def get_monitoring_integration(
    tool_identifier: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Retrieves a specific monitoring tool configuration."""
    config = await monitoring_config_service.get_config_by_identifier(db, tool_identifier)
    if not config:
        raise HTTPException(status_code=404, detail="Monitoring integration not found")

    creds = monitoring_config_service.decrypt_credentials(config.encrypted_credentials)
    out = MonitoringToolConfigOut(
        id=config.id,
        tool_identifier=config.tool_identifier,
        tool_type=config.tool_type,
        display_name=config.display_name,
        description=config.description,
        is_enabled=config.is_enabled,
        base_url=config.base_url,
        tls_verify=config.tls_verify,
        ca_cert_path=config.ca_cert_path,
        timeout_seconds=config.timeout_seconds,
        retry_count=config.retry_count,
        retry_backoff_factor=config.retry_backoff_factor,
        auth_type=config.auth_type,
        custom_headers=config.custom_headers or {},
        capabilities=config.capabilities or [],
        metric_mappings=config.metric_mappings or {},
        environment_scope=config.environment_scope or ["ALL"],
        priority=config.priority,
        is_default_for_scope=config.is_default_for_scope,
        scrape_interval_seconds=config.scrape_interval_seconds,
        health_check_path=config.health_check_path,
        health_check_interval_seconds=config.health_check_interval_seconds,
        tool_parameters=config.tool_parameters or {},
        target_assignments=config.target_assignments or {},
        masked_credentials=monitoring_config_service.mask_credentials(creds),
        version=config.version,
        modified_by=config.modified_by,
        created_at=config.created_at,
        updated_at=config.updated_at
    )
    return StandardResponse(
        success=True,
        message=f"Retrieved configuration for '{config.tool_identifier}'",
        data=out
    )


@router.put("/integrations/{tool_identifier}", response_model=StandardResponse[MonitoringToolConfigOut])
async def update_monitoring_integration(
    tool_identifier: str,
    payload: MonitoringToolConfigUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Updates an existing monitoring configuration and hot-reloads it in memory."""
    user_id = current_user.username if current_user else "admin"
    raw_payload = payload.model_dump(exclude_unset=True)
    raw_credentials = raw_payload.pop("credentials", None)

    updated = await monitoring_config_service.update_tool(
        db=db,
        tool_identifier=tool_identifier,
        payload=raw_payload,
        raw_credentials=raw_credentials,
        performed_by=user_id
    )
    if not updated:
        raise HTTPException(status_code=404, detail="Monitoring integration not found")

    creds = monitoring_config_service.decrypt_credentials(updated.encrypted_credentials)
    out = MonitoringToolConfigOut(
        id=updated.id,
        tool_identifier=updated.tool_identifier,
        tool_type=updated.tool_type,
        display_name=updated.display_name,
        description=updated.description,
        is_enabled=updated.is_enabled,
        base_url=updated.base_url,
        tls_verify=updated.tls_verify,
        ca_cert_path=updated.ca_cert_path,
        timeout_seconds=updated.timeout_seconds,
        retry_count=updated.retry_count,
        retry_backoff_factor=updated.retry_backoff_factor,
        auth_type=updated.auth_type,
        custom_headers=updated.custom_headers or {},
        capabilities=updated.capabilities or [],
        metric_mappings=updated.metric_mappings or {},
        environment_scope=updated.environment_scope or ["ALL"],
        priority=updated.priority,
        is_default_for_scope=updated.is_default_for_scope,
        scrape_interval_seconds=updated.scrape_interval_seconds,
        health_check_path=updated.health_check_path,
        health_check_interval_seconds=updated.health_check_interval_seconds,
        tool_parameters=updated.tool_parameters or {},
        target_assignments=updated.target_assignments or {},
        masked_credentials=monitoring_config_service.mask_credentials(creds),
        version=updated.version,
        modified_by=updated.modified_by,
        created_at=updated.created_at,
        updated_at=updated.updated_at
    )
    return StandardResponse(
        success=True,
        message=f"Monitoring integration '{tool_identifier}' updated and hot-reloaded",
        data=out
    )


@router.delete("/integrations/{tool_identifier}", response_model=StandardResponse[Dict[str, bool]])
async def delete_monitoring_integration(
    tool_identifier: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Deletes a monitoring integration from centralized configuration."""
    user_id = current_user.username if current_user else "admin"
    deleted = await monitoring_config_service.delete_tool(db, tool_identifier, performed_by=user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Monitoring integration not found")

    return StandardResponse(
        success=True,
        message=f"Monitoring integration '{tool_identifier}' deleted successfully",
        data={"deleted": True}
    )


@router.patch("/integrations/{tool_identifier}/toggle", response_model=StandardResponse[Dict[str, Any]])
async def toggle_monitoring_integration(
    tool_identifier: str,
    payload: MonitoringConfigToggleRequest,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Dynamically activates or deactivates a monitoring tool instance."""
    user_id = current_user.username if current_user else "admin"
    updated = await monitoring_config_service.toggle_tool_state(
        db=db,
        tool_identifier=tool_identifier,
        is_enabled=payload.is_enabled,
        performed_by=user_id
    )
    if not updated:
        raise HTTPException(status_code=404, detail="Monitoring integration not found")

    return StandardResponse(
        success=True,
        message=f"Monitoring tool '{tool_identifier}' is now {'ENABLED' if updated.is_enabled else 'DISABLED'}",
        data={"tool_identifier": updated.tool_identifier, "is_enabled": updated.is_enabled}
    )


@router.post("/integrations/{tool_identifier}/test-connection", response_model=StandardResponse[ConnectionTestResult])
async def test_monitoring_integration_connection(
    tool_identifier: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Probes endpoint connectivity, credentials, and API latency for a configured tool."""
    res = await monitoring_config_service.test_tool_connection(db, tool_identifier)
    return StandardResponse(
        success=res.success,
        message=res.message,
        data=res
    )


@router.post("/integrations/test-probe", response_model=StandardResponse[ConnectionTestResult])
async def test_transient_monitoring_probe(
    payload: MonitoringToolConfigCreate,
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Pre-flight verification of credentials and endpoint before saving configuration."""
    raw = payload.model_dump()
    creds = raw.pop("credentials", None)
    res = await monitoring_config_service.test_transient_connection(raw, raw_credentials=creds)
    return StandardResponse(
        success=res.success,
        message=res.message,
        data=res
    )


@router.get("/integrations/{tool_identifier}/audit-logs", response_model=StandardResponse[List[MonitoringConfigAuditLogOut]])
async def get_integration_audit_logs(
    tool_identifier: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Retrieves immutable audit logs for a specific monitoring configuration."""
    logs = await monitoring_config_service.list_audit_logs(db, tool_identifier=tool_identifier)
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(logs)} audit logs for '{tool_identifier}'",
        data=[MonitoringConfigAuditLogOut.model_validate(l) for l in logs]
    )




