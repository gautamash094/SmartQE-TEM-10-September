import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError

from app.core.config import settings
from app.core.exceptions import (
    AppException, app_exception_handler,
    validation_exception_handler, unhandled_exception_handler
)
from app.database.base import Base
from app.database.session import engine, fallback_to_sqlite, AsyncSessionLocal
from app.api.v1.router import api_router
from app.utils.seed_data import seed_initial_data
from app.core.logging import logger
import app.models.user
import app.models.role
import app.models.setting
import app.models.portfolio
import app.models.environment_profile
import app.models.reservation
import app.models.test_phase
import app.models.release
import app.models.incident
import app.models.runbook
import app.models.asset
import app.models.topology
import app.models.access
import app.models.auth_audit
import app.models.session
import app.models.user_group
import app.models.workflow
import app.models.email_notification
import app.models.provisioning
import app.models.health_check
import app.models.environment_software
import app.models.monitoring
import app.models.monitoring_config



def sync_sqlite_columns(sync_conn):
    from sqlalchemy import inspect, text
    inspector = inspect(sync_conn)
    existing_tables = set(inspector.get_table_names())
    for table_name, table in Base.metadata.tables.items():
        if table_name in existing_tables:
            existing_columns = {col['name'] for col in inspector.get_columns(table_name)}
            for column in table.columns:
                if column.name not in existing_columns:
                    col_type = column.type.compile(dialect=sync_conn.dialect)
                    sql = f"ALTER TABLE {table_name} ADD COLUMN {column.name} {col_type}"
                    logger.info(f"SQLite Schema Sync: Executing '{sql}'")
                    sync_conn.execute(text(sql))


from app.services.reminder_scheduler import reminder_scheduler
from app.services.monitoring_scheduler import monitoring_scheduler
from app.services.monitoring_config_service import monitoring_config_service
from app.core.instrumentation import setup_instrumentation


@asynccontextmanager
async def lifespan(app: FastAPI):
    if os.environ.get("TESTING") == "1":
        yield
        return
    logger.info("Initializing SmartQE TEM CONTROL FastAPI Microservice...")
    active_engine = engine

    # Attempt connecting to primary database (PostgreSQL)
    try:
        async with active_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    except Exception as e:
        logger.warning(f"Could not connect to primary database on port 5432 ({str(e)}). Switching to local SQLite engine...")
        active_engine = fallback_to_sqlite()
        async with active_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
            await conn.run_sync(sync_sqlite_columns)

    # Seed initial datasets using updated sessionmaker
    async with AsyncSessionLocal() as session:
        await seed_initial_data(session)
        try:
            await monitoring_config_service.sync_all_adapters_from_db(session)
        except Exception as exc:
            logger.warning(f"Error syncing monitoring adapters on startup: {exc}")

    # Start the automated 1-hour booking reminder background worker
    reminder_scheduler.start()

    # Start the automated enterprise monitoring & health check scheduler
    monitoring_scheduler.start()

    logger.info("Database schema verified and initial mock data seeded successfully.")
    yield
    logger.info("Shutting down SmartQE TEM CONTROL API...")
    reminder_scheduler.stop()
    monitoring_scheduler.stop()


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Production-Ready Test Environment Management (TEM) System Microservice API backed by PostgreSQL and Async SQLAlchemy 2.x DAO Pattern.",
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url=f"{settings.API_V1_STR}/docs",
    redoc_url=f"{settings.API_V1_STR}/redoc",
    lifespan=lifespan
)

# Exception Handlers
app.add_exception_handler(AppException, app_exception_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)
app.add_exception_handler(Exception, unhandled_exception_handler)

import asyncio
import os
import psutil
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import Depends
from starlette.responses import Response
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from app.database.session import get_db

# Enterprise Application Performance Monitoring (Prometheus Instrumentation)
setup_instrumentation(app)

# Configure CORS Middleware (Registered outermost to handle preflight OPTIONS immediately)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API v1 Router
app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/")
async def root():
    return {
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "docs": f"{settings.API_V1_STR}/docs",
        "status": "OPERATIONAL"
    }


# -------------------------------------------------------------------------
# Spring Boot Actuator Compatibility Aliases for Enterprise Observability
# -------------------------------------------------------------------------

@app.get("/actuator/health", tags=["Actuator Aliases"])
async def actuator_health(db: AsyncSession = Depends(get_db)):
    """
    Spring Boot Actuator health endpoint alias returning live component status,
    database connectivity, disk space, and process runtime telemetry.
    """
    db_status = "UP"
    db_details: dict = {"database": "SQLite / PostgreSQL"}
    try:
        await asyncio.wait_for(db.execute(text("SELECT 1")), timeout=1.5)
        db_details["connection"] = "ACTIVE"
    except Exception as e:
        db_status = "DOWN"
        db_details["error"] = str(e)
        db_details["error"] = str(e)

    disk_status = "UP"
    disk_details: dict = {}
    try:
        usage = psutil.disk_usage(os.getcwd())
        disk_details = {
            "total_gb": round(usage.total / (1024 ** 3), 2),
            "free_gb": round(usage.free / (1024 ** 3), 2),
            "used_gb": round(usage.used / (1024 ** 3), 2),
            "percent_used": usage.percent
        }
        if usage.percent > 95:
            disk_status = "DOWN"
    except Exception:
        pass

    process_status = "UP"
    process_details: dict = {}
    try:
        proc = psutil.Process(os.getpid())
        mem = proc.memory_info()
        process_details = {
            "rss_mb": round(mem.rss / (1024 ** 2), 2),
            "cpu_percent": round(proc.cpu_percent(interval=None), 1),
            "num_threads": proc.num_threads(),
            "open_handles": proc.num_handles() if hasattr(proc, "num_handles") else (proc.num_fds() if hasattr(proc, "num_fds") else 0)
        }
    except Exception:
        pass

    overall_status = "UP" if db_status == "UP" and disk_status == "UP" else "DEGRADED"

    return {
        "status": overall_status,
        "service": settings.PROJECT_NAME,
        "framework": "FastAPI",
        "runtime": "Python",
        "version": settings.VERSION,
        "components": {
            "db": {
                "status": db_status,
                "details": db_details
            },
            "diskSpace": {
                "status": disk_status,
                "details": disk_details
            },
            "ping": {
                "status": "UP"
            },
            "process": {
                "status": process_status,
                "details": process_details
            }
        }
    }


@app.get("/actuator/prometheus", tags=["Actuator Aliases"], include_in_schema=False)
async def actuator_prometheus():
    """Spring Boot Actuator prometheus exposition endpoint alias."""
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)


@app.get("/actuator", tags=["Actuator Aliases"])
async def actuator_index():
    """Spring Boot Actuator discovery index."""
    return {
        "_links": {
            "self": {"href": "/actuator"},
            "health": {"href": "/actuator/health"},
            "prometheus": {"href": "/actuator/prometheus"}
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
