import time
import os
import psutil
from typing import Optional, Callable
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Match
from fastapi import FastAPI
from prometheus_client import (
    Counter,
    Gauge,
    Histogram,
    REGISTRY,
    generate_latest,
    CONTENT_TYPE_LATEST
)
from prometheus_client.core import GaugeMetricFamily, CounterMetricFamily

from app.core.config import settings
from app.core.logging import logger

APP_NAME = getattr(settings, "APPLICATION_NAME", "smartqe-tem-backend")

# Default histogram latency buckets (seconds)
LATENCY_BUCKETS = (
    0.005, 0.01, 0.025, 0.05, 0.075, 0.1, 0.25, 0.5, 0.75, 1.0, 2.5, 5.0, 7.5, 10.0
)

# -------------------------------------------------------------------------
# Safe Metric Registration (Handles Uvicorn Hot-Reloading cleanly)
# -------------------------------------------------------------------------

def _get_or_create_metric(metric_type, name, documentation, *args, **kwargs):
    """Safely retrieves existing registered metric or creates new one without throwing ValueError."""
    for collector in list(REGISTRY._names_to_collectors.values()):
        if hasattr(collector, "_name") and collector._name == name:
            return collector
    return metric_type(name, documentation, *args, **kwargs)


HTTP_REQUESTS_TOTAL = _get_or_create_metric(
    Counter,
    "http_requests_total",
    "Total HTTP requests processed by application",
    ["method", "handler", "status", "app"]
)

HTTP_REQUEST_DURATION_SECONDS = _get_or_create_metric(
    Histogram,
    "http_request_duration_seconds",
    "HTTP request execution duration in seconds",
    ["method", "handler", "app"],
    buckets=LATENCY_BUCKETS
)

HTTP_REQUESTS_IN_PROGRESS = _get_or_create_metric(
    Gauge,
    "http_requests_in_progress",
    "Active HTTP requests currently being processed",
    ["method", "app"]
)

HTTP_EXCEPTIONS_TOTAL = _get_or_create_metric(
    Counter,
    "http_exceptions_total",
    "Total unhandled HTTP exceptions raised during request processing",
    ["exception_type", "app"]
)


# -------------------------------------------------------------------------
# Custom Collector for Process & Runtime Telemetry
# -------------------------------------------------------------------------

class AppProcessCollector:
    """
    Dynamically collects real-time process CPU, memory, thread, handle,
    and application uptime metrics on demand using psutil.
    Works seamlessly across Windows, Linux, and macOS.
    """

    def __init__(self, app_name: str = APP_NAME):
        self.app_name = app_name
        self.process = psutil.Process(os.getpid())
        self.start_time = time.time()
        # Seed cpu_percent initial call
        try:
            self.process.cpu_percent(interval=None)
        except Exception:
            pass

    def collect(self):
        uptime = round(time.time() - self.start_time, 2)
        yield GaugeMetricFamily(
            "app_uptime_seconds",
            "Total application uptime in seconds",
            value=uptime
        )
        yield GaugeMetricFamily(
            "app_health_status",
            "Application health status (1.0 = healthy/ready, 0.0 = degraded)",
            value=1.0
        )

        try:
            mem = self.process.memory_info()
            yield GaugeMetricFamily(
                "process_resident_memory_bytes",
                "Resident memory size (RSS) in bytes",
                value=float(mem.rss)
            )
            yield GaugeMetricFamily(
                "process_virtual_memory_bytes",
                "Virtual memory size (VMS) in bytes",
                value=float(mem.vms)
            )

            cpu_times = self.process.cpu_times()
            yield CounterMetricFamily(
                "process_cpu_seconds_total",
                "Total user and system CPU time spent in seconds",
                value=float(cpu_times.user + cpu_times.system)
            )
            yield GaugeMetricFamily(
                "process_cpu_percent",
                "Current process CPU utilization percentage (0-100%)",
                value=float(self.process.cpu_percent(interval=None))
            )

            threads = self.process.num_threads()
            yield GaugeMetricFamily(
                "process_threads_total",
                "Number of OS threads currently in process",
                value=float(threads)
            )

            # Open file handles on Windows / FDs on Unix
            if hasattr(self.process, "num_handles"):
                yield GaugeMetricFamily(
                    "process_open_fds",
                    "Number of open file handles/descriptors",
                    value=float(self.process.num_handles())
                )
            elif hasattr(self.process, "num_fds"):
                yield GaugeMetricFamily(
                    "process_open_fds",
                    "Number of open file descriptors",
                    value=float(self.process.num_fds())
                )
        except Exception as exc:
            logger.debug(f"Error querying process stats in AppProcessCollector: {exc}")


_collector_registered = False

def _register_collector():
    global _collector_registered
    if not _collector_registered:
        # Check if already registered
        for collector in list(getattr(REGISTRY, "_collector_to_names", {}).keys()):
            if isinstance(collector, AppProcessCollector):
                _collector_registered = True
                return
        try:
            REGISTRY.register(AppProcessCollector(app_name=APP_NAME))
            _collector_registered = True
        except Exception as exc:
            logger.debug(f"Collector already registered or registration failed: {exc}")


# -------------------------------------------------------------------------
# Request Normalization Helper
# -------------------------------------------------------------------------

def _resolve_handler_path(request: Request) -> str:
    """Extracts normalized route path (e.g., /api/v1/monitoring/applications/{app_id})."""
    try:
        if "route" in request.scope and request.scope["route"]:
            return getattr(request.scope["route"], "path", request.url.path)
        
        target_app = getattr(request, "app", None)
        if target_app and hasattr(target_app, "routes"):
            for route in target_app.routes:
                match, _ = route.matches(request.scope)
                if match == Match.FULL:
                    return getattr(route, "path", request.url.path)
    except Exception:
        pass
    
    return request.url.path


# -------------------------------------------------------------------------
# Prometheus HTTP Middleware
# -------------------------------------------------------------------------

class PrometheusMetricsMiddleware(BaseHTTPMiddleware):
    """
    Middleware that records live HTTP request metrics:
    counts, durations, active in-flight requests, and unhandled exceptions.
    """

    def __init__(self, app, app_name: str = APP_NAME):
        super().__init__(app)
        self.app_name = app_name

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Avoid scrape loop feedback on /metrics and pass CORS preflight OPTIONS requests directly
        if request.url.path == "/metrics" or request.method == "OPTIONS":
            return await call_next(request)

        method = request.method
        HTTP_REQUESTS_IN_PROGRESS.labels(method=method, app=self.app_name).inc()
        start_time = time.perf_counter()

        status_code = 500
        try:
            response = await call_next(request)
            status_code = response.status_code
            return response
        except Exception as exc:
            HTTP_EXCEPTIONS_TOTAL.labels(
                exception_type=type(exc).__name__,
                app=self.app_name
            ).inc()
            raise
        finally:
            try:
                duration = max(time.perf_counter() - start_time, 0.0)
                HTTP_REQUESTS_IN_PROGRESS.labels(method=method, app=self.app_name).dec()

                handler = _resolve_handler_path(request)
                HTTP_REQUEST_DURATION_SECONDS.labels(
                    method=method,
                    handler=handler,
                    app=self.app_name
                ).observe(duration)

                HTTP_REQUESTS_TOTAL.labels(
                    method=method,
                    handler=handler,
                    status=str(status_code),
                    app=self.app_name
                ).inc()
            except Exception as metric_err:
                logger.debug(f"Prometheus metric observation error: {metric_err}")


# -------------------------------------------------------------------------
# Setup Function for FastAPI App
# -------------------------------------------------------------------------

def setup_instrumentation(app: FastAPI):
    """Instruments FastAPI application with Prometheus metrics and /metrics endpoint."""
    _register_collector()
    app.add_middleware(PrometheusMetricsMiddleware, app_name=APP_NAME)

    @app.get("/metrics", include_in_schema=False)
    async def metrics_endpoint():
        """Prometheus metrics endpoint exposing real live application and process telemetry."""
        data = generate_latest()
        return Response(content=data, media_type=CONTENT_TYPE_LATEST)

    logger.info(f"Prometheus application instrumentation enabled for '{APP_NAME}' at /metrics")
