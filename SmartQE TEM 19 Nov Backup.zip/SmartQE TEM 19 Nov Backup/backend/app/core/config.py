import json
from typing import List, Union
from pydantic import AnyHttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    PROJECT_NAME: str = "SmartQE TEM CONTROL API"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = "super-secret-key-change-this-in-production-smartqe-tem"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 1 day
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # Enterprise Session Timeout Management
    SESSION_IDLE_TIMEOUT_MINUTES: int = 20
    SESSION_ABSOLUTE_TIMEOUT_HOURS: int = 8
    SESSION_WARNING_MINUTES: int = 2
    SESSION_COOKIE_NAME: str = "smartqe_session"
    SESSION_COOKIE_SECURE: bool = False
    SESSION_COOKIE_HTTPONLY: bool = True
    SESSION_COOKIE_SAMESITE: str = "lax"

    # Database & Enterprise PostgreSQL Monitoring Configuration
    POSTGRES_SERVER: str = "localhost"
    POSTGRES_HOST: Union[str, None] = None
    POSTGRES_PORT: int = 5432
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_DB: str = "smartqe_tem"
    POSTGRES_DATABASE: Union[str, None] = None
    POSTGRES_SSL_MODE: str = "prefer"
    POSTGRES_CONNECT_TIMEOUT: float = 5.0
    POSTGRES_ENABLED: bool = True
    POSTGRES_SLOW_QUERY_THRESHOLD_SECONDS: float = 1.0
    POSTGRES_EXPORTER_HOST: str = "0.0.0.0"
    POSTGRES_EXPORTER_PORT: int = 9188
    POSTGRES_COLLECTION_INTERVAL: int = 15
    POSTGRES_DATABASES: Union[str, None] = None
    DATABASE_URL: Union[str, None] = None

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
        "*"
    ]

    # SMTP Email Configuration
    SMTP_HOST: str = "localhost"
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM_EMAIL: str = "no-reply@testops.io"
    SMTP_FROM_NAME: str = "TEM Notifications"
    SMTP_SENDER_EMAIL: str = "no-reply@testops.io"
    SMTP_SENDER_NAME: str = "TEM Notifications"
    SMTP_USE_TLS: bool = True
    SMTP_USE_SSL: bool = False
    SMTP_ENABLED: bool = False
    SMTP_TIMEOUT: int = 5

    # AI / LLM Integration (Multi-Provider: Gemini, OpenAI, Ollama)
    LLM_ENABLED: bool = True
    LLM_PROVIDER: str = "auto"  # "auto", "gemini", "openai", "ollama", "none"
    GEMINI_API_KEY: Union[str, None] = None
    GEMINI_MODEL: str = "gemini-1.5-flash"
    OPENAI_API_KEY: Union[str, None] = None
    OPENAI_MODEL: str = "gpt-4o-mini"
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3"
    LLM_TEMPERATURE: float = 0.2
    LLM_TIMEOUT_SECONDS: float = 12.0

    # Enterprise Monitoring Integration Layer
    PROMETHEUS_URL: str = "http://localhost:9090"
    PROMETHEUS_TIMEOUT: float = 5.0
    PROMETHEUS_ENABLED: bool = True
    PROMETHEUS_SCRAPE_INTERVAL_SECONDS: int = 15
    MONITORING_DATA_STALE_THRESHOLD_SECONDS: int = 60
    ALERTMANAGER_WEBHOOK_SECRET: str = ""

    # Path Portability & Exporters Configuration
    PROMETHEUS_CONFIG_DIR: Union[str, None] = None
    PROMETHEUS_CONFIG_PATH: Union[str, None] = None
    PROMETHEUS_ALERT_RULES_PATH: Union[str, None] = None
    PROMETHEUS_RUNTIME_DIRS: Union[str, None] = None
    SQLITE_DB_PATH: Union[str, None] = None

    # Monitoring Background Worker & Retention
    MONITORING_BACKGROUND_SCHEDULER_ENABLED: bool = True
    MONITORING_PROBE_INTERVAL_SECONDS: int = 60
    MONITORING_DATA_RETENTION_DAYS: int = 30
    MONITORING_RETENTION_CLEANUP_INTERVAL_HOURS: int = 12

    # Probe Security & TLS
    HEALTH_CHECK_VERIFY_SSL: bool = True

    # Auto-Heal Circuit Breaker & Safety
    AUTO_HEAL_CIRCUIT_BREAKER_MAX_ATTEMPTS: int = 3
    AUTO_HEAL_CIRCUIT_BREAKER_WINDOW_MINUTES: int = 30

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"
    )

    @property
    def postgres_effective_host(self) -> str:
        return self.POSTGRES_HOST or self.POSTGRES_SERVER

    @property
    def postgres_effective_database(self) -> str:
        return self.POSTGRES_DATABASE or self.POSTGRES_DB

    def get_database_url(self) -> str:
        if self.DATABASE_URL:
            return self.DATABASE_URL
        return f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.postgres_effective_host}:{self.POSTGRES_PORT}/{self.postgres_effective_database}"


settings = Settings()
