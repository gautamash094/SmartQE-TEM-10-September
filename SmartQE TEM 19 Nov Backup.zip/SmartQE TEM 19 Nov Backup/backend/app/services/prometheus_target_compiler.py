from app.core.config import settings
import os
import shutil
import yaml
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import logger
from app.models.monitoring import MonitoringTarget
from app.models.asset import Asset, AssetType
from app.models.environment_profile import EnvironmentProfile
from app.adapters.monitoring.prometheus_client import prometheus_client


class PrometheusTargetCompiler:
    """
    Compiles dynamic server infrastructure and application targets across environments
    from SmartQE TEM into Prometheus scrape_configs in prometheus.yml, replicates the
    file across runtime locations, and triggers hot configuration reload.
    """

    @property
    def base_prometheus_config_path(self) -> str:
        if getattr(settings, "PROMETHEUS_CONFIG_PATH", None):
            return os.path.abspath(settings.PROMETHEUS_CONFIG_PATH)
        base_dir = getattr(settings, "PROMETHEUS_CONFIG_DIR", None) or os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "..", "monitoring")
        )
        return os.path.join(base_dir, "prometheus.yml")

    @property
    def prometheus_dirs(self) -> List[str]:
        dirs: List[str] = []
        base_dir = getattr(settings, "PROMETHEUS_CONFIG_DIR", None) or os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "..", "monitoring")
        )
        if os.path.isdir(base_dir):
            dirs.append(base_dir)
        runtime_dirs = getattr(settings, "PROMETHEUS_RUNTIME_DIRS", None)
        if runtime_dirs:
            for p in runtime_dirs.split(","):
                p_clean = p.strip()
                if p_clean and os.path.isdir(p_clean) and p_clean not in dirs:
                    dirs.append(p_clean)
        return dirs

    def _get_base_config_template(self) -> Dict[str, Any]:
        """Provides the platform base configuration and internal self-monitoring jobs."""
        return {
            "global": {
                "scrape_interval": "15s",
                "evaluation_interval": "15s",
                "scrape_timeout": "10s",
                "external_labels": {
                    "monitor": "smartqe-tem-monitoring-system",
                    "cluster": "tem-control-plane"
                }
            },
            "alerting": {
                "alertmanagers": [
                    {
                        "static_configs": [
                            {"targets": ["localhost:9093"]}
                        ]
                    }
                ]
            },
            "rule_files": [
                "alert_rules.yml"
            ],
            "scrape_configs": [
                {
                    "job_name": "prometheus",
                    "static_configs": [
                        {
                            "targets": ["localhost:9090"],
                            "labels": {
                                "environment": "Production / TEM",
                                "tier": "MONITORING",
                                "service": "prometheus-server"
                            }
                        }
                    ]
                },
                {
                    "job_name": "smartqe-tem-sqlite",
                    "scrape_interval": "15s",
                    "scrape_timeout": "5s",
                    "metrics_path": "/metrics",
                    "static_configs": [
                        {
                            "targets": ["localhost:9187"],
                            "labels": {
                                "environment": "Production / TEM",
                                "tier": "DATABASE",
                                "database": "sqlite",
                                "technology": "sqlite",
                                "app": "smartqe-tem",
                                "instance": "localhost:9187"
                            }
                        }
                    ]
                },
                {
                    "job_name": "smartqe-tem-postgresql",
                    "scrape_interval": "15s",
                    "scrape_timeout": "5s",
                    "metrics_path": "/metrics",
                    "static_configs": [
                        {
                            "targets": ["localhost:9188"],
                            "labels": {
                                "environment": "Production / TEM",
                                "tier": "DATABASE",
                                "database": "smartqe_tem",
                                "technology": "postgresql",
                                "app": "smartqe-tem",
                                "instance": "localhost:9188"
                            }
                        }
                    ]
                },
                {
                    "job_name": "smartqe-applications",
                    "scrape_interval": "10s",
                    "scrape_timeout": "5s",
                    "metrics_path": "/metrics",
                    "static_configs": [
                        {
                            "targets": ["localhost:8000"],
                            "labels": {
                                "environment": "Production / TEM",
                                "tier": "APPLICATION",
                                "monitoring_tier": "application",
                                "app": "smartqe-tem-backend",
                                "application": "smartqe-tem-backend",
                                "runtime": "python",
                                "instance": "localhost:8000"
                            }
                        }
                    ]
                }
            ]
        }

    async def compile_config_from_db(self, db: AsyncSession) -> Dict[str, Any]:
        """
        Gathers all servers across environments from database assets & monitoring targets,
        constructs dynamic scrape_configs with environment tags, and returns the full YAML dict.
        """
        config = self._get_base_config_template()
        scrape_configs: List[Dict[str, Any]] = config["scrape_configs"]

        # Track targets to avoid duplicate scrapes
        seen_endpoints = set()

        # Always maintain the primary local windows_exporter host
        local_windows_target = {
            "targets": ["localhost:9182"],
            "labels": {
                "environment": "Production / TEM",
                "tier": "INFRASTRUCTURE",
                "os": "windows",
                "app": "smartqe-tem",
                "hostname": "WIN-SRV-TEM-01"
            }
        }
        windows_targets = [local_windows_target]
        seen_endpoints.add("localhost:9182")

        linux_targets: List[Dict[str, Any]] = []

        # 1. Fetch from Asset inventory (servers)
        try:
            asset_stmt = select(Asset).where(
                Asset.is_active == True,
                Asset.is_visible == True,
                Asset.asset_type == AssetType.SERVER
            )
            asset_res = await db.execute(asset_stmt)
            servers = list(asset_res.scalars().all())

            for s in servers:
                host = s.ip_address or s.hostname or "127.0.0.1"
                os_str = (s.operating_system or "").lower()
                is_win = "windows" in os_str
                port = 9182 if is_win else 9100

                clean_endpoint = f"{host}:{port}" if ":" not in host else host
                if clean_endpoint in seen_endpoints:
                    continue
                seen_endpoints.add(clean_endpoint)

                target_item = {
                    "targets": [clean_endpoint],
                    "labels": {
                        "environment": s.environment_name or "Unassigned",
                        "environment_id": str(s.environment_id or "env-unassigned"),
                        "tier": "INFRASTRUCTURE",
                        "os": "windows" if is_win else "linux",
                        "app": s.application_name or "smartqe-tem",
                        "hostname": s.name or s.hostname or host
                    }
                }
                if is_win:
                    windows_targets.append(target_item)
                else:
                    linux_targets.append(target_item)
        except Exception as exc:
            logger.warning(f"Error querying asset servers for prometheus compilation: {exc}")

        # 2. Fetch from MonitoringTarget table
        try:
            mt_stmt = select(MonitoringTarget).where(
                MonitoringTarget.is_enabled == True,
                MonitoringTarget.target_type.in_(["SERVER", "LINUX_SERVER", "WINDOWS_SERVER"])
            )
            mt_res = await db.execute(mt_stmt)
            m_targets = list(mt_res.scalars().all())

            for mt in m_targets:
                raw_url = mt.endpoint_url or ""
                endpoint = raw_url.replace("http://", "").replace("https://", "").split("/")[0]
                if not endpoint or endpoint in seen_endpoints:
                    continue
                seen_endpoints.add(endpoint)

                is_win = "win" in (mt.target_type or "").lower()
                target_item = {
                    "targets": [endpoint],
                    "labels": {
                        "environment": mt.environment_name or "Unassigned",
                        "environment_id": str(mt.environment_id or "env-unassigned"),
                        "tier": "INFRASTRUCTURE",
                        "os": "windows" if is_win else "linux",
                        "app": mt.application_name or "smartqe-tem",
                        "hostname": mt.server_name or mt.name
                    }
                }
                if is_win:
                    windows_targets.append(target_item)
                else:
                    linux_targets.append(target_item)
        except Exception as exc:
            logger.warning(f"Error querying monitoring targets for prometheus compilation: {exc}")

        
        # 3. Dynamic Application Targets
        app_targets: List[Dict[str, Any]] = [
            {
                "targets": ["localhost:8000"],
                "labels": {
                    "environment": "Production / TEM",
                    "tier": "APPLICATION",
                    "monitoring_tier": "application",
                    "app": "smartqe-tem-backend",
                    "application": "smartqe-tem-backend",
                    "runtime": "python",
                    "instance": "localhost:8000"
                }
            }
        ]
        try:
            app_mt_stmt = select(MonitoringTarget).where(
                MonitoringTarget.is_enabled == True,
                MonitoringTarget.target_type.in_(["APPLICATION", "MICROSERVICE", "REST_API", "SERVICE"])
            )
            app_mt_res = await db.execute(app_mt_stmt)
            for amt in app_mt_res.scalars().all():
                raw_url = amt.endpoint_url or ""
                endpoint = raw_url.replace("http://", "").replace("https://", "").split("/")[0]
                if not endpoint or endpoint in seen_endpoints:
                    continue
                seen_endpoints.add(endpoint)
                app_targets.append({
                    "targets": [endpoint],
                    "labels": {
                        "environment": amt.environment_name or "Unassigned",
                        "environment_id": str(amt.environment_id or "env-unassigned"),
                        "tier": "APPLICATION",
                        "monitoring_tier": "application",
                        "app": amt.name or amt.application_name or "custom-app",
                        "application": amt.application_name or amt.name or "custom-app",
                        "runtime": "generic",
                        "instance": endpoint
                    }
                })
        except Exception as exc:
            logger.warning(f"Error querying application monitoring targets: {exc}")

        # Update or add smartqe-applications job in scrape_configs
        app_job = next((j for j in scrape_configs if j.get("job_name") == "smartqe-applications"), None)
        if app_job:
            app_job["static_configs"] = app_targets
        else:
            scrape_configs.append({
                "job_name": "smartqe-applications",
                "scrape_interval": "10s",
                "scrape_timeout": "5s",
                "metrics_path": "/metrics",
                "static_configs": app_targets
            })

        # 3. Append dynamic Windows Exporter Scrape Job
        if windows_targets:
            scrape_configs.append({
                "job_name": "windows-exporter",
                "scrape_interval": "15s",
                "scrape_timeout": "10s",
                "metrics_path": "/metrics",
                "static_configs": windows_targets
            })

        # 4. Append dynamic Linux Node Exporter Scrape Job
        if linux_targets:
            scrape_configs.append({
                "job_name": "node-exporter",
                "scrape_interval": "15s",
                "scrape_timeout": "10s",
                "metrics_path": "/metrics",
                "static_configs": linux_targets
            })

        return config

    async def sync_to_prometheus(self, db: AsyncSession) -> Dict[str, Any]:
        """
        Compiles dynamic targets from DB, updates prometheus.yml across runtime locations,
        and triggers hot configuration reload on Prometheus.
        """
        config_structure = await self.compile_config_from_db(db)
        yaml_content = yaml.dump(config_structure, sort_keys=False, default_flow_style=False)

        # 1. Write to base backend prometheus.yml
        os.makedirs(os.path.dirname(self.base_prometheus_config_path), exist_ok=True)
        with open(self.base_prometheus_config_path, "w", encoding="utf-8") as f:
            f.write(yaml_content)
        logger.info(f"Compiled prometheus.yml written to {self.base_prometheus_config_path}")

        # 2. Replicate to active Prometheus runtime directories
        replicated_paths: List[str] = []
        for target_dir in self.prometheus_dirs:
            if os.path.isdir(target_dir):
                dest_path = os.path.join(target_dir, "prometheus.yml")
                if os.path.abspath(dest_path) == os.path.abspath(self.base_prometheus_config_path):
                    continue
                try:
                    shutil.copyfile(self.base_prometheus_config_path, dest_path)
                    replicated_paths.append(dest_path)
                    logger.info(f"Replicated prometheus.yml to Prometheus runtime directory: {dest_path}")
                except Exception as exc:
                    logger.warning(f"Could not copy prometheus.yml to {dest_path}: {exc}")

        # 3. Trigger Prometheus reload via lifecycle API
        reload_success, reload_err = await prometheus_client.reload_config()
        total_jobs = len(config_structure.get("scrape_configs", []))
        total_targets = sum(
            len(sc.get("targets", []))
            for job in config_structure.get("scrape_configs", [])
            for sc in job.get("static_configs", [])
        )

        return {
            "success": True,
            "jobs_count": total_jobs,
            "targets_count": total_targets,
            "prometheus_reloaded": reload_success,
            "reload_message": reload_err or "Configuration reloaded successfully",
            "synced_at": datetime.now(timezone.utc).isoformat(),
            "destinations": replicated_paths
        }


prometheus_target_compiler = PrometheusTargetCompiler()
