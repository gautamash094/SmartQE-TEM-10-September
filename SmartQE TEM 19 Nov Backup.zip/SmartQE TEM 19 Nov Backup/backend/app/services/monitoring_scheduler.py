import asyncio
import time
from datetime import datetime, timezone, timedelta
from typing import List, Optional
from sqlalchemy import select, and_, or_, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.logging import logger
from app.database.session import AsyncSessionLocal
from app.models.environment_profile import EnvironmentProfile
from app.models.monitoring import (
    MonitoringTarget,
    TimeSeriesMetric,
    MonitoringEvent,
    EventState
)
from app.models.health_check import (
    HealthCheckExecution,
    HealthCheckResult
)
from app.services.health_check_service import health_check_service
from app.services.monitoring_service import monitoring_service


class MonitoringScheduler:
    """
    Enterprise Autonomous Monitoring & Health Check Scheduler.
    Runs continuous background health checks, Prometheus target scrapes,
    and automated time-series telemetry data retention cleanup.
    """

    def __init__(
        self,
        probe_interval_seconds: Optional[int] = None,
        retention_days: Optional[int] = None,
        retention_interval_hours: Optional[int] = None
    ):
        self.probe_interval_seconds = probe_interval_seconds or getattr(settings, "MONITORING_PROBE_INTERVAL_SECONDS", 60)
        self.retention_days = retention_days or getattr(settings, "MONITORING_DATA_RETENTION_DAYS", 30)
        self.retention_interval_hours = retention_interval_hours or getattr(settings, "MONITORING_RETENTION_CLEANUP_INTERVAL_HOURS", 12)
        
        self._task: Optional[asyncio.Task] = None
        self._is_running = False
        self._last_retention_run: float = 0.0

    async def execute_probe_cycle(self, db: AsyncSession):
        """
        Executes active synthetic probes and readiness evaluations for all enabled environment profiles.
        """
        try:
            # 1. Fetch all active environment profiles
            q = select(EnvironmentProfile).where(EnvironmentProfile.is_visible == True)
            res = await db.execute(q)
            environments: List[EnvironmentProfile] = list(res.scalars().all())

            for env in environments:
                try:
                    await health_check_service.execute_environment_health_check(
                        db=db,
                        environment_id=env.id,
                        triggered_by="SYSTEM_SCHEDULER",
                        trigger_type="SCHEDULED",
                        auto_heal_if_critical=True
                    )
                except Exception as env_err:
                    logger.warning(f"[MONITORING SCHEDULER] Health check probe failed for env {env.name} ({env.id}): {env_err}")

            # 2. Scrape enabled monitoring targets
            t_q = select(MonitoringTarget).where(
                and_(
                    MonitoringTarget.is_enabled == True,
                    MonitoringTarget.is_visible == True
                )
            )
            t_res = await db.execute(t_q)
            targets: List[MonitoringTarget] = list(t_res.scalars().all())

            for target in targets:
                try:
                    await monitoring_service.scrape_target(db=db, target_id=target.id)
                except Exception as t_err:
                    logger.debug(f"[MONITORING SCHEDULER] Target scrape error for {target.name}: {t_err}")

        except Exception as exc:
            logger.error(f"[MONITORING SCHEDULER] Probe cycle error: {exc}")

    async def execute_retention_cleanup(self, db: AsyncSession) -> dict:
        """
        Prunes historical time-series metric samples, executions, and recovered alerts
        older than the configured retention policy to maintain optimal database performance.
        """
        cutoff_date = datetime.now(timezone.utc) - timedelta(days=self.retention_days)
        logger.info(f"[MONITORING RETENTION] Starting data retention cleanup (Cutoff: {cutoff_date.isoformat()}, Retention: {self.retention_days} days)...")

        pruned_stats = {
            "time_series_metrics": 0,
            "health_check_executions": 0,
            "recovered_events": 0
        }

        try:
            # 1. Prune TimeSeriesMetric
            stmt_ts = delete(TimeSeriesMetric).where(TimeSeriesMetric.timestamp < cutoff_date)
            res_ts = await db.execute(stmt_ts)
            pruned_stats["time_series_metrics"] = res_ts.rowcount or 0

            # 2. Prune old HealthCheckExecution records (HealthCheckResult cascades automatically)
            stmt_hc = delete(HealthCheckExecution).where(HealthCheckExecution.started_at < cutoff_date)
            res_hc = await db.execute(stmt_hc)
            pruned_stats["health_check_executions"] = res_hc.rowcount or 0

            # 3. Prune recovered MonitoringEvent records
            stmt_ev = delete(MonitoringEvent).where(
                and_(
                    MonitoringEvent.state == EventState.RECOVERED,
                    MonitoringEvent.triggered_at < cutoff_date
                )
            )
            res_ev = await db.execute(stmt_ev)
            pruned_stats["recovered_events"] = res_ev.rowcount or 0

            await db.commit()
            logger.info(
                f"[MONITORING RETENTION] Cleanup complete: Pruned {pruned_stats['time_series_metrics']} metrics, "
                f"{pruned_stats['health_check_executions']} health executions, "
                f"{pruned_stats['recovered_events']} recovered events."
            )
        except Exception as exc:
            await db.rollback()
            logger.error(f"[MONITORING RETENTION ERROR] Failed to prune historical data: {exc}")

        return pruned_stats

    async def _run_loop(self):
        logger.info(f"TEM Autonomous Monitoring Scheduler started (Probe Interval: {self.probe_interval_seconds}s, Retention: {self.retention_days}d)")
        
        # Initial retention check on startup
        try:
            async with AsyncSessionLocal() as session:
                await self.execute_retention_cleanup(session)
                self._last_retention_run = time.time()
        except Exception as exc:
            logger.warning(f"Initial monitoring retention check failed: {exc}")

        while self._is_running:
            try:
                async with AsyncSessionLocal() as session:
                    await self.execute_probe_cycle(session)

                    # Check if retention cleanup interval has elapsed
                    elapsed_hours = (time.time() - self._last_retention_run) / 3600.0
                    if elapsed_hours >= self.retention_interval_hours:
                        await self.execute_retention_cleanup(session)
                        self._last_retention_run = time.time()

            except Exception as exc:
                logger.error(f"Error during monitoring scheduler loop: {exc}")

            try:
                await asyncio.sleep(self.probe_interval_seconds)
            except asyncio.CancelledError:
                break

        logger.info("TEM Autonomous Monitoring Scheduler stopped.")

    def start(self):
        if not getattr(settings, "MONITORING_BACKGROUND_SCHEDULER_ENABLED", True):
            logger.info("TEM Autonomous Monitoring Scheduler is disabled via configuration.")
            return

        if not self._is_running:
            self._is_running = True
            self._task = asyncio.create_task(self._run_loop())

    def stop(self):
        self._is_running = False
        if self._task and not self._task.done():
            self._task.cancel()


monitoring_scheduler = MonitoringScheduler()
