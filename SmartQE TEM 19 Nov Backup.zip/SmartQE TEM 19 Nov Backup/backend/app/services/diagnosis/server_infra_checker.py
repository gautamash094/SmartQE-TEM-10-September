from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from sqlalchemy import select, and_, or_
from app.services.diagnosis.base_checker import BaseDiagnosisChecker
from app.schemas.diagnosis import DiagnosisCheckerResult
from app.models.monitoring import MonitoringThresholdRule


class ServerInfrastructureChecker(BaseDiagnosisChecker):
    @property
    def name(self) -> str:
        return "Server & Infrastructure Resource Checker"

    @property
    def category(self) -> str:
        return "SERVER"

    async def _resolve_user_thresholds(
        self, db: Any, server_id: Optional[str] = None
    ) -> Dict[str, Dict[str, Any]]:
        """
        Dynamically fetches user-configured threshold rules from the database.
        Falls back to baseline defaults only if no rule is configured by the user.
        """
        thresholds: Dict[str, Dict[str, Any]] = {
            "CPU": {"warning": 75.0, "critical": 90.0, "severe": 95.0, "is_user_configured": False},
            "MEMORY": {"warning": 80.0, "critical": 90.0, "severe": 95.0, "is_user_configured": False},
            "DISK": {"warning": 80.0, "critical": 90.0, "severe": 95.0, "is_user_configured": False},
        }

        if not db:
            return thresholds

        try:
            conditions = [MonitoringThresholdRule.is_enabled == True]
            if server_id and server_id.upper() != "ALL":
                conditions.append(
                    or_(
                        MonitoringThresholdRule.server_id == server_id,
                        MonitoringThresholdRule.server_id == "ALL",
                        MonitoringThresholdRule.server_id.is_(None)
                    )
                )
            stmt = select(MonitoringThresholdRule).where(and_(*conditions)).order_by(
                MonitoringThresholdRule.updated_at.desc(),
                MonitoringThresholdRule.created_at.desc()
            )
            result = await db.execute(stmt)
            rules = list(result.scalars().all())

            # Server-specific rules take precedence over global 'ALL', then newest updated first
            rules.sort(key=lambda r: (
                1 if (r.server_id and r.server_id.upper() != "ALL") else 0,
                r.updated_at.isoformat() if r.updated_at else (r.created_at.isoformat() if r.created_at else "")
            ), reverse=True)

            resolved_categories = set()
            for r in rules:
                cat = (r.metric_category or (r.metric_type.value if hasattr(r.metric_type, "value") else str(r.metric_type))).upper()
                if cat in ("CPU", "PROCESSOR"):
                    key = "CPU"
                elif cat in ("MEMORY", "RAM"):
                    key = "MEMORY"
                elif cat in ("DISK", "STORAGE", "DISK_VOLUME"):
                    key = "DISK"
                else:
                    continue

                # Once the highest-priority rule (server-specific & newest) is resolved for this category, skip older ones
                if key in resolved_categories:
                    continue
                resolved_categories.add(key)

                this_is_server_specific = bool(r.server_id and r.server_id != "ALL")
                if r.warning_threshold is not None:
                    thresholds[key]["warning"] = float(r.warning_threshold)
                if r.critical_threshold is not None:
                    thresholds[key]["critical"] = float(r.critical_threshold)
                if r.severe_threshold is not None:
                    thresholds[key]["severe"] = float(r.severe_threshold)
                thresholds[key]["is_user_configured"] = True
                thresholds[key]["is_server_specific"] = this_is_server_specific
                thresholds[key]["rule_name"] = r.name
        except Exception:
            # If query fails, retain default baseline
            pass

        return thresholds

    async def run_check(self, context: Dict[str, Any]) -> DiagnosisCheckerResult:
        db = context.get("db")
        env = context.get("env")
        profile = context.get("profile")
        assets: List[Any] = context.get("assets", [])
        env_id = context.get("env_id") or (getattr(env, "id", None) or getattr(profile, "id", None))

        findings = []
        status = "PASSED"

        # Determine target server ID if available
        target_server_id = None
        if profile and getattr(profile, "server_ids", None) and len(profile.server_ids) > 0:
            target_server_id = profile.server_ids[0]
        elif assets and len(assets) > 0:
            target_server_id = getattr(assets[0], "id", None) or getattr(assets[0], "server_id", None)

        # 1. Dynamically retrieve user-configured thresholds from DB
        thresholds = await self._resolve_user_thresholds(db, target_server_id)
        cpu_rules = thresholds["CPU"]
        mem_rules = thresholds["MEMORY"]
        disk_rules = thresholds["DISK"]

        # 2. Check CPU / Memory / Storage metrics
        cpu_usage = getattr(env, "cpu_usage", None)
        memory_usage = getattr(env, "memory_usage", None)
        storage_usage = getattr(env, "storage_usage", None)
        env_status = str(getattr(env, "status", None) or getattr(profile, "status", "HEALTHY") or "HEALTHY")

        # Fallback to monitoring_service if env model does not directly store live telemetry
        if cpu_usage is None or memory_usage is None or storage_usage is None:
            try:
                from app.services.monitoring_service import monitoring_service
                dossier = await monitoring_service.get_server_dossier(
                    environment_id=env_id or "default",
                    server_id=target_server_id or "default",
                    db=db
                )
                if dossier:
                    if cpu_usage is None and dossier.cpu:
                        cpu_usage = float(dossier.cpu.utilization_pct or 0.0)
                    if memory_usage is None and dossier.memory:
                        memory_usage = float(dossier.memory.utilization_pct or 0.0)
                    if storage_usage is None and dossier.disk:
                        storage_usage = float(dossier.disk.utilization_pct or 0.0)
            except Exception:
                pass

        cpu_usage = float(cpu_usage or 0.0)
        memory_usage = float(memory_usage or 0.0)
        storage_usage = float(storage_usage or 0.0)

        # 3. Environment operational status check
        if env_status in ("DOWN", "CRITICAL"):
            status = "CRITICAL"
            findings.append(f"Environment status is currently marked as {env_status}")
        elif env_status in ("DEGRADED", "WARNING", "MAINTENANCE"):
            status = "WARNING"
            findings.append(f"Environment is in {env_status} operational state")

        # 4. CPU Evaluation using User-Configured Thresholds
        cpu_crit = cpu_rules["critical"]
        cpu_warn = cpu_rules["warning"]
        if cpu_usage >= cpu_crit:
            status = "CRITICAL"
            cfg_note = " (User-Configured Critical Threshold)" if cpu_rules["is_user_configured"] else ""
            findings.append(f"High CPU utilization: {cpu_usage:.1f}% (Threshold: {cpu_crit:.1f}%{cfg_note})")
        elif cpu_usage >= cpu_warn and status != "CRITICAL":
            status = "WARNING"
            cfg_note = " (User-Configured Warning Threshold)" if cpu_rules["is_user_configured"] else ""
            findings.append(f"Elevated CPU utilization: {cpu_usage:.1f}% (Threshold: {cpu_warn:.1f}%{cfg_note})")

        # 5. Memory Evaluation using User-Configured Thresholds
        mem_crit = mem_rules["critical"]
        mem_warn = mem_rules["warning"]
        if memory_usage >= mem_crit:
            status = "CRITICAL"
            cfg_note = " (User-Configured Critical Threshold)" if mem_rules["is_user_configured"] else ""
            findings.append(f"High Memory utilization: {memory_usage:.1f}% (Threshold: {mem_crit:.1f}%{cfg_note})")
        elif memory_usage >= mem_warn and status != "CRITICAL":
            status = "WARNING"
            cfg_note = " (User-Configured Warning Threshold)" if mem_rules["is_user_configured"] else ""
            findings.append(f"Elevated Memory utilization: {memory_usage:.1f}% (Threshold: {mem_warn:.1f}%{cfg_note})")

        # 6. Storage Evaluation using User-Configured Thresholds
        disk_crit = disk_rules["critical"]
        disk_warn = disk_rules["warning"]
        if storage_usage >= disk_crit:
            status = "CRITICAL"
            cfg_note = " (User-Configured Critical Threshold)" if disk_rules["is_user_configured"] else ""
            findings.append(f"High Storage utilization: {storage_usage:.1f}% (Threshold: {disk_crit:.1f}%{cfg_note})")
        elif storage_usage >= disk_warn and status != "CRITICAL":
            status = "WARNING"
            cfg_note = " (User-Configured Warning Threshold)" if disk_rules["is_user_configured"] else ""
            findings.append(f"Elevated Storage utilization: {storage_usage:.1f}% (Threshold: {disk_warn:.1f}%{cfg_note})")

        summary = (
            "Server infrastructure resources are healthy and within user-configured operational thresholds."
            if status == "PASSED"
            else f"Infrastructure check returned {status} with {len(findings)} alert(s)."
        )

        return DiagnosisCheckerResult(
            checker_name=self.name,
            category=self.category,
            status=status,
            summary=summary,
            details={
                "cpu_usage_pct": round(cpu_usage, 1),
                "memory_usage_pct": round(memory_usage, 1),
                "storage_usage_pct": round(storage_usage, 1),
                "linked_assets_count": len(assets),
                "applied_thresholds": {
                    "cpu": {"warning": cpu_warn, "critical": cpu_crit, "user_configured": cpu_rules["is_user_configured"]},
                    "memory": {"warning": mem_warn, "critical": mem_crit, "user_configured": mem_rules["is_user_configured"]},
                    "storage": {"warning": disk_warn, "critical": disk_crit, "user_configured": disk_rules["is_user_configured"]},
                },
                "findings": findings
            },
            timestamp=datetime.now(timezone.utc)
        )
