from app.database.session import is_postgres_available
import json
import base64
import hashlib
from typing import List, Optional, Dict, Any
from sqlalchemy import select, update, delete
from sqlalchemy.ext.asyncio import AsyncSession
from cryptography.fernet import Fernet

from app.core.config import settings
from app.core.logging import logger
from app.models.monitoring_config import (
    MonitoringToolConfig,
    MonitoringConfigAuditLog,
    MonitoringToolType,
    MonitoringAuthType,
    MonitoringCapability
)
from app.schemas.monitoring_config import ConnectionTestResult
from app.adapters.monitoring.factory import AdapterFactory
from app.adapters.monitoring.registry import adapter_registry


class MonitoringConfigService:
    """
    Centralized Monitoring Configuration Service for SmartQE TEM.
    Acts as the Single Source of Truth for all monitoring integrations.
    Handles credential encryption, live adapter factory instantiation,
    audit history, connection testing, and hot-reload.
    """

    def __init__(self):
        secret = getattr(settings, "SECRET_KEY", "smartqe-tem-monitoring-default-secret-key-32")
        key_32 = hashlib.sha256(secret.encode("utf-8")).digest()
        fernet_key = base64.urlsafe_b64encode(key_32)
        self._fernet = Fernet(fernet_key)

    def encrypt_credentials(self, credentials: Dict[str, Any]) -> str:
        """Encrypts sensitive credentials into a secure AES-256 payload."""
        if not credentials:
            return ""
        payload = json.dumps(credentials).encode("utf-8")
        return self._fernet.encrypt(payload).decode("utf-8")

    def decrypt_credentials(self, encrypted_str: Optional[str]) -> Dict[str, Any]:
        """Decrypts encrypted credentials payload into a dictionary."""
        if not encrypted_str:
            return {}
        try:
            raw = self._fernet.decrypt(encrypted_str.encode("utf-8"))
            return json.loads(raw.decode("utf-8"))
        except Exception as exc:
            logger.warning(f"Could not decrypt monitoring credentials: {exc}")
            return {}

    @staticmethod
    def mask_credentials(credentials: Dict[str, Any]) -> Dict[str, str]:
        """Masks sensitive credentials for safe API serialization."""
        masked = {}
        for k, v in (credentials or {}).items():
            if isinstance(v, str) and len(v) > 4:
                masked[k] = f"********{v[-4:]}"
            else:
                masked[k] = "********"
        return masked

    async def list_configs(self, db: AsyncSession) -> List[MonitoringToolConfig]:
        """Retrieves all registered monitoring configurations sorted by priority."""
        stmt = select(MonitoringToolConfig).order_by(MonitoringToolConfig.priority.asc(), MonitoringToolConfig.created_at.asc())
        res = await db.execute(stmt)
        return list(res.scalars().all())

    async def get_config_by_identifier(self, db: AsyncSession, tool_identifier: str) -> Optional[MonitoringToolConfig]:
        """Retrieves a configuration by its unique tool_identifier or ID."""
        stmt = select(MonitoringToolConfig).where(
            (MonitoringToolConfig.tool_identifier == tool_identifier) | (MonitoringToolConfig.id == tool_identifier)
        )
        res = await db.execute(stmt)
        return res.scalars().first()

    async def create_or_register_tool(
        self,
        db: AsyncSession,
        payload: Dict[str, Any],
        raw_credentials: Optional[Dict[str, Any]] = None,
        performed_by: str = "admin"
    ) -> MonitoringToolConfig:
        """Registers a new monitoring platform into the centralized registry."""
        encrypted_creds = self.encrypt_credentials(raw_credentials) if raw_credentials else None

        tool_type = payload.get("tool_type", "PROMETHEUS")
        if isinstance(tool_type, str):
            tool_type = MonitoringToolType(tool_type.upper())

        auth_type = payload.get("auth_type", "NONE")
        if isinstance(auth_type, str):
            auth_type = MonitoringAuthType(auth_type.upper())

        config = MonitoringToolConfig(
            tool_identifier=payload["tool_identifier"],
            tool_type=tool_type,
            display_name=payload.get("display_name", payload["tool_identifier"]),
            description=payload.get("description", ""),
            is_enabled=payload.get("is_enabled", True),
            base_url=payload["base_url"].rstrip("/"),
            tls_verify=payload.get("tls_verify", True),
            ca_cert_path=payload.get("ca_cert_path"),
            timeout_seconds=payload.get("timeout_seconds", 5.0),
            retry_count=payload.get("retry_count", 3),
            retry_backoff_factor=payload.get("retry_backoff_factor", 0.5),
            auth_type=auth_type,
            encrypted_credentials=encrypted_creds,
            custom_headers=payload.get("custom_headers", {}),
            capabilities=payload.get("capabilities", ["INFRASTRUCTURE", "SERVER"]),
            metric_mappings=payload.get("metric_mappings", {}),
            environment_scope=payload.get("environment_scope", ["ALL"]),
            priority=payload.get("priority", 1),
            is_default_for_scope=payload.get("is_default_for_scope", False),
            scrape_interval_seconds=payload.get("scrape_interval_seconds", 15),
            health_check_path=payload.get("health_check_path", "/health"),
            health_check_interval_seconds=payload.get("health_check_interval_seconds", 30),
            tool_parameters=payload.get("tool_parameters", {}),
            target_assignments=payload.get("target_assignments", {}),
            modified_by=performed_by
        )
        db.add(config)
        await db.flush()

        audit = MonitoringConfigAuditLog(
            config_id=config.id,
            tool_identifier=config.tool_identifier,
            action="CREATED",
            changed_fields={"display_name": config.display_name, "base_url": config.base_url},
            performed_by=performed_by
        )
        db.add(audit)
        await db.commit()
        await db.refresh(config)

        # Hot-load into live adapter registry
        if config.is_enabled:
            await self.hot_load_adapter(config, raw_credentials)

        return config

    async def update_tool(
        self,
        db: AsyncSession,
        tool_identifier: str,
        payload: Dict[str, Any],
        raw_credentials: Optional[Dict[str, Any]] = None,
        performed_by: str = "admin"
    ) -> Optional[MonitoringToolConfig]:
        """Updates an existing monitoring tool configuration and hot-reloads it."""
        config = await self.get_config_by_identifier(db, tool_identifier)
        if not config:
            return None

        changed = {}
        for key, value in payload.items():
            if value is not None and hasattr(config, key):
                old_val = getattr(config, key)
                if old_val != value:
                    setattr(config, key, value)
                    changed[key] = value

        if raw_credentials is not None:
            config.encrypted_credentials = self.encrypt_credentials(raw_credentials)
            changed["credentials_updated"] = True

        config.version += 1
        config.modified_by = performed_by

        audit = MonitoringConfigAuditLog(
            config_id=config.id,
            tool_identifier=config.tool_identifier,
            action="UPDATED",
            changed_fields=changed,
            performed_by=performed_by
        )
        db.add(audit)
        await db.commit()
        await db.refresh(config)

        # Hot-reload in memory
        creds = raw_credentials if raw_credentials is not None else self.decrypt_credentials(config.encrypted_credentials)
        if config.is_enabled:
            await self.hot_load_adapter(config, creds)
        else:
            adapter_registry.unregister_adapter(config.tool_identifier)

        return config

    async def toggle_tool_state(
        self,
        db: AsyncSession,
        tool_identifier: str,
        is_enabled: bool,
        performed_by: str = "admin"
    ) -> Optional[MonitoringToolConfig]:
        """Toggles a monitoring tool between ENABLED and DISABLED."""
        config = await self.get_config_by_identifier(db, tool_identifier)
        if not config:
            return None

        config.is_enabled = is_enabled
        config.version += 1
        config.modified_by = performed_by

        audit = MonitoringConfigAuditLog(
            config_id=config.id,
            tool_identifier=config.tool_identifier,
            action="ENABLED" if is_enabled else "DISABLED",
            changed_fields={"is_enabled": is_enabled},
            performed_by=performed_by
        )
        db.add(audit)
        await db.commit()
        await db.refresh(config)

        if is_enabled:
            creds = self.decrypt_credentials(config.encrypted_credentials)
            await self.hot_load_adapter(config, creds)
        else:
            adapter_registry.unregister_adapter(config.tool_identifier)

        return config

    async def delete_tool(
        self,
        db: AsyncSession,
        tool_identifier: str,
        performed_by: str = "admin"
    ) -> bool:
        """Deletes a monitoring tool configuration and unregisters its adapter."""
        config = await self.get_config_by_identifier(db, tool_identifier)
        if not config:
            return False

        audit = MonitoringConfigAuditLog(
            config_id=config.id,
            tool_identifier=config.tool_identifier,
            action="DELETED",
            changed_fields={"tool_identifier": config.tool_identifier},
            performed_by=performed_by
        )
        db.add(audit)
        await db.delete(config)
        await db.commit()

        adapter_registry.unregister_adapter(tool_identifier)
        return True

    async def test_tool_connection(
        self,
        db: AsyncSession,
        tool_identifier: str
    ) -> ConnectionTestResult:
        """Runs a live connection probe against an existing configured tool."""
        config = await self.get_config_by_identifier(db, tool_identifier)
        if not config:
            return ConnectionTestResult(success=False, latency_ms=0.0, message="Tool configuration not found")

        credentials = self.decrypt_credentials(config.encrypted_credentials)
        try:
            transient_adapter = AdapterFactory.create_adapter(config, decrypted_credentials=credentials)
            return await transient_adapter.test_connection()
        except Exception as exc:
            return ConnectionTestResult(success=False, latency_ms=0.0, message=f"Adapter instantiation error: {exc}")

    async def test_transient_connection(
        self,
        payload: Dict[str, Any],
        raw_credentials: Optional[Dict[str, Any]] = None
    ) -> ConnectionTestResult:
        """Runs a pre-save connection probe without saving to database."""
        try:
            tool_type = payload.get("tool_type", "PROMETHEUS")
            if isinstance(tool_type, str):
                tool_type = MonitoringToolType(tool_type.upper())

            dummy_config = MonitoringToolConfig(
                tool_identifier=payload.get("tool_identifier", "probe-temp"),
                tool_type=tool_type,
                display_name=payload.get("display_name", "Probe"),
                base_url=payload["base_url"].rstrip("/"),
                timeout_seconds=payload.get("timeout_seconds", 5.0),
                capabilities=payload.get("capabilities", ["INFRASTRUCTURE", "SERVER"]),
                tool_parameters=payload.get("tool_parameters", {})
            )
            transient_adapter = AdapterFactory.create_adapter(dummy_config, decrypted_credentials=raw_credentials)
            return await transient_adapter.test_connection()
        except Exception as exc:
            return ConnectionTestResult(success=False, latency_ms=0.0, message=f"Probe failed: {exc}")

    async def list_audit_logs(
        self,
        db: AsyncSession,
        tool_identifier: Optional[str] = None
    ) -> List[MonitoringConfigAuditLog]:
        """Lists configuration audit logs."""
        stmt = select(MonitoringConfigAuditLog).order_by(MonitoringConfigAuditLog.created_at.desc())
        if tool_identifier:
            stmt = stmt.where(MonitoringConfigAuditLog.tool_identifier == tool_identifier)
        res = await db.execute(stmt)
        return list(res.scalars().all())

    async def hot_load_adapter(
        self,
        config: MonitoringToolConfig,
        credentials: Optional[Dict[str, Any]] = None
    ):
        """Instantiates an adapter and injects it into the live registry."""
        try:
            adapter = AdapterFactory.create_adapter(config, decrypted_credentials=credentials)
            adapter_registry.register_adapter(adapter)
            logger.info(f"Centralized Monitoring: Hot-loaded adapter '{config.tool_identifier}' successfully.")
        except Exception as exc:
            logger.error(f"Failed to hot-load adapter '{config.tool_identifier}': {exc}")

    async def bootstrap_default_configs(self, db: AsyncSession):
        """
        Seeds default initial integrations into monitoring_tool_configs if the table is empty.
        Ensures existing Prometheus and PostgreSQL installations work seamlessly out-of-the-box.
        """
        existing = await self.list_configs(db)
        if existing:
            return

        logger.info("Centralized Monitoring: Seeding default configuration records from environment...")
        prom_url = getattr(settings, "PROMETHEUS_URL", "http://localhost:9090")
        prom_timeout = getattr(settings, "PROMETHEUS_TIMEOUT", 5.0)

        # 1. Prometheus Default
        prom_config = MonitoringToolConfig(
            tool_identifier="prometheus-core",
            tool_type=MonitoringToolType.PROMETHEUS,
            display_name="Prometheus Server & Exporters",
            description="Primary Prometheus server scraping Windows, Linux, and SQLite exporters.",
            is_enabled=getattr(settings, "PROMETHEUS_ENABLED", True),
            base_url=prom_url,
            timeout_seconds=prom_timeout,
            auth_type=MonitoringAuthType.NONE,
            capabilities=[
                "INFRASTRUCTURE", "SERVER", "APPLICATION", "DATABASE", "ALERTS", "HISTORICAL_METRICS"
            ],
            environment_scope=["ALL"],
            priority=1,
            is_default_for_scope=True,
            scrape_interval_seconds=getattr(settings, "PROMETHEUS_SCRAPE_INTERVAL_SECONDS", 15),
            health_check_path="/-/healthy",
            modified_by="system-bootstrap"
        )
        db.add(prom_config)

        # 2. PostgreSQL Default (if enabled and reachable)
        if getattr(settings, "POSTGRES_ENABLED", True):
            host = getattr(settings, "postgres_effective_host", "localhost")
            port = getattr(settings, "POSTGRES_PORT", 5432)
            pg_avail = is_postgres_available()
            pg_config = MonitoringToolConfig(
                tool_identifier="postgres-core",
                tool_type=MonitoringToolType.CUSTOM,  # Mapped to DATABASE
                display_name="PostgreSQL Database Monitor",
                description="Live PostgreSQL connection, buffer pool, lock contention, and storage telemetry.",
                is_enabled=pg_avail,
                base_url=f"postgresql://{host}:{port}",
                timeout_seconds=getattr(settings, "POSTGRES_CONNECT_TIMEOUT", 5.0),
                auth_type=MonitoringAuthType.BASIC_AUTH,
                encrypted_credentials=self.encrypt_credentials({
                    "user": getattr(settings, "POSTGRES_USER", "postgres"),
                    "password": getattr(settings, "POSTGRES_PASSWORD", "postgres")
                }),
                capabilities=["DATABASE", "ALERTS", "HISTORICAL_METRICS"],
                environment_scope=["ALL"],
                priority=2,
                is_default_for_scope=False,
                scrape_interval_seconds=15,
                modified_by="system-bootstrap"
            )
            db.add(pg_config)

        await db.commit()
        logger.info("Centralized Monitoring: Default integrations seeded successfully.")

    async def sync_all_adapters_from_db(self, db: AsyncSession):
        """Loads all active configurations from DB into the live Dynamic Adapter Registry."""
        await self.bootstrap_default_configs(db)
        configs = await self.list_configs(db)
        for cfg in configs:
            if cfg.is_enabled:
                creds = self.decrypt_credentials(cfg.encrypted_credentials)
                await self.hot_load_adapter(cfg, creds)


monitoring_config_service = MonitoringConfigService()
