from typing import List, Optional, Dict, Any, Union
from datetime import datetime, timezone
from pydantic import BaseModel, Field


# =============================================================================
# 1. DATA FRESHNESS MODEL
# =============================================================================

class DataFreshness(BaseModel):
    """Normalized freshness telemetry for real-time observability."""
    age_seconds: float = 0.0
    status: str = "FRESH"  # FRESH, STALE, UNKNOWN
    threshold_seconds: float = 60.0


# =============================================================================
# 2. NORMALIZED METRIC MODEL
# =============================================================================

class NormalizedMetric(BaseModel):
    """
    Standardized, provider-independent monitoring metric.
    Decoupled from Prometheus, OpenMetrics, or any specific TSDB.
    """
    source: str = "prometheus"
    provider: str = "PrometheusAdapter"
    environment: Optional[str] = "Default"
    environment_id: Optional[str] = None
    environment_type: Optional[str] = None
    application: Optional[str] = None
    service: Optional[str] = None
    component: Optional[str] = None
    server: Optional[str] = None
    host: Optional[str] = None
    database: Optional[str] = None
    resource: str
    resource_id: Optional[str] = None
    resource_type: str = "SERVER"  # SERVER, DATABASE, DATABASE_TABLE, APPLICATION, SERVICE, EXPORTER
    metric_category: str = "INFRASTRUCTURE"  # INFRASTRUCTURE, DATABASE, STORAGE, APPLICATION, NETWORK
    metric_name: str
    value: float
    unit: str = "%"  # %, bytes, ms, rps, count, status, rows
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    labels: Dict[str, str] = Field(default_factory=dict)
    status: str = "HEALTHY"  # HEALTHY, WARNING, DEGRADED, CRITICAL, DOWN, UNKNOWN
    severity: str = "INFO"  # INFO, LOW, MEDIUM, HIGH, CRITICAL
    data_freshness: DataFreshness = Field(default_factory=DataFreshness)


# =============================================================================
# 3. NORMALIZED RESOURCE MODEL
# =============================================================================

class NormalizedResource(BaseModel):
    """
    Normalized monitoring resource entity with stable identity.
    Represents monitored databases, tables, servers, applications, exporters, or targets.
    """
    id: str
    name: str
    type: str  # database, database_table, server, application, service, exporter, target
    technology: str = "generic"  # sqlite, postgresql, linux, windows, spring-boot, nodejs
    monitoring_source: str = "prometheus"
    status: str = "HEALTHY"  # HEALTHY, WARNING, DEGRADED, CRITICAL, DOWN, UNKNOWN
    is_up: bool = True
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    endpoint_url: Optional[str] = None
    labels: Dict[str, str] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    metrics_summary: Dict[str, Any] = Field(default_factory=dict)
    last_updated: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    data_freshness: DataFreshness = Field(default_factory=DataFreshness)


# =============================================================================
# 4. NORMALIZED OVERVIEW MODEL
# =============================================================================

class NormalizedOverview(BaseModel):
    """
    Enterprise executive monitoring overview.
    All values originate strictly from live monitoring telemetry.
    """
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    environment_count: int = 0
    healthy_environment_count: int = 0
    warning_environment_count: int = 0
    degraded_environment_count: int = 0
    critical_environment_count: int = 0
    down_environment_count: int = 0
    active_alert_count: int = 0
    critical_alert_count: int = 0
    monitoring_target_count: int = 0
    healthy_target_count: int = 0
    active_providers_count: int = 0
    healthy_providers_count: int = 0
    total_metrics_discovered: int = 0
    data_freshness: DataFreshness = Field(default_factory=DataFreshness)


# =============================================================================
# 5. DYNAMIC METRIC DISCOVERY SCHEMAS
# =============================================================================

class DiscoveredMetric(BaseModel):
    """Metadata describing a dynamically discovered metric family."""
    name: str
    type: str = "gauge"  # gauge, counter, summary, histogram, untyped
    help_text: Optional[str] = None
    unit: Optional[str] = None
    category: str = "GENERAL"
    sample_value: Optional[float] = None
    labels: List[str] = Field(default_factory=list)


class DynamicMetricCatalog(BaseModel):
    """Complete catalog of metrics dynamically discovered from active monitoring providers."""
    source: str
    total_count: int
    metrics: List[DiscoveredMetric] = Field(default_factory=list)
    categories: List[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# =============================================================================
# 6. NORMALIZED TIME-SERIES FOR APACHE ECHARTS
# =============================================================================

class TimeSeriesPoint(BaseModel):
    """Single timestamped point for chart rendering."""
    timestamp: str  # ISO-8601 string or formatted label
    value: float


class TimeSeriesTelemetrySeries(BaseModel):
    """Named series with statistical aggregations for ECharts."""
    name: str
    unit: str = "%"
    points: List[TimeSeriesPoint] = Field(default_factory=list)
    current: float = 0.0
    avg: float = 0.0
    peak: float = 0.0
    min_val: float = 0.0


class NormalizedTimeSeriesResponse(BaseModel):
    """Normalized time-series response strictly decoupled from TSDB engine."""
    resource_id: Optional[str] = None
    resource_name: Optional[str] = None
    environment_id: Optional[str] = None
    timeframe: str = "1h"
    start_time: str
    end_time: str
    step: str = "15s"
    series: Dict[str, TimeSeriesTelemetrySeries] = Field(default_factory=dict)


# =============================================================================
# 7. NORMALIZED ALERT MODEL
# =============================================================================

class NormalizedAlert(BaseModel):
    """Provider-independent alert notification structure."""
    alert_id: str
    source: str = "prometheus"
    resource: str
    environment: Optional[str] = None
    metric: str
    condition: str
    severity: str = "WARNING"  # CRITICAL, HIGH, WARNING, INFO
    status: str = "ACTIVE"  # ACTIVE, ACKNOWLEDGED, RESOLVED
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: Optional[datetime] = None
    acknowledged_at: Optional[datetime] = None
    resolved_at: Optional[datetime] = None
    message: str
    labels: Dict[str, str] = Field(default_factory=dict)
    annotations: Dict[str, str] = Field(default_factory=dict)


# =============================================================================
# 8. INTEGRATION LAYER OPERATIONAL SELF-METRICS
# =============================================================================

class OperationalMetricsSummary(BaseModel):
    """Telemetry describing the health, throughput, and latency of the monitoring layer itself."""
    uptime_seconds: float
    total_api_requests: int
    api_request_duration_avg_ms: float
    total_provider_queries: int
    provider_query_errors: int
    provider_query_duration_avg_ms: float
    registered_providers: List[str]
    active_providers: List[str]
    cache_hit_ratio: float = 0.0
    last_freshness_seconds: float = 0.0


# =============================================================================
# 9. NORMALIZED SERVER & THRESHOLD MONITORING MODELS
# =============================================================================

class Server(BaseModel):
    """Normalized server identity and status."""
    id: str
    name: str
    hostname: str
    ip_address: str
    os_type: str = "WINDOWS"  # WINDOWS, LINUX
    os_version: Optional[str] = None
    environment_id: str
    environment_name: str
    status: str = "UP"  # UP, DOWN, DEGRADED, UNREACHABLE
    is_exporter_available: bool = True
    exporter_type: str = "WINDOWS_EXPORTER"
    monitoring_source: str = "Prometheus/WindowsExporter"
    system_uptime_seconds: Optional[float] = None
    system_boot_time: Optional[datetime] = None
    last_scrape_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metric_freshness_seconds: float = 0.0
    restart_detected: bool = False
    hosted_applications: List[str] = Field(default_factory=list)


class ServerMetric(BaseModel):
    """Normalized metric measurement for servers."""
    server_id: str
    metric_category: str  # CPU, CORE, MEMORY, DISK_VOLUME, DISK_IO, NETWORK, AVAILABILITY, SERVICE, PROCESS
    metric_name: str
    value: float
    unit: str  # %, GB, MB, KB/s, MB/s, count, ms, status
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    labels: Dict[str, str] = Field(default_factory=dict)
    status: str = "HEALTHY"  # HEALTHY, WARNING, CRITICAL, DOWN
    data_freshness_seconds: float = 0.0


class ServerResource(BaseModel):
    """Normalized server hardware/software sub-resource."""
    id: str
    server_id: str
    resource_type: str  # LOGICAL_CORE, DISK_VOLUME, NETWORK_INTERFACE, SERVICE, PROCESS
    name: str
    capacity: Optional[float] = None
    used: Optional[float] = None
    free: Optional[float] = None
    utilization_pct: Optional[float] = None
    free_pct: Optional[float] = None
    unit: str = "%"
    status: str = "HEALTHY"  # HEALTHY, WARNING, CRITICAL, DOWN
    details: Dict[str, Any] = Field(default_factory=dict)


class ServerHealth(BaseModel):
    """Multi-dimensional health evaluation for a server."""
    server_id: str
    overall_status: str = "HEALTHY"  # HEALTHY, WARNING, CRITICAL, DOWN
    health_score: float = 100.0  # 0 to 100
    cpu_status: str = "HEALTHY"
    memory_status: str = "HEALTHY"
    disk_status: str = "HEALTHY"
    network_status: str = "HEALTHY"
    services_status: str = "HEALTHY"
    exporter_status: str = "HEALTHY"
    freshness_status: str = "FRESH"  # FRESH, STALE
    active_alerts_count: int = 0
    warning_count: int = 0
    critical_count: int = 0
    evaluated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ServerThreshold(BaseModel):
    """Configurable threshold rule for server metrics."""
    id: str
    server_id: Optional[str] = None  # None or "ALL" for all servers
    name: str
    metric_category: str  # CPU, CORE, MEMORY, DISK_VOLUME, DISK_IO, NETWORK, AVAILABILITY, SERVICE
    target_resource: Optional[str] = "ALL"  # "ALL", "Core 0", "C:", "Ethernet", service name
    operator: str = ">"  # >, <, >=, <=, ==
    warning_threshold: float
    critical_threshold: float
    severe_threshold: Optional[float] = None
    duration_minutes: int = 2
    unit: str = "%"
    is_enabled: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: Optional[datetime] = None


class ServerThresholdCreate(BaseModel):
    """Payload to create or update server threshold."""
    name: str
    server_id: Optional[str] = None
    metric_category: str
    target_resource: Optional[str] = "ALL"
    operator: str = ">"
    warning_threshold: float
    critical_threshold: float
    severe_threshold: Optional[float] = None
    duration_minutes: int = 2
    unit: str = "%"
    is_enabled: bool = True


class ServerAlert(BaseModel):
    """Normalized active or historical alert for a server."""
    alert_id: str
    fingerprint: Optional[str] = None
    server_id: str
    server_name: str
    resource: str  # CPU, Core 1, Volume C:, Interface eth0
    metric_name: str
    condition: str
    current_value: Optional[float] = None
    threshold_value: Optional[float] = None
    severity: str = "WARNING"  # WARNING, CRITICAL, SEVERE, INFO
    status: str = "ACTIVE"  # ACTIVE, ACKNOWLEDGED, RESOLVED
    message: str
    labels: Dict[str, str] = Field(default_factory=dict)
    annotations: Dict[str, str] = Field(default_factory=dict)
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    acknowledged_at: Optional[datetime] = None
    acknowledged_by: Optional[str] = None
    resolved_at: Optional[datetime] = None


class ServerAvailability(BaseModel):
    """Server, exporter, and Prometheus target availability metrics."""
    server_id: str
    hostname: str
    ip_address: str
    is_reachable: bool = True
    exporter_status: str = "UP"  # UP, DOWN
    target_health: str = "UP"  # UP, DOWN, UNKNOWN
    scrape_duration_ms: float = 0.0
    last_scrape_time: Optional[datetime] = None
    metric_freshness_seconds: float = 0.0
    restart_detected: bool = False
    system_uptime_seconds: float = 0.0
    uptime_formatted: str = "N/A"

