import enum
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from pydantic import BaseModel, Field


# =========================================================================
# 1. CORE UNIFIED METRIC SAMPLE
# =========================================================================

class MetricAvailabilityState(str, enum.Enum):
    ACTIVE_VALUE = "ACTIVE_VALUE"
    ZERO_VALUE = "ZERO_VALUE"
    UNSUPPORTED = "UNSUPPORTED"
    UNAVAILABLE = "UNAVAILABLE"
    STALE = "STALE"


class UnifiedMetricSample(BaseModel):
    """
    Standardized telemetry metric sample conforming to the Unified Monitoring Model.
    Decoupled from specific monitoring backends (Prometheus, APM, etc.).
    Supports explicit 4-state availability (ACTIVE_VALUE, ZERO_VALUE, UNSUPPORTED, UNAVAILABLE, STALE).
    """
    environment: str
    environment_id: str
    target: str
    target_type: str = "SERVER"  # SERVER, APPLICATION, DATABASE, SERVICE, CONTAINER, MIDDLEWARE, CUSTOM
    server: Optional[str] = None
    application: Optional[str] = None
    service: Optional[str] = None
    metric: str
    metric_type: str = "GAUGE"  # GAUGE, COUNTER, HISTOGRAM, SUMMARY
    value: Optional[float] = 0.0
    unit: str  # percent, milliseconds, req/s, bytes, count, status
    availability_state: MetricAvailabilityState = MetricAvailabilityState.ACTIVE_VALUE
    unsupported_reason: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    status: str = "HEALTHY"  # HEALTHY, WARNING, CRITICAL, UNKNOWN
    severity: str = "INFO"  # LOW, MEDIUM, HIGH, CRITICAL, INFO
    source: str = "prometheus"  # prometheus, app-monitor, server-monitor, custom, apm
    provider: str = "PrometheusAdapter"
    labels: Dict[str, str] = Field(default_factory=dict)
    dimensions: Dict[str, str] = Field(default_factory=dict)
    threshold: Optional[Dict[str, float]] = None  # e.g. {"warning": 75.0, "critical": 90.0}
    alert_state: Optional[str] = None
    health_state: Optional[str] = None
    availability: Optional[float] = None
    data_freshness_seconds: float = 0.0
    freshness_status: str = "FRESH"  # FRESH, STALE, EXPIRED


# =========================================================================
# 2. APPLICATION MONITORING SCHEMAS
# =========================================================================

class ApplicationDependencyInfo(BaseModel):
    """Monitored application dependency (Downstream API, Database, Queue, External Service)."""
    name: str
    dependency_type: str  # DATABASE, REST_API, MESSAGE_QUEUE, EXTERNAL_SERVICE
    endpoint: str
    status: str = "HEALTHY"  # HEALTHY, WARNING, DOWN, UNKNOWN
    latency_ms: float = 12.0
    error_count: int = 0
    last_checked: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ApplicationRuntimeResources(BaseModel):
    """Runtime / JVM / Process level resource consumption."""
    jvm_heap_used_mb: float = 0.0
    jvm_heap_max_mb: float = 0.0
    jvm_heap_utilization_pct: float = 0.0
    thread_count: int = 0
    thread_peak_count: int = 0
    active_db_connections: int = 0
    max_db_connections: int = 0
    gc_pause_ms: float = 0.0
    gc_count: int = 0
    process_cpu_pct: float = 0.0
    process_memory_mb: float = 0.0
    process_virtual_memory_mb: float = 0.0
    open_file_descriptors: int = 0
    runtime_type: str = "PYTHON"


class ApplicationPerformanceMetrics(BaseModel):
    """Application performance indicators."""
    response_time_ms: float = 0.0
    p50_latency_ms: float = 0.0
    p90_latency_ms: float = 0.0
    p95_latency_ms: float = 0.0
    p99_latency_ms: float = 0.0
    request_rate_rps: float = 0.0
    throughput_rps: float = 0.0
    error_rate_pct: float = 0.0
    total_requests: int = 0
    active_requests: int = 0
    http_2xx_count: int = 0
    http_4xx_count: int = 0
    http_5xx_count: int = 0
    slow_requests_count: int = 0


class ApplicationAvailabilityMetrics(BaseModel):
    """Application availability status."""
    is_up: bool = True
    health_status: str = "HEALTHY"  # HEALTHY, DEGRADED, DOWN, UNKNOWN
    uptime_pct: float = 0.0
    startup_status: str = "READY"  # STARTING, READY, FAILED
    readiness_status: str = "READY"
    endpoint_availability_pct: float = 0.0
    last_heartbeat: Optional[datetime] = Field(default_factory=lambda: datetime.now(timezone.utc))


class ApplicationMonitoringDossier(BaseModel):
    """Comprehensive application monitoring dossier exposed by TEM Monitoring API."""
    id: str
    name: str
    application_name: Optional[str] = None
    software_name: Optional[str] = None
    category: Optional[str] = None
    environment_id: str
    environment_name: str
    version: str = "1.0.0"
    hosted_on_server: str
    hosted_on_server_id: Optional[str] = None
    server_ip: Optional[str] = None
    runtime: str = "PYTHON"
    monitoring_source: str = "ApplicationMonitoringAdapter"
    
    # Sub-metrics
    availability: ApplicationAvailabilityMetrics
    performance: ApplicationPerformanceMetrics
    resources: ApplicationRuntimeResources
    dependencies: List[ApplicationDependencyInfo] = Field(default_factory=list)
    
    # Active alerts
    active_alerts_count: int = 0
    active_alerts: List[Dict[str, Any]] = Field(default_factory=list)
    metric_freshness_seconds: float = 1.5


# =========================================================================
# 3. SERVER MONITORING SCHEMAS
# =========================================================================

class ServerCpuMetrics(BaseModel):
    """Detailed CPU telemetry for Linux / Windows servers."""
    utilization_pct: float = 0.0
    idle_pct: float = 0.0
    cores_count: int = 1
    load_1m: float = 0.0
    load_5m: float = 0.0
    load_15m: float = 0.0
    saturation_pct: float = 0.0
    trend: str = "STABLE"  # INCREASING, DECREASING, STABLE
    per_core_utilization: Optional[List[Dict[str, Any]]] = None


class ServerMemoryMetrics(BaseModel):
    """Detailed memory telemetry."""
    total_gb: float = 0.0
    used_gb: float = 0.0
    available_gb: float = 0.0
    utilization_pct: float = 0.0
    swap_total_gb: float = 0.0
    swap_used_gb: float = 0.0
    swap_utilization_pct: float = 0.0


class ServerDiskMetrics(BaseModel):
    """Disk storage and I/O telemetry."""
    total_gb: float = 0.0
    used_gb: float = 0.0
    free_gb: float = 0.0
    utilization_pct: float = 0.0
    free_pct: float = 0.0
    read_throughput_mb_s: float = 0.0
    write_throughput_mb_s: float = 0.0
    iops: float = 0.0
    latency_ms: float = 0.0
    queue_length: float = 0.0
    busy_pct: float = 0.0
    mount_point: str = "C:"
    volumes: Optional[List[Dict[str, Any]]] = None


class ServerNetworkMetrics(BaseModel):
    """Network interface telemetry."""
    utilization_pct: float = 0.0
    rx_rate_kb_s: float = 0.0
    tx_rate_kb_s: float = 0.0
    total_traffic_kb_s: float = 0.0
    packets_rx_per_sec: float = 0.0
    packets_tx_per_sec: float = 0.0
    packet_errors: int = 0
    packet_drops: int = 0
    interfaces: Optional[List[Dict[str, Any]]] = None


class ServerProcessItem(BaseModel):
    """Monitored OS process."""
    pid: int
    name: str
    status: str = "RUNNING"
    cpu_pct: float = 0.0
    memory_mb: float = 0.0
    restart_count: int = 0


class ServerMonitoringDossier(BaseModel):
    """Comprehensive server monitoring dossier exposed by TEM Monitoring API."""
    id: str
    name: str
    hostname: str
    ip_address: str
    os_type: str = "WINDOWS"  # LINUX, WINDOWS
    environment_id: str
    environment_name: str
    status: str = "UP"  # UP, DOWN, DEGRADED, UNREACHABLE
    is_exporter_available: bool = True
    exporter_type: str = "WINDOWS_EXPORTER"
    monitoring_source: str = "ServerMonitoringAdapter"
    last_scrape_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metric_freshness_seconds: float = 0.0
    system_uptime_seconds: Optional[float] = None
    system_boot_time: Optional[datetime] = None
    restart_detected: bool = False
    os_version: Optional[str] = None
    
    # Sub-metrics
    cpu: ServerCpuMetrics
    memory: ServerMemoryMetrics
    disk: ServerDiskMetrics
    network: ServerNetworkMetrics
    processes: List[ServerProcessItem] = Field(default_factory=list)
    services: Optional[List[Dict[str, Any]]] = None
    performance_indicators: Optional[Dict[str, Any]] = None
    
    # Hosted Applications Relationship
    hosted_applications: List[str] = Field(default_factory=list)
    hosted_applications_count: int = 0
    
    # Active alerts
    active_alerts_count: int = 0
    active_alerts: List[Dict[str, Any]] = Field(default_factory=list)


# =========================================================================
# 4. APPLICATION-TO-SERVER TOPOLOGY RELATIONSHIP
# =========================================================================

class HostedAppSummary(BaseModel):
    app_id: str
    app_name: str
    application_name: Optional[str] = None
    software_name: Optional[str] = None
    category: Optional[str] = None
    version: Optional[str] = None
    status: str
    response_time_ms: float
    error_rate_pct: float


class ServerTopologyNode(BaseModel):
    server_id: str
    server_name: str
    ip_address: str
    os_type: str
    status: str
    cpu_pct: float
    memory_pct: float
    disk_pct: float
    hosted_applications: List[HostedAppSummary] = Field(default_factory=list)


class AppServerTopologyMap(BaseModel):
    """Bidirectional application-to-server relationship mapping for an environment."""
    environment_id: str
    environment_name: str
    total_servers: int = 0
    total_applications: int = 0
    servers: List[ServerTopologyNode] = Field(default_factory=list)


# =========================================================================
# 5. ENVIRONMENT READINESS & HEALTH ASSESSMENT
# =========================================================================

class ReadinessGateItem(BaseModel):
    gate_name: str
    description: str
    status: str = "PASSED"  # PASSED, FAILED, WARNING
    passed: bool = True
    details: str = "Passed operational criteria"


class EnvironmentReadinessAssessment(BaseModel):
    """Automated environment test readiness assessment based on normalized telemetry."""
    environment_id: str
    environment_name: str
    status: str = "READY_FOR_TESTING"  # READY_FOR_TESTING, PARTIALLY_READY, NOT_READY
    overall_readiness_score: int = 100
    passed_gates_count: int = 8
    total_gates_count: int = 8
    gates: List[ReadinessGateItem] = Field(default_factory=list)
    blocking_reasons: List[str] = Field(default_factory=list)
    evaluated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# =========================================================================
# 6. MONITORING SOURCE HEALTH SCHEMAS
# =========================================================================

class MonitoringSourceHealth(BaseModel):
    """Health and status of an external or in-house monitoring source / adapter."""
    source_id: str
    source_name: str
    adapter_name: str
    source_type: str  # PROMETHEUS, APM, SERVER_TOOL, CUSTOM
    status: str = "HEALTHY"  # HEALTHY, WARNING, DOWN, UNKNOWN
    connectivity: bool = True
    api_available: bool = True
    latency_ms: float = 18.0
    data_freshness_seconds: float = 2.5
    last_sync_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    query_failures_count: int = 0
    error_message: Optional[str] = None


# =========================================================================
# 7. TEST EXECUTION CORRELATION SCHEMAS
# =========================================================================

class MetricComparisonValue(BaseModel):
    metric_name: str
    before_test: float
    during_test: float
    unit: str
    variance_pct: float
    threshold: float
    is_saturated: bool = False


class TestCorrelationAnalysis(BaseModel):
    """Correlation between test suite execution and live environment telemetry."""
    test_run_id: str
    test_suite_name: str
    test_phase: str = "REGRESSION"
    environment_id: str
    environment_name: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    status: str = "FAILED"  # PASSED, FAILED, RUNNING
    
    # Telemetry metrics comparison: Before vs During Test
    application_response_time: MetricComparisonValue
    server_cpu: MetricComparisonValue
    server_memory: MetricComparisonValue
    application_error_rate: MetricComparisonValue
    
    # Diagnosis conclusion
    is_environment_caused: bool = True
    diagnostic_verdict: str  # e.g., "Potential server resource saturation: Host CPU 94% caused application latency spike"
    recommended_action: str
    correlated_incidents: List[str] = Field(default_factory=list)


# =========================================================================
# 8. HISTORICAL TELEMETRY SCHEMAS FOR ECHARTS
# =========================================================================

class HistoricalDataPoint(BaseModel):
    timestamp: str  # ISO string or formatted time
    value: float


class HistoricalSeries(BaseModel):
    name: str
    unit: str
    points: List[HistoricalDataPoint] = Field(default_factory=list)
    current: float = 0.0
    avg: float = 0.0
    peak: float = 0.0
    min_val: float = 0.0


class UnifiedHistoricalTelemetry(BaseModel):
    """Historical time-series telemetry designed for native Apache ECharts consumption."""
    environment_id: str
    target_id: Optional[str] = None
    target_name: Optional[str] = None
    timeframe: str = "1h"  # 15m, 1h, 6h, 24h, 7d, custom
    interval_seconds: int = 60
    series: Dict[str, HistoricalSeries] = Field(default_factory=dict)
