from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from pydantic import BaseModel, Field, HttpUrl
from app.models.monitoring_config import MonitoringToolType, MonitoringAuthType, MonitoringCapability


class ConnectionTestResult(BaseModel):
    """Result of an active probe before enabling a tool configuration."""
    success: bool
    latency_ms: float
    message: str
    discovered_capabilities: List[str] = Field(default_factory=list)
    raw_probe_details: Optional[Dict[str, Any]] = None


class MonitoringToolConfigBase(BaseModel):
    tool_identifier: str = Field(..., pattern=r"^[a-zA-Z0-9_\-\.]{3,64}$")
    tool_type: MonitoringToolType
    display_name: str
    description: Optional[str] = None
    is_enabled: bool = True
    base_url: str
    tls_verify: bool = True
    ca_cert_path: Optional[str] = None
    timeout_seconds: float = Field(5.0, ge=0.5, le=60.0)
    retry_count: int = Field(3, ge=0, le=10)
    retry_backoff_factor: float = Field(0.5, ge=0.1, le=5.0)
    auth_type: MonitoringAuthType = MonitoringAuthType.NONE
    custom_headers: Dict[str, str] = Field(default_factory=dict)
    capabilities: List[str] = Field(default_factory=lambda: ["INFRASTRUCTURE", "SERVER"])
    metric_mappings: Dict[str, str] = Field(default_factory=dict)
    environment_scope: List[str] = Field(default_factory=lambda: ["ALL"])
    priority: int = Field(1, ge=1, le=100)
    is_default_for_scope: bool = False
    scrape_interval_seconds: int = Field(15, ge=5, le=3600)
    health_check_path: str = "/health"
    health_check_interval_seconds: int = Field(30, ge=5, le=3600)
    tool_parameters: Dict[str, Any] = Field(default_factory=dict)
    target_assignments: Dict[str, Any] = Field(default_factory=dict)


class MonitoringToolConfigCreate(MonitoringToolConfigBase):
    credentials: Optional[Dict[str, Any]] = None


class MonitoringToolConfigUpdate(BaseModel):
    display_name: Optional[str] = None
    description: Optional[str] = None
    is_enabled: Optional[bool] = None
    base_url: Optional[str] = None
    tls_verify: Optional[bool] = None
    ca_cert_path: Optional[str] = None
    timeout_seconds: Optional[float] = Field(None, ge=0.5, le=60.0)
    retry_count: Optional[int] = Field(None, ge=0, le=10)
    retry_backoff_factor: Optional[float] = Field(None, ge=0.1, le=5.0)
    auth_type: Optional[MonitoringAuthType] = None
    credentials: Optional[Dict[str, Any]] = None
    custom_headers: Optional[Dict[str, str]] = None
    capabilities: Optional[List[str]] = None
    metric_mappings: Optional[Dict[str, str]] = None
    environment_scope: Optional[List[str]] = None
    priority: Optional[int] = Field(None, ge=1, le=100)
    is_default_for_scope: Optional[bool] = None
    scrape_interval_seconds: Optional[int] = Field(None, ge=5, le=3600)
    health_check_path: Optional[str] = None
    health_check_interval_seconds: Optional[int] = Field(None, ge=5, le=3600)
    tool_parameters: Optional[Dict[str, Any]] = None
    target_assignments: Optional[Dict[str, Any]] = None


class MonitoringToolConfigOut(MonitoringToolConfigBase):
    id: str
    masked_credentials: Dict[str, str] = Field(default_factory=dict)
    version: int
    modified_by: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class MonitoringConfigToggleRequest(BaseModel):
    is_enabled: bool


class MonitoringConfigAuditLogOut(BaseModel):
    id: str
    config_id: str
    tool_identifier: str
    action: str
    changed_fields: Dict[str, Any]
    performed_by: str
    ip_address: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True
