import pytest
from app.adapters.monitoring.prometheus_client import (
    PrometheusClient,
    PrometheusClientError,
    PrometheusConnectionError,
    PrometheusTimeoutError,
    PrometheusQueryError
)


@pytest.mark.asyncio
async def test_prometheus_client_health():
    client = PrometheusClient()
    is_healthy, latency_ms, err = await client.check_health()
    assert is_healthy is True
    assert latency_ms >= 0.0
    assert err is None


@pytest.mark.asyncio
async def test_prometheus_client_query_instant():
    client = PrometheusClient()
    # Query database up metric or prometheus up
    res = await client.query_instant("up")
    assert "resultType" in res
    assert "result" in res
    assert len(res["result"]) >= 1


@pytest.mark.asyncio
async def test_prometheus_client_targets():
    client = PrometheusClient()
    targets = await client.get_targets()
    assert isinstance(targets, list)
    assert len(targets) >= 1
    # Check that sqlite exporter or prometheus is present
    labels = [t.get("labels", {}).get("job") for t in targets]
    assert any("sqlite" in (l or "") or "prometheus" in (l or "") for l in labels)


@pytest.mark.asyncio
async def test_prometheus_client_metric_discovery():
    client = PrometheusClient()
    metrics = await client.get_metric_names()
    assert isinstance(metrics, list)
    assert len(metrics) > 0
    # sqlite metrics should be among discovered metrics
    sqlite_metrics = [m for m in metrics if "sqlite" in m]
    assert len(sqlite_metrics) >= 5


@pytest.mark.asyncio
async def test_prometheus_client_invalid_connection():
    # Connecting to non-existent port should raise PrometheusConnectionError
    bad_client = PrometheusClient(base_url="http://localhost:59999", timeout=1.0)
    is_healthy, latency, err = await bad_client.check_health()
    assert is_healthy is False
    assert err is not None

    with pytest.raises(PrometheusClientError):
        await bad_client.query_instant("up")
