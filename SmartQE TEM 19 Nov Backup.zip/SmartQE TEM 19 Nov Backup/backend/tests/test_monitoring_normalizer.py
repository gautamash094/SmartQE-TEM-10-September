import time
import pytest
from app.adapters.monitoring.normalizer import normalizer


def test_sqlite_database_metric_normalization():
    norm = normalizer.normalize_metric(
        raw_name="sqlite_database_up",
        value=1.0,
        timestamp=time.time(),
        labels={"database": "sqlite", "job": "smartqe-tem-sqlite"},
        source="prometheus",
        provider="PrometheusAdapter",
        environment_id="env-01",
        environment_name="TEST-01"
    )
    assert norm.resource_type == "database"
    assert norm.metric_category == "DATABASE"
    assert norm.metric_name == "database_availability"
    assert norm.value == 1.0
    assert norm.unit == "status"
    assert norm.status == "HEALTHY"
    assert norm.data_freshness.status == "FRESH"


def test_sqlite_table_metric_normalization():
    norm = normalizer.normalize_metric(
        raw_name="sqlite_table_rows_total",
        value=142.0,
        timestamp=time.time(),
        labels={"table": "environment_profiles", "database": "sqlite"},
        source="prometheus",
        provider="PrometheusAdapter"
    )
    assert norm.resource_type == "database_table"
    assert norm.metric_name == "table_row_count"
    assert norm.value == 142.0
    assert norm.unit == "rows"
    assert norm.status == "HEALTHY"
    assert "environment_profiles" in norm.resource


def test_stale_data_detection():
    # Timestamp 120 seconds in the past should be STALE
    old_ts = time.time() - 120.0
    norm = normalizer.normalize_metric(
        raw_name="sqlite_database_size_bytes",
        value=5242880.0,
        timestamp=old_ts,
        labels={"database": "sqlite"}
    )
    assert norm.data_freshness.age_seconds >= 100.0
    assert norm.data_freshness.status == "STALE"


def test_extract_resources_from_metrics():
    now = time.time()
    m1 = normalizer.normalize_metric("sqlite_database_up", 1.0, now, {"database": "sqlite"})
    m2 = normalizer.normalize_metric("sqlite_database_size_bytes", 5000000.0, now, {"database": "sqlite"})
    m3 = normalizer.normalize_metric("sqlite_table_rows_total", 50.0, now, {"table": "users", "database": "sqlite"})

    resources = normalizer.extract_resources_from_metrics([m1, m2, m3])
    res_ids = [r.id for r in resources]
    assert "db-sqlite" in res_ids
    assert "table-users" in res_ids

    db_res = next(r for r in resources if r.id == "db-sqlite")
    assert db_res.type == "database"
    assert db_res.is_up is True
    assert db_res.metrics_summary["database_availability"] == 1.0
