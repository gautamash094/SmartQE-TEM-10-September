import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.models.monitoring_config import MonitoringToolConfig, MonitoringToolType, MonitoringAuthType
from app.services.monitoring_config_service import monitoring_config_service
from app.adapters.monitoring.factory import AdapterFactory
from app.adapters.monitoring.prometheus_adapter import PrometheusAdapter
from app.adapters.monitoring.datadog_adapter import DatadogMonitoringAdapter
from app.adapters.monitoring.nagios_adapter import NagiosMonitoringAdapter
from app.schemas.unified_monitoring import MetricAvailabilityState


def step_coroutine(coro):
    """Executes a non-blocking coroutine synchronously without needing socket event loops."""
    try:
        coro.send(None)
    except StopIteration as exc:
        return exc.value


def test_encryption():
    raw = {"api_key": "dd_secret_key_1234567890", "app_key": "app_secret_abcd"}
    encrypted = monitoring_config_service.encrypt_credentials(raw)
    assert encrypted != ""
    decrypted = monitoring_config_service.decrypt_credentials(encrypted)
    assert decrypted["api_key"] == "dd_secret_key_1234567890"
    masked = monitoring_config_service.mask_credentials(decrypted)
    assert masked["api_key"] == "********7890"
    print("[PASS] 1. Credential encryption, decryption, and masking")


def test_factory():
    types = AdapterFactory.list_supported_tool_types()
    assert "PROMETHEUS" in types
    assert "DATADOG" in types
    assert "NAGIOS" in types
    print("[PASS] 2. Dynamic Adapter Factory registration (Prometheus, Datadog, Nagios)")


def test_nagios():
    adapter = NagiosMonitoringAdapter(
        provider_id="nagios-test",
        provider_name="Nagios Test",
        base_url="http://localhost:80"
    )
    metrics = step_coroutine(adapter.get_metrics(
        environment_id="env-01",
        metric_names=["jvm_heap_utilization_pct", "server_availability"]
    ))
    avail = next((m for m in metrics if m.metric == "server_availability"), None)
    assert avail is not None
    assert avail.availability_state == MetricAvailabilityState.ACTIVE_VALUE
    assert avail.value == 1.0

    jvm = next((m for m in metrics if m.metric == "jvm_heap_utilization_pct"), None)
    assert jvm is not None
    assert jvm.availability_state == MetricAvailabilityState.UNSUPPORTED
    assert jvm.value is None
    assert "does not collect JVM" in jvm.unsupported_reason
    print("[PASS] 3. Nagios unsupported metrics tagging (avoids misleading zero values)")


def test_fault_isolation():
    failing_dd = DatadogMonitoringAdapter(
        provider_id="dd-failing-probe",
        provider_name="Failing Datadog Endpoint",
        base_url="http://127.0.0.1:59999",
        timeout=0.2
    )
    # Probing without API key should immediately fail safely with pre-flight check
    conn_test = step_coroutine(failing_dd.test_connection())
    assert conn_test.success is False
    assert "api key is required" in conn_test.message.lower()
    print("[PASS] 4. Fault isolation & safe pre-activation validation")


if __name__ == "__main__":
    print("--- Starting Centralized Monitoring Architecture Verification ---")
    test_encryption()
    test_factory()
    test_nagios()
    test_fault_isolation()
    print("--- ALL 4 CENTRALIZED MONITORING VERIFICATION TESTS PASSED! ---")
