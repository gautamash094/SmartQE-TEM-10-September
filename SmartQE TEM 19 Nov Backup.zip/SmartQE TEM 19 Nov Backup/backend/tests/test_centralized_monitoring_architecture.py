import pytest
import json
from app.models.monitoring_config import MonitoringToolConfig, MonitoringToolType, MonitoringAuthType
from app.services.monitoring_config_service import monitoring_config_service
from app.adapters.monitoring.factory import AdapterFactory
from app.adapters.monitoring.registry import adapter_registry
from app.adapters.monitoring.prometheus_adapter import PrometheusAdapter
from app.adapters.monitoring.datadog_adapter import DatadogMonitoringAdapter
from app.adapters.monitoring.nagios_adapter import NagiosMonitoringAdapter
from app.schemas.unified_monitoring import MetricAvailabilityState


def test_credential_encryption_and_masking():
    """Validates that credentials are encrypted with AES-256 Fernet and masked in API outputs."""
    raw = {"api_key": "dd_secret_key_1234567890", "app_key": "app_secret_abcd"}
    encrypted = monitoring_config_service.encrypt_credentials(raw)
    assert encrypted != ""
    assert encrypted != json.dumps(raw)

    decrypted = monitoring_config_service.decrypt_credentials(encrypted)
    assert decrypted["api_key"] == "dd_secret_key_1234567890"
    assert decrypted["app_key"] == "app_secret_abcd"

    masked = monitoring_config_service.mask_credentials(decrypted)
    assert masked["api_key"] == "********7890"
    assert masked["app_key"] == "********abcd"


def test_adapter_factory_registration():
    """Validates that monitoring adapter classes register with the factory."""
    supported = AdapterFactory.list_supported_tool_types()
    assert "PROMETHEUS" in supported
    assert "DATADOG" in supported
    assert "NAGIOS" in supported

    prom_cls = AdapterFactory.get_adapter_class("PROMETHEUS")
    assert prom_cls == PrometheusAdapter

    dd_cls = AdapterFactory.get_adapter_class("DATADOG")
    assert dd_cls == DatadogMonitoringAdapter

    nag_cls = AdapterFactory.get_adapter_class("NAGIOS")
    assert nag_cls == NagiosMonitoringAdapter


@pytest.mark.asyncio
async def test_nagios_unsupported_metrics_tagging():
    """
    Validates the architectural requirement that unsupported metrics
    are explicitly tagged as UNSUPPORTED rather than misleading 0.0 values.
    """
    adapter = NagiosMonitoringAdapter(
        provider_id="nagios-test",
        provider_name="Nagios Test",
        base_url="http://localhost:80"
    )

    metrics = await adapter.get_metrics(
        environment_id="env-01",
        metric_names=["jvm_heap_utilization_pct", "server_availability"]
    )

    # 1. Server availability should be active
    avail = next((m for m in metrics if m.metric == "server_availability"), None)
    assert avail is not None
    assert avail.availability_state == MetricAvailabilityState.ACTIVE_VALUE
    assert avail.value == 1.0

    # 2. JVM metric should be explicitly marked UNSUPPORTED
    jvm_sample = next((m for m in metrics if m.metric == "jvm_heap_utilization_pct"), None)
    assert jvm_sample is not None
    assert jvm_sample.availability_state == MetricAvailabilityState.UNSUPPORTED
    assert jvm_sample.value is None
    assert "does not collect JVM" in jvm_sample.unsupported_reason


@pytest.mark.asyncio
async def test_fault_isolation_when_tool_fails():
    """
    Validates that if a monitoring source fails (network unreachable),
    it reports DOWN without throwing an unhandled exception or breaking platform health.
    """
    failing_dd = DatadogMonitoringAdapter(
        provider_id="dd-failing-probe",
        provider_name="Failing Datadog Endpoint",
        base_url="http://127.0.0.1:59999",  # Closed local port fails instantly
        timeout=0.2
    )

    health = await failing_dd.get_health()
    assert health.is_healthy is False
    assert health.status == "DOWN"
    assert "failed" in health.error_message.lower() or "connection" in health.error_message.lower()

    # Also verify test_connection probe fails safely
    conn_test = await failing_dd.test_connection()
    assert conn_test.success is False
