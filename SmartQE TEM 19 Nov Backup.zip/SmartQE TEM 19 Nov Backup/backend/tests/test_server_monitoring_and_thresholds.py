import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_list_normalized_servers(client: AsyncClient):
    response = await client.get("/api/v1/monitoring/normalized/servers")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert isinstance(data["data"], list)
    if len(data["data"]) > 0:
        srv = data["data"][0]
        assert "id" in srv
        assert "name" in srv
        assert "status" in srv
        assert "monitoring_source" in srv


@pytest.mark.asyncio
async def test_get_normalized_server_and_resources(client: AsyncClient):
    # 1. Get servers to retrieve valid server ID
    list_resp = await client.get("/api/v1/monitoring/normalized/servers")
    servers = list_resp.json()["data"]
    server_id = servers[0]["id"] if servers else "win-srv-default"

    # 2. Get server detail
    detail_resp = await client.get(f"/api/v1/monitoring/normalized/servers/{server_id}")
    assert detail_resp.status_code == 200
    srv = detail_resp.json()["data"]
    assert srv["id"] == server_id

    # 3. Get server resources
    res_resp = await client.get(f"/api/v1/monitoring/normalized/servers/{server_id}/resources")
    assert res_resp.status_code == 200
    resources = res_resp.json()["data"]
    assert isinstance(resources, list)


@pytest.mark.asyncio
async def test_get_server_health_and_availability(client: AsyncClient):
    server_id = "win-srv-default"

    # 1. Server Health
    health_resp = await client.get(f"/api/v1/monitoring/normalized/servers/{server_id}/health")
    assert health_resp.status_code == 200
    health = health_resp.json()["data"]
    assert "health_score" in health
    assert 0.0 <= health["health_score"] <= 100.0
    assert "overall_status" in health

    # 2. Server Availability
    avail_resp = await client.get(f"/api/v1/monitoring/normalized/servers/{server_id}/availability")
    assert avail_resp.status_code == 200
    avail = avail_resp.json()["data"]
    assert "is_reachable" in avail
    assert "exporter_status" in avail
    assert "uptime_formatted" in avail


@pytest.mark.asyncio
async def test_server_threshold_crud_and_sync(client: AsyncClient):
    server_id = "win-srv-test"

    # 1. Create Threshold
    payload = {
        "name": "E2ETestCpuThreshold",
        "server_id": server_id,
        "metric_category": "CPU",
        "target_resource": "ALL",
        "operator": ">",
        "warning_threshold": 75.0,
        "critical_threshold": 88.0,
        "severe_threshold": 96.0,
        "duration_minutes": 3,
        "unit": "%",
        "is_enabled": True
    }
    create_resp = await client.post(f"/api/v1/monitoring/normalized/servers/{server_id}/thresholds", json=payload)
    assert create_resp.status_code == 200
    created = create_resp.json()["data"]
    rule_id = created["id"]
    assert created["name"] == "E2ETestCpuThreshold"
    assert created["warning_threshold"] == 75.0

    # 2. Retrieve Thresholds for server
    get_resp = await client.get(f"/api/v1/monitoring/normalized/servers/{server_id}/thresholds")
    assert get_resp.status_code == 200
    rules = get_resp.json()["data"]
    assert any(r["id"] == rule_id for r in rules)

    # 3. Trigger manual sync to Prometheus
    sync_resp = await client.post("/api/v1/monitoring/thresholds/sync-prometheus")
    assert sync_resp.status_code == 200
    sync_data = sync_resp.json()["data"]
    assert sync_data["success"] is True
    assert sync_data["rules_count"] > 0

    # 4. Delete Threshold
    del_resp = await client.delete(f"/api/v1/monitoring/normalized/servers/{server_id}/thresholds/{rule_id}")
    assert del_resp.status_code == 200
    assert del_resp.json()["data"]["deleted"] is True


@pytest.mark.asyncio
async def test_alertmanager_webhook_and_alerts_api(client: AsyncClient):
    server_id = "win-srv-webhook-test"

    # 1. Post simulated Alertmanager webhook payload
    webhook_payload = {
        "version": "4",
        "groupKey": "{}:{alertname=\"WindowsHighCpuUtilization\"}",
        "status": "firing",
        "receiver": "tem-webhook",
        "alerts": [
            {
                "status": "firing",
                "labels": {
                    "alertname": "WindowsHighCpuUtilization",
                    "severity": "critical",
                    "server_id": server_id,
                    "instance": "localhost:9182",
                    "category": "CPU",
                    "resource": "Total"
                },
                "annotations": {
                    "summary": "High CPU utilization detected on server",
                    "description": "CPU utilization reached 89.5% exceeding 85% limit."
                },
                "fingerprint": "abc123fingerprint-test-01"
            }
        ]
    }
    wh_resp = await client.post("/api/v1/monitoring/alertmanager/webhook", json=webhook_payload)
    assert wh_resp.status_code == 200
    wh_data = wh_resp.json()
    assert wh_data["processed"] >= 1

    # 2. Query alerts for server
    alerts_resp = await client.get(f"/api/v1/monitoring/normalized/servers/{server_id}/alerts")
    assert alerts_resp.status_code == 200
    alerts = alerts_resp.json()["data"]
    assert len(alerts) >= 1
    test_alert = next((a for a in alerts if a["fingerprint"] == "abc123fingerprint-test-01"), None)
    assert test_alert is not None
    assert test_alert["severity"] == "CRITICAL"
    assert test_alert["status"] in ["ACTIVE", "WARNING", "CRITICAL"]

    # 3. Acknowledge Alert
    ack_resp = await client.post(f"/api/v1/monitoring/normalized/alerts/{test_alert['alert_id']}/acknowledge")
    assert ack_resp.status_code == 200
    ack_alert = ack_resp.json()["data"]
    assert ack_alert["status"] == "ACKNOWLEDGED"

    # 4. Resolve Alert
    res_resp = await client.post(f"/api/v1/monitoring/normalized/alerts/{test_alert['alert_id']}/resolve")
    assert res_resp.status_code == 200
    res_alert = res_resp.json()["data"]
    assert res_alert["status"] == "RESOLVED"
