import pytest
from app.adapters.monitoring.prometheus_adapter import PrometheusAdapter
from app.adapters.monitoring.registry import adapter_registry, MonitoringAdapterRegistry
from app.adapters.monitoring.base import BaseMonitoringAdapter, ProviderHealth, UnifiedTarget
from app.adapters.monitoring.metrics import operational_metrics
from app.schemas.unified_monitoring import UnifiedMetricSample, UnifiedHistoricalTelemetry


@pytest.mark.asyncio
async def test_prometheus_adapter_live_pipeline():
    """Validates the live SQLite -> Exporter -> Prometheus -> PrometheusAdapter pipeline."""
    adapter = PrometheusAdapter()
    
    # 1. Health Probe
    health = await adapter.get_health()
    assert health.is_healthy is True
    assert health.status == "HEALTHY"
    assert health.active_targets_count >= 1
    assert health.data_freshness_seconds >= 0.0

    # 2. Target Discovery
    targets = await adapter.get_targets("env-01")
    assert len(targets) >= 1
    target_names = [t.name for t in targets]
    assert any("sqlite" in n.lower() or "prometheus" in n.lower() for n in target_names)

    # 3. Normalized Resources Discovery
    resources = await adapter.get_resources("env-01")
    assert len(resources) >= 5
    db_res = next((r for r in resources if r.type == "database"), None)
    assert db_res is not None
    assert db_res.is_up is True
    assert db_res.technology == "sqlite"

    # 4. Live Metrics Retrieval
    metrics = await adapter.get_metrics("env-01")
    assert len(metrics) > 0
    metric_names = [m.metric for m in metrics]
    assert "database_availability" in metric_names or "sqlite_database_up" in metric_names

    # 5. Dynamic Metric Discovery
    catalog = await adapter.discover_metrics()
    assert len(catalog) > 0
    discovered_names = [m.name for m in catalog]
    assert any("sqlite" in n for n in discovered_names)


@pytest.mark.asyncio
async def test_future_provider_extensibility():
    """
    Validates Requirement 27: Adding a future monitoring provider (e.g. PostgreSQLAdapter)
    does not break the platform or require architecture redesign.
    """
    class FuturePostgreSQLAdapter(BaseMonitoringAdapter):
        def __init__(self):
            super().__init__(
                provider_id="postgres-prod",
                provider_name="Production PostgreSQL Monitor",
                provider_type="DATABASE"
            )

        async def get_health(self) -> ProviderHealth:
            return ProviderHealth(
                provider_id=self.provider_id,
                provider_name=self.provider_name,
                provider_type=self.provider_type,
                is_healthy=True,
                status="HEALTHY",
                latency_ms=4.2,
                data_freshness_seconds=1.0,
                active_targets_count=1
            )

        async def get_targets(self, environment_id=None):
            return [
                UnifiedTarget(
                    id="pg-prod-01",
                    name="PostgreSQL Primary",
                    environment_id=environment_id or "env-prod",
                    environment_name="Production",
                    target_type="DATABASE",
                    endpoint_url="postgresql://db.prod:5432/core",
                    is_up=True,
                    status="UP"
                )
            ]

        async def get_metrics(self, environment_id, target_id=None, metric_names=None):
            return [
                UnifiedMetricSample(
                    environment="Production",
                    environment_id=environment_id,
                    target="PostgreSQL Primary",
                    target_type="DATABASE",
                    metric="pg_active_connections",
                    metric_type="GAUGE",
                    value=34.0,
                    unit="count",
                    status="HEALTHY",
                    severity="INFO",
                    source="postgresql",
                    provider=self.__class__.__name__
                )
            ]

        async def get_historical_metrics(self, environment_id, target_id=None, metric_names=None, timeframe="1h"):
            return UnifiedHistoricalTelemetry(
                environment_id=environment_id,
                timeframe=timeframe,
                series={}
            )

        async def get_alerts(self, environment_id=None):
            return []

    # Create fresh registry
    registry = MonitoringAdapterRegistry()
    initial_count = len(registry.list_adapters())

    # Register future adapter
    pg_adapter = FuturePostgreSQLAdapter()
    registry.register_adapter(pg_adapter)
    assert len(registry.list_adapters()) == initial_count + 1
    assert registry.get_adapter("postgres-prod") is not None

    # Verify unified health across providers includes the new adapter
    all_health = await registry.get_all_sources_health()
    source_ids = [h.source_id for h in all_health]
    assert "postgres-prod" in source_ids

    # Verify unified metrics aggregation includes new adapter
    metrics = await registry.get_all_metrics("env-prod")
    metric_names = [m.metric for m in metrics]
    assert "pg_active_connections" in metric_names


def test_operational_metrics_collector():
    operational_metrics.record_api_request("/test-endpoint", 200, 0.045)
    operational_metrics.record_provider_query("prometheus", "query", 0.012)
    operational_metrics.record_data_freshness(3.5)
    
    summary = operational_metrics.get_summary()
    assert summary["total_api_requests"] >= 1
    assert summary["total_provider_queries"] >= 1
    assert summary["last_data_freshness_seconds"] == 3.5

    openmetrics_text = operational_metrics.to_openmetrics_text()
    assert "monitoring_api_requests_total" in openmetrics_text
    assert "monitoring_data_freshness_seconds" in openmetrics_text
