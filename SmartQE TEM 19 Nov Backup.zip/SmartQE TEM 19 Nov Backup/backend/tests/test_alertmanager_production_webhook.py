import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.config import settings
from app.models.monitoring import MonitoringEvent, EventState, EventSeverity, MonitoringMetricType


@pytest.mark.asyncio
async def test_alertmanager_webhook_authentication(client: AsyncClient, monkeypatch):
    """Verifies that when ALERTMANAGER_WEBHOOK_SECRET is set, unauthenticated requests are rejected with 401."""
    monkeypatch.setattr(settings, "ALERTMANAGER_WEBHOOK_SECRET", "prod-secret-key-12345")

    payload = {
        "status": "firing",
        "alerts": [
            {
                "status": "firing",
                "labels": {"alertname": "TestAlert", "instance": "srv-01"},
                "fingerprint": "test-auth-fp-01"
            }
        ]
    }

    # 1. Missing Authorization header -> 401
    resp_no_auth = await client.post("/api/v1/monitoring/alertmanager/webhook", json=payload)
    assert resp_no_auth.status_code == 401
    assert "Unauthorized" in resp_no_auth.json()["detail"]

    # 2. Invalid Bearer token -> 401
    resp_bad_auth = await client.post(
        "/api/v1/monitoring/alertmanager/webhook",
        json=payload,
        headers={"Authorization": "Bearer wrong-secret"}
    )
    assert resp_bad_auth.status_code == 401

    # 3. Valid Bearer token -> 200
    resp_good_auth = await client.post(
        "/api/v1/monitoring/alertmanager/webhook",
        json=payload,
        headers={"Authorization": "Bearer prod-secret-key-12345"}
    )
    assert resp_good_auth.status_code == 200
    assert resp_good_auth.json()["status"] == "success"

    # 4. Valid X-Webhook-Token header -> 200
    resp_x_token = await client.post(
        "/api/v1/monitoring/alertmanager/webhook",
        json=payload,
        headers={"X-Webhook-Token": "prod-secret-key-12345"}
    )
    assert resp_x_token.status_code == 200


@pytest.mark.asyncio
async def test_alertmanager_batch_ingestion_and_categorization(client: AsyncClient, db_session: AsyncSession):
    """Tests batch processing of alerts across multiple categories (MEMORY, NETWORK, AVAILABILITY, CPU)."""
    payload = {
        "receiver": "tem-monitoring-webhook",
        "status": "firing",
        "alerts": [
            {
                "status": "firing",
                "labels": {
                    "alertname": "WindowsHighMemoryUsage",
                    "category": "MEMORY",
                    "instance": "prod-db-01",
                    "severity": "critical",
                    "environment": "Production-Fleet"
                },
                "annotations": {
                    "summary": "Memory utilization is above 92%",
                    "description": "Physical RAM exhausted."
                },
                "fingerprint": "batch-fp-mem-01"
            },
            {
                "status": "firing",
                "labels": {
                    "alertname": "NetworkInterfaceDropHigh",
                    "category": "NETWORK",
                    "instance": "prod-db-01",
                    "severity": "warning",
                    "environment": "Production-Fleet"
                },
                "annotations": {
                    "summary": "Packet drops detected on eth0",
                    "description": "High discard rate."
                },
                "fingerprint": "batch-fp-net-01"
            },
            {
                "status": "firing",
                "labels": {
                    "alertname": "WindowsExporterDown",
                    "category": "AVAILABILITY",
                    "instance": "prod-app-02",
                    "severity": "critical",
                    "environment": "Production-Fleet"
                },
                "annotations": {
                    "summary": "Host unreachable",
                    "description": "Scrape failed."
                },
                "fingerprint": "batch-fp-avail-01"
            },
            {
                "status": "firing",
                "labels": {
                    "alertname": "HighDiskUtilization",
                    "category": "DISK",
                    "instance": "prod-app-02",
                    "volume": "C:",
                    "severity": "warning",
                    "environment": "Production-Fleet"
                },
                "annotations": {
                    "summary": "Disk space critically low on C:",
                    "description": "Less than 5% free."
                },
                "fingerprint": "batch-fp-disk-01"
            }
        ]
    }

    resp = await client.post("/api/v1/monitoring/alertmanager/webhook", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert data["processed"] == 4
    assert data["total"] == 4

    # Verify database records and proper categorization
    stmt = select(MonitoringEvent).where(
        MonitoringEvent.fingerprint.in_([
            "batch-fp-mem-01", "batch-fp-net-01", "batch-fp-avail-01", "batch-fp-disk-01"
        ])
    )
    res = await db_session.execute(stmt)
    events = {e.fingerprint: e for e in res.scalars().all()}

    assert len(events) == 4
    assert events["batch-fp-mem-01"].event_type == MonitoringMetricType.MEMORY
    assert events["batch-fp-mem-01"].severity == EventSeverity.CRITICAL
    assert events["batch-fp-mem-01"].state == EventState.CRITICAL
    assert events["batch-fp-mem-01"].environment_name == "Production-Fleet"

    assert events["batch-fp-net-01"].event_type == MonitoringMetricType.NETWORK
    assert events["batch-fp-net-01"].severity == EventSeverity.WARNING

    assert events["batch-fp-avail-01"].event_type == MonitoringMetricType.AVAILABILITY
    assert events["batch-fp-avail-01"].severity == EventSeverity.CRITICAL

    assert events["batch-fp-disk-01"].event_type in [MonitoringMetricType.DISK, MonitoringMetricType.DISK_VOLUME]


@pytest.mark.asyncio
async def test_alertmanager_resolve_flow(client: AsyncClient, db_session: AsyncSession):
    """Tests that sending a resolved status updates active events to RECOVERED with a timestamp."""
    fp = "resolve-test-fp-999"

    # Step 1: Fire alert
    firing_payload = {
        "status": "firing",
        "alerts": [
            {
                "status": "firing",
                "labels": {
                    "alertname": "HighCPUUtilization",
                    "category": "CPU",
                    "instance": "prod-web-01",
                    "severity": "warning"
                },
                "annotations": {
                    "summary": "CPU over 85%",
                    "description": "High CPU utilization detected."
                },
                "fingerprint": fp
            }
        ]
    }

    fire_resp = await client.post("/api/v1/monitoring/alertmanager/webhook", json=firing_payload)
    assert fire_resp.status_code == 200

    stmt = select(MonitoringEvent).where(MonitoringEvent.fingerprint == fp)
    res = await db_session.execute(stmt)
    event = res.scalars().first()
    assert event is not None
    assert event.state == EventState.WARNING
    assert event.recovered_at is None

    # Step 2: Resolve alert
    resolve_payload = {
        "status": "resolved",
        "alerts": [
            {
                "status": "resolved",
                "labels": {
                    "alertname": "HighCPUUtilization",
                    "category": "CPU",
                    "instance": "prod-web-01"
                },
                "fingerprint": fp
            }
        ]
    }

    resolve_resp = await client.post("/api/v1/monitoring/alertmanager/webhook", json=resolve_payload)
    assert resolve_resp.status_code == 200

    await db_session.refresh(event)
    assert event.state == EventState.RECOVERED
    assert event.recovered_at is not None


@pytest.mark.asyncio
async def test_alertmanager_in_flight_deduplication(client: AsyncClient, db_session: AsyncSession):
    """Verifies that sending duplicate alerts with the same fingerprint in a single batch does not create duplicate DB rows."""
    duplicate_fp = "duplicate-test-fp-01"
    payload = {
        "status": "firing",
        "alerts": [
            {
                "status": "firing",
                "labels": {"alertname": "DuplicateTest", "instance": "srv-x"},
                "fingerprint": duplicate_fp
            },
            {
                "status": "firing",
                "labels": {"alertname": "DuplicateTest", "instance": "srv-x"},
                "fingerprint": duplicate_fp
            }
        ]
    }

    resp = await client.post("/api/v1/monitoring/alertmanager/webhook", json=payload)
    assert resp.status_code == 200

    stmt = select(MonitoringEvent).where(MonitoringEvent.fingerprint == duplicate_fp)
    res = await db_session.execute(stmt)
    records = res.scalars().all()
    assert len(records) == 1
