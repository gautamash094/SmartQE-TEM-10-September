import time
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from prometheus_client import REGISTRY, generate_latest

from app.core.config import settings
from app.adapters.monitoring.postgres_adapter import PostgreSQLAdapter
from app.adapters.monitoring.prometheus_adapter import PrometheusAdapter
from app.adapters.monitoring.normalizer import MonitoringNormalizer
from app.adapters.monitoring.registry import adapter_registry
from app.adapters.monitoring.base import BaseMonitoringAdapter, ProviderHealth
from app.schemas.unified_monitoring import UnifiedMetricSample, UnifiedHistoricalTelemetry
from app.services.monitoring_service import monitoring_service
from monitoring.postgres_exporter import (
    PostgreSQLMetricsCollector,
    classify_query,
    sanitize_query_text,
    get_metrics_text,
)


# ==============================================================================
# 1. Configuration & Security Tests
# ==============================================================================

def test_postgres_configuration_defaults_and_masking():
    """Validates configuration parameters and verifies credentials are never exposed."""
    assert hasattr(settings, "POSTGRES_HOST")
    assert hasattr(settings, "POSTGRES_PORT")
    assert hasattr(settings, "POSTGRES_DATABASE")
    assert hasattr(settings, "POSTGRES_USER")
    assert hasattr(settings, "POSTGRES_PASSWORD")
    assert hasattr(settings, "POSTGRES_EXPORTER_PORT")
    assert settings.POSTGRES_EXPORTER_PORT == 9188
    assert settings.POSTGRES_PORT == 5432
    assert settings.postgres_effective_database == "smartqe_tem"
    
    # Verify password masking (never exposed as plaintext in connection endpoints)
    adapter = PostgreSQLAdapter()
    assert f":{adapter.password}@" not in adapter.base_url
    assert adapter.password not in adapter.host


# ==============================================================================
# 2. Exporter & Metrics Collector Unit Tests
# ==============================================================================

def test_collector_query_classification_and_sanitization():
    """Tests SQL query classification and sensitive literal sanitization in the exporter."""
    assert classify_query("SELECT * FROM test_executions WHERE id = 10") == "SELECT"
    assert classify_query("INSERT INTO environments (name) VALUES ('SIT')") == "INSERT"
    assert classify_query("UPDATE users SET password = 'abc' WHERE id = 1") == "UPDATE"
    assert classify_query("DELETE FROM logs WHERE created_at < NOW()") == "DELETE"
    assert classify_query("CREATE INDEX idx_name ON users(name)") == "DDL"
    assert classify_query("") == "OTHER"

    # Query sanitization (literals replaced with placeholders)
    sanitized = sanitize_query_text("SELECT * FROM users WHERE email = 'admin@example.com' AND age > 25")
    assert "admin@example.com" not in sanitized
    assert "25" not in sanitized
    assert "?" in sanitized


def test_collector_metric_definitions_and_registry():
    """Tests that all enterprise PostgreSQL Prometheus metrics are defined in the collector registry."""
    registered_names = set(REGISTRY._names_to_collectors.keys())
    expected_metrics = {
        "pg_up",
        "pg_database_up",
        "pg_connection_status",
        "pg_settings_max_connections",
        "pg_stat_activity_count",
        "pg_connection_utilization_ratio",
        "pg_stat_database_xact_commit",
        "pg_stat_database_xact_rollback",
        "pg_stat_database_deadlocks",
        "pg_database_size_bytes",
        "pg_table_size_bytes",
        "pg_table_rows_total",
        "pg_cache_hit_ratio",
        "pg_slow_queries_total",
        "pg_exporter_scrape_duration_seconds",
    }
    for metric in expected_metrics:
        assert metric in registered_names, f"Expected metric '{metric}' in registered collector names"


@pytest.mark.asyncio
async def test_collector_offline_fallback():
    """Tests that when PostgreSQL is offline or unreachable, pg_up=0 is set gracefully without crashing."""
    collector = PostgreSQLMetricsCollector(host="127.0.0.1", port=5439, timeout=0.2)
    success = await collector.collect()
    assert success is False
    output = get_metrics_text()
    assert "pg_up 0.0" in output or "pg_up" in output


# ==============================================================================
# 3. Monitoring Normalizer PostgreSQL Semantic Mapping Tests
# ==============================================================================

def test_normalizer_postgres_metrics_mapping():
    """Validates that PostgreSQL metrics are normalized into standardized semantic representations."""
    normalizer = MonitoringNormalizer()
    now_ts = time.time()
    
    norm_up = normalizer.normalize_metric(
        raw_name="pg_up",
        value=1.0,
        timestamp=now_ts,
        labels={"job": "smartqe-tem-postgresql", "instance": "localhost:9188"},
        provider="PostgreSQLAdapter",
    )
    assert norm_up.metric_name == "database_availability"
    assert norm_up.metric_category == "DATABASE"
    assert norm_up.unit == "status"
    assert norm_up.status == "HEALTHY"
    assert norm_up.labels.get("technology") == "postgresql"

    norm_conn = normalizer.normalize_metric(
        raw_name="pg_connection_utilization_ratio",
        value=0.45,
        timestamp=now_ts,
        labels={"database": "smartqe_tem", "job": "smartqe-tem-postgresql"},
        provider="PostgreSQLAdapter",
    )
    assert norm_conn.metric_name == "connection_utilization"
    assert norm_conn.metric_category == "CONNECTION"
    assert norm_conn.unit == "%"

    norm_cache = normalizer.normalize_metric(
        raw_name="pg_cache_hit_ratio",
        value=0.995,
        timestamp=now_ts,
        labels={"database": "smartqe_tem"},
        provider="PostgreSQLAdapter",
    )
    assert norm_cache.metric_name == "cache_hit_ratio"
    assert norm_cache.metric_category == "DATABASE"
    assert norm_cache.unit == "%"

    norm_slow = normalizer.normalize_metric(
        raw_name="pg_slow_queries_total",
        value=12.0,
        timestamp=now_ts,
        labels={"database": "smartqe_tem"},
        provider="PostgreSQLAdapter",
    )
    assert norm_slow.metric_name == "slow_queries_count"
    assert norm_slow.metric_category == "QUERY"
    assert norm_slow.status == "CRITICAL"


def test_normalizer_postgres_resource_extraction():
    """Validates dynamic extraction of PostgreSQL database and table resources."""
    normalizer = MonitoringNormalizer()
    now_ts = time.time()
    
    metrics = [
        normalizer.normalize_metric(
            raw_name="pg_up",
            value=1.0,
            timestamp=now_ts,
            labels={"database": "smartqe_tem", "job": "smartqe-tem-postgresql"},
            provider="PostgreSQLAdapter",
        ),
        normalizer.normalize_metric(
            raw_name="pg_database_size_bytes",
            value=52428800.0,
            timestamp=now_ts,
            labels={"database": "smartqe_tem", "job": "smartqe-tem-postgresql"},
            provider="PostgreSQLAdapter",
        ),
        normalizer.normalize_metric(
            raw_name="pg_table_rows_total",
            value=1500.0,
            timestamp=now_ts,
            labels={"database": "smartqe_tem", "table": "test_executions", "schema": "public"},
            provider="PostgreSQLAdapter",
        ),
        normalizer.normalize_metric(
            raw_name="pg_table_size_bytes",
            value=204800.0,
            timestamp=now_ts,
            labels={"database": "smartqe_tem", "table": "test_executions", "schema": "public"},
            provider="PostgreSQLAdapter",
        ),
    ]
    
    resources = normalizer.extract_resources_from_metrics(metrics)
    assert len(resources) >= 2
    
    db_res = next((r for r in resources if r.type == "database" and r.technology == "postgresql"), None)
    assert db_res is not None
    assert "smartqe_tem" in db_res.name
    assert db_res.is_up is True
    assert db_res.status == "HEALTHY"
    
    table_res = next((r for r in resources if r.type == "database_table" and r.labels.get("table") == "test_executions"), None)
    assert table_res is not None
    assert table_res.technology == "postgresql"
    assert table_res.metrics_summary.get("table_row_count") == 1500.0
    assert table_res.metrics_summary.get("table_size") == 204800.0


# ==============================================================================
# 4. PostgreSQLAdapter Interface Tests
# ==============================================================================

@pytest.mark.asyncio
async def test_postgres_adapter_lifecycle():
    """Validates the PostgreSQLAdapter implementation of BaseMonitoringAdapter."""
    adapter = PostgreSQLAdapter()
    
    # 1. Health Probe
    health = await adapter.get_health()
    assert isinstance(health, ProviderHealth)
    assert health.provider_id == "postgres-core"
    assert health.provider_type == "DATABASE"
    assert health.status in ("HEALTHY", "DEGRADED", "OFFLINE", "DOWN")
    
    # 2. Target Discovery
    targets = await adapter.get_targets("env-sit-01")
    assert len(targets) >= 1
    assert targets[0].target_type == "DATABASE"
    assert targets[0].labels.get("technology") == "postgresql"
    assert targets[0].labels.get("database") == "smartqe_tem"
    
    # 3. Discovered Normalized Resources
    resources = await adapter.get_resources("env-sit-01")
    assert len(resources) >= 1
    db_res = next((r for r in resources if r.type == "database"), None)
    assert db_res is not None
    assert db_res.technology == "postgresql"
    
    # 4. Live Metrics Retrieval
    metrics = await adapter.get_metrics("env-sit-01")
    assert len(metrics) > 0
    metric_names = [m.metric for m in metrics]
    assert "pg_up" in metric_names or "database_availability" in metric_names
    assert any("pg_" in m.metric or m.labels.get("technology") == "postgresql" for m in metrics)

    # 5. Dynamic Metric Catalog
    catalog = await adapter.discover_metrics()
    assert len(catalog) >= 10
    catalog_names = [item.name for item in catalog]
    assert "pg_up" in catalog_names
    assert "pg_stat_activity_count" in catalog_names
    assert "pg_connection_utilization_ratio" in catalog_names
    assert "pg_cache_hit_ratio" in catalog_names

    # 6. Historical Telemetry
    hist = await adapter.get_historical_metrics("env-sit-01", timeframe="1h")
    assert isinstance(hist, UnifiedHistoricalTelemetry)
    assert "database_availability" in hist.series or "connection_utilization" in hist.series


@pytest.mark.asyncio
async def test_postgres_adapter_alerts_generation():
    """Tests alert threshold triggering in PostgreSQLAdapter."""
    adapter = PostgreSQLAdapter()
    
    # Mock offline state
    with patch.object(adapter, "check_connectivity", return_value=False):
        alerts = await adapter.get_alerts("env-sit-01")
        assert len(alerts) >= 1
        assert any(a.get("severity") == "CRITICAL" and a.get("metric") == "pg_up" for a in alerts)


# ==============================================================================
# 5. Adapter Registry Integration Tests
# ==============================================================================

def test_adapter_registry_contains_postgres():
    """Validates that PostgreSQLAdapter is registered in the centralized adapter registry."""
    adapters = adapter_registry.list_adapters()
    adapter_ids = [a.provider_id for a in adapters]
    assert "postgres-core" in adapter_ids
    assert "prometheus-core" in adapter_ids
    
    pg_adapter = adapter_registry.get_adapter("postgres-core")
    assert pg_adapter is not None
    assert isinstance(pg_adapter, PostgreSQLAdapter)


# ==============================================================================
# 6. Dual-Engine Coexistence & Service Integration Tests
# ==============================================================================

@pytest.mark.asyncio
async def test_service_monitored_databases_includes_both_engines():
    """Validates that monitoring_service.get_monitored_databases() discovers both PostgreSQL and SQLite."""
    databases = await monitoring_service.get_monitored_databases("env-sit-01")
    assert len(databases) >= 1
    technologies = [db.technology for db in databases]
    
    # Both engines can coexist in the monitored databases list
    assert "sqlite" in technologies or "postgresql" in technologies


@pytest.mark.asyncio
async def test_environment_readiness_with_postgres_evaluation():
    """Validates that the environment readiness gate evaluates database operational health."""
    readiness = await monitoring_service.get_environment_readiness_assessment("env-sit-01")
    assert readiness is not None
    assert hasattr(readiness, "overall_readiness_score")
    assert hasattr(readiness, "status")
    assert hasattr(readiness, "gates")
    
    # Gates must include Database Connection Pool
    db_gate = next((g for g in readiness.gates if "Database" in g.gate_name), None)
    assert db_gate is not None
    assert db_gate.status in ("PASSED", "WARNING", "FAILED")
