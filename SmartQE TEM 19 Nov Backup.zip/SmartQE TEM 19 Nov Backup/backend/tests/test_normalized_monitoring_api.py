import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.environment_profile import EnvironmentProfile
from app.models.environment import EnvironmentStatus


@pytest.mark.asyncio
async def test_get_monitoring_overview(client: AsyncClient, db_session: AsyncSession):
    # Ensure at least one environment exists
    env = EnvironmentProfile(
        name="OVERVIEW-TEST-ENV",
        type="SIT",
        status=EnvironmentStatus.HEALTHY,
        is_visible=True
    )
    db_session.add(env)
    await db_session.commit()

    resp = await client.get("/api/v1/monitoring/overview")
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    data = body["data"]
    assert data["environment_count"] >= 1
    assert data["healthy_environment_count"] >= 1
    assert data["monitoring_target_count"] >= 1
    assert data["active_providers_count"] >= 1
    assert "data_freshness" in data
    assert data["data_freshness"]["status"] in ["FRESH", "STALE"]


@pytest.mark.asyncio
async def test_get_monitoring_providers(client: AsyncClient):
    resp = await client.get("/api/v1/monitoring/providers")
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    providers = body["data"]
    assert len(providers) >= 1
    provider_ids = [p["source_id"] for p in providers]
    assert "prometheus-core" in provider_ids


@pytest.mark.asyncio
async def test_get_normalized_resources(client: AsyncClient):
    resp = await client.get("/api/v1/monitoring/resources")
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    resources = body["data"]
    assert len(resources) >= 1
    types = [r["type"] for r in resources]
    assert "database" in types or "server" in types or "target" in types


@pytest.mark.asyncio
async def test_get_dynamic_metrics_catalog(client: AsyncClient):
    resp = await client.get("/api/v1/monitoring/metrics")
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    catalog = body["data"]
    assert catalog["total_count"] > 0
    assert len(catalog["metrics"]) > 0


@pytest.mark.asyncio
async def test_get_normalized_timeseries(client: AsyncClient):
    resp = await client.get("/api/v1/monitoring/timeseries?timeframe=1h")
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert "series" in body["data"]


@pytest.mark.asyncio
async def test_get_operational_metrics(client: AsyncClient):
    resp = await client.get("/api/v1/monitoring/operational-metrics")
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    data = body["data"]
    assert "uptime_seconds" in data
    assert "total_api_requests" in data

    raw_resp = await client.get("/api/v1/monitoring/operational-metrics/raw")
    assert raw_resp.status_code == 200
    assert "monitoring_layer_uptime_seconds" in raw_resp.text


@pytest.mark.asyncio
async def test_live_promql_query_endpoint(client: AsyncClient):
    payload = {
        "query": "sqlite_database_up"
    }
    resp = await client.post("/api/v1/monitoring/prometheus/query", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "success"
    assert "data" in body
    assert body["data"]["resultType"] in ["vector", "matrix"]
    assert isinstance(body["data"]["result"], list)


@pytest.mark.asyncio
async def test_unified_metrics_backward_compatibility(client: AsyncClient):
    resp = await client.get("/api/v1/monitoring/unified/metrics?environment_id=env-01")
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    samples = body["data"]
    assert len(samples) > 0
    first = samples[0]
    assert "metric" in first
    assert "value" in first
    assert "unit" in first
    assert "status" in first
    assert "source" in first
