import pytest
from app.services.diagnosis.server_infra_checker import ServerInfrastructureChecker
from app.services.monitoring_service import monitoring_service
from app.models.monitoring import MonitoringThresholdRule, MonitoringMetricType
from types import SimpleNamespace


@pytest.mark.asyncio
async def test_server_infra_checker_respects_user_configured_thresholds(db_session):
    checker = ServerInfrastructureChecker()

    # Step 1: Baseline check without user rules (65% CPU usage should be PASSED under default 75% warn)
    fake_env = SimpleNamespace(id="env-test-01", cpu_usage=65.0, memory_usage=50.0, storage_usage=40.0, status="HEALTHY")
    ctx = {"db": db_session, "env": fake_env, "assets": []}
    res = await checker.run_check(ctx)
    assert res.status == "PASSED"
    assert len(res.details["findings"]) == 0

    # Step 2: User configures a strict custom CPU threshold (warning at 60%, critical at 80%)
    rule = MonitoringThresholdRule(
        name="Strict SIT CPU Threshold",
        server_id="ALL",
        metric_category="CPU",
        metric_type=MonitoringMetricType.CPU,
        operator=">",
        warning_threshold=60.0,
        critical_threshold=80.0,
        severe_threshold=95.0,
        unit="%",
        is_enabled=True,
        is_visible=True
    )
    db_session.add(rule)
    await db_session.commit()

    # Step 3: Run check again with same 65% CPU usage - must now trigger WARNING because 65% >= user's 60% threshold!
    res_strict = await checker.run_check(ctx)
    assert res_strict.status == "WARNING"
    assert len(res_strict.details["findings"]) == 1
    assert "Elevated CPU utilization: 65.0%" in res_strict.details["findings"][0]
    assert "User-Configured Warning Threshold" in res_strict.details["findings"][0]
    assert res_strict.details["applied_thresholds"]["cpu"]["warning"] == 60.0
    assert res_strict.details["applied_thresholds"]["cpu"]["user_configured"] is True

    # Step 4: Increase CPU usage to 82% - must trigger CRITICAL against user's 80% critical threshold!
    fake_env.cpu_usage = 82.0
    res_crit = await checker.run_check(ctx)
    assert res_crit.status == "CRITICAL"
    assert "High CPU utilization: 82.0%" in res_crit.details["findings"][0]
    assert "User-Configured Critical Threshold" in res_crit.details["findings"][0]


@pytest.mark.asyncio
async def test_server_health_respects_user_configured_thresholds(db_session):
    # Insert custom threshold for server 'SRV-CUSTOM-01': CPU critical at 75% (instead of default 85%)
    rule = MonitoringThresholdRule(
        name="Custom Server CPU Rule",
        server_id="SRV-CUSTOM-01",
        metric_category="CPU",
        metric_type=MonitoringMetricType.CPU,
        operator=">",
        warning_threshold=60.0,
        critical_threshold=75.0,
        is_enabled=True,
        is_visible=True
    )
    db_session.add(rule)
    await db_session.commit()

    # Check health for SRV-CUSTOM-01
    health = await monitoring_service.get_normalized_server_health(
        server_id="SRV-CUSTOM-01",
        environment_id="env-test",
        db=db_session
    )
    assert health is not None
    assert health.server_id == "SRV-CUSTOM-01"


@pytest.mark.asyncio
async def test_environment_observability_respects_user_configured_thresholds(db_session):
    # Insert custom CPU warning threshold of 50.0%
    rule = MonitoringThresholdRule(
        name="Global Low CPU Warning",
        server_id="ALL",
        metric_category="CPU",
        metric_type=MonitoringMetricType.CPU,
        operator=">",
        warning_threshold=50.0,
        critical_threshold=70.0,
        is_enabled=True,
        is_visible=True
    )
    db_session.add(rule)
    await db_session.commit()

    obs = await monitoring_service.get_environment_detailed_observability(db=db_session, env_id="env-test")
    assert obs is not None
