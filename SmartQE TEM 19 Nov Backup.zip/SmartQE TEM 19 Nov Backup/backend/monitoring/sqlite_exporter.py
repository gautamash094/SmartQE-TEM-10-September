import os
import sqlite3
import time
from pathlib import Path

from prometheus_client import start_http_server, Gauge, Counter


# ============================================================
# Configuration
# ============================================================

DB_PATH = os.getenv(
    "SQLITE_DB_PATH",
    str(Path(__file__).resolve().parent.parent / "smartqe_tem.db")
)

EXPORTER_PORT = int(
    os.getenv("SQLITE_EXPORTER_PORT", "9187")
)

COLLECTION_INTERVAL = int(
    os.getenv("SQLITE_COLLECTION_INTERVAL", "15")
)


# ============================================================
# Database-level Metrics
# ============================================================

db_up = Gauge(
    "sqlite_database_up",
    "Whether the SQLite database is accessible"
)

db_size_bytes = Gauge(
    "sqlite_database_size_bytes",
    "SQLite database file size in bytes"
)

db_page_count = Gauge(
    "sqlite_database_page_count",
    "Number of pages in the SQLite database"
)

db_page_size_bytes = Gauge(
    "sqlite_database_page_size_bytes",
    "SQLite database page size in bytes"
)

db_freelist_pages = Gauge(
    "sqlite_database_freelist_pages",
    "Number of free pages in the SQLite database"
)

db_used_bytes = Gauge(
    "sqlite_database_used_bytes",
    "Approximate used database size in bytes"
)

db_table_count = Gauge(
    "sqlite_database_tables_total",
    "Number of user tables in the SQLite database"
)

db_query_duration = Gauge(
    "sqlite_database_query_duration_seconds",
    "Time required to collect SQLite metrics"
)

db_wal_size_bytes = Gauge(
    "sqlite_database_wal_size_bytes",
    "SQLite WAL file size in bytes"
)

db_errors_total = Counter(
    "sqlite_database_errors_total",
    "Total number of SQLite monitoring errors"
)


# ============================================================
# Table-level Metrics
# ============================================================

table_row_count = Gauge(
    "sqlite_table_rows_total",
    "Number of rows in a SQLite table",
    ["table"]
)

table_size_bytes = Gauge(
    "sqlite_table_size_bytes",
    "Approximate size of a SQLite table in bytes",
    ["table"]
)

table_index_count = Gauge(
    "sqlite_table_indexes_total",
    "Number of indexes associated with a SQLite table",
    ["table"]
)

table_column_count = Gauge(
    "sqlite_table_columns_total",
    "Number of columns in a SQLite table",
    ["table"]
)


# ============================================================
# WAL Size
# ============================================================

def get_wal_size():

    db_file = Path(DB_PATH)
    wal_file = Path(str(db_file) + "-wal")

    if wal_file.exists():
        return wal_file.stat().st_size

    return 0


# ============================================================
# Discover SQLite Tables Dynamically
# ============================================================

def discover_tables(connection):

    cursor = connection.cursor()

    cursor.execute("""
        SELECT name
        FROM sqlite_master
        WHERE type = 'table'
        AND name NOT LIKE 'sqlite_%'
        ORDER BY name
    """)

    return [
        row[0]
        for row in cursor.fetchall()
    ]


# ============================================================
# Collect Table Metrics
# ============================================================

def collect_table_metrics(connection, tables, page_size):

    cursor = connection.cursor()

    discovered_tables = set(tables)

    # --------------------------------------------------------
    # Remove metrics for tables that no longer exist
    # --------------------------------------------------------

    existing_metric_tables = set()

    for metric in [
        table_row_count,
        table_size_bytes,
        table_index_count,
        table_column_count
    ]:

        for sample in metric.collect()[0].samples:

            if "table" in sample.labels:

                existing_metric_tables.add(
                    sample.labels["table"]
                )

    removed_tables = (
        existing_metric_tables - discovered_tables
    )

    for table in removed_tables:

        table_row_count.remove(table)
        table_size_bytes.remove(table)
        table_index_count.remove(table)
        table_column_count.remove(table)

    # --------------------------------------------------------
    # Collect metrics for every discovered table
    # --------------------------------------------------------

    for table in tables:

        try:

            # --------------------------------------------
            # Row count
            # --------------------------------------------

            quoted_table = '"' + table.replace('"', '""') + '"'

            cursor.execute(
                f"SELECT COUNT(*) FROM {quoted_table}"
            )

            row_count = cursor.fetchone()[0]

            table_row_count.labels(
                table=table
            ).set(row_count)

            # --------------------------------------------
            # Column count
            # --------------------------------------------

            cursor.execute(
                f"PRAGMA table_info({quoted_table})"
            )

            columns = cursor.fetchall()

            table_column_count.labels(
                table=table
            ).set(len(columns))

            # --------------------------------------------
            # Index count
            # --------------------------------------------

            cursor.execute(
                f"PRAGMA index_list({quoted_table})"
            )

            indexes = cursor.fetchall()

            table_index_count.labels(
                table=table
            ).set(len(indexes))

            # --------------------------------------------
            # Approximate table size
            #
            # SQLite does not directly expose exact
            # per-table storage size.
            #
            # We therefore estimate the table footprint
            # based on average row/page characteristics.
            # --------------------------------------------

            if row_count > 0 and page_size > 0:

                table_size = (
                    row_count
                    * max(len(columns), 1)
                    * 32
                )

                table_size_bytes.labels(
                    table=table
                ).set(table_size)

            else:

                table_size_bytes.labels(
                    table=table
                ).set(0)

        except Exception as exc:

            print(
                f"Table monitoring error "
                f"[{table}]: {exc}"
            )

            db_errors_total.inc()


# ============================================================
# Collect Database Metrics
# ============================================================

def collect_metrics():

    start_time = time.perf_counter()

    connection = None

    try:

        # ----------------------------------------------------
        # Database existence
        # ----------------------------------------------------

        if not os.path.exists(DB_PATH):

            db_up.set(0)
            db_errors_total.inc()

            return

        # ----------------------------------------------------
        # Database file size
        # ----------------------------------------------------

        db_size_bytes.set(
            os.path.getsize(DB_PATH)
        )

        # ----------------------------------------------------
        # Read-only SQLite connection
        # ----------------------------------------------------

        connection = sqlite3.connect(
            f"file:{DB_PATH}?mode=ro",
            uri=True,
            timeout=5
        )

        cursor = connection.cursor()

        # ----------------------------------------------------
        # Page count
        # ----------------------------------------------------

        cursor.execute(
            "PRAGMA page_count"
        )

        page_count = cursor.fetchone()[0]

        db_page_count.set(page_count)

        # ----------------------------------------------------
        # Page size
        # ----------------------------------------------------

        cursor.execute(
            "PRAGMA page_size"
        )

        page_size = cursor.fetchone()[0]

        db_page_size_bytes.set(page_size)

        # ----------------------------------------------------
        # Free pages
        # ----------------------------------------------------

        cursor.execute(
            "PRAGMA freelist_count"
        )

        freelist_count = cursor.fetchone()[0]

        db_freelist_pages.set(
            freelist_count
        )

        # ----------------------------------------------------
        # Used database size
        # ----------------------------------------------------

        used_bytes = (
            page_count - freelist_count
        ) * page_size

        db_used_bytes.set(
            max(used_bytes, 0)
        )

        # ----------------------------------------------------
        # Dynamic table discovery
        # ----------------------------------------------------

        tables = discover_tables(
            connection
        )

        db_table_count.set(
            len(tables)
        )

        # ----------------------------------------------------
        # Dynamic table metrics
        # ----------------------------------------------------

        collect_table_metrics(
            connection,
            tables,
            page_size
        )

        # ----------------------------------------------------
        # WAL size
        # ----------------------------------------------------

        db_wal_size_bytes.set(
            get_wal_size()
        )

        # ----------------------------------------------------
        # Database health
        # ----------------------------------------------------

        db_up.set(1)

        print(
            f"Monitoring {len(tables)} tables: "
            f"{', '.join(tables)}"
        )

    except Exception as exc:

        print(
            f"SQLite monitoring error: {exc}"
        )

        db_up.set(0)

        db_errors_total.inc()

    finally:

        if connection:

            connection.close()

        duration = (
            time.perf_counter()
            - start_time
        )

        db_query_duration.set(
            duration
        )


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":

    print("=" * 70)
    print("SmartQE TEM Dynamic SQLite Monitoring Exporter")
    print("=" * 70)

    print(f"Database : {DB_PATH}")
    print(f"Port     : {EXPORTER_PORT}")
    print(
        f"Interval : {COLLECTION_INTERVAL} seconds"
    )

    print("=" * 70)

    # Start Prometheus metrics server
    start_http_server(
        EXPORTER_PORT
    )

    print(
        f"Metrics endpoint: "
        f"http://localhost:{EXPORTER_PORT}/metrics"
    )

    print()

    # Initial collection
    collect_metrics()

    # Continuous monitoring
    while True:

        time.sleep(
            COLLECTION_INTERVAL
        )

        collect_metrics()