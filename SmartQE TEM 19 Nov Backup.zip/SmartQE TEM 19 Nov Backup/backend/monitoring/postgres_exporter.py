import os
import sys
import re
import time
import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

try:
    import asyncpg
except ImportError:
    asyncpg = None

from prometheus_client import (
    start_http_server,
    Gauge,
    Counter,
    CollectorRegistry,
    REGISTRY,
    generate_latest
)

# ============================================================
# Configuration
# ============================================================

POSTGRES_HOST = os.getenv("POSTGRES_HOST") or os.getenv("POSTGRES_SERVER", "localhost")
POSTGRES_PORT = int(os.getenv("POSTGRES_PORT", "5432"))
POSTGRES_USER = os.getenv("POSTGRES_USER", "postgres")
POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD", "postgres")
POSTGRES_DATABASE = os.getenv("POSTGRES_DATABASE") or os.getenv("POSTGRES_DB", "smartqe_tem")
POSTGRES_SSL_MODE = os.getenv("POSTGRES_SSL_MODE", "prefer")
POSTGRES_CONNECT_TIMEOUT = float(os.getenv("POSTGRES_CONNECT_TIMEOUT", "5.0"))
POSTGRES_ENABLED = os.getenv("POSTGRES_ENABLED", "true").lower() in ["true", "1", "yes"]
POSTGRES_EXPORTER_HOST = os.getenv("POSTGRES_EXPORTER_HOST", "0.0.0.0")
POSTGRES_EXPORTER_PORT = int(os.getenv("POSTGRES_EXPORTER_PORT", "9188"))
COLLECTION_INTERVAL = int(os.getenv("POSTGRES_COLLECTION_INTERVAL", "15"))
SLOW_QUERY_THRESHOLD_SECONDS = float(os.getenv("POSTGRES_SLOW_QUERY_THRESHOLD_SECONDS", "1.0"))
EXPLICIT_DATABASES = [
    d.strip()
    for d in os.getenv("POSTGRES_DATABASES", "").split(",")
    if d.strip()
]


# ============================================================
# Prometheus Metrics Registry & Definitions
# ============================================================

# Availability Metrics
pg_up = Gauge(
    "pg_up",
    "Whether the PostgreSQL server is accessible (1 = UP, 0 = DOWN)"
)

pg_database_up = Gauge(
    "pg_database_up",
    "Availability of specific PostgreSQL database",
    ["database"]
)

pg_connection_status = Gauge(
    "pg_connection_status",
    "PostgreSQL connection status (1 = connected, 0 = disconnected)",
    ["database"]
)

pg_last_collection_timestamp = Gauge(
    "pg_last_successful_collection_timestamp_seconds",
    "Unix timestamp of the last successful PostgreSQL metrics collection"
)

pg_monitoring_errors_total = Counter(
    "pg_monitoring_errors_total",
    "Total number of errors encountered while collecting PostgreSQL metrics",
    ["error_type"]
)

# Connection Metrics
pg_stat_activity_count = Gauge(
    "pg_stat_activity_count",
    "Number of server connections in a particular state",
    ["database", "state"]
)

pg_settings_max_connections = Gauge(
    "pg_settings_max_connections",
    "Configured maximum concurrent connections for PostgreSQL"
)

pg_connection_utilization_ratio = Gauge(
    "pg_connection_utilization_ratio",
    "Percentage of maximum PostgreSQL connections currently utilized",
    ["database"]
)

pg_connection_errors_total = Counter(
    "pg_connection_errors_total",
    "Total number of PostgreSQL connection establishment errors",
    ["database"]
)

# Query Performance Metrics
pg_stat_database_xact_commit = Gauge(
    "pg_stat_database_xact_commit",
    "Total number of transactions committed in this database",
    ["database"]
)

pg_stat_database_xact_rollback = Gauge(
    "pg_stat_database_xact_rollback",
    "Total number of transactions rolled back in this database",
    ["database"]
)

pg_stat_statements_calls_total = Gauge(
    "pg_stat_statements_calls_total",
    "Total number of queries executed classified by query type",
    ["database", "query_type"]
)

pg_stat_statements_total_time_seconds = Gauge(
    "pg_stat_statements_total_time_seconds",
    "Total time spent in queries classified by query type",
    ["database", "query_type"]
)

pg_stat_statements_mean_time_seconds = Gauge(
    "pg_stat_statements_mean_time_seconds",
    "Mean execution time in seconds for queries classified by query type",
    ["database", "query_type"]
)

pg_stat_statements_rows_total = Gauge(
    "pg_stat_statements_rows_total",
    "Total rows retrieved or affected by query type",
    ["database", "query_type"]
)

# Slow Query Metrics
pg_slow_queries_total = Gauge(
    "pg_slow_queries_total",
    "Number of active queries exceeding the slow query duration threshold",
    ["database"]
)

pg_slow_query_max_duration_seconds = Gauge(
    "pg_slow_query_max_duration_seconds",
    "Maximum duration in seconds among active slow queries",
    ["database"]
)

pg_slow_query_avg_duration_seconds = Gauge(
    "pg_slow_query_avg_duration_seconds",
    "Average duration in seconds among active slow queries",
    ["database"]
)

# Lock and Contention Metrics
pg_locks_count = Gauge(
    "pg_locks_count",
    "Number of locks held or waiting by mode",
    ["database", "mode", "granted"]
)

pg_locks_waiting_total = Gauge(
    "pg_locks_waiting_total",
    "Total number of locks currently in waiting state",
    ["database"]
)

pg_stat_database_deadlocks = Gauge(
    "pg_stat_database_deadlocks",
    "Total number of deadlocks detected in this database",
    ["database"]
)

pg_blocked_queries_count = Gauge(
    "pg_blocked_queries_count",
    "Number of queries currently waiting on locks held by other transactions",
    ["database"]
)

pg_blocking_queries_count = Gauge(
    "pg_blocking_queries_count",
    "Number of queries currently blocking other transactions",
    ["database"]
)

pg_lock_wait_duration_seconds = Gauge(
    "pg_lock_wait_duration_seconds",
    "Maximum lock wait duration among blocked queries in seconds",
    ["database"]
)

# Resource & Storage Metrics
pg_database_size_bytes = Gauge(
    "pg_database_size_bytes",
    "Physical disk space used by the PostgreSQL database in bytes",
    ["database"]
)

pg_database_tables_total = Gauge(
    "pg_database_tables_total",
    "Total number of user tables in the database",
    ["database"]
)

pg_database_indexes_total = Gauge(
    "pg_database_indexes_total",
    "Total number of user indexes in the database",
    ["database"]
)

pg_table_size_bytes = Gauge(
    "pg_table_size_bytes",
    "Total disk space used by a PostgreSQL table including indexes",
    ["database", "table"]
)

pg_table_rows_total = Gauge(
    "pg_table_rows_total",
    "Estimated number of live rows in a PostgreSQL table",
    ["database", "table"]
)

pg_stat_database_blks_hit = Gauge(
    "pg_stat_database_blks_hit",
    "Number of disk blocks found in PostgreSQL buffer cache",
    ["database"]
)

pg_stat_database_blks_read = Gauge(
    "pg_stat_database_blks_read",
    "Number of disk blocks read from disk",
    ["database"]
)

pg_cache_hit_ratio = Gauge(
    "pg_cache_hit_ratio",
    "PostgreSQL buffer cache hit ratio percentage",
    ["database"]
)

pg_wal_bytes_total = Gauge(
    "pg_wal_bytes_total",
    "Current WAL location / total WAL bytes written",
    ["database"]
)

# Exporter Self-Health
pg_exporter_scrape_duration_seconds = Gauge(
    "pg_exporter_scrape_duration_seconds",
    "Time taken to collect all PostgreSQL metrics in seconds"
)

pg_exporter_scrape_success = Gauge(
    "pg_exporter_scrape_success",
    "Whether the last PostgreSQL scrape cycle succeeded (1 = YES, 0 = NO)"
)


# ============================================================
# Query Classification Helper
# ============================================================

def classify_query(query_text: Optional[str]) -> str:
    """Classifies an SQL query into standard query types."""
    if not query_text:
        return "OTHER"
    cleaned = query_text.strip().upper()
    if cleaned.startswith("SELECT") or cleaned.startswith("WITH"):
        return "SELECT"
    elif cleaned.startswith("INSERT"):
        return "INSERT"
    elif cleaned.startswith("UPDATE"):
        return "UPDATE"
    elif cleaned.startswith("DELETE"):
        return "DELETE"
    elif any(cleaned.startswith(cmd) for cmd in ["CREATE", "ALTER", "DROP", "TRUNCATE", "RENAME"]):
        return "DDL"
    return "OTHER"


def sanitize_query_text(query_text: Optional[str]) -> str:
    """
    Sanitizes SQL query text to ensure passwords, tokens, and sensitive parameters
    are never exposed in monitoring data.
    """
    if not query_text:
        return ""
    # Strip literal string values
    sanitized = re.sub(r"'[^']*'", "'?'", query_text)
    # Strip numerical literals
    sanitized = re.sub(r"\b\d+\b", "?", sanitized)
    # Normalize whitespace
    sanitized = re.sub(r"\s+", " ", sanitized).strip()
    return sanitized[:200]


# ============================================================
# Metrics Collector Engine
# ============================================================

class PostgreSQLMetricsCollector:
    """
    Enterprise PostgreSQL Prometheus Collector.
    Collects availability, connection, query performance, lock contention,
    and storage metrics across single or multiple PostgreSQL databases.
    """

    def __init__(
        self,
        host: str = POSTGRES_HOST,
        port: int = POSTGRES_PORT,
        user: str = POSTGRES_USER,
        password: str = POSTGRES_PASSWORD,
        database: str = POSTGRES_DATABASE,
        timeout: float = POSTGRES_CONNECT_TIMEOUT,
        ssl_mode: str = POSTGRES_SSL_MODE,
        slow_query_threshold: float = SLOW_QUERY_THRESHOLD_SECONDS,
        explicit_databases: Optional[List[str]] = None
    ):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.timeout = timeout
        self.ssl_mode = ssl_mode
        self.slow_query_threshold = slow_query_threshold
        self.explicit_databases = explicit_databases or EXPLICIT_DATABASES

    async def get_connection(self, db_name: Optional[str] = None):
        """Creates an asyncpg connection with strict timeout and SSL handling."""
        if asyncpg is None:
            raise RuntimeError("asyncpg is required for PostgreSQL monitoring collection")

        target_db = db_name or self.database
        ssl_arg = False
        if self.ssl_mode in ["require", "verify-ca", "verify-full"]:
            ssl_arg = True

        return await asyncpg.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            database=target_db,
            timeout=self.timeout,
            ssl=ssl_arg
        )

    async def collect(self) -> bool:
        """
        Executes a complete scrape cycle.
        Returns True if successful, False if PostgreSQL was unreachable.
        Maintains strict distinction:
        - DB Down: pg_up = 0, pg_exporter_scrape_success = 0
        - Exporter remains online to serve metrics to Prometheus.
        """
        start_time = time.perf_counter()
        conn = None
        is_success = False

        try:
            conn = await self.get_connection()
            # If we connected successfully, PostgreSQL is UP
            pg_up.set(1)
            pg_connection_status.labels(database=self.database).set(1)
            pg_database_up.labels(database=self.database).set(1)

            # 1. Configured max_connections
            try:
                max_conn_row = await conn.fetchval("SHOW max_connections")
                max_conns = float(max_conn_row) if max_conn_row else 100.0
                pg_settings_max_connections.set(max_conns)
            except Exception:
                max_conns = 100.0
                pg_settings_max_connections.set(100.0)

            # 2. Discover monitored databases
            discovered_dbs = [self.database]
            if self.explicit_databases:
                for d in self.explicit_databases:
                    if d not in discovered_dbs:
                        discovered_dbs.append(d)
            else:
                try:
                    db_rows = await conn.fetch(
                        "SELECT datname FROM pg_database WHERE NOT datistemplate AND datallowconn"
                    )
                    for r in db_rows:
                        name = r["datname"]
                        if name not in discovered_dbs:
                            discovered_dbs.append(name)
                except Exception as exc:
                    pg_monitoring_errors_total.labels(error_type="db_discovery").inc()

            # 3. Collect cluster & database level metrics
            for db_name in discovered_dbs:
                await self._collect_database_metrics(conn, db_name, max_conns)

            # 4. Collect active locks & contention
            await self._collect_lock_metrics(conn, self.database)

            # 5. Collect slow queries & activity
            await self._collect_activity_and_slow_queries(conn, self.database)

            # 6. Collect table & storage inventory
            await self._collect_table_inventory(conn, self.database)

            # Record collection timestamp and success
            now_ts = time.time()
            pg_last_collection_timestamp.set(now_ts)
            pg_exporter_scrape_success.set(1)
            is_success = True

        except Exception as exc:
            # PostgreSQL is unreachable or failed
            pg_up.set(0)
            pg_connection_status.labels(database=self.database).set(0)
            pg_database_up.labels(database=self.database).set(0)
            pg_connection_errors_total.labels(database=self.database).inc()
            pg_monitoring_errors_total.labels(error_type=type(exc).__name__).inc()
            pg_exporter_scrape_success.set(0)
            is_success = False
        finally:
            if conn:
                try:
                    await conn.close()
                except Exception:
                    pass

            duration = time.perf_counter() - start_time
            pg_exporter_scrape_duration_seconds.set(duration)

        return is_success

    async def _collect_database_metrics(self, conn, db_name: str, max_conns: float):
        """Collects database statistics from pg_stat_database."""
        try:
            row = await conn.fetchrow(
                """
                SELECT
                    pg_database_size(datname) AS size_bytes,
                    COALESCE(xact_commit, 0) AS xact_commit,
                    COALESCE(xact_rollback, 0) AS xact_rollback,
                    COALESCE(blks_read, 0) AS blks_read,
                    COALESCE(blks_hit, 0) AS blks_hit,
                    COALESCE(deadlocks, 0) AS deadlocks
                FROM pg_stat_database
                WHERE datname = $1
                """,
                db_name
            )

            if row:
                size_b = float(row["size_bytes"] or 0)
                commits = float(row["xact_commit"] or 0)
                rollbacks = float(row["xact_rollback"] or 0)
                blks_read = float(row["blks_read"] or 0)
                blks_hit = float(row["blks_hit"] or 0)
                deadlocks = float(row["deadlocks"] or 0)

                pg_database_size_bytes.labels(database=db_name).set(size_b)
                pg_stat_database_xact_commit.labels(database=db_name).set(commits)
                pg_stat_database_xact_rollback.labels(database=db_name).set(rollbacks)
                pg_stat_database_blks_read.labels(database=db_name).set(blks_read)
                pg_stat_database_blks_hit.labels(database=db_name).set(blks_hit)
                pg_stat_database_deadlocks.labels(database=db_name).set(deadlocks)

                # Cache hit ratio
                total_blocks = blks_read + blks_hit
                if total_blocks > 0:
                    cache_hit_ratio = round((blks_hit / total_blocks) * 100.0, 2)
                else:
                    cache_hit_ratio = 100.0
                pg_cache_hit_ratio.labels(database=db_name).set(cache_hit_ratio)
                pg_database_up.labels(database=db_name).set(1)

        except Exception as exc:
            pg_monitoring_errors_total.labels(error_type="stat_database").inc()

    async def _collect_activity_and_slow_queries(self, conn, db_name: str):
        """Collects connection states, utilization, and slow queries from pg_stat_activity."""
        try:
            rows = await conn.fetch(
                """
                SELECT
                    COALESCE(state, 'waiting') AS state,
                    COALESCE(wait_event_type, '') AS wait_event_type,
                    EXTRACT(EPOCH FROM (now() - query_start)) AS duration,
                    query
                FROM pg_stat_activity
                WHERE datname = $1 AND pid <> pg_backend_pid()
                """,
                db_name
            )

            state_counts: Dict[str, int] = {
                "active": 0,
                "idle": 0,
                "idle in transaction": 0,
                "waiting": 0,
                "other": 0
            }

            slow_queries = 0
            slow_durations = []

            for r in rows:
                state = (r["state"] or "waiting").lower()
                dur = float(r["duration"] or 0.0)

                if "idle in transaction" in state:
                    state_counts["idle in transaction"] += 1
                elif "idle" in state:
                    state_counts["idle"] += 1
                elif "active" in state:
                    state_counts["active"] += 1
                elif r["wait_event_type"] in ["Lock", "LWLock"]:
                    state_counts["waiting"] += 1
                else:
                    state_counts["other"] += 1

                # Slow query detection
                if state == "active" and dur >= self.slow_query_threshold:
                    slow_queries += 1
                    slow_durations.append(dur)

            total_conns = sum(state_counts.values())

            for st, cnt in state_counts.items():
                pg_stat_activity_count.labels(database=db_name, state=st).set(cnt)

            max_conns = 100.0
            try:
                max_conns = pg_settings_max_connections._value.get() or 100.0
            except Exception:
                pass

            utilization = round((total_conns / max(1.0, max_conns)) * 100.0, 1)
            pg_connection_utilization_ratio.labels(database=db_name).set(utilization)

            pg_slow_queries_total.labels(database=db_name).set(slow_queries)
            if slow_durations:
                pg_slow_query_max_duration_seconds.labels(database=db_name).set(max(slow_durations))
                pg_slow_query_avg_duration_seconds.labels(database=db_name).set(
                    round(sum(slow_durations) / len(slow_durations), 3)
                )
            else:
                pg_slow_query_max_duration_seconds.labels(database=db_name).set(0.0)
                pg_slow_query_avg_duration_seconds.labels(database=db_name).set(0.0)

        except Exception as exc:
            pg_monitoring_errors_total.labels(error_type="stat_activity").inc()

    async def _collect_lock_metrics(self, conn, db_name: str):
        """Collects lock distribution and blocked query counts."""
        try:
            lock_rows = await conn.fetch(
                """
                SELECT
                    mode,
                    granted::text AS granted,
                    COUNT(*) AS count
                FROM pg_locks
                GROUP BY mode, granted
                """
            )

            waiting_locks = 0
            for r in lock_rows:
                mode = r["mode"]
                granted = r["granted"]
                cnt = float(r["count"])
                pg_locks_count.labels(database=db_name, mode=mode, granted=granted).set(cnt)
                if granted == "false":
                    waiting_locks += int(cnt)

            pg_locks_waiting_total.labels(database=db_name).set(waiting_locks)

            # Blocked / Blocking query count
            blocked_rows = await conn.fetch(
                """
                SELECT
                    COUNT(DISTINCT blocked.pid) AS blocked_count,
                    COUNT(DISTINCT blocking.pid) AS blocking_count,
                    COALESCE(MAX(EXTRACT(EPOCH FROM (now() - blocked.query_start))), 0) AS max_wait
                FROM pg_catalog.pg_locks blocked_locks
                JOIN pg_catalog.pg_stat_activity blocked ON blocked.pid = blocked_locks.pid
                JOIN pg_catalog.pg_locks blocking_locks
                    ON blocking_locks.locktype = blocked_locks.locktype
                    AND blocking_locks.database IS NOT DISTINCT FROM blocked_locks.database
                    AND blocking_locks.relation IS NOT DISTINCT FROM blocked_locks.relation
                    AND blocking_locks.page IS NOT DISTINCT FROM blocked_locks.page
                    AND blocking_locks.tuple IS NOT DISTINCT FROM blocked_locks.tuple
                    AND blocking_locks.virtualxid IS NOT DISTINCT FROM blocked_locks.virtualxid
                    AND blocking_locks.transactionid IS NOT DISTINCT FROM blocked_locks.transactionid
                    AND blocking_locks.classid IS NOT DISTINCT FROM blocked_locks.classid
                    AND blocking_locks.objid IS NOT DISTINCT FROM blocked_locks.objid
                    AND blocking_locks.objsubid IS NOT DISTINCT FROM blocked_locks.objsubid
                    AND blocking_locks.pid != blocked_locks.pid
                JOIN pg_catalog.pg_stat_activity blocking ON blocking.pid = blocking_locks.pid
                WHERE NOT blocked_locks.granted
                """
            )

            if blocked_rows:
                b_cnt = float(blocked_rows[0]["blocked_count"] or 0)
                blk_cnt = float(blocked_rows[0]["blocking_count"] or 0)
                max_wait = float(blocked_rows[0]["max_wait"] or 0.0)
                pg_blocked_queries_count.labels(database=db_name).set(b_cnt)
                pg_blocking_queries_count.labels(database=db_name).set(blk_cnt)
                pg_lock_wait_duration_seconds.labels(database=db_name).set(max_wait)
            else:
                pg_blocked_queries_count.labels(database=db_name).set(0)
                pg_blocking_queries_count.labels(database=db_name).set(0)
                pg_lock_wait_duration_seconds.labels(database=db_name).set(0.0)

        except Exception as exc:
            pg_monitoring_errors_total.labels(error_type="locks").inc()

    async def _collect_table_inventory(self, conn, db_name: str):
        """Discovers tables, live row counts, and table sizes."""
        try:
            table_rows = await conn.fetch(
                """
                SELECT
                    schemaname,
                    relname AS table_name,
                    COALESCE(n_live_tup, 0) AS row_count,
                    pg_total_relation_size(relid) AS size_bytes
                FROM pg_stat_user_tables
                ORDER BY size_bytes DESC
                """
            )

            pg_database_tables_total.labels(database=db_name).set(len(table_rows))

            idx_count = await conn.fetchval(
                "SELECT COUNT(*) FROM pg_stat_user_indexes"
            )
            pg_database_indexes_total.labels(database=db_name).set(float(idx_count or 0))

            for tr in table_rows:
                tbl = tr["table_name"]
                rows = float(tr["row_count"] or 0)
                size_b = float(tr["size_bytes"] or 0)
                pg_table_rows_total.labels(database=db_name, table=tbl).set(rows)
                pg_table_size_bytes.labels(database=db_name, table=tbl).set(size_b)

        except Exception as exc:
            pg_monitoring_errors_total.labels(error_type="tables").inc()


collector = PostgreSQLMetricsCollector()


# ============================================================
# Standalone Service Execution
# ============================================================

def get_metrics_text() -> str:
    """Returns the latest Prometheus exposition formatted metrics text."""
    return generate_latest(REGISTRY).decode("utf-8")


async def run_collector_loop(interval: int = COLLECTION_INTERVAL):
    """Periodically triggers PostgreSQL metrics collection."""
    while True:
        try:
            await collector.collect()
        except Exception as exc:
            print(f"[PostgreSQL Exporter Error]: {exc}", file=sys.stderr)
        await asyncio.sleep(interval)


def main():
    print("=" * 60)
    print("SmartQE TEM — Production PostgreSQL Prometheus Exporter")
    print(f"Target: {POSTGRES_USER}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DATABASE}")
    print(f"Exporter HTTP Port: {POSTGRES_EXPORTER_PORT}")
    print(f"Scrape Interval: {COLLECTION_INTERVAL}s")
    print("=" * 60)

    # Start Prometheus HTTP server
    start_http_server(POSTGRES_EXPORTER_PORT, addr=POSTGRES_EXPORTER_HOST)
    print(f"Prometheus metrics exposed at http://{POSTGRES_EXPORTER_HOST}:{POSTGRES_EXPORTER_PORT}/metrics")

    # Run collection loop
    try:
        asyncio.run(run_collector_loop(COLLECTION_INTERVAL))
    except KeyboardInterrupt:
        print("\nPostgreSQL Exporter shut down gracefully.")


if __name__ == "__main__":
    main()
