@echo off
title Prometheus Server (TEM with Lifecycle Hot-Reload)
cd /d "%~dp0"
echo =========================================================================
echo  Starting Prometheus Server with --web.enable-lifecycle
echo  Configuration: prometheus.yml
echo  Alert Rules:   alert_rules.yml
echo =========================================================================
prometheus.exe --config.file="prometheus.yml" --web.enable-lifecycle
pause
