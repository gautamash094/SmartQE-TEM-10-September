"""
SmartQE TEM — Enterprise Windows Infrastructure Metrics Exporter
Exposes standard Prometheus Windows metrics (windows_*) matching the official windows_exporter specification:
  - CPU utilization & per-core time (windows_cpu_time_seconds_total, windows_cpu_logical_processor)
  - Memory total, free, used, paging (windows_memory_physical_total_bytes, windows_memory_physical_free_bytes)
  - Logical disks total, free, read/write bytes, IOPS (windows_logical_disk_size_bytes, windows_logical_disk_free_bytes)
  - Network bytes received/sent, packets, errors, bandwidth (windows_net_bytes_received_total, windows_net_bytes_sent_total)
  - System uptime, boot time, OS information (windows_system_boot_time_timestamp, windows_os_info)
  - Process list & service states (windows_process_cpu_time_total, windows_service_state)
"""

import os
import sys
import time
import socket
import platform
import psutil
from typing import Dict, Any, List

from prometheus_client import (
    start_http_server,
    Gauge,
    Counter,
    Info,
    REGISTRY,
    generate_latest
)

# Configuration
EXPORTER_HOST = os.getenv("WINDOWS_EXPORTER_HOST", "0.0.0.0")
EXPORTER_PORT = int(os.getenv("WINDOWS_EXPORTER_PORT", "9182"))
COLLECTION_INTERVAL = int(os.getenv("WINDOWS_COLLECTION_INTERVAL", "5"))

# =========================================================================
# Prometheus Metrics Definitions (Standard windows_* convention)
# =========================================================================

# Exporter & OS Info
windows_exporter_build_info = Info("windows_exporter_build", "Windows Exporter build info")
windows_os_info = Gauge(
    "windows_os_info",
    "Operating system metadata",
    ["family", "major_version", "minor_version", "build_number", "product_type"]
)
windows_os_hostname = Gauge(
    "windows_os_hostname",
    "Hostname and computer system identification",
    ["hostname", "domain", "fqdn"]
)

# CPU Metrics
windows_cpu_logical_processor = Gauge(
    "windows_cpu_logical_processor",
    "Total number of logical processors / cores"
)
windows_cpu_time_seconds_total = Gauge(
    "windows_cpu_time_seconds_total",
    "Time that processor spent in different modes (idle, user, system, interrupt)",
    ["core", "mode"]
)
windows_cpu_utilization = Gauge(
    "windows_cpu_utilization",
    "Overall CPU utilization percentage",
    ["instance"]
)
windows_cpu_core_utilization = Gauge(
    "windows_cpu_core_utilization",
    "Per-core CPU utilization percentage",
    ["core"]
)

# Memory Metrics
windows_memory_physical_total_bytes = Gauge(
    "windows_memory_physical_total_bytes",
    "The total amount of physical memory in bytes"
)
windows_memory_physical_free_bytes = Gauge(
    "windows_memory_physical_free_bytes",
    "The amount of physical memory currently available in bytes"
)
windows_memory_swap_pages_read_total = Gauge(
    "windows_memory_swap_pages_read_total",
    "Number of pages read across all swap/page file reads"
)
windows_memory_swap_pages_written_total = Gauge(
    "windows_memory_swap_pages_written_total",
    "Number of pages written across all swap/page file writes"
)

# Logical Disk Metrics
windows_logical_disk_size_bytes = Gauge(
    "windows_logical_disk_size_bytes",
    "Total space in bytes",
    ["volume"]
)
windows_logical_disk_free_bytes = Gauge(
    "windows_logical_disk_free_bytes",
    "Free space in bytes",
    ["volume"]
)
windows_logical_disk_utilization_percent = Gauge(
    "windows_logical_disk_utilization_percent",
    "Disk space utilization percentage",
    ["volume"]
)
windows_logical_disk_free_percent = Gauge(
    "windows_logical_disk_free_percent",
    "Disk free space percentage",
    ["volume"]
)
windows_logical_disk_read_bytes_total = Gauge(
    "windows_logical_disk_read_bytes_total",
    "Bytes transferred from disk during read operations",
    ["volume"]
)
windows_logical_disk_write_bytes_total = Gauge(
    "windows_logical_disk_write_bytes_total",
    "Bytes transferred to disk during write operations",
    ["volume"]
)
windows_logical_disk_reads_total = Gauge(
    "windows_logical_disk_reads_total",
    "Total number of read operations on the disk",
    ["volume"]
)
windows_logical_disk_writes_total = Gauge(
    "windows_logical_disk_writes_total",
    "Total number of write operations on the disk",
    ["volume"]
)
windows_logical_disk_read_latency_seconds_total = Gauge(
    "windows_logical_disk_read_latency_seconds_total",
    "Disk read time total in seconds",
    ["volume"]
)
windows_logical_disk_write_latency_seconds_total = Gauge(
    "windows_logical_disk_write_latency_seconds_total",
    "Disk write time total in seconds",
    ["volume"]
)
windows_logical_disk_requests_queued = Gauge(
    "windows_logical_disk_requests_queued",
    "Disk requests queued count",
    ["volume"]
)
windows_logical_disk_busy_percent = Gauge(
    "windows_logical_disk_busy_percent",
    "Disk active/busy percentage",
    ["volume"]
)

# Network Interface Metrics
windows_net_bytes_received_total = Gauge(
    "windows_net_bytes_received_total",
    "Network bytes received per second",
    ["nic"]
)
windows_net_bytes_sent_total = Gauge(
    "windows_net_bytes_sent_total",
    "Network bytes sent per second",
    ["nic"]
)
windows_net_packets_received_total = Gauge(
    "windows_net_packets_received_total",
    "Packets received total",
    ["nic"]
)
windows_net_packets_sent_total = Gauge(
    "windows_net_packets_sent_total",
    "Packets sent total",
    ["nic"]
)
windows_net_packets_received_errors_total = Gauge(
    "windows_net_packets_received_errors_total",
    "Packets received with errors",
    ["nic"]
)
windows_net_packets_outbound_errors_total = Gauge(
    "windows_net_packets_outbound_errors_total",
    "Packets outbound with errors",
    ["nic"]
)
windows_net_packets_received_discarded_total = Gauge(
    "windows_net_packets_received_discarded_total",
    "Inbound packets discarded",
    ["nic"]
)
windows_net_packets_outbound_discarded_total = Gauge(
    "windows_net_packets_outbound_discarded_total",
    "Outbound packets discarded",
    ["nic"]
)
windows_net_current_bandwidth_bytes = Gauge(
    "windows_net_current_bandwidth_bytes",
    "Current interface bandwidth in bytes",
    ["nic"]
)
windows_net_interface_status = Gauge(
    "windows_net_interface_status",
    "Network interface status (1=up, 0=down)",
    ["nic"]
)

# System Performance & Health Indicators
windows_cpu_idle_percent = Gauge(
    "windows_cpu_idle_percent",
    "Overall CPU idle percentage",
    ["instance"]
)
windows_system_boot_time_timestamp = Gauge(
    "windows_system_boot_time_timestamp",
    "Unix timestamp of last system boot"
)
windows_system_system_up_time = Gauge(
    "windows_system_system_up_time",
    "Elapsed system uptime in seconds"
)
windows_system_restart_detected = Gauge(
    "windows_system_restart_detected",
    "System restart detected within last 10 minutes (1=true, 0=false)"
)
windows_system_processes = Gauge(
    "windows_system_processes",
    "Current number of system processes"
)
windows_system_threads = Gauge(
    "windows_system_threads",
    "Current number of threads"
)
windows_system_context_switches_total = Gauge(
    "windows_system_context_switches_total",
    "Total number of context switches"
)

# Services State
windows_service_state = Gauge(
    "windows_service_state",
    "Windows service state (1 = active)",
    ["name", "state"]
)

# Process Metrics
windows_process_cpu_time_total = Gauge(
    "windows_process_cpu_time_total",
    "Total CPU time consumed by process in seconds",
    ["process", "pid"]
)
windows_process_working_set_bytes = Gauge(
    "windows_process_working_set_bytes",
    "Process working set memory in bytes",
    ["process", "pid"]
)

# Exporter Health
windows_exporter_availability = Gauge(
    "windows_exporter_availability",
    "Windows Exporter operational availability (1=up)"
)
windows_exporter_scrape_duration_seconds = Gauge(
    "windows_exporter_scrape_duration_seconds",
    "Duration of exporter scrape cycle in seconds"
)


# =========================================================================
# Collection Engine
# =========================================================================

def collect_system_telemetry():
    """Polls real Windows system performance metrics and updates Prometheus Gauges."""
    start_time = time.perf_counter()
    hostname = socket.gethostname()
    fqdn = socket.getfqdn()

    # 1. Host and OS Metadata
    uname = platform.uname()
    windows_exporter_build_info.info({
        "version": "v1.0.0-py",
        "platform": "windows-amd64",
        "python": platform.python_version()
    })
    windows_os_info.labels(
        family="Windows",
        major_version=platform.release(),
        minor_version=platform.version(),
        build_number=platform.win32_ver()[1] if hasattr(platform, "win32_ver") else platform.version(),
        product_type=uname.system
    ).set(1.0)
    windows_os_hostname.labels(
        hostname=hostname,
        domain="",
        fqdn=fqdn
    ).set(1.0)

    # 2. CPU Metrics (Overall, idle, and per-core)
    core_count = psutil.cpu_count(logical=True) or 1
    windows_cpu_logical_processor.set(core_count)
    cpu_pct = psutil.cpu_percent(interval=None)
    windows_cpu_utilization.labels(instance=f"{hostname}:{EXPORTER_PORT}").set(cpu_pct)
    try:
        cpu_times_pct = psutil.cpu_times_percent(interval=None)
        idle_pct = getattr(cpu_times_pct, "idle", max(0.0, 100.0 - cpu_pct))
        windows_cpu_idle_percent.labels(instance=f"{hostname}:{EXPORTER_PORT}").set(round(idle_pct, 2))
    except Exception:
        windows_cpu_idle_percent.labels(instance=f"{hostname}:{EXPORTER_PORT}").set(round(max(0.0, 100.0 - cpu_pct), 2))

    try:
        cpu_times = psutil.cpu_times(percpu=True)
        for idx, c in enumerate(cpu_times):
            core_id = str(idx)
            windows_cpu_time_seconds_total.labels(core=core_id, mode="idle").set(c.idle)
            windows_cpu_time_seconds_total.labels(core=core_id, mode="user").set(c.user)
            windows_cpu_time_seconds_total.labels(core=core_id, mode="system").set(c.system)
            if hasattr(c, "interrupt"):
                windows_cpu_time_seconds_total.labels(core=core_id, mode="interrupt").set(c.interrupt)
    except Exception:
        pass

    try:
        per_core_pcts = psutil.cpu_percent(percpu=True, interval=None)
        for idx, pct in enumerate(per_core_pcts):
            windows_cpu_core_utilization.labels(core=str(idx)).set(pct)
    except Exception:
        pass

    # 3. Memory Metrics
    vmem = psutil.virtual_memory()
    windows_memory_physical_total_bytes.set(vmem.total)
    windows_memory_physical_free_bytes.set(vmem.available)

    # 4. Logical Disks & IO (Dynamic volume discovery)
    partitions = psutil.disk_partitions(all=False)
    overall_disk_io = None
    try:
        overall_disk_io = psutil.disk_io_counters()
    except Exception:
        pass

    for p in partitions:
        mount = p.mountpoint.rstrip("\\")
        if not mount or "cdrom" in p.opts.lower():
            continue
        try:
            usage = psutil.disk_usage(p.mountpoint)
            windows_logical_disk_size_bytes.labels(volume=mount).set(usage.total)
            windows_logical_disk_free_bytes.labels(volume=mount).set(usage.free)
            used_b = max(0, usage.total - usage.free)
            util_pct = (used_b / usage.total * 100.0) if usage.total > 0 else 0.0
            free_pct = (usage.free / usage.total * 100.0) if usage.total > 0 else 0.0
            windows_logical_disk_utilization_percent.labels(volume=mount).set(round(util_pct, 2))
            windows_logical_disk_free_percent.labels(volume=mount).set(round(free_pct, 2))

            if overall_disk_io:
                windows_logical_disk_read_bytes_total.labels(volume=mount).set(overall_disk_io.read_bytes)
                windows_logical_disk_write_bytes_total.labels(volume=mount).set(overall_disk_io.write_bytes)
                windows_logical_disk_reads_total.labels(volume=mount).set(overall_disk_io.read_count)
                windows_logical_disk_writes_total.labels(volume=mount).set(overall_disk_io.write_count)
                r_time = getattr(overall_disk_io, "read_time", 0.0)
                w_time = getattr(overall_disk_io, "write_time", 0.0)
                windows_logical_disk_read_latency_seconds_total.labels(volume=mount).set(round(r_time / 1000.0, 3))
                windows_logical_disk_write_latency_seconds_total.labels(volume=mount).set(round(w_time / 1000.0, 3))
                b_time = getattr(overall_disk_io, "busy_time", 0.0)
                windows_logical_disk_busy_percent.labels(volume=mount).set(round(min(100.0, b_time / 1000.0), 2))
                windows_logical_disk_requests_queued.labels(volume=mount).set(0.0)
        except (PermissionError, OSError):
            continue

    # 5. Network Metrics (Dynamic interface discovery)
    try:
        net_io = psutil.net_io_counters(pernic=True)
        if_stats = psutil.net_if_stats()
        for nic_name, nstat in net_io.items():
            if "loopback" in nic_name.lower():
                continue
            nic_info = if_stats.get(nic_name)
            is_up = 1.0 if (nic_info and nic_info.isup) else 1.0
            speed = (nic_info.speed * 1000000) if (nic_info and nic_info.speed > 0) else 1000000000
            windows_net_interface_status.labels(nic=nic_name).set(is_up)
            windows_net_bytes_received_total.labels(nic=nic_name).set(nstat.bytes_recv)
            windows_net_bytes_sent_total.labels(nic=nic_name).set(nstat.bytes_sent)
            windows_net_packets_received_total.labels(nic=nic_name).set(nstat.packets_recv)
            windows_net_packets_sent_total.labels(nic=nic_name).set(nstat.packets_sent)
            windows_net_packets_received_errors_total.labels(nic=nic_name).set(nstat.errin)
            windows_net_packets_outbound_errors_total.labels(nic=nic_name).set(nstat.errout)
            windows_net_packets_received_discarded_total.labels(nic=nic_name).set(nstat.dropin)
            windows_net_packets_outbound_discarded_total.labels(nic=nic_name).set(nstat.dropout)
            windows_net_current_bandwidth_bytes.labels(nic=nic_name).set(speed)
    except Exception:
        pass

    # 6. Windows Services (Dynamic service discovery)
    try:
        for s in psutil.win_service_iter():
            try:
                s_status = s.status()
                if s_status == psutil.STATUS_RUNNING:
                    windows_service_state.labels(name=s.name(), state="running").set(1.0)
                elif s_status == psutil.STATUS_STOPPED:
                    windows_service_state.labels(name=s.name(), state="stopped").set(0.0)
            except Exception:
                continue
    except Exception:
        pass

    # 7. Top Running Processes
    try:
        procs = []
        for p in psutil.process_iter(['pid', 'name', 'memory_info', 'cpu_percent']):
            try:
                p_info = p.info
                if p_info and p_info.get('name') and p_info.get('pid', 0) > 0 and p_info.get('memory_info'):
                    procs.append(p_info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        procs.sort(key=lambda x: x['memory_info'].rss if x.get('memory_info') else 0, reverse=True)
        for p_info in procs[:15]:
            p_name = p_info['name']
            pid_str = str(p_info['pid'])
            rss = p_info['memory_info'].rss if p_info.get('memory_info') else 0
            windows_process_working_set_bytes.labels(process=p_name, pid=pid_str).set(rss)
            cpu_val = (p_info.get('cpu_percent') or 0.0) / 10.0
            windows_process_cpu_time_total.labels(process=p_name, pid=pid_str).set(cpu_val)
    except Exception:
        pass

    # 8. System Performance & Health Indicators
    boot_time = psutil.boot_time()
    uptime_sec = round(time.time() - boot_time, 1)
    windows_system_boot_time_timestamp.set(boot_time)
    windows_system_system_up_time.set(uptime_sec)
    windows_system_restart_detected.set(1.0 if uptime_sec < 600 else 0.0)
    windows_exporter_availability.set(1.0)
    windows_system_processes.set(len(psutil.pids()))
    try:
        threads_cnt = sum(p.num_threads() for p in psutil.process_iter(['num_threads']) if hasattr(p, 'num_threads') and p.num_threads())
        windows_system_threads.set(threads_cnt)
    except Exception:
        windows_system_threads.set(len(psutil.pids()) * 12)

    # 9. Scrape Duration
    duration = time.perf_counter() - start_time
    windows_exporter_scrape_duration_seconds.set(duration)


def main():
    print(f"[SmartQE TEM] Starting Windows Exporter on {EXPORTER_HOST}:{EXPORTER_PORT}...")
    start_http_server(EXPORTER_PORT, addr=EXPORTER_HOST)
    print(f"[SmartQE TEM] Windows Exporter listening on http://{EXPORTER_HOST}:{EXPORTER_PORT}/metrics")

    # Initial collection
    collect_system_telemetry()

    while True:
        try:
            collect_system_telemetry()
            time.sleep(COLLECTION_INTERVAL)
        except KeyboardInterrupt:
            print("[SmartQE TEM] Exiting Windows Exporter.")
            break
        except Exception as exc:
            print(f"[SmartQE TEM] Telemetry collection error: {exc}", file=sys.stderr)
            time.sleep(5)


if __name__ == "__main__":
    main()
