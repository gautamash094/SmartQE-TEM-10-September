@echo off
title Alertmanager Server (TEM Live Webhook Dispatcher)
cd /d "%~dp0"
echo =========================================================================
echo  Starting Alertmanager Server on port 9093
echo  Configuration: alertmanager.yml
echo  Webhook Target: http://localhost:8000/api/v1/monitoring/alertmanager/webhook
echo =========================================================================
alertmanager.exe --config.file="alertmanager.yml" --storage.path="data"
pause
