# =============================================================================
# SmartQE TEM — Windows Infrastructure Exporter Launcher
# Starts windows_exporter on port 9182 for Prometheus scraping.
# =============================================================================

param (
    [string]$Mode = "binary", # "binary" (windows_exporter.exe) or "python" (windows_exporter.py)
    [int]$Port = 9182
)

$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition

if ($Mode -eq "binary") {
    $exePath = Join-Path $PSScriptRoot "windows_exporter.exe"
    if (Test-Path $exePath) {
        Write-Host "[SmartQE TEM] Starting native windows_exporter.exe on port $Port..." -ForegroundColor Cyan
        & $exePath --telemetry.addr=":$Port" --collectors.enabled="cpu,cs,logical_disk,memory,net,os,physical_disk,service,system,process"
    } else {
        Write-Warning "windows_exporter.exe not found at $exePath. Falling back to Python exporter..."
        $Mode = "python"
    }
}

if ($Mode -eq "python") {
    $pyScript = Join-Path $PSScriptRoot "windows_exporter.py"
    Write-Host "[SmartQE TEM] Starting Python Windows Exporter on port $Port..." -ForegroundColor Green
    python $pyScript
}
