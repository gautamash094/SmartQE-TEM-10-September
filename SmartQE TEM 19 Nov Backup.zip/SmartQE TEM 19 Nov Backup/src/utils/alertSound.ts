/**
 * SmartQE TEM — Browser Native Web Audio Synthesizer for Real-Time Alerts
 * Uses Web Audio API (AudioContext) so zero external audio assets are required.
 * Generates crisp, high-tech chimes for Warning, Critical, and Severe threshold breaches.
 */

const STORAGE_KEY = 'smartqe_alert_sound_enabled';

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return null;
    if (!audioCtx) {
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    return audioCtx;
  } catch {
    return null;
  }
}

export function isAlertSoundEnabled(): boolean {
  if (typeof window === 'undefined') return true;
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored !== 'false'; // Default to true
}

export function setAlertSoundEnabled(enabled: boolean): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, enabled ? 'true' : 'false');
}

/**
 * Plays a resonant dual-frequency chime based on alert severity.
 * @param severity 'WARNING' | 'CRITICAL' | 'SEVERE' | 'INFO'
 */
export function playAlertSound(severity: string = 'WARNING'): void {
  if (!isAlertSoundEnabled()) return;

  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const sev = (severity || 'WARNING').toUpperCase();
    const isUrgent = sev === 'CRITICAL' || sev === 'SEVERE';
    const now = ctx.currentTime;

    // Pulse 1: Base chime
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();

    osc1.type = isUrgent ? 'sawtooth' : 'sine';
    const startFreq1 = isUrgent ? 880 : 587.33; // A5 or D5
    const endFreq1 = isUrgent ? 1046.5 : 880;   // C6 or A5

    osc1.frequency.setValueAtTime(startFreq1, now);
    osc1.frequency.exponentialRampToValueAtTime(endFreq1, now + 0.12);

    gain1.gain.setValueAtTime(isUrgent ? 0.25 : 0.2, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc1.connect(gain1);
    gain1.connect(ctx.destination);

    osc1.start(now);
    osc1.stop(now + 0.35);

    // Pulse 2: Second harmonics pulse for urgency
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();

    osc2.type = isUrgent ? 'sawtooth' : 'sine';
    const startFreq2 = isUrgent ? 987.77 : 783.99; // B5 or G5
    const endFreq2 = isUrgent ? 1318.51 : 1046.5;  // E6 or C6

    const pulse2Start = now + 0.15;
    osc2.frequency.setValueAtTime(startFreq2, pulse2Start);
    osc2.frequency.exponentialRampToValueAtTime(endFreq2, pulse2Start + 0.12);

    gain2.gain.setValueAtTime(isUrgent ? 0.3 : 0.22, pulse2Start);
    gain2.gain.exponentialRampToValueAtTime(0.001, pulse2Start + 0.4);

    osc2.connect(gain2);
    gain2.connect(ctx.destination);

    osc2.start(pulse2Start);
    osc2.stop(pulse2Start + 0.4);
  } catch (err) {
    console.warn('Unable to play alert audio chime:', err);
  }
}

/**
 * Triggers a test sound with user gesture context resumption.
 */
export function testAlertSound(severity: string = 'CRITICAL'): void {
  const ctx = getAudioContext();
  if (ctx && ctx.state === 'suspended') {
    ctx.resume().then(() => playAlertSound(severity)).catch(() => {});
  } else {
    playAlertSound(severity);
  }
}
