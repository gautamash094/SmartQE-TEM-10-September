import { EnvironmentProfile, ServerDetail, SoftwareDetail } from './environmentDetails';
import { Incident, Booking } from './index';

export type EnvironmentHealthStatus =
  | 'HEALTHY'
  | 'DEGRADED'
  | 'UNHEALTHY'
  | 'UNAVAILABLE'
  | 'MAINTENANCE'
  | 'UNKNOWN';

export type TestReadinessStatus =
  | 'READY_FOR_TESTING'
  | 'PARTIALLY_READY'
  | 'NOT_READY'
  | 'UNKNOWN';

export type AlertSeverity = 'CRITICAL' | 'HIGH' | 'WARNING' | 'INFO';
export type AlertStatus = 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED';
export type EventState = 'NORMAL' | 'WARNING' | 'CRITICAL' | 'RECOVERED';
export type TimeframeOption = '1h' | '6h' | '24h' | '7d' | '30d';

export interface HealthCategoryScores {
  infrastructure: number;
  application: number;
  database: number;
  services: number;
  configuration: number;
  overall_health_score: number;
  status: EnvironmentHealthStatus;
  status_details: string;
}

export interface MetricPoint {
  timestamp: string; // ISO string
  value: number;
}

export interface MetricSeries {
  metricName: string;
  unit: string;
  points: MetricPoint[];
  current: number;
  avg: number;
  peak: number;
}

export interface HistoricalTelemetry {
  environmentId: string;
  timeframe: TimeframeOption;
  cpu: MetricSeries;
  memory: MetricSeries;
  disk: MetricSeries;
  networkLatency: MetricSeries;
  responseTime: MetricSeries;
  errorRate: MetricSeries;
  throughput: MetricSeries;
  healthScoreTrend?: MetricSeries;
}

export interface ReadinessCheckResult {
  environmentId: string;
  environmentName: string;
  status: TestReadinessStatus;
  score: number; // 0 to 100
  checks: {
    environmentAvailable: boolean;
    serversOnline: boolean;
    servicesHealthy: boolean;
    databaseConnected?: boolean;
    noVersionDrift?: boolean;
    noBlockingIncidents: boolean;
    noMaintenanceBlock: boolean;
    noBookingCollision: boolean;
    exportersHealthy?: boolean;
    metricsFresh?: boolean;
    capacityHeadroomOk?: boolean;
  };
  reasons: string[];
}

export interface SoftwareDriftSummary {
  total_software: number;
  matching: number;
  version_mismatch: number;
  missing: number;
  outdated: number;
  consistency_health_score: number;
  has_drift: boolean;
}

export interface ReleaseImpactSummary {
  has_active_workload: boolean;
  impacted_application?: string;
  impacted_release?: string;
  impacted_phase?: string;
  active_bookings_count: number;
  affected_teams: string[];
  affected_users_count: number;
  impact_level: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export interface AutoHealActionSummary {
  is_auto_heal_available: boolean;
  rule_id?: string;
  rule_name?: string;
  action_type?: string;
  action_target?: string;
  requires_approval: boolean;
  last_execution_status?: string;
}

export interface PredictiveInsight {
  insight_type: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  target: string;
  message: string;
  predicted_breach_timeline?: string;
  confidence_score: number;
  recommended_action: string;
}

export interface EnvironmentDetailedObservability {
  environment_id: string;
  environment_name: string;
  tier: string;
  owner: string;
  team: string;
  current_status: EnvironmentHealthStatus;
  uptime: number;
  health: HealthCategoryScores;
  readiness: ReadinessCheckResult;
  cpu_usage: number;
  memory_usage: number;
  storage_usage: number;
  network_latency_ms: number;
  api_p95_ms: number;
  error_rate_pct: number;
  drift_summary: SoftwareDriftSummary;
  impact_summary: ReleaseImpactSummary;
  auto_heal: AutoHealActionSummary;
  predictive_insights: PredictiveInsight[];
  active_critical_alerts: number;
  active_warning_alerts: number;
  active_correlated_incidents?: number;
  last_health_check_time?: string;
  data_freshness_seconds?: number;
  is_data_stale?: boolean;
  last_scrape_duration_ms?: number;
  scraper_health?: string;
}

export interface FleetObservabilityKPIs {
  total_monitored_environments: number;
  healthy_environments: number;
  degraded_environments: number;
  unhealthy_environments: number;
  unavailable_environments: number;
  maintenance_environments: number;
  ready_for_testing_environments: number;
  readiness_rate_pct: number;
  environments_with_drift: number;
  environments_with_active_releases: number;
  fleet_average_health_score: number;
  fleet_availability_pct: number;
  mean_time_to_recovery_minutes: number;
  auto_heal_success_rate_pct: number;
  active_critical_events: number;
  active_warning_events: number;
  active_correlated_incidents?: number;
  active_targets_count?: number;
  active_exporters_count?: number;
  stale_metrics_count?: number;
  scraper_success_rate_pct?: number;
}

export interface FleetObservabilitySummary {
  kpis: FleetObservabilityKPIs;
  environments: EnvironmentDetailedObservability[];
  recent_events: MonitoringAlert[];
  predictive_alerts: PredictiveInsight[];
  correlated_incidents?: CorrelatedIncident[];
}

export interface MonitoringAlert {
  id: string;
  environmentId: string;
  environmentName: string;
  targetType: 'SERVER' | 'SERVICE' | 'APPLICATION' | 'ENVIRONMENT' | 'DATABASE';
  targetId?: string;
  targetName: string;
  title: string;
  message: string;
  severity: AlertSeverity;
  status: AlertStatus;
  state?: EventState;
  currentValue?: number;
  thresholdValue?: number;
  triggeredAt: string;
  acknowledgedAt?: string;
  acknowledgedBy?: string;
  resolvedAt?: string;
  linkedIncidentId?: string;
  autoHealTriggered?: boolean;
}

export interface AlertRule {
  id: string;
  name: string;
  environmentId?: string; // 'ALL' or specific
  metricName: 'CPU' | 'MEMORY' | 'DISK' | 'LATENCY' | 'ERROR_RATE' | 'SERVICE_DOWN';
  operator: '>' | '>=' | '<' | '==';
  threshold: number;
  warningThreshold?: number;
  criticalThreshold?: number;
  durationMinutes: number;
  severity: AlertSeverity;
  autoEscalateIncident: boolean;
  autoHealEnabled?: boolean;
  enabled: boolean;
}

export interface MaintenanceWindow {
  id: string;
  environmentId: string;
  environmentName: string;
  title: string;
  description: string;
  scheduledStart: string;
  scheduledEnd: string;
  createdBy: string;
  suppressAlerts: boolean;
  status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED';
}

export interface TelemetryLog {
  id: string;
  environmentId: string;
  timestamp: string;
  level: 'ERROR' | 'WARN' | 'INFO' | 'DEBUG';
  serviceName: string;
  serverName: string;
  message: string;
  traceId?: string;
}

export interface TelemetryTraceSpan {
  id: string;
  serviceName: string;
  name: string;
  durationMs: number;
  startTimeOffsetMs: number;
  status: 'OK' | 'ERROR';
  tags: Record<string, string>;
}

export interface TelemetryTrace {
  traceId: string;
  environmentId: string;
  rootService: string;
  operationName: string;
  totalDurationMs: number;
  timestamp: string;
  status: 'OK' | 'ERROR';
  spans: TelemetryTraceSpan[];
}

export type MetricAvailabilityState = 
  | 'ACTIVE_VALUE' 
  | 'ZERO_VALUE' 
  | 'UNSUPPORTED' 
  | 'UNAVAILABLE' 
  | 'STALE';

export interface ConnectionTestResult {
  success: boolean;
  latency_ms: number;
  message: string;
  discovered_capabilities: string[];
  raw_probe_details?: Record<string, any>;
}

export interface MonitoringIntegrationConfig {
  id: string;
  tool_identifier: string;
  tool_type: 'PROMETHEUS' | 'DATADOG' | 'NAGIOS' | 'OPENTELEMETRY' | 'NEW_RELIC' | 'DYNATRACE' | 'CLOUDWATCH' | 'CUSTOM';
  display_name: string;
  description?: string;
  is_enabled: boolean;
  base_url: string;
  tls_verify: boolean;
  ca_cert_path?: string;
  timeout_seconds: number;
  retry_count: number;
  retry_backoff_factor: number;
  auth_type: string;
  custom_headers?: Record<string, string>;
  capabilities: string[];
  metric_mappings?: Record<string, string>;
  environment_scope: string[];
  priority: number;
  is_default_for_scope: boolean;
  scrape_interval_seconds: number;
  health_check_path: string;
  health_check_interval_seconds: number;
  tool_parameters?: Record<string, any>;
  target_assignments?: Record<string, any>;
  masked_credentials: Record<string, string>;
  version: number;
  modified_by?: string;
  created_at: string;
  updated_at: string;
}

export interface MonitoringSourceIntegration {
  id: string;
  name: string;
  type: 'PROMETHEUS' | 'CUSTOM' | 'DATADOG' | 'DYNATRACE' | 'AWS_CLOUDWATCH' | 'OPENTELEMETRY';
  status: 'CONNECTED' | 'DEGRADED' | 'DISCONNECTED';
  endpoint: string;
  lastSyncAt: string;
  activeMetricsCount: number;
}

export interface MonitoringExporter {
  id: string;
  target_id: string;
  name: string;
  exporter_type: string;
  endpoint_url: string;
  status: 'EXPORTER_UP' | 'EXPORTER_DOWN' | 'DEGRADED' | 'UNKNOWN';
  version?: string;
  last_scrape_time?: string;
  scrape_duration_ms: number;
  success_count: number;
  failure_count: number;
  error_message?: string;
}

export interface MonitoringTarget {
  id: string;
  name: string;
  environment_id: string;
  environment_name: string;
  application_name?: string;
  service_name?: string;
  server_name?: string;
  target_type: 'LINUX_SERVER' | 'WINDOWS_SERVER' | 'SERVER' | 'SERVICE' | 'APPLICATION' | 'REST_API' | 'MICROSERVICE' | 'DATABASE' | 'CONTAINER' | string;
  endpoint_url: string;
  scrape_interval_seconds: number;
  scrape_timeout_seconds: number;
  is_enabled: boolean;
  target_status: 'UP' | 'DOWN' | 'DEGRADED' | 'UNREACHABLE' | 'UNKNOWN';
  scrape_status: 'SUCCESS' | 'FAILURE' | 'TIMEOUT' | 'STALE' | 'UNKNOWN';
  last_scrape_time?: string;
  last_successful_scrape?: string;
  last_failed_scrape?: string;
  scrape_duration_ms: number;
  metrics_freshness_seconds: number;
  is_stale: boolean;
  is_up?: boolean;
  error_message?: string;
  labels: Record<string, any>;
  exporters: MonitoringExporter[];
}

export interface CorrelatedIncident {
  id: string;
  incident_code: string;
  environment_id: string;
  environment_name: string;
  title: string;
  severity: AlertSeverity;
  status: 'TRIGGERED' | 'ACKNOWLEDGED' | 'INVESTIGATING' | 'RESOLVED';
  root_cause_type: string;
  root_cause_summary: string;
  recommended_action?: string;
  correlated_alert_ids: string[];
  affected_components: string[];
  blast_radius_summary?: string;
  created_at: string;
  acknowledged_at?: string;
  acknowledged_by?: string;
  resolved_at?: string;
  resolved_by?: string;
}

export interface NotificationRule {
  id: string;
  name: string;
  environment_id?: string;
  min_severity: AlertSeverity;
  channel: 'IN_APP' | 'EMAIL' | 'SLACK' | 'WEBHOOK';
  recipients: string;
  is_enabled: boolean;
  template?: string;
}

export interface CapacityHistoricalPoint {
  timestamp: string;
  value: number;
}

export interface CapacityForecast {
  environment_id: string;
  environment_name: string;
  metric_name: string;
  current_value: number;
  unit: string;
  warning_threshold: number;
  critical_threshold: number;
  growth_rate_daily: number;
  days_to_warning_breach?: number;
  days_to_critical_breach?: number;
  projected_breach_date?: string;
  capacity_health: 'HEALTHY' | 'APPROACHING_LIMIT' | 'CRITICAL';
  recommendation: string;
  historical_points?: CapacityHistoricalPoint[];
}

export interface TestExecutionCorrelation {
  id: string;
  test_run_id: string;
  test_suite_name: string;
  test_phase: string;
  environment_id: string;
  environment_name: string;
  started_at: string;
  completed_at?: string;
  status: 'PASSED' | 'FAILED' | 'RUNNING';
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  is_environment_caused: boolean;
  failure_root_cause?: string;
  linked_incident_id?: string;
  correlated_anomalies: Array<{ metric: string; value: string }>;
  environment_health_at_run: number;
}

export interface MonitoringSelfHealth {
  service_status: string;
  scraper_status: string;
  collector_status: string;
  query_engine_status: string;
  active_targets_count: number;
  active_exporters_count: number;
  scrape_success_rate_pct: number;
  avg_scrape_duration_ms: number;
  stored_metric_samples_count: number;
  metrics_retention_days: number;
  queue_backlog_size: number;
  uptime_seconds: number;
  storage_engine: string;
  last_scraper_run: string;
}

export interface PromQLMetricResult {
  metric: Record<string, string>;
  value?: [number, string];
  values?: Array<[number, string]>;
}

export interface PromQLQueryResponse {
  status: 'success' | 'error';
  data: {
    resultType: 'matrix' | 'vector' | 'scalar' | 'string';
    result: PromQLMetricResult[];
  };
  errorType?: string;
  error?: string;
}

// =========================================================================
// UNIFIED MONITORING MODEL TYPES (APACHE ECHARTS & IN-HOUSE DASHBOARDS)
// =========================================================================

export interface UnifiedMetricSample {
  availability_state?: MetricAvailabilityState;
  unsupported_reason?: string;
  environment: string;
  environment_id: string;
  target: string;
  target_type: 'SERVER' | 'APPLICATION' | 'DATABASE' | 'SERVICE' | 'CONTAINER' | 'CUSTOM';
  server?: string;
  application?: string;
  service?: string;
  metric: string;
  metric_type: 'GAUGE' | 'COUNTER' | 'HISTOGRAM' | 'SUMMARY';
  value: number;
  unit: string;
  timestamp: string;
  status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'UNKNOWN';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | 'INFO';
  source: string;
  provider: string;
  labels: Record<string, string>;
  threshold?: { warning?: number; critical?: number };
  data_freshness_seconds: number;
  freshness_status: 'FRESH' | 'STALE' | 'EXPIRED';
}

export interface ApplicationDependencyInfo {
  name: string;
  dependency_type: 'DATABASE' | 'REST_API' | 'MESSAGE_QUEUE' | 'EXTERNAL_SERVICE';
  endpoint: string;
  status: 'HEALTHY' | 'WARNING' | 'DOWN' | 'UNKNOWN';
  latency_ms: number;
  error_count: number;
  last_checked: string;
}

export interface ApplicationRuntimeResources {
  jvm_heap_used_mb: number;
  jvm_heap_max_mb: number;
  jvm_heap_utilization_pct: number;
  thread_count: number;
  thread_peak_count: number;
  active_db_connections: number;
  max_db_connections: number;
  gc_pause_ms: number;
  gc_count: number;
  process_cpu_pct?: number;
  process_memory_mb?: number;
  process_virtual_memory_mb?: number;
  open_file_descriptors?: number;
  runtime_type?: string;
}

export interface ApplicationPerformanceMetrics {
  response_time_ms: number;
  p50_latency_ms: number;
  p90_latency_ms?: number;
  p95_latency_ms: number;
  p99_latency_ms: number;
  request_rate_rps: number;
  throughput_rps: number;
  error_rate_pct: number;
  total_requests?: number;
  active_requests?: number;
  http_2xx_count: number;
  http_4xx_count: number;
  http_5xx_count: number;
  slow_requests_count: number;
}

export interface ApplicationAvailabilityMetrics {
  is_up: boolean;
  health_status: 'HEALTHY' | 'DEGRADED' | 'DOWN' | 'UNKNOWN';
  uptime_pct: number;
  startup_status: string;
  readiness_status: string;
  endpoint_availability_pct: number;
  last_heartbeat: string;
}

export interface ApplicationMonitoringDossier {
  id: string;
  name: string;
  application_name?: string;
  software_name?: string;
  category?: string;
  environment_id: string;
  environment_name: string;
  version: string;
  hosted_on_server: string;
  hosted_on_server_id?: string;
  server_ip?: string;
  runtime?: string;
  monitoring_source: string;
  availability: ApplicationAvailabilityMetrics;
  performance: ApplicationPerformanceMetrics;
  resources: ApplicationRuntimeResources;
  dependencies: ApplicationDependencyInfo[];
  active_alerts_count: number;
  active_alerts: any[];
  metric_freshness_seconds: number;
}

export interface ServerCpuMetrics {
  utilization_pct: number;
  idle_pct?: number;
  cores_count: number;
  load_1m: number;
  load_5m: number;
  load_15m: number;
  saturation_pct: number;
  trend: 'INCREASING' | 'DECREASING' | 'STABLE';
  per_core_utilization?: Array<{ core: string; utilization_pct: number }>;
}

export interface ServerMemoryMetrics {
  total_gb: number;
  used_gb: number;
  available_gb: number;
  utilization_pct: number;
  swap_total_gb: number;
  swap_used_gb: number;
  swap_utilization_pct: number;
}

export interface ServerDiskMetrics {
  total_gb: number;
  used_gb: number;
  free_gb: number;
  utilization_pct: number;
  free_pct?: number;
  read_throughput_mb_s: number;
  write_throughput_mb_s: number;
  iops: number;
  latency_ms?: number;
  queue_length?: number;
  busy_pct?: number;
  mount_point: string;
  volumes?: Array<{
    volume: string;
    total_gb: number;
    free_gb: number;
    used_gb: number;
    utilization_pct: number;
    free_pct?: number;
  }>;
}

export interface ServerNetworkMetrics {
  utilization_pct: number;
  rx_rate_kb_s: number;
  tx_rate_kb_s: number;
  total_traffic_kb_s?: number;
  packets_rx_per_sec?: number;
  packets_tx_per_sec?: number;
  packet_errors: number;
  packet_drops: number;
  interfaces?: Array<{
    name: string;
    rx_rate_kb_s: number;
    tx_rate_kb_s: number;
    is_up?: boolean;
    errors?: number;
    mac_address?: string;
  }>;
}

export interface ServerProcessItem {
  pid: number;
  name: string;
  status: string;
  cpu_pct: number;
  memory_mb: number;
  restart_count: number;
}

export interface ServerMonitoringDossier {
  id: string;
  name: string;
  hostname: string;
  ip_address: string;
  os_type: 'LINUX' | 'WINDOWS';
  environment_id: string;
  environment_name: string;
  status: 'UP' | 'DOWN' | 'DEGRADED' | 'UNREACHABLE';
  is_exporter_available: boolean;
  exporter_type: string;
  monitoring_source: string;
  last_scrape_time: string;
  metric_freshness_seconds: number;
  system_uptime_seconds?: number;
  system_boot_time?: string;
  restart_detected?: boolean;
  os_version?: string;
  cpu: ServerCpuMetrics;
  memory: ServerMemoryMetrics;
  disk: ServerDiskMetrics;
  network: ServerNetworkMetrics;
  processes: ServerProcessItem[];
  services?: Array<{ name: string; state: string }>;
  performance_indicators?: Record<string, any>;
  hosted_applications: string[];
  hosted_applications_count: number;
  active_alerts_count: number;
  active_alerts: any[];
}

export interface HostedAppSummary {
  app_id: string;
  app_name: string;
  application_name?: string;
  software_name?: string;
  category?: string;
  version?: string;
  status: string;
  response_time_ms: number;
  error_rate_pct: number;
}

export interface ServerTopologyNode {
  server_id: string;
  server_name: string;
  ip_address: string;
  os_type: string;
  status: string;
  cpu_pct: number;
  memory_pct: number;
  disk_pct: number;
  hosted_applications: HostedAppSummary[];
}

export interface AppServerTopologyMap {
  environment_id: string;
  environment_name: string;
  total_servers: number;
  total_applications: number;
  servers: ServerTopologyNode[];
}

export interface ReadinessGateItem {
  gate_name: string;
  description: string;
  status: 'PASSED' | 'FAILED' | 'WARNING';
  passed: boolean;
  details: string;
}

export interface EnvironmentReadinessAssessment {
  environment_id: string;
  environment_name: string;
  status: 'READY_FOR_TESTING' | 'PARTIALLY_READY' | 'NOT_READY';
  overall_readiness_score: number;
  passed_gates_count: number;
  total_gates_count: number;
  gates: ReadinessGateItem[];
  blocking_reasons: string[];
  evaluated_at: string;
}

export interface MonitoringSourceHealthItem {
  source_id: string;
  source_name: string;
  adapter_name: string;
  source_type: 'PROMETHEUS' | 'APM' | 'SERVER_TOOL' | 'CUSTOM';
  status: 'HEALTHY' | 'WARNING' | 'DOWN' | 'UNKNOWN';
  connectivity: boolean;
  api_available: boolean;
  latency_ms: number;
  data_freshness_seconds: number;
  last_sync_time: string;
  query_failures_count: number;
  error_message?: string;
}

export interface MetricComparisonValue {
  metric_name: string;
  before_test: number;
  during_test: number;
  unit: string;
  variance_pct: number;
  threshold: number;
  is_saturated: boolean;
}

export interface TestCorrelationAnalysis {
  test_run_id: string;
  test_suite_name: string;
  test_phase: string;
  environment_id: string;
  environment_name: string;
  started_at: string;
  completed_at?: string;
  status: string;
  application_response_time: MetricComparisonValue;
  server_cpu: MetricComparisonValue;
  server_memory: MetricComparisonValue;
  application_error_rate: MetricComparisonValue;
  is_environment_caused: boolean;
  diagnostic_verdict: string;
  recommended_action: string;
  correlated_incidents: string[];
}

export interface HistoricalDataPoint {
  timestamp: string;
  value: number;
}

export interface HistoricalSeries {
  name: string;
  unit: string;
  points: HistoricalDataPoint[];
  current: number;
  avg: number;
  peak: number;
  min_val: number;
}

export interface UnifiedHistoricalTelemetry {
  environment_id: string;
  target_id?: string;
  target_name?: string;
  timeframe: string;
  interval_seconds: number;
  series: Record<string, HistoricalSeries>;
}

export interface DataFreshnessInfo {
  age_seconds: number;
  status: 'FRESH' | 'STALE' | 'UNKNOWN';
  threshold_seconds: number;
}

export interface NormalizedOverview {
  timestamp: string;
  environment_count: number;
  healthy_environment_count: number;
  warning_environment_count: number;
  degraded_environment_count: number;
  critical_environment_count: number;
  down_environment_count: number;
  active_alert_count: number;
  critical_alert_count: number;
  monitoring_target_count: number;
  healthy_target_count: number;
  active_providers_count: number;
  healthy_providers_count: number;
  total_metrics_discovered: number;
  data_freshness: DataFreshnessInfo;
}

export interface NormalizedResource {
  id: string;
  name: string;
  type: string;
  technology: string;
  monitoring_source: string;
  status: string;
  is_up: boolean;
  environment_id?: string;
  environment_name?: string;
  endpoint_url?: string;
  labels: Record<string, string>;
  metadata: Record<string, any>;
  metrics_summary: Record<string, any>;
  last_updated: string;
  data_freshness: DataFreshnessInfo;
}

export interface DiscoveredMetricItem {
  name: string;
  type: string;
  help_text?: string;
  unit?: string;
  category: string;
  labels: string[];
}

export interface DynamicMetricCatalog {
  source: string;
  total_count: number;
  metrics: DiscoveredMetricItem[];
  categories: string[];
  timestamp: string;
}

export interface OperationalMetricsSummary {
  uptime_seconds: number;
  total_api_requests: number;
  api_request_duration_avg_ms: number;
  total_provider_queries: number;
  provider_query_errors: number;
  provider_query_duration_avg_ms: number;
  registered_providers: string[];
  active_providers: string[];
  cache_hit_ratio: number;
  last_freshness_seconds: number;
}

// =========================================================================
// NORMALIZED SERVER & THRESHOLD MONITORING INTERFACES
// =========================================================================

export interface NormalizedServer {
  id: string;
  name: string;
  hostname: string;
  ip_address: string;
  os_type: 'WINDOWS' | 'LINUX';
  os_version?: string;
  environment_id: string;
  environment_name: string;
  status: 'UP' | 'DOWN' | 'DEGRADED' | 'UNREACHABLE';
  is_exporter_available: boolean;
  exporter_type: string;
  monitoring_source: string;
  system_uptime_seconds?: number;
  system_boot_time?: string;
  last_scrape_time: string;
  metric_freshness_seconds: number;
  restart_detected: boolean;
  hosted_applications: string[];
}

export interface ServerMetricItem {
  server_id: string;
  metric_category: 'CPU' | 'CORE' | 'MEMORY' | 'DISK_VOLUME' | 'DISK_IO' | 'NETWORK' | 'AVAILABILITY' | 'SERVICE' | 'PROCESS';
  metric_name: string;
  value: number;
  unit: string;
  timestamp: string;
  labels: Record<string, string>;
  status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'DOWN';
  data_freshness_seconds: number;
}

export interface ServerResourceItem {
  id: string;
  server_id: string;
  resource_type: 'LOGICAL_CORE' | 'DISK_VOLUME' | 'NETWORK_INTERFACE' | 'SERVICE' | 'PROCESS';
  name: string;
  capacity?: number;
  used?: number;
  free?: number;
  utilization_pct?: number;
  free_pct?: number;
  unit: string;
  status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'DOWN';
  details: Record<string, any>;
}

export interface ServerHealthItem {
  server_id: string;
  overall_status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'DOWN' | 'UNKNOWN';
  health_score: number;
  cpu_status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'DOWN';
  memory_status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'DOWN';
  disk_status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'DOWN';
  network_status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'DOWN';
  services_status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'DOWN';
  exporter_status: 'HEALTHY' | 'DOWN';
  freshness_status: 'FRESH' | 'STALE';
  active_alerts_count: number;
  warning_count: number;
  critical_count: number;
  evaluated_at: string;
}

export interface ServerThresholdItem {
  id: string;
  server_id?: string;
  name: string;
  metric_category: string;
  target_resource?: string;
  operator: string;
  warning_threshold: number;
  critical_threshold: number;
  severe_threshold?: number;
  duration_minutes: number;
  unit: string;
  is_enabled: boolean;
  created_at: string;
  updated_at?: string;
}

export interface ServerThresholdCreatePayload {
  name: string;
  server_id?: string;
  metric_category: string;
  target_resource?: string;
  operator?: string;
  warning_threshold: number;
  critical_threshold: number;
  severe_threshold?: number;
  duration_minutes?: number;
  unit?: string;
  is_enabled?: boolean;
}

export interface ServerAlertItem {
  alert_id: string;
  fingerprint?: string;
  server_id: string;
  server_name: string;
  resource: string;
  metric_name: string;
  condition: string;
  current_value?: number;
  threshold_value?: number;
  severity: 'WARNING' | 'CRITICAL' | 'SEVERE' | 'INFO';
  status: 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED';
  message: string;
  labels: Record<string, string>;
  annotations: Record<string, string>;
  started_at: string;
  acknowledged_at?: string;
  acknowledged_by?: string;
  resolved_at?: string;
}

export interface ServerAvailabilityItem {
  server_id: string;
  hostname: string;
  ip_address: string;
  is_reachable: boolean;
  exporter_status: 'UP' | 'DOWN';
  target_health: 'UP' | 'DOWN' | 'UNKNOWN';
  scrape_duration_ms: number;
  last_scrape_time?: string;
  metric_freshness_seconds: number;
  restart_detected: boolean;
  system_uptime_seconds: number;
  uptime_formatted: string;
}




