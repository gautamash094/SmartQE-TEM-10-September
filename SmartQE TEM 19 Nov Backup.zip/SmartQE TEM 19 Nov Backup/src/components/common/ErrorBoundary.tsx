import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home, ChevronDown, ChevronUp } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  showDetails: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    showDetails: false,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null, showDetails: false };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error trapped by ErrorBoundary:', error, errorInfo);
    this.setState({ error, errorInfo });
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null, showDetails: false });
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  private handleReload = () => {
    window.location.reload();
  };

  private toggleDetails = () => {
    this.setState((prev) => ({ showDetails: !prev.showDetails }));
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      const errorMessage = this.state.error?.message || 'An unexpected rendering error occurred.';
      const stack = this.state.errorInfo?.componentStack || this.state.error?.stack || '';

      return (
        <div className="min-h-screen bg-[#080c14] text-slate-100 flex items-center justify-center p-4">
          <div className="max-w-xl w-full bg-[#0d1424] border border-rose-900/60 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-rose-950/60 border border-rose-800/80 flex items-center justify-center text-rose-400 shrink-0 shadow-inner">
                <AlertTriangle className="w-7 h-7" />
              </div>
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-rose-500 block">
                  TEM RUNTIME ERROR
                </span>
                <h2 className="text-xl font-black text-white mt-0.5">Component Render Failure</h2>
                <p className="text-xs text-slate-400 mt-1">
                  The dashboard caught an unexpected error. You can recover by refreshing or returning to the main dashboard.
                </p>
              </div>
            </div>

            <div className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 font-mono text-xs text-rose-300 break-words">
              {errorMessage}
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={this.handleReload}
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-md"
              >
                <RefreshCw className="w-4 h-4" /> Reload Page
              </button>

              <a
                href="/tem-dashboard"
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold text-slate-300 bg-slate-800 hover:bg-slate-700 transition-all border border-slate-700"
              >
                <Home className="w-4 h-4" /> Return to Dashboard
              </a>

              {stack && (
                <button
                  type="button"
                  onClick={this.toggleDetails}
                  className="ml-auto flex items-center gap-1 px-3 py-2 text-xs text-slate-400 hover:text-slate-200 transition-colors"
                >
                  <span>{this.state.showDetails ? 'Hide' : 'Show'} Details</span>
                  {this.state.showDetails ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              )}
            </div>

            {this.state.showDetails && stack && (
              <div className="mt-4 pt-4 border-t border-slate-800">
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-2">
                  Component Stack Trace:
                </span>
                <pre className="p-3 bg-black/60 rounded-lg text-[10px] font-mono text-slate-400 max-h-48 overflow-y-auto whitespace-pre-wrap break-all border border-slate-900">
                  {stack}
                </pre>
              </div>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
