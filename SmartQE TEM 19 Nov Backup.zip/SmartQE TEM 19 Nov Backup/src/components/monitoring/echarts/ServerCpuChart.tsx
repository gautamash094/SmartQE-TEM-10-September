import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { HistoricalSeries } from '../../../types/monitoring';

export interface ServerCpuChartProps {
  series?: HistoricalSeries;
  title?: string;
  currentUtil?: number;
  idlePct?: number;
  warningThreshold?: number;
  criticalThreshold?: number;
  severeThreshold?: number;
  height?: string;
}

export const ServerCpuChart: React.FC<ServerCpuChartProps> = ({
  series,
  title = 'Server CPU Utilization',
  currentUtil,
  idlePct,
  warningThreshold = 70,
  criticalThreshold = 85,
  severeThreshold = 95,
  height = '280px',
}) => {
  const options = useMemo<echarts.EChartsOption>(() => {
    const timestamps = series?.points?.map((p) => p.timestamp) || [];
    const values = series?.points?.map((p) => p.value) || [];

    const effectiveCurrent = currentUtil !== undefined ? currentUtil : (values.length ? values[values.length - 1] : 0);
    const effectiveIdle = idlePct !== undefined ? idlePct : Math.max(0, +(100 - effectiveCurrent).toFixed(1));

    const markLines: any[] = [];
    if (warningThreshold) {
      markLines.push({
        yAxis: warningThreshold,
        lineStyle: { color: '#f59e0b', type: 'dashed', width: 1.5 },
        label: {
          formatter: `Warn (${warningThreshold}%)`,
          position: 'insideEndTop',
          color: '#f59e0b',
          fontSize: 10,
        },
      });
    }
    if (criticalThreshold) {
      markLines.push({
        yAxis: criticalThreshold,
        lineStyle: { color: '#ef4444', type: 'dashed', width: 1.5 },
        label: {
          formatter: `Crit (${criticalThreshold}%)`,
          position: 'insideEndTop',
          color: '#ef4444',
          fontSize: 10,
        },
      });
    }
    if (severeThreshold) {
      markLines.push({
        yAxis: severeThreshold,
        lineStyle: { color: '#b91c1c', type: 'solid', width: 2 },
        label: {
          formatter: `Severe (${severeThreshold}%)`,
          position: 'insideEndTop',
          color: '#f87171',
          fontSize: 10,
        },
      });
    }

    return {
      title: {
        text: title,
        subtext: `Current Load: ${effectiveCurrent}%  |  Idle: ${effectiveIdle}%  |  Trend: ${series?.points && series.points.length > 1 && values[values.length - 1] > values[0] ? '↑ Rising' : '→ Stable'}`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        subtextStyle: { color: '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          const item = params[0];
          const val = Number(item.value);
          const itemIdle = Math.max(0, +(100 - val).toFixed(1));
          return `
            <div class="font-sans">
              <div class="text-slate-400 text-xs mb-1">${item.axisValue}</div>
              <div class="flex items-center gap-2 mb-1">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="font-semibold text-slate-300">CPU Usage:</span>
                <span class="text-cyan-400 font-bold">${val}%</span>
              </div>
              <div class="flex items-center gap-2 text-xs text-slate-400">
                <span>CPU Idle:</span>
                <span class="text-emerald-400 font-semibold">${itemIdle}%</span>
              </div>
            </div>
          `;
        },
      },
      grid: {
        top: 55,
        left: 45,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: timestamps,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        min: 0,
        max: 100,
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: '{value}%',
        },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'CPU Usage',
          type: 'line',
          smooth: true,
          data: values,
          itemStyle: { color: '#38bdf8' },
          lineStyle: { width: 2.5, color: '#38bdf8' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(56, 189, 248, 0.45)' },
              { offset: 1, color: 'rgba(56, 189, 248, 0.02)' },
            ]),
          },
          markLine: {
            silent: true,
            symbol: 'none',
            data: markLines,
          },
        },
      ],
    };
  }, [series, title, currentUtil, idlePct, warningThreshold, criticalThreshold, severeThreshold]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
