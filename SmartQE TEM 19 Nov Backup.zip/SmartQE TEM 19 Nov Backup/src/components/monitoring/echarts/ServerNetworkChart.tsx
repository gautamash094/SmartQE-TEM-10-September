import React, { useMemo, useState } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { HistoricalSeries } from '../../../types/monitoring';

export interface NetworkInterfaceData {
  name: string;
  rx_rate_kb_s: number;
  tx_rate_kb_s: number;
  is_up?: boolean;
  errors?: number;
  mac_address?: string;
}

export interface ServerNetworkChartProps {
  series?: HistoricalSeries;
  rxSeries?: HistoricalSeries;
  txSeries?: HistoricalSeries;
  interfaces?: NetworkInterfaceData[];
  totalTrafficKbS?: number;
  packetsRxPerSec?: number;
  packetsTxPerSec?: number;
  packetErrors?: number;
  packetDrops?: number;
  title?: string;
  height?: string;
}

export const ServerNetworkChart: React.FC<ServerNetworkChartProps> = ({
  series,
  rxSeries,
  txSeries,
  interfaces = [],
  totalTrafficKbS,
  packetsRxPerSec = 0,
  packetsTxPerSec = 0,
  packetErrors = 0,
  packetDrops = 0,
  title = 'Server Network Traffic & Throughput',
  height = '280px',
}) => {
  const [selectedNic, setSelectedNic] = useState<string>('ALL');

  const safeInterfaces = useMemo(() => (Array.isArray(interfaces) ? interfaces : []), [interfaces]);

  const activeNic = useMemo(() => {
    if (selectedNic === 'ALL' || safeInterfaces.length === 0) return null;
    return safeInterfaces.find((n) => n.name === selectedNic) || safeInterfaces[0];
  }, [selectedNic, safeInterfaces]);

  const effectiveTraffic = totalTrafficKbS !== undefined
    ? totalTrafficKbS
    : (activeNic ? activeNic.rx_rate_kb_s + activeNic.tx_rate_kb_s : 0);

  const options = useMemo<echarts.EChartsOption>(() => {
    // If multiple interfaces and ALL selected, render bar breakdown per NIC
    if (safeInterfaces.length > 1 && selectedNic === 'ALL') {
      const nicNames = safeInterfaces.map((n) => n.name);
      const rxValues = safeInterfaces.map((n) => n.rx_rate_kb_s);
      const txValues = safeInterfaces.map((n) => n.tx_rate_kb_s);

      return {
        title: {
          text: title,
          subtext: `Interfaces: ${safeInterfaces.length}  |  Total Traffic: ${effectiveTraffic.toFixed(1)} KB/s  |  Errors: ${packetErrors}  |  Packets/s: ${(packetsRxPerSec + packetsTxPerSec).toFixed(0)}`,
          textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
          subtextStyle: { color: '#94a3b8', fontSize: 11 },
          left: 0,
          top: 0,
        },
        legend: {
          data: ['RX Bandwidth', 'TX Bandwidth'],
          textStyle: { color: '#94a3b8', fontSize: 11 },
          top: 0,
          right: 10,
        },
        tooltip: {
          trigger: 'axis',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc', fontSize: 12 },
          formatter: (params: any) => {
            const nicName = params[0]?.name;
            const nic = interfaces.find((n) => n.name === nicName);
            let html = `<div class="font-sans"><div class="text-slate-400 text-xs mb-1 font-semibold">${nicName} (${nic?.is_up ? 'ONLINE' : 'OFFLINE'})</div>`;
            params.forEach((item: any) => {
              html += `
                <div class="flex items-center gap-2 mb-0.5">
                  <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                  <span class="text-slate-300 font-medium">${item.seriesName}:</span>
                  <span class="font-bold text-white">${item.value} KB/s</span>
                </div>
              `;
            });
            html += `</div>`;
            return html;
          },
        },
        grid: {
          top: 55,
          left: 55,
          right: 25,
          bottom: 30,
        },
        xAxis: {
          type: 'category',
          data: nicNames,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: { color: '#94a3b8', fontSize: 10 },
        },
        yAxis: {
          type: 'value',
          axisLabel: { color: '#94a3b8', fontSize: 10, formatter: '{value} KB/s' },
          splitLine: { lineStyle: { color: '#1e293b' } },
        },
        series: [
          {
            name: 'RX Bandwidth',
            type: 'bar',
            data: rxValues,
            itemStyle: { color: '#06b6d4', borderRadius: [3, 3, 0, 0] },
            barMaxWidth: 28,
          },
          {
            name: 'TX Bandwidth',
            type: 'bar',
            data: txValues,
            itemStyle: { color: '#8b5cf6', borderRadius: [3, 3, 0, 0] },
            barMaxWidth: 28,
          },
        ],
      };
    }

    // Historical time series for single/selected NIC
    const effectiveRx = rxSeries || series;
    const timestamps =
      effectiveRx?.points?.map((p) => p.timestamp) ||
      txSeries?.points?.map((p) => p.timestamp) ||
      [];
    const rxValues = effectiveRx?.points?.map((p) => p.value) || [];
    const txValues = txSeries?.points?.map((p) => p.value) || [];

    return {
      title: {
        text: title,
        subtext: `Interface: ${activeNic ? activeNic.name : 'Default'}  |  Total Traffic: ${effectiveTraffic.toFixed(1)} KB/s  |  Packets: ${packetsRxPerSec} RX/s, ${packetsTxPerSec} TX/s  |  Errors: ${packetErrors}`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        subtextStyle: { color: '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      legend: {
        data: ['Inbound (RX)', 'Outbound (TX)'],
        textStyle: { color: '#94a3b8', fontSize: 11 },
        top: 0,
        right: 10,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          let html = `<div class="font-sans"><div class="text-slate-400 text-xs mb-1">${params[0].axisValue}</div>`;
          params.forEach((item: any) => {
            html += `
              <div class="flex items-center gap-2 mb-0.5">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="text-slate-300 font-medium">${item.seriesName}:</span>
                <span class="font-bold text-white">${item.value} KB/s</span>
              </div>
            `;
          });
          html += '</div>';
          return html;
        },
      },
      grid: {
        top: 55,
        left: 55,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: timestamps,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: '{value} KB/s',
        },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'Inbound (RX)',
          type: 'line',
          smooth: true,
          data: rxValues,
          itemStyle: { color: '#06b6d4' },
          lineStyle: { width: 2, color: '#06b6d4' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(6, 182, 212, 0.35)' },
              { offset: 1, color: 'rgba(6, 182, 212, 0.01)' },
            ]),
          },
        },
        {
          name: 'Outbound (TX)',
          type: 'line',
          smooth: true,
          data: txValues,
          itemStyle: { color: '#8b5cf6' },
          lineStyle: { width: 2, color: '#8b5cf6' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(139, 92, 246, 0.35)' },
              { offset: 1, color: 'rgba(139, 92, 246, 0.01)' },
            ]),
          },
        },
      ],
    };
  }, [series, rxSeries, txSeries, interfaces, selectedNic, activeNic, effectiveTraffic, packetErrors, packetsRxPerSec, packetsTxPerSec, title]);

  return (
    <div className="relative">
      {interfaces.length > 1 && (
        <div className="absolute right-0 top-0 z-10 flex items-center gap-1.5 bg-slate-900/80 px-2 py-0.5 rounded border border-slate-700 text-xs text-slate-300">
          <span className="text-slate-400">NIC:</span>
          <select
            value={selectedNic}
            onChange={(e) => setSelectedNic(e.target.value)}
            className="bg-transparent text-white focus:outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-slate-900 text-white">All Interfaces</option>
            {interfaces.map((n) => (
              <option key={n.name} value={n.name} className="bg-slate-900 text-white">
                {n.name}
              </option>
            ))}
          </select>
        </div>
      )}
      <BaseEChart options={options} style={{ height, width: '100%' }} />
    </div>
  );
};
