import React, { useMemo } from 'react';
import { AppServerTopologyMap } from '../../../types/monitoring';
import { Server, Layers, Cpu, HardDrive, ArrowRight, Activity, CheckCircle2 } from 'lucide-react';

export interface AppServerRelationshipWidgetProps {
  topology?: AppServerTopologyMap | null;
  onSelectServer?: (serverId: string) => void;
  onSelectApplication?: (appId: string) => void;
}

export const AppServerRelationshipWidget: React.FC<AppServerRelationshipWidgetProps> = ({
  topology,
  onSelectServer,
  onSelectApplication,
}) => {
  const servers = topology?.servers || [];

  if (servers.length === 0) {
    return (
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-8 text-center min-h-[160px] flex flex-col items-center justify-center">
        <Server className="w-8 h-8 text-slate-600 mb-2" />
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Application-to-Server Relationship & Drill-Down
        </h4>
        <p className="text-[11px] text-slate-500 mt-1">
          No host servers or hosted application mappings discovered for this environment.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-4">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Software / Application to Server Relationship & Drill-Down
            </h4>
            <p className="text-[10px] text-slate-400">
              Correlates software package and application health with host server conditions for cross-tier troubleshooting
            </p>
          </div>
        </div>
        <div className="text-[11px] text-slate-400 font-medium">
          {servers.length} Host Servers &bull; {servers.reduce((acc, s) => acc + s.hosted_applications.length, 0)} Software / Applications
        </div>
      </div>

      {/* Relationship Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
        {servers.map((server) => (
          <div
            key={server.server_id}
            className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 hover:border-slate-700 transition-all flex flex-col justify-between"
          >
            {/* Host Server Details */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-2.5">
                <div className="p-2 rounded-lg bg-cyan-950/40 border border-cyan-800/60 text-cyan-400">
                  <Server className="w-4 h-4" />
                </div>
                <div>
                  <button
                    onClick={() => onSelectServer?.(server.server_id)}
                    className="text-xs font-bold text-slate-100 hover:text-cyan-400 text-left transition-colors flex items-center gap-1.5"
                  >
                    <span>{server.server_name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">({server.ip_address})</span>
                  </button>
                  <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-400">
                    <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-medium">{server.os_type}</span>
                    <span>Status: <strong className="text-emerald-400 font-semibold">{server.status}</strong></span>
                  </div>
                </div>
              </div>

              {/* Server Metrics Summary */}
              <div className="flex items-center gap-2 text-[10px] bg-slate-900/80 px-2.5 py-1.5 rounded-lg border border-slate-800">
                <div>
                  <span className="text-slate-500 block text-[9px]">CPU</span>
                  <span className={`font-bold ${server.cpu_pct > 80 ? 'text-rose-400' : 'text-cyan-400'}`}>
                    {server.cpu_pct}%
                  </span>
                </div>
                <div className="w-px h-5 bg-slate-800" />
                <div>
                  <span className="text-slate-500 block text-[9px]">RAM</span>
                  <span className="text-emerald-400 font-bold">{server.memory_pct}%</span>
                </div>
                <div className="w-px h-5 bg-slate-800" />
                <div>
                  <span className="text-slate-500 block text-[9px]">Disk</span>
                  <span className="text-amber-400 font-bold">{server.disk_pct}%</span>
                </div>
              </div>
            </div>

            {/* Hosted Software & Applications */}
            <div className="pt-2.5 border-t border-slate-800/60">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-2">
                Hosted Software & Applications ({server.hosted_applications.length}):
              </span>
              <div className="space-y-1.5">
                {server.hosted_applications.map((app) => (
                  <div
                    key={app.app_id}
                    onClick={() => onSelectApplication?.(app.app_id)}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/40 hover:bg-slate-850 border border-slate-800/50 hover:border-cyan-800/50 cursor-pointer transition-all text-xs group"
                  >
                    <div className="flex items-start gap-2.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {app.application_name && (
                            <span className="px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-800/60 text-cyan-300 font-bold text-[10px] tracking-wide">
                              {app.application_name}
                            </span>
                          )}
                          <span className="font-semibold text-slate-100 group-hover:text-cyan-300 text-xs transition-colors">
                            {app.software_name || app.app_name}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-slate-400">
                          <span>Software: <strong className="text-slate-300 font-medium">{app.software_name || app.app_name}</strong></span>
                          {app.application_name && (
                            <>
                              <span className="text-slate-600">&bull;</span>
                              <span>App: <strong className="text-cyan-400 font-medium">{app.application_name}</strong></span>
                            </>
                          )}
                          {app.version && (
                            <>
                              <span className="text-slate-600">&bull;</span>
                              <span className="text-slate-500 font-mono">v{app.version}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 text-[11px] shrink-0 ml-2">
                      <span className="text-slate-400">
                        p95: <strong className="text-slate-200">{app.response_time_ms}ms</strong>
                      </span>
                      <span className="text-slate-400">
                        err: <strong className="text-slate-200">{app.error_rate_pct}%</strong>
                      </span>
                      <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-cyan-400 transition-transform group-hover:translate-x-0.5" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
