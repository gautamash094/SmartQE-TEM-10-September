import React, { useMemo } from 'react';
import { BaseEChart } from './BaseEChart';
import { EChartsOption } from 'echarts';
import { CapacityForecast } from '../../../types/monitoring';
import { TrendingUp, AlertTriangle, CheckCircle2, HardDrive, Cpu, Database, Calendar, Activity } from 'lucide-react';

interface CapacityForecastChartProps {
  forecast: CapacityForecast;
  height?: string | number;
}

export const CapacityForecastChart: React.FC<CapacityForecastChartProps> = ({
  forecast,
  height = '300px',
}) => {
  const hasTelemetry =
    (forecast.historical_points && forecast.historical_points.length > 0) ||
    forecast.current_value > 0;

  const isCritical = forecast.capacity_health === 'CRITICAL';
  const isApproaching = forecast.capacity_health === 'APPROACHING_LIMIT';
  const daysToBreach = forecast.days_to_critical_breach ?? forecast.days_to_warning_breach ?? null;

  const chartOptions: EChartsOption = useMemo(() => {
    // Zero Synthetic Data Policy: Plot only authentic telemetry points
    const rawHistory = forecast.historical_points || [];
    const histDates: string[] = [];
    const histValues: number[] = [];
    const projDates: string[] = [];
    const projValues: (number | null)[] = [];

    if (rawHistory.length > 0) {
      const sortedHistory = [...rawHistory].sort(
        (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );

      sortedHistory.forEach((pt) => {
        const d = new Date(pt.timestamp);
        const label = isNaN(d.getTime())
          ? pt.timestamp
          : `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
        histDates.push(label);
        histValues.push(pt.value);
      });

      // Linear projection based on real regression slope
      const growth = forecast.growth_rate_daily || 0;
      const lastPt = sortedHistory[sortedHistory.length - 1];
      const lastDate = new Date(lastPt.timestamp);
      const current = forecast.current_value;

      if (growth > 0.01) {
        for (let i = 1; i <= 14; i++) {
          const d = new Date(lastDate.getTime() + i * 86400000);
          projDates.push(`${d.getMonth() + 1}/${d.getDate()}`);
          const val = Math.min(100, Math.max(0, current + i * growth));
          projValues.push(Number(val.toFixed(1)));
        }
      }
    } else {
      histDates.push('Current');
      histValues.push(forecast.current_value);
    }

    const allCategories = [...histDates, ...projDates];
    const historicalSeriesData = [...histValues, ...new Array(projDates.length).fill(null)];
    const projectedSeriesData = projValues.length > 0
      ? [
          ...new Array(Math.max(0, histValues.length - 1)).fill(null),
          histValues.length > 0 ? histValues[histValues.length - 1] : null,
          ...projValues,
        ]
      : [];

    const breachSubtext = !hasTelemetry
      ? 'Awaiting telemetry scrape'
      : daysToBreach !== null && daysToBreach <= 0
      ? 'Breached'
      : daysToBreach !== null
      ? `Breach in ~${daysToBreach}d`
      : 'Headroom ample (>90d runway)';

    return {
      title: {
        text: `${forecast.metric_name} Capacity & Growth Forecast`,
        subtext: `Current: ${forecast.current_value}${forecast.unit} · Daily Growth: +${forecast.growth_rate_daily}${forecast.unit} · ${breachSubtext}`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 'bold' },
        subtextStyle: { color: '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'cross' },
        formatter: (params: any) => {
          if (!Array.isArray(params)) return '';
          let dateStr = params[0]?.axisValueLabel || '';
          let html = `<div style="font-weight:bold;margin-bottom:4px;color:#f8fafc;">${dateStr}</div>`;
          params.forEach((p: any) => {
            if (p.value !== null && p.value !== undefined) {
              html += `<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin:2px 0;">
                <span>${p.marker} ${p.seriesName}</span>
                <span style="font-weight:bold;">${p.value}${forecast.unit}</span>
              </div>`;
            }
          });
          return html;
        },
      },
      legend: {
        data: ['Historical Trend', 'Linear Projection (Forecast)'],
        top: 38,
        right: 10,
        textStyle: { color: '#cbd5e1', fontSize: 11 },
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '8%',
        top: '28%',
        containLabel: true,
      },
      xAxis: {
        type: 'category',
        data: allCategories,
        boundaryGap: allCategories.length <= 1,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10, interval: 'auto' },
      },
      yAxis: {
        type: 'value',
        min: 0,
        max: (value) => Math.max(100, Math.ceil(value.max / 10) * 10),
        axisLine: { lineStyle: { color: '#334155' } },
        splitLine: { lineStyle: { color: '#1e293b' } },
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: `{value}${forecast.unit}`,
        },
      },
      series: [
        {
          name: 'Historical Trend',
          type: 'line',
          data: historicalSeriesData,
          smooth: true,
          showSymbol: true,
          symbol: 'circle',
          symbolSize: 7,
          itemStyle: { color: '#38bdf8' },
          lineStyle: { width: 2.5, color: '#38bdf8' },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(56, 189, 248, 0.25)' },
                { offset: 1, color: 'rgba(56, 189, 248, 0.0)' },
              ],
            },
          },
          markLine: {
            symbol: 'none',
            data: [
              {
                yAxis: forecast.warning_threshold || 75,
                lineStyle: { color: '#eab308', type: 'dashed', width: 1.5 },
                label: {
                  formatter: `Warning (${forecast.warning_threshold}${forecast.unit})`,
                  position: 'insideEndTop',
                  color: '#eab308',
                  fontSize: 10,
                },
              },
              {
                yAxis: forecast.critical_threshold || 90,
                lineStyle: { color: '#ef4444', type: 'dashed', width: 1.5 },
                label: {
                  formatter: `Critical (${forecast.critical_threshold}${forecast.unit})`,
                  position: 'insideEndTop',
                  color: '#ef4444',
                  fontSize: 10,
                },
              },
            ],
          },
        },
        {
          name: 'Linear Projection (Forecast)',
          type: 'line',
          data: projectedSeriesData,
          smooth: true,
          itemStyle: { color: '#a855f7' },
          lineStyle: { width: 2, type: 'dashed', color: '#a855f7' },
        },
      ],
    };
  }, [forecast, hasTelemetry, daysToBreach]);

  return (
    <div className="bg-[#0b1320] border border-slate-800 rounded-xl p-4 space-y-3">
      {/* Header bar */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          {forecast.metric_name.toLowerCase().includes('disk') ? (
            <HardDrive className="w-4 h-4 text-amber-400" />
          ) : forecast.metric_name.toLowerCase().includes('memory') ? (
            <Cpu className="w-4 h-4 text-purple-400" />
          ) : (
            <Database className="w-4 h-4 text-blue-400" />
          )}
          <span className="font-extrabold text-sm text-white">{forecast.metric_name}</span>
        </div>

        <div className="flex items-center gap-2">
          {!hasTelemetry ? (
            <span className="text-[10px] font-semibold tracking-wider uppercase px-2.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-slate-500 animate-pulse" />
              Awaiting Telemetry Scrape
            </span>
          ) : (
            <>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase border ${
                  isCritical
                    ? 'bg-rose-950 text-rose-300 border-rose-700'
                    : isApproaching
                    ? 'bg-amber-950 text-amber-300 border-amber-700'
                    : 'bg-emerald-950 text-emerald-300 border-emerald-700'
                }`}
              >
                {forecast.capacity_health.replace('_', ' ')}
              </span>
              <span className="text-xs font-bold text-slate-300 px-2 py-0.5 rounded bg-slate-800 border border-slate-700 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-purple-400" />
                {daysToBreach !== null && daysToBreach <= 0
                  ? 'Breached'
                  : daysToBreach !== null
                  ? `${daysToBreach}d to breach`
                  : 'Ample Runway (>90d)'}
              </span>
            </>
          )}
        </div>
      </div>

      {!hasTelemetry ? (
        <div
          style={{ height }}
          className="flex flex-col items-center justify-center text-center p-6 border border-dashed border-slate-800/80 rounded-xl bg-slate-900/30"
        >
          <TrendingUp className="w-8 h-8 text-slate-600 mb-2.5 animate-pulse" />
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Awaiting Real Telemetry
          </h4>
          <p className="text-[11px] text-slate-500 max-w-xs mt-1.5 leading-relaxed">
            No live telemetry samples collected yet for {forecast.metric_name}. Real historical trends and linear projection will automatically render once metrics are scraped.
          </p>
        </div>
      ) : (
        <BaseEChart options={chartOptions} height={height} />
      )}

      {/* Recommendation footer */}
      <div
        className={`p-2.5 rounded-lg border text-xs flex items-center gap-2 ${
          isCritical
            ? 'bg-rose-950/20 border-rose-900/60 text-rose-300'
            : isApproaching
            ? 'bg-amber-950/20 border-amber-900/60 text-amber-300'
            : 'bg-slate-900/60 border-slate-800 text-slate-300'
        }`}
      >
        <TrendingUp className="w-4 h-4 shrink-0 text-purple-400" />
        <span className="font-sans">
          <strong>Recommendation:</strong> {forecast.recommendation}
        </span>
      </div>
    </div>
  );
};
