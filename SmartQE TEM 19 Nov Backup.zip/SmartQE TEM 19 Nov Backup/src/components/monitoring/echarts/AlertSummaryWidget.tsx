import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { MonitoringAlert } from '../../../types/monitoring';

export interface AlertSummaryWidgetProps {
  alerts?: MonitoringAlert[];
  height?: string;
}

export const AlertSummaryWidget: React.FC<AlertSummaryWidgetProps> = ({
  alerts = [],
  height = '240px',
}) => {
  const counts = useMemo(() => {
    let critical = 0;
    let high = 0;
    let warning = 0;
    let info = 0;

    alerts.forEach((a) => {
      if (a.severity === 'CRITICAL') critical++;
      else if (a.severity === 'HIGH') high++;
      else if (a.severity === 'WARNING') warning++;
      else info++;
    });

    return [
      { value: critical, name: 'Critical', itemStyle: { color: '#ef4444' } },
      { value: high, name: 'High', itemStyle: { color: '#f97316' } },
      { value: warning, name: 'Warning', itemStyle: { color: '#f59e0b' } },
      { value: info, name: 'Info', itemStyle: { color: '#38bdf8' } },
    ];
  }, [alerts]);

  const totalAlerts = useMemo(() => alerts.length, [alerts]);

  const options = useMemo<echarts.EChartsOption>(() => {
    return {
      title: {
        text: 'Active Alerts by Severity',
        subtext: totalAlerts === 0 ? '0 active alerts (fleet nominal)' : `Total Active: ${totalAlerts}`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        subtextStyle: { color: totalAlerts === 0 ? '#34d399' : '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'item',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: totalAlerts === 0 ? 'No active threshold alerts' : '{b}: <b>{c}</b> ({d}%)',
      },
      legend: {
        orient: 'vertical',
        right: 10,
        top: 'center',
        textStyle: { color: '#cbd5e1', fontSize: 11 },
      },
      series: [
        {
          name: 'Alert Severity',
          type: 'pie',
          radius: ['45%', '72%'],
          center: ['35%', '55%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 4,
            borderColor: '#0f172a',
            borderWidth: 2,
          },
          label: { show: false },
          emphasis: {
            label: {
              show: true,
              fontSize: 12,
              fontWeight: 'bold',
              color: '#f8fafc',
            },
          },
          labelLine: { show: false },
          data:
            totalAlerts === 0
              ? [{ value: 1, name: 'Nominal (0 Alerts)', itemStyle: { color: '#10b981' } }]
              : counts.filter((c) => c.value > 0),
        },
      ],
    };
  }, [counts, totalAlerts]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
