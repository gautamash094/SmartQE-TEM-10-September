import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { HistoricalSeries } from '../../../types/monitoring';

export interface ApplicationErrorRateChartProps {
  series?: HistoricalSeries;
  title?: string;
  warningPct?: number;
  criticalPct?: number;
  height?: string;
}

export const ApplicationErrorRateChart: React.FC<ApplicationErrorRateChartProps> = ({
  series,
  title = 'Application Error Rate (%)',
  warningPct = 2.0,
  criticalPct = 5.0,
  height = '280px',
}) => {
  const options = useMemo<echarts.EChartsOption>(() => {
    const timestamps = series?.points?.map((p) => p.timestamp) || [];
    const values = series?.points?.map((p) => p.value) || [];

    return {
      title: {
        text: title,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          const item = params[0];
          return `
            <div class="font-sans">
              <div class="text-slate-400 text-xs mb-1">${item.axisValue}</div>
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="font-semibold">${item.seriesName}:</span>
                <span class="text-rose-400 font-bold">${item.value}%</span>
              </div>
            </div>
          `;
        },
      },
      grid: {
        top: 45,
        left: 45,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: timestamps,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        min: 0,
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: '{value}%',
        },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'Error Rate',
          type: 'line',
          smooth: true,
          data: values,
          itemStyle: { color: '#f43f5e' },
          lineStyle: { width: 2.5, color: '#f43f5e' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(244, 63, 94, 0.45)' },
              { offset: 1, color: 'rgba(244, 63, 94, 0.02)' },
            ]),
          },
          markLine: {
            silent: true,
            symbol: 'none',
            data: [
              {
                yAxis: warningPct,
                lineStyle: { color: '#f59e0b', type: 'dashed', width: 1.5 },
                label: { formatter: `Warning (${warningPct}%)`, position: 'insideEndTop', color: '#f59e0b', fontSize: 10 },
              },
              {
                yAxis: criticalPct,
                lineStyle: { color: '#ef4444', type: 'dashed', width: 1.5 },
                label: { formatter: `Critical (${criticalPct}%)`, position: 'insideEndTop', color: '#ef4444', fontSize: 10 },
              },
            ],
          },
        },
      ],
    };
  }, [series, title, warningPct, criticalPct]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
