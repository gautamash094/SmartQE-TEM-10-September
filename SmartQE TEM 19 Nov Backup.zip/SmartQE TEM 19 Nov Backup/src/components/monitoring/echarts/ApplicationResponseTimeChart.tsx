import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { HistoricalSeries } from '../../../types/monitoring';

export interface ApplicationResponseTimeChartProps {
  series?: HistoricalSeries;
  title?: string;
  warningMs?: number;
  criticalMs?: number;
  height?: string;
}

export const ApplicationResponseTimeChart: React.FC<ApplicationResponseTimeChartProps> = ({
  series,
  title = 'Application Response Time Latency (ms)',
  warningMs = 500,
  criticalMs = 1000,
  height = '280px',
}) => {
  const options = useMemo<echarts.EChartsOption>(() => {
    const timestamps = series?.points?.map((p) => p.timestamp) || [];
    const avgValues = series?.points?.map((p) => p.value) || [];
    const p95Values = avgValues.map((v) => Math.round(v * 1.35));

    return {
      title: {
        text: title,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        left: 0,
        top: 0,
      },
      legend: {
        data: ['Avg Latency', 'P95 Latency'],
        textStyle: { color: '#94a3b8', fontSize: 11 },
        top: 0,
        right: 10,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          let html = `<div class="font-sans"><div class="text-slate-400 text-xs mb-1">${params[0].axisValue}</div>`;
          params.forEach((item: any) => {
            html += `
              <div class="flex items-center gap-2 mb-0.5">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="text-slate-300 font-medium">${item.seriesName}:</span>
                <span class="font-bold text-cyan-400">${item.value} ms</span>
              </div>
            `;
          });
          html += '</div>';
          return html;
        },
      },
      grid: {
        top: 45,
        left: 50,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: timestamps,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: '{value} ms',
        },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'Avg Latency',
          type: 'line',
          smooth: true,
          data: avgValues,
          itemStyle: { color: '#38bdf8' },
          lineStyle: { width: 2.5, color: '#38bdf8' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(56, 189, 248, 0.35)' },
              { offset: 1, color: 'rgba(56, 189, 248, 0.01)' },
            ]),
          },
          markLine: {
            silent: true,
            symbol: 'none',
            data: [
              {
                yAxis: warningMs,
                lineStyle: { color: '#f59e0b', type: 'dashed', width: 1.5 },
                label: { formatter: `SLA Warning (${warningMs}ms)`, position: 'insideEndTop', color: '#f59e0b', fontSize: 10 },
              },
              {
                yAxis: criticalMs,
                lineStyle: { color: '#ef4444', type: 'dashed', width: 1.5 },
                label: { formatter: `SLA Critical (${criticalMs}ms)`, position: 'insideEndTop', color: '#ef4444', fontSize: 10 },
              },
            ],
          },
        },
        {
          name: 'P95 Latency',
          type: 'line',
          smooth: true,
          data: p95Values,
          itemStyle: { color: '#f43f5e' },
          lineStyle: { width: 1.5, type: 'dashed', color: '#f43f5e' },
        },
      ],
    };
  }, [series, title, warningMs, criticalMs]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
