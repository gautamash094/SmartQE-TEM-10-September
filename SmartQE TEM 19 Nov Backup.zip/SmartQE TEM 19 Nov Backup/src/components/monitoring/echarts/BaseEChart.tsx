import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';

export interface BaseEChartProps {
  options: echarts.EChartsOption;
  style?: React.CSSProperties;
  className?: string;
  loading?: boolean;
  height?: string | number;
  onEvents?: Record<string, (params: any) => void>;
}

export const BaseEChart: React.FC<BaseEChartProps> = ({
  options,
  style = { height: '300px', width: '100%' },
  className = '',
  loading = false,
  height,
  onEvents,
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);

  const mergedStyle = height ? { ...style, height } : style;

  useEffect(() => {
    if (!chartRef.current) return;

    // Initialize ECharts instance with dark theme default
    if (!chartInstance.current) {
      chartInstance.current = echarts.init(chartRef.current, 'dark', {
        renderer: 'canvas',
      });

      // Bind custom event handlers if provided
      if (onEvents) {
        Object.entries(onEvents).forEach(([eventName, handler]) => {
          chartInstance.current?.on(eventName, handler);
        });
      }
    }

    // Apply dark background transparently to match TEM design language
    const themedOptions: echarts.EChartsOption = {
      backgroundColor: 'transparent',
      ...options,
    };

    chartInstance.current.setOption(themedOptions, true);

    if (loading) {
      chartInstance.current.showLoading({
        text: 'Loading telemetry...',
        color: '#38bdf8',
        textColor: '#94a3b8',
        maskColor: 'rgba(15, 23, 42, 0.6)',
      });
    } else {
      chartInstance.current.hideLoading();
    }

    // Auto-resize on container dimensions change
    const resizeObserver = new ResizeObserver(() => {
      chartInstance.current?.resize();
    });
    resizeObserver.observe(chartRef.current);

    const handleWindowResize = () => {
      chartInstance.current?.resize();
    };
    window.addEventListener('resize', handleWindowResize);

    return () => {
      window.removeEventListener('resize', handleWindowResize);
      resizeObserver.disconnect();
    };
  }, [options, loading, onEvents]);

  useEffect(() => {
    return () => {
      chartInstance.current?.dispose();
      chartInstance.current = null;
    };
  }, []);

  return <div ref={chartRef} style={mergedStyle} className={`relative ${className}`} />;
};
