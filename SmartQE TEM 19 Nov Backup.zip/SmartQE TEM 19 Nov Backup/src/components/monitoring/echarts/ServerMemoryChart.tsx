import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { HistoricalSeries } from '../../../types/monitoring';

export interface ServerMemoryChartProps {
  series?: HistoricalSeries;
  title?: string;
  totalGb?: number;
  usedGb?: number;
  availableGb?: number;
  warningThreshold?: number;
  criticalThreshold?: number;
  height?: string;
}

export const ServerMemoryChart: React.FC<ServerMemoryChartProps> = ({
  series,
  title = 'Server Memory Utilization',
  totalGb = 32,
  usedGb,
  availableGb,
  warningThreshold = 80,
  criticalThreshold = 90,
  height = '280px',
}) => {
  const options = useMemo<echarts.EChartsOption>(() => {
    const timestamps = series?.points?.map((p) => p.timestamp) || [];
    const usedPct = series?.points?.map((p) => p.value) || [];

    const effectiveUsedGb = usedGb !== undefined ? usedGb : (usedPct.length ? +((usedPct[usedPct.length - 1] / 100) * totalGb).toFixed(1) : 0);
    const effectiveAvailGb = availableGb !== undefined ? availableGb : Math.max(0, +(totalGb - effectiveUsedGb).toFixed(1));

    const markLines: any[] = [];
    if (warningThreshold) {
      markLines.push({
        yAxis: warningThreshold,
        lineStyle: { color: '#f59e0b', type: 'dashed', width: 1.5 },
        label: { formatter: `Warn (${warningThreshold}%)`, position: 'insideEndTop', color: '#f59e0b', fontSize: 10 },
      });
    }
    if (criticalThreshold) {
      markLines.push({
        yAxis: criticalThreshold,
        lineStyle: { color: '#ef4444', type: 'dashed', width: 1.5 },
        label: { formatter: `Crit (${criticalThreshold}%)`, position: 'insideEndTop', color: '#ef4444', fontSize: 10 },
      });
    }

    return {
      title: {
        text: title,
        subtext: `Total RAM: ${totalGb} GB  |  Used: ${effectiveUsedGb} GB  |  Available: ${effectiveAvailGb} GB`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        subtextStyle: { color: '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          const item = params[0];
          const gbVal = ((item.value / 100) * totalGb).toFixed(1);
          const freeGb = Math.max(0, +(totalGb - Number(gbVal)).toFixed(1));
          return `
            <div class="font-sans">
              <div class="text-slate-400 text-xs mb-1">${item.axisValue}</div>
              <div class="flex items-center gap-2 mb-1">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="font-semibold text-slate-300">${item.seriesName}:</span>
                <span class="text-emerald-400 font-bold">${item.value}% (${gbVal} GB)</span>
              </div>
              <div class="text-xs text-slate-400">Available: <span class="text-cyan-400 font-medium">${freeGb} GB</span></div>
            </div>
          `;
        },
      },
      grid: {
        top: 55,
        left: 45,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: timestamps,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        min: 0,
        max: 100,
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: '{value}%',
        },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'RAM Used',
          type: 'line',
          smooth: true,
          data: usedPct,
          itemStyle: { color: '#10b981' },
          lineStyle: { width: 2.5, color: '#10b981' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(16, 185, 129, 0.45)' },
              { offset: 1, color: 'rgba(16, 185, 129, 0.02)' },
            ]),
          },
          markLine: {
            silent: true,
            symbol: 'none',
            data: markLines,
          },
        },
      ],
    };
  }, [series, title, totalGb, usedGb, availableGb, warningThreshold, criticalThreshold]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
