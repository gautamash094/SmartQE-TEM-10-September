import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';

export interface ApplicationAvailabilityChartProps {
  uptimePct?: number;
  healthStatus?: string;
  title?: string;
  height?: string;
}

export const ApplicationAvailabilityChart: React.FC<ApplicationAvailabilityChartProps> = ({
  uptimePct = 99.95,
  healthStatus = 'HEALTHY',
  title = 'Service Availability & Uptime',
  height = '240px',
}) => {
  const options = useMemo<echarts.EChartsOption>(() => {
    let color = '#10b981';
    if (healthStatus === 'DEGRADED') color = '#f59e0b';
    if (healthStatus === 'DOWN') color = '#ef4444';

    return {
      title: {
        text: title,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        left: 'center',
        top: 0,
      },
      series: [
        {
          type: 'gauge',
          startAngle: 180,
          endAngle: 0,
          min: 90,
          max: 100,
          radius: '95%',
          center: ['50%', '75%'],
          splitNumber: 5,
          axisLine: {
            lineStyle: {
              width: 14,
              color: [
                [0.5, '#ef4444'],
                [0.8, '#f59e0b'],
                [1, '#10b981'],
              ],
            },
          },
          pointer: {
            icon: 'path://M12.8,0.7l12,40.1H0.7L12.8,0.7z',
            length: '12%',
            width: 10,
            offsetCenter: [0, '-60%'],
            itemStyle: { color: 'auto' },
          },
          axisTick: { length: 8, lineStyle: { color: 'auto', width: 1.5 } },
          splitLine: { length: 14, lineStyle: { color: 'auto', width: 2.5 } },
          axisLabel: {
            color: '#94a3b8',
            fontSize: 10,
            distance: -35,
            formatter: (v: number) => `${v}%`,
          },
          title: {
            offsetCenter: [0, '-25%'],
            fontSize: 12,
            color: '#94a3b8',
          },
          detail: {
            fontSize: 22,
            offsetCenter: [0, '0%'],
            valueAnimation: true,
            formatter: (value: number) => `${value.toFixed(2)}%`,
            color: '#f8fafc',
            fontWeight: 'bold',
          },
          data: [
            {
              value: uptimePct,
              name: `Status: ${healthStatus}`,
            },
          ],
        },
      ],
    };
  }, [uptimePct, healthStatus, title]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
