import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';

export interface ServerCoreBreakdownChartProps {
  cores?: Array<{ core: string; utilization_pct: number }>;
  title?: string;
  warningThreshold?: number;
  criticalThreshold?: number;
  height?: string;
}

export const ServerCoreBreakdownChart: React.FC<ServerCoreBreakdownChartProps> = ({
  cores = [],
  title = 'CPU Utilization by Logical Core (%)',
  warningThreshold = 70,
  criticalThreshold = 85,
  height = '280px',
}) => {
  const options = useMemo<echarts.EChartsOption>(() => {
    const safeCores = Array.isArray(cores) ? cores : [];

    if (safeCores.length === 0) {
      return {
        title: {
          text: title,
          subtext: 'No per-core CPU breakdown available for this host',
          textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
          subtextStyle: { color: '#94a3b8', fontSize: 11 },
          left: 0,
          top: 0,
        },
        grid: { top: 60, left: 45, right: 25, bottom: 30 },
        xAxis: { type: 'category', data: ['Host'] },
        yAxis: { type: 'value', min: 0, max: 100 },
        series: [{ type: 'bar', data: [0] }],
      };
    }

    // Sort cores numerically by core id
    const sorted = [...safeCores].sort((a, b) => {
      const numA = parseInt(a.core, 10);
      const numB = parseInt(b.core, 10);
      if (isNaN(numA) || isNaN(numB)) return (a.core || '').localeCompare(b.core || '');
      return numA - numB;
    });

    const categories = sorted.map((c) => `Core ${c.core}`);
    const values = sorted.map((c) => c.utilization_pct || 0);

    const markLines: any[] = [];
    if (warningThreshold) {
      markLines.push({
        yAxis: warningThreshold,
        lineStyle: { color: '#f59e0b', type: 'dashed', width: 1.5 },
        label: {
          formatter: `Warn (${warningThreshold}%)`,
          position: 'insideEndTop',
          color: '#f59e0b',
          fontSize: 10,
        },
      });
    }
    if (criticalThreshold) {
      markLines.push({
        yAxis: criticalThreshold,
        lineStyle: { color: '#ef4444', type: 'dashed', width: 1.5 },
        label: {
          formatter: `Crit (${criticalThreshold}%)`,
          position: 'insideEndTop',
          color: '#ef4444',
          fontSize: 10,
        },
      });
    }

    const isBalanced = values.length > 0 && Math.max(...values) - Math.min(...values) < 25;

    return {
      title: {
        text: title,
        subtext: `Total Logical Cores: ${sorted.length}  |  Balanced Load: ${values.length ? (isBalanced ? 'Yes' : 'Skewed') : 'N/A'}`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        subtextStyle: { color: '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          const item = Array.isArray(params) ? params[0] : params;
          const val = Number(item.value);
          const status = val >= criticalThreshold ? 'Critical' : val >= warningThreshold ? 'Warning' : 'Normal';
          const statusColor = val >= criticalThreshold ? '#ef4444' : val >= warningThreshold ? '#f59e0b' : '#10b981';
          return `
            <div class="font-sans">
              <div class="text-slate-400 text-xs mb-1 font-semibold">${item.name}</div>
              <div class="flex items-center gap-2 mb-1">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="text-slate-300 font-medium">Core Load:</span>
                <span class="font-bold text-white">${val}%</span>
              </div>
              <div class="text-[11px] flex items-center gap-1.5">
                <span class="text-slate-400">Core Status:</span>
                <span class="font-bold" style="color:${statusColor}">${status}</span>
              </div>
            </div>
          `;
        },
      },
      grid: {
        top: 55,
        left: 45,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: categories,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        min: 0,
        max: 100,
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: '{value}%',
        },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'Core Utilization',
          type: 'bar',
          data: values.map((val) => ({
            value: val,
            itemStyle: {
              color:
                val >= criticalThreshold
                  ? '#ef4444'
                  : val >= warningThreshold
                  ? '#f59e0b'
                  : '#06b6d4',
              borderRadius: [4, 4, 0, 0],
            },
          })),
          barMaxWidth: 32,
          markLine: {
            silent: true,
            symbol: 'none',
            data: markLines,
          },
        },
      ],
    };
  }, [cores, title, warningThreshold, criticalThreshold]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
