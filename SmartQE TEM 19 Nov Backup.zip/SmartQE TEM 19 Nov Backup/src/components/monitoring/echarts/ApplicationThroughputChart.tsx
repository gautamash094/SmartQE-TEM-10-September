import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { HistoricalSeries } from '../../../types/monitoring';

export interface ApplicationThroughputChartProps {
  series?: HistoricalSeries;
  title?: string;
  height?: string;
}

export const ApplicationThroughputChart: React.FC<ApplicationThroughputChartProps> = ({
  series,
  title = 'Application Throughput & Request Rate (req/s)',
  height = '280px',
}) => {
  const options = useMemo<echarts.EChartsOption>(() => {
    const timestamps = series?.points?.map((p) => p.timestamp) || [];
    const values = series?.points?.map((p) => p.value) || [];

    return {
      title: {
        text: title,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          const item = params[0];
          return `
            <div class="font-sans">
              <div class="text-slate-400 text-xs mb-1">${item.axisValue}</div>
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="font-semibold">${item.seriesName}:</span>
                <span class="text-emerald-400 font-bold">${item.value} req/s</span>
              </div>
            </div>
          `;
        },
      },
      grid: {
        top: 45,
        left: 45,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: timestamps,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: '{value}',
        },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'Throughput',
          type: 'bar',
          data: values,
          itemStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: '#10b981' },
              { offset: 1, color: '#047857' },
            ]),
            borderRadius: [4, 4, 0, 0],
          },
          barMaxWidth: 24,
        },
      ],
    };
  }, [series, title]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
