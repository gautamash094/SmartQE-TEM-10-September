import React, { useMemo, useState } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { HistoricalSeries } from '../../../types/monitoring';

export interface DiskVolumeData {
  volume: string;
  total_gb: number;
  free_gb: number;
  used_gb: number;
  utilization_pct: number;
  free_pct?: number;
}

export interface ServerDiskChartProps {
  series?: HistoricalSeries;
  volumes?: DiskVolumeData[];
  title?: string;
  totalGb?: number;
  warningThreshold?: number;
  criticalThreshold?: number;
  height?: string;
}

export const ServerDiskChart: React.FC<ServerDiskChartProps> = ({
  series,
  volumes = [],
  title = 'Server Disk Storage Utilization',
  totalGb = 500,
  warningThreshold = 80,
  criticalThreshold = 90,
  height = '280px',
}) => {
  const [selectedVolName, setSelectedVolName] = useState<string>('ALL');

  const safeVolumes = useMemo(() => (Array.isArray(volumes) ? volumes : []), [volumes]);

  const activeVolume = useMemo(() => {
    if (selectedVolName === 'ALL' || safeVolumes.length === 0) return null;
    return safeVolumes.find((v) => v.volume === selectedVolName) || safeVolumes[0];
  }, [selectedVolName, safeVolumes]);

  const effectiveTotalGb = activeVolume ? activeVolume.total_gb : (safeVolumes.length ? safeVolumes.reduce((acc, v) => acc + v.total_gb, 0) : totalGb);
  const effectiveFreeGb = activeVolume ? activeVolume.free_gb : (safeVolumes.length ? safeVolumes.reduce((acc, v) => acc + v.free_gb, 0) : 0);
  const effectiveUsedGb = activeVolume ? activeVolume.used_gb : (safeVolumes.length ? safeVolumes.reduce((acc, v) => acc + v.used_gb, 0) : 0);
  const effectiveFreePct = effectiveTotalGb > 0 ? +((effectiveFreeGb / effectiveTotalGb) * 100).toFixed(1) : 0;

  const options = useMemo<echarts.EChartsOption>(() => {
    // If multiple volumes and ALL selected, render grouped bar breakdown per volume
    if (safeVolumes.length > 1 && selectedVolName === 'ALL') {
      const volNames = safeVolumes.map((v) => v.volume);
      const usedPcts = safeVolumes.map((v) => v.utilization_pct);

      return {
        title: {
          text: title,
          subtext: `Volumes: ${safeVolumes.length}  |  Total Capacity: ${effectiveTotalGb.toFixed(0)} GB  |  Free: ${effectiveFreeGb.toFixed(0)} GB (${effectiveFreePct}%)`,
          textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
          subtextStyle: { color: '#94a3b8', fontSize: 11 },
          left: 0,
          top: 0,
        },
        tooltip: {
          trigger: 'axis',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc', fontSize: 12 },
          formatter: (params: any) => {
            const item = Array.isArray(params) ? params[0] : params;
            const vol = volumes.find((v) => v.volume === item.name);
            return `
              <div class="font-sans">
                <div class="text-slate-400 text-xs mb-1 font-semibold">Volume ${item.name}</div>
                <div class="text-amber-400 font-bold mb-1">Utilization: ${item.value}%</div>
                <div class="text-xs text-slate-300">Used: ${vol?.used_gb ?? 0} GB / Total: ${vol?.total_gb ?? 0} GB</div>
                <div class="text-xs text-emerald-400">Free: ${vol?.free_gb ?? 0} GB (${vol?.free_pct ?? 0}%)</div>
              </div>
            `;
          },
        },
        grid: {
          top: 55,
          left: 45,
          right: 25,
          bottom: 30,
        },
        xAxis: {
          type: 'category',
          data: volNames,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: { color: '#94a3b8', fontSize: 11, fontWeight: 500 },
        },
        yAxis: {
          type: 'value',
          min: 0,
          max: 100,
          axisLabel: { color: '#94a3b8', fontSize: 10, formatter: '{value}%' },
          splitLine: { lineStyle: { color: '#1e293b' } },
        },
        series: [
          {
            name: 'Volume Utilization',
            type: 'bar',
            data: usedPcts.map((val) => ({
              value: val,
              itemStyle: {
                color: val >= criticalThreshold ? '#ef4444' : val >= warningThreshold ? '#f59e0b' : '#38bdf8',
                borderRadius: [4, 4, 0, 0],
              },
            })),
            barMaxWidth: 36,
            markLine: {
              silent: true,
              symbol: 'none',
              data: [
                {
                  yAxis: warningThreshold,
                  lineStyle: { color: '#f59e0b', type: 'dashed', width: 1.5 },
                  label: { formatter: `Warn (${warningThreshold}%)`, position: 'insideEndTop', color: '#f59e0b', fontSize: 10 },
                },
                {
                  yAxis: criticalThreshold,
                  lineStyle: { color: '#ef4444', type: 'dashed', width: 1.5 },
                  label: { formatter: `Crit (${criticalThreshold}%)`, position: 'insideEndTop', color: '#ef4444', fontSize: 10 },
                },
              ],
            },
          },
        ],
      };
    }

    // Historical time series for single/selected volume
    const timestamps = series?.points?.map((p) => p.timestamp) || [];
    const values = series?.points?.map((p) => p.value) || [];

    return {
      title: {
        text: title,
        subtext: `Volume: ${activeVolume ? activeVolume.volume : 'Default'}  |  Total: ${effectiveTotalGb.toFixed(0)} GB  |  Used: ${effectiveUsedGb.toFixed(0)} GB  |  Free: ${effectiveFreeGb.toFixed(0)} GB (${effectiveFreePct}%)`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        subtextStyle: { color: '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          const item = params[0];
          const usedGb = ((item.value / 100) * effectiveTotalGb).toFixed(1);
          const freeGb = Math.max(0, +(effectiveTotalGb - Number(usedGb)).toFixed(1));
          return `
            <div class="font-sans">
              <div class="text-slate-400 text-xs mb-1">${item.axisValue}</div>
              <div class="flex items-center gap-2 mb-1">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="font-semibold text-slate-300">Disk Used:</span>
                <span class="text-amber-400 font-bold">${item.value}% (${usedGb} GB)</span>
              </div>
              <div class="text-xs text-slate-400">Free Space: <span class="text-emerald-400 font-medium">${freeGb} GB</span></div>
            </div>
          `;
        },
      },
      grid: {
        top: 55,
        left: 45,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: timestamps,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        min: 0,
        max: 100,
        axisLabel: {
          color: '#94a3b8',
          fontSize: 10,
          formatter: '{value}%',
        },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'Disk Utilization',
          type: 'line',
          smooth: true,
          data: values,
          itemStyle: { color: '#f59e0b' },
          lineStyle: { width: 2.5, color: '#f59e0b' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(245, 158, 11, 0.4)' },
              { offset: 1, color: 'rgba(245, 158, 11, 0.02)' },
            ]),
          },
          markLine: {
            silent: true,
            symbol: 'none',
            data: [
              {
                yAxis: warningThreshold,
                lineStyle: { color: '#f59e0b', type: 'dashed', width: 1.5 },
                label: { formatter: `Warn (${warningThreshold}%)`, position: 'insideEndTop', color: '#f59e0b', fontSize: 10 },
              },
              {
                yAxis: criticalThreshold,
                lineStyle: { color: '#ef4444', type: 'dashed', width: 1.5 },
                label: { formatter: `Crit (${criticalThreshold}%)`, position: 'insideEndTop', color: '#ef4444', fontSize: 10 },
              },
            ],
          },
        },
      ],
    };
  }, [series, volumes, selectedVolName, activeVolume, effectiveTotalGb, effectiveFreeGb, effectiveUsedGb, effectiveFreePct, title, warningThreshold, criticalThreshold]);

  return (
    <div className="relative">
      {volumes.length > 1 && (
        <div className="absolute right-0 top-0 z-10 flex items-center gap-1.5 bg-slate-900/80 px-2 py-0.5 rounded border border-slate-700 text-xs text-slate-300">
          <span className="text-slate-400">Volume:</span>
          <select
            value={selectedVolName}
            onChange={(e) => setSelectedVolName(e.target.value)}
            className="bg-transparent text-white focus:outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-slate-900 text-white">All Volumes</option>
            {volumes.map((v) => (
              <option key={v.volume} value={v.volume} className="bg-slate-900 text-white">
                {v.volume} ({v.utilization_pct}%)
              </option>
            ))}
          </select>
        </div>
      )}
      <BaseEChart options={options} style={{ height, width: '100%' }} />
    </div>
  );
};
