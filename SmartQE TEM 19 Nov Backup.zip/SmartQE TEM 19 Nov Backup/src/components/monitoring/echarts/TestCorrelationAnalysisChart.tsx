import React, { useMemo } from 'react';
import { BaseEChart } from './BaseEChart';
import { EChartsOption } from 'echarts';
import { TestCorrelationAnalysis } from '../../../types/monitoring';
import { AlertTriangle, Bug, CheckCircle2, ShieldAlert, Cpu, Activity, Clock } from 'lucide-react';

interface TestCorrelationAnalysisChartProps {
  analysis: TestCorrelationAnalysis;
  height?: string | number;
}

export const TestCorrelationAnalysisChart: React.FC<TestCorrelationAnalysisChartProps> = ({
  analysis,
  height = '320px',
}) => {
  const chartOptions: EChartsOption = useMemo(() => {
    const metrics = [
      analysis.application_response_time,
      analysis.server_cpu,
      analysis.server_memory,
      analysis.application_error_rate,
    ].filter(Boolean);

    const labels = metrics.map((m) => `${m.metric_name} (${m.unit})`);
    const baselineData = metrics.map((m) => m.before_test);
    const duringData = metrics.map((m) => m.during_test);

    return {
      title: {
        text: 'Telemetry Baseline Before Test vs. During Test Execution',
        subtext: `Test Run: ${analysis.test_run_id} (${analysis.test_suite_name}) · Phase: ${analysis.test_phase}`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 'bold' },
        subtextStyle: { color: '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        formatter: (params: any) => {
          if (!Array.isArray(params) || params.length === 0) return '';
          const idx = params[0].dataIndex;
          const m = metrics[idx];
          const devStr = m ? `${m.variance_pct > 0 ? '+' : ''}${m.variance_pct}%` : 'N/A';
          let html = `<div style="font-weight:bold;margin-bottom:4px;color:#f8fafc;">${labels[idx]}</div>`;
          params.forEach((p: any) => {
            html += `<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin:2px 0;">
              <span>${p.marker} ${p.seriesName}</span>
              <span style="font-weight:bold;">${p.value} ${m?.unit || ''}</span>
            </div>`;
          });
          html += `<div style="margin-top:6px;padding-top:4px;border-top:1px solid #334155;color:#f59e0b;font-weight:bold;">
            Variance: ${devStr} ${m?.is_saturated ? '⚠ SATURATED' : ''}
          </div>`;
          return html;
        },
      },
      legend: {
        data: ['Pre-Test Baseline', 'During Test Execution'],
        top: 30,
        right: 10,
        textStyle: { color: '#cbd5e1', fontSize: 11 },
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '10%',
        top: '25%',
        containLabel: true,
      },
      xAxis: {
        type: 'category',
        data: labels,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 11, interval: 0 },
      },
      yAxis: {
        type: 'value',
        axisLine: { lineStyle: { color: '#334155' } },
        splitLine: { lineStyle: { color: '#1e293b' } },
        axisLabel: { color: '#94a3b8', fontSize: 11 },
      },
      series: [
        {
          name: 'Pre-Test Baseline',
          type: 'bar',
          data: baselineData,
          itemStyle: {
            color: '#3b82f6',
            borderRadius: [4, 4, 0, 0],
          },
          barGap: '20%',
        },
        {
          name: 'During Test Execution',
          type: 'bar',
          data: duringData,
          itemStyle: {
            color: analysis.is_environment_caused ? '#f97316' : '#ec4899',
            borderRadius: [4, 4, 0, 0],
          },
        },
      ],
    };
  }, [analysis]);

  const isEnvDefect = analysis.is_environment_caused;

  return (
    <div className="bg-[#0b1320] border border-slate-800 rounded-xl p-4 space-y-4">
      {/* Verdict Banner */}
      <div
        className={`p-4 rounded-xl border flex flex-col md:flex-row items-start md:items-center justify-between gap-3 ${
          isEnvDefect
            ? 'bg-amber-950/30 border-amber-800/80 text-amber-200'
            : 'bg-emerald-950/30 border-emerald-800/80 text-emerald-200'
        }`}
      >
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            {isEnvDefect ? (
              <AlertTriangle className="w-5 h-5 text-amber-400" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            )}
            <span className="font-extrabold text-sm uppercase tracking-wide">
              Root Cause Verdict: {isEnvDefect ? 'ENVIRONMENT / INFRASTRUCTURE DEFECT' : 'FUNCTIONAL APPLICATION DEFECT'}
            </span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-black/40 border border-slate-700 font-bold">
              Status: {analysis.status}
            </span>
          </div>
          <p className="text-xs text-slate-300 font-sans leading-relaxed">
            {analysis.diagnostic_verdict}
          </p>
        </div>

        <div className="text-right shrink-0">
          <div className="text-[11px] text-slate-400">Environment</div>
          <div className="text-xs font-bold text-white">{analysis.environment_name}</div>
        </div>
      </div>

      {/* Chart */}
      <BaseEChart options={chartOptions} height={height} />

      {/* Metrics Saturation & Recommendation footer */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-amber-400" />
            Resource Saturation Analysis
          </div>
          <div className="space-y-1">
            {[
              analysis.application_response_time,
              analysis.server_cpu,
              analysis.server_memory,
              analysis.application_error_rate,
            ]
              .filter(Boolean)
              .map((m, idx) => (
                <div
                  key={idx}
                  className={`text-xs px-2.5 py-1 rounded border flex items-center justify-between ${
                    m.is_saturated
                      ? 'bg-amber-950/30 border-amber-800 text-amber-300'
                      : 'bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <span className="font-bold">{m.metric_name}:</span>
                  <span>
                    Baseline {m.before_test}{m.unit} → Test {m.during_test}{m.unit} ({m.variance_pct > 0 ? '+' : ''}{m.variance_pct}%)
                  </span>
                  {m.is_saturated && <span className="font-bold text-amber-400">⚠ SATURATED</span>}
                </div>
              ))}
          </div>
        </div>

        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Recommended Remediation
          </div>
          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-xs text-slate-300 leading-relaxed font-sans">
            {analysis.recommended_action || 'No automated action required. Continue standard test cycles.'}
          </div>
          {analysis.correlated_incidents && analysis.correlated_incidents.length > 0 && (
            <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-2">
              <span>Linked Incidents:</span>
              {analysis.correlated_incidents.map((incId, idx) => (
                <span key={idx} className="font-bold text-orange-400 bg-orange-950/40 px-2 py-0.5 rounded border border-orange-800/60">
                  {incId}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
