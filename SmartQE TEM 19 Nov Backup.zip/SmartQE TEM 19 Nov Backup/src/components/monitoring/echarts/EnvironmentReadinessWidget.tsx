import React from 'react';
import { EnvironmentReadinessAssessment } from '../../../types/monitoring';
import { CheckCircle2, XCircle, AlertTriangle, ShieldCheck, ShieldAlert } from 'lucide-react';

export interface EnvironmentReadinessWidgetProps {
  assessment?: EnvironmentReadinessAssessment | null;
}

export const EnvironmentReadinessWidget: React.FC<EnvironmentReadinessWidgetProps> = ({ assessment }) => {
  const isReady = assessment?.status === 'READY_FOR_TESTING';
  const score = assessment?.overall_readiness_score ?? 0;
  const gates = assessment?.gates || [];

  if (!assessment || gates.length === 0) {
    return (
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center text-center min-h-[220px]">
        <ShieldCheck className="w-8 h-8 text-slate-600 mb-2" />
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Test Execution Readiness</h4>
        <p className="text-[11px] text-slate-500 mt-1">
          {assessment ? 'No validation gates defined for this environment.' : 'Evaluating dynamic environment readiness criteria...'}
        </p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
        <div className="flex items-center gap-2">
          {isReady ? (
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
          ) : (
            <ShieldAlert className="w-5 h-5 text-rose-400" />
          )}
          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Test Execution Readiness</h4>
            <p className="text-[11px] text-slate-400">Automated gate validation for test execution clearance</p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="text-right">
            <span className="text-xs text-slate-400">Readiness Score</span>
            <div className="text-base font-black text-cyan-400">{score}%</div>
          </div>
          <span
            className={`px-3 py-1 rounded-full text-xs font-bold border ${
              isReady
                ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800/70'
                : 'bg-rose-950/60 text-rose-400 border-rose-800/70'
            }`}
          >
            {isReady ? 'READY FOR TESTING' : 'NOT READY'}
          </span>
        </div>
      </div>

      {/* Gates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
        {gates.map((g, idx) => (
          <div
            key={idx}
            className={`flex items-start justify-between p-2 rounded-lg border transition-colors ${
              g.passed
                ? 'bg-slate-950/40 border-slate-800/60 hover:border-emerald-800/50'
                : 'bg-rose-950/20 border-rose-900/50'
            }`}
          >
            <div className="flex items-start gap-2">
              {g.passed ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              )}
              <div>
                <span className="font-semibold text-slate-200 block text-[11px]">{g.gate_name}</span>
                <span className="text-[10px] text-slate-400 block">{g.details || g.description}</span>
              </div>
            </div>
            <span
              className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                g.passed ? 'text-emerald-400 bg-emerald-950/50' : 'text-rose-400 bg-rose-950/50'
              }`}
            >
              {g.passed ? 'PASS' : 'FAIL'}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
