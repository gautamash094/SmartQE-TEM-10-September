import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';
import { HealthCategoryScores } from '../../../types/monitoring';

export interface EnvironmentHealthWidgetProps {
  health?: HealthCategoryScores;
  height?: string;
}

export const EnvironmentHealthWidget: React.FC<EnvironmentHealthWidgetProps> = ({
  health,
  height = '300px',
}) => {
  const scores = useMemo(() => {
    return {
      infrastructure: health?.infrastructure ?? 0,
      application: health?.application ?? 0,
      database: health?.database ?? 0,
      services: health?.services ?? 0,
      configuration: health?.configuration ?? 0,
      overall: health?.overall_health_score ?? 0,
      status: health?.status ?? (health ? 'HEALTHY' : 'AWAITING_TELEMETRY'),
    };
  }, [health]);

  const options = useMemo<echarts.EChartsOption>(() => {
    const isLive = health && health.overall_health_score !== undefined;
    return {
      title: {
        text: '5-Tier Environment Health Breakdown',
        subtext: isLive
          ? `Overall Health Score: ${scores.overall}% (${scores.status})`
          : 'Awaiting dynamic environment telemetry...',
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        subtextStyle: {
          color: scores.overall >= 80 ? '#34d399' : scores.overall >= 60 ? '#fbbf24' : '#94a3b8',
          fontSize: 11,
          fontWeight: 'bold',
        },
        left: 0,
        top: 0,
      },
      tooltip: {
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
      },
      radar: {
        indicator: [
          { name: 'Infrastructure (30%)', max: 100 },
          { name: 'Application (25%)', max: 100 },
          { name: 'Database (20%)', max: 100 },
          { name: 'Services (15%)', max: 100 },
          { name: 'Configuration (10%)', max: 100 },
        ],
        center: ['50%', '58%'],
        radius: '68%',
        splitNumber: 4,
        axisName: {
          color: '#94a3b8',
          fontSize: 10,
          fontWeight: 500,
        },
        splitLine: {
          lineStyle: {
            color: [
              'rgba(51, 65, 85, 0.4)',
              'rgba(51, 65, 85, 0.6)',
              'rgba(51, 65, 85, 0.8)',
              'rgba(51, 65, 85, 1)',
            ],
          },
        },
        splitArea: {
          show: true,
          areaStyle: {
            color: ['rgba(15, 23, 42, 0.8)', 'rgba(30, 41, 59, 0.4)'],
          },
        },
        axisLine: { lineStyle: { color: '#334155' } },
      },
      series: [
        {
          name: 'Tier Health Score',
          type: 'radar',
          data: [
            {
              value: [
                scores.infrastructure,
                scores.application,
                scores.database,
                scores.services,
                scores.configuration,
              ],
              name: 'Health Score (%)',
              symbol: 'circle',
              symbolSize: 6,
              itemStyle: { color: '#38bdf8' },
              lineStyle: { width: 2, color: '#38bdf8' },
              areaStyle: {
                color: 'rgba(56, 189, 248, 0.35)',
              },
            },
          ],
        },
      ],
    };
  }, [scores]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
