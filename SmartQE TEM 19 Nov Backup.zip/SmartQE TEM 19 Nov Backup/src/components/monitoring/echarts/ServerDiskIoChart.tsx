import React, { useMemo } from 'react';
import * as echarts from 'echarts';
import { BaseEChart } from './BaseEChart';

export interface ServerDiskIoChartProps {
  readMbS?: number;
  writeMbS?: number;
  iops?: number;
  latencyMs?: number;
  queueLength?: number;
  busyPct?: number;
  title?: string;
  height?: string;
}

export const ServerDiskIoChart: React.FC<ServerDiskIoChartProps> = ({
  readMbS = 0,
  writeMbS = 0,
  iops = 0,
  latencyMs = 0,
  queueLength = 0,
  busyPct = 0,
  title = 'Server Disk I/O Performance & Latency',
  height = '280px',
}) => {
  const options = useMemo<echarts.EChartsOption>(() => {
    const categories = ['Read (MB/s)', 'Write (MB/s)', 'IOPS / 10', 'Latency (ms)', 'Queue Length', 'Busy %'];
    const values = [
      readMbS,
      writeMbS,
      +(iops / 10).toFixed(1),
      latencyMs,
      queueLength,
      busyPct,
    ];

    return {
      title: {
        text: title,
        subtext: `Total Throughput: ${(readMbS + writeMbS).toFixed(1)} MB/s  |  IOPS: ${iops}  |  Avg Latency: ${latencyMs} ms  |  Queue: ${queueLength}`,
        textStyle: { color: '#e2e8f0', fontSize: 13, fontWeight: 600 },
        subtextStyle: { color: '#94a3b8', fontSize: 11 },
        left: 0,
        top: 0,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 12 },
        formatter: (params: any) => {
          const item = Array.isArray(params) ? params[0] : params;
          let actualVal = item.value;
          let unit = '';
          if (item.name.includes('Read') || item.name.includes('Write')) unit = ' MB/s';
          else if (item.name.includes('IOPS')) {
            actualVal = iops;
            unit = ' ops/sec';
          } else if (item.name.includes('Latency')) unit = ' ms';
          else if (item.name.includes('Busy')) unit = '%';

          return `
            <div class="font-sans">
              <div class="text-slate-400 text-xs mb-1 font-semibold">${item.name}</div>
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full" style="background:${item.color}"></span>
                <span class="text-slate-300 font-medium">Value:</span>
                <span class="font-bold text-white">${actualVal}${unit}</span>
              </div>
            </div>
          `;
        },
      },
      grid: {
        top: 55,
        left: 45,
        right: 25,
        bottom: 30,
      },
      xAxis: {
        type: 'category',
        data: categories,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        axisLabel: { color: '#94a3b8', fontSize: 10 },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: 'I/O Metrics',
          type: 'bar',
          data: values.map((val, idx) => ({
            value: val,
            itemStyle: {
              color:
                idx === 0
                  ? '#06b6d4' // Read cyan
                  : idx === 1
                  ? '#8b5cf6' // Write purple
                  : idx === 2
                  ? '#3b82f6' // IOPS blue
                  : idx === 3
                  ? val > 20
                    ? '#ef4444'
                    : '#10b981' // Latency ms
                  : idx === 4
                  ? val > 5
                    ? '#ef4444'
                    : '#f59e0b' // Queue length
                  : '#ec4899', // Busy %
              borderRadius: [4, 4, 0, 0],
            },
          })),
          barMaxWidth: 36,
        },
      ],
    };
  }, [readMbS, writeMbS, iops, latencyMs, queueLength, busyPct, title]);

  return <BaseEChart options={options} style={{ height, width: '100%' }} />;
};
