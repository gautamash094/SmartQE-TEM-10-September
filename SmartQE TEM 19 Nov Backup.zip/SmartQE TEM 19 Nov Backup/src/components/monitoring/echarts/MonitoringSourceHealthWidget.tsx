import React from 'react';
import { MonitoringSourceHealthItem } from '../../../types/monitoring';
import { Activity, CheckCircle2, AlertTriangle, XCircle, Clock, Zap, ShieldCheck } from 'lucide-react';

export interface MonitoringSourceHealthWidgetProps {
  sources?: MonitoringSourceHealthItem[];
  onRefresh?: () => void;
}

export const MonitoringSourceHealthWidget: React.FC<MonitoringSourceHealthWidgetProps> = ({
  sources = [],
  onRefresh,
}) => {
  const displaySources = sources;

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          <div>
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Monitoring Sources Health</h4>
            <p className="text-[10px] text-slate-400">
              Provider Adapter Layer (Isolates monitoring failures from server/app failures)
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
            {displaySources.filter((s) => s.status === 'HEALTHY').length}/{displaySources.length} Sources Online
          </span>
        </div>
      </div>

      {/* Sources Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
        {displaySources.map((source) => {
          const isHealthy = source.status === 'HEALTHY';
          return (
            <div
              key={source.source_id}
              className={`p-3 rounded-lg border transition-all ${
                isHealthy
                  ? 'bg-slate-950/40 border-slate-800/60 hover:border-slate-700'
                  : 'bg-rose-950/20 border-rose-900/60'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-200 truncate">{source.source_name}</span>
                {isHealthy ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                )}
              </div>

              <div className="text-[10px] text-slate-400 mb-2 font-mono truncate">{source.adapter_name}</div>

              <div className="grid grid-cols-2 gap-1.5 text-[10px] pt-2 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-500 block">Latency</span>
                  <span className="text-cyan-400 font-semibold">{source.latency_ms} ms</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Freshness</span>
                  <span className="text-emerald-400 font-semibold">{source.data_freshness_seconds}s</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
