import React, { useState, useEffect } from 'react';
import {
  Terminal,
  Play,
  Clock,
  Sparkles,
  FileText,
  Database,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Activity,
  TrendingUp,
  BarChart3,
  ExternalLink,
  Copy,
  Check,
  X,
  Loader2,
} from 'lucide-react';
import { monitoringService } from '../../services/monitoringService';
import { PromQLQueryResponse, PromQLMetricResult } from '../../types/monitoring';

interface PromQLConsoleProps {
  selectedEnvId?: string;
  selectedEnvName?: string;
}

// Zero Synthetic Data Policy Active: All telemetry derived strictly from live Prometheus responses.
export const PromQLConsole: React.FC<PromQLConsoleProps> = ({
  selectedEnvId,
  selectedEnvName = 'All Environments',
}) => {
  const [query, setQuery] = useState('sqlite_database_used_bytes');
  const [discoveredMetrics, setDiscoveredMetrics] = useState<string[]>([]);

  // Fetch live metric names from Prometheus discovery endpoint for auto-completion
  useEffect(() => {
    const fetchCatalog = async () => {
      try {
        const res = await fetch('/api/v1/monitoring/metrics');
        if (res.ok) {
          const json = await res.json();
          if (json.data?.metrics && Array.isArray(json.data.metrics)) {
            setDiscoveredMetrics(json.data.metrics.map((m: any) => m.name));
          }
        }
      } catch (err) {
        console.debug('Metric catalog prefetch:', err);
      }
    };
    fetchCatalog();
  }, []);
  const [evaluationType, setEvaluationType] = useState<'INSTANT' | 'RANGE'>('RANGE');
  const [timeStep, setTimeStep] = useState('15s');
  const [timeWindowHours, setTimeWindowHours] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [queryResponse, setQueryResponse] = useState<PromQLQueryResponse | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [lastExecutedAt, setLastExecutedAt] = useState<string>('');
  const [queryCount, setQueryCount] = useState<number>(1);

  // Interactive SVG hover crosshair & tooltip state
  const [hoveredPoint, setHoveredPoint] = useState<{
    seriesIdx: number;
    x: number;
    y: number;
    val: string;
    time: number;
  } | null>(null);

  // Raw Prometheus Telemetry Modal State
  const [activeRawModal, setActiveRawModal] = useState<'METRICS' | 'TARGETS' | null>(null);
  const [rawModalContent, setRawModalContent] = useState<string>('');
  const [isLoadingRaw, setIsLoadingRaw] = useState<boolean>(false);
  const [copiedRaw, setCopiedRaw] = useState<boolean>(false);

  const handleOpenRawModal = async (type: 'METRICS' | 'TARGETS') => {
    setActiveRawModal(type);
    setIsLoadingRaw(true);
    setCopiedRaw(false);
    try {
      const url =
        type === 'METRICS'
          ? '/api/v1/monitoring/prometheus/metrics'
          : '/api/v1/monitoring/prometheus/targets.json';
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
      if (type === 'METRICS') {
        const text = await res.text();
        setRawModalContent(text);
      } else {
        const json = await res.json();
        setRawModalContent(JSON.stringify(json, null, 2));
      }
    } catch (e: any) {
      setRawModalContent(`Error fetching endpoint: ${e?.message || e}`);
    } finally {
      setIsLoadingRaw(false);
    }
  };

  const handleCopyRaw = () => {
    if (!rawModalContent) return;
    navigator.clipboard.writeText(rawModalContent);
    setCopiedRaw(true);
    setTimeout(() => setCopiedRaw(false), 2000);
  };

  const PRESET_QUERIES = [
    { label: 'Host CPU %', query: 'windows_cpu_utilization', desc: 'Real-time Windows host CPU utilization percentage' },
    { label: 'Host Memory Free', query: 'windows_memory_physical_free_bytes', desc: 'Real-time Windows physical free memory in bytes' },
    { label: 'Target Up (Prometheus)', query: 'up', desc: 'Prometheus target availability (1 = UP, 0 = DOWN)' },
    { label: 'DB Health / Up', query: 'sqlite_database_up', desc: 'Database scrape connectivity health (1 = UP)' },
    { label: 'Scrape Duration (s)', query: 'scrape_duration_seconds', desc: 'Time taken by Prometheus to scrape exporter' },
    { label: 'DB Used Bytes', query: 'sqlite_database_used_bytes', desc: 'Approximate used SQLite database storage in bytes' },
    { label: 'DB Size Bytes', query: 'sqlite_database_size_bytes', desc: 'Total SQLite database file size in bytes' },
    { label: 'DB Tables Count', query: 'sqlite_database_tables_total', desc: 'Total user tables in SQLite database' },
    { label: 'DB Query Latency', query: 'sqlite_database_query_duration_seconds', desc: 'SQLite scrape / query latency in seconds' },
  ];

  const handleExecuteQuery = async (queryOverride?: string, typeOverride?: 'INSTANT' | 'RANGE') => {
    const activeQuery = (queryOverride !== undefined ? queryOverride : query).trim();
    const activeType = typeOverride || evaluationType;
    if (!activeQuery) return;

    setIsLoading(true);
    setErrorMsg(null);
    setHoveredPoint(null);

    const startTime = Date.now();
    const minDelayMs = 700; // Guarantees the loader is clearly visible to the user even on sub-millisecond local queries

    try {
      let res: PromQLQueryResponse | null = null;
      if (activeType === 'INSTANT') {
        res = await monitoringService.queryPromQL(activeQuery, selectedEnvId);
      } else {
        const now = Date.now() / 1000;
        const start = now - timeWindowHours * 3600;
        res = await monitoringService.queryPromQLRange(activeQuery, start, now, timeStep, selectedEnvId);
      }

      // Ensure minimum display time so the loader does not flash abruptly
      const elapsed = Date.now() - startTime;
      if (elapsed < minDelayMs) {
        await new Promise((resolve) => setTimeout(resolve, minDelayMs - elapsed));
      }

      setQueryResponse(res);
      setLastExecutedAt(new Date().toLocaleTimeString());
      setQueryCount((c) => c + 1);
    } catch (err: any) {
      const elapsed = Date.now() - startTime;
      if (elapsed < minDelayMs) {
        await new Promise((resolve) => setTimeout(resolve, minDelayMs - elapsed));
      }
      console.warn('Backend PromQL execution error:', err);
      setErrorMsg(err?.message || 'Error executing PromQL query on Prometheus.');
      setQueryResponse(null);
      setLastExecutedAt(new Date().toLocaleTimeString());
      setQueryCount((c) => c + 1);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    handleExecuteQuery();
  }, [selectedEnvId, evaluationType, timeWindowHours, timeStep]);

  // Metric-specific visual theme & palette helper
  const getMetricTheme = (metricName: string) => {
    const q = metricName.toLowerCase();
    if (q.includes('bytes')) {
      return {
        color: '#10b981',
        border: 'border-emerald-500/50',
        bg: 'bg-emerald-950/40',
        badge: 'text-emerald-300 bg-emerald-950/80 border-emerald-800',
        gradientStart: 'rgba(16, 185, 129, 0.45)',
        dot: 'bg-emerald-400',
        category: 'DATABASE STORAGE (BYTES)',
      };
    }
    if (q.includes('sqlite') || q.includes('database') || q.includes('table')) {
      return {
        color: '#38bdf8',
        border: 'border-sky-500/50',
        bg: 'bg-sky-950/40',
        badge: 'text-sky-300 bg-sky-950/80 border-sky-800',
        gradientStart: 'rgba(56, 189, 248, 0.45)',
        dot: 'bg-sky-400',
        category: 'DATABASE METRIC',
      };
    }
    if (q === 'up' || q.includes('database_up')) {
      return {
        color: '#22c55e',
        border: 'border-green-500/50',
        bg: 'bg-green-950/40',
        badge: 'text-green-300 bg-green-950/80 border-green-800',
        gradientStart: 'rgba(34, 197, 94, 0.45)',
        dot: 'bg-green-400',
        category: 'TARGET HEALTH (UP)',
      };
    }
    if (q.includes('memory')) {
      return {
        color: '#a855f7',
        border: 'border-purple-500/50',
        bg: 'bg-purple-950/40',
        badge: 'text-purple-300 bg-purple-950/80 border-purple-800',
        gradientStart: 'rgba(168, 85, 247, 0.45)',
        dot: 'bg-purple-400',
        category: 'MEMORY SATURATION',
      };
    }
    if (q.includes('latency') || q.includes('response_time')) {
      return {
        color: '#06b6d4',
        border: 'border-cyan-500/50',
        bg: 'bg-cyan-950/40',
        badge: 'text-cyan-300 bg-cyan-950/80 border-cyan-800',
        gradientStart: 'rgba(6, 182, 212, 0.45)',
        dot: 'bg-cyan-400',
        category: 'GATEWAY LATENCY',
      };
    }
    if (q.includes('error')) {
      return {
        color: '#f43f5e',
        border: 'border-rose-500/50',
        bg: 'bg-rose-950/40',
        badge: 'text-rose-300 bg-rose-950/80 border-rose-800',
        gradientStart: 'rgba(244, 63, 94, 0.45)',
        dot: 'bg-rose-400',
        category: 'HTTP ERROR RATE',
      };
    }
    if (q.includes('pool')) {
      return {
        color: '#10b981',
        border: 'border-emerald-500/50',
        bg: 'bg-emerald-950/40',
        badge: 'text-emerald-300 bg-emerald-950/80 border-emerald-800',
        gradientStart: 'rgba(16, 185, 129, 0.45)',
        dot: 'bg-emerald-400',
        category: 'DB CONNECTION POOL',
      };
    }
    if (q.includes('node_cpu') || q.includes('seconds')) {
      return {
        color: '#6366f1',
        border: 'border-indigo-500/50',
        bg: 'bg-indigo-950/40',
        badge: 'text-indigo-300 bg-indigo-950/80 border-indigo-800',
        gradientStart: 'rgba(99, 102, 241, 0.45)',
        dot: 'bg-indigo-400',
        category: 'RAW HOST COUNTER',
      };
    }
    return {
      color: '#f97316',
      border: 'border-orange-500/50',
      bg: 'bg-orange-950/40',
      badge: 'text-orange-300 bg-orange-950/80 border-orange-800',
      gradientStart: 'rgba(249, 115, 22, 0.45)',
      dot: 'bg-orange-400',
      category: 'HOST METRIC',
    };
  };

  // Determine metric unit for display
  const getUnitSuffix = (metricName: string) => {
    const q = metricName.toLowerCase();
    if (q.includes('bytes')) {
      return ' bytes';
    }
    if (q === 'up' || q.includes('database_up')) {
      return ' (1=UP)';
    }
    if (q.includes('memory') || q.includes('cpu') || q.includes('pool') || q.includes('rate') || q.includes('pct') || q.includes('utilization')) {
      return '%';
    }
    if (q.includes('latency') || q.includes('response_time') || q.includes('duration') || q.includes('ms')) {
      return ' ms';
    }
    if (q.includes('seconds') || q.includes('sec')) {
      return 's';
    }
    return '';
  };

  // Format metric value cleanly according to its unit
  const formatMetricValue = (val: number, unit: string) => {
    if (unit.trim() === 'bytes') {
      if (val >= 1024 * 1024 * 1024) return `${(val / (1024 * 1024 * 1024)).toFixed(2)} GB`;
      if (val >= 1024 * 1024) return `${(val / (1024 * 1024)).toFixed(2)} MB`;
      if (val >= 1024) return `${(val / 1024).toFixed(1)} KB`;
      return `${Math.round(val)} B`;
    }
    if (unit === '%') {
      return `${val.toFixed(val < 10 ? 2 : 1)}%`;
    }
    if (unit.trim() === 's') {
      return val < 1 ? `${(val * 1000).toFixed(1)} ms` : `${val.toFixed(2)} s`;
    }
    if (unit.includes('1=UP')) {
      return val === 1 ? '1 (UP)' : '0 (DOWN)';
    }
    if (val >= 1000000) return `${(val / 1000000).toFixed(2)}M`;
    if (val >= 1000) return `${(val / 1000).toFixed(1)}k`;
    return `${val % 1 === 0 ? val : val.toFixed(2)}${unit}`;
  };

  return (
    <div className="space-y-6">
      {/* PromQL Query Terminal Bar */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-orange-400" />
            <h3 className="text-sm font-mono font-bold text-white tracking-wide uppercase">
              PromQL Interactive Query Console
            </h3>
            <span className="text-[10px] font-mono text-slate-500">|</span>
            <span className="text-[10px] font-mono text-slate-400">
              Target: <strong className="text-orange-400">{selectedEnvName}</strong>
            </span>
          </div>

          {/* Service Discovery & Raw Metrics Links */}
          <div className="flex items-center gap-2 text-xs font-mono">
            <button
              onClick={() => handleOpenRawModal('METRICS')}
              className="flex items-center gap-1.5 text-[10px] font-bold text-slate-300 hover:text-orange-400 bg-slate-900 border border-slate-800 hover:border-orange-500/50 px-2.5 py-1 rounded transition-all cursor-pointer shadow-sm group"
              title="Inspect live Prometheus text exposition (/metrics)"
            >
              <FileText className="w-3 h-3 text-orange-400 group-hover:scale-110 transition-transform" />
              <span>/metrics</span>
            </button>
            <button
              onClick={() => handleOpenRawModal('TARGETS')}
              className="flex items-center gap-1.5 text-[10px] font-bold text-slate-300 hover:text-emerald-400 bg-slate-900 border border-slate-800 hover:border-emerald-500/50 px-2.5 py-1 rounded transition-all cursor-pointer shadow-sm group"
              title="Inspect Prometheus HTTP Service Discovery targets (/targets.json)"
            >
              <Layers className="w-3 h-3 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span>/targets.json</span>
            </button>
          </div>
        </div>

        {/* Input Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="relative flex-1">
            <input list="prom-metric-suggestions"
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleExecuteQuery()}
              placeholder="e.g. cpu_utilization, node_cpu_seconds_total, http_response_time_ms"
              className="w-full bg-[#161f2e] border border-slate-700 rounded-lg pl-3 pr-20 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:border-orange-500 focus:outline-none shadow-inner"
            />
            <datalist id="prom-metric-suggestions">
              {discoveredMetrics.map((name) => (
                <option key={name} value={name} />
              ))}
            </datalist>
            <span className="absolute right-3 top-2.5 text-[10px] font-mono text-slate-500 font-bold uppercase">
              PromQL
            </span>
          </div>

          {/* Query Type Toggle */}
          <div className="flex items-center bg-[#161f2e] border border-slate-700 rounded-lg p-0.5 text-xs font-mono">
            <button
              onClick={() => {
                setEvaluationType('RANGE');
                handleExecuteQuery(undefined, 'RANGE');
              }}
              className={`px-3 py-1.5 rounded-md font-bold transition-all ${
                evaluationType === 'RANGE'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Graph View (Range)
            </button>
            <button
              onClick={() => {
                setEvaluationType('INSTANT');
                handleExecuteQuery(undefined, 'INSTANT');
              }}
              className={`px-3 py-1.5 rounded-md font-bold transition-all ${
                evaluationType === 'INSTANT'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Table View (Instant)
            </button>
          </div>

          {/* Time Controls for Range Query */}
          {evaluationType === 'RANGE' && (
            <div className="flex items-center gap-2">
              <select
                value={timeWindowHours}
                onChange={(e) => setTimeWindowHours(Number(e.target.value))}
                className="bg-[#161f2e] border border-slate-700 text-white text-xs font-mono font-bold rounded-lg px-2.5 py-2 focus:outline-none cursor-pointer"
              >
                <option value={1}>1 Hour</option>
                <option value={6}>6 Hours</option>
                <option value={24}>24 Hours</option>
                <option value={168}>7 Days</option>
              </select>
              <select
                value={timeStep}
                onChange={(e) => setTimeStep(e.target.value)}
                className="bg-[#161f2e] border border-slate-700 text-white text-xs font-mono font-bold rounded-lg px-2.5 py-2 focus:outline-none cursor-pointer"
              >
                <option value="15s">Step: 15s</option>
                <option value="30s">Step: 30s</option>
                <option value="1m">Step: 1m</option>
                <option value="5m">Step: 5m</option>
              </select>
            </div>
          )}

          {/* Execute Button */}
          <button
            onClick={() => handleExecuteQuery()}
            disabled={isLoading}
            className={`flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg text-xs font-mono font-bold text-white transition-all shadow-md cursor-pointer ${
              isLoading
                ? 'bg-orange-700/80 cursor-wait opacity-85'
                : 'bg-orange-600 hover:bg-orange-500 active:scale-95'
            }`}
          >
            {isLoading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            <span>{isLoading ? 'RUNNING...' : 'RUN'}</span>
          </button>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] font-mono">
          <span className="text-slate-500 text-[10px] uppercase font-bold shrink-0">PRESETS:</span>
          {PRESET_QUERIES.map((p) => {
            const isMatch = query === p.query;
            const pTheme = getMetricTheme(p.query);
            return (
              <button
                key={p.query}
                onClick={() => {
                  setQuery(p.query);
                  handleExecuteQuery(p.query);
                }}
                className={`px-2.5 py-1 rounded text-xs font-mono transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                  isMatch
                    ? `${pTheme.bg} ${pTheme.badge} font-bold shadow-md ring-1 ring-white/20 scale-[1.02]`
                    : 'bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white'
                }`}
                title={p.desc}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${pTheme.dot}`}></span>
                <span>{p.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Error Message */}
      {errorMsg && (
        <div className="bg-rose-950/80 border border-rose-800 text-rose-300 rounded-xl p-4 text-xs font-mono flex items-center gap-2 shadow-lg">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Loading Indicator when query is actively executing and no response yet */}
      {isLoading && !queryResponse && (
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-12 shadow-xl flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
          <div className="text-xs font-mono text-slate-200 font-semibold">Executing PromQL query on live Prometheus...</div>
          <div className="text-[11px] font-mono text-slate-500">Evaluating metric expression against Prometheus server</div>
        </div>
      )}

      {/* Results Rendering */}
      {queryResponse && (
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 shadow-xl space-y-4 relative">
          {isLoading && (
            <div className="absolute inset-0 bg-[#0f172a]/70 backdrop-blur-[1px] rounded-xl flex items-center justify-center z-20">
              <div className="flex items-center gap-2.5 px-4 py-2.5 bg-slate-900/95 border border-orange-500/50 rounded-lg shadow-2xl text-xs font-mono text-white">
                <Loader2 className="w-4 h-4 text-orange-400 animate-spin" />
                <span>Executing PromQL query...</span>
              </div>
            </div>
          )}
          {/* Status Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <span className={`font-bold flex items-center gap-1.5 px-2.5 py-1 rounded-full ${
                queryResponse.data.result.length > 0 
                  ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/80' 
                  : 'text-amber-400 bg-amber-950/60 border border-amber-800/80'
              }`}>
                {queryResponse.data.result.length > 0 ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                )}
                {queryResponse.data.result.length > 0 ? 'HTTP 200 OK (LIVE PROMETHEUS)' : 'EMPTY RESULT (0 SERIES)'}
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                Result Type: <strong className="text-white">{queryResponse.data.resultType}</strong>
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                Series: <strong className="text-white">{queryResponse.data.result.length}</strong>
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                Active: <strong className={getMetricTheme(query).badge + " px-2 py-0.5 rounded text-[10px]"}>{getMetricTheme(query).category}</strong>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                <span>Run #{queryCount}</span>
              </span>
              {lastExecutedAt && (
                <div className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-500" />
                  <span>{lastExecutedAt}</span>
                </div>
              )}
            </div>
          </div>

          {/* Zero Result Empty State */}
          {queryResponse.data.result.length === 0 ? (
            <div className="bg-[#161f2e] border border-amber-900/50 rounded-xl p-8 text-center space-y-3 font-mono">
              <div className="inline-flex p-3 rounded-full bg-amber-950/80 border border-amber-800 text-amber-400 shadow-md">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                No Metric Series Found in Prometheus
              </h4>
              <p className="text-xs text-slate-400 max-w-lg mx-auto">
                Prometheus has no scraped data for query <code className="text-amber-300 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700">{query}</code>.
              </p>
              <div className="text-[11px] text-emerald-400 font-semibold pt-1">
                Zero Synthetic Data Policy Enforced — Only genuine Prometheus scraped data is displayed.
              </div>
              <div className="text-[11px] text-slate-400 pt-2">
                Click a live scraped metric to view real Prometheus data:
                <div className="flex flex-wrap items-center justify-center gap-2 mt-2">
                  {['sqlite_database_used_bytes', 'sqlite_database_size_bytes', 'sqlite_database_query_duration_seconds', 'sqlite_database_up', 'up'].map((m) => (
                    <button
                      key={m}
                      onClick={() => {
                        setQuery(m);
                        handleExecuteQuery(m);
                      }}
                      className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500 text-slate-300 hover:text-white rounded text-[10px] transition-colors cursor-pointer"
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <>
          {/* RANGE QUERY: Render SVG Chart & Summary Statistics */}
          {queryResponse.data.resultType === 'matrix' && (
            <div className="space-y-6">
              {queryResponse.data.result.map((series, sIdx) => {
                const values = series.values || [];
                const numVals = values.map((v) => parseFloat(v[1]) || 0);
                const minVal = numVals.length > 0 ? Math.min(...numVals) : 0;
                const maxVal = numVals.length > 0 ? Math.max(...numVals) : 1.0;
                const avgVal = numVals.length > 0 ? numVals.reduce((a, b) => a + b, 0) / numVals.length : 0;
                const latestVal = numVals.length > 0 ? numVals[numVals.length - 1] : 0;

                const metricTitle = series.metric?.__name__ || query;
                const mTheme = getMetricTheme(metricTitle);
                const unit = getUnitSuffix(metricTitle);

                // Semantic Y-axis scale based on metric category so each metric sits at its true height!
                let scaleMin = 0;
                let scaleMax = 100;

                if (unit === '%') {
                  if (metricTitle.toLowerCase().includes('error')) {
                    scaleMin = 0;
                    scaleMax = Math.max(2.0, Math.ceil(maxVal * 1.5 * 10) / 10);
                  } else {
                    scaleMin = 0;
                    scaleMax = 100;
                  }
                } else if (unit.trim() === 'ms') {
                  scaleMin = 0;
                  scaleMax = Math.max(10, Math.ceil(maxVal * 1.25));
                } else if (unit.trim() === 's') {
                  if (maxVal < 1.0) {
                    scaleMin = 0;
                    scaleMax = Math.max(0.005, Number((maxVal * 1.3).toFixed(3)));
                  } else {
                    const pad = Math.max(0.1, (maxVal - minVal) * 0.2);
                    scaleMin = Math.max(0, Number((minVal - pad).toFixed(2)));
                    scaleMax = Number((maxVal + pad).toFixed(2));
                  }
                } else if (minVal === maxVal) {
                  // For flat series with constant values (e.g. 1=UP or fixed count)
                  if (maxVal === 1.0 && (unit.includes('UP') || metricTitle === 'up')) {
                    scaleMin = 0;
                    scaleMax = 2;
                  } else if (maxVal > 0) {
                    scaleMin = Math.floor(maxVal * 0.85);
                    scaleMax = Math.ceil(maxVal * 1.15);
                  } else {
                    scaleMin = 0;
                    scaleMax = 1;
                  }
                } else {
                  const pad = Math.max(0.001, (maxVal - minVal) * 0.15);
                  scaleMin = Math.max(0, minVal - pad);
                  scaleMax = maxVal + pad;
                }

                const formatDisplayVal = (v: number) => {
                  if (scaleMax < 0.05) return v.toFixed(4);
                  if (scaleMax < 1) return v.toFixed(3);
                  if (unit === '%' && scaleMax <= 10) return v.toFixed(2);
                  if (scaleMax < 10) return v.toFixed(2);
                  return v.toFixed(1);
                };

                const scaleRange = Math.max(0.001, scaleMax - scaleMin);

                const width = 680;
                const height = 190;
                const paddingX = 20;
                const paddingY = 25;
                const plotW = width - paddingX * 2;
                const plotH = height - paddingY * 2;

                const pts = values.map((v, i) => {
                  const num = parseFloat(v[1]) || 0;
                  const x = paddingX + (i / Math.max(1, values.length - 1)) * plotW;
                  const clampedNum = Math.max(scaleMin, Math.min(scaleMax, num));
                  const y = paddingY + plotH - ((clampedNum - scaleMin) / scaleRange) * plotH;
                  return { x, y, val: v[1], time: v[0] };
                });

                const lineD = pts.length > 0
                  ? pts.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)},${p.y.toFixed(1)}`, '')
                  : '';
                const areaD = pts.length > 0
                  ? `${lineD} L ${pts[pts.length - 1].x.toFixed(1)},${height - paddingY + 10} L ${pts[0].x.toFixed(1)},${height - paddingY + 10} Z`
                  : '';

                const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
                  if (pts.length === 0) return;
                  const rect = e.currentTarget.getBoundingClientRect();
                  const mouseX = e.clientX - rect.left;
                  const svgX = (mouseX / rect.width) * width;

                  let closest = pts[0];
                  let minDiff = Math.abs(pts[0].x - svgX);
                  for (let i = 1; i < pts.length; i++) {
                    const diff = Math.abs(pts[i].x - svgX);
                    if (diff < minDiff) {
                      minDiff = diff;
                      closest = pts[i];
                    }
                  }
                  if (closest) {
                    setHoveredPoint({
                      seriesIdx: sIdx,
                      x: closest.x,
                      y: closest.y,
                      val: closest.val,
                      time: closest.time,
                    });
                  }
                };

                return (
                  <div
                    key={`${sIdx}-${query}-${queryCount}`}
                    className="bg-[#161f2e] border border-slate-800 rounded-xl p-4 space-y-3 shadow-inner transition-all duration-300"
                  >
                    {/* Series Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                      <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono">
                        <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${mTheme.dot}`}></span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${mTheme.badge}`}>
                          {mTheme.category}
                        </span>
                        {Object.entries(series.metric).map(([k, v]) => (
                          <span
                            key={k}
                            className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-slate-300"
                          >
                            <strong style={{ color: mTheme.color }}>{k}</strong>="{v}"
                          </span>
                        ))}
                      </div>
                      <div className="flex items-center gap-2 font-mono text-xs">
                        <span className="text-slate-400 text-[11px]">Latest:</span>
                        <span
                          style={{ color: mTheme.color, borderColor: mTheme.color }}
                          className="font-bold border px-2.5 py-0.5 rounded bg-slate-900/80 shadow-sm"
                        >
                          {formatDisplayVal(latestVal)}{unit}
                        </span>
                      </div>
                    </div>

                    {/* Minimum / Maximum / Average Summary Statistics */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                      <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-2.5">
                        <div className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider">
                          MINIMUM
                        </div>
                        <div className="text-lg font-mono font-bold text-white mt-0.5">
                          {formatDisplayVal(minVal)}
                          <span className="text-xs text-slate-400 ml-0.5">{unit}</span>
                        </div>
                      </div>
                      <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-2.5">
                        <div className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider">
                          AVERAGE
                        </div>
                        <div className="text-lg font-mono font-bold text-white mt-0.5">
                          {formatDisplayVal(avgVal)}
                          <span className="text-xs text-slate-400 ml-0.5">{unit}</span>
                        </div>
                      </div>
                      <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-2.5">
                        <div className="text-[10px] font-mono text-rose-400 font-bold uppercase tracking-wider">
                          MAXIMUM
                        </div>
                        <div className="text-lg font-mono font-bold text-white mt-0.5">
                          {formatDisplayVal(maxVal)}
                          <span className="text-xs text-slate-400 ml-0.5">{unit}</span>
                        </div>
                      </div>
                      <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-2.5">
                        <div
                          style={{ color: mTheme.color }}
                          className="text-[10px] font-mono font-bold uppercase tracking-wider"
                        >
                          CURRENT
                        </div>
                        <div
                          style={{ color: mTheme.color }}
                          className="text-lg font-mono font-bold mt-0.5"
                        >
                          {formatDisplayVal(latestVal)}
                          <span className="text-xs opacity-75 ml-0.5">{unit}</span>
                        </div>
                      </div>
                    </div>

                    {/* Interactive SVG Chart */}
                    <div className="relative w-full rounded-lg bg-[#0b111e] border border-slate-800/90 p-2 overflow-hidden shadow-inner">
                      <svg
                        viewBox={`0 0 ${width} ${height}`}
                        className="w-full h-44 cursor-crosshair select-none"
                        preserveAspectRatio="none"
                        onMouseMove={handleMouseMove}
                        onMouseLeave={() => setHoveredPoint(null)}
                      >
                        <defs>
                          <linearGradient id={`grad-promql-${sIdx}-${metricTitle}`} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor={mTheme.gradientStart} />
                            <stop offset="100%" stopColor="rgba(0, 0, 0, 0.0)" />
                          </linearGradient>
                        </defs>

                        {/* Y-Axis Gridlines & Reference Values */}
                        <line
                          x1={paddingX}
                          y1={paddingY}
                          x2={width - paddingX}
                          y2={paddingY}
                          stroke="#1e293b"
                          strokeDasharray="3 3"
                        />
                        <text
                          x={paddingX + 4}
                          y={paddingY - 5}
                          fill="#64748b"
                          fontSize="9"
                          fontFamily="monospace"
                        >
                          {scaleMax < 0.05 ? scaleMax.toFixed(4) : scaleMax < 1 ? scaleMax.toFixed(3) : scaleMax < 10 ? scaleMax.toFixed(1) : scaleMax.toFixed(0)}{unit}
                        </text>

                        <line
                          x1={paddingX}
                          y1={paddingY + plotH / 2}
                          x2={width - paddingX}
                          y2={paddingY + plotH / 2}
                          stroke="#1e293b"
                          strokeDasharray="3 3"
                        />
                        <text
                          x={paddingX + 4}
                          y={paddingY + plotH / 2 - 5}
                          fill="#475569"
                          fontSize="9"
                          fontFamily="monospace"
                        >
                          {((scaleMax + scaleMin) / 2) < 0.05 ? ((scaleMax + scaleMin) / 2).toFixed(4) : ((scaleMax + scaleMin) / 2) < 1 ? ((scaleMax + scaleMin) / 2).toFixed(3) : ((scaleMax + scaleMin) / 2) < 10 ? ((scaleMax + scaleMin) / 2).toFixed(1) : ((scaleMax + scaleMin) / 2).toFixed(0)}{unit}
                        </text>

                        <line
                          x1={paddingX}
                          y1={paddingY + plotH}
                          x2={width - paddingX}
                          y2={paddingY + plotH}
                          stroke="#1e293b"
                          strokeDasharray="3 3"
                        />
                        <text
                          x={paddingX + 4}
                          y={paddingY + plotH - 5}
                          fill="#64748b"
                          fontSize="9"
                          fontFamily="monospace"
                        >
                          {scaleMin < 0.05 && scaleMin > 0 ? scaleMin.toFixed(4) : scaleMin < 1 && scaleMin > 0 ? scaleMin.toFixed(3) : scaleMin < 10 && scaleMin > 0 ? scaleMin.toFixed(1) : scaleMin.toFixed(0)}{unit}
                        </text>

                        {/* Area & Line Fill with Metric Specific Theme Colors */}
                        {areaD && <path d={areaD} fill={`url(#grad-promql-${sIdx}-${metricTitle})`} />}
                        {lineD && (
                          <path
                            d={lineD}
                            fill="none"
                            stroke={mTheme.color}
                            strokeWidth="2.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        )}

                        {/* Interactive Data Point Markers */}
                        {pts.map((p, pIdx) => {
                          const isSampled =
                            pts.length <= 25 ||
                            pIdx % Math.ceil(pts.length / 25) === 0 ||
                            pIdx === pts.length - 1;
                          if (!isSampled) return null;
                          return (
                            <circle
                              key={pIdx}
                              cx={p.x}
                              cy={p.y}
                              r="2.5"
                              fill={mTheme.color}
                              stroke="#0f172a"
                              strokeWidth="1"
                            />
                          );
                        })}

                        {/* Hover Crosshair & Data Tooltip */}
                        {hoveredPoint && hoveredPoint.seriesIdx === sIdx && (
                          <>
                            {/* Vertical Crosshair Line */}
                            <line
                              x1={hoveredPoint.x}
                              y1={paddingY}
                              x2={hoveredPoint.x}
                              y2={height - paddingY}
                              stroke={mTheme.color}
                              strokeWidth="1.5"
                              strokeDasharray="2 2"
                            />
                            {/* Glowing Target Circle */}
                            <circle
                              cx={hoveredPoint.x}
                              cy={hoveredPoint.y}
                              r="6"
                              fill={mTheme.color}
                              stroke="#ffffff"
                              strokeWidth="2"
                            />
                            <circle
                              cx={hoveredPoint.x}
                              cy={hoveredPoint.y}
                              r="10"
                              fill="none"
                              stroke={mTheme.color}
                              strokeWidth="1"
                              opacity="0.6"
                            />

                            {/* Tooltip Card */}
                            <g
                              transform={`translate(${Math.min(
                                width - 130,
                                Math.max(paddingX, hoveredPoint.x - 65)
                              )}, ${
                                hoveredPoint.y < 70
                                  ? hoveredPoint.y + 15
                                  : hoveredPoint.y - 45
                              })`}
                            >
                              <rect
                                width="130"
                                height="38"
                                rx="6"
                                fill="#0f172a"
                                stroke={mTheme.color}
                                strokeWidth="1"
                                filter="drop-shadow(0 4px 6px rgba(0,0,0,0.5))"
                              />
                              <text
                                x="8"
                                y="15"
                                fill="#94a3b8"
                                fontSize="9"
                                fontFamily="monospace"
                              >
                                {new Date(hoveredPoint.time * 1000).toLocaleTimeString()}
                              </text>
                              <text
                                x="8"
                                y="30"
                                fill="#ffffff"
                                fontSize="12"
                                fontWeight="bold"
                                fontFamily="monospace"
                              >
                                {hoveredPoint.val}
                                <tspan fill={mTheme.color} fontSize="10">
                                  {unit}
                                </tspan>
                              </text>
                            </g>
                          </>
                        )}
                      </svg>
                    </div>

                    {/* Time Window Legend */}
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 px-1">
                      <span>{values[0]?.[0] ? new Date(values[0][0] * 1000).toLocaleTimeString() : 'Start'}</span>
                      <span className="text-slate-600">
                        Window: Last {timeWindowHours} Hour{timeWindowHours > 1 ? 's' : ''} ({values.length} data points)
                      </span>
                      <span>
                        {values[values.length - 1]?.[0]
                          ? new Date(values[values.length - 1][0] * 1000).toLocaleTimeString()
                          : 'Now'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* INSTANT QUERY: Render High-Fidelity Table View */}
          {queryResponse.data.resultType === 'vector' && (() => {
            const vectorResults = queryResponse.data.result;
            const values = vectorResults
              .map((r) => parseFloat(r.value?.[1] || '0'))
              .filter((v) => !isNaN(v));
            const minVal = values.length > 0 ? Math.min(...values) : 0;
            const maxVal = values.length > 0 ? Math.max(...values) : 0;
            const avgVal = values.length > 0 ? values.reduce((a, b) => a + b, 0) / values.length : 0;
            const unit = getUnitSuffix(vectorResults[0]?.metric?.__name__ || query);
            const mTheme = getMetricTheme(query);

            return (
              <div className="space-y-3.5">
                {/* Instant Vector Summary Header */}
                <div className="bg-[#161f2e] border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-md">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-orange-950/70 border border-orange-800/80 flex items-center justify-center text-orange-400 shrink-0 shadow-inner">
                      <Layers className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-mono font-bold text-white tracking-wide">
                          Instant Vector Snapshot
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${mTheme.badge}`}>
                          {mTheme.category}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-900 border border-slate-700 text-slate-300">
                          {vectorResults.length} Target Instances
                        </span>
                      </div>
                      <p className="text-xs font-mono text-slate-400 mt-1">
                        Active PromQL evaluation across instances in <strong className="text-orange-400">{selectedEnvName}</strong>
                      </p>
                    </div>
                  </div>

                  {/* Summary Metric Badges */}
                  {values.length > 0 && (
                    <div className="grid grid-cols-3 gap-2 font-mono text-xs shrink-0">
                      <div className="bg-[#0f172a] border border-slate-800 px-3 py-1.5 rounded-lg text-center">
                        <span className="text-[9px] text-cyan-400 block font-bold tracking-wider">MINIMUM</span>
                        <span className="text-white font-bold text-sm">
                          {minVal.toFixed(unit === '%' && maxVal <= 10 ? 2 : 1)}{unit}
                        </span>
                      </div>
                      <div className="bg-[#0f172a] border border-slate-800 px-3 py-1.5 rounded-lg text-center">
                        <span className="text-[9px] text-amber-400 block font-bold tracking-wider">AVERAGE</span>
                        <span className="text-white font-bold text-sm">
                          {avgVal.toFixed(unit === '%' && maxVal <= 10 ? 2 : 1)}{unit}
                        </span>
                      </div>
                      <div className="bg-[#0f172a] border border-slate-800 px-3 py-1.5 rounded-lg text-center">
                        <span className="text-[9px] text-rose-400 block font-bold tracking-wider">MAXIMUM</span>
                        <span className="text-white font-bold text-sm">
                          {maxVal.toFixed(unit === '%' && maxVal <= 10 ? 2 : 1)}{unit}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Instant Vector Data Table */}
                <div className="overflow-x-auto rounded-xl border border-slate-800 shadow-xl">
                  <table className="w-full text-left font-mono text-xs">
                    <thead>
                      <tr className="bg-[#161f2e] border-b border-slate-800 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                        <th className="py-3 px-4">Monitored Service / Target</th>
                        <th className="py-3 px-3">Metric Labels</th>
                        <th className="py-3 px-3 text-center">Scrape Target State</th>
                        <th className="py-3 px-4 text-right">Instant Telemetry</th>
                        <th className="py-3 px-4 text-right">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 bg-[#0f172a]">
                      {vectorResults.map((res, rIdx) => {
                        const compName = res.metric.component || res.metric.service || res.metric.instance || 'Target Instance';
                        const hostName = res.metric.instance || res.metric.host || '';
                        const tier = res.metric.tier || 'service';

                        return (
                          <tr key={rIdx} className="hover:bg-slate-800/40 transition-colors">
                            {/* Component / Target Name */}
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2.5">
                                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
                                <div>
                                  <div className="font-bold text-white text-xs flex items-center gap-1.5">
                                    <span>{compName}</span>
                                    <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">
                                      {tier}
                                    </span>
                                  </div>
                                  {hostName && (
                                    <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                                      {hostName}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </td>

                            {/* Prometheus Labels */}
                            <td className="py-3 px-3">
                              <div className="flex flex-wrap items-center gap-1 max-w-xl">
                                {Object.entries(res.metric)
                                  .filter(([k]) => !['component', 'tier'].includes(k))
                                  .map(([k, v]) => (
                                    <span
                                      key={k}
                                      className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-slate-300"
                                    >
                                      <span style={{ color: mTheme.color }}>{k}</span>="{v}"
                                    </span>
                                  ))}
                              </div>
                            </td>

                            {/* Target State */}
                            <td className="py-3 px-3 text-center">
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950/70 border border-emerald-800 text-[10px] font-bold text-emerald-400 shadow-sm">
                                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                UP (1)
                              </span>
                            </td>

                            {/* Instant Value */}
                            <td className="py-3 px-4 text-right">
                              <span
                                style={{ color: mTheme.color }}
                                className="font-bold text-base tracking-tight"
                              >
                                {res.value?.[1]}
                              </span>
                              <span className="text-xs text-slate-400 ml-1">
                                {unit}
                              </span>
                            </td>

                            {/* Timestamp */}
                            <td className="py-3 px-4 text-right text-slate-400 text-[11px] whitespace-nowrap">
                              <div className="flex items-center justify-end gap-1.5 text-slate-400">
                                <Clock className="w-3.5 h-3.5 text-slate-500" />
                                <span>{res.value?.[0] ? new Date(res.value[0] * 1000).toLocaleTimeString() : 'now'}</span>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}
            </>
          )}
        </div>
      )}

      {/* Raw Prometheus Telemetry Inspector Modal */}
      {activeRawModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-4xl bg-[#0f172a] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#161f2e]">
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                    activeRawModal === 'METRICS'
                      ? 'bg-orange-950/80 border border-orange-800 text-orange-400'
                      : 'bg-emerald-950/80 border border-emerald-800 text-emerald-400'
                  }`}
                >
                  {activeRawModal === 'METRICS' ? <FileText className="w-5 h-5" /> : <Layers className="w-5 h-5" />}
                </div>
                <div>
                  <h4 className="text-sm font-mono font-bold text-white flex items-center gap-2">
                    <span>
                      {activeRawModal === 'METRICS'
                        ? 'Prometheus Text Exposition Format'
                        : 'Prometheus HTTP Service Discovery (SD)'}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded font-mono bg-slate-900 border border-slate-700 text-slate-300">
                      {activeRawModal === 'METRICS' ? 'GET /metrics' : 'GET /targets.json'}
                    </span>
                  </h4>
                  <p className="text-xs font-mono text-slate-400 mt-0.5">
                    {activeRawModal === 'METRICS'
                      ? 'Standard OpenMetrics exposition payload ready for external Prometheus scraper ingestion'
                      : 'http_sd_config payload for automated target & exporter discovery'}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <a
                  href={
                    activeRawModal === 'METRICS'
                      ? '/api/v1/monitoring/prometheus/metrics'
                      : '/api/v1/monitoring/prometheus/targets.json'
                  }
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors"
                  title="Open raw output in a separate browser tab"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-orange-400" />
                  <span>Open in Tab</span>
                </a>
                <button
                  onClick={handleCopyRaw}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors cursor-pointer"
                  title="Copy full telemetry payload to clipboard"
                >
                  {copiedRaw ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-bold">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => setActiveRawModal(null)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-2 cursor-pointer"
                  title="Close modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-4 overflow-y-auto flex-1 bg-[#0b111e] font-mono text-xs">
              {isLoadingRaw ? (
                <div className="py-16 flex flex-col items-center justify-center text-slate-500 gap-2">
                  <span className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full animate-spin"></span>
                  <span className="text-xs">Fetching Prometheus payload from backend...</span>
                </div>
              ) : (
                <pre className="text-slate-300 whitespace-pre-wrap leading-relaxed select-text p-2 font-mono text-xs">
                  {rawModalContent}
                </pre>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 border-t border-slate-800 bg-[#161f2e] flex items-center justify-between text-[11px] font-mono text-slate-500">
              <span>
                Endpoint URL:{' '}
                <code className="text-orange-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                  {activeRawModal === 'METRICS'
                    ? '/api/v1/monitoring/prometheus/metrics'
                    : '/api/v1/monitoring/prometheus/targets.json'}
                </code>
              </span>
              <span>Click Close or press Esc to dismiss</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
