import React, { useState, useEffect } from 'react';
import { X, Sliders, Plus, Trash2, RefreshCw, CheckCircle, AlertTriangle, ShieldCheck, Edit2 } from 'lucide-react';
import { ServerThresholdItem, ServerThresholdCreatePayload } from '../../types/monitoring';
import { monitoringService } from '../../services/monitoringService';

export interface ServerThresholdModalProps {
  isOpen: boolean;
  onClose: () => void;
  serverId: string;
  serverName: string;
  onThresholdsUpdated?: () => void;
}

export const ServerThresholdModal: React.FC<ServerThresholdModalProps> = ({
  isOpen,
  onClose,
  serverId,
  serverName,
  onThresholdsUpdated,
}) => {
  const [thresholds, setThresholds] = useState<ServerThresholdItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [syncing, setSyncing] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [category, setCategory] = useState('CPU');
  const [targetResource, setTargetResource] = useState('ALL');
  const [operator, setOperator] = useState('>');
  const [warningThreshold, setWarningThreshold] = useState<number>(70);
  const [criticalThreshold, setCriticalThreshold] = useState<number>(85);
  const [severeThreshold, setSevereThreshold] = useState<number | undefined>(95);
  const [durationMinutes, setDurationMinutes] = useState<number>(2);
  const [unit, setUnit] = useState('%');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const activeRuleIds = React.useMemo(() => {
    const parseTime = (item: ServerThresholdItem) => {
      const val = item.updated_at || item.created_at;
      if (!val) return 0;
      const t = new Date(val).getTime();
      return isNaN(t) ? 0 : t;
    };

    const map = new Map<string, ServerThresholdItem>();
    for (const rule of thresholds) {
      if (!rule.is_enabled) continue;
      const cat = (rule.metric_category || 'CPU').toUpperCase();
      const existing = map.get(cat);
      if (!existing) {
        map.set(cat, rule);
      } else {
        const existingIsServer = existing.server_id && existing.server_id !== 'ALL' && existing.server_id === serverId;
        const ruleIsServer = rule.server_id && rule.server_id !== 'ALL' && rule.server_id === serverId;
        if (ruleIsServer && !existingIsServer) {
          map.set(cat, rule);
        } else if (ruleIsServer === existingIsServer && parseTime(rule) > parseTime(existing)) {
          map.set(cat, rule);
        }
      }
    }
    return new Set(Array.from(map.values()).map((r) => r.id));
  }, [thresholds, serverId]);

  const fetchThresholds = async () => {
    setLoading(true);
    try {
      const data = await monitoringService.getServerThresholds(serverId);
      setThresholds(data);
    } catch (err) {
      console.error('Failed to load thresholds:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchThresholds();
      setStatusMessage(null);
    }
  }, [isOpen, serverId]);

  if (!isOpen) return null;

  const handleCategoryChange = (newCat: string) => {
    setCategory(newCat);
    if (newCat === 'CPU') {
      setName('Server Overall CPU Utilization');
      setTargetResource('ALL');
      setUnit('%');
      setWarningThreshold(70);
      setCriticalThreshold(85);
      setSevereThreshold(95);
    } else if (newCat === 'CORE') {
      setName('Logical Core CPU Utilization');
      setTargetResource('ALL');
      setUnit('%');
      setWarningThreshold(75);
      setCriticalThreshold(88);
      setSevereThreshold(96);
    } else if (newCat === 'MEMORY') {
      setName('Physical RAM Utilization');
      setTargetResource('ALL');
      setUnit('%');
      setWarningThreshold(80);
      setCriticalThreshold(90);
      setSevereThreshold(98);
    } else if (newCat === 'DISK_VOLUME') {
      setName('Storage Volume Utilization');
      setTargetResource('ALL');
      setUnit('%');
      setWarningThreshold(80);
      setCriticalThreshold(90);
      setSevereThreshold(97);
    } else if (newCat === 'DISK_IO') {
      setName('Disk Latency Limit');
      setTargetResource('ALL');
      setUnit('ms');
      setWarningThreshold(25);
      setCriticalThreshold(50);
      setSevereThreshold(100);
    } else if (newCat === 'LATENCY') {
      setName('Application Response Time SLA');
      setTargetResource('ALL');
      setUnit('ms');
      setWarningThreshold(250);
      setCriticalThreshold(500);
      setSevereThreshold(1000);
    } else if (newCat === 'ERROR_RATE') {
      setName('Application Error Rate SLA');
      setTargetResource('ALL');
      setUnit('%');
      setWarningThreshold(2);
      setCriticalThreshold(5);
      setSevereThreshold(10);
    } else if (newCat === 'DATABASE_POOL') {
      setName('Database Connection Pool Limit');
      setTargetResource('ALL');
      setUnit('%');
      setWarningThreshold(75);
      setCriticalThreshold(90);
      setSevereThreshold(98);
    } else if (newCat === 'NETWORK') {
      setName('Network Bandwidth Ceiling');
      setTargetResource('ALL');
      setUnit('KB/s');
      setWarningThreshold(5000);
      setCriticalThreshold(10000);
      setSevereThreshold(20000);
    }
  };

  const handleEdit = (rule: ServerThresholdItem) => {
    setEditingRuleId(rule.id);
    setName(rule.name);
    setCategory(rule.metric_category || 'CPU');
    setTargetResource(rule.target_resource || 'ALL');
    setOperator(rule.operator || '>');
    setWarningThreshold(rule.warning_threshold);
    setCriticalThreshold(rule.critical_threshold);
    setSevereThreshold(rule.severe_threshold);
    setDurationMinutes(rule.duration_minutes);
    setUnit(rule.unit || '%');
    setStatusMessage(`Editing rule '${rule.name}'. Adjust threshold limits and click Update.`);
  };

  const handleCancelEdit = () => {
    setEditingRuleId(null);
    setName('');
    setStatusMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setSubmitting(true);
    setStatusMessage(null);
    try {
      const payload: ServerThresholdCreatePayload = {
        name: name.trim(),
        server_id: serverId,
        metric_category: category,
        target_resource: targetResource.trim() || 'ALL',
        operator,
        warning_threshold: Number(warningThreshold),
        critical_threshold: Number(criticalThreshold),
        severe_threshold: severeThreshold !== undefined ? Number(severeThreshold) : undefined,
        duration_minutes: Number(durationMinutes),
        unit,
        is_enabled: true,
      };

      await monitoringService.saveServerThreshold(serverId, payload, editingRuleId || undefined);
      setStatusMessage(
        editingRuleId
          ? `Threshold '${name}' updated & synced to Prometheus successfully!`
          : 'Threshold saved & synced to Prometheus successfully!'
      );
      setEditingRuleId(null);
      setName('');
      await fetchThresholds();
      if (onThresholdsUpdated) onThresholdsUpdated();
    } catch (err: any) {
      setStatusMessage(`Error saving threshold: ${err.message || 'Check inputs'}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (ruleId: string) => {
    try {
      const ok = await monitoringService.deleteServerThreshold(serverId, ruleId);
      if (ok) {
        setThresholds((prev) => prev.filter((t) => t.id !== ruleId));
        setStatusMessage('Threshold deleted & Prometheus rules recompiled.');
        if (onThresholdsUpdated) onThresholdsUpdated();
      }
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  const handleSyncToPrometheus = async () => {
    setSyncing(true);
    setStatusMessage(null);
    try {
      const res = await monitoringService.syncThresholdRulesToPrometheus();
      if (res && res.success) {
        setStatusMessage(`Prometheus reloaded successfully (${res.rules_count} rules compiled).`);
      } else {
        setStatusMessage(res?.message || 'Prometheus reload returned error.');
      }
    } catch (err: any) {
      setStatusMessage(`Sync failed: ${err.message}`);
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg border border-indigo-500/20">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Dynamic Server Alert Thresholds</h2>
              <p className="text-xs text-slate-400">
                Server: <span className="text-cyan-400 font-medium">{serverName}</span> ({serverId})
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSyncToPrometheus}
              disabled={syncing}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 rounded border border-slate-600 transition"
              title="Force PromQL compilation and Prometheus hot reload"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin text-cyan-400' : ''}`} />
              {syncing ? 'Syncing...' : 'Sync to Prometheus'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Status notification banner */}
        {statusMessage && (
          <div className="px-6 py-2.5 bg-indigo-950/60 border-b border-indigo-500/30 text-xs text-indigo-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{statusMessage}</span>
            </div>
            <button onClick={() => setStatusMessage(null)} className="text-indigo-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Create Threshold Form */}
          <div className="bg-slate-950/50 rounded-lg p-4 border border-slate-800">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-cyan-400" /> Configure Dynamic Threshold Rule
            </h3>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
              <div className="md:col-span-2">
                <label className="block text-slate-400 mb-1">Rule Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. CPU Spike Alert"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Metric Category</label>
                <select
                  value={category}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="CPU">CPU Utilization (%)</option>
                  <option value="CORE">Logical Core (%)</option>
                  <option value="MEMORY">Memory Utilization (%)</option>
                  <option value="DISK_VOLUME">Disk Storage Volume (%)</option>
                  <option value="DISK_IO">Disk I/O Latency (ms)</option>
                  <option value="LATENCY">Application Response Time SLA (ms)</option>
                  <option value="ERROR_RATE">Application Error Rate SLA (%)</option>
                  <option value="DATABASE_POOL">Database Connection Pool (%)</option>
                  <option value="NETWORK">Network Bandwidth (KB/s)</option>
                  <option value="SERVICE">Windows Service</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Target Resource</label>
                <input
                  type="text"
                  value={targetResource}
                  onChange={(e) => setTargetResource(e.target.value)}
                  placeholder="ALL, Core 0, C:, etc."
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Operator</label>
                <select
                  value={operator}
                  onChange={(e) => setOperator(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value=">">&gt; (Greater Than)</option>
                  <option value=">=">&gt;= (Greater or Equal)</option>
                  <option value="<">&lt; (Less Than)</option>
                  <option value="<=">&lt;= (Less or Equal)</option>
                  <option value="==">== (Equals)</option>
                </select>
              </div>

              <div>
                <label className="block text-amber-400 font-medium mb-1">Warning Limit ({unit})</label>
                <input
                  type="number"
                  step="any"
                  value={warningThreshold}
                  onChange={(e) => setWarningThreshold(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-amber-500/40 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block text-rose-400 font-medium mb-1">Critical Limit ({unit})</label>
                <input
                  type="number"
                  step="any"
                  value={criticalThreshold}
                  onChange={(e) => setCriticalThreshold(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-rose-500/40 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-rose-400"
                  required
                />
              </div>

              <div>
                <label className="block text-red-500 font-medium mb-1">Severe Limit ({unit})</label>
                <input
                  type="number"
                  step="any"
                  value={severeThreshold ?? ''}
                  onChange={(e) => setSevereThreshold(e.target.value ? Number(e.target.value) : undefined)}
                  placeholder="Optional"
                  className="w-full bg-slate-900 border border-red-600/40 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Eval Duration (min)</label>
                <input
                  type="number"
                  min="1"
                  max="60"
                  value={durationMinutes}
                  onChange={(e) => setDurationMinutes(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div className="flex items-end gap-2 md:col-span-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-1.5 px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-medium rounded transition"
                >
                  {editingRuleId ? <Edit2 className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                  {submitting ? 'Compiling Rule...' : editingRuleId ? 'Update & Compile Alert Rule' : 'Save & Compile Alert Rule'}
                </button>
                {editingRuleId && (
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded transition"
                  >
                    Cancel Edit
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Active Thresholds Table */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
              Configured Active Thresholds ({thresholds.length})
            </h3>
            {loading ? (
              <div className="text-center py-8 text-slate-500 text-xs flex items-center justify-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" /> Loading configured rules...
              </div>
            ) : thresholds.length === 0 ? (
              <div className="text-center py-8 bg-slate-950/40 rounded border border-slate-800 text-slate-400 text-xs">
                No custom server thresholds configured yet. Using baseline system rules.
              </div>
            ) : (
              <div className="border border-slate-800 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-4">Rule Name</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3">Target</th>
                      <th className="py-2.5 px-3">Warning</th>
                      <th className="py-2.5 px-3">Critical</th>
                      <th className="py-2.5 px-3">Severe</th>
                      <th className="py-2.5 px-3">Duration</th>
                      <th className="py-2.5 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                    {thresholds.map((rule) => {
                      const isActive = activeRuleIds.has(rule.id);
                      return (
                        <tr key={rule.id} className="hover:bg-slate-800/40 transition">
                          <td className="py-2.5 px-4 font-medium text-white">
                            <div className="flex items-center gap-2">
                              <span>{rule.name}</span>
                              {isActive ? (
                                <span className="px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded">
                                  Active
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-wider bg-slate-800 text-slate-500 rounded">
                                  Superseded
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-2.5 px-3 text-cyan-400">{rule.metric_category}</td>
                          <td className="py-2.5 px-3 text-slate-400">{rule.target_resource || 'ALL'}</td>
                          <td className="py-2.5 px-3 text-amber-400 font-semibold">
                            {rule.operator} {rule.warning_threshold}{rule.unit}
                          </td>
                          <td className="py-2.5 px-3 text-rose-400 font-semibold">
                            {rule.operator} {rule.critical_threshold}{rule.unit}
                          </td>
                          <td className="py-2.5 px-3 text-red-500 font-semibold">
                            {rule.severe_threshold ? `${rule.operator} ${rule.severe_threshold}${rule.unit}` : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-slate-400">{rule.duration_minutes}m</td>
                          <td className="py-2.5 px-3 text-right">
                            <button
                              onClick={() => handleEdit(rule)}
                              className="p-1 text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 rounded transition mr-1"
                              title="Edit Rule"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDelete(rule.id)}
                              className="p-1 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded transition"
                              title="Delete Rule"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-950/40 text-xs text-slate-400">
          <span>Rules are synchronized in real-time with Prometheus alert rules and evaluated every 15s.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-medium transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
