import React, { useState } from 'react';
import { TestExecutionCorrelation } from '../../types/monitoring';
import { Bug, CheckCircle2, AlertTriangle, ShieldAlert, Sparkles, Plus, Trash2, ExternalLink } from 'lucide-react';

interface TestExecutionCorrelationSectionProps {
  correlations: TestExecutionCorrelation[];
  selectedEnvironmentName?: string;
  selectedEnvId?: string;
  environments?: Array<{ id: string; name: string }>;
  onRecordTestRun?: (payload: Partial<TestExecutionCorrelation>) => void;
  onDeleteTestRun?: (id: string) => void;
  onNavigateToIncidents?: (incidentId?: string) => void;
}

export const TestExecutionCorrelationSection: React.FC<TestExecutionCorrelationSectionProps> = ({
  correlations,
  selectedEnvironmentName,
  selectedEnvId,
  environments = [],
  onRecordTestRun,
  onDeleteTestRun,
  onNavigateToIncidents,
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'ENV_CAUSED' | 'FAILED' | 'PASSED'>('ALL');
  const [isSimulateModalOpen, setIsSimulateModalOpen] = useState(false);

  // Form State without hardcoded assumptions
  const [envId, setEnvId] = useState<string>(selectedEnvId || (environments[0]?.id ?? ''));
  const [suiteName, setSuiteName] = useState('');
  const [testPhase, setTestPhase] = useState('SIT');
  const [status, setStatus] = useState<'PASSED' | 'FAILED'>('FAILED');
  const [totalCount, setTotalCount] = useState<number>(50);
  const [failedCount, setFailedCount] = useState<number>(5);

  const filtered = correlations.filter((c) => {
    if (filterType === 'ENV_CAUSED') return c.is_environment_caused;
    if (filterType === 'FAILED') return c.status === 'FAILED';
    if (filterType === 'PASSED') return c.status === 'PASSED';
    return true;
  });

  const envCausedCount = correlations.filter((c) => c.is_environment_caused).length;

  const handleOpenModal = () => {
    setEnvId(selectedEnvId || (environments[0]?.id ?? ''));
    setSuiteName('');
    setStatus('FAILED');
    setTotalCount(50);
    setFailedCount(5);
    setIsSimulateModalOpen(true);
  };

  const handleSubmitSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!suiteName.trim()) return;

    const matchedEnv = environments.find((e) => e.id === envId);
    const finalEnvName = matchedEnv?.name || selectedEnvironmentName || 'Target Environment';
    const finalTotal = Math.max(1, totalCount);
    const finalFailed = status === 'PASSED' ? 0 : Math.min(finalTotal, Math.max(1, failedCount));
    const finalPassed = finalTotal - finalFailed;

    if (onRecordTestRun) {
      onRecordTestRun({
        test_run_id: `TR-RUN-${Math.floor(Date.now() / 1000) % 100000}`,
        test_suite_name: suiteName.trim(),
        test_phase: testPhase,
        environment_id: envId || selectedEnvId || 'env-default',
        environment_name: finalEnvName,
        status: status,
        total_tests: finalTotal,
        passed_tests: finalPassed,
        failed_tests: finalFailed,
        started_at: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
        completed_at: new Date().toISOString(),
      });
    }
    setIsSimulateModalOpen(false);
  };

  return (
    <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Bug className="w-4 h-4 text-orange-400" /> TEST EXECUTION & ENVIRONMENT CORRELATION ({correlations.length})
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Integrates TEM test execution timelines with environment telemetry to determine if test failures were caused by environment defects or functional code bugs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[#161f2e] border border-slate-700 rounded-lg p-0.5">
            {(['ALL', 'ENV_CAUSED', 'FAILED', 'PASSED'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setFilterType(st)}
                className={`px-2.5 py-1 rounded text-[10px] font-bold transition-colors ${
                  filterType === st ? 'bg-orange-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                {st === 'ENV_CAUSED' ? `ENV CAUSED (${envCausedCount})` : st}
              </button>
            ))}
          </div>

          <button
            onClick={handleOpenModal}
            className="px-3 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center gap-1 shadow-md shadow-orange-950/40"
          >
            <Plus className="w-3.5 h-3.5" /> Correlate Test Run
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-slate-800 rounded-xl space-y-3">
          <CheckCircle2 className="w-9 h-9 text-slate-600 mx-auto" />
          <p className="text-white font-bold text-sm">No Correlated Test Executions</p>
          <p className="text-slate-400 text-[11px] max-w-md mx-auto">
            Correlate automated test runs with live environment telemetry to diagnose whether test failures were caused by infrastructure defects or functional code bugs.
          </p>
          <button
            onClick={handleOpenModal}
            className="mt-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold text-xs rounded-lg inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5 text-orange-400" /> Correlate Test Run
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => {
            const isFailed = item.status === 'FAILED';
            const isEnvCaused = item.is_environment_caused;
            const total = Math.max(1, item.total_tests || 1);
            const passedPct = Math.round(((item.passed_tests || 0) / total) * 100);
            const failedPct = Math.round(((item.failed_tests || 0) / total) * 100);

            return (
              <div
                key={item.id}
                className={`p-4 rounded-xl border space-y-3 transition-all ${
                  isEnvCaused
                    ? 'bg-[#1e100a]/80 border-orange-800 shadow-md shadow-orange-950/20'
                    : isFailed
                    ? 'bg-rose-950/20 border-rose-900/60'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-black/60 border border-slate-700 text-slate-300">
                        {item.test_run_id}
                      </span>
                      <span className="text-xs font-extrabold text-white">{item.test_suite_name}</span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-800 text-slate-300 uppercase">
                        {item.test_phase}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-[10px] text-slate-400">
                      <span>Environment: <strong className="text-orange-400">{item.environment_name}</strong></span>
                      <span>Run Time: {item.started_at?.replace('T', ' ').substring(0, 16)}</span>
                      <span>
                        Tests: <strong className="text-white">{item.passed_tests}</strong> passed /{' '}
                        <strong className={item.failed_tests > 0 ? 'text-rose-400' : 'text-slate-400'}>
                          {item.failed_tests}
                        </strong> failed
                      </span>
                      <span>
                        Health at Execution:{' '}
                        <strong className={item.environment_health_at_run >= 80 ? 'text-emerald-400' : 'text-amber-400'}>
                          {item.environment_health_at_run}%
                        </strong>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`px-2.5 py-1 rounded text-[10px] font-bold ${
                        item.status === 'PASSED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {item.status}
                    </span>

                    {isEnvCaused ? (
                      <span className="px-2.5 py-1 rounded text-[10px] font-extrabold bg-orange-950 text-orange-300 border border-orange-700 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-orange-400" /> ENVIRONMENT DEFECT
                      </span>
                    ) : isFailed ? (
                      <span className="px-2.5 py-1 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                        FUNCTIONAL DEFECT
                      </span>
                    ) : null}

                    {onDeleteTestRun && (
                      <button
                        onClick={() => onDeleteTestRun(item.id)}
                        title="Delete test correlation record"
                        className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors ml-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Visual Pass / Fail Progress Bar */}
                <div className="space-y-1">
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden flex">
                    <div
                      style={{ width: `${passedPct}%` }}
                      className="bg-emerald-500 h-full transition-all duration-500"
                      title={`${passedPct}% Passed`}
                    />
                    <div
                      style={{ width: `${failedPct}%` }}
                      className="bg-rose-500 h-full transition-all duration-500"
                      title={`${failedPct}% Failed`}
                    />
                  </div>
                </div>

                {/* Root Cause Diagnostic & Anomalies */}
                {item.failure_root_cause && (
                  <div
                    className={`p-3 rounded-lg border text-[11px] space-y-2 ${
                      isEnvCaused
                        ? 'bg-orange-950/30 border-orange-800/80 text-orange-200'
                        : 'bg-black/40 border-slate-800 text-slate-300'
                    }`}
                  >
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-orange-400" /> AUTOMATED TEST FAILURE ROOT CAUSE:
                    </span>
                    <p className="leading-relaxed">{item.failure_root_cause}</p>

                    {/* Linked Incident Badge */}
                    {item.linked_incident_id && (
                      <div className="pt-1">
                        <button
                          type="button"
                          onClick={() => onNavigateToIncidents?.(item.linked_incident_id)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-rose-950/80 border border-rose-700 text-rose-300 hover:bg-rose-900 transition-colors text-[10px] font-bold"
                        >
                          <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                          <span>Linked Correlated Incident: <strong>{item.linked_incident_id}</strong></span>
                          <ExternalLink className="w-3 h-3 ml-0.5 opacity-80" />
                        </button>
                      </div>
                    )}

                    {item.correlated_anomalies && item.correlated_anomalies.length > 0 && (
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <span className="text-[10px] text-slate-400 font-bold uppercase">Overlapping Telemetry Anomalies:</span>
                        {item.correlated_anomalies.map((anom, idx) => (
                          <span key={idx} className="px-2 py-0.5 rounded bg-black/60 border border-orange-800/60 text-[10px] font-mono text-orange-300">
                            {anom.metric}: <strong>{anom.value}</strong>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Correlate Test Run Modal */}
      {isSimulateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-[#0f1724] border border-slate-700 rounded-xl p-5 max-w-md w-full space-y-4 shadow-2xl font-mono text-xs">
            <div className="border-b border-slate-800 pb-2">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Bug className="w-4 h-4 text-orange-400" /> Correlate Test Run with Live Telemetry
              </h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Evaluates test execution outcomes against concurrent CPU, memory, database connection pool, latency, and active incidents.
              </p>
            </div>

            <form onSubmit={handleSubmitSimulation} className="space-y-3">
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Target Environment</label>
                <select
                  value={envId}
                  onChange={(e) => setEnvId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-white focus:outline-none focus:border-orange-500"
                  required
                >
                  {environments.length > 0 ? (
                    environments.map((env) => (
                      <option key={env.id} value={env.id}>
                        {env.name}
                      </option>
                    ))
                  ) : (
                    <option value={selectedEnvId || 'default'}>{selectedEnvironmentName || 'Default Environment'}</option>
                  )}
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Test Suite Name</label>
                <input
                  type="text"
                  value={suiteName}
                  onChange={(e) => setSuiteName(e.target.value)}
                  placeholder="e.g. Core Banking SIT Regression Suite"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-white placeholder-slate-600 focus:outline-none focus:border-orange-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Test Phase</label>
                  <select
                    value={testPhase}
                    onChange={(e) => setTestPhase(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500"
                  >
                    <option value="SIT">SIT</option>
                    <option value="UAT">UAT</option>
                    <option value="PERF">PERF</option>
                    <option value="REGRESSION">REGRESSION</option>
                    <option value="SMOKE">SMOKE</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Execution Outcome</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500"
                  >
                    <option value="FAILED">FAILED</option>
                    <option value="PASSED">PASSED</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Total Tests</label>
                  <input
                    type="number"
                    min={1}
                    value={totalCount}
                    onChange={(e) => setTotalCount(parseInt(e.target.value) || 1)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-orange-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Failed Tests</label>
                  <input
                    type="number"
                    min={0}
                    max={totalCount}
                    value={status === 'PASSED' ? 0 : failedCount}
                    onChange={(e) => setFailedCount(parseInt(e.target.value) || 0)}
                    disabled={status === 'PASSED'}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white disabled:opacity-40 focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSimulateModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!suiteName.trim()}
                  className="px-4 py-1.5 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-bold rounded shadow-md shadow-orange-950/40"
                >
                  Analyze & Correlate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
