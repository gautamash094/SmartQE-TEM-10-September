import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  X,
  Activity,
  RotateCcw,
  Clock,
  Cpu,
  Layers,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Copy,
  Check,
  Terminal,
  Radio,
  RefreshCw,
  Server,
  Code2,
  HardDrive,
  Database,
  Wifi,
  Globe,
  Plus,
  Sparkles,
  Settings,
  Trash2,
  ChevronDown,
  Info
} from 'lucide-react';

export type ServiceRuntime = 'PYTHON' | 'JAVA' | 'NODEJS' | 'GO' | 'DOTNET' | 'GENERIC';

export interface DiagnosticRoute {
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'HEAD';
  type: string;
  desc: string;
  source: 'BASELINE' | 'DISCOVERED' | 'CONFIGURED' | 'USER_CUSTOM';
}

interface ServiceDiagnosticModalProps {
  service: any;
  isOpen: boolean;
  onClose: () => void;
  onRestartService?: (serviceName: string) => Promise<void>;
}

// Enterprise Standard Baseline Route Catalog per Runtime
const BASELINE_ROUTES: Record<ServiceRuntime, DiagnosticRoute[]> = {
  PYTHON: [
    {
      path: '/actuator/health',
      method: 'GET',
      type: 'Actuator Health Alias',
      desc: 'Spring Boot compatible JSON health checks & system status',
      source: 'BASELINE'
    },
    {
      path: '/actuator/prometheus',
      method: 'GET',
      type: 'Prometheus Actuator Alias',
      desc: 'Spring Boot compatible Prometheus metrics stream',
      source: 'BASELINE'
    },
    {
      path: '/api/v1/health',
      method: 'GET',
      type: 'Native REST Health Probe',
      desc: 'Primary FastAPI operational status',
      source: 'BASELINE'
    },
    {
      path: '/api/v1/ready',
      method: 'GET',
      type: 'Database Readiness Probe',
      desc: 'Live PostgreSQL/SQLite connection verification',
      source: 'BASELINE'
    },
    {
      path: '/metrics',
      method: 'GET',
      type: 'Native Prometheus Target',
      desc: 'FastAPI / Python psutil metric exposition',
      source: 'BASELINE'
    }
  ],
  JAVA: [
    {
      path: '/actuator/health',
      method: 'GET',
      type: 'Liveness Probe',
      desc: 'Spring Boot component health indicators',
      source: 'BASELINE'
    },
    {
      path: '/actuator/prometheus',
      method: 'GET',
      type: 'Metrics Exposition',
      desc: 'Micrometer Prometheus scrape endpoint',
      source: 'BASELINE'
    },
    {
      path: '/actuator/info',
      method: 'GET',
      type: 'Service Information',
      desc: 'Spring Boot build & git information',
      source: 'BASELINE'
    },
    {
      path: '/actuator/metrics',
      method: 'GET',
      type: 'Actuator Metric Keys',
      desc: 'Comprehensive list of available JVM metric meters',
      source: 'BASELINE'
    }
  ],
  NODEJS: [
    {
      path: '/health',
      method: 'GET',
      type: 'Service Health Probe',
      desc: 'Express / NestJS operational liveness indicator',
      source: 'BASELINE'
    },
    {
      path: '/healthz',
      method: 'GET',
      type: 'Kubernetes Liveness',
      desc: 'K8s standard pod liveness probe',
      source: 'BASELINE'
    },
    {
      path: '/ready',
      method: 'GET',
      type: 'Readiness Probe',
      desc: 'Dependency & database connection status',
      source: 'BASELINE'
    },
    {
      path: '/metrics',
      method: 'GET',
      type: 'Prometheus Client',
      desc: 'prom-client metrics exposition endpoint',
      source: 'BASELINE'
    }
  ],
  GO: [
    {
      path: '/healthz',
      method: 'GET',
      type: 'K8s Liveness Probe',
      desc: 'Go runtime & goroutine liveness indicator',
      source: 'BASELINE'
    },
    {
      path: '/readyz',
      method: 'GET',
      type: 'K8s Readiness Probe',
      desc: 'Subsystem & database connection verification',
      source: 'BASELINE'
    },
    {
      path: '/metrics',
      method: 'GET',
      type: 'Prometheus Handler',
      desc: 'Standard Go prometheus HTTP handler',
      source: 'BASELINE'
    }
  ],
  DOTNET: [
    {
      path: '/health',
      method: 'GET',
      type: 'ASP.NET Health Check',
      desc: 'Microsoft.Extensions.Diagnostics.HealthChecks endpoint',
      source: 'BASELINE'
    },
    {
      path: '/health/live',
      method: 'GET',
      type: 'Liveness Probe',
      desc: 'Minimal application process liveness probe',
      source: 'BASELINE'
    },
    {
      path: '/health/ready',
      method: 'GET',
      type: 'Readiness Probe',
      desc: 'Database & dependency connection validation',
      source: 'BASELINE'
    },
    {
      path: '/metrics',
      method: 'GET',
      type: 'Prometheus-net',
      desc: 'prometheus-net metric scrape target',
      source: 'BASELINE'
    }
  ],
  GENERIC: [
    {
      path: '/health',
      method: 'GET',
      type: 'Liveness Probe',
      desc: 'Standard service operational status',
      source: 'BASELINE'
    },
    {
      path: '/api/v1/health',
      method: 'GET',
      type: 'REST Health Check',
      desc: 'API health status verification',
      source: 'BASELINE'
    },
    {
      path: '/status',
      method: 'GET',
      type: 'Service Status',
      desc: 'HTTP service status probe',
      source: 'BASELINE'
    },
    {
      path: '/metrics',
      method: 'GET',
      type: 'Prometheus Metrics',
      desc: 'Metrics exposition target',
      source: 'BASELINE'
    }
  ]
};

export const ServiceDiagnosticModal: React.FC<ServiceDiagnosticModalProps> = ({
  service,
  isOpen,
  onClose,
  onRestartService
}) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [isProbing, setIsProbing] = useState(false);
  const [probingPath, setProbingPath] = useState<string | null>(null);
  const [isRestarting, setIsRestarting] = useState(false);
  const [showDiagnosticDetails, setShowDiagnosticDetails] = useState(false);

  // Dynamic Target Host & Port Resolution
  const initialHost = useMemo(() => {
    if (service?.hostIp) return service.hostIp;
    if (service?.host) return service.host;
    if (service?.ip) return service.ip;
    if (service?.serverIp) return service.serverIp;
    if (service?.server_ip) return service.server_ip;
    if (service?.endpoint_url) {
      try {
        const u = new URL(service.endpoint_url);
        if (u.hostname) return u.hostname;
      } catch {}
    }
    return '127.0.0.1';
  }, [service]);

  const initialPort = useMemo(() => {
    if (service?.servicePort) return String(service.servicePort);
    if (service?.port) return String(service.port);
    if (service?.endpoint_url) {
      try {
        const u = new URL(service.endpoint_url);
        if (u.port) return u.port;
      } catch {}
    }
    return '8000';
  }, [service]);

  const [targetHost, setTargetHost] = useState<string>(initialHost);
  const [targetPort, setTargetPort] = useState<string>(initialPort);
  const [isEditingTarget, setIsEditingTarget] = useState(false);

  // Multi-Framework Runtime Detection
  const detectedRuntime = useMemo<ServiceRuntime>(() => {
    const rt = String(service?.runtime || service?.language || service?.framework || '').toUpperCase();
    if (rt.includes('PYTHON') || rt.includes('FASTAPI') || rt.includes('FLASK') || rt.includes('DJANGO')) return 'PYTHON';
    if (rt.includes('JAVA') || rt.includes('SPRING') || rt.includes('QUARKUS') || rt.includes('MICRONAUT')) return 'JAVA';
    if (rt.includes('NODE') || rt.includes('EXPRESS') || rt.includes('NEST') || rt.includes('TYPESCRIPT') || rt.includes('JAVASCRIPT')) return 'NODEJS';
    if (rt.includes('GO') || rt.includes('GOLANG') || rt.includes('GIN')) return 'GO';
    if (rt.includes('DOTNET') || rt.includes('.NET') || rt.includes('CSHARP') || rt.includes('ASP')) return 'DOTNET';

    const name = String(service?.serviceName || service?.name || '').toLowerCase();
    if (name.includes('spring') || name.includes('jvm')) return 'JAVA';
    if (name.includes('node') || name.includes('express') || name.includes('nest')) return 'NODEJS';
    if (name.includes('go') || name.includes('gin')) return 'GO';
    if (name.includes('dotnet') || name.includes('asp')) return 'DOTNET';
    if (name.includes('backend') || name.includes('python') || service?.isPython || String(targetPort) === '8000') return 'PYTHON';
    if (String(targetPort) === '8080' || String(targetPort) === '8443') return 'JAVA';
    if (String(targetPort) === '3000' || String(targetPort) === '4000') return 'NODEJS';

    return 'PYTHON';
  }, [service, targetPort]);

  const frameworkLabel = useMemo(() => {
    switch (detectedRuntime) {
      case 'PYTHON':
        return 'Python / FastAPI (Uvicorn APM)';
      case 'JAVA':
        return 'Spring Boot Actuator / JMX';
      case 'NODEJS':
        return 'Node.js / Express (Prometheus Client)';
      case 'GO':
        return 'Go / Prometheus Exporter';
      case 'DOTNET':
        return '.NET Core / ASP.NET Health';
      default:
        return 'HTTP Application Service';
    }
  }, [detectedRuntime]);

  const isPython = detectedRuntime === 'PYTHON';

  // Dynamic Route Discovery & Custom Add States
  const [discoveredRoutes, setDiscoveredRoutes] = useState<DiagnosticRoute[]>([]);
  const [isDiscovering, setIsDiscovering] = useState(false);
  const [discoveryStatus, setDiscoveryStatus] = useState<string | null>(null);

  const [userCustomRoutes, setUserCustomRoutes] = useState<DiagnosticRoute[]>([]);
  const [isAddingCustomRoute, setIsAddingCustomRoute] = useState(false);
  const [customPath, setCustomPath] = useState('');
  const [customMethod, setCustomMethod] = useState<'GET' | 'POST' | 'HEAD'>('GET');
  const [customDesc, setCustomDesc] = useState('');

  // Probe Result State
  const [probeResult, setProbeResult] = useState<{
    status: 'HEALTHY' | 'DEGRADED' | 'DOWN';
    httpStatus: number;
    latencyMs: number;
    timestamp: string;
    endpoint: string;
    rawPayload: any;
    checks: { name: string; status: 'UP' | 'DOWN'; details?: string }[];
  } | null>(null);

  const [routeProbeResults, setRouteProbeResults] = useState<{
    [path: string]: { status: number; latencyMs: number; ok: boolean };
  }>({});

  // Reset states whenever service changes
  useEffect(() => {
    setTargetHost(initialHost);
    setTargetPort(initialPort);
    setIsEditingTarget(false);
    setProbeResult(null);
    setRouteProbeResults({});
    setDiscoveredRoutes([]);
    setDiscoveryStatus(null);
    setShowDiagnosticDetails(false);
    setIsProbing(false);
    setProbingPath(null);
    setIsAddingCustomRoute(false);
  }, [service?.id, service?.serviceName, initialHost, initialPort, isOpen]);

  const handleClose = () => {
    setProbeResult(null);
    setRouteProbeResults({});
    setShowDiagnosticDetails(false);
    setIsProbing(false);
    setProbingPath(null);
    onClose();
  };

  if (!isOpen || !service) return null;

  const port = targetPort;
  const version = service.version || 'v1.0';
  const serviceName = service.serviceName || service.name || 'Application Service';

  // Configured Endpoints from Service Profile in Registry / CMDB
  const configuredRoutes = useMemo<DiagnosticRoute[]>(() => {
    const list: DiagnosticRoute[] = [];
    if (service?.healthEndpoint && !service.healthEndpoint.startsWith('/actuator/health')) {
      list.push({
        path: service.healthEndpoint.startsWith('/') ? service.healthEndpoint : `/${service.healthEndpoint}`,
        method: 'GET',
        type: 'Registry Health Path',
        desc: 'Service health check endpoint configured in TEM Inventory',
        source: 'CONFIGURED'
      });
    }
    if (Array.isArray(service?.endpoints)) {
      service.endpoints.forEach((ep: any) => {
        const p = typeof ep === 'string' ? ep : ep.path || ep.url;
        if (p) {
          list.push({
            path: p.startsWith('/') ? p : `/${p}`,
            method: (ep.method || 'GET').toUpperCase(),
            type: ep.type || 'Registry Endpoint',
            desc: ep.description || 'Configured service endpoint in TEM Registry',
            source: 'CONFIGURED'
          });
        }
      });
    }
    return list;
  }, [service]);

  // Combined Active Routes (Prioritized: User Custom -> Configured -> Discovered -> Baseline)
  const activeRoutes = useMemo<DiagnosticRoute[]>(() => {
    const base = BASELINE_ROUTES[detectedRuntime] || BASELINE_ROUTES.GENERIC;
    const map = new Map<string, DiagnosticRoute>();

    // 1. User custom routes (Highest priority)
    userCustomRoutes.forEach((r) => map.set(`${r.method}:${r.path}`, r));

    // 2. Configured routes from database / profile
    configuredRoutes.forEach((r) => {
      const k = `${r.method}:${r.path}`;
      if (!map.has(k)) map.set(k, r);
    });

    // 3. Discovered routes from live OpenAPI or Actuator
    discoveredRoutes.forEach((r) => {
      const k = `${r.method}:${r.path}`;
      if (!map.has(k)) map.set(k, r);
    });

    // 4. Baseline routes for the runtime
    base.forEach((r) => {
      const k = `${r.method}:${r.path}`;
      if (!map.has(k)) map.set(k, r);
    });

    return Array.from(map.values());
  }, [detectedRuntime, discoveredRoutes, configuredRoutes, userCustomRoutes]);

  // Dynamic Primary Probe Path
  const primaryProbePath = useMemo(() => {
    if (service?.healthEndpoint) return service.healthEndpoint.startsWith('/') ? service.healthEndpoint : `/${service.healthEndpoint}`;
    if (configuredRoutes.length > 0) return configuredRoutes[0].path;
    if (detectedRuntime === 'PYTHON' || detectedRuntime === 'JAVA') return '/actuator/health';
    if (detectedRuntime === 'NODEJS' || detectedRuntime === 'DOTNET') return '/health';
    if (detectedRuntime === 'GO') return '/healthz';
    return '/health';
  }, [service, configuredRoutes, detectedRuntime]);

  const primaryProbeUrl = `http://${targetHost}:${targetPort}${primaryProbePath}`;

  // Framework-specific cURL Probes (Dynamically updated with host, port, and top active routes)
  const curlCommands = useMemo(() => {
    return activeRoutes.slice(0, 6).map((r, i) => ({
      id: `curl-${r.method.toLowerCase()}-${i}`,
      label: `${r.type} (${r.method})`,
      cmd: `curl -s -X ${r.method} "http://${targetHost}:${targetPort}${r.path}"`
    }));
  }, [activeRoutes, targetHost, targetPort]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2500);
  };

  // Enterprise HTTP Probe Execution:
  // Leverages backend proxy (/api/v1/monitoring/probe) first to cleanly bypass CORS, mixed content, and private VPC firewall boundaries
  const probeTarget = async (targetUrl: string, method: string = 'GET') => {
    const t0 = performance.now();
    try {
      const proxyUrl = `/api/v1/monitoring/probe?url=${encodeURIComponent(targetUrl)}`;
      const proxyRes = await fetch(proxyUrl, { signal: AbortSignal.timeout(5000) });
      const json = await proxyRes.json();
      if (json && json.data) {
        return {
          ok: Boolean(json.data.is_up),
          status: json.data.http_status || (json.data.is_up ? 200 : 0),
          latencyMs: Math.round(json.data.latency_ms || performance.now() - t0),
          payload: json.data.payload,
          error: json.data.error
        };
      }
      throw new Error(json.message || 'Probe proxy response invalid');
    } catch (proxyErr: any) {
      // Fallback: Direct browser fetch if running in unproxied sandbox
      try {
        const res = await fetch(targetUrl, { method, signal: AbortSignal.timeout(3500) });
        const latencyMs = Math.round(performance.now() - t0);
        let payload: any = null;
        try {
          payload = await res.json();
        } catch {
          const text = await res.text();
          payload = { raw: text.slice(0, 500) };
        }
        return {
          ok: res.ok,
          status: res.status,
          latencyMs,
          payload,
          error: null
        };
      } catch (directErr: any) {
        return {
          ok: false,
          status: 0,
          latencyMs: Math.round(performance.now() - t0),
          payload: null,
          error: directErr.message || proxyErr.message || 'Target service unreachable'
        };
      }
    }
  };

  // Live Auto-Discovery of Routes via OpenAPI / Swagger or Actuator Hypermedia
  const handleAutoDiscoverRoutes = async () => {
    setIsDiscovering(true);
    setDiscoveryStatus('Querying OpenAPI and Actuator hypermedia indices...');
    const found: DiagnosticRoute[] = [];

    try {
      // 1. Probe OpenAPI / Swagger spec (FastAPI, NestJS, Go, .NET)
      const openApiUrl = `http://${targetHost}:${targetPort}/openapi.json`;
      const openApiRes = await probeTarget(openApiUrl);

      if (openApiRes.ok && openApiRes.payload && openApiRes.payload.paths) {
        const pathsObj = openApiRes.payload.paths;
        Object.keys(pathsObj).forEach((p) => {
          const methods = Object.keys(pathsObj[p]);
          const m = (methods[0] || 'get').toUpperCase() as any;
          const details = pathsObj[p][methods[0]];
          const summary = details?.summary || details?.description || 'Auto-discovered OpenAPI route';
          const tags = (details?.tags || []).join(', ');
          const isDiagnostic = /health|ready|live|metric|status|info|probe/i.test(p) || /health|metric/i.test(tags);

          found.push({
            path: p,
            method: m,
            type: isDiagnostic ? 'Discovered Diagnostic' : 'Discovered API',
            desc: summary,
            source: 'DISCOVERED'
          });
        });
      }

      // 2. Probe Spring Boot Actuator Hypermedia (_links)
      const actuatorUrl = `http://${targetHost}:${targetPort}/actuator`;
      const actuatorRes = await probeTarget(actuatorUrl);

      if (actuatorRes.ok && actuatorRes.payload && actuatorRes.payload._links) {
        const links = actuatorRes.payload._links;
        Object.entries(links).forEach(([rel, linkObj]: [string, any]) => {
          if (rel === 'self') return;
          let p = linkObj.href || '';
          try {
            const u = new URL(p);
            p = u.pathname;
          } catch {}
          if (!p.startsWith('/')) p = `/actuator/${rel}`;

          if (!found.some((r) => r.path === p)) {
            found.push({
              path: p,
              method: 'GET',
              type: 'Spring Actuator',
              desc: `Active Spring Boot '${rel}' actuator hypermedia endpoint`,
              source: 'DISCOVERED'
            });
          }
        });
      }

      if (found.length > 0) {
        setDiscoveredRoutes(found);
        setDiscoveryStatus(`Discovered ${found.length} live routes from service specifications.`);
      } else {
        setDiscoveryStatus('No dynamic OpenAPI or Actuator routes discovered. Using baseline probes.');
      }
    } catch (err: any) {
      setDiscoveryStatus(`Discovery completed with baseline routes (${err.message || 'Host not responding'}).`);
    } finally {
      setIsDiscovering(false);
      setTimeout(() => setDiscoveryStatus(null), 6000);
    }
  };

  // Primary Live Probe Action
  const handleRunProbe = async (endpointPath: string = primaryProbePath, method: string = 'GET') => {
    setIsProbing(true);
    setProbingPath(endpointPath);
    setProbeResult(null);

    const fullUrl = `http://${targetHost}:${targetPort}${endpointPath}`;
    const result = await probeTarget(fullUrl, method);

    const checksList: { name: string; status: 'UP' | 'DOWN'; details?: string }[] = [];

    if (result.payload && result.payload.components) {
      // Live Actuator component hierarchy
      Object.entries(result.payload.components).forEach(([compName, compVal]: [string, any]) => {
        const compStatus = (compVal.status || 'UP').toUpperCase() === 'UP' ? 'UP' : 'DOWN';
        let detailsStr = '';
        if (compVal.details) {
          if (typeof compVal.details === 'object') {
            detailsStr = Object.entries(compVal.details)
              .map(([k, v]) => `${k}: ${v}`)
              .join(', ');
          } else {
            detailsStr = String(compVal.details);
          }
        }
        checksList.push({
          name: compName,
          status: compStatus,
          details: detailsStr || (compStatus === 'UP' ? 'OK' : 'Error')
        });
      });
    } else if (result.payload && result.payload.data) {
      // Native TEM standard payload
      Object.entries(result.payload.data).forEach(([k, v]) => {
        checksList.push({
          name: k,
          status: 'UP',
          details: typeof v === 'object' ? JSON.stringify(v) : String(v)
        });
      });
    } else if (result.ok) {
      checksList.push({
        name: 'http_liveness',
        status: 'UP',
        details: `HTTP ${result.status} OK`
      });
    } else {
      const isConnectionRefused =
        !result.status ||
        String(result.error || '').toLowerCase().includes('failed to fetch') ||
        String(result.error || '').includes('refused');
      checksList.push({
        name: 'service_connectivity',
        status: 'DOWN',
        details: isConnectionRefused
          ? `Host ${targetHost}:${targetPort} is closed (Connection Refused). No application process is listening on this port.`
          : (result.error || `HTTP ${result.status} Error`)
      });
    }

    setProbeResult({
      status: result.ok ? 'HEALTHY' : (result.status === 0 ? 'DOWN' : 'DEGRADED'),
      httpStatus: result.status,
      latencyMs: result.latencyMs,
      timestamp: new Date().toLocaleTimeString(),
      endpoint: fullUrl,
      rawPayload: result.payload,
      checks: checksList
    });

    setRouteProbeResults((prev) => ({
      ...prev,
      [endpointPath]: {
        status: result.status,
        latencyMs: result.latencyMs,
        ok: result.ok
      }
    }));

    setIsProbing(false);
    setProbingPath(null);
  };

  // Probe a single route on demand
  const handleProbeRoute = async (routePath: string, method: string = 'GET') => {
    setProbingPath(routePath);
    const fullUrl = `http://${targetHost}:${targetPort}${routePath}`;
    const result = await probeTarget(fullUrl, method);
    setRouteProbeResults((prev) => ({
      ...prev,
      [routePath]: {
        status: result.status,
        latencyMs: result.latencyMs,
        ok: result.ok
      }
    }));
    setProbingPath(null);
  };

  // Add User Custom Route on the fly
  const handleAddCustomRoute = () => {
    if (!customPath.trim()) return;
    const p = customPath.trim().startsWith('/') ? customPath.trim() : `/${customPath.trim()}`;
    const newRoute: DiagnosticRoute = {
      path: p,
      method: customMethod,
      type: 'Custom Probe',
      desc: customDesc.trim() || 'On-demand custom probe route',
      source: 'USER_CUSTOM'
    };
    setUserCustomRoutes((prev) => [newRoute, ...prev.filter((r) => r.path !== p)]);
    setCustomPath('');
    setCustomDesc('');
    setIsAddingCustomRoute(false);
    handleProbeRoute(p, customMethod);
  };

  const handleRemoveCustomRoute = (path: string) => {
    setUserCustomRoutes((prev) => prev.filter((r) => r.path !== path));
  };

  const handleRestart = async () => {
    if (onRestartService) {
      setIsRestarting(true);
      try {
        await onRestartService(serviceName);
        await handleRunProbe();
      } finally {
        setIsRestarting(false);
      }
    }
  };

  // Dynamic Metrics & Threshold Calculations
  const cpuWarningThreshold = service.cpuThreshold || 80;
  const errorWarningThreshold = service.errorThreshold || 2.0;
  const isWarning = service.testReadinessImpact === 'READY_WITH_WARNINGS' || (service.errorRate5xx || 0) > errorWarningThreshold;

  const maxMemoryScaleMb = useMemo(() => {
    if (service.totalRamMb && service.totalRamMb > 0) return service.totalRamMb;
    if (service.ramGb && service.ramGb > 0) return service.ramGb * 1024;
    return Math.max(1024, Math.round((service.processMemoryMb || 100) * 1.5));
  }, [service]);

  const maxThreadsScale = useMemo(() => {
    if (service.maxThreads && service.maxThreads > 0) return service.maxThreads;
    return Math.max(50, Math.round((service.activeThreads || 10) * 1.5));
  }, [service]);

  const maxFdsScale = useMemo(() => {
    if (service.maxOpenFds && service.maxOpenFds > 0) return service.maxOpenFds;
    return Math.max(500, Math.round((service.openFds || 50) * 1.5));
  }, [service]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 font-mono">
      <div className="bg-[#0b111e] border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-[#0d1527]">
          <div className="flex items-center gap-3">
            <div
              className={`p-2.5 rounded-xl border ${
                isWarning
                  ? 'bg-amber-950/80 border-amber-800 text-amber-400'
                  : 'bg-indigo-950/80 border-indigo-800 text-indigo-400'
              }`}
            >
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-base font-extrabold text-white tracking-wide">{serviceName}</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  {version}
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    isWarning
                      ? 'bg-amber-950 text-amber-300 border-amber-800'
                      : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  }`}
                >
                  {service.testReadinessImpact || 'READY'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 flex flex-wrap items-center gap-1.5">
                <span>Enterprise Diagnostic Console · Runtime:</span>
                <strong className={isPython ? 'text-cyan-400' : 'text-indigo-400'}>
                  {frameworkLabel}
                </strong>
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Dynamic Target Host Override Bar */}
        <div className="bg-[#0c1424] px-5 py-2.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400 text-[11px] font-bold uppercase">PROBE TARGET:</span>
            {isEditingTarget ? (
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={targetHost}
                  onChange={(e) => setTargetHost(e.target.value)}
                  className="bg-slate-950 border border-slate-700 rounded px-2 py-0.5 text-white font-mono text-xs w-36 focus:outline-none focus:border-cyan-500"
                  placeholder="127.0.0.1 or host.domain"
                />
                <span className="text-slate-500">:</span>
                <input
                  type="text"
                  value={targetPort}
                  onChange={(e) => setTargetPort(e.target.value)}
                  className="bg-slate-950 border border-slate-700 rounded px-2 py-0.5 text-white font-mono text-xs w-16 focus:outline-none focus:border-cyan-500"
                  placeholder="8000"
                />
                <button
                  onClick={() => setIsEditingTarget(false)}
                  className="px-2 py-0.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[10px]"
                >
                  Save
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="font-mono text-cyan-300 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  http://{targetHost}:{targetPort}
                </span>
                <button
                  onClick={() => setIsEditingTarget(true)}
                  className="text-[10px] text-cyan-400 hover:text-cyan-300 underline font-bold"
                >
                  Change Host/Port
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleAutoDiscoverRoutes}
              disabled={isDiscovering}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-[10px] font-bold flex items-center gap-1.5 transition-all disabled:opacity-50"
              title="Automatically discover routes from /openapi.json or Spring Actuator /actuator"
            >
              <Sparkles className={`w-3.5 h-3.5 text-amber-400 ${isDiscovering ? 'animate-spin' : ''}`} />
              <span>{isDiscovering ? 'Discovering Spec...' : 'Auto-Discover Routes'}</span>
            </button>
          </div>
        </div>

        {/* Discovery Notification Toast */}
        {discoveryStatus && (
          <div className="bg-amber-950/30 border-b border-amber-900/60 px-5 py-2 text-[11px] text-amber-300 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
              <span>{discoveryStatus}</span>
            </span>
            <button onClick={() => setDiscoveryStatus(null)} className="text-amber-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 space-y-6 text-xs">
          {/* Action & Quick Probe Bar */}
          <div className="bg-gradient-to-r from-slate-900 via-[#0e1628] to-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-indigo-950/50 border border-indigo-800 text-indigo-400">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
                  Primary Health Probe Endpoint
                </span>
                <span className="text-xs font-bold text-white font-mono">
                  GET {primaryProbeUrl}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => handleRunProbe(primaryProbePath)}
                disabled={isProbing}
                className="flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/20 transition-all disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isProbing ? 'animate-spin' : ''}`} />
                <span>{isProbing ? 'Executing Live Probe...' : 'Ping / Probe Endpoint'}</span>
              </button>

              <button
                onClick={handleRestart}
                disabled={isRestarting}
                className="flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/70 border border-slate-700 hover:border-rose-800 text-slate-200 hover:text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all disabled:opacity-50"
                title="Trigger Autonomous Service Restart via Auto-Heal"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isRestarting ? 'animate-spin text-rose-400' : ''}`} />
                <span>{isRestarting ? 'Restarting...' : 'Restart Service'}</span>
              </button>
            </div>
          </div>

          {/* Real-Time Live Probe Result Banner */}
          {probeResult && (
            <div
              className={`p-4 rounded-xl border animate-in fade-in duration-200 space-y-3 ${
                probeResult.status === 'HEALTHY'
                  ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                  : probeResult.status === 'DEGRADED'
                  ? 'bg-amber-950/30 border-amber-800 text-amber-300'
                  : 'bg-rose-950/30 border-rose-800 text-rose-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {probeResult.status === 'HEALTHY' ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : probeResult.status === 'DEGRADED' ? (
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-400" />
                  )}
                  <strong className="text-sm font-bold text-white">
                    {probeResult.httpStatus > 0 ? `HTTP ${probeResult.httpStatus}` : 'Target Offline'} · Latency: {probeResult.latencyMs}ms
                  </strong>
                  <span className="text-[10px] text-slate-400 font-mono">({probeResult.endpoint})</span>
                </div>
                <span className="text-[10px] text-slate-400">Probed: {probeResult.timestamp}</span>
              </div>

              {/* Sub-system checks from live health response */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 pt-1 border-t border-slate-800/80 text-[11px]">
                {probeResult.checks.map((chk, i) => (
                  <div key={i} className="bg-slate-900/60 p-2.5 rounded border border-slate-800 flex items-center justify-between gap-2">
                    <div className="truncate">
                      <span className="text-slate-200 font-bold block truncate">{chk.name}</span>
                      {chk.details && <span className="text-[10px] text-slate-400 block truncate" title={chk.details}>{chk.details}</span>}
                    </div>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold flex-shrink-0 ${
                        chk.status === 'UP'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {chk.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* REALTIME RUNTIME TELEMETRY (Framework-Aware: Process Telemetry for Python/Node/Go vs JMX Heap for Java) */}
          {detectedRuntime !== 'JAVA' ? (() => {
            const liveProcess = probeResult?.rawPayload?.components?.process?.details;
            const currentCpuPct = liveProcess?.cpu_percent !== undefined ? liveProcess.cpu_percent : (service.processCpuPct || 0);
            const currentMemoryMb = liveProcess?.rss_mb !== undefined ? liveProcess.rss_mb : (service.processMemoryMb || 0);
            const currentThreads = liveProcess?.num_threads !== undefined ? liveProcess.num_threads : (service.activeThreads || 0);
            const currentOpenFds = liveProcess?.open_handles !== undefined ? liveProcess.open_handles : (service.openFds || 0);
            const isAwaitingTelemetry = currentCpuPct === 0 && currentMemoryMb === 0 && currentThreads === 0 && (service.rps || 0) === 0;

            return (
              <div className="bg-[#0d1420] border border-slate-800 rounded-xl p-4 space-y-4 shadow-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="text-xs font-bold uppercase text-white flex items-center gap-1.5 text-cyan-400">
                    <Cpu className="w-4 h-4 text-cyan-400" /> Process Telemetry & System Resource Utilization
                  </h4>
                  <div className="flex items-center gap-2 text-[10px]">
                    <span className="text-slate-400">
                      Source:{' '}
                      <strong className="text-indigo-300">
                        {liveProcess ? 'Live Actuator Probe' : (service.monitoringSource || 'Prometheus APM')}
                      </strong>
                    </span>
                    <span className="text-slate-600">·</span>
                    <span className="text-slate-400">
                      Freshness:{' '}
                      <strong className="text-emerald-400">
                        {liveProcess ? 'Live' : `${service.freshnessSeconds ?? 0}s`}
                      </strong>
                    </span>
                  </div>
                </div>

                {isAwaitingTelemetry && !probeResult && (
                  <div className="p-2.5 rounded-lg bg-indigo-950/40 border border-indigo-800/60 text-indigo-300 text-[11px] flex items-center justify-between gap-3">
                    <span className="flex items-center gap-2">
                      <Radio className="w-4 h-4 text-indigo-400 animate-pulse flex-shrink-0" />
                      <span>
                        <strong>Awaiting Live Telemetry:</strong> This service is cataloged in the Registry. Click <strong>&ldquo;Ping / Probe Endpoint&rdquo;</strong> above to query live process resources on {targetHost}:{targetPort}.
                      </span>
                    </span>
                  </div>
                )}

                {/* Process Stats Grid with Dynamic Scaling */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  {/* CPU Utilization */}
                  <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400 font-bold">Process CPU Slice</span>
                      <span className={`font-bold ${currentCpuPct > cpuWarningThreshold ? 'text-amber-400' : 'text-cyan-400'}`}>
                        {currentCpuPct}%
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${currentCpuPct > cpuWarningThreshold ? 'bg-amber-500' : 'bg-cyan-500'}`}
                        style={{ width: `${Math.min(100, Math.max(0, currentCpuPct))}%` }}
                      ></div>
                    </div>
                    <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                      <span>Threshold: {cpuWarningThreshold}%</span>
                      <span>{liveProcess ? 'Live Telemetry' : 'Total User+Sys'}</span>
                    </div>
                  </div>

                  {/* Resident Memory RSS */}
                  <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400 font-bold">Resident Memory (RSS)</span>
                      <span className="text-emerald-400 font-bold">{currentMemoryMb} MB</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full"
                        style={{ width: `${Math.min(100, (currentMemoryMb / maxMemoryScaleMb) * 100)}%` }}
                      ></div>
                    </div>
                    <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                      <span>Cap: {maxMemoryScaleMb} MB</span>
                      <span>Mapped RSS</span>
                    </div>
                  </div>

                  {/* Active Threads */}
                  <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400 font-bold">OS Threads</span>
                      <span className="text-indigo-400 font-bold">{currentThreads} Threads</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-indigo-500 rounded-full"
                        style={{ width: `${Math.min(100, (currentThreads / maxThreadsScale) * 100)}%` }}
                      ></div>
                    </div>
                    <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                      <span>Pool: {maxThreadsScale} max</span>
                      <span>Event Loop</span>
                    </div>
                  </div>

                  {/* File Descriptors / Handles */}
                  <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400 font-bold">Open Handles / FDs</span>
                      <span className="text-teal-400 font-bold">{currentOpenFds} Handles</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-teal-500 rounded-full"
                        style={{ width: `${Math.min(100, (currentOpenFds / maxFdsScale) * 100)}%` }}
                      ></div>
                    </div>
                    <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                      <span>Limit: {maxFdsScale}</span>
                      <span>Sockets & Files</span>
                    </div>
                  </div>
                </div>

                {/* Traffic & Latency Real Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-800 text-[11px]">
                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <span className="text-slate-500 text-[10px] uppercase font-bold block">THROUGHPUT</span>
                    <strong className="text-white font-extrabold text-sm">{service.rps || 0} req/s</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Total: {service.totalRequests || 0} req</span>
                  </div>

                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <span className="text-slate-500 text-[10px] uppercase font-bold block">5xx ERROR RATE</span>
                    <strong className={`font-extrabold text-sm ${(service.errorRate5xx || 0) > errorWarningThreshold ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {service.errorRate5xx || 0}%
                    </strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">2xx: {service.http2xx || 0} · 5xx: {service.http5xx || 0}</span>
                  </div>

                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <span className="text-slate-500 text-[10px] uppercase font-bold block">P50 LATENCY</span>
                    <strong className="text-emerald-400 font-extrabold text-sm">{service.p50 || 0}ms</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Median response</span>
                  </div>

                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <span className="text-slate-500 text-[10px] uppercase font-bold block">P95 LATENCY</span>
                    <strong className="text-amber-400 font-extrabold text-sm">{service.p95 || 0}ms</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">P99: {service.p99 || 0}ms</span>
                  </div>
                </div>
              </div>
            );
          })() : (
            /* SPRING BOOT / JAVA RUNTIME TELEMETRY */
            <div className="bg-[#0d1420] border border-slate-800 rounded-xl p-4 space-y-4 shadow-lg">
              <h4 className="text-xs font-bold uppercase text-white flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-indigo-400">
                  <Layers className="w-4 h-4 text-indigo-400" /> JVM Runtime Telemetry (Prometheus JMX)
                </span>
                <span className="text-[10px] text-slate-500">
                  Max Heap: <strong className="text-slate-300">{service.jvmHeapMax || 'N/A'}</strong>
                </span>
              </h4>

              {service.jvmHeapUsed ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400 font-bold">Heap Saturation</span>
                      <span className="text-indigo-400 font-bold">{service.jvmHeapPct}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${service.jvmHeapPct}%` }}></div>
                    </div>
                    <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                      <span>Used: {service.jvmHeapUsed}</span>
                      <span>Max: {service.jvmHeapMax}</span>
                    </div>
                  </div>

                  <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400 font-bold">GC Pause</span>
                      <span className="text-emerald-400 font-bold">{service.gcPauseMs || 0}ms</span>
                    </div>
                    <div className="text-[10px] text-slate-500 pt-2">
                      <span>Live GC pause duration from JVM JMX collector</span>
                    </div>
                  </div>

                  <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400 font-bold">Active Threads</span>
                      <span className="text-teal-400 font-bold">{service.activeThreads}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 pt-2">
                      <span>Live Java threads from JVM JMX collector</span>
                    </div>
                  </div>

                  <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400 font-bold">Throughput</span>
                      <span className="text-white font-bold">{service.rps} req/s</span>
                    </div>
                    <div className="text-[10px] text-slate-500 pt-2">
                      <span>HTTP request rate</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-400 space-y-1">
                  <p className="text-white font-bold text-xs">No Live JMX Exporter Scraped For Port {port}</p>
                  <p className="text-[11px] text-slate-500">
                    To capture live Eden, Survivor, Metaspace, and GC pauses for this Spring Boot service, ensure a Prometheus JMX exporter is attached to the JVM on port {port}.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Dynamic Actuator & API Route Health Table */}
          <div className="bg-[#0d1420] border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h4 className="text-xs font-bold uppercase text-white flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-orange-400" /> Key Actuator & API Routes ({activeRoutes.length})
                </h4>
                <span className="text-[10px] text-slate-500">
                  Real-time health probes · Click &ldquo;Probe&rdquo; to test any route live
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAddingCustomRoute(!isAddingCustomRoute)}
                  className="px-2.5 py-1 rounded bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-800 text-indigo-300 text-[10px] font-bold flex items-center gap-1 transition-colors"
                >
                  <Plus className="w-3 h-3" />
                  <span>{isAddingCustomRoute ? 'Cancel' : '+ Add Custom Route'}</span>
                </button>
              </div>
            </div>

            {/* Inline Custom Route Creator Form */}
            {isAddingCustomRoute && (
              <div className="p-3 bg-slate-950 rounded-lg border border-indigo-800/60 space-y-2 animate-in fade-in duration-150">
                <span className="text-indigo-300 font-bold text-[11px] block">Add Custom Route to Test</span>
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={customMethod}
                    onChange={(e: any) => setCustomMethod(e.target.value)}
                    className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white text-xs font-bold focus:outline-none focus:border-indigo-500"
                  >
                    <option value="GET">GET</option>
                    <option value="POST">POST</option>
                    <option value="HEAD">HEAD</option>
                  </select>
                  <input
                    type="text"
                    value={customPath}
                    onChange={(e) => setCustomPath(e.target.value)}
                    placeholder="/api/v1/custom-endpoint"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-white text-xs font-mono focus:outline-none focus:border-indigo-500"
                  />
                  <input
                    type="text"
                    value={customDesc}
                    onChange={(e) => setCustomDesc(e.target.value)}
                    placeholder="Description (optional)"
                    className="w-48 bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-white text-xs focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    onClick={handleAddCustomRoute}
                    className="px-3 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs"
                  >
                    Add &amp; Probe
                  </button>
                </div>
              </div>
            )}

            {/* Route List */}
            <div className="space-y-2">
              {activeRoutes.map((route, idx) => {
                const probed = routeProbeResults[route.path];
                const isThisRouteProbing = probingPath === route.path;

                return (
                  <div
                    key={`${route.method}-${route.path}-${idx}`}
                    className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                        {route.method}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white text-xs font-bold">{route.path}</span>
                          <span className="text-[10px] text-slate-400">· {route.type}</span>
                          {route.source === 'DISCOVERED' && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800">
                              AUTO-DISCOVERED
                            </span>
                          )}
                          {route.source === 'CONFIGURED' && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                              REGISTRY
                            </span>
                          )}
                          {route.source === 'USER_CUSTOM' && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-purple-950/80 text-purple-300 border border-purple-800">
                              CUSTOM
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 block">{route.desc}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 self-end sm:self-auto">
                      {probed ? (
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-400">{probed.latencyMs}ms</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              probed.ok
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-rose-950 text-rose-400 border border-rose-800'
                            }`}
                          >
                            HTTP {probed.status} {probed.ok ? 'OK' : 'ERR'}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-500 italic">Not probed yet</span>
                      )}

                      <button
                        onClick={() => handleProbeRoute(route.path, route.method)}
                        disabled={isThisRouteProbing}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold flex items-center gap-1 border border-slate-700 transition-colors disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3 h-3 ${isThisRouteProbing ? 'animate-spin' : ''}`} />
                        <span>{isThisRouteProbing ? 'Probing...' : 'Probe'}</span>
                      </button>

                      {route.source === 'USER_CUSTOM' && (
                        <button
                          onClick={() => handleRemoveCustomRoute(route.path)}
                          className="p-1 rounded text-slate-500 hover:text-rose-400 transition-colors"
                          title="Remove custom route"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Dynamic CLI Validation & cURL Probes */}
          <div className="bg-[#0d1420] border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase text-white flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-emerald-400" /> CLI Validation &amp; cURL Probes
              </h4>
              <button
                onClick={() => setShowDiagnosticDetails(!showDiagnosticDetails)}
                className="text-[10px] text-indigo-400 hover:text-indigo-300 underline font-bold"
              >
                {showDiagnosticDetails ? 'Hide Live Diagnostic Payload' : 'View Live Diagnostic Payload (JSON)'}
              </button>
            </div>

            <div className="space-y-2">
              {curlCommands.map((cmdItem) => (
                <div
                  key={cmdItem.id}
                  className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between gap-2"
                >
                  <div className="truncate font-mono text-[11px] text-slate-300">
                    <span className="text-emerald-400 mr-2">$</span>
                    {cmdItem.cmd}
                    <span className="text-[9px] text-slate-500 ml-2">({cmdItem.label})</span>
                  </div>
                  <button
                    onClick={() => handleCopy(cmdItem.cmd, cmdItem.id)}
                    className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors flex-shrink-0"
                    title="Copy cURL command"
                  >
                    {copiedCmd === cmdItem.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              ))}
            </div>

            {/* Live Diagnostic Payload Inspector */}
            {showDiagnosticDetails && (
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/90 space-y-2 font-mono text-[10px] text-slate-300">
                <span className="text-white font-bold block">Live Telemetry &amp; Last Probe Diagnostic Payload</span>
                <pre className="overflow-x-auto max-h-48 text-emerald-400 p-2 bg-slate-900 rounded border border-slate-800">
                  {JSON.stringify(
                    {
                      service: serviceName,
                      target: `http://${targetHost}:${targetPort}`,
                      runtime: detectedRuntime,
                      framework: frameworkLabel,
                      liveTelemetry: {
                        processCpuPct: service.processCpuPct,
                        processMemoryMb: service.processMemoryMb,
                        activeThreads: service.activeThreads,
                        openFds: service.openFds,
                        rps: service.rps,
                        errorRate5xx: service.errorRate5xx,
                        p50Ms: service.p50,
                        p95Ms: service.p95,
                        jvmHeapUsed: service.jvmHeapUsed,
                        jvmHeapMax: service.jvmHeapMax
                      },
                      lastLiveProbe: probeResult
                        ? {
                            endpoint: probeResult.endpoint,
                            httpStatus: probeResult.httpStatus,
                            latencyMs: probeResult.latencyMs,
                            timestamp: probeResult.timestamp,
                            payload: probeResult.rawPayload
                          }
                        : "Click 'Ping / Probe Endpoint' to run live probe against the service"
                    },
                    null,
                    2
                  )}
                </pre>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between p-4 border-t border-slate-800 bg-[#0d1527]">
          <span className="text-[11px] text-slate-500">
            Realtime telemetry stream from <strong className="text-slate-400">{service.monitoringSource || 'Prometheus APM'}</strong> · Host: <strong className="text-cyan-400">{targetHost}:{targetPort}</strong>
          </span>
          <button
            onClick={handleClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
