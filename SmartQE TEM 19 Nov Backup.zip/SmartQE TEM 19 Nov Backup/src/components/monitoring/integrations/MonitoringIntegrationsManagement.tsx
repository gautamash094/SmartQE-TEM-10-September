import React, { useState, useEffect } from 'react';
import {
  MonitoringIntegrationConfig,
  ConnectionTestResult,
} from '../../../types/monitoring';
import { monitoringService } from '../../../services/monitoringService';
import {
  Layers,
  Plus,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Radio,
  Activity,
  Cpu,
  Database,
  Server,
  Zap,
  Trash2,
  Edit2,
  Lock,
  Globe,
  Sliders,
  ShieldCheck,
  Power,
  X,
} from 'lucide-react';

interface MonitoringIntegrationsManagementProps {
  onIntegrationsChanged?: () => void;
}

export const MonitoringIntegrationsManagement: React.FC<MonitoringIntegrationsManagementProps> = ({
  onIntegrationsChanged,
}) => {
  const [integrations, setIntegrations] = useState<MonitoringIntegrationConfig[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, ConnectionTestResult>>({});
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingTool, setEditingTool] = useState<MonitoringIntegrationConfig | null>(null);
  const [probeLoading, setProbeLoading] = useState<boolean>(false);
  const [probeResult, setProbeResult] = useState<ConnectionTestResult | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    tool_identifier: '',
    tool_type: 'PROMETHEUS',
    display_name: '',
    description: '',
    base_url: 'http://localhost:9090',
    auth_type: 'NONE',
    apiKey: '',
    appKey: '',
    username: '',
    password: '',
    capabilities: ['INFRASTRUCTURE', 'SERVER'],
    scrape_interval_seconds: 15,
    timeout_seconds: 5.0,
    priority: 1,
    environment_scope: ['ALL'],
  });

  const loadIntegrations = async () => {
    setLoading(true);
    try {
      const data = await monitoringService.getMonitoringIntegrations();
      setIntegrations(data);
    } catch (err) {
      console.error('Failed to load integrations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadIntegrations();
  }, []);

  const handleTestConnection = async (toolIdentifier: string) => {
    setTestingId(toolIdentifier);
    try {
      const res = await monitoringService.testIntegrationConnection(toolIdentifier);
      if (res) {
        setTestResults((prev) => ({ ...prev, [toolIdentifier]: res }));
      }
    } finally {
      setTestingId(null);
    }
  };

  const handleToggle = async (toolIdentifier: string, currentStatus: boolean) => {
    const success = await monitoringService.toggleIntegration(toolIdentifier, !currentStatus);
    if (success) {
      setIntegrations((prev) =>
        prev.map((item) =>
          item.tool_identifier === toolIdentifier
            ? { ...item, is_enabled: !currentStatus }
            : item
        )
      );
      if (onIntegrationsChanged) onIntegrationsChanged();
    }
  };

  const handleDelete = async (toolIdentifier: string) => {
    if (!window.confirm(`Are you sure you want to remove monitoring integration '${toolIdentifier}'?`)) return;
    const success = await monitoringService.deleteMonitoringIntegration(toolIdentifier);
    if (success) {
      setIntegrations((prev) => prev.filter((i) => i.tool_identifier !== toolIdentifier));
      if (onIntegrationsChanged) onIntegrationsChanged();
    }
  };

  const openRegisterModal = () => {
    setEditingTool(null);
    setProbeResult(null);
    setFormData({
      tool_identifier: '',
      tool_type: 'PROMETHEUS',
      display_name: '',
      description: '',
      base_url: 'http://localhost:9090',
      auth_type: 'NONE',
      apiKey: '',
      appKey: '',
      username: '',
      password: '',
      capabilities: ['INFRASTRUCTURE', 'SERVER'],
      scrape_interval_seconds: 15,
      timeout_seconds: 5.0,
      priority: 1,
      environment_scope: ['ALL'],
    });
    setModalOpen(true);
  };

  const openEditModal = (tool: MonitoringIntegrationConfig) => {
    setEditingTool(tool);
    setProbeResult(null);
    setFormData({
      tool_identifier: tool.tool_identifier,
      tool_type: tool.tool_type,
      display_name: tool.display_name,
      description: tool.description || '',
      base_url: tool.base_url,
      auth_type: tool.auth_type,
      apiKey: '',
      appKey: '',
      username: '',
      password: '',
      capabilities: tool.capabilities,
      scrape_interval_seconds: tool.scrape_interval_seconds,
      timeout_seconds: tool.timeout_seconds,
      priority: tool.priority,
      environment_scope: tool.environment_scope,
    });
    setModalOpen(true);
  };

  const handleProbeModalConnection = async () => {
    setProbeLoading(true);
    setProbeResult(null);
    try {
      const creds: Record<string, string> = {};
      if (formData.apiKey) creds.api_key = formData.apiKey;
      if (formData.appKey) creds.app_key = formData.appKey;
      if (formData.username) creds.username = formData.username;
      if (formData.password) creds.password = formData.password;

      const payload = {
        tool_identifier: formData.tool_identifier || 'probe-temp',
        tool_type: formData.tool_type as any,
        display_name: formData.display_name || 'Probe Test',
        base_url: formData.base_url,
        timeout_seconds: formData.timeout_seconds,
        capabilities: formData.capabilities,
        credentials: creds,
      };

      const res = await monitoringService.testTransientProbe(payload);
      setProbeResult(res);
    } finally {
      setProbeLoading(false);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const creds: Record<string, string> = {};
    if (formData.apiKey) creds.api_key = formData.apiKey;
    if (formData.appKey) creds.app_key = formData.appKey;
    if (formData.username) creds.username = formData.username;
    if (formData.password) creds.password = formData.password;

    const payload: any = {
      tool_identifier: formData.tool_identifier,
      tool_type: formData.tool_type,
      display_name: formData.display_name,
      description: formData.description,
      base_url: formData.base_url,
      auth_type: formData.auth_type,
      capabilities: formData.capabilities,
      scrape_interval_seconds: Number(formData.scrape_interval_seconds),
      timeout_seconds: Number(formData.timeout_seconds),
      priority: Number(formData.priority),
      environment_scope: formData.environment_scope,
    };
    if (Object.keys(creds).length > 0) {
      payload.credentials = creds;
    }

    try {
      if (editingTool) {
        await monitoringService.updateMonitoringIntegration(editingTool.tool_identifier, payload);
      } else {
        await monitoringService.registerMonitoringIntegration(payload);
      }
      setModalOpen(false);
      await loadIntegrations();
      if (onIntegrationsChanged) onIntegrationsChanged();
    } catch (err: any) {
      alert(`Error saving monitoring integration: ${err?.message || 'Check connection parameters'}`);
    }
  };

  const toggleCapability = (cap: string) => {
    setFormData((prev) => {
      const exists = prev.capabilities.includes(cap);
      return {
        ...prev,
        capabilities: exists ? prev.capabilities.filter((c) => c !== cap) : [...prev.capabilities, cap],
      };
    });
  };

  return (
    <div className="bg-[#0b101b] border border-slate-800 rounded-2xl p-6 font-mono text-xs space-y-6 shadow-2xl">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-500/10 border border-orange-500/30 flex items-center justify-center">
              <Layers className="w-4 h-4 text-orange-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide uppercase">
                Centralized Monitoring Integrations & Registry
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Single Source of Truth for all monitoring backends. Connect Prometheus, Datadog, Nagios, OTel, and custom observability engines.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={loadIntegrations}
            disabled={loading}
            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold rounded-lg border border-slate-700/80 flex items-center gap-1.5 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${loading ? 'animate-spin' : ''}`} />
            <span>SYNC REGISTRY</span>
          </button>

          <button
            onClick={openRegisterModal}
            className="px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold rounded-lg shadow-lg flex items-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>CONNECT NEW MONITORING TOOL</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">REGISTERED INTEGRATIONS</span>
          <span className="text-2xl font-black text-white">{integrations.length}</span>
          <span className="text-[10px] text-slate-500 block mt-1">Multi-Tool Architecture</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">ACTIVE / ENABLED</span>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-2xl font-black text-emerald-400">
              {integrations.filter((i) => i.is_enabled).length}
            </span>
          </div>
          <span className="text-[10px] text-emerald-500/80 block mt-1">Live Telemetry Sources</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">TOOL ECOSYSTEM</span>
          <span className="text-xl font-bold text-cyan-400">
            {new Set(integrations.map((i) => i.tool_type)).size} Platforms
          </span>
          <span className="text-[10px] text-slate-500 block mt-1">Tool-Agnostic Model</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
          <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">SECURITY VAULT</span>
          <div className="flex items-center gap-1.5 text-amber-400 font-bold">
            <ShieldCheck className="w-4 h-4" />
            <span>AES-256 Fernet</span>
          </div>
          <span className="text-[10px] text-slate-500 block mt-1">Encrypted Credentials</span>
        </div>
      </div>

      {/* Integrations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {integrations.map((tool) => {
          const testRes = testResults[tool.tool_identifier];
          const isTesting = testingId === tool.tool_identifier;

          return (
            <div
              key={tool.tool_identifier}
              className={`p-5 rounded-xl border transition-all ${
                tool.is_enabled
                  ? 'bg-slate-950/70 border-slate-800 hover:border-slate-700 shadow-md'
                  : 'bg-slate-950/30 border-slate-900 opacity-60'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-white">{tool.display_name}</span>
                    <span
                      className={`text-[9px] px-2 py-0.5 rounded font-black tracking-wider ${
                        tool.tool_type === 'PROMETHEUS'
                          ? 'bg-orange-950 text-orange-400 border border-orange-800'
                          : tool.tool_type === 'DATADOG'
                          ? 'bg-purple-950 text-purple-400 border border-purple-800'
                          : tool.tool_type === 'NAGIOS'
                          ? 'bg-blue-950 text-blue-400 border border-blue-800'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {tool.tool_type}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">ID: {tool.tool_identifier}</p>
                </div>

                <button
                  onClick={() => handleToggle(tool.tool_identifier, tool.is_enabled)}
                  title={tool.is_enabled ? 'Click to Disable' : 'Click to Enable'}
                  className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 border transition-all ${
                    tool.is_enabled
                      ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800 hover:bg-emerald-900/60'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <Power className="w-3 h-3" />
                  <span>{tool.is_enabled ? 'ACTIVE' : 'DISABLED'}</span>
                </button>
              </div>

              {/* Endpoint & Priority */}
              <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/80 mb-3 space-y-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-500">Endpoint:</span>
                  <span className="text-slate-200 truncate max-w-[200px]" title={tool.base_url}>
                    {tool.base_url}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-500">Scrape Rate:</span>
                  <span className="text-cyan-400 font-bold">{tool.scrape_interval_seconds}s interval</span>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-500">Priority & Auth:</span>
                  <span className="text-slate-300 font-bold">
                    P{tool.priority} ({tool.auth_type})
                  </span>
                </div>
              </div>

              {/* Masked Credentials if present */}
              {Object.keys(tool.masked_credentials || {}).length > 0 && (
                <div className="mb-3 p-2 bg-slate-900/40 border border-slate-800/60 rounded text-[10px] text-slate-400 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Lock className="w-3 h-3 text-amber-400" /> Key:
                  </span>
                  <span className="font-mono text-slate-300">
                    {Object.values(tool.masked_credentials)[0]}
                  </span>
                </div>
              )}

              {/* Capabilities Badges */}
              <div className="mb-4">
                <span className="text-[10px] text-slate-500 block mb-1">Capabilities:</span>
                <div className="flex flex-wrap gap-1">
                  {tool.capabilities.map((cap) => (
                    <span
                      key={cap}
                      className="px-1.5 py-0.5 rounded text-[9px] bg-slate-800 text-slate-300 border border-slate-700"
                    >
                      {cap}
                    </span>
                  ))}
                </div>
              </div>

              {/* Connection Test Output */}
              {testRes && (
                <div
                  className={`p-2.5 rounded-lg text-[10px] mb-3 border ${
                    testRes.success
                      ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                      : 'bg-rose-950/30 border-rose-800 text-rose-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold mb-0.5">
                    <span>{testRes.success ? 'PROBE SUCCESS' : 'PROBE FAILED'}</span>
                    <span>{testRes.latency_ms} ms</span>
                  </div>
                  <p className="text-[9px] opacity-80">{testRes.message}</p>
                </div>
              )}

              {/* Card Footer Actions */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-800/80">
                <button
                  onClick={() => handleTestConnection(tool.tool_identifier)}
                  disabled={isTesting}
                  className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 font-bold text-[10px] flex items-center gap-1 border border-slate-700 transition-all"
                >
                  <Radio className={`w-3 h-3 ${isTesting ? 'animate-pulse text-amber-400' : ''}`} />
                  <span>{isTesting ? 'PROBING...' : 'TEST PROBE'}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEditModal(tool)}
                    className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition-all"
                    title="Edit Configuration"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(tool.tool_identifier)}
                    className="p-1.5 rounded hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 transition-all"
                    title="Remove Integration"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Register / Edit Monitoring Tool */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0e1626] border border-slate-700 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white uppercase flex items-center gap-2">
                <Sliders className="w-4 h-4 text-orange-400" />
                {editingTool ? `Edit '${editingTool.tool_identifier}'` : 'Connect New Monitoring Platform'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Tool Identifier Slug *
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!!editingTool}
                    value={formData.tool_identifier}
                    onChange={(e) => setFormData({ ...formData, tool_identifier: e.target.value })}
                    placeholder="e.g. datadog-aws-prod"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-orange-500 disabled:opacity-50"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Monitoring Platform *
                  </label>
                  <select
                    value={formData.tool_type}
                    onChange={(e) => {
                      const type = e.target.value;
                      let defaultUrl = formData.base_url;
                      if (type === 'DATADOG') defaultUrl = 'https://api.datadoghq.com';
                      if (type === 'PROMETHEUS') defaultUrl = 'http://localhost:9090';
                      if (type === 'NAGIOS') defaultUrl = 'http://nagios-server:80';
                      if (type === 'OPENTELEMETRY') defaultUrl = 'http://localhost:4318';
                      setFormData({
                        ...formData,
                        tool_type: type,
                        base_url: defaultUrl,
                        auth_type: type === 'DATADOG' ? 'API_KEY' : type === 'NAGIOS' ? 'BASIC_AUTH' : 'NONE',
                      });
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-orange-500"
                  >
                    <option value="PROMETHEUS">Prometheus Server / Exporters</option>
                    <option value="DATADOG">Datadog Cloud Observability</option>
                    <option value="NAGIOS">Nagios Core / XI</option>
                    <option value="OPENTELEMETRY">OpenTelemetry Collector</option>
                    <option value="NEW_RELIC">New Relic One</option>
                    <option value="DYNATRACE">Dynatrace</option>
                    <option value="CUSTOM">Custom Observability API</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">Display Name *</label>
                <input
                  type="text"
                  required
                  value={formData.display_name}
                  onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                  placeholder="e.g. Production Datadog AWS"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">Endpoint Base URL *</label>
                <input
                  type="url"
                  required
                  value={formData.base_url}
                  onChange={(e) => setFormData({ ...formData, base_url: e.target.value })}
                  placeholder="http://... or https://..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-orange-500"
                />
              </div>

              {/* Auth Settings */}
              <div className="bg-slate-900/60 border border-slate-800 p-3.5 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-white flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-400" /> Authentication & Credentials
                  </span>
                  <select
                    value={formData.auth_type}
                    onChange={(e) => setFormData({ ...formData, auth_type: e.target.value })}
                    className="bg-slate-800 border border-slate-700 rounded px-2 py-1 text-slate-200 text-[10px]"
                  >
                    <option value="NONE">No Authentication</option>
                    <option value="API_KEY">API Key / Token</option>
                    <option value="BASIC_AUTH">Basic Auth (User / Pass)</option>
                    <option value="BEARER_TOKEN">Bearer Token</option>
                  </select>
                </div>

                {formData.auth_type === 'API_KEY' && (
                  <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                    <div>
                      <label className="text-[9px] text-slate-400 uppercase block mb-1">API Key</label>
                      <input
                        type="password"
                        value={formData.apiKey}
                        onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                        placeholder={editingTool ? '(Unchanged)' : 'Enter API Key'}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] text-slate-400 uppercase block mb-1">App Key (Optional)</label>
                      <input
                        type="password"
                        value={formData.appKey}
                        onChange={(e) => setFormData({ ...formData, appKey: e.target.value })}
                        placeholder={editingTool ? '(Unchanged)' : 'Enter App Key'}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white text-xs"
                      />
                    </div>
                  </div>
                )}

                {formData.auth_type === 'BASIC_AUTH' && (
                  <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                    <div>
                      <label className="text-[9px] text-slate-400 uppercase block mb-1">Username</label>
                      <input
                        type="text"
                        value={formData.username}
                        onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                        placeholder="e.g. nagiosadmin"
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] text-slate-400 uppercase block mb-1">Password</label>
                      <input
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        placeholder="Enter Password"
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Capabilities Multi-select */}
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1.5">
                  Supported Monitoring Capabilities
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['INFRASTRUCTURE', 'SERVER', 'APPLICATION', 'DATABASE', 'NETWORK', 'ALERTS', 'HISTORICAL_METRICS'].map(
                    (cap) => (
                      <button
                        type="button"
                        key={cap}
                        onClick={() => toggleCapability(cap)}
                        className={`px-2.5 py-1.5 rounded-lg text-[10px] font-bold border transition-all text-left ${
                          formData.capabilities.includes(cap)
                            ? 'bg-orange-950/50 text-orange-400 border-orange-700'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                        }`}
                      >
                        ✓ {cap}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Scrape Rate & Priority */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[9px] text-slate-400 uppercase block mb-1">Scrape Interval (s)</label>
                  <input
                    type="number"
                    min="5"
                    max="3600"
                    value={formData.scrape_interval_seconds}
                    onChange={(e) => setFormData({ ...formData, scrape_interval_seconds: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-slate-400 uppercase block mb-1">Timeout (s)</label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    step="0.5"
                    value={formData.timeout_seconds}
                    onChange={(e) => setFormData({ ...formData, timeout_seconds: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-slate-400 uppercase block mb-1">Priority (1 = high)</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-white text-xs"
                  />
                </div>
              </div>

              {/* Pre-flight Probe Output */}
              {probeResult && (
                <div
                  className={`p-3 rounded-lg text-[11px] border ${
                    probeResult.success
                      ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                      : 'bg-rose-950/40 border-rose-800 text-rose-300'
                  }`}
                >
                  <div className="font-bold flex items-center justify-between mb-0.5">
                    <span>{probeResult.success ? 'PRE-FLIGHT PROBE PASSED' : 'PRE-FLIGHT PROBE FAILED'}</span>
                    <span>{probeResult.latency_ms} ms</span>
                  </div>
                  <p className="text-[10px]">{probeResult.message}</p>
                </div>
              )}

              {/* Modal Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleProbeModalConnection}
                  disabled={probeLoading || !formData.base_url}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 font-bold rounded-lg border border-slate-700 flex items-center gap-1.5"
                >
                  <Radio className={`w-3.5 h-3.5 ${probeLoading ? 'animate-pulse text-amber-400' : ''}`} />
                  <span>{probeLoading ? 'VERIFYING...' : 'VERIFY CONNECTION'}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold rounded-lg shadow-lg"
                  >
                    {editingTool ? 'Save Changes' : 'Register Tool'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
