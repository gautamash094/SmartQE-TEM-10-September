import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  AlertTriangle,
  BellRing,
  Volume2,
  VolumeX,
  X,
  CheckCircle2,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  Maximize2
} from 'lucide-react';
import { ServerAlertItem } from '../../../types/monitoring';
import {
  playAlertSound,
  isAlertSoundEnabled,
  setAlertSoundEnabled,
  testAlertSound
} from '../../../utils/alertSound';

interface AlertPopupNotificationProps {
  alerts: ServerAlertItem[];
  serverName?: string;
  onAcknowledge: (alertId: string) => void;
  onResolve: (alertId: string) => void;
}

export const AlertPopupNotification: React.FC<AlertPopupNotificationProps> = ({
  alerts = [],
  serverName = 'WIN-SRV-TEM-01',
  onAcknowledge,
  onResolve,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => isAlertSoundEnabled());
  const [snoozedAlertIds, setSnoozedAlertIds] = useState<Set<string>>(new Set());

  // Track known alert IDs to detect newly triggered threshold breaches
  const knownAlertIdsRef = useRef<Set<string>>(new Set());

  // Filter only ACTIVE alerts that have not been manually snoozed
  const activeAlerts = useMemo(() => {
    return alerts.filter((a) => a.status === 'ACTIVE');
  }, [alerts]);

  const visibleAlerts = useMemo(() => {
    return activeAlerts.filter((a) => !snoozedAlertIds.has(a.alert_id));
  }, [activeAlerts, snoozedAlertIds]);

  // Determine highest severity
  const highestSeverity = useMemo(() => {
    if (visibleAlerts.some((a) => a.severity === 'SEVERE')) return 'SEVERE';
    if (visibleAlerts.some((a) => a.severity === 'CRITICAL')) return 'CRITICAL';
    if (visibleAlerts.some((a) => a.severity === 'WARNING')) return 'WARNING';
    return 'INFO';
  }, [visibleAlerts]);

  // Detect newly arrived active alerts and trigger popup + sound
  useEffect(() => {
    if (activeAlerts.length === 0) {
      // Clear known when alerts resolve
      knownAlertIdsRef.current = new Set();
      setIsOpen(false);
      return;
    }

    const currentIds = new Set(activeAlerts.map((a) => a.alert_id));
    const newAlerts = activeAlerts.filter((a) => !knownAlertIdsRef.current.has(a.alert_id));

    if (newAlerts.length > 0) {
      // New breach detected!
      setIsOpen(true);
      setIsMinimized(false);

      // Play alert chime
      const topSev = newAlerts.some((a) => a.severity === 'SEVERE' || a.severity === 'CRITICAL')
        ? 'CRITICAL'
        : 'WARNING';
      playAlertSound(topSev);
    }

    knownAlertIdsRef.current = currentIds;
  }, [activeAlerts]);

  const toggleSound = () => {
    const nextState = !soundEnabled;
    setSoundEnabled(nextState);
    setAlertSoundEnabled(nextState);
    if (nextState) {
      testAlertSound('WARNING');
    }
  };

  const handleSnoozeAll = () => {
    const allIds = new Set(activeAlerts.map((a) => a.alert_id));
    setSnoozedAlertIds(allIds);
    setIsOpen(false);
  };

  if (!isOpen && visibleAlerts.length === 0) {
    return null;
  }

  // Floating Minimized Pill
  if (isMinimized || (!isOpen && visibleAlerts.length > 0)) {
    return (
      <div className="fixed bottom-5 right-5 z-50 animate-bounce cursor-pointer">
        <button
          onClick={() => {
            setIsOpen(true);
            setIsMinimized(false);
          }}
          className={`flex items-center gap-2.5 px-4 py-2.5 rounded-full shadow-2xl border text-xs font-bold transition ${
            highestSeverity === 'SEVERE' || highestSeverity === 'CRITICAL'
              ? 'bg-rose-950 text-rose-200 border-rose-500 shadow-rose-950/80 hover:bg-rose-900'
              : 'bg-amber-950 text-amber-200 border-amber-500 shadow-amber-950/80 hover:bg-amber-900'
          }`}
        >
          <BellRing className="w-4 h-4 animate-spin text-white" />
          <span>
            {visibleAlerts.length} Active Alert{visibleAlerts.length > 1 ? 's' : ''} on {serverName}
          </span>
          <Maximize2 className="w-3.5 h-3.5 ml-1 text-slate-300" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-5 right-5 z-50 w-full max-w-lg animate-in slide-in-from-bottom-5 duration-300">
      <div
        className={`rounded-2xl border-2 shadow-2xl overflow-hidden backdrop-blur-xl ${
          highestSeverity === 'SEVERE' || highestSeverity === 'CRITICAL'
            ? 'bg-slate-950/95 border-rose-600 shadow-rose-950/70'
            : 'bg-slate-950/95 border-amber-500 shadow-amber-950/70'
        }`}
      >
        {/* Header Bar */}
        <div
          className={`px-4 py-3 flex items-center justify-between border-b ${
            highestSeverity === 'SEVERE' || highestSeverity === 'CRITICAL'
              ? 'bg-rose-950/80 border-rose-800/80 text-rose-200'
              : 'bg-amber-950/80 border-amber-800/80 text-amber-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <BellRing className="w-5 h-5 text-white animate-pulse" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" />
            </div>
            <div>
              <div className="text-xs font-black tracking-wider uppercase flex items-center gap-2">
                THRESHOLD BREACH ALERT
                <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-black/40 text-white">
                  {visibleAlerts.length} ACTIVE
                </span>
              </div>
              <div className="text-[11px] font-mono opacity-80">
                Server: <strong className="text-white">{serverName}</strong>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Audio Toggle */}
            <button
              onClick={toggleSound}
              title={soundEnabled ? 'Alert Sound Enabled (Click to Mute)' : 'Alert Sound Muted (Click to Enable)'}
              className={`p-1.5 rounded-lg border text-xs transition cursor-pointer flex items-center gap-1 ${
                soundEnabled
                  ? 'bg-emerald-950/80 border-emerald-600 text-emerald-300 hover:bg-emerald-900'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              <span className="text-[10px] font-mono">{soundEnabled ? 'Sound ON' : 'Muted'}</span>
            </button>

            {/* Test Chime */}
            <button
              onClick={() => testAlertSound(highestSeverity)}
              title="Test Alert Chime"
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[10px] cursor-pointer"
            >
              Chime
            </button>

            {/* Minimize */}
            <button
              onClick={() => setIsMinimized(true)}
              title="Minimize to Pill"
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 transition cursor-pointer"
            >
              <ChevronDown className="w-4 h-4" />
            </button>

            {/* Close / Dismiss */}
            <button
              onClick={handleSnoozeAll}
              title="Dismiss Popup"
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Alerts List */}
        <div className="p-3.5 space-y-2.5 max-h-80 overflow-y-auto">
          {visibleAlerts.map((alert) => (
            <div
              key={alert.alert_id}
              className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition flex flex-col gap-2"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider border ${
                      alert.severity === 'SEVERE'
                        ? 'bg-rose-950 text-rose-300 border-rose-600'
                        : alert.severity === 'CRITICAL'
                        ? 'bg-red-950 text-red-300 border-red-600'
                        : 'bg-amber-950 text-amber-300 border-amber-600'
                    }`}
                  >
                    {alert.severity}
                  </span>
                  <span className="font-bold text-white text-xs">
                    {alert.metric_name || 'System Metric'}
                  </span>
                  {alert.resource && (
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-1.5 py-0.2 rounded border border-cyan-800">
                      {alert.resource}
                    </span>
                  )}
                </div>

                {alert.current_value !== null && alert.current_value !== undefined && (
                  <span className="text-xs font-mono font-bold text-rose-400 bg-rose-950/50 px-2 py-0.5 rounded border border-rose-900/60">
                    Live: {alert.current_value}%
                  </span>
                )}
              </div>

              <p className="text-slate-300 text-xs leading-relaxed">
                {alert.message || 'Telemetry metric crossed configured operational limit.'}
              </p>

              {alert.condition && (
                <div className="text-[10px] font-mono text-slate-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  <span>Rule: {alert.condition}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-800/60">
                <button
                  onClick={() => onAcknowledge(alert.alert_id)}
                  className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold border border-slate-700 transition cursor-pointer flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3 h-3 text-slate-400" />
                  Acknowledge
                </button>
                <button
                  onClick={() => onResolve(alert.alert_id)}
                  className="px-3 py-1 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-300 text-[11px] font-semibold border border-emerald-700 transition cursor-pointer flex items-center gap-1"
                >
                  <ShieldAlert className="w-3 h-3 text-emerald-400" />
                  Resolve
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Footer info bar */}
        <div className="px-4 py-2 bg-slate-900/60 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
          <span className="font-mono">Live telemetry evaluated via Prometheus</span>
          <button
            onClick={handleSnoozeAll}
            className="text-slate-400 hover:text-white transition cursor-pointer underline"
          >
            Dismiss / Snooze All
          </button>
        </div>
      </div>
    </div>
  );
};
