import sqlite3

conn = sqlite3.connect(r'backend\smartqe_tem.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
print("Tables:", tables)

for t in ['assets', 'components']:
    if t in tables:
        print(f"\n--- {t} ---")
        rows = c.execute(f"SELECT * FROM {t} WHERE id='srv-6681' OR name LIKE '%Server_20Aug%'").fetchall()
        for row in rows[:5]:
            print(dict(row))
