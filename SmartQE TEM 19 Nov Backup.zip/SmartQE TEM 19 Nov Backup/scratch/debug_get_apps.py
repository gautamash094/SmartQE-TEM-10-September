import asyncio
import os
import sys

sys.path.insert(0, os.path.abspath('backend'))

from app.database.session import AsyncSessionLocal
from app.services.monitoring_service import monitoring_service
from app.models.environment_profile import EnvironmentProfile
from sqlalchemy import select

async def test():
    async with AsyncSessionLocal() as db:
        for env_id in ['5a9a8432-3f6d-4528-965a-c4f634261fa0', '2c2726a3-e358-4537-9862-e5ab41059d6e']:
            apps = await monitoring_service.get_all_applications(env_id, db=db)
            print(f"Env {env_id} -> {len(apps)} apps")
            for a in apps:
                print(f"    - {a.name} ({a.software_name})")

if __name__ == '__main__':
    asyncio.run(test())
