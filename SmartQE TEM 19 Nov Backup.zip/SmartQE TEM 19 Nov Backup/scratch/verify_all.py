import asyncio, sys, time
sys.path.insert(0, 'backend')
from app.database.session import AsyncSessionLocal
from app.adapters.monitoring.registry import adapter_registry
from app.services.monitoring_service import monitoring_service

async def verify_all():
    print('========================================')
    print('RUNNING COMPREHENSIVE ENDPOINT VERIFICATION')
    print('========================================')

    async with AsyncSessionLocal() as db:
        # 1. Sources Health
        t0 = time.perf_counter()
        sources = await adapter_registry.get_all_sources_health()
        print(f'[1] Sources Health: {len(sources)} sources probed in {time.perf_counter() - t0:.3f}s')
        for s in sources:
            print(f'    - {s.source_name} ({s.source_id}): status={s.status}, latency={s.latency_ms}ms, online={s.connectivity}')

        # 2. Resources (SQLite Database & Tables)
        t0 = time.perf_counter()
        resources = await adapter_registry.get_all_resources()
        tables = [r for r in resources if r.type == 'database_table']
        dbs = [r for r in resources if r.type == 'database']
        print(f'[2] Normalized Resources: {len(resources)} total ({len(tables)} tables, {len(dbs)} databases) in {time.perf_counter() - t0:.3f}s')
        if tables:
            print(f'    - Sample table: {tables[0].name}, rows={tables[0].metadata.get("rows")}, size={tables[0].metadata.get("size_bytes")} bytes')

        # 3. Servers & Infrastructure Nodes
        t0 = time.perf_counter()
        servers = await monitoring_service.get_all_servers('AshEnv_12Aug', db=db)
        print(f'[3] Server Dossiers (AshEnv_12Aug): {len(servers)} servers in {time.perf_counter() - t0:.3f}s')
        for s in servers:
            print(f'    - {s.name} ({s.ip_address}): status={s.status}, exporter_available={s.is_exporter_available}, CPU={s.cpu.utilization_pct}%, RAM={s.memory.utilization_pct}%')

        # 4. Applications (APM & Software Inventory)
        t0 = time.perf_counter()
        apps = await monitoring_service.get_all_applications('AshEnv_12Aug', db=db)
        print(f'[4] Monitored Applications (AshEnv_12Aug): {len(apps)} apps in {time.perf_counter() - t0:.3f}s')
        for a in apps:
            print(f'    - {a.name} (v{a.version}): server={a.hosted_on_server}, runtime={a.runtime}, category={a.category}')

        # 5. Targets
        t0 = time.perf_counter()
        targets = await adapter_registry.get_all_targets('AshEnv_12Aug')
        server_targets = [t for t in targets if 'SERVER' in t.target_type]
        print(f'[5] Unified Targets (AshEnv_12Aug): {len(targets)} targets ({len(server_targets)} server targets) in {time.perf_counter() - t0:.3f}s')
        for st in server_targets:
            print(f'    - {st.name}: is_up={st.is_up}, status={st.status}, url={st.endpoint_url}')

        # 6. Fleet Summary
        t0 = time.perf_counter()
        fleet = await monitoring_service.get_fleet_observability_summary(db=db)
        print(f'[6] Fleet Observability Summary: {len(fleet.environments)} environments in {time.perf_counter() - t0:.3f}s')

    print('========================================')
    print('ALL VERIFICATIONS COMPLETED SUCCESSFULLY!')
    print('========================================')

asyncio.run(verify_all())
