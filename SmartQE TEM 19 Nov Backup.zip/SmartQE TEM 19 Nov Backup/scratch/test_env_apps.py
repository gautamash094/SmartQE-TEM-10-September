import asyncio
from app.database.session import AsyncSessionLocal
from app.services.monitoring_service import monitoring_service
from app.models.environment_profile import EnvironmentProfile
from sqlalchemy import select

async def main():
    async with AsyncSessionLocal() as db:
        res = await db.execute(select(EnvironmentProfile))
        profiles = res.scalars().all()
        for p in profiles:
            apps = await monitoring_service.get_all_applications(p.id, db=db)
            print(f"Env: {p.name} (id={p.id}) -> Apps count: {len(apps)}")
            for a in apps:
                print(f"   App: id={a.id}, name={a.name}, software={a.software_name}")

if __name__ == "__main__":
    asyncio.run(main())
