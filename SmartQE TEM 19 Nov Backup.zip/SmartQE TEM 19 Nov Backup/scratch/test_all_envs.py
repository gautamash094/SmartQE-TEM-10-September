import sqlite3

conn = sqlite3.connect(r'backend\smartqe_tem.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

envs = c.execute("SELECT id, name FROM environment_profiles").fetchall()
for e in envs:
    print(f"Env: {e['name']} ({e['id']})")
    sws = c.execute("SELECT software_name, category FROM environment_softwares WHERE environment_id=? OR environment_name=?", (e['id'], e['name'])).fetchall()
    print(f"   Softwares in DB: {[dict(s) for s in sws]}")
    targets = c.execute("SELECT name, endpoint_url, target_type FROM monitoring_targets WHERE environment_id=? OR environment_name=?", (e['id'], e['name'])).fetchall()
    print(f"   Monitoring Targets in DB: {[dict(t) for t in targets]}")
