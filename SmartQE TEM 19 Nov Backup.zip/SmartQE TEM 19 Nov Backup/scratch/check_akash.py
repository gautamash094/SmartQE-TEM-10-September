import sqlite3
import json

conn = sqlite3.connect(r'backend\smartqe_tem.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

env = c.execute("SELECT * FROM environment_profiles WHERE id='2c2726a3-e358-4537-9862-e5ab41059d6e'").fetchone()
print("Akash Env Profile:")
print(dict(env))

print("\nAll Environment Profiles:")
rows = c.execute("SELECT id, name, software_ids, server_ids FROM environment_profiles").fetchall()
for r in rows:
    print(dict(r))
