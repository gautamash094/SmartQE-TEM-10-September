import sqlite3
import json

conn = sqlite3.connect(r'backend\smartqe_tem.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

envs = c.execute("SELECT id, name, software_ids, server_ids FROM environment_profiles").fetchall()
sws = c.execute("SELECT environment_id, environment_name, software_name, category, status FROM environment_softwares").fetchall()

print(f"Total Environments: {len(envs)}")
print(f"Total Environment Softwares: {len(sws)}")

for e in envs:
    env_id = e['id']
    env_name = e['name']
    sids = json.loads(e['software_ids']) if e['software_ids'] else []
    
    # Softwares registered in environment_softwares
    matching_sw = [s['software_name'] for s in sws if s['environment_id'] == env_id or s['environment_name'] == env_name]
    
    print(f"\nEnv: '{env_name}' ({env_id})")
    print(f"  software_ids in profile: {sids}")
    print(f"  softwares in environment_softwares: {matching_sw}")
