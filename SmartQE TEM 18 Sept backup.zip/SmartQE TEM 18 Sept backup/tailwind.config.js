﻿/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        background: 'var(--color-bg-app)',
        card: 'var(--color-bg-card)',
        'card-hover': 'var(--color-bg-card-hover)',
        'card-subtle': 'var(--color-bg-card-subtle)',
        border: 'var(--color-border-app)',
        muted: 'var(--color-bg-muted)',
        'muted-foreground': 'var(--color-text-muted)',
        accent: '#f97316', // Neon Orange primary accent
        'accent-hover': '#ea580c',
        healthy: '#10b981',
        down: '#ef4444',
        degraded: '#f59e0b',
        maintenance: '#3b82f6',
      },
      fontFamily: {
        mono: ['Fira Code', 'JetBrains Mono', 'monospace'],
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
