# TESTOPS TEM CONTROL — Python FastAPI Microservice Backend

Production-ready, independent Python 3.12+ FastAPI microservice for **TESTOPS TEM CONTROL** built using PostgreSQL, Async SQLAlchemy 2.x, Alembic, JWT Authentication, and clean layered **DAO (Data Access Object)** Architecture.

---

## 🏗️ Architecture

```
Client (React 19 Frontend)
         │
         ▼
FastAPI Controllers (API Layer / app/api/v1/endpoints)
         │
         ▼
Business Services Layer (app/services)
         │
         ▼
DAO Layer (Data Access Objects / app/dao)
         │
         ▼
PostgreSQL Database (Async SQLAlchemy 2.x / asyncpg)
```

- **API Layer**: Route handling, Pydantic v2 input/output validation, Dependency Injection, Swagger OpenAPI documentation.
- **Service Layer**: Business rules, overlap validation, risk scoring, orchestration.
- **DAO Layer**: Raw database access, queries, pagination, search. Encapsulates all SQLAlchemy ORM operations.

---

## ⚡ Quick Start Options

### Option 1: Running with Docker Compose (Recommended)

```bash
cd backend
docker-compose up --build
```
This spins up:
- **PostgreSQL 16** on `localhost:5432`
- **Redis 7** on `localhost:6379`
- **FastAPI Microservice** on `http://localhost:8000`

Interactive OpenAPI Swagger Docs:
👉 **[http://localhost:8000/api/v1/docs](http://localhost:8000/api/v1/docs)**

---

### Option 2: Running Locally with Python

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Start FastAPI server
uvicorn app.main:app --reload --port 8000
```

---

## 🧪 Running Automated Tests

```bash
cd backend
pytest --cov=app --cov-report=term-missing
```

---

## 🔐 Default API Credentials

- **Admin Account**: `admin@testops.io` / `Admin@123`
- **Manager Account**: `ops@testops.io` / `Ops@123`
