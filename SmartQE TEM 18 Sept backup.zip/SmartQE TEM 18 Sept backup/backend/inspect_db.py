import sqlite3

conn = sqlite3.connect('smartqe_tem.db')
cursor = conn.cursor()

tables = cursor.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
print("==========================================")
print("📂 TABLES IN YOUR DATABASE (smartqe_tem.db):")
print("==========================================")
for t in tables:
    count = cursor.execute(f"SELECT COUNT(*) FROM {t[0]}").fetchone()[0]
    print(f"  • {t[0]} ({count} records)")

print("\n==========================================")
print("📋 SAMPLE RESERVATIONS DATA (table: reservations):")
print("==========================================")
reservations = cursor.execute("SELECT environment_name, business_unit, project, application, purpose, start_date, end_date FROM reservations LIMIT 5;").fetchall()
for r in reservations:
    print(f"  Env: {r[0]} | BU: {r[1]} | Proj: {r[2]} | App: {r[3]} | Purpose: {r[4]} ({r[5]} to {r[6]})")
