from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import get_password_hash
from app.dao.user_dao import user_dao
from app.dao.role_dao import role_dao
from app.dao.setting_dao import setting_dao
from app.models.role import Role


async def seed_initial_data(db: AsyncSession) -> None:
    """
    Seed initial system administrator accounts, default Super Admin role,
    initial role hierarchy, and default configuration.
    """
    # 1. Seed Roles (Only Super Admin initial system role)
    super_admin_role = None
    if await role_dao.count(db) == 0:
        super_admin_role = await role_dao.create(db, {
            "name": "Super Admin",
            "description": "Default initial system role with top-level administrative authority across the TEM application.",
            "role_order": 1,
            "is_system": True,
            "is_active": True,
            "status": "ACTIVE"
        })

        # Seed initial default settings pointing to Super Admin
        await setting_dao.set_value(db, "default_role_id", super_admin_role.id, "Default role assigned to new users")
        await setting_dao.set_value(db, "default_role_name", super_admin_role.name, "Default role name")
    else:
        super_admin_role = await role_dao.get_by_name(db, "Super Admin")

    # 2. Seed Initial Administrator User
    if await user_dao.count(db) == 0 and super_admin_role:
        admin_data = {
            "first_name": "System",
            "last_name": "Admin",
            "username": "admin",
            "email": "admin@testops.io",
            "hashed_password": get_password_hash("Admin@123"),
            "is_active": True,
            "status": "ACTIVE",
            "created_by": "System",
            "updated_by": "System",
        }
        await user_dao.create_user_with_roles(db, admin_data, [super_admin_role])


