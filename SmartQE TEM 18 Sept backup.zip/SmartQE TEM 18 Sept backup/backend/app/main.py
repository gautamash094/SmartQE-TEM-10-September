from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError

from app.core.config import settings
from app.core.exceptions import (
    AppException, app_exception_handler,
    validation_exception_handler, unhandled_exception_handler
)
from app.database.base import Base
from app.database.session import engine, fallback_to_sqlite, AsyncSessionLocal
from app.api.v1.router import api_router
from app.utils.seed_data import seed_initial_data
from app.core.logging import logger
import app.models.user
import app.models.role
import app.models.setting
import app.models.portfolio
import app.models.environment
import app.models.environment_profile
import app.models.reservation
import app.models.release
import app.models.incident
import app.models.runbook
import app.models.asset
import app.models.topology
import app.models.access
import app.models.auth_audit
import app.models.session
import app.models.user_group
import app.models.workflow
import app.models.email_notification
import app.models.provisioning



def sync_sqlite_columns(sync_conn):
    from sqlalchemy import inspect, text
    inspector = inspect(sync_conn)
    existing_tables = set(inspector.get_table_names())
    for table_name, table in Base.metadata.tables.items():
        if table_name in existing_tables:
            existing_columns = {col['name'] for col in inspector.get_columns(table_name)}
            for column in table.columns:
                if column.name not in existing_columns:
                    col_type = column.type.compile(dialect=sync_conn.dialect)
                    sql = f"ALTER TABLE {table_name} ADD COLUMN {column.name} {col_type}"
                    logger.info(f"SQLite Schema Sync: Executing '{sql}'")
                    sync_conn.execute(text(sql))


from app.services.reminder_scheduler import reminder_scheduler


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing TESTOPS TEM CONTROL FastAPI Microservice...")
    active_engine = engine

    # Attempt connecting to primary database (PostgreSQL)
    try:
        async with active_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    except Exception as e:
        logger.warning(f"Could not connect to primary database on port 5432 ({str(e)}). Switching to local SQLite engine...")
        active_engine = fallback_to_sqlite()
        async with active_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
            await conn.run_sync(sync_sqlite_columns)

    # Seed initial datasets using updated sessionmaker
    async with AsyncSessionLocal() as session:
        await seed_initial_data(session)

    # Start the automated 1-hour booking reminder background worker
    reminder_scheduler.start()

    logger.info("Database schema verified and initial mock data seeded successfully.")
    yield
    logger.info("Shutting down TESTOPS TEM CONTROL API...")
    reminder_scheduler.stop()


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Production-Ready Test Environment Management (TEM) System Microservice API backed by PostgreSQL and Async SQLAlchemy 2.x DAO Pattern.",
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url=f"{settings.API_V1_STR}/docs",
    redoc_url=f"{settings.API_V1_STR}/redoc",
    lifespan=lifespan
)

# Configure CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Exception Handlers
app.add_exception_handler(AppException, app_exception_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)
app.add_exception_handler(Exception, unhandled_exception_handler)

# Include API v1 Router
app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/")
async def root():
    return {
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "docs": f"{settings.API_V1_STR}/docs",
        "status": "OPERATIONAL"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
