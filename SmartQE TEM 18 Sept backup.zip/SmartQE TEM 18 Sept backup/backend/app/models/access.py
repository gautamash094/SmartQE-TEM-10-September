from sqlalchemy import Column, String, Integer, Boolean, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from app.database.base import Base


class ApplicationScreen(Base):
    __tablename__ = "application_screens"

    key = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    route = Column(String, nullable=False)
    parent_key = Column(String, nullable=True, index=True)
    category = Column(String, nullable=False, default="Core")
    display_order = Column(Integer, default=1, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)


class RoleScreenAccess(Base):
    __tablename__ = "role_screen_access"

    role_id = Column(String, ForeignKey("roles.id", ondelete="CASCADE"), nullable=False, index=True)
    screen_id = Column(String, ForeignKey("application_screens.id", ondelete="CASCADE"), nullable=False, index=True)
    has_access = Column(Boolean, default=True, nullable=False)

    role = relationship("Role", lazy="selectin")
    screen = relationship("ApplicationScreen", lazy="selectin")

    __table_args__ = (
        UniqueConstraint("role_id", "screen_id", name="uq_role_screen"),
    )
