import enum
from sqlalchemy import Column, String, Integer, Boolean, ForeignKey, UniqueConstraint, DateTime, Enum as SQLEnum
from sqlalchemy.orm import relationship
from app.database.base import Base


class TEMServiceType(str, enum.Enum):
    ENVIRONMENT_RESERVATION = "ENVIRONMENT_RESERVATION"
    ENVIRONMENT_PROVISIONING = "ENVIRONMENT_PROVISIONING"
    ENVIRONMENT_MONITORING = "ENVIRONMENT_MONITORING"
    ENVIRONMENT_HEALTH_CHECK = "ENVIRONMENT_HEALTH_CHECK"


SERVICE_DISPLAY_NAMES = {
    TEMServiceType.ENVIRONMENT_RESERVATION: "Environment Reservation",
    TEMServiceType.ENVIRONMENT_PROVISIONING: "Environment Provisioning",
    TEMServiceType.ENVIRONMENT_MONITORING: "Environment Monitoring",
    TEMServiceType.ENVIRONMENT_HEALTH_CHECK: "Environment Health Check",
}


class Workflow(Base):
    __tablename__ = "workflows"

    bu_id = Column(String, ForeignKey("business_units.id", ondelete="RESTRICT"), nullable=False, index=True)
    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=True)
    application_id = Column(String, nullable=False, index=True)
    application_name = Column(String, nullable=True)
    service_code = Column(String, nullable=False, index=True)
    service_name = Column(String, nullable=False)
    status = Column(String, default="ACTIVE", nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    # Audit tracking fields
    created_by = Column(String, default="Super Admin", nullable=False)
    modified_by = Column(String, default="Super Admin", nullable=False)

    # Relationships
    business_unit = relationship("BusinessUnit", lazy="selectin")
    approvers = relationship(
        "WorkflowApprover",
        back_populates="workflow",
        cascade="all, delete-orphan",
        order_by="WorkflowApprover.workflow_order",
        lazy="selectin"
    )

    __table_args__ = (
        UniqueConstraint("bu_id", "environment_id", "application_id", "service_code", name="uq_workflow_context"),
    )


class WorkflowApprover(Base):
    __tablename__ = "workflow_approvers"

    workflow_id = Column(String, ForeignKey("workflows.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    workflow_order = Column(Integer, nullable=False)
    created_by = Column(String, default="Super Admin", nullable=False)

    # Relationships
    workflow = relationship("Workflow", back_populates="approvers")
    user = relationship("User", lazy="selectin")

    __table_args__ = (
        UniqueConstraint("workflow_id", "workflow_order", name="uq_workflow_approver_order"),
        UniqueConstraint("workflow_id", "user_id", name="uq_workflow_approver_user"),
    )


class WorkflowExecution(Base):
    __tablename__ = "workflow_executions"

    workflow_id = Column(String, ForeignKey("workflows.id", ondelete="SET NULL"), nullable=True, index=True)
    entity_type = Column(String, nullable=False, default="RESERVATION", index=True)
    entity_id = Column(String, nullable=False, index=True)
    current_step_order = Column(Integer, default=1, nullable=False)
    total_steps = Column(Integer, default=1, nullable=False)
    status = Column(String, default="PENDING", nullable=False)  # PENDING, APPROVED, REJECTED
    created_by = Column(String, default="System", nullable=False)
    modified_by = Column(String, default="System", nullable=False)

    # Relationships
    workflow = relationship("Workflow", lazy="selectin")
    steps = relationship(
        "WorkflowExecutionStep",
        back_populates="execution",
        cascade="all, delete-orphan",
        order_by="WorkflowExecutionStep.workflow_order",
        lazy="selectin"
    )


class WorkflowExecutionStep(Base):
    __tablename__ = "workflow_execution_steps"

    execution_id = Column(String, ForeignKey("workflow_executions.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    workflow_order = Column(Integer, nullable=False)
    status = Column(String, default="WAITING", nullable=False)  # WAITING, PENDING, APPROVED, REJECTED
    action_by = Column(String, nullable=True)
    action_at = Column(DateTime(timezone=True), nullable=True)
    comments = Column(String, nullable=True)

    # Relationships
    execution = relationship("WorkflowExecution", back_populates="steps")
    user = relationship("User", lazy="selectin")

    __table_args__ = (
        UniqueConstraint("execution_id", "workflow_order", name="uq_execution_step_order"),
    )
