from sqlalchemy import Column, String, JSON, Enum as SQLEnum, Boolean
from app.database.base import Base
from app.models.environment import EnvironmentStatus


class EnvironmentProfile(Base):
    __tablename__ = "environment_profiles"

    name = Column(String, unique=True, index=True, nullable=False)
    type = Column(String, default="Development", nullable=False)
    description = Column(String, nullable=True)
    status = Column(SQLEnum(EnvironmentStatus, name="environment_status", create_constraint=False), default=EnvironmentStatus.HEALTHY, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)
    owner_team = Column(String, nullable=True)
    network_zone = Column(String, nullable=True)
    server_ids = Column(JSON, default=list, nullable=False)
    software_ids = Column(JSON, default=list, nullable=False)
