from sqlalchemy import Column, String, Text
from app.database.base import Base


class SystemSetting(Base):
    __tablename__ = "system_settings"

    key = Column(String, unique=True, index=True, nullable=False)
    value = Column(Text, nullable=True)
    description = Column(String, nullable=True)
