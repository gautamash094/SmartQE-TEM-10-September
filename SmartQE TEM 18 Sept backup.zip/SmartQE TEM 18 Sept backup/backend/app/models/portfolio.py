from sqlalchemy import Column, String, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from app.database.base import Base


class BusinessUnit(Base):
    __tablename__ = "business_units"

    name = Column(String, unique=True, index=True, nullable=False)
    code = Column(String, unique=True, index=True, nullable=False)
    lead = Column(String, nullable=True)
    description = Column(String, nullable=True)
    status = Column(String, default="ACTIVE", nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)


class Project(Base):
    __tablename__ = "projects"

    name = Column(String, index=True, nullable=False)
    code = Column(String, unique=True, index=True, nullable=False)
    business_unit = Column(String, index=True, nullable=False)
    lead = Column(String, nullable=True)
    status = Column(String, default="ACTIVE", nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)


class Component(Base):
    __tablename__ = "components"

    name = Column(String, index=True, nullable=False)
    code = Column(String, index=True, nullable=True)
    description = Column(String, nullable=True)
    business_unit = Column(String, index=True, nullable=False)
    project_name = Column(String, index=True, nullable=True)
    endpoint_url = Column(String, nullable=True)
    status = Column(String, default="ACTIVE", nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)


class Application(Base):
    __tablename__ = "applications"

    name = Column(String, unique=True, index=True, nullable=False)
    code = Column(String, unique=True, index=True, nullable=False)
    business_unit = Column(String, index=True, nullable=False)
    project_name = Column(String, index=True, nullable=False)
    component_name = Column(String, index=True, nullable=False)
    owner = Column(String, nullable=False)
    status = Column(String, default="ACTIVE", nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)
