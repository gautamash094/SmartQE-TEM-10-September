import enum
from sqlalchemy import Column, String, Float, JSON, Enum as SQLEnum, ForeignKey, Boolean
from sqlalchemy.orm import relationship, foreign
from app.database.base import Base


class EnvironmentStatus(str, enum.Enum):
    HEALTHY = "HEALTHY"
    DOWN = "DOWN"
    DEGRADED = "DEGRADED"
    MAINTENANCE = "MAINTENANCE"


class EnvironmentTier(str, enum.Enum):
    DEV = "DEV"
    SIT = "SIT"
    UAT = "UAT"
    PRE_PROD = "PRE-PROD"
    PERF = "PERF"
    QA = "QA"


class ComponentTopology(Base):
    __tablename__ = "component_topologies"

    environment_id = Column(String, ForeignKey("environments.id", ondelete="CASCADE"), nullable=False)
    name = Column(String, nullable=False)
    category = Column(String, nullable=False)  # SERVICE | COMPUTE | DATABASE | CACHE | QUEUE
    version = Column(String, nullable=False)
    status = Column(SQLEnum(EnvironmentStatus), default=EnvironmentStatus.HEALTHY, nullable=False)

    environment = relationship("Environment", back_populates="topology")


class Environment(Base):
    __tablename__ = "environments"

    name = Column(String, unique=True, index=True, nullable=False)
    tier = Column(SQLEnum(EnvironmentTier), nullable=False)
    team = Column(String, nullable=False)
    owner = Column(String, nullable=False)
    region = Column(String, nullable=False)
    status = Column(SQLEnum(EnvironmentStatus), default=EnvironmentStatus.HEALTHY, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)
    uptime = Column(Float, default=99.9, nullable=False)
    cpu_usage = Column(Float, default=0.0, nullable=False)
    memory_usage = Column(Float, default=0.0, nullable=False)
    storage_usage = Column(Float, default=0.0, nullable=False)
    tech_stack = Column(JSON, default=list, nullable=False)

    topology = relationship("ComponentTopology", back_populates="environment", cascade="all, delete-orphan", lazy="selectin")
    reservations = relationship("Reservation", primaryjoin="Environment.id == foreign(Reservation.environment_id)", back_populates="environment", cascade="all, delete-orphan")
    releases = relationship("Release", back_populates="environment", cascade="all, delete-orphan")
    incidents = relationship("Incident", back_populates="environment", cascade="all, delete-orphan")
