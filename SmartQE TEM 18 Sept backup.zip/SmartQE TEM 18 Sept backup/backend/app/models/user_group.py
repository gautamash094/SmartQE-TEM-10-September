from sqlalchemy import Column, String, Boolean, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from app.database.base import Base


class UserGroup(Base):
    __tablename__ = "user_groups"

    name = Column(String, unique=True, index=True, nullable=False)
    description = Column(String, nullable=True)
    bu_id = Column(String, ForeignKey("business_units.id", ondelete="RESTRICT"), nullable=False, index=True)
    status = Column(String, default="ACTIVE", nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    # Audit tracking fields
    created_by = Column(String, default="Super Admin", nullable=False)
    modified_by = Column(String, default="Super Admin", nullable=False)

    # Relationships
    business_unit = relationship("BusinessUnit", lazy="selectin")
    members = relationship("UserGroupMember", back_populates="group", cascade="all, delete-orphan", lazy="selectin")


class UserGroupMember(Base):
    __tablename__ = "user_group_members"

    group_id = Column(String, ForeignKey("user_groups.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_by = Column(String, default="Super Admin", nullable=False)

    # Relationships
    group = relationship("UserGroup", back_populates="members")
    user = relationship("User", lazy="selectin")

    __table_args__ = (
        UniqueConstraint("group_id", "user_id", name="uq_user_group_member"),
    )
