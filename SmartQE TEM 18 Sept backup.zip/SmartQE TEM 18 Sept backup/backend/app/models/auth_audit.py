from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, Boolean, ForeignKey
from app.database.base import Base


class AuthAuditLog(Base):
    __tablename__ = "auth_audit_logs"

    user_id = Column(String, nullable=True, index=True)
    username = Column(String, nullable=False, index=True)
    event_type = Column(String, nullable=False)  # LOGIN, FAILED_LOGIN, LOGOUT, PASSWORD_CHANGE, PASSWORD_RESET, ACCOUNT_LOCK
    status = Column(String, nullable=False, default="SUCCESS")  # SUCCESS, FAILED
    ip_address = Column(String, nullable=True)
    details = Column(String, nullable=True)


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token = Column(String, unique=True, index=True, nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    is_used = Column(Boolean, default=False, nullable=False)
