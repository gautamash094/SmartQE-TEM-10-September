from sqlalchemy import Column, String
from app.database.base import Base


class Application(Base):
    __tablename__ = "applications"

    name = Column(String, unique=True, index=True, nullable=False)
    code = Column(String, unique=True, index=True, nullable=False)
    business_unit = Column(String, nullable=False)
    owner = Column(String, nullable=False)
