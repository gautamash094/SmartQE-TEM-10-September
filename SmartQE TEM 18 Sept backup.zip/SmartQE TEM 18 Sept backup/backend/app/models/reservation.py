import enum
from sqlalchemy import Column, String, DateTime, Enum as SQLEnum, CheckConstraint, Boolean, Integer
from sqlalchemy.orm import relationship, foreign
from app.database.base import Base


class ReservationStatus(str, enum.Enum):
    CONFIRMED = "CONFIRMED"
    APPROVED = "APPROVED"
    CONFLICT = "CONFLICT"
    PENDING = "PENDING"
    CANCELLED = "CANCELLED"
    COMPLETED = "COMPLETED"
    REJECTED = "REJECTED"
    AUTO_REJECTED = "AUTO_REJECTED"


class ReservationMode(str, enum.Enum):
    SHARED = "SHARED"
    DISRUPTIVE = "DISRUPTIVE"


class AutoApprovalRule(str, enum.Enum):
    ALL_REQUESTS = "ALL_REQUESTS"
    PRIORITY_REQUESTS = "PRIORITY_REQUESTS"
    SHORT_REQUESTS = "SHORT_REQUESTS"


class ReservationPriority(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class Reservation(Base):
    __tablename__ = "reservations"
    __table_args__ = (
        CheckConstraint("end_date > start_date", name="chk_reservation_dates"),
    )

    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=False)
    
    # Domain Metadata
    business_unit = Column(String, nullable=False, index=True)
    project = Column(String, nullable=True, index=True, default="")
    application = Column(String, nullable=True, index=True, default="")
    
    purpose = Column(String, nullable=False)
    team = Column(String, nullable=False)
    requested_by = Column(String, nullable=False)
    
    # Priority
    priority = Column(
        SQLEnum(ReservationPriority, values_callable=lambda obj: [e.value for e in obj]),
        default=ReservationPriority.MEDIUM,
        nullable=False,
        index=True
    )
    
    # Auto Approval
    auto_approval_enabled = Column(Boolean, default=False, nullable=False, index=True)
    auto_approval_rule = Column(
        SQLEnum(AutoApprovalRule, values_callable=lambda obj: [e.value for e in obj]),
        nullable=True
    )

    # Date and Time (with hour, minute, second support)
    start_date = Column(DateTime(timezone=True), nullable=False, index=True)
    end_date = Column(DateTime(timezone=True), nullable=False, index=True)
    status = Column(
        SQLEnum(ReservationStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=ReservationStatus.CONFIRMED,
        nullable=False
    )
    reservation_mode = Column(
        SQLEnum(ReservationMode, values_callable=lambda obj: [e.value for e in obj]),
        default=ReservationMode.SHARED,
        nullable=False
    )

    # Data Ownership & Visibility Controls
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    assigned_user_id = Column(String, nullable=True, index=True)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    modified_by = Column(String, nullable=True)

    # Workflow Approval Tracking
    workflow_id = Column(String, nullable=True, index=True)
    current_workflow_order = Column(Integer, nullable=True)
    current_approver_id = Column(String, nullable=True, index=True)
    current_approver_name = Column(String, nullable=True)

    # Rejection Audit Tracking
    rejection_reason = Column(String, nullable=True)
    rejected_at = Column(DateTime(timezone=True), nullable=True)
    rejection_type = Column(String, nullable=True)  # 'MANUAL' or 'AUTO'
    audit_history = Column(String, nullable=True)  # JSON audit trail

    environment = relationship(
        "Environment",
        primaryjoin="foreign(Reservation.environment_id) == Environment.id",
        back_populates="reservations"
    )
