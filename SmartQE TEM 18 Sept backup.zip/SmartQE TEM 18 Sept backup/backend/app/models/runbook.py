import enum
from sqlalchemy import Column, String, Integer, JSON, Enum as SQLEnum, Boolean
from app.database.base import Base


class RunbookStatus(str, enum.Enum):
    IDLE = "IDLE"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


class Runbook(Base):
    __tablename__ = "runbooks"

    name = Column(String, nullable=False)
    category = Column(String, nullable=False)
    estimated_time_minutes = Column(Integer, default=5, nullable=False)
    last_executed = Column(String, nullable=True)
    target_environment_id = Column(String, nullable=True)
    status = Column(SQLEnum(RunbookStatus), default=RunbookStatus.IDLE, nullable=False)
    steps = Column(JSON, default=list, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)
