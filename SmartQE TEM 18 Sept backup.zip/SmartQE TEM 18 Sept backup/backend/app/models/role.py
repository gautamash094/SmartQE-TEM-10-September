from sqlalchemy import Column, String, Integer, Boolean
from app.database.base import Base


class Role(Base):
    __tablename__ = "roles"

    name = Column(String, unique=True, index=True, nullable=False)
    description = Column(String, nullable=True)
    role_order = Column(Integer, index=True, nullable=False, default=1)
    is_system = Column(Boolean, default=False, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    status = Column(String, default="ACTIVE", nullable=False)
