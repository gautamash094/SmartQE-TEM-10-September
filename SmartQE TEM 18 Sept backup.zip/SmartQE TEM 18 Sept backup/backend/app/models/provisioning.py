import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, Float, JSON, DateTime, Enum as SQLEnum, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
from app.database.base import Base


class ProvisioningStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    VALIDATING = "VALIDATING"
    VALIDATED = "VALIDATED"
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    QUEUED = "QUEUED"
    PROVISIONING = "PROVISIONING"
    CONFIGURING = "CONFIGURING"
    HEALTH_CHECK = "HEALTH_CHECK"
    READY = "READY"
    PARTIALLY_READY = "PARTIALLY_READY"
    FAILED = "FAILED"
    ROLLBACK = "ROLLBACK"
    DECOMMISSIONING = "DECOMMISSIONING"
    DECOMMISSIONED = "DECOMMISSIONED"
    CANCELLED = "CANCELLED"


class StepStatus(str, enum.Enum):
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    ROLLED_BACK = "ROLLED_BACK"


class StepCategory(str, enum.Enum):
    INFRASTRUCTURE = "INFRASTRUCTURE"
    NETWORK = "NETWORK"
    STORAGE = "STORAGE"
    SOFTWARE = "SOFTWARE"
    CONFIGURATION = "CONFIGURATION"
    DEPLOYMENT = "DEPLOYMENT"
    HEALTH_CHECK = "HEALTH_CHECK"
    TEARDOWN = "TEARDOWN"


class ProvisioningMode(str, enum.Enum):
    ON_DEMAND = "ON_DEMAND"
    SCHEDULED = "SCHEDULED"
    TEMPLATE_BASED = "TEMPLATE_BASED"


class ProvisioningTemplate(Base):
    __tablename__ = "provisioning_templates"

    name = Column(String, unique=True, index=True, nullable=False)
    description = Column(String, nullable=True)
    environment_type = Column(String, default="QA", nullable=False)
    business_unit = Column(String, nullable=True)
    project_name = Column(String, nullable=True)
    compute_type = Column(String, default="VM", nullable=False)  # VM | CONTAINER | KUBERNETES | BARE_METAL
    cpu_cores = Column(Integer, default=4, nullable=False)
    ram_gb = Column(Float, default=16.0, nullable=False)
    storage_gb = Column(Float, default=100.0, nullable=False)
    os_disk_gb = Column(Float, default=50.0, nullable=False)
    data_disk_gb = Column(Float, default=50.0, nullable=False)
    software_stack = Column(JSON, default=list, nullable=False)
    network_config = Column(JSON, default=dict, nullable=False)
    env_vars = Column(JSON, default=list, nullable=False)
    secrets_references = Column(JSON, default=list, nullable=False)
    health_check_config = Column(JSON, default=dict, nullable=False)
    estimated_duration_min = Column(Integer, default=15, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    tags = Column(JSON, default=list, nullable=False)


class ProvisioningRequest(Base):
    __tablename__ = "provisioning_requests"

    request_number = Column(String, unique=True, index=True, nullable=False)  # e.g., PR-2026-001
    environment_name = Column(String, index=True, nullable=False)
    environment_type = Column(String, default="QA", nullable=False)  # DEV, QA, SIT, UAT, Performance, Regression, Pre-Production
    business_unit = Column(String, index=True, nullable=False)
    project_name = Column(String, index=True, nullable=False)
    application_name = Column(String, index=True, nullable=False)
    component_name = Column(String, nullable=True)
    environment_owner = Column(String, nullable=False)
    requested_by = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    provisioning_mode = Column(
        SQLEnum(ProvisioningMode, values_callable=lambda obj: [e.value for e in obj]),
        default=ProvisioningMode.ON_DEMAND,
        nullable=False
    )
    template_id = Column(String, ForeignKey("provisioning_templates.id", ondelete="SET NULL"), nullable=True)

    # Scheduling
    scheduled_start = Column(DateTime(timezone=True), nullable=True)
    scheduled_end = Column(DateTime(timezone=True), nullable=True)
    execution_started_at = Column(DateTime(timezone=True), nullable=True)
    execution_completed_at = Column(DateTime(timezone=True), nullable=True)

    # Status & Progress
    status = Column(
        SQLEnum(ProvisioningStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=ProvisioningStatus.DRAFT,
        nullable=False,
        index=True
    )
    progress_percentage = Column(Float, default=0.0, nullable=False)
    current_step_index = Column(Integer, default=0, nullable=False)
    total_steps = Column(Integer, default=0, nullable=False)
    health_status = Column(String, default="PENDING", nullable=False)  # PENDING | HEALTHY | DEGRADED | FAILED
    failure_reason = Column(Text, nullable=True)
    failure_step_id = Column(String, nullable=True)
    retry_count = Column(Integer, default=0, nullable=False)

    # Linked TEM entities
    environment_id = Column(String, ForeignKey("environments.id", ondelete="SET NULL"), nullable=True, index=True)
    booking_id = Column(String, nullable=True)
    incident_id = Column(String, nullable=True)

    # Configurations & Payloads
    resource_specs = Column(JSON, default=dict, nullable=False)
    software_stack = Column(JSON, default=list, nullable=False)
    configuration_payload = Column(JSON, default=dict, nullable=False)
    dependency_graph = Column(JSON, default=list, nullable=False)
    validation_results = Column(JSON, default=dict, nullable=False)
    health_check_results = Column(JSON, default=list, nullable=False)
    custom_tags = Column(JSON, default=dict, nullable=False)

    # Relationships
    steps = relationship("ProvisioningStep", back_populates="request", cascade="all, delete-orphan", order_by="ProvisioningStep.step_order", lazy="selectin")
    resources = relationship("ProvisioningResource", back_populates="request", cascade="all, delete-orphan", lazy="selectin")
    dependencies = relationship("ProvisioningDependency", back_populates="request", cascade="all, delete-orphan", lazy="selectin")
    logs = relationship("ProvisioningLog", back_populates="request", cascade="all, delete-orphan", order_by="ProvisioningLog.timestamp", lazy="selectin")
    approvals = relationship("ProvisioningApproval", back_populates="request", cascade="all, delete-orphan", lazy="selectin")
    audits = relationship("ProvisioningAudit", back_populates="request", cascade="all, delete-orphan", order_by="ProvisioningAudit.timestamp", lazy="selectin")
    template = relationship("ProvisioningTemplate", foreign_keys=[template_id], lazy="selectin")


class ProvisioningStep(Base):
    __tablename__ = "provisioning_steps"

    request_id = Column(String, ForeignKey("provisioning_requests.id", ondelete="CASCADE"), nullable=False, index=True)
    step_order = Column(Integer, nullable=False)
    step_key = Column(String, nullable=False)  # e.g., ALLOCATE_SERVER, ALLOCATE_IP, INSTALL_OS, INSTALL_JAVA
    step_name = Column(String, nullable=False)
    category = Column(
        SQLEnum(StepCategory, values_callable=lambda obj: [e.value for e in obj]),
        default=StepCategory.INFRASTRUCTURE,
        nullable=False
    )
    provider_type = Column(String, default="MOCK", nullable=False)  # MOCK | AWS | AZURE | GCP | VMWARE | KUBERNETES | BARE_METAL
    status = Column(
        SQLEnum(StepStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=StepStatus.PENDING,
        nullable=False,
        index=True
    )
    estimated_duration_sec = Column(Integer, default=30, nullable=False)
    actual_duration_sec = Column(Float, default=0.0, nullable=False)
    started_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    error_message = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0, nullable=False)
    max_retries = Column(Integer, default=3, nullable=False)
    parameters = Column(JSON, default=dict, nullable=False)
    execution_output = Column(JSON, default=dict, nullable=False)
    rollback_supported = Column(Boolean, default=True, nullable=False)
    rollback_status = Column(String, default="NOT_APPLICABLE", nullable=False)

    request = relationship("ProvisioningRequest", back_populates="steps")


class ProvisioningResource(Base):
    __tablename__ = "provisioning_resources"

    request_id = Column(String, ForeignKey("provisioning_requests.id", ondelete="CASCADE"), nullable=False, index=True)
    resource_type = Column(String, nullable=False)  # COMPUTE | IP | STORAGE | DATABASE | LOAD_BALANCER | CONTAINER | POD
    resource_name = Column(String, nullable=False)
    resource_id = Column(String, nullable=False)  # AST-1001 or vm-4890 or 10.0.12.44
    provider = Column(String, default="MOCK", nullable=False)
    status = Column(String, default="ALLOCATED", nullable=False)  # ALLOCATED | ATTACHED | RELEASED | FAILED
    configuration = Column(JSON, default=dict, nullable=False)
    allocated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    released_at = Column(DateTime(timezone=True), nullable=True)

    request = relationship("ProvisioningRequest", back_populates="resources")


class ProvisioningDependency(Base):
    __tablename__ = "provisioning_dependencies"

    request_id = Column(String, ForeignKey("provisioning_requests.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String, nullable=False)
    dependency_type = Column(String, nullable=False)  # DATABASE | EXTERNAL_API | MESSAGE_QUEUE | SERVICE | MIDDLEWARE
    target_endpoint = Column(String, nullable=True)
    required = Column(Boolean, default=True, nullable=False)
    status = Column(String, default="RESOLVED", nullable=False)  # RESOLVED | PROVISIONED | EXISTING | UNREACHABLE
    health_status = Column(String, default="HEALTHY", nullable=False)  # HEALTHY | DEGRADED | DOWN | UNKNOWN
    details = Column(JSON, default=dict, nullable=False)

    request = relationship("ProvisioningRequest", back_populates="dependencies")


class ProvisioningLog(Base):
    __tablename__ = "provisioning_logs"

    request_id = Column(String, ForeignKey("provisioning_requests.id", ondelete="CASCADE"), nullable=False, index=True)
    step_id = Column(String, ForeignKey("provisioning_steps.id", ondelete="CASCADE"), nullable=True, index=True)
    step_key = Column(String, nullable=True)
    log_level = Column(String, default="INFO", nullable=False)  # INFO | WARN | ERROR | SUCCESS | DEBUG
    message = Column(Text, nullable=False)
    source = Column(String, default="ORCHESTRATOR", nullable=False)  # ORCHESTRATOR | PROVIDER | HEALTH_CHECK | USER
    details = Column(JSON, default=dict, nullable=False)
    timestamp = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False, index=True)

    request = relationship("ProvisioningRequest", back_populates="logs")


class ProvisioningApproval(Base):
    __tablename__ = "provisioning_approvals"

    request_id = Column(String, ForeignKey("provisioning_requests.id", ondelete="CASCADE"), nullable=False, index=True)
    approver_role = Column(String, default="Environment Manager", nullable=False)
    approver_user = Column(String, nullable=True)
    status = Column(String, default="PENDING", nullable=False)  # PENDING | APPROVED | REJECTED | AUTO_APPROVED
    comments = Column(Text, nullable=True)
    auto_approved = Column(Boolean, default=False, nullable=False)
    decision_reason = Column(String, nullable=True)
    approved_at = Column(DateTime(timezone=True), nullable=True)

    request = relationship("ProvisioningRequest", back_populates="approvals")


class ProvisioningAudit(Base):
    __tablename__ = "provisioning_audits"

    request_id = Column(String, ForeignKey("provisioning_requests.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String, nullable=False)  # CREATE | VALIDATE | APPROVE | REJECT | PROVISION | RETRY | ROLLBACK | DECOMMISSION
    performed_by = Column(String, default="System Admin", nullable=False)
    old_status = Column(String, nullable=True)
    new_status = Column(String, nullable=True)
    details = Column(JSON, default=dict, nullable=False)
    ip_address = Column(String, default="127.0.0.1", nullable=True)
    timestamp = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    request = relationship("ProvisioningRequest", back_populates="audits")
