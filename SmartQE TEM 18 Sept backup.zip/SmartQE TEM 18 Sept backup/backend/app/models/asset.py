import enum
from sqlalchemy import Column, String, Integer, Float, JSON, DateTime, Enum as SQLEnum, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from app.database.base import Base


class AssetType(str, enum.Enum):
    SERVER = "SERVER"
    DATABASE = "DATABASE"
    CLOUD_RESOURCE = "CLOUD_RESOURCE"
    NETWORK_COMPONENT = "NETWORK_COMPONENT"
    STORAGE = "STORAGE"
    SOFTWARE = "SOFTWARE"


class InfrastructureType(str, enum.Enum):
    ON_PREMISES = "ON_PREMISES"
    CLOUD = "CLOUD"
    HYBRID = "HYBRID"


class CloudProvider(str, enum.Enum):
    AWS = "AWS"
    AZURE = "Azure"
    GCP = "GCP"
    OCI = "OCI"
    ALIBABA = "Alibaba Cloud"
    ON_PREM = "On-Premises"
    OTHER = "Other"


class AssetStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    MAINTENANCE = "MAINTENANCE"
    PROVISIONING = "PROVISIONING"
    RETIRED = "RETIRED"
    DECOMMISSIONED = "DECOMMISSIONED"


class Asset(Base):
    __tablename__ = "assets"

    # Core Identifiers
    asset_id = Column(String, unique=True, index=True, nullable=False)  # e.g. AST-1001
    name = Column(String, index=True, nullable=False)
    asset_type = Column(
        SQLEnum(AssetType, values_callable=lambda obj: [e.value for e in obj]),
        default=AssetType.SERVER,
        nullable=False,
        index=True
    )
    infrastructure_type = Column(
        SQLEnum(InfrastructureType, values_callable=lambda obj: [e.value for e in obj]),
        default=InfrastructureType.CLOUD,
        nullable=False,
        index=True
    )
    cloud_provider = Column(
        SQLEnum(CloudProvider, values_callable=lambda obj: [e.value for e in obj]),
        default=CloudProvider.AWS,
        nullable=False,
        index=True
    )
    
    # Enterprise Hierarchy Association
    business_unit = Column(String, index=True, nullable=False)
    account_name = Column(String, index=True, nullable=False)  # or project_name
    environment_id = Column(String, nullable=True, index=True)
    environment_name = Column(String, nullable=True, index=True)
    environment_type = Column(String, default="UAT / Staging", nullable=True)
    application_name = Column(String, nullable=True, index=True)

    # Technical Specifications & Network
    ip_address = Column(String, nullable=True, index=True)
    hostname = Column(String, nullable=True, index=True)
    operating_system = Column(String, nullable=True)
    os_version = Column(String, nullable=True)
    runtime_stack = Column(String, nullable=True)
    cpu_cores = Column(Integer, default=4, nullable=True)
    ram_gb = Column(Float, default=16.0, nullable=True)
    storage_gb = Column(Float, default=250.0, nullable=True)

    # Cloud & Datacenter Location
    region = Column(String, default="us-east-1", nullable=True)
    availability_zone = Column(String, default="us-east-1a", nullable=True)
    datacenter = Column(String, nullable=True)
    rack_unit = Column(String, nullable=True)
    instance_id = Column(String, nullable=True)  # e.g. i-082194bfa2
    instance_type = Column(String, nullable=True)  # e.g. t3.xlarge
    vpc_subnet = Column(String, nullable=True)

    # Linked Software / Services (JSON Array of Software objects or names)
    installed_software = Column(JSON, default=list, nullable=False)

    # Lifecycle & Ownership
    status = Column(
        SQLEnum(AssetStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=AssetStatus.ACTIVE,
        nullable=False,
        index=True
    )
    is_active = Column(Boolean, default=True, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)
    owner_team = Column(String, default="Platform QE", nullable=False)
    responsible_person = Column(String, default="Ops Engineer", nullable=True)
    cost_center = Column(String, default="CC-ENG-402", nullable=True)
    end_of_life_date = Column(String, nullable=True)  # YYYY-MM-DD
    notes = Column(Text, nullable=True)
    tags = Column(JSON, default=dict, nullable=False)

    # Audit & Tracking
    updated_by = Column(String, default="System Admin", nullable=False)

    audit_logs = relationship("AssetAuditLog", back_populates="asset", cascade="all, delete-orphan", lazy="selectin")


class AssetAuditLog(Base):
    __tablename__ = "asset_audit_logs"

    asset_id = Column(String, ForeignKey("assets.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String, nullable=False)  # CREATE, UPDATE, STATUS_CHANGE, LINK_ENV, UNLINK_ENV, RETIRE
    changed_by = Column(String, default="System User", nullable=False)
    changed_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    field_name = Column(String, nullable=True)
    old_value = Column(String, nullable=True)
    new_value = Column(String, nullable=True)
    notes = Column(Text, nullable=True)

    asset = relationship("Asset", back_populates="audit_logs")
