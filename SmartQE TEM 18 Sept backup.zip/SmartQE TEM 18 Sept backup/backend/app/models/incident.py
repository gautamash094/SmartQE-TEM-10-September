import enum
from sqlalchemy import Column, String, DateTime, Enum as SQLEnum, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from app.database.base import Base


class IncidentSeverity(str, enum.Enum):
    SEV1 = "SEV1"
    SEV2 = "SEV2"
    SEV3 = "SEV3"
    SEV4 = "SEV4"


class IncidentStatus(str, enum.Enum):
    OPEN = "OPEN"
    INVESTIGATING = "INVESTIGATING"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


class Incident(Base):
    __tablename__ = "incidents"

    incident_code = Column(String, unique=True, index=True, nullable=False) # e.g. INC-88252
    title = Column(String, nullable=False)
    severity = Column(SQLEnum(IncidentSeverity), default=IncidentSeverity.SEV3, nullable=False)
    environment_id = Column(String, ForeignKey("environments.id", ondelete="CASCADE"), nullable=False, index=True)
    environment_name = Column(String, nullable=False)
    assignee = Column(String, nullable=False)
    assignee_id = Column(String, nullable=True, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    status = Column(SQLEnum(IncidentStatus), default=IncidentStatus.OPEN, nullable=False)
    opened_at = Column(DateTime(timezone=True), nullable=False)
    resolved_at = Column(DateTime(timezone=True), nullable=True)
    description = Column(String, nullable=True)

    environment = relationship("Environment", back_populates="incidents")
