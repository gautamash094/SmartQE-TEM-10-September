from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database.base import Base


class UserSession(Base):
    __tablename__ = "user_sessions"

    session_id = Column(String, unique=True, index=True, nullable=False)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    last_activity_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True, nullable=False)
    absolute_expires_at = Column(DateTime(timezone=True), index=True, nullable=False)
    status = Column(String, default="ACTIVE", nullable=False)  # ACTIVE, EXPIRED, LOGGED_OUT
    ip_address = Column(String, nullable=True)
    user_agent = Column(String, nullable=True)
    logout_at = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    user = relationship("User", lazy="selectin")
