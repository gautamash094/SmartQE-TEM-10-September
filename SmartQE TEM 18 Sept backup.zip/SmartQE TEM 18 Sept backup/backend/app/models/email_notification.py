import enum
from sqlalchemy import Column, String, Integer, DateTime
from app.database.base import Base


class NotificationType(str, enum.Enum):
    BOOKING_CREATED = "BOOKING_CREATED"
    APPROVAL_REQUEST = "APPROVAL_REQUEST"
    APPROVAL_COMPLETED = "APPROVAL_COMPLETED"
    REJECTION = "REJECTION"
    FINAL_APPROVAL = "FINAL_APPROVAL"
    BOOKING_REMINDER = "BOOKING_REMINDER"
    AUTO_APPROVAL = "AUTO_APPROVAL"


class NotificationStatus(str, enum.Enum):
    PENDING = "PENDING"
    SENT = "SENT"
    FAILED = "FAILED"


class EmailNotification(Base):
    __tablename__ = "email_notifications"

    booking_id = Column(String, nullable=False, index=True)
    notification_type = Column(String, nullable=False, index=True)
    step_order = Column(Integer, nullable=True, index=True)
    recipient_to = Column(String, nullable=False)
    recipient_cc = Column(String, nullable=True)
    subject = Column(String, nullable=False)
    body = Column(String, nullable=False)
    status = Column(String, default=NotificationStatus.PENDING.value, nullable=False, index=True)
    sent_at = Column(DateTime(timezone=True), nullable=True)
    error_message = Column(String, nullable=True)
    retry_count = Column(Integer, default=0, nullable=False)
