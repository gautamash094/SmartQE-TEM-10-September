from datetime import datetime, timezone
import enum
from sqlalchemy import Column, String, Boolean, ForeignKey, Table, DateTime, Enum as SQLEnum
from sqlalchemy.orm import relationship
from app.database.base import Base


class UserRole(str, enum.Enum):
    ADMIN = "ADMIN"
    MANAGER = "MANAGER"
    USER = "USER"
    READ_ONLY = "READ_ONLY"


# Many-to-Many association table for User <-> Role
user_roles = Table(
    "user_roles",
    Base.metadata,
    Column("user_id", String, ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("role_id", String, ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
)


class User(Base):
    __tablename__ = "users"

    first_name = Column(String, nullable=False, default="")
    last_name = Column(String, nullable=False, default="")
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=True, default="")
    business_unit_id = Column(String, ForeignKey("business_units.id", ondelete="SET NULL"), nullable=True)
    role = Column(SQLEnum(UserRole), default=UserRole.USER, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    status = Column(String, default="ACTIVE", nullable=False)

    # Audit tracking fields
    created_by = Column(String, default="Super Admin", nullable=False)
    updated_by = Column(String, default="Super Admin", nullable=False)

    # Legacy full_name column mapping if present in DB
    _legacy_full_name = Column("full_name", String, nullable=True)

    # Relationships
    roles = relationship("Role", secondary=user_roles, lazy="selectin", cascade="all, delete")
    business_unit = relationship("BusinessUnit", lazy="selectin")

    @property
    def full_name(self) -> str:
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}".strip()
        if self.first_name or self.last_name:
            return (self.first_name or self.last_name).strip()
        if self._legacy_full_name and self._legacy_full_name.strip():
            return self._legacy_full_name.strip()
        if self.username.lower() == "admin":
            return "System Admin"
        return self.username
