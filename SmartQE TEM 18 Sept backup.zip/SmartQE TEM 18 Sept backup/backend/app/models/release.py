import enum
from sqlalchemy import Column, String, DateTime, Enum as SQLEnum, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from app.database.base import Base


class ReleaseRisk(str, enum.Enum):
    LOW_RISK = "LOW RISK"
    MEDIUM_RISK = "MEDIUM RISK"
    HIGH_RISK = "HIGH RISK"


class ReleaseStatus(str, enum.Enum):
    SCHEDULED = "SCHEDULED"
    IN_PROGRESS = "IN_PROGRESS"
    DEPLOYED = "DEPLOYED"
    FAILED = "FAILED"


class Release(Base):
    __tablename__ = "releases"

    name = Column(String, nullable=False)
    version = Column(String, nullable=False)
    environment_id = Column(String, ForeignKey("environments.id", ondelete="CASCADE"), nullable=False, index=True)
    environment_name = Column(String, nullable=False)
    lead = Column(String, nullable=False)
    lead_id = Column(String, nullable=True, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    change_ref = Column(String, nullable=False)
    
    # Date and Time (with hour, minute, second support)
    scheduled_date = Column(DateTime(timezone=True), nullable=False)
    risk = Column(SQLEnum(ReleaseRisk), default=ReleaseRisk.LOW_RISK, nullable=False)
    status = Column(SQLEnum(ReleaseStatus), default=ReleaseStatus.SCHEDULED, nullable=False)

    environment = relationship("Environment", back_populates="releases")
