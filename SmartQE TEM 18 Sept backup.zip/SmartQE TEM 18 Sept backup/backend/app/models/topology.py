import enum
from sqlalchemy import Column, String, Boolean, Float, Text, Enum as SQLEnum, ForeignKey, UniqueConstraint
from app.database.base import Base


class TopologyRelationshipType(str, enum.Enum):
    HOSTED_ON = "HOSTED_ON"
    RUNS_ON = "RUNS_ON"
    DEPENDS_ON = "DEPENDS_ON"
    CONNECTS_TO = "CONNECTS_TO"
    CALLS = "CALLS"
    SENDS_DATA_TO = "SENDS_DATA_TO"
    USES_DATABASE = "USES_DATABASE"
    USES_SERVICE = "USES_SERVICE"
    PART_OF = "PART_OF"
    DEPLOYED_ON = "DEPLOYED_ON"


class TopologyNodeType(str, enum.Enum):
    ENVIRONMENT = "ENVIRONMENT"
    APPLICATION = "APPLICATION"
    SERVER = "SERVER"
    SOFTWARE = "SOFTWARE"
    DATABASE = "DATABASE"
    MICROSERVICE = "MICROSERVICE"
    CLOUD_RESOURCE = "CLOUD_RESOURCE"
    NETWORK_COMPONENT = "NETWORK_COMPONENT"
    STORAGE = "STORAGE"


class TopologyRelationship(Base):
    __tablename__ = "topology_relationships"
    __table_args__ = (
        UniqueConstraint("source_id", "target_id", "relationship_type", name="uq_topology_relationship"),
    )

    source_id = Column(String, index=True, nullable=False)
    source_type = Column(String, nullable=False) # e.g. APPLICATION, SERVER, SOFTWARE
    source_name = Column(String, nullable=False)

    target_id = Column(String, index=True, nullable=False)
    target_type = Column(String, nullable=False)
    target_name = Column(String, nullable=False)

    relationship_type = Column(
        SQLEnum(TopologyRelationshipType, name="topology_rel_type", create_constraint=False),
        default=TopologyRelationshipType.DEPENDS_ON,
        nullable=False
    )

    environment_id = Column(String, index=True, nullable=True)
    environment_name = Column(String, nullable=True)

    port = Column(String, nullable=True)
    protocol = Column(String, nullable=True) # HTTPS, gRPC, JDBC, TCP, etc.
    latency_ms = Column(Float, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    notes = Column(Text, nullable=True)

    created_by = Column(String, default="system", nullable=False)
    updated_by = Column(String, default="system", nullable=False)
