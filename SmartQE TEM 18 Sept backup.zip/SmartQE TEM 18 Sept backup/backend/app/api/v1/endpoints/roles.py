from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.dao.role_dao import role_dao
from app.schemas.role import (
    RoleCreate, RoleUpdate, RoleRead, RoleReorderRequest
)
from app.schemas.common import StandardResponse

router = APIRouter(prefix="/roles", tags=["Role Management"])


@router.get("", response_model=StandardResponse[List[RoleRead]])
async def get_roles(db: AsyncSession = Depends(get_db)):
    """
    Retrieve all roles ordered by role_order (hierarchy rank).
    """
    roles = await role_dao.get_ordered_roles(db)
    if not roles:
        super_admin = await role_dao.create(db, {
            "name": "Super Admin",
            "description": "Default initial system role with top-level administrative authority across the TEM application.",
            "role_order": 1,
            "is_system": True,
            "is_active": True,
            "status": "ACTIVE"
        })
        roles = [super_admin]
    return StandardResponse(
        success=True,
        message="Roles retrieved successfully",
        data=[RoleRead.model_validate(r) for r in roles]
    )


@router.post("", response_model=StandardResponse[RoleRead], status_code=status.HTTP_201_CREATED)
async def create_role(role_in: RoleCreate, db: AsyncSession = Depends(get_db)):
    """
    Create a new role with mandatory non-empty name and uniqueness validation.
    """
    clean_name = role_in.name.strip()
    if not clean_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Role Name is mandatory and cannot be empty or contain only spaces."
        )

    # Check for duplicate role name (case-insensitive)
    existing = await role_dao.get_by_name(db, clean_name)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A role with this name already exists."
        )

    role_data = role_in.model_dump()
    role_data["name"] = clean_name
    role_data["is_system"] = False  # Only pre-seeded roles like Super Admin are system roles
    role_data["status"] = "ACTIVE" if role_in.is_active else "INACTIVE"

    created = await role_dao.create_role(db, role_data)
    return StandardResponse(
        success=True,
        message="Role created successfully",
        data=RoleRead.model_validate(created)
    )


@router.get("/{role_id}", response_model=StandardResponse[RoleRead])
async def get_role(role_id: str, db: AsyncSession = Depends(get_db)):
    """
    Get a single role by ID.
    """
    role = await role_dao.get_by_id(db, role_id)
    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Role with ID {role_id} not found."
        )
    return StandardResponse(
        success=True,
        message="Role details retrieved successfully",
        data=RoleRead.model_validate(role)
    )


@router.put("/reorder", response_model=StandardResponse[List[RoleRead]])
async def reorder_roles(reorder_req: RoleReorderRequest, db: AsyncSession = Depends(get_db)):
    """
    Batch update role orders / hierarchy.
    """
    items = [item.model_dump() for item in reorder_req.roles]
    updated_roles = await role_dao.reorder_roles(db, items)
    return StandardResponse(
        success=True,
        message="Role hierarchy order updated successfully",
        data=[RoleRead.model_validate(r) for r in updated_roles]
    )


@router.put("/{role_id}", response_model=StandardResponse[RoleRead])
async def update_role(role_id: str, role_in: RoleUpdate, db: AsyncSession = Depends(get_db)):
    """
    Update an existing role's name, description, status, or order.
    """
    role = await role_dao.get_by_id(db, role_id)
    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Role with ID {role_id} not found."
        )

    update_data = role_in.model_dump(exclude_unset=True)

    if "name" in update_data and update_data["name"] is not None:
        clean_name = update_data["name"].strip()
        if not clean_name:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Role Name cannot be empty or contain only spaces."
            )
        # Check duplicate if name is changing
        if clean_name.lower() != role.name.lower():
            existing = await role_dao.get_by_name(db, clean_name)
            if existing and existing.id != role_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="A role with this name already exists."
                )
        update_data["name"] = clean_name

    if "is_active" in update_data and update_data["is_active"] is not None:
        if role.is_system and not update_data["is_active"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="The default system role (Super Admin) cannot be deactivated."
            )
        update_data["status"] = "ACTIVE" if update_data["is_active"] else "INACTIVE"

    updated = await role_dao.update(db, role, update_data)
    return StandardResponse(
        success=True,
        message="Role updated successfully",
        data=RoleRead.model_validate(updated)
    )


@router.patch("/{role_id}/toggle-status", response_model=StandardResponse[RoleRead])
async def toggle_role_status(role_id: str, db: AsyncSession = Depends(get_db)):
    """
    Toggle a role's active/inactive status.
    """
    role = await role_dao.get_by_id(db, role_id)
    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Role with ID {role_id} not found."
        )

    if role.is_system:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The default system role (Super Admin) cannot be deactivated."
        )

    new_active = not getattr(role, "is_active", True)
    updated = await role_dao.update(db, role, {
        "is_active": new_active,
        "status": "ACTIVE" if new_active else "INACTIVE"
    })
    status_str = "activated" if new_active else "deactivated"
    return StandardResponse(
        success=True,
        message=f"Role {status_str} successfully",
        data=RoleRead.model_validate(updated)
    )


@router.delete("/{role_id}", response_model=StandardResponse[dict])
async def delete_role(role_id: str, db: AsyncSession = Depends(get_db)):
    """
    Delete or deactivate a role. System roles cannot be deleted.
    """
    role = await role_dao.get_by_id(db, role_id)
    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Role with ID {role_id} not found."
        )

    if role.is_system:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The default system role (Super Admin) cannot be deleted."
        )

    await role_dao.delete(db, role_id)
    return StandardResponse(
        success=True,
        message="Role deleted successfully",
        data={"id": role_id}
    )
