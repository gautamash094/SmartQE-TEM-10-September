import asyncio
import json
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.dao.provisioning_dao import (
    provisioning_request_dao,
    provisioning_template_dao,
    provisioning_step_dao,
    provisioning_resource_dao,
    provisioning_dependency_dao,
    provisioning_log_dao,
    provisioning_approval_dao,
    provisioning_audit_dao,
)
from app.models.provisioning import (
    ProvisioningRequest,
    ProvisioningStep,
    ProvisioningResource,
    ProvisioningDependency,
    ProvisioningLog,
    ProvisioningApproval,
    ProvisioningStatus,
    StepStatus,
)
from app.schemas.provisioning import (
    ProvisioningRequestCreate,
    ProvisioningRequestUpdate,
    ProvisioningRequestListItem,
    ProvisioningRequestDetailResponse,
    ProvisioningTemplateCreate,
    ProvisioningTemplateUpdate,
    ProvisioningTemplateResponse,
    ProvisioningLogResponse,
    ApprovalActionRequest,
    RetryActionRequest,
    DashboardKPIsResponse,
)
from app.services.provisioning.preflight_validator import preflight_validator
from app.services.provisioning.orchestrator import orchestrator
from app.services.provisioning.event_stream import event_stream

router = APIRouter(prefix="/provisioning", tags=["Environment Provisioning"])


# =============================================================
# TEMPLATES ENDPOINTS
# =============================================================
@router.get("/templates", response_model=List[ProvisioningTemplateResponse])
async def list_templates(db: AsyncSession = Depends(get_db)):
    """List all available environment provisioning templates."""
    templates = await provisioning_template_dao.get_active_templates(db)
    return templates


@router.post("/templates", response_model=ProvisioningTemplateResponse, status_code=status.HTTP_201_CREATED)
async def create_template(
    template_in: ProvisioningTemplateCreate,
    db: AsyncSession = Depends(get_db),
):
    """Create a new reusable environment provisioning template."""
    existing = await provisioning_template_dao.get_by_name(db, template_in.name)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Template with name '{template_in.name}' already exists.",
        )
    template = await provisioning_template_dao.create(db, template_in.model_dump())
    return template


@router.get("/templates/{template_id}", response_model=ProvisioningTemplateResponse)
async def get_template(template_id: str, db: AsyncSession = Depends(get_db)):
    """Get single template details by ID."""
    template = await provisioning_template_dao.get_by_id(db, template_id)
    if not template:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template not found.")
    return template


# =============================================================
# DASHBOARD KPIS
# =============================================================
@router.get("/dashboard-kpis", response_model=DashboardKPIsResponse)
async def get_dashboard_kpis(db: AsyncSession = Depends(get_db)):
    """Fetch top-level aggregate KPIs for the Provisioning Dashboard."""
    kpis = await provisioning_request_dao.get_dashboard_kpis(db)
    return kpis


# =============================================================
# PROVISIONING REQUESTS ENDPOINTS
# =============================================================
@router.get("/requests")
async def list_provisioning_requests(
    business_unit: Optional[str] = Query("ALL"),
    project_name: Optional[str] = Query("ALL"),
    application_name: Optional[str] = Query("ALL"),
    environment_name: Optional[str] = None,
    status_filter: Optional[str] = Query("ALL", alias="status"),
    owner: Optional[str] = Query("ALL"),
    provisioning_mode: Optional[str] = Query("ALL"),
    search: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """List provisioning requests with filtering, search, and pagination."""
    skip = (page - 1) * page_size
    items, total = await provisioning_request_dao.filter_requests(
        db,
        business_unit=business_unit,
        project_name=project_name,
        application_name=application_name,
        environment_name=environment_name,
        status=status_filter,
        owner=owner,
        provisioning_mode=provisioning_mode,
        search=search,
        skip=skip,
        limit=page_size,
    )
    return {
        "items": [ProvisioningRequestListItem.model_validate(item) for item in items],
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size if total > 0 else 1,
    }


@router.post("/requests", response_model=ProvisioningRequestDetailResponse, status_code=status.HTTP_201_CREATED)
async def create_provisioning_request(
    request_in: ProvisioningRequestCreate,
    db: AsyncSession = Depends(get_db),
):
    """
    Create a new Environment Provisioning request:
    1. Validates input & generates request number (PR-2026-xxxx)
    2. Runs pre-flight validation
    3. Generates sequential provisioning plan steps
    4. Evaluates approval policy (Auto-Approved vs Pending Manager Approval)
    5. Stores dependency mapping and configurations
    """
    # 1. Run Pre-flight Validation
    validation_report = await preflight_validator.validate(db, request_in.model_dump())
    if validation_report["has_blocking_errors"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "message": "Pre-flight validation failed with blocking errors.",
                "validation_report": validation_report,
            },
        )

    # 2. Determine Request Number & Approval Rule
    req_number = await provisioning_request_dao.get_next_request_number(db)
    
    # Auto-approval rule: Dev/QA low-resource is AUTO_APPROVED; High resource or Prod-like requires Manager approval
    cpu = request_in.resource_specs.get("cpu_cores", 4)
    ram = request_in.resource_specs.get("ram_gb", 16.0)
    is_prod_tier = request_in.environment_type.upper() in ["PRE-PRODUCTION", "PERFORMANCE", "UAT"]
    needs_manual_approval = is_prod_tier or cpu > 16 or ram > 64

    initial_status = ProvisioningStatus.PENDING_APPROVAL if needs_manual_approval else ProvisioningStatus.APPROVED

    # Create Request Record
    req_data = request_in.model_dump(exclude={"auto_validate"})
    req_data["request_number"] = req_number
    req_data["status"] = initial_status
    req_data["validation_results"] = validation_report
    req_data["health_status"] = "PENDING"
    req_data["progress_percentage"] = 0.0

    req_obj = await provisioning_request_dao.create(db, req_data)

    # 3. Create Approval Record
    approval = ProvisioningApproval(
        request_id=req_obj.id,
        approver_role="Environment Manager" if needs_manual_approval else "System Auto-Rule",
        approver_user=None if needs_manual_approval else "Auto-Approval Engine",
        status="PENDING" if needs_manual_approval else "AUTO_APPROVED",
        auto_approved=not needs_manual_approval,
        decision_reason="Standard QA/Dev policy auto-approved" if not needs_manual_approval else "High resource / Production-like tier requires manager review",
        approved_at=datetime.now(timezone.utc) if not needs_manual_approval else None,
    )
    db.add(approval)

    # 4. Generate & Insert Provisioning Plan Steps
    plan_steps = orchestrator.generate_plan_steps(
        req_obj.id,
        req_obj.resource_specs or {},
        req_obj.software_stack or [],
        req_obj.configuration_payload or {},
    )
    for step_data in plan_steps:
        step_rec = ProvisioningStep(**step_data)
        db.add(step_rec)
    req_obj.total_steps = len(plan_steps)

    # 5. Insert Dependencies if any
    for dep in request_in.dependency_graph:
        dep_rec = ProvisioningDependency(
            request_id=req_obj.id,
            name=dep.get("name", "Dependency"),
            dependency_type=dep.get("type", "SERVICE"),
            target_endpoint=dep.get("endpoint"),
            required=dep.get("required", True),
            status=dep.get("status", "RESOLVED"),
            health_status=dep.get("health_status", "HEALTHY"),
            details=dep.get("details", {}),
        )
        db.add(dep_rec)

    # 6. Audit & Log Initial Creation
    await db.flush()
    await provisioning_request_dao.append_audit(
        db, req_obj.id, "CREATE_REQUEST", req_obj.requested_by,
        new_status=initial_status, details={"request_number": req_number}
    )
    await provisioning_request_dao.append_log(
        db, req_obj.id,
        f"Request {req_number} submitted by {req_obj.requested_by}. Pre-flight validation status: {validation_report['overall_status']}.",
        log_level="INFO", source="USER"
    )

    await db.commit()
    detailed_req = await provisioning_request_dao.get_detailed(db, req_obj.id)
    return ProvisioningRequestDetailResponse.model_validate(detailed_req)


@router.get("/requests/{request_id}", response_model=ProvisioningRequestDetailResponse)
async def get_provisioning_request_detail(
    request_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Get complete details, steps, resources, logs, dependencies, and audits for a request."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Provisioning request not found.")
    return ProvisioningRequestDetailResponse.model_validate(request)


@router.put("/requests/{request_id}", response_model=ProvisioningRequestDetailResponse)
async def update_provisioning_request(
    request_id: str,
    update_in: ProvisioningRequestUpdate,
    db: AsyncSession = Depends(get_db),
):
    """Update draft provisioning request configuration."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")
    if request.status not in [ProvisioningStatus.DRAFT, ProvisioningStatus.VALIDATING, ProvisioningStatus.PENDING_APPROVAL]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot edit request in '{request.status}' state.",
        )

    updated = await provisioning_request_dao.update(db, request, update_in.model_dump(exclude_unset=True))
    detailed = await provisioning_request_dao.get_detailed(db, updated.id)
    return ProvisioningRequestDetailResponse.model_validate(detailed)


@router.delete("/requests/{request_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_provisioning_request(
    request_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Delete a draft or cancelled provisioning request."""
    request = await provisioning_request_dao.get_by_id(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")
    if request.status in [ProvisioningStatus.PROVISIONING, ProvisioningStatus.CONFIGURING, ProvisioningStatus.HEALTH_CHECK]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete an actively running provisioning request. Rollback or cancel it first.",
        )
    await provisioning_request_dao.delete(db, request_id)
    return None


@router.post("/requests/{request_id}/validate")
async def validate_request_preflight(
    request_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Run real-time pre-flight validation on an existing request."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")

    report = await preflight_validator.validate(db, {
        "environment_name": request.environment_name,
        "scheduled_start": request.scheduled_start,
        "scheduled_end": request.scheduled_end,
        "resource_specs": request.resource_specs or {},
        "software_stack": request.software_stack or [],
        "configuration_payload": request.configuration_payload or {},
        "dependency_graph": [d.to_dict() for d in request.dependencies] if request.dependencies else [],
    })

    request.validation_results = report
    await db.commit()
    return report


@router.post("/requests/{request_id}/approve", response_model=ProvisioningRequestDetailResponse)
async def approve_or_reject_request(
    request_id: str,
    action_in: ApprovalActionRequest,
    db: AsyncSession = Depends(get_db),
):
    """Approve or reject a pending provisioning request."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")
    if request.status != ProvisioningStatus.PENDING_APPROVAL:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Request is in '{request.status}' status, cannot approve/reject.",
        )

    is_approved = action_in.action.upper() == "APPROVE"
    new_status = ProvisioningStatus.APPROVED if is_approved else ProvisioningStatus.CANCELLED

    # Update Approval Record
    approval = await provisioning_approval_dao.get_by_request(db, request_id)
    if approval:
        approval.status = "APPROVED" if is_approved else "REJECTED"
        approval.approver_user = action_in.approver_user or "Environment Manager"
        approval.comments = action_in.comments
        approval.approved_at = datetime.now(timezone.utc)

    old_status = request.status
    request.status = new_status
    await db.commit()

    await provisioning_request_dao.append_audit(
        db, request_id, f"APPROVAL_{action_in.action.upper()}", action_in.approver_user or "Manager",
        old_status=old_status, new_status=new_status, details={"comments": action_in.comments}
    )
    await provisioning_request_dao.append_log(
        db, request_id,
        f"Request {action_in.action.upper()}D by {action_in.approver_user or 'Manager'}. Comments: {action_in.comments or 'None'}",
        log_level="INFO" if is_approved else "WARN", source="USER"
    )

    detailed = await provisioning_request_dao.get_detailed(db, request_id)
    return ProvisioningRequestDetailResponse.model_validate(detailed)


@router.post("/requests/{request_id}/provision", response_model=ProvisioningRequestDetailResponse)
async def trigger_async_provisioning(
    request_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Enqueues an approved provisioning request for background asynchronous execution."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")
    if request.status not in [ProvisioningStatus.APPROVED, ProvisioningStatus.DRAFT, ProvisioningStatus.VALIDATED]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot start provisioning for request in '{request.status}' state. Must be APPROVED.",
        )

    request.status = ProvisioningStatus.QUEUED
    await db.commit()

    # Launch non-blocking background orchestration task
    asyncio.create_task(orchestrator.execute_request_async(request_id, start_step_index=1))

    detailed = await provisioning_request_dao.get_detailed(db, request_id)
    return ProvisioningRequestDetailResponse.model_validate(detailed)


@router.post("/requests/{request_id}/retry", response_model=ProvisioningRequestDetailResponse)
async def retry_failed_provisioning(
    request_id: str,
    retry_in: RetryActionRequest,
    db: AsyncSession = Depends(get_db),
):
    """Idempotently retries a failed step or resumes execution from the first incomplete step."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")
    if request.status != ProvisioningStatus.FAILED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot retry request in '{request.status}' state. Only FAILED requests can be retried.",
        )

    await orchestrator.retry_step(request_id, retry_in.step_id)
    detailed = await provisioning_request_dao.get_detailed(db, request_id)
    return ProvisioningRequestDetailResponse.model_validate(detailed)


@router.post("/requests/{request_id}/rollback", response_model=ProvisioningRequestDetailResponse)
async def rollback_provisioning(
    request_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Executes a rollback to cleanly tear down and release any partially provisioned resources."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")

    await orchestrator.rollback_request(request_id)
    detailed = await provisioning_request_dao.get_detailed(db, request_id)
    return ProvisioningRequestDetailResponse.model_validate(detailed)


@router.post("/requests/{request_id}/decommission", response_model=ProvisioningRequestDetailResponse)
async def decommission_environment(
    request_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Executes complete environment decommissioning, releasing IP and updating TEM Inventory."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")

    await orchestrator.decommission_request(request_id)
    detailed = await provisioning_request_dao.get_detailed(db, request_id)
    return ProvisioningRequestDetailResponse.model_validate(detailed)


@router.get("/requests/{request_id}/logs", response_model=List[ProvisioningLogResponse])
async def get_execution_logs(
    request_id: str,
    step_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """Fetch chronological execution stdout/diagnostic logs for a request."""
    logs = await provisioning_log_dao.get_logs_for_request(db, request_id, step_id=step_id)
    return logs


@router.get("/requests/{request_id}/health")
async def get_health_check_results(
    request_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Fetch post-provisioning automated probe test results."""
    request = await provisioning_request_dao.get_detailed(db, request_id)
    if not request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found.")
    return {
        "health_status": request.health_status,
        "probes": request.health_check_results or [],
    }


@router.get("/requests/{request_id}/events")
async def stream_provisioning_events(request_id: str):
    """Server-Sent Events (SSE) stream for real-time progress, status, and stdout logs."""
    queue = event_stream.subscribe(request_id)

    async def event_generator():
        try:
            yield f"data: {json.dumps({'event': 'CONNECTED', 'request_id': request_id})}\n\n"
            while True:
                payload = await queue.get()
                yield f"data: {json.dumps(payload)}\n\n"
        except asyncio.CancelledError:
            pass
        finally:
            event_stream.unsubscribe(request_id, queue)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
