from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.environment_profile import (
    EnvironmentProfileCreate, EnvironmentProfileUpdate, EnvironmentProfileRead
)
from app.schemas.common import StandardResponse
from app.services.environment_profile_service import environment_profile_service
from app.dependencies.auth import get_current_user_optional
from app.models.user import User

router = APIRouter(prefix="/environment-profiles", tags=["Environment Profiles"])


@router.get("", response_model=StandardResponse[List[EnvironmentProfileRead]])
async def get_environment_profiles(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    profiles = await environment_profile_service.get_all_profiles(db, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment profiles retrieved successfully",
        data=profiles
    )


@router.post("", response_model=StandardResponse[EnvironmentProfileRead], status_code=status.HTTP_201_CREATED)
async def create_environment_profile(
    profile_in: EnvironmentProfileCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    created = await environment_profile_service.create_profile(db, profile_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment profile registered successfully",
        data=created
    )


@router.get("/{profile_id}", response_model=StandardResponse[EnvironmentProfileRead])
async def get_environment_profile_by_id(
    profile_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    profile = await environment_profile_service.get_profile_by_id(db, profile_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment profile details retrieved",
        data=profile
    )


@router.put("/{profile_id}", response_model=StandardResponse[EnvironmentProfileRead])
async def update_environment_profile(
    profile_id: str,
    profile_in: EnvironmentProfileUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await environment_profile_service.update_profile(db, profile_id, profile_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment profile updated successfully",
        data=updated
    )


@router.patch("/{profile_id}/toggle-status", response_model=StandardResponse[EnvironmentProfileRead])
async def toggle_environment_profile_status(
    profile_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await environment_profile_service.toggle_profile_status(db, profile_id, current_user=current_user)
    status_str = "activated" if updated.is_active else "deactivated"
    return StandardResponse(
        success=True,
        message=f"Environment profile {status_str} successfully",
        data=updated
    )


@router.delete("/{profile_id}", response_model=StandardResponse[dict])
async def delete_environment_profile(
    profile_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    await environment_profile_service.delete_profile(db, profile_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment profile deactivated successfully",
        data={"id": profile_id, "is_active": False}
    )
