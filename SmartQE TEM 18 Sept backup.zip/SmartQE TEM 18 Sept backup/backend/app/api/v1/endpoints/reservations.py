from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional, require_screen_access
from app.models.user import User
from app.schemas.reservation import (
    ReservationCreate,
    ReservationUpdate,
    ReservationRead,
    ReservationRejectRequest,
    ReservationApprovalActionRequest,
)
from app.schemas.common import StandardResponse, MetaParams
from app.services.reservation_service import reservation_service

router = APIRouter(prefix="/reservations", tags=["Reservations / Bookings"])


@router.get("", response_model=StandardResponse[List[ReservationRead]])
async def get_reservations(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=100, ge=1, le=1000),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    items, total = await reservation_service.get_reservations_paginated(
        db, page=page, page_size=pageSize, current_user=current_user
    )
    return StandardResponse(
        success=True,
        message="Reservations retrieved successfully",
        data=items,
        meta=MetaParams(page=page, pageSize=pageSize, total=total)
    )


@router.post("", response_model=StandardResponse[ReservationRead], status_code=status.HTTP_201_CREATED)
async def create_reservation(
    res_in: ReservationCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    created, msg = await reservation_service.create_reservation(db, res_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message=msg,
        data=created
    )


@router.post("/auto-reject-expired", response_model=StandardResponse[dict])
async def auto_reject_expired(
    db: AsyncSession = Depends(get_db)
):
    count = await reservation_service.auto_reject_expired(db)
    return StandardResponse(
        success=True,
        message=f"{count} expired reservation(s) auto-rejected",
        data={"auto_rejected_count": count}
    )


@router.get("/{res_id}", response_model=StandardResponse[ReservationRead])
async def get_reservation_by_id(
    res_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    res = await reservation_service.get_reservation_by_id(db, res_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Reservation details retrieved",
        data=res
    )


@router.post("/{res_id}/approval", response_model=StandardResponse[ReservationRead])
async def process_reservation_approval_action(
    res_id: str,
    body: ReservationApprovalActionRequest,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated, msg = await reservation_service.process_approval_action(
        db, res_id, action=body.action, comments=body.comments, current_user=current_user
    )
    return StandardResponse(
        success=True,
        message=msg,
        data=updated
    )


@router.post("/{res_id}/reject", response_model=StandardResponse[ReservationRead])
async def reject_reservation(
    res_id: str,
    body: ReservationRejectRequest = ReservationRejectRequest(),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    rejected = await reservation_service.reject_reservation(db, res_id, reason=body.reason, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Reservation rejected successfully. The approval workflow has been terminated.",
        data=rejected
    )


@router.post("/{res_id}/cancel", response_model=StandardResponse[ReservationRead])
async def cancel_reservation(
    res_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    cancelled = await reservation_service.cancel_reservation(db, res_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Reservation cancelled successfully.",
        data=cancelled
    )


@router.put("/{res_id}", response_model=StandardResponse[ReservationRead])
async def update_reservation(
    res_id: str,
    res_in: ReservationUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await reservation_service.update_reservation(db, res_id, res_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Reservation updated successfully",
        data=updated
    )


@router.delete("/{res_id}", response_model=StandardResponse[dict])
async def delete_reservation(
    res_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    await reservation_service.delete_reservation(db, res_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Reservation cancelled successfully.",
        data={"id": res_id}
    )
