from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.schemas.common import StandardResponse
from app.schemas.email_notification import EmailNotificationRead, EmailNotificationRetryResponse
from app.dao.email_notification_dao import email_notification_dao
from app.services.email_service import email_service
from app.services.reminder_scheduler import process_upcoming_booking_reminders

router = APIRouter(prefix="/notifications", tags=["Email Notifications & Reminders"])


@router.get("/booking/{booking_id}", response_model=StandardResponse[List[EmailNotificationRead]])
async def get_booking_notifications(
    booking_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Fetches the full email notification audit trail for a specific booking.
    """
    records = await email_notification_dao.get_by_booking_id(db, booking_id)
    items = [EmailNotificationRead.model_validate(r) for r in records]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(items)} notification record(s) for booking {booking_id}",
        data=items
    )


@router.post("/{notification_id}/retry", response_model=StandardResponse[EmailNotificationRead])
async def retry_email_notification(
    notification_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Retries sending a pending or failed email notification record.
    """
    success, message, record = await email_service.retry_notification(db, notification_id)
    if not record:
        return StandardResponse(
            success=False,
            message=message,
            data=None
        )

    return StandardResponse(
        success=success,
        message=message,
        data=EmailNotificationRead.model_validate(record)
    )


@router.post("/trigger-reminders", response_model=StandardResponse[dict])
async def trigger_booking_reminders(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Manually triggers the scan for upcoming reservations starting within the next 1 hour.
    """
    sent_count = await process_upcoming_booking_reminders(db)
    return StandardResponse(
        success=True,
        message=f"Upcoming reminder check executed. {sent_count} reminder(s) dispatched.",
        data={"reminders_dispatched": sent_count}
    )
