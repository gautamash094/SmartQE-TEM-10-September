from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.access import (
    ApplicationScreenRead,
    RoleAccessRead,
    RoleAccessUpdate,
    UserPermissionsRead,
)
from app.schemas.common import StandardResponse
from app.services.access_service import access_service
from app.dao.user_dao import user_dao

router = APIRouter(prefix="/access", tags=["Access Management"])


@router.get("/screens", response_model=StandardResponse[List[ApplicationScreenRead]])
async def get_screens(db: AsyncSession = Depends(get_db)):
    screens = await access_service.get_all_screens(db)
    return StandardResponse(
        success=True,
        message="Application screens retrieved successfully",
        data=screens,
    )


@router.get("/roles/{role_id}", response_model=StandardResponse[RoleAccessRead])
async def get_role_access(role_id: str, db: AsyncSession = Depends(get_db)):
    role_access = await access_service.get_role_access(db, role_id)
    return StandardResponse(
        success=True,
        message=f"Access configuration for role retrieved",
        data=role_access,
    )


@router.put("/roles/{role_id}", response_model=StandardResponse[RoleAccessRead])
async def update_role_access(
    role_id: str,
    access_in: RoleAccessUpdate,
    db: AsyncSession = Depends(get_db),
):
    updated = await access_service.update_role_access(db, role_id, access_in.screen_ids)
    return StandardResponse(
        success=True,
        message="Role access configuration updated successfully",
        data=updated,
    )


@router.get("/user-permissions", response_model=StandardResponse[UserPermissionsRead])
async def get_user_permissions(
    userId: Optional[str] = None,
    username: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    target_user = None
    if userId:
        target_user = await user_dao.get_user_by_id_with_relations(db, userId)
    elif username:
        target_user = await user_dao.get_by_username(db, username)
    else:
        # Default to first active user in system (e.g. admin)
        all_users = await user_dao.get_all_users_with_relations(db, is_active=True)
        if all_users:
            target_user = all_users[0]

    if not target_user:
        return StandardResponse(
            success=False,
            message="User not found",
            data=UserPermissionsRead(
                user_id="",
                username="guest",
                roles=[],
                is_super_admin=False,
                allowed_screen_keys=[],
                allowed_routes=[],
            ),
        )

    permissions = await access_service.get_effective_user_permissions(db, target_user.id)
    return StandardResponse(
        success=True,
        message="User effective permissions calculated",
        data=permissions,
    )
