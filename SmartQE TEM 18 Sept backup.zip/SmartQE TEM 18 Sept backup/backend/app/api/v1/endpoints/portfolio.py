from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.core.exceptions import EntityNotFoundException, PermissionDeniedException
from app.dependencies.auth import get_current_user_optional, is_user_super_admin
from app.models.user import User
from app.dao.portfolio_dao import business_unit_dao, project_dao, component_dao, application_dao
from app.schemas.portfolio import (
    BusinessUnitCreate, BusinessUnitUpdate, BusinessUnitRead,
    ProjectCreate, ProjectUpdate, ProjectRead,
    ComponentCreate, ComponentUpdate, ComponentRead,
    ApplicationCreate, ApplicationUpdate, ApplicationRead,
    PortfolioHierarchy
)
from app.schemas.common import StandardResponse

router = APIRouter(prefix="/portfolio", tags=["Portfolio & Applications"])


def _check_entity_ownership(entity: any, current_user: Optional[User]):
    if is_user_super_admin(current_user):
        return
    if not current_user:
        raise PermissionDeniedException("Authentication required.")
    user_id = str(getattr(current_user, "id", "") or "")
    username = str(getattr(current_user, "username", "") or "").lower()
    full_name = str(getattr(current_user, "full_name", "") or username).lower()
    owner_id = str(getattr(entity, "owner_id", "") or "")
    created_by = str(getattr(entity, "created_by", "") or "").lower()
    if owner_id != user_id and created_by not in (username, full_name):
        raise PermissionDeniedException("You do not have permission to view, modify, or delete this record.")


# --- Business Units ---
@router.get("/business-units", response_model=StandardResponse[List[BusinessUnitRead]])
async def get_business_units(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    bus = await business_unit_dao.get_all_for_user(db, current_user)
    return StandardResponse(
        success=True,
        message="Business units retrieved successfully",
        data=[BusinessUnitRead.model_validate(b) for b in bus]
    )


@router.post("/business-units", response_model=StandardResponse[BusinessUnitRead], status_code=status.HTTP_201_CREATED)
async def create_business_unit(
    bu_in: BusinessUnitCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    data = bu_in.model_dump()
    if current_user:
        data["created_by"] = current_user.username
        data["owner_id"] = str(current_user.id)
    else:
        data["created_by"] = "Super Admin"
        data["owner_id"] = None
    created = await business_unit_dao.create(db, data)
    return StandardResponse(
        success=True,
        message="Business unit created successfully",
        data=BusinessUnitRead.model_validate(created)
    )


@router.put("/business-units/{bu_id}", response_model=StandardResponse[BusinessUnitRead])
async def update_business_unit(
    bu_id: str,
    bu_in: BusinessUnitUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    bu = await business_unit_dao.get_by_id(db, bu_id)
    if not bu:
        raise EntityNotFoundException("BusinessUnit", bu_id)
    _check_entity_ownership(bu, current_user)
    update_data = bu_in.model_dump(exclude_unset=True)
    # Prevent overwriting ownership
    update_data.pop("created_by", None)
    update_data.pop("owner_id", None)
    if "is_active" in update_data and update_data["is_active"] is not None:
        update_data["status"] = "ACTIVE" if update_data["is_active"] else "INACTIVE"
    elif "status" in update_data and update_data["status"] is not None:
        update_data["is_active"] = update_data["status"] == "ACTIVE"
    if current_user:
        update_data["modified_by"] = getattr(current_user, "username", "Super Admin")
    updated = await business_unit_dao.update(db, bu, update_data)
    return StandardResponse(
        success=True,
        message="Business unit updated successfully",
        data=BusinessUnitRead.model_validate(updated)
    )


@router.patch("/business-units/{bu_id}/toggle-status", response_model=StandardResponse[BusinessUnitRead])
async def toggle_business_unit_status(
    bu_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    bu = await business_unit_dao.get_by_id(db, bu_id)
    if not bu:
        raise EntityNotFoundException("BusinessUnit", bu_id)
    _check_entity_ownership(bu, current_user)
    new_active = not getattr(bu, "is_active", True)
    updated = await business_unit_dao.update(db, bu, {
        "is_active": new_active,
        "status": "ACTIVE" if new_active else "INACTIVE",
        "modified_by": getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
    })
    status_str = "activated" if new_active else "deactivated"
    return StandardResponse(
        success=True,
        message=f"Business unit {status_str} successfully",
        data=BusinessUnitRead.model_validate(updated)
    )


@router.delete("/business-units/{bu_id}", response_model=StandardResponse[dict])
async def delete_business_unit(
    bu_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    bu = await business_unit_dao.get_by_id(db, bu_id)
    if not bu:
        raise EntityNotFoundException("BusinessUnit", bu_id)
    _check_entity_ownership(bu, current_user)
    # Soft deactivation: preserve all data and child relationships
    await business_unit_dao.update(db, bu, {
        "is_active": False,
        "status": "INACTIVE",
        "modified_by": getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
    })
    return StandardResponse(
        success=True,
        message="Business unit deactivated successfully",
        data={"id": bu_id, "is_active": False}
    )


# --- Projects ---
@router.get("/projects", response_model=StandardResponse[List[ProjectRead]])
async def get_projects(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    projs = await project_dao.get_all_for_user(db, current_user)
    return StandardResponse(
        success=True,
        message="Projects retrieved successfully",
        data=[ProjectRead.model_validate(p) for p in projs]
    )


@router.post("/projects", response_model=StandardResponse[ProjectRead], status_code=status.HTTP_201_CREATED)
async def create_project(
    proj_in: ProjectCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    data = proj_in.model_dump()
    if current_user:
        data["created_by"] = current_user.username
        data["owner_id"] = str(current_user.id)
    else:
        data["created_by"] = "Super Admin"
        data["owner_id"] = None
    created = await project_dao.create(db, data)
    return StandardResponse(
        success=True,
        message="Project created successfully",
        data=ProjectRead.model_validate(created)
    )


@router.put("/projects/{proj_id}", response_model=StandardResponse[ProjectRead])
async def update_project(
    proj_id: str,
    proj_in: ProjectUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    proj = await project_dao.get_by_id(db, proj_id)
    if not proj:
        raise EntityNotFoundException("Project", proj_id)
    _check_entity_ownership(proj, current_user)
    update_data = proj_in.model_dump(exclude_unset=True)
    # Prevent overwriting ownership
    update_data.pop("created_by", None)
    update_data.pop("owner_id", None)
    if "is_active" in update_data and update_data["is_active"] is not None:
        update_data["status"] = "ACTIVE" if update_data["is_active"] else "INACTIVE"
    elif "status" in update_data and update_data["status"] is not None:
        update_data["is_active"] = update_data["status"] == "ACTIVE"
    if current_user:
        update_data["modified_by"] = getattr(current_user, "username", "Super Admin")
    updated = await project_dao.update(db, proj, update_data)
    return StandardResponse(
        success=True,
        message="Project updated successfully",
        data=ProjectRead.model_validate(updated)
    )


@router.patch("/projects/{proj_id}/toggle-status", response_model=StandardResponse[ProjectRead])
async def toggle_project_status(
    proj_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    proj = await project_dao.get_by_id(db, proj_id)
    if not proj:
        raise EntityNotFoundException("Project", proj_id)
    _check_entity_ownership(proj, current_user)
    new_active = not getattr(proj, "is_active", True)
    updated = await project_dao.update(db, proj, {
        "is_active": new_active,
        "status": "ACTIVE" if new_active else "INACTIVE",
        "modified_by": getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
    })
    status_str = "activated" if new_active else "deactivated"
    return StandardResponse(
        success=True,
        message=f"Project {status_str} successfully",
        data=ProjectRead.model_validate(updated)
    )


@router.delete("/projects/{proj_id}", response_model=StandardResponse[dict])
async def delete_project(
    proj_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    proj = await project_dao.get_by_id(db, proj_id)
    if not proj:
        raise EntityNotFoundException("Project", proj_id)
    _check_entity_ownership(proj, current_user)
    # Soft deactivation: preserve all data and relationships
    await project_dao.update(db, proj, {
        "is_active": False,
        "status": "INACTIVE",
        "modified_by": getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
    })
    return StandardResponse(
        success=True,
        message="Project deactivated successfully",
        data={"id": proj_id, "is_active": False}
    )


# --- Components ---
@router.get("/components", response_model=StandardResponse[List[ComponentRead]])
async def get_components(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    comps = await component_dao.get_all_for_user(db, current_user)
    return StandardResponse(
        success=True,
        message="Components retrieved successfully",
        data=[ComponentRead.model_validate(c) for c in comps]
    )


@router.post("/components", response_model=StandardResponse[ComponentRead], status_code=status.HTTP_201_CREATED)
async def create_component(
    comp_in: ComponentCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    data = comp_in.model_dump()
    if current_user:
        data["created_by"] = current_user.username
        data["owner_id"] = str(current_user.id)
    else:
        data["created_by"] = "Super Admin"
        data["owner_id"] = None
    created = await component_dao.create(db, data)
    return StandardResponse(
        success=True,
        message="Component created successfully",
        data=ComponentRead.model_validate(created)
    )


@router.put("/components/{comp_id}", response_model=StandardResponse[ComponentRead])
async def update_component(
    comp_id: str,
    comp_in: ComponentUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    comp = await component_dao.get_by_id(db, comp_id)
    if not comp:
        raise EntityNotFoundException("Component", comp_id)
    _check_entity_ownership(comp, current_user)
    update_data = comp_in.model_dump(exclude_unset=True)
    # Prevent overwriting ownership
    update_data.pop("created_by", None)
    update_data.pop("owner_id", None)
    if "is_active" in update_data and update_data["is_active"] is not None:
        update_data["status"] = "ACTIVE" if update_data["is_active"] else "INACTIVE"
    elif "status" in update_data and update_data["status"] is not None:
        update_data["is_active"] = update_data["status"] == "ACTIVE"
    if current_user:
        update_data["modified_by"] = getattr(current_user, "username", "Super Admin")
    updated = await component_dao.update(db, comp, update_data)
    return StandardResponse(
        success=True,
        message="Component updated successfully",
        data=ComponentRead.model_validate(updated)
    )


@router.patch("/components/{comp_id}/toggle-status", response_model=StandardResponse[ComponentRead])
async def toggle_component_status(
    comp_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    comp = await component_dao.get_by_id(db, comp_id)
    if not comp:
        raise EntityNotFoundException("Component", comp_id)
    _check_entity_ownership(comp, current_user)
    new_active = not getattr(comp, "is_active", True)
    updated = await component_dao.update(db, comp, {
        "is_active": new_active,
        "status": "ACTIVE" if new_active else "INACTIVE",
        "modified_by": getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
    })
    status_str = "activated" if new_active else "deactivated"
    return StandardResponse(
        success=True,
        message=f"Component {status_str} successfully",
        data=ComponentRead.model_validate(updated)
    )


@router.delete("/components/{comp_id}", response_model=StandardResponse[dict])
async def delete_component(
    comp_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    comp = await component_dao.get_by_id(db, comp_id)
    if not comp:
        raise EntityNotFoundException("Component", comp_id)
    _check_entity_ownership(comp, current_user)
    # Soft deactivation: preserve all data and relationships
    await component_dao.update(db, comp, {
        "is_active": False,
        "status": "INACTIVE",
        "modified_by": getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
    })
    return StandardResponse(
        success=True,
        message="Component deactivated successfully",
        data={"id": comp_id, "is_active": False}
    )


# --- Applications ---
@router.get("/applications", response_model=StandardResponse[List[ApplicationRead]])
async def get_applications(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    apps = await application_dao.get_all_for_user(db, current_user)
    return StandardResponse(
        success=True,
        message="Applications retrieved successfully",
        data=[ApplicationRead.model_validate(a) for a in apps]
    )


@router.post("/applications", response_model=StandardResponse[ApplicationRead], status_code=status.HTTP_201_CREATED)
async def create_application(
    app_in: ApplicationCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    data = app_in.model_dump()
    if current_user:
        data["created_by"] = current_user.username
        data["owner_id"] = str(current_user.id)
    else:
        data["created_by"] = "Super Admin"
        data["owner_id"] = None
    created = await application_dao.create(db, data)
    return StandardResponse(
        success=True,
        message="Application created successfully",
        data=ApplicationRead.model_validate(created)
    )


@router.put("/applications/{app_id}", response_model=StandardResponse[ApplicationRead])
async def update_application(
    app_id: str,
    app_in: ApplicationUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    app_obj = await application_dao.get_by_id(db, app_id)
    if not app_obj:
        raise EntityNotFoundException("Application", app_id)
    _check_entity_ownership(app_obj, current_user)
    update_data = app_in.model_dump(exclude_unset=True)
    # Prevent overwriting ownership
    update_data.pop("created_by", None)
    update_data.pop("owner_id", None)
    if "is_active" in update_data and update_data["is_active"] is not None:
        update_data["status"] = "ACTIVE" if update_data["is_active"] else "INACTIVE"
    elif "status" in update_data and update_data["status"] is not None:
        update_data["is_active"] = update_data["status"] == "ACTIVE"
    if current_user:
        update_data["modified_by"] = getattr(current_user, "username", "Super Admin")
    updated = await application_dao.update(db, app_obj, update_data)
    return StandardResponse(
        success=True,
        message="Application updated successfully",
        data=ApplicationRead.model_validate(updated)
    )


@router.patch("/applications/{app_id}/toggle-status", response_model=StandardResponse[ApplicationRead])
async def toggle_application_status(
    app_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    app_obj = await application_dao.get_by_id(db, app_id)
    if not app_obj:
        raise EntityNotFoundException("Application", app_id)
    _check_entity_ownership(app_obj, current_user)
    new_active = not getattr(app_obj, "is_active", True)
    updated = await application_dao.update(db, app_obj, {
        "is_active": new_active,
        "status": "ACTIVE" if new_active else "INACTIVE",
        "modified_by": getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
    })
    status_str = "activated" if new_active else "deactivated"
    return StandardResponse(
        success=True,
        message=f"Application {status_str} successfully",
        data=ApplicationRead.model_validate(updated)
    )


@router.delete("/applications/{app_id}", response_model=StandardResponse[dict])
async def delete_application(
    app_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    app_obj = await application_dao.get_by_id(db, app_id)
    if not app_obj:
        raise EntityNotFoundException("Application", app_id)
    _check_entity_ownership(app_obj, current_user)
    # Soft deactivation: preserve all data and relationships
    await application_dao.update(db, app_obj, {
        "is_active": False,
        "status": "INACTIVE",
        "modified_by": getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
    })
    return StandardResponse(
        success=True,
        message="Application deactivated successfully",
        data={"id": app_id, "is_active": False}
    )


# --- Full Hierarchy Tree ---
@router.get("/tree", response_model=StandardResponse[PortfolioHierarchy])
async def get_portfolio_tree(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    filtered_bus = await business_unit_dao.get_all_for_user(db, current_user)
    filtered_projs = await project_dao.get_all_for_user(db, current_user)
    filtered_comps = await component_dao.get_all_for_user(db, current_user)
    filtered_apps = await application_dao.get_all_for_user(db, current_user)

    return StandardResponse(
        success=True,
        message="Portfolio hierarchy tree retrieved successfully",
        data=PortfolioHierarchy(
            business_units=[BusinessUnitRead.model_validate(b) for b in filtered_bus],
            projects=[ProjectRead.model_validate(p) for p in filtered_projs],
            components=[ComponentRead.model_validate(c) for c in filtered_comps],
            applications=[ApplicationRead.model_validate(a) for a in filtered_apps]
        )
    )
