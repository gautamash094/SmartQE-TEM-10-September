from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.dao.asset_dao import asset_dao
from app.schemas.asset import (
    AssetCreate, AssetUpdate, AssetRead, AssetStatusUpdate,
    InventoryMetrics, AssetAuditLogRead
)
from app.schemas.common import StandardResponse, MetaParams
from app.dependencies.auth import get_current_user_optional
from app.models.user import User

router = APIRouter(prefix="/inventory", tags=["Inventory Management"])


@router.get("/metrics", response_model=StandardResponse[InventoryMetrics])
async def get_inventory_metrics(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    metrics_data = await asset_dao.get_metrics(db, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Inventory metrics retrieved successfully",
        data=InventoryMetrics(**metrics_data)
    )


@router.get("/assets", response_model=StandardResponse[List[AssetRead]])
async def get_assets(
    search: Optional[str] = Query(None, description="Search query across name, asset_id, IP, hostname, BU"),
    business_unit: Optional[str] = Query(None, description="Filter by Business Unit"),
    account_name: Optional[str] = Query(None, description="Filter by Account/Project"),
    environment_id: Optional[str] = Query(None, description="Filter by Environment ID"),
    environment_name: Optional[str] = Query(None, description="Filter by Environment Name"),
    asset_type: Optional[str] = Query(None, description="Filter by Asset Type (SERVER, DATABASE, etc.)"),
    infrastructure_type: Optional[str] = Query(None, description="Filter by Infra Type (ON_PREMISES, CLOUD)"),
    cloud_provider: Optional[str] = Query(None, description="Filter by Cloud Provider (AWS, Azure, GCP, etc.)"),
    region: Optional[str] = Query(None, description="Filter by Region"),
    status: Optional[str] = Query(None, description="Filter by Status (ACTIVE, INACTIVE, RETIRED, etc.)"),
    operating_system: Optional[str] = Query(None, description="Filter by Operating System"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    sort_by: str = Query("created_at"),
    sort_order: str = Query("desc"),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    skip = (page - 1) * page_size
    assets, total_count = await asset_dao.get_all(
        db=db,
        search=search,
        business_unit=business_unit,
        account_name=account_name,
        environment_id=environment_id,
        environment_name=environment_name,
        asset_type=asset_type,
        infrastructure_type=infrastructure_type,
        cloud_provider=cloud_provider,
        region=region,
        status=status,
        operating_system=operating_system,
        skip=skip,
        limit=page_size,
        sort_by=sort_by,
        sort_order=sort_order,
        current_user=current_user
    )

    data = [AssetRead.model_validate(a) for a in assets]
    return StandardResponse(
        success=True,
        message="Inventory assets retrieved successfully",
        data=data,
        meta={"page": page, "pageSize": page_size, "total": total_count}
    )


from app.core.exceptions import PermissionDeniedException, EntityNotFoundException
from app.dependencies.auth import get_current_user_optional, is_user_super_admin


def _check_asset_ownership(asset: any, current_user: Optional[User]):
    if is_user_super_admin(current_user):
        return
    if not current_user:
        raise PermissionDeniedException("Authentication required.")
    user_id = str(getattr(current_user, "id", "") or "")
    username = str(getattr(current_user, "username", "") or "").lower()
    full_name = str(getattr(current_user, "full_name", "") or username).lower()
    owner_id = str(getattr(asset, "owner_id", "") or "")
    created_by = str(getattr(asset, "created_by", "") or "").lower()
    if owner_id != user_id and created_by not in (username, full_name):
        raise PermissionDeniedException("You do not have permission to view, modify, or delete this asset.")


@router.get("/assets/{id}", response_model=StandardResponse[AssetRead])
async def get_asset(
    id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    asset = await asset_dao.get_by_id_for_user(db, id, current_user=current_user)
    if not asset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    return StandardResponse(
        success=True,
        message="Asset retrieved successfully",
        data=AssetRead.model_validate(asset)
    )


@router.post("/assets", response_model=StandardResponse[AssetRead], status_code=status.HTTP_201_CREATED)
async def create_asset(
    asset_in: AssetCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    creator_name = current_user.username if current_user else "Super Admin"
    owner_id = str(current_user.id) if current_user else None
    data = asset_in.model_dump()
    data["created_by"] = creator_name
    if owner_id:
        data["owner_id"] = owner_id
    created = await asset_dao.create_with_audit(db, data, user=creator_name, owner_id=owner_id)
    return StandardResponse(
        success=True,
        message="Asset created successfully",
        data=AssetRead.model_validate(created)
    )


@router.put("/assets/{id}", response_model=StandardResponse[AssetRead])
async def update_asset(
    id: str,
    asset_in: AssetUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    asset = await asset_dao.get_by_id(db, id)
    if not asset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    _check_asset_ownership(asset, current_user)

    modifier_name = current_user.username if current_user else "Super Admin"
    update_data = asset_in.model_dump(exclude_unset=True)
    update_data.pop("created_by", None)
    update_data.pop("owner_id", None)
    updated = await asset_dao.update_with_audit(db, id, update_data, user=modifier_name)
    if not updated:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    return StandardResponse(
        success=True,
        message="Asset updated successfully",
        data=AssetRead.model_validate(updated)
    )


@router.post("/assets/{id}/status", response_model=StandardResponse[AssetRead])
async def update_asset_status(
    id: str,
    status_in: AssetStatusUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    asset = await asset_dao.get_by_id(db, id)
    if not asset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    _check_asset_ownership(asset, current_user)

    modifier_name = current_user.username if current_user else "Super Admin"
    updated = await asset_dao.update_status_with_audit(db, id, status_in.status, status_in.reason, user=modifier_name)
    if not updated:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    return StandardResponse(
        success=True,
        message=f"Asset status transitioned to '{status_in.status}' successfully",
        data=AssetRead.model_validate(updated)
    )


@router.patch("/assets/{id}/toggle-status", response_model=StandardResponse[AssetRead])
async def toggle_asset_status(
    id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    asset = await asset_dao.get_by_id(db, id)
    if not asset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    _check_asset_ownership(asset, current_user)

    modifier_name = current_user.username if current_user else "Super Admin"
    updated = await asset_dao.toggle_status(db, id, user=modifier_name)
    if not updated:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    status_str = "activated" if updated.status == AssetStatus.ACTIVE else "deactivated"
    return StandardResponse(
        success=True,
        message=f"Asset {status_str} successfully",
        data=AssetRead.model_validate(updated)
    )


@router.delete("/assets/{id}", response_model=StandardResponse[dict])
async def delete_asset(
    id: str,
    hard_delete: bool = Query(False, description="Deprecated. All deletes are soft deactivations"),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    asset = await asset_dao.get_by_id(db, id)
    if not asset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    _check_asset_ownership(asset, current_user)

    modifier_name = current_user.username if current_user else "Super Admin"
    success = await asset_dao.delete_asset(db, id, hard_delete=False, user=modifier_name)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Asset with ID '{id}' not found")
    return StandardResponse(
        success=True,
        message="Asset successfully deactivated",
        data={"id": id, "is_active": False}
    )


@router.get("/audit-logs", response_model=StandardResponse[List[AssetAuditLogRead]])
async def get_audit_logs(
    asset_id: Optional[str] = Query(None, description="Optional asset ID filter"),
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db)
):
    logs = await asset_dao.get_audit_logs(db, asset_id=asset_id, limit=limit)
    return StandardResponse(
        success=True,
        message="Audit logs retrieved successfully",
        data=[AssetAuditLogRead.model_validate(log) for log in logs]
    )
