from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.user import UserCreate, UserUpdate, UserRead
from app.schemas.common import StandardResponse, MetaParams
from app.services.user_service import user_service
from app.dependencies.auth import get_current_user_optional
from app.models.user import User

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("", response_model=StandardResponse[List[UserRead]])
async def get_users(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=50, ge=1, le=100),
    search: Optional[str] = None,
    roleId: Optional[str] = None,
    buId: Optional[str] = None,
    isActive: Optional[bool] = None,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    users, total = await user_service.get_users(
        db,
        page=page,
        page_size=pageSize,
        search=search,
        role_id=roleId,
        bu_id=buId,
        is_active=isActive,
        current_user=current_user,
    )
    return StandardResponse(
        success=True,
        message="Users retrieved successfully",
        data=users,
        meta=MetaParams(page=page, pageSize=pageSize, total=total),
    )


@router.post("", response_model=StandardResponse[UserRead], status_code=status.HTTP_201_CREATED)
async def create_user(
    user_in: UserCreate,
    db: AsyncSession = Depends(get_db),
):
    created = await user_service.create_user(db, user_in)
    return StandardResponse(
        success=True,
        message="User created successfully",
        data=created,
    )


@router.get("/{user_id}", response_model=StandardResponse[UserRead])
async def get_user_by_id(
    user_id: str,
    db: AsyncSession = Depends(get_db),
):
    user = await user_service.get_user_by_id(db, user_id)
    return StandardResponse(
        success=True,
        message="User details retrieved",
        data=user,
    )


@router.put("/{user_id}", response_model=StandardResponse[UserRead])
async def update_user(
    user_id: str,
    user_in: UserUpdate,
    db: AsyncSession = Depends(get_db),
):
    updated = await user_service.update_user(db, user_id, user_in)
    return StandardResponse(
        success=True,
        message="User updated successfully",
        data=updated,
    )


@router.patch("/{user_id}/toggle-status", response_model=StandardResponse[UserRead])
async def toggle_user_status(
    user_id: str,
    db: AsyncSession = Depends(get_db),
):
    updated = await user_service.toggle_user_status(db, user_id)
    return StandardResponse(
        success=True,
        message=f"User status set to {'ACTIVE' if updated.is_active else 'INACTIVE'}",
        data=updated,
    )


@router.delete("/{user_id}", response_model=StandardResponse[dict])
async def delete_user(
    user_id: str,
    db: AsyncSession = Depends(get_db),
):
    await user_service.delete_user(db, user_id)
    return StandardResponse(
        success=True,
        message="User deleted successfully",
        data={"id": user_id},
    )
