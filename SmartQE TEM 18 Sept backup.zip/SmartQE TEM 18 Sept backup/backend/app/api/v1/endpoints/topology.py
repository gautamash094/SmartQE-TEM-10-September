from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query, Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.dao.topology_dao import TopologyDAO
from app.schemas.topology import (
    TopologyRelationshipCreate,
    TopologyRelationshipUpdate,
    TopologyRelationshipRead,
    TopologyGraphResponse,
    ImpactAnalysisResponse,
    TopologyExportRequest
)
from app.services.topology_export_service import TopologyExportService


from app.dependencies.auth import get_current_user_optional
from app.models.user import User


router = APIRouter()


@router.get("/graph", response_model=TopologyGraphResponse)
async def get_topology_graph(
    environment_id: Optional[str] = Query(None, description="Filter by specific environment ID"),
    business_unit: Optional[str] = Query(None, description="Filter by business unit"),
    asset_type: Optional[str] = Query(None, description="Filter by asset type"),
    status: Optional[str] = Query(None, description="Filter by health/status"),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Get consolidated topology graph with nodes, directional edges, active incidents, and metrics.
    """
    return await TopologyDAO.get_topology_graph(
        db,
        environment_id=environment_id,
        business_unit=business_unit,
        asset_type=asset_type,
        status=status,
        current_user=current_user
    )


@router.get("/impact", response_model=ImpactAnalysisResponse)
async def get_impact_analysis(
    node_id: str = Query(..., description="Target node ID to simulate impact for"),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Simulate component failure and compute blast radius (upstream callers & downstream dependencies).
    """
    return await TopologyDAO.get_impact_analysis(db, node_id=node_id, current_user=current_user)


@router.get("/relationships", response_model=List[TopologyRelationshipRead])
async def list_relationships(
    environment_id: Optional[str] = Query(None),
    source_id: Optional[str] = Query(None),
    target_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """
    List explicit user-defined topology relationships.
    """
    return await TopologyDAO.get_relationships(
        db,
        environment_id=environment_id,
        source_id=source_id,
        target_id=target_id
    )


@router.post("/relationships", response_model=TopologyRelationshipRead, status_code=status.HTTP_201_CREATED)
async def create_relationship(
    rel_in: TopologyRelationshipCreate,
    db: AsyncSession = Depends(get_db)
):
    """
    Create a custom topology relationship between two nodes.
    """
    return await TopologyDAO.create_relationship(db, rel_in)


@router.get("/relationships/{rel_id}", response_model=TopologyRelationshipRead)
async def get_relationship(
    rel_id: str,
    db: AsyncSession = Depends(get_db)
):
    rel = await TopologyDAO.get_relationship_by_id(db, rel_id)
    if not rel:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Topology relationship not found")
    return rel


@router.put("/relationships/{rel_id}", response_model=TopologyRelationshipRead)
async def update_relationship(
    rel_id: str,
    update_data: TopologyRelationshipUpdate,
    db: AsyncSession = Depends(get_db)
):
    rel = await TopologyDAO.get_relationship_by_id(db, rel_id)
    if not rel:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Topology relationship not found")
    return await TopologyDAO.update_relationship(db, rel, update_data)


@router.delete("/relationships/{rel_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_relationship(
    rel_id: str,
    db: AsyncSession = Depends(get_db)
):
    rel = await TopologyDAO.get_relationship_by_id(db, rel_id)
    if not rel:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Topology relationship not found")
    await TopologyDAO.delete_relationship(db, rel)
    return None


@router.post("/export")
async def export_topology(
    export_req: TopologyExportRequest,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Generate and download Environment Topology export (CSV, XLSX, PDF, DOCX).
    Supports exporting all, filtered, or individually selected environments.
    """
    if export_req.graph_data:
        graph_dict = export_req.graph_data
    else:
        graph_resp = await TopologyDAO.get_topology_graph(db, current_user=current_user)
        graph_dict = graph_resp.model_dump()
    
    file_bytes, filename, media_type = TopologyExportService.export_topology(
        graph_data=graph_dict,
        scope=export_req.scope,
        selected_env_ids=export_req.selected_environment_ids,
        export_format=export_req.format
    )
    
    return Response(
        content=file_bytes,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Access-Control-Expose-Headers": "Content-Disposition"
        }
    )

