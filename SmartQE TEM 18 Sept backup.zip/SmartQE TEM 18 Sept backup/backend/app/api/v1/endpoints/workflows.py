from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.workflow import (
    WorkflowCreate,
    WorkflowUpdate,
    WorkflowRead,
    WorkflowExecutionRead,
    WorkflowApprovalAction,
)
from app.schemas.common import StandardResponse, MetaParams
from app.services.workflow_service import workflow_service
from app.dependencies.auth import get_current_user_optional, is_user_super_admin
from app.models.user import User

router = APIRouter(prefix="/workflows", tags=["Workflows"])


@router.get("", response_model=StandardResponse[List[WorkflowRead]])
async def get_workflows(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=50, ge=1, le=100),
    buId: Optional[str] = None,
    environmentId: Optional[str] = None,
    applicationId: Optional[str] = None,
    serviceCode: Optional[str] = None,
    isActive: Optional[bool] = None,
    db: AsyncSession = Depends(get_db),
):
    workflows, total = await workflow_service.get_workflows(
        db,
        page=page,
        page_size=pageSize,
        bu_id=buId,
        environment_id=environmentId,
        application_id=applicationId,
        service_code=serviceCode,
        is_active=isActive,
    )
    return StandardResponse(
        success=True,
        message="Workflows retrieved successfully",
        data=workflows,
        meta=MetaParams(page=page, pageSize=pageSize, total=total),
    )


@router.post("", response_model=StandardResponse[WorkflowRead], status_code=status.HTTP_201_CREATED)
async def create_workflow(
    workflow_in: WorkflowCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    actor = current_user.username if current_user else "Super Admin"
    created = await workflow_service.create_workflow(db, workflow_in, actor=actor)
    return StandardResponse(
        success=True,
        message="Workflow defined successfully",
        data=created,
    )


@router.get("/{workflow_id}", response_model=StandardResponse[WorkflowRead])
async def get_workflow_by_id(
    workflow_id: str,
    db: AsyncSession = Depends(get_db),
):
    workflow = await workflow_service.get_workflow_by_id(db, workflow_id)
    return StandardResponse(
        success=True,
        message="Workflow details retrieved",
        data=workflow,
    )


@router.put("/{workflow_id}", response_model=StandardResponse[WorkflowRead])
async def update_workflow(
    workflow_id: str,
    workflow_in: WorkflowUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    actor = current_user.username if current_user else "Super Admin"
    updated = await workflow_service.update_workflow(db, workflow_id, workflow_in, actor=actor)
    return StandardResponse(
        success=True,
        message="Workflow updated successfully",
        data=updated,
    )


@router.patch("/{workflow_id}/toggle-status", response_model=StandardResponse[WorkflowRead])
async def toggle_workflow_status(
    workflow_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    actor = current_user.username if current_user else "Super Admin"
    updated = await workflow_service.toggle_workflow_status(db, workflow_id, actor=actor)
    return StandardResponse(
        success=True,
        message=f"Workflow status set to {'ACTIVE' if updated.is_active else 'INACTIVE'}",
        data=updated,
    )


@router.delete("/{workflow_id}", response_model=StandardResponse[dict])
async def delete_workflow(
    workflow_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    actor = current_user.username if current_user else "Super Admin"
    await workflow_service.delete_workflow(db, workflow_id, actor=actor)
    return StandardResponse(
        success=True,
        message="Workflow deleted successfully",
        data={"id": workflow_id},
    )


# --- Workflow Execution & Sequential Approval Endpoints ---

@router.get("/executions/{entity_type}/{entity_id}", response_model=StandardResponse[Optional[WorkflowExecutionRead]])
async def get_execution_for_entity(
    entity_type: str,
    entity_id: str,
    db: AsyncSession = Depends(get_db),
):
    execution = await workflow_service.get_execution_for_entity(db, entity_type, entity_id)
    return StandardResponse(
        success=True,
        message="Workflow execution details retrieved",
        data=execution,
    )


@router.post("/executions/{execution_id}/action", response_model=StandardResponse[WorkflowExecutionRead])
async def submit_approval_action(
    execution_id: str,
    action_in: WorkflowApprovalAction,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    if not current_user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required to perform workflow approvals."
        )

    user_id = str(current_user.id)
    is_super = is_user_super_admin(current_user)

    updated_exec = await workflow_service.process_approval_action(
        db,
        execution_id=execution_id,
        user_id=user_id,
        action=action_in.action,
        comments=action_in.comments,
        is_super_admin=is_super,
    )
    return StandardResponse(
        success=True,
        message=f"Workflow action '{action_in.action}' processed successfully",
        data=updated_exec,
    )
