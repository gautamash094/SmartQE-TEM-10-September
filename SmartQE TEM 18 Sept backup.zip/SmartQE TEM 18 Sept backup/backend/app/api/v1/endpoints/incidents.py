from typing import List, Dict, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.schemas.incident import IncidentCreate, IncidentUpdate, IncidentRead
from app.schemas.common import StandardResponse, MetaParams
from app.services.incident_service import incident_service

router = APIRouter(prefix="/incidents", tags=["Incidents"])


@router.get("", response_model=StandardResponse[List[IncidentRead]])
async def get_incidents(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=20, ge=1, le=100),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    items, total = await incident_service.get_incidents_paginated(
        db, page=page, page_size=pageSize, current_user=current_user
    )
    return StandardResponse(
        success=True,
        message="Incidents retrieved successfully",
        data=items,
        meta=MetaParams(page=page, pageSize=pageSize, total=total)
    )


@router.get("/severity-summary", response_model=StandardResponse[Dict[str, int]])
async def get_severity_summary(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    summary = await incident_service.get_severity_summary(db, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Incident severity counts calculated",
        data=summary
    )


@router.post("", response_model=StandardResponse[IncidentRead], status_code=status.HTTP_201_CREATED)
async def create_incident(
    inc_in: IncidentCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    created = await incident_service.create_incident(db, inc_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Incident logged successfully",
        data=created
    )


@router.get("/{inc_id}", response_model=StandardResponse[IncidentRead])
async def get_incident_by_id(
    inc_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    res = await incident_service.get_incident_by_id(db, inc_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Incident details retrieved",
        data=res
    )


@router.put("/{inc_id}", response_model=StandardResponse[IncidentRead])
async def update_incident(
    inc_id: str,
    inc_in: IncidentUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await incident_service.update_incident(db, inc_id, inc_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Incident updated successfully",
        data=updated
    )


@router.delete("/{inc_id}", response_model=StandardResponse[dict])
async def delete_incident(
    inc_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    await incident_service.delete_incident(db, inc_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Incident resolved/deleted successfully",
        data={"id": inc_id}
    )
