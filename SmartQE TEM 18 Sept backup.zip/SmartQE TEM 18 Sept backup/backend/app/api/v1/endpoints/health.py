from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from app.database.session import get_db
from app.schemas.common import StandardResponse

router = APIRouter(tags=["Health & Readiness"])


@router.get("/health", response_model=StandardResponse[dict])
async def health_check():
    return StandardResponse(
        success=True,
        message="Service is healthy",
        data={"status": "UP", "service": "TESTOPS TEM CONTROL API"}
    )


@router.get("/ready", response_model=StandardResponse[dict])
async def readiness_check(db: AsyncSession = Depends(get_db)):
    try:
        await db.execute(text("SELECT 1"))
        return StandardResponse(
            success=True,
            message="Service and Database are ready",
            data={"status": "READY", "database": "CONNECTED"}
        )
    except Exception as e:
        return StandardResponse(
            success=False,
            message=f"Database connection failed: {str(e)}",
            data={"status": "NOT_READY", "database": "DISCONNECTED"}
        )
