from typing import List, Optional, Tuple
from fastapi import APIRouter, Depends, Request, Response, status, Query
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.database.session import get_db
from app.dependencies.auth import (
    get_current_user,
    get_current_user_and_session,
    get_current_user_optional,
)
from app.models.user import User
from app.models.session import UserSession
from app.schemas.auth import (
    LoginRequest,
    RefreshTokenRequest,
    TokenResponse,
    ChangePasswordRequest,
    AdminResetPasswordRequest,
    ForgotPasswordRequest,
    ResetPasswordWithTokenRequest,
    AuthAuditLogRead,
    SessionStatusResponse,
    SessionRefreshResponse,
)
from app.schemas.user import UserRead
from app.schemas.common import StandardResponse
from app.services.auth_service import auth_service

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _set_auth_cookie(response: Response, session_id: Optional[str]) -> None:
    if session_id:
        response.set_cookie(
            key=settings.SESSION_COOKIE_NAME,
            value=session_id,
            httponly=settings.SESSION_COOKIE_HTTPONLY,
            secure=settings.SESSION_COOKIE_SECURE,
            samesite=settings.SESSION_COOKIE_SAMESITE,
            max_age=settings.SESSION_ABSOLUTE_TIMEOUT_HOURS * 3600,
            path="/",
        )


def _delete_auth_cookie(response: Response) -> None:
    response.delete_cookie(
        key=settings.SESSION_COOKIE_NAME,
        path="/",
        httponly=settings.SESSION_COOKIE_HTTPONLY,
        secure=settings.SESSION_COOKIE_SECURE,
        samesite=settings.SESSION_COOKIE_SAMESITE,
    )


@router.post("/login")
async def login(
    request: Request,
    response: Response,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db),
):
    """
    OAuth2 form compatible token login endpoint with server-enforced session generation.
    """
    client_ip = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")
    login_req = LoginRequest(username=form_data.username, password=form_data.password)
    token_resp = await auth_service.authenticate_user(
        db, login_req, ip_address=client_ip, user_agent=user_agent
    )

    _set_auth_cookie(response, token_resp.session_id)

    return {
        "access_token": token_resp.access_token,
        "refresh_token": token_resp.refresh_token,
        "token_type": "bearer",
        "user_id": token_resp.user_id,
        "username": token_resp.username,
        "email": token_resp.email,
        "full_name": token_resp.full_name,
        "roles": [r.model_dump() for r in token_resp.roles],
        "is_super_admin": token_resp.is_super_admin,
        "allowed_screens": token_resp.allowed_screens,
        "session_id": token_resp.session_id,
        "success": True,
        "message": "Authentication successful",
    }


@router.post("/json-login", response_model=StandardResponse[TokenResponse])
async def json_login(
    request: Request,
    response: Response,
    login_data: LoginRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    JSON payload login endpoint for web client with secure HttpOnly cookie and server-side session.
    """
    client_ip = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")
    token_resp = await auth_service.authenticate_user(
        db, login_data, ip_address=client_ip, user_agent=user_agent
    )

    _set_auth_cookie(response, token_resp.session_id)

    return StandardResponse(
        success=True,
        message="Authentication successful",
        data=token_resp,
    )


@router.post("/logout", response_model=StandardResponse[dict])
async def logout(
    request: Request,
    response: Response,
    auth_data: Tuple[User, Optional[UserSession], Optional[str]] = Depends(get_current_user_and_session),
    db: AsyncSession = Depends(get_db),
):
    """
    Explicitly terminates server-side session, invalidates cookies, and audits logout.
    """
    user, session, session_id = auth_data
    client_ip = request.client.host if request.client else None

    await auth_service.logout_session(
        db=db,
        session_id=session_id,
        user=user,
        ip_address=client_ip,
    )

    _delete_auth_cookie(response)

    return StandardResponse(
        success=True,
        message="Session successfully terminated and logged out.",
        data={},
    )


@router.get("/session", response_model=StandardResponse[SessionStatusResponse])
async def get_session_status(
    request: Request,
    auth_data: Tuple[User, Optional[UserSession], Optional[str]] = Depends(get_current_user_and_session),
    db: AsyncSession = Depends(get_db),
):
    """
    Retrieves current server session status, remaining idle seconds, and warnings.
    """
    user, session, session_id = auth_data
    session_status = await auth_service.get_session_status(db, session_id, user)

    return StandardResponse(
        success=True,
        message="Session status retrieved",
        data=session_status,
    )



@router.post("/session/refresh", response_model=StandardResponse[SessionRefreshResponse])
async def refresh_session(
    request: Request,
    auth_data: Tuple[User, Optional[UserSession], Optional[str]] = Depends(get_current_user_and_session),
    db: AsyncSession = Depends(get_db),
):
    """
    Endpoint called when user clicks 'Continue Session' from warning modal to extend inactivity timer.
    """
    user, session, session_id = auth_data
    if not session_id:
        # If token was JWT without session table record, provide success response
        return StandardResponse(
            success=True,
            message="Session refreshed.",
            data=SessionRefreshResponse(
                success=True,
                message="Session refreshed.",
                idle_remaining_seconds=settings.SESSION_IDLE_TIMEOUT_MINUTES * 60,
                absolute_remaining_seconds=settings.SESSION_ABSOLUTE_TIMEOUT_HOURS * 3600,
                last_activity_at=auth_service.make_aware(None),
            )
        )

    refresh_result = await auth_service.refresh_session_activity(db, session_id, user)
    return StandardResponse(
        success=True,
        message="Session inactivity timer refreshed successfully.",
        data=refresh_result,
    )


@router.post("/refresh", response_model=StandardResponse[TokenResponse])
async def refresh_token(
    refresh_data: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db),
):
    token_resp = await auth_service.refresh_access_token(db, refresh_data.refresh_token)
    return StandardResponse(
        success=True,
        message="Token refreshed successfully",
        data=token_resp,
    )


@router.get("/me", response_model=StandardResponse[UserRead])
async def get_current_user_profile(
    current_user: User = Depends(get_current_user),
):
    return StandardResponse(
        success=True,
        message="Profile retrieved successfully",
        data=UserRead.model_validate(current_user),
    )


@router.post("/change-password", response_model=StandardResponse[dict])
async def change_password(
    request: Request,
    payload: ChangePasswordRequest,
    auth_data: Tuple[User, Optional[UserSession], Optional[str]] = Depends(get_current_user_and_session),
    db: AsyncSession = Depends(get_db),
):
    """
    Change password for authenticated logged-in user and revoke other sessions.
    """
    current_user, _, session_id = auth_data
    client_ip = request.client.host if request.client else None
    await auth_service.change_password(
        db,
        user_id=current_user.id,
        current_password=payload.current_password,
        new_password=payload.new_password,
        ip_address=client_ip,
        current_session_id=session_id,
    )
    return StandardResponse(
        success=True,
        message="Password changed successfully. Other active sessions have been invalidated.",
        data={"user_id": current_user.id},
    )


@router.post("/forgot-password", response_model=StandardResponse[dict])
async def forgot_password(
    payload: ForgotPasswordRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Request time-limited password reset token.
    """
    token, msg = await auth_service.create_password_reset_token(db, payload.username_or_email)
    return StandardResponse(
        success=True,
        message=msg,
        data={"reset_token": token} if token else {},
    )


@router.post("/reset-password", response_model=StandardResponse[dict])
async def reset_password_with_token(
    request: Request,
    payload: ResetPasswordWithTokenRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Reset password using single-use verification token.
    """
    client_ip = request.client.host if request.client else None
    await auth_service.reset_password_with_token(
        db,
        token=payload.token,
        new_password=payload.new_password,
        ip_address=client_ip,
    )
    return StandardResponse(
        success=True,
        message="Password has been reset successfully. You can now log in with your new password.",
        data={},
    )


@router.post("/admin/users/{user_id}/reset-password", response_model=StandardResponse[dict])
async def admin_reset_password(
    user_id: str,
    payload: AdminResetPasswordRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Administrator endpoint to reset a user's password and revoke sessions.
    """
    client_ip = request.client.host if request.client else None
    await auth_service.admin_reset_password(
        db,
        target_user_id=user_id,
        new_password=payload.new_password,
        admin_username=current_user.username,
        ip_address=client_ip,
    )
    return StandardResponse(
        success=True,
        message="User password reset successfully by administrator. User sessions have been invalidated.",
        data={"user_id": user_id},
    )


@router.get("/audit-logs", response_model=StandardResponse[List[AuthAuditLogRead]])
async def get_auth_audit_logs(
    limit: int = Query(default=50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
):
    """
    Retrieve authentication audit event history.
    """
    logs = await auth_service.get_audit_logs(db, limit=limit)
    return StandardResponse(
        success=True,
        message="Authentication audit logs retrieved",
        data=logs,
    )
