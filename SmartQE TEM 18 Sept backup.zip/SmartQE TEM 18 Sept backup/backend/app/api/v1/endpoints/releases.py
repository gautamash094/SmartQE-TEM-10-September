from typing import List, Dict, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.schemas.release import ReleaseCreate, ReleaseUpdate, ReleaseRead
from app.schemas.common import StandardResponse, MetaParams
from app.services.release_service import release_service

router = APIRouter(prefix="/releases", tags=["Releases"])


@router.get("", response_model=StandardResponse[List[ReleaseRead]])
async def get_releases(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=20, ge=1, le=100),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    items, total = await release_service.get_releases_paginated(
        db, page=page, page_size=pageSize, current_user=current_user
    )
    return StandardResponse(
        success=True,
        message="Releases retrieved successfully",
        data=items,
        meta=MetaParams(page=page, pageSize=pageSize, total=total)
    )


@router.get("/kanban", response_model=StandardResponse[Dict[str, List[ReleaseRead]]])
async def get_kanban_board(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    kanban = await release_service.get_kanban_board(db, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Kanban board populated",
        data=kanban
    )


@router.post("", response_model=StandardResponse[ReleaseRead], status_code=status.HTTP_201_CREATED)
async def create_release(
    rel_in: ReleaseCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    created = await release_service.create_release(db, rel_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release scheduled successfully",
        data=created
    )


@router.get("/{rel_id}", response_model=StandardResponse[ReleaseRead])
async def get_release_by_id(
    rel_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    res = await release_service.get_release_by_id(db, rel_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release details retrieved",
        data=res
    )


@router.put("/{rel_id}", response_model=StandardResponse[ReleaseRead])
async def update_release(
    rel_id: str,
    rel_in: ReleaseUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await release_service.update_release(db, rel_id, rel_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release updated successfully",
        data=updated
    )


@router.delete("/{rel_id}", response_model=StandardResponse[dict])
async def delete_release(
    rel_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    await release_service.delete_release(db, rel_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release deleted successfully",
        data={"id": rel_id}
    )
