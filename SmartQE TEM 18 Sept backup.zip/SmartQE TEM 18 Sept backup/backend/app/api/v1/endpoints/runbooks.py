from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.runbook import RunbookCreate, RunbookRead, RunbookExecute
from app.schemas.common import StandardResponse, MetaParams
from app.services.runbook_service import runbook_service
from app.dependencies.auth import get_current_user_optional
from app.models.user import User

router = APIRouter(prefix="/runbooks", tags=["Runbooks"])


@router.get("", response_model=StandardResponse[List[RunbookRead]])
async def get_runbooks(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=20, ge=1, le=100),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    items, total = await runbook_service.get_runbooks_paginated(db, page=page, page_size=pageSize, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Runbooks retrieved successfully",
        data=items,
        meta=MetaParams(page=page, pageSize=pageSize, total=total)
    )


@router.post("", response_model=StandardResponse[RunbookRead], status_code=status.HTTP_201_CREATED)
async def create_runbook(
    rb_in: RunbookCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    created = await runbook_service.create_runbook(db, rb_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Runbook cataloged successfully",
        data=created
    )


@router.post("/{rb_id}/execute", response_model=StandardResponse[RunbookRead])
async def execute_runbook(
    rb_id: str,
    exec_in: RunbookExecute,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    executed = await runbook_service.execute_runbook(db, rb_id, exec_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Runbook execution triggered",
        data=executed
    )
