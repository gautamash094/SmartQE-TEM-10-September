from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.user_group import UserGroupCreate, UserGroupUpdate, UserGroupRead
from app.schemas.common import StandardResponse, MetaParams
from app.services.user_group_service import user_group_service
from app.dependencies.auth import get_current_user_optional, is_user_super_admin
from app.models.user import User

router = APIRouter(prefix="/user-groups", tags=["User Groups"])


@router.get("", response_model=StandardResponse[List[UserGroupRead]])
async def get_user_groups(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=50, ge=1, le=100),
    search: Optional[str] = None,
    buId: Optional[str] = None,
    isActive: Optional[bool] = None,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    groups, total = await user_group_service.get_user_groups(
        db,
        page=page,
        page_size=pageSize,
        search=search,
        bu_id=buId,
        is_active=isActive,
        current_user=current_user,
    )
    return StandardResponse(
        success=True,
        message="User groups retrieved successfully",
        data=groups,
        meta=MetaParams(page=page, pageSize=pageSize, total=total),
    )


@router.post("", response_model=StandardResponse[UserGroupRead], status_code=status.HTTP_201_CREATED)
async def create_user_group(
    group_in: UserGroupCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    actor = current_user.username if current_user else "Super Admin"
    created = await user_group_service.create_user_group(db, group_in, actor=actor)
    return StandardResponse(
        success=True,
        message="User group created successfully",
        data=created,
    )


@router.get("/{group_id}", response_model=StandardResponse[UserGroupRead])
async def get_user_group_by_id(
    group_id: str,
    db: AsyncSession = Depends(get_db),
):
    group = await user_group_service.get_user_group_by_id(db, group_id)
    return StandardResponse(
        success=True,
        message="User group details retrieved",
        data=group,
    )


@router.put("/{group_id}", response_model=StandardResponse[UserGroupRead])
async def update_user_group(
    group_id: str,
    group_in: UserGroupUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    actor = current_user.username if current_user else "Super Admin"
    updated = await user_group_service.update_user_group(db, group_id, group_in, actor=actor)
    return StandardResponse(
        success=True,
        message="User group updated successfully",
        data=updated,
    )


@router.patch("/{group_id}/toggle-status", response_model=StandardResponse[UserGroupRead])
async def toggle_user_group_status(
    group_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    actor = current_user.username if current_user else "Super Admin"
    updated = await user_group_service.toggle_group_status(db, group_id, actor=actor)
    return StandardResponse(
        success=True,
        message=f"User group status set to {'ACTIVE' if updated.is_active else 'INACTIVE'}",
        data=updated,
    )


@router.delete("/{group_id}", response_model=StandardResponse[dict])
async def delete_user_group(
    group_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db),
):
    actor = current_user.username if current_user else "Super Admin"
    await user_group_service.delete_user_group(db, group_id, actor=actor)
    return StandardResponse(
        success=True,
        message="User group deactivated successfully",
        data={"id": group_id, "is_active": False},
    )
