from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.schemas.environment import (
    EnvironmentCreate, EnvironmentUpdate, EnvironmentRead, OverviewMetrics
)
from app.schemas.common import StandardResponse, MetaParams
from app.services.environment_service import environment_service

router = APIRouter(prefix="/environments", tags=["Environments"])


@router.get("", response_model=StandardResponse[List[EnvironmentRead]])
async def get_environments(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=20, ge=1, le=100),
    tier: Optional[str] = Query(default=None),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    items, total = await environment_service.get_environments_paginated(db, page=page, page_size=pageSize, tier=tier, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environments retrieved successfully",
        data=items,
        meta=MetaParams(page=page, pageSize=pageSize, total=total)
    )


@router.get("/metrics/overview", response_model=StandardResponse[OverviewMetrics])
async def get_overview_metrics(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    metrics = await environment_service.get_overview_metrics(db, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Fleet metrics calculated",
        data=metrics
    )


@router.post("", response_model=StandardResponse[EnvironmentRead], status_code=status.HTTP_201_CREATED)
async def create_environment(
    env_in: EnvironmentCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    created = await environment_service.create_environment(db, env_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment registered successfully",
        data=created
    )


@router.get("/{env_id}", response_model=StandardResponse[EnvironmentRead])
async def get_environment_by_id(
    env_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    env = await environment_service.get_environment_by_id(db, env_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment details retrieved",
        data=env
    )


@router.put("/{env_id}", response_model=StandardResponse[EnvironmentRead])
async def update_environment(
    env_id: str,
    env_in: EnvironmentUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await environment_service.update_environment(db, env_id, env_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment updated successfully",
        data=updated
    )


@router.patch("/{env_id}/toggle-status", response_model=StandardResponse[EnvironmentRead])
async def toggle_environment_status(
    env_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await environment_service.toggle_environment_status(db, env_id, current_user=current_user)
    status_str = "activated" if updated.is_active else "deactivated"
    return StandardResponse(
        success=True,
        message=f"Environment {status_str} successfully",
        data=updated
    )


@router.delete("/{env_id}", response_model=StandardResponse[dict])
async def delete_environment(
    env_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    await environment_service.delete_environment(db, env_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Environment deleted successfully",
        data={"id": env_id, "is_active": False}
    )
