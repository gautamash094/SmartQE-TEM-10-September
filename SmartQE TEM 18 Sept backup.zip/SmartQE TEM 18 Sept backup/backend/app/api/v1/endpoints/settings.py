from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.dao.setting_dao import setting_dao
from app.dao.role_dao import role_dao
from app.dao.portfolio_dao import business_unit_dao
from app.schemas.setting import AppConfigRead, AppConfigUpdate
from app.schemas.common import StandardResponse

router = APIRouter(prefix="/settings", tags=["Settings & Configuration"])


@router.get("/config", response_model=StandardResponse[AppConfigRead])
async def get_app_config(db: AsyncSession = Depends(get_db)):
    """
    Retrieve current application configuration including Default Role and Default Business Unit.
    """
    config_dict = await setting_dao.get_app_config(db)
    return StandardResponse(
        success=True,
        message="Application configuration retrieved successfully",
        data=AppConfigRead(**config_dict)
    )


@router.put("/config", response_model=StandardResponse[AppConfigRead])
async def update_app_config(config_in: AppConfigUpdate, db: AsyncSession = Depends(get_db)):
    """
    Update application configuration for Default Role and/or Default Business Unit.
    Validates that configured role and BU are active entities.
    """
    update_dict = config_in.model_dump(exclude_unset=True)

    # Validate Default Role if provided
    if "default_role_id" in update_dict and update_dict["default_role_id"]:
        role = await role_dao.get_by_id(db, update_dict["default_role_id"])
        if not role:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Role with ID {update_dict['default_role_id']} not found."
            )
        if not role.is_active:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Role '{role.name}' is inactive and cannot be set as the Default Role."
            )
        update_dict["default_role_name"] = role.name

    # Validate Default Business Unit if provided
    if "default_business_unit_id" in update_dict and update_dict["default_business_unit_id"]:
        bu = await business_unit_dao.get_by_id(db, update_dict["default_business_unit_id"])
        if not bu:
            # Check if matching by name or if id exists
            bu_by_name = await business_unit_dao.get_by_name(db, update_dict["default_business_unit_id"])
            if bu_by_name:
                bu = bu_by_name
        if bu:
            if not getattr(bu, "is_active", True) or getattr(bu, "status", "ACTIVE") == "INACTIVE":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Business Unit '{bu.name}' is inactive and cannot be set as the Default Business Unit."
                )
            update_dict["default_business_unit_id"] = bu.id
            update_dict["default_business_unit_name"] = bu.name

    updated_config = await setting_dao.update_app_config(db, update_dict)
    return StandardResponse(
        success=True,
        message="Application configuration updated successfully",
        data=AppConfigRead(**updated_config)
    )
