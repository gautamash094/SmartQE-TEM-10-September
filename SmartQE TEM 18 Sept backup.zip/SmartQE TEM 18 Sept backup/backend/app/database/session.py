from pathlib import Path
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from app.core.config import settings
from app.core.logging import logger

BASE_DIR = Path(__file__).resolve().parent.parent.parent
SQLITE_DB_PATH = BASE_DIR / "smartqe_tem.db"

sqlite_url = f"sqlite+aiosqlite:///{SQLITE_DB_PATH.as_posix()}"
db_url = settings.DATABASE_URL if settings.DATABASE_URL else sqlite_url

# Create primary engine
engine = create_async_engine(
    db_url,
    echo=False,
    future=True
)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)


def fallback_to_sqlite():
    global engine, AsyncSessionLocal
    logger.warning("Switching engine and AsyncSessionLocal to SQLite fallback (./smartqe_tem.db).")
    engine = create_async_engine(
        sqlite_url,
        echo=False,
        future=True
    )
    AsyncSessionLocal.configure(bind=engine)
    return engine


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
