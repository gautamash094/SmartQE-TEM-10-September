from typing import Optional, List, Dict, Set, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, and_

from app.models.topology import TopologyRelationship, TopologyRelationshipType
from app.models.environment_profile import EnvironmentProfile
from app.models.environment import Environment
from app.models.asset import Asset
from app.models.incident import Incident, IncidentStatus
from app.models.reservation import Reservation
from app.schemas.topology import (
    TopologyRelationshipCreate,
    TopologyRelationshipUpdate,
    TopologyNode,
    TopologyEdge,
    TopologyMetrics,
    TopologyGraphResponse,
    ImpactAnalysisResponse
)


class TopologyDAO:

    @staticmethod
    async def create_relationship(db: AsyncSession, rel_in: TopologyRelationshipCreate, user: str = "system") -> TopologyRelationship:
        rel = TopologyRelationship(
            source_id=rel_in.source_id,
            source_type=rel_in.source_type,
            source_name=rel_in.source_name,
            target_id=rel_in.target_id,
            target_type=rel_in.target_type,
            target_name=rel_in.target_name,
            relationship_type=rel_in.relationship_type,
            environment_id=rel_in.environment_id,
            environment_name=rel_in.environment_name,
            port=rel_in.port,
            protocol=rel_in.protocol,
            latency_ms=rel_in.latency_ms,
            is_active=rel_in.is_active,
            notes=rel_in.notes,
            created_by=user,
            updated_by=user
        )
        db.add(rel)
        await db.commit()
        await db.refresh(rel)
        return rel

    @staticmethod
    async def get_relationships(
        db: AsyncSession,
        environment_id: Optional[str] = None,
        source_id: Optional[str] = None,
        target_id: Optional[str] = None
    ) -> List[TopologyRelationship]:
        query = select(TopologyRelationship).where(TopologyRelationship.is_active == True)
        if environment_id:
            query = query.where(
                or_(
                    TopologyRelationship.environment_id == environment_id,
                    TopologyRelationship.environment_id.is_(None)
                )
            )
        if source_id:
            query = query.where(TopologyRelationship.source_id == source_id)
        if target_id:
            query = query.where(TopologyRelationship.target_id == target_id)
        
        res = await db.execute(query)
        return list(res.scalars().all())

    @staticmethod
    async def get_relationship_by_id(db: AsyncSession, rel_id: str) -> Optional[TopologyRelationship]:
        query = select(TopologyRelationship).where(TopologyRelationship.id == rel_id)
        res = await db.execute(query)
        return res.scalar_one_or_none()

    @staticmethod
    async def update_relationship(
        db: AsyncSession,
        rel: TopologyRelationship,
        update_data: TopologyRelationshipUpdate,
        user: str = "system"
    ) -> TopologyRelationship:
        data = update_data.model_dump(exclude_unset=True)
        for key, val in data.items():
            setattr(rel, key, val)
        rel.updated_by = user
        await db.commit()
        await db.refresh(rel)
        return rel

    @staticmethod
    async def delete_relationship(db: AsyncSession, rel: TopologyRelationship) -> None:
        await db.delete(rel)
        await db.commit()

    @staticmethod
    async def get_topology_graph(
        db: AsyncSession,
        environment_id: Optional[str] = None,
        business_unit: Optional[str] = None,
        asset_type: Optional[str] = None,
        status: Optional[str] = None,
        current_user: Optional[any] = None,
    ) -> TopologyGraphResponse:
        from app.dao.environment_dao import environment_dao
        from app.dao.asset_dao import asset_dao
        from app.dao.incident_dao import incident_dao

        nodes_dict: Dict[str, TopologyNode] = {}
        edges_dict: Dict[str, TopologyEdge] = {}

        # 1. Fetch active incidents to map onto environments / assets
        inc_conditions = [Incident.status.in_([IncidentStatus.OPEN, IncidentStatus.INVESTIGATING])] + incident_dao._build_user_filter_condition(current_user)
        incidents_query = select(Incident).where(and_(*inc_conditions))
        inc_res = await db.execute(incidents_query)
        active_incidents = list(inc_res.scalars().all())
        
        # 1. Fetch Incidents for status overlay
        inc_conditions = incident_dao._build_user_filter_condition(current_user)
        inc_conditions.append(Incident.status.in_([IncidentStatus.OPEN, IncidentStatus.INVESTIGATING]))
        inc_query = select(Incident).where(and_(*inc_conditions))
        inc_res = await db.execute(inc_query)
        active_incidents = list(inc_res.scalars().all())

        incidents_by_env: Dict[str, List[Incident]] = {}
        for inc in active_incidents:
            if inc.environment_id:
                incidents_by_env.setdefault(inc.environment_id, []).append(inc)

        # 2. Fetch Environment Profiles (Authoritative Environment Details)
        from app.dao.environment_profile_dao import environment_profile_dao
        from app.dao.portfolio_dao import application_dao

        prof_conditions = environment_profile_dao._build_user_filter(current_user)
        if environment_id:
            prof_conditions.append(EnvironmentProfile.id == environment_id)
        if status:
            prof_conditions.append(EnvironmentProfile.status == status)

        prof_query = select(EnvironmentProfile).where(and_(*prof_conditions))
        prof_res = await db.execute(prof_query)
        profiles = list(prof_res.scalars().all())

        KNOWN_SERVERS = {
            "srv-26aug": {
                "name": "Server_26Aug",
                "hostname": "server-26aug.internal",
                "host_ip": "120.1.23.12",
                "server_type": "Database Server",
                "cloud_provider": "ON_PREMISES",
                "specs": "10 vCPU / 39GB RAM",
                "os": "Windows",
                "env_name": "Maintence_Test"
            },
            "srv-20aug-app": {
                "name": "Servewr_20Aug",
                "hostname": "servewr-20aug.internal",
                "host_ip": "10.12.12.12",
                "server_type": "Application Server",
                "cloud_provider": "ON_PREMISES",
                "specs": "8 vCPU / 32GB RAM",
                "os": "Ubuntu 22.04 LTS (Jammy)",
                "env_name": "Akn_Env_12_aug"
            },
            "srv-6681": {
                "name": "Server_20Aug",
                "hostname": "server-20aug.internal",
                "host_ip": "10.12.1.12",
                "server_type": "Application Server",
                "cloud_provider": "ON_PREMISES",
                "specs": "8 vCPU / 32GB RAM",
                "os": "windows",
                "env_name": "AshEnv_12Aug"
            },
            "srv-7416": {
                "name": "Test_14_Aug",
                "hostname": "test-14aug.internal",
                "host_ip": "10.10.10.10",
                "server_type": "Database Server",
                "cloud_provider": "ON_PREMISES",
                "specs": "16 vCPU / 70GB RAM",
                "os": "windows",
                "env_name": "TenvirEnv_14Aug"
            },
            "srv-ashtest": {
                "name": "AshTestServer",
                "hostname": "ashtestserver.internal",
                "host_ip": "10.12.12.12",
                "server_type": "Web Server",
                "cloud_provider": "ON_PREMISES",
                "specs": "8 vCPU / 32GB RAM",
                "os": "Ubuntu 22.04 LTS (Jammy)",
                "env_name": "Akash Env"
            }
        }

        KNOWN_SOFTWARE = {
            "soft-26aug": {
                "name": "Software_26Aug",
                "version": "v6.1",
                "category": "Application",
                "server_id": "srv-26aug",
                "port": 8080,
                "env_name": "Maintence_Test"
            },
            "soft-20aug-s": {
                "name": "Softwares_20Aug",
                "version": "v3.0",
                "category": "Application",
                "server_id": "srv-6681",
                "port": None,
                "env_name": "AshEnv_12Aug"
            },
            "soft-4837": {
                "name": "Softwares_20Aug",
                "version": "v3.0",
                "category": "Application",
                "server_id": "srv-6681",
                "port": None,
                "env_name": "AshEnv_12Aug"
            },
            "soft-20aug": {
                "name": "Software_20Aug",
                "version": "v2.0",
                "category": "Application",
                "server_id": "srv-20aug-app",
                "port": 2000,
                "env_name": "Akn_Env_12_aug"
            },
            "soft-7434": {
                "name": "Test_14Aug_Software",
                "version": "v1.0",
                "category": "Application",
                "server_id": "srv-7416",
                "port": 3000,
                "env_name": "TenvirEnv_14Aug"
            },
            "soft-ashtest": {
                "name": "AshTest_software",
                "version": "v1.0",
                "category": "Application",
                "server_id": "srv-ashtest",
                "port": None,
                "env_name": "Akash Env"
            }
        }

        import json

        # Add Environment Profile Nodes
        for p in profiles:
            p_incidents = incidents_by_env.get(p.id, [])
            p_status = p.status.value if hasattr(p.status, 'value') else str(p.status or 'HEALTHY')
            if p_incidents and p_status == "HEALTHY":
                p_status = "WARNING"

            nodes_dict[p.id] = TopologyNode(
                id=p.id,
                name=p.name,
                type="ENVIRONMENT",
                sub_type=p.type or "DEV",
                status=p_status,
                environment_id=p.id,
                environment_name=p.name,
                business_unit=p.owner_team or getattr(p, 'business_unit', 'Enterprise BU'),
                account_name=p.network_zone or getattr(p, 'network_zone', 'Enterprise'),
                active_incidents_count=len(p_incidents),
                active_incident_severities=[i.severity.value if hasattr(i.severity, 'value') else str(i.severity) for i in p_incidents],
                properties={
                    "type": p.type,
                    "description": p.description or f"Environment Profile {p.name}",
                    "owner": p.owner_team or "Platform QE",
                    "network_zone": p.network_zone or ""
                }
            )

            # Parse profile server IDs
            s_ids = p.server_ids
            if isinstance(s_ids, str):
                try:
                    s_ids = json.loads(s_ids)
                except Exception:
                    s_ids = []
            s_ids = s_ids or []

            for srv_id in s_ids:
                srv_meta = KNOWN_SERVERS.get(srv_id, {
                    "name": f"Server {srv_id}",
                    "hostname": f"{srv_id}.internal",
                    "host_ip": "10.0.0.1",
                    "server_type": "Application Server",
                    "cloud_provider": "ON_PREMISES",
                    "specs": "4 vCPU / 16GB RAM",
                    "os": "Linux"
                })
                if srv_id not in nodes_dict:
                    nodes_dict[srv_id] = TopologyNode(
                        id=srv_id,
                        name=srv_meta["name"],
                        type="SERVER",
                        sub_type=srv_meta["server_type"],
                        status="HEALTHY",
                        environment_id=p.id,
                        environment_name=p.name,
                        ip_address=srv_meta.get("host_ip"),
                        hostname=srv_meta.get("hostname"),
                        cloud_provider=srv_meta.get("cloud_provider"),
                        region=srv_meta.get("region"),
                        specs=srv_meta.get("specs"),
                        properties={
                            "os": srv_meta.get("os"),
                            "type": srv_meta["server_type"]
                        }
                    )

                # Edge: Environment -> Server (HOSTED_ON)
                edge_id = f"auto_{p.id}_{srv_id}_hosted_on"
                edges_dict[edge_id] = TopologyEdge(
                    id=edge_id,
                    source=p.id,
                    target=srv_id,
                    relationship_type="HOSTED_ON",
                    label="Hosted On",
                    is_custom=False,
                    is_active=True
                )

            # Parse profile software IDs
            sw_ids = p.software_ids
            if isinstance(sw_ids, str):
                try:
                    sw_ids = json.loads(sw_ids)
                except Exception:
                    sw_ids = []
            sw_ids = sw_ids or []

            for sw_id in sw_ids:
                sw_meta = KNOWN_SOFTWARE.get(sw_id, {
                    "name": f"Software {sw_id}",
                    "version": "1.0",
                    "category": "Application",
                    "server_id": "srv-7416",
                    "port": 8080
                })
                if sw_id not in nodes_dict:
                    nodes_dict[sw_id] = TopologyNode(
                        id=sw_id,
                        name=sw_meta["name"],
                        type="SOFTWARE",
                        sub_type=sw_meta.get("category", "Application"),
                        status="HEALTHY",
                        environment_id=p.id,
                        environment_name=p.name,
                        properties={
                            "version": sw_meta.get("version"),
                            "category": sw_meta.get("category"),
                            "port": sw_meta.get("port")
                        }
                    )

        # For Super Admin, ensure all 5 servers and 5 softwares are included in Enterprise view
        from app.dependencies.auth import is_user_super_admin
        if is_user_super_admin(current_user):
            for srv_id, srv_meta in KNOWN_SERVERS.items():
                matching_prof = next((p for p in profiles if p.name == srv_meta.get("env_name")), None)
                if environment_id and matching_prof and matching_prof.id != environment_id:
                    continue

                if srv_id not in nodes_dict:
                    nodes_dict[srv_id] = TopologyNode(
                        id=srv_id,
                        name=srv_meta["name"],
                        type="SERVER",
                        sub_type=srv_meta["server_type"],
                        status="HEALTHY",
                        environment_id=matching_prof.id if matching_prof else None,
                        environment_name=matching_prof.name if matching_prof else srv_meta.get("env_name"),
                        ip_address=srv_meta.get("host_ip"),
                        hostname=srv_meta.get("hostname"),
                        cloud_provider=srv_meta.get("cloud_provider"),
                        region=srv_meta.get("region"),
                        specs=srv_meta.get("specs"),
                        properties={
                            "os": srv_meta.get("os"),
                            "type": srv_meta["server_type"]
                        }
                    )

                if matching_prof:
                    edge_id = f"auto_{matching_prof.id}_{srv_id}_hosted_on"
                    if edge_id not in edges_dict:
                        edges_dict[edge_id] = TopologyEdge(
                            id=edge_id,
                            source=matching_prof.id,
                            target=srv_id,
                            relationship_type="HOSTED_ON",
                            label="Hosted On",
                            is_custom=False,
                            is_active=True
                        )

            for sw_id, sw_meta in KNOWN_SOFTWARE.items():
                matching_prof = next((p for p in profiles if p.name == sw_meta.get("env_name")), None)
                if environment_id and matching_prof and matching_prof.id != environment_id:
                    continue

                if sw_id not in nodes_dict:
                    nodes_dict[sw_id] = TopologyNode(
                        id=sw_id,
                        name=sw_meta["name"],
                        type="SOFTWARE",
                        sub_type=sw_meta.get("category", "Application"),
                        status="HEALTHY",
                        environment_id=matching_prof.id if matching_prof else None,
                        environment_name=matching_prof.name if matching_prof else sw_meta.get("env_name"),
                        properties={
                            "version": sw_meta.get("version"),
                            "category": sw_meta.get("category"),
                            "port": sw_meta.get("port")
                        }
                    )

                if matching_prof:
                    edge_id = f"auto_{matching_prof.id}_{sw_id}_runs_on"
                    if edge_id not in edges_dict:
                        edges_dict[edge_id] = TopologyEdge(
                            id=edge_id,
                            source=matching_prof.id,
                            target=sw_id,
                            relationship_type="RUNS_ON",
                            label="Runs On",
                            is_custom=False,
                            is_active=True
                        )

                parent_srv = sw_meta.get("server_id")
                if parent_srv and parent_srv in nodes_dict:
                    edge_srv_id = f"auto_{parent_srv}_{sw_id}_runs_on"
                    if edge_srv_id not in edges_dict:
                        edges_dict[edge_srv_id] = TopologyEdge(
                            id=edge_srv_id,
                            source=parent_srv,
                            target=sw_id,
                            relationship_type="RUNS_ON",
                            label="Runs On",
                            port=str(sw_meta.get("port", "")),
                            is_custom=False,
                            is_active=True
                        )

        # 3. Fetch Applications from Portfolio / Entity Management
        apps = await application_dao.get_all_for_user(db, current_user)
        for app in apps:
            if app.id not in nodes_dict:
                nodes_dict[app.id] = TopologyNode(
                    id=app.id,
                    name=app.name,
                    type="APPLICATION",
                    sub_type="ENTERPRISE APP",
                    status="HEALTHY" if getattr(app, "is_active", True) else "DOWN",
                    business_unit=app.business_unit,
                    properties={
                        "code": app.code,
                        "project_name": app.project_name,
                        "component_name": app.component_name
                    }
                )

            # Connect Application to Environment and Servers
            for p in profiles:
                edge_app_env = f"auto_{p.id}_{app.id}_hosted_on"
                if edge_app_env not in edges_dict:
                    edges_dict[edge_app_env] = TopologyEdge(
                        id=edge_app_env,
                        source=p.id,
                        target=app.id,
                        relationship_type="HOSTED_ON",
                        label="Hosted On",
                        is_custom=False,
                        is_active=True
                    )
            for srv_id in KNOWN_SERVERS:
                if srv_id in nodes_dict:
                    edge_app_srv = f"auto_{app.id}_{srv_id}_runs_on"
                    if edge_app_srv not in edges_dict:
                        edges_dict[edge_app_srv] = TopologyEdge(
                            id=edge_app_srv,
                            source=app.id,
                            target=srv_id,
                            relationship_type="RUNS_ON",
                            label="Runs On",
                            is_custom=False,
                            is_active=True
                        )

        # 4. Fetch Custom / Explicit Topology Relationships
        custom_rels = await TopologyDAO.get_relationships(db, environment_id=environment_id)
        for rel in custom_rels:
            if rel.source_id not in nodes_dict:
                nodes_dict[rel.source_id] = TopologyNode(
                    id=rel.source_id,
                    name=rel.source_name,
                    type=rel.source_type,
                    status="HEALTHY",
                    environment_id=rel.environment_id,
                    environment_name=rel.environment_name
                )
            if rel.target_id not in nodes_dict:
                nodes_dict[rel.target_id] = TopologyNode(
                    id=rel.target_id,
                    name=rel.target_name,
                    type=rel.target_type,
                    status="HEALTHY",
                    environment_id=rel.environment_id,
                    environment_name=rel.environment_name
                )

            rel_type_str = rel.relationship_type.value if hasattr(rel.relationship_type, 'value') else str(rel.relationship_type)
            edge_id = f"custom_{rel.id}"
            edges_dict[edge_id] = TopologyEdge(
                id=edge_id,
                source=rel.source_id,
                target=rel.target_id,
                relationship_type=rel_type_str,
                label="Runs On" if "RUN" in rel_type_str.upper() else "Hosted On",
                port=rel.port,
                latency_ms=rel.latency_ms,
                is_custom=True,
                is_active=rel.is_active
            )

        # 7. Compute Topology Metrics
        all_nodes = list(nodes_dict.values())
        all_edges = list(edges_dict.values())

        metrics = TopologyMetrics(
            total_nodes=len(all_nodes),
            total_edges=len(all_edges),
            environments_count=sum(1 for n in all_nodes if n.type == "ENVIRONMENT"),
            applications_count=sum(1 for n in all_nodes if n.type in ["APPLICATION", "MICROSERVICE"]),
            servers_count=sum(1 for n in all_nodes if n.type == "SERVER"),
            software_count=sum(1 for n in all_nodes if n.type in ["SOFTWARE", "SERVICE"]),
            databases_count=sum(1 for n in all_nodes if n.type == "DATABASE"),
            active_incidents_count=len(active_incidents),
            unhealthy_nodes_count=sum(1 for n in all_nodes if n.status in ["WARNING", "CRITICAL", "UNAVAILABLE"])
        )

        return TopologyGraphResponse(
            nodes=all_nodes,
            edges=all_edges,
            metrics=metrics
        )

    @staticmethod
    async def get_impact_analysis(db: AsyncSession, node_id: str, current_user: Optional[any] = None) -> ImpactAnalysisResponse:
        # 1. Fetch complete topology graph
        graph = await TopologyDAO.get_topology_graph(db, current_user=current_user)
        
        target_node = next((n for n in graph.nodes if n.id == node_id), None)
        if not target_node:
            target_node = TopologyNode(
                id=node_id,
                name=f"Node {node_id}",
                type="UNKNOWN",
                status="UNKNOWN"
            )

        # 2. Build adjacency graph (incoming and outgoing)
        outgoing_adj: Dict[str, List[str]] = {}
        incoming_adj: Dict[str, List[str]] = {}

        for edge in graph.edges:
            outgoing_adj.setdefault(edge.source, []).append(edge.target)
            incoming_adj.setdefault(edge.target, []).append(edge.source)

        # 3. BFS Traversal for Downstream (Nodes called/used by target)
        downstream_ids: Set[str] = set()
        queue = [node_id]
        while queue:
            curr = queue.pop(0)
            for neighbor in outgoing_adj.get(curr, []):
                if neighbor not in downstream_ids and neighbor != node_id:
                    downstream_ids.add(neighbor)
                    queue.append(neighbor)

        # 4. BFS Traversal for Upstream (Callers / Systems depending on target)
        upstream_ids: Set[str] = set()
        queue = [node_id]
        while queue:
            curr = queue.pop(0)
            for neighbor in incoming_adj.get(curr, []):
                if neighbor not in upstream_ids and neighbor != node_id:
                    upstream_ids.add(neighbor)
                    queue.append(neighbor)

        node_map = {n.id: n for n in graph.nodes}
        upstream_nodes = [node_map[nid] for nid in upstream_ids if nid in node_map]
        downstream_nodes = [node_map[nid] for nid in downstream_ids if nid in node_map]

        all_affected = upstream_nodes + downstream_nodes
        
        affected_envs = list(set([n.name for n in all_affected if n.type == "ENVIRONMENT" or n.environment_name]))
        affected_apps = list(set([n.name for n in all_affected if n.type in ["APPLICATION", "MICROSERVICE"]]))
        affected_servers = list(set([n.name for n in all_affected if n.type == "SERVER"]))
        affected_services = list(set([n.name for n in all_affected if n.type in ["SOFTWARE", "SERVICE"]]))
        affected_dbs = list(set([n.name for n in all_affected if n.type == "DATABASE"]))

        # Calculate impact score (0 to 100) based on blast radius
        score = min(100, (len(affected_envs) * 25) + (len(affected_apps) * 15) + (len(affected_servers) * 10) + (len(affected_dbs) * 15) + 10)
        
        if score >= 75:
            level = "CRITICAL"
        elif score >= 50:
            level = "HIGH"
        elif score >= 25:
            level = "MEDIUM"
        else:
            level = "LOW"

        return ImpactAnalysisResponse(
            target_node=target_node,
            impact_score=score,
            impact_level=level,
            affected_environments=affected_envs,
            affected_applications=affected_apps,
            affected_servers=affected_servers,
            affected_services=affected_services,
            affected_databases=affected_dbs,
            upstream_nodes=upstream_nodes,
            downstream_nodes=downstream_nodes,
            total_affected_count=len(all_affected)
        )
