from typing import List, Optional, Tuple
from sqlalchemy import select, func, delete
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.workflow import Workflow, WorkflowApprover, WorkflowExecution, WorkflowExecutionStep
from app.schemas.workflow import WorkflowApproverItem


class WorkflowDAO(BaseDAO[Workflow]):
    def __init__(self):
        super().__init__(Workflow)

    async def get_by_context(
        self,
        db: AsyncSession,
        bu_id: str,
        environment_id: str,
        application_id: str,
        service_code: str,
    ) -> Optional[Workflow]:
        query = (
            select(Workflow)
            .options(
                selectinload(Workflow.business_unit),
                selectinload(Workflow.approvers).selectinload(WorkflowApprover.user)
            )
            .where(
                Workflow.bu_id == bu_id,
                Workflow.environment_id == environment_id,
                Workflow.application_id == application_id,
                Workflow.service_code == service_code,
            )
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_active_workflow_for_reservation(
        self,
        db: AsyncSession,
        bu_id: Optional[str] = None,
        bu_name: Optional[str] = None,
        environment_id: Optional[str] = None,
        environment_name: Optional[str] = None,
        application_id: Optional[str] = None,
        application_name: Optional[str] = None,
        service_code: str = "ENVIRONMENT_RESERVATION",
    ) -> Optional[Workflow]:
        """
        Finds the active workflow matching the reservation context:
        BU + Environment + Application + Service.
        Supports case-insensitive matching across IDs, Names, and Codes.
        """
        from app.models.portfolio import BusinessUnit
        from sqlalchemy import or_, func

        query = (
            select(Workflow)
            .outerjoin(Workflow.business_unit)
            .options(
                selectinload(Workflow.business_unit),
                selectinload(Workflow.approvers).selectinload(WorkflowApprover.user)
            )
            .where(
                Workflow.is_active == True,
                Workflow.service_code == service_code,
            )
        )

        # BU match condition
        bu_keys = [k.strip() for k in [bu_id, bu_name] if k and str(k).strip()]
        if bu_keys:
            bu_conds = []
            for k in bu_keys:
                k_lower = k.lower()
                bu_conds.append(Workflow.bu_id == k)
                bu_conds.append(func.lower(Workflow.bu_id) == k_lower)
                bu_conds.append(func.lower(BusinessUnit.name) == k_lower)
                bu_conds.append(func.lower(BusinessUnit.code) == k_lower)
            query = query.where(or_(*bu_conds))

        # Environment match condition
        env_keys = [k.strip() for k in [environment_id, environment_name] if k and str(k).strip()]
        if env_keys:
            env_conds = []
            for k in env_keys:
                k_lower = k.lower()
                env_conds.append(Workflow.environment_id == k)
                env_conds.append(func.lower(Workflow.environment_id) == k_lower)
                env_conds.append(func.lower(Workflow.environment_name) == k_lower)
            query = query.where(or_(*env_conds))

        result = await db.execute(query)
        workflows = list(result.scalars().all())

        # If application was provided, first check for exact application match
        app_keys = [k.strip().lower() for k in [application_id, application_name] if k and str(k).strip()]
        if app_keys:
            for wf in workflows:
                wf_app_id = (wf.application_id or "").strip().lower()
                wf_app_name = (wf.application_name or "").strip().lower()
                if (wf_app_id in app_keys or wf_app_name in app_keys) and wf.approvers and len(wf.approvers) > 0:
                    return wf

        # Otherwise fallback to any active matching workflow for the BU + Environment with approvers
        for wf in workflows:
            if wf.approvers and len(wf.approvers) > 0:
                return wf

        return None

    async def get_with_details(self, db: AsyncSession, workflow_id: str) -> Optional[Workflow]:
        query = (
            select(Workflow)
            .options(
                selectinload(Workflow.business_unit),
                selectinload(Workflow.approvers).selectinload(WorkflowApprover.user)
            )
            .where(Workflow.id == workflow_id)
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_all_workflows(
        self,
        db: AsyncSession,
        page: int = 1,
        page_size: int = 50,
        bu_id: Optional[str] = None,
        environment_id: Optional[str] = None,
        application_id: Optional[str] = None,
        service_code: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> Tuple[List[Workflow], int]:
        query = (
            select(Workflow)
            .options(
                selectinload(Workflow.business_unit),
                selectinload(Workflow.approvers).selectinload(WorkflowApprover.user)
            )
        )

        if bu_id:
            query = query.where(Workflow.bu_id == bu_id)
        if environment_id:
            query = query.where(Workflow.environment_id == environment_id)
        if application_id:
            query = query.where(Workflow.application_id == application_id)
        if service_code:
            query = query.where(Workflow.service_code == service_code)
        if is_active is not None:
            query = query.where(Workflow.is_active == is_active)

        count_query = select(func.count()).select_from(query.subquery())
        total_result = await db.execute(count_query)
        total = total_result.scalar_one()

        query = query.order_by(Workflow.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
        result = await db.execute(query)
        workflows = list(result.scalars().all())

        return workflows, total

    async def save_approvers(
        self,
        db: AsyncSession,
        workflow_id: str,
        approvers: List[WorkflowApproverItem],
        created_by: str = "Super Admin"
    ) -> List[WorkflowApprover]:
        # Delete existing approvers
        await db.execute(delete(WorkflowApprover).where(WorkflowApprover.workflow_id == workflow_id))

        new_approvers = []
        for item in approvers:
            approver = WorkflowApprover(
                workflow_id=workflow_id,
                user_id=item.user_id,
                workflow_order=item.workflow_order,
                created_by=created_by,
            )
            db.add(approver)
            new_approvers.append(approver)

        await db.commit()
        return new_approvers

    # Workflow Execution Methods
    async def get_execution_by_entity(
        self, db: AsyncSession, entity_type: str, entity_id: str
    ) -> Optional[WorkflowExecution]:
        query = (
            select(WorkflowExecution)
            .options(
                selectinload(WorkflowExecution.workflow),
                selectinload(WorkflowExecution.steps).selectinload(WorkflowExecutionStep.user)
            )
            .where(
                WorkflowExecution.entity_type == entity_type,
                WorkflowExecution.entity_id == entity_id,
            )
            .order_by(WorkflowExecution.created_at.desc())
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_execution_with_details(
        self, db: AsyncSession, execution_id: str
    ) -> Optional[WorkflowExecution]:
        query = (
            select(WorkflowExecution)
            .options(
                selectinload(WorkflowExecution.workflow),
                selectinload(WorkflowExecution.steps).selectinload(WorkflowExecutionStep.user)
            )
            .where(WorkflowExecution.id == execution_id)
        )
        result = await db.execute(query)
        return result.scalars().first()


workflow_dao = WorkflowDAO()
