from typing import List, Optional, Dict, Any
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.role import Role


class RoleDAO(BaseDAO[Role]):
    def __init__(self):
        super().__init__(Role)

    async def get_ordered_roles(self, db: AsyncSession) -> List[Role]:
        query = select(self.model).order_by(self.model.role_order.asc(), self.model.created_at.asc())
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_by_name(self, db: AsyncSession, name: str) -> Optional[Role]:
        clean_name = name.strip()
        query = select(self.model).where(func.lower(self.model.name) == clean_name.lower())
        result = await db.execute(query)
        return result.scalars().first()

    async def get_max_order(self, db: AsyncSession) -> int:
        query = select(func.max(self.model.role_order))
        result = await db.execute(query)
        return result.scalar() or 0

    async def create_role(self, db: AsyncSession, obj_in: Dict[str, Any]) -> Role:
        if "role_order" not in obj_in or obj_in["role_order"] is None:
            max_order = await self.get_max_order(db)
            obj_in["role_order"] = max_order + 1
        return await self.create(db, obj_in)

    async def reorder_roles(self, db: AsyncSession, reorder_list: List[Dict[str, Any]]) -> List[Role]:
        for item in reorder_list:
            role_id = item["id"]
            new_order = item["role_order"]
            role_obj = await self.get_by_id(db, role_id)
            if role_obj:
                role_obj.role_order = new_order
                db.add(role_obj)
        await db.commit()
        return await self.get_ordered_roles(db)


role_dao = RoleDAO()
