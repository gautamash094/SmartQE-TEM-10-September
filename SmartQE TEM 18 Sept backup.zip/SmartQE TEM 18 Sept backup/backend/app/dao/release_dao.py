from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy import func, select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.release import Release, ReleaseStatus


class ReleaseDAO(BaseDAO[Release]):
    def __init__(self):
        super().__init__(Release)

    def _build_user_filter_condition(self, current_user: Optional[any]):
        from sqlalchemy import false
        from app.dependencies.auth import is_user_super_admin
        visible_condition = or_(Release.is_visible == True, Release.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]
        if not current_user:
            return [false()]

        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)

        user_or_clauses = [
            Release.owner_id == user_id,
            Release.lead_id == user_id,
            Release.created_by.ilike(username),
            Release.created_by.ilike(full_name),
            Release.lead.ilike(username),
            Release.lead.ilike(full_name),
        ]

        return [
            visible_condition,
            or_(*user_or_clauses)
        ]

    async def paginate_for_user(
        self, db: AsyncSession, current_user: Optional[any], page: int = 1, page_size: int = 20
    ) -> Tuple[List[Release], int]:
        conditions = self._build_user_filter_condition(current_user)

        count_query = select(func.count(Release.id)).where(and_(*conditions))
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        start = (page - 1) * page_size
        query = (
            select(Release)
            .where(and_(*conditions))
            .order_by(Release.scheduled_date.desc())
            .offset(start)
            .limit(page_size)
        )
        result = await db.execute(query)
        items = list(result.scalars().all())
        return items, total

    async def get_by_id_for_user(
        self, db: AsyncSession, rel_id: str, current_user: Optional[any]
    ) -> Optional[Release]:
        conditions = [Release.id == rel_id] + self._build_user_filter_condition(current_user)
        query = select(Release).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()

    async def get_by_status(self, db: AsyncSession, status: ReleaseStatus, current_user: Optional[any] = None) -> List[Release]:
        conditions = [Release.status == status] + self._build_user_filter_condition(current_user)
        query = select(Release).where(and_(*conditions))
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_kanban_data(self, db: AsyncSession, current_user: Optional[any] = None) -> Dict[str, List[Release]]:
        scheduled = await self.get_by_status(db, ReleaseStatus.SCHEDULED, current_user=current_user)
        in_progress = await self.get_by_status(db, ReleaseStatus.IN_PROGRESS, current_user=current_user)
        deployed = await self.get_by_status(db, ReleaseStatus.DEPLOYED, current_user=current_user)
        return {
            "SCHEDULED": scheduled,
            "IN_PROGRESS": in_progress,
            "DEPLOYED": deployed
        }


release_dao = ReleaseDAO()
