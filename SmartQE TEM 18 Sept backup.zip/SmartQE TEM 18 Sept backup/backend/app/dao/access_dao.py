from typing import List, Optional
from sqlalchemy import select, delete
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.access import ApplicationScreen, RoleScreenAccess


DEFAULT_SCREENS = [
    # Top-Level / Core
    {"key": "dashboard", "name": "TEM Dashboard", "route": "/tem-dashboard", "parent_key": None, "category": "Core", "display_order": 1},
    
    # Settings Parent & Children
    {"key": "settings", "name": "Settings", "route": "/settings", "parent_key": None, "category": "Administration", "display_order": 2},
    {"key": "settings_users", "name": "User Management", "route": "/settings/users", "parent_key": "settings", "category": "Administration", "display_order": 3},
    {"key": "settings_roles", "name": "Role Management", "route": "/settings/roles", "parent_key": "settings", "category": "Administration", "display_order": 4},
    {"key": "settings_access", "name": "Access Management", "route": "/settings/access", "parent_key": "settings", "category": "Administration", "display_order": 5},
    {"key": "settings_user_groups", "name": "User Group Management", "route": "/settings/user-groups", "parent_key": "settings", "category": "Administration", "display_order": 6},
    {"key": "settings_define_workflow", "name": "Define Workflow", "route": "/settings/define-workflow", "parent_key": "settings", "category": "Administration", "display_order": 7},

    # Main Modules
    {"key": "entity_management", "name": "Entity Management", "route": "/entity-management", "parent_key": None, "category": "Core", "display_order": 8},
    {"key": "environment_details", "name": "Environment Details", "route": "/environment-details", "parent_key": None, "category": "Core", "display_order": 9},
    {"key": "worklist", "name": "Worklist", "route": "/worklist", "parent_key": None, "category": "Operations", "display_order": 10},
    {"key": "bookings", "name": "Bookings Grid", "route": "/bookings", "parent_key": None, "category": "Operations", "display_order": 11},
    {"key": "releases", "name": "Releases", "route": "/releases", "parent_key": None, "category": "Operations", "display_order": 12},
    {"key": "incidents", "name": "Incidents", "route": "/incidents", "parent_key": None, "category": "Operations", "display_order": 13},

    # Provisioning Parent & Children
    {"key": "provisioning", "name": "Environment Provisioning", "route": "/provisioning", "parent_key": None, "category": "Provisioning", "display_order": 14},
    {"key": "provisioning_requests", "name": "Provisioning Requests", "route": "/provisioning/requests", "parent_key": "provisioning", "category": "Provisioning", "display_order": 15},
    {"key": "provisioning_new", "name": "New Request (Wizard)", "route": "/provisioning/new", "parent_key": "provisioning", "category": "Provisioning", "display_order": 16},
    {"key": "provisioning_templates", "name": "Provisioning Templates", "route": "/provisioning/templates", "parent_key": "provisioning", "category": "Provisioning", "display_order": 17},
    {"key": "provisioning_history", "name": "Provisioning History", "route": "/provisioning/history", "parent_key": "provisioning", "category": "Provisioning", "display_order": 18},

    # Resource Management Parent & Children
    {"key": "resource_management", "name": "Resource Management", "route": "/inventory", "parent_key": None, "category": "Resources", "display_order": 19},
    {"key": "inventory", "name": "Inventory Management", "route": "/inventory", "parent_key": "resource_management", "category": "Resources", "display_order": 20},
    {"key": "topology", "name": "Environment Topology", "route": "/environment-topology", "parent_key": "resource_management", "category": "Resources", "display_order": 21},
    {"key": "monitoring", "name": "Environment Monitoring", "route": "/environment-monitoring", "parent_key": "resource_management", "category": "Resources", "display_order": 22},
    {"key": "predictive_demand", "name": "AI Predictive Demand", "route": "/ai-predictive-demand", "parent_key": "resource_management", "category": "Resources", "display_order": 23},

    # Advanced Operations
    {"key": "integrations", "name": "External Integrations", "route": "/external-integrations", "parent_key": None, "category": "Integrations", "display_order": 24},
    {"key": "runbooks", "name": "Runbooks", "route": "/runbooks", "parent_key": None, "category": "Automation", "display_order": 25},
]


class AccessDAO(BaseDAO[ApplicationScreen]):
    def __init__(self):
        super().__init__(ApplicationScreen)

    async def get_all_screens(self, db: AsyncSession) -> List[ApplicationScreen]:
        # Ensure default screens are present
        await self.seed_default_screens(db)
        query = select(ApplicationScreen).where(ApplicationScreen.is_active == True).order_by(ApplicationScreen.display_order.asc())
        result = await db.execute(query)
        screens = list(result.scalars().all())
        return screens

    async def seed_default_screens(self, db: AsyncSession) -> List[ApplicationScreen]:
        created_screens = []
        has_changes = False
        for s_data in DEFAULT_SCREENS:
            existing = await self.get_by_key(db, s_data["key"])
            if not existing:
                screen = ApplicationScreen(**s_data)
                db.add(screen)
                created_screens.append(screen)
                has_changes = True
            else:
                if (
                    existing.name != s_data["name"]
                    or existing.route != s_data["route"]
                    or existing.parent_key != s_data["parent_key"]
                    or existing.category != s_data["category"]
                    or existing.display_order != s_data["display_order"]
                ):
                    existing.name = s_data["name"]
                    existing.route = s_data["route"]
                    existing.parent_key = s_data["parent_key"]
                    existing.category = s_data["category"]
                    existing.display_order = s_data["display_order"]
                    has_changes = True
                created_screens.append(existing)
        if has_changes:
            await db.commit()
            for s in created_screens:
                await db.refresh(s)
        return created_screens

    async def get_by_key(self, db: AsyncSession, key: str) -> Optional[ApplicationScreen]:
        query = select(ApplicationScreen).where(ApplicationScreen.key == key)
        result = await db.execute(query)
        return result.scalars().first()

    async def get_role_access_entries(self, db: AsyncSession, role_id: str) -> List[RoleScreenAccess]:
        query = (
            select(RoleScreenAccess)
            .options(selectinload(RoleScreenAccess.screen))
            .where(RoleScreenAccess.role_id == role_id)
        )
        result = await db.execute(query)
        return list(result.scalars().all())

    async def save_role_access(
        self, db: AsyncSession, role_id: str, allowed_screen_ids: List[str]
    ) -> List[RoleScreenAccess]:
        # Delete existing mappings for role
        await db.execute(delete(RoleScreenAccess).where(RoleScreenAccess.role_id == role_id))

        new_entries = []
        for s_id in set(allowed_screen_ids):
            entry = RoleScreenAccess(role_id=role_id, screen_id=s_id, has_access=True)
            db.add(entry)
            new_entries.append(entry)

        await db.commit()
        return new_entries


access_dao = AccessDAO()
