from typing import List, Optional, Tuple
from sqlalchemy import select, func, or_, delete
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.user import User, user_roles
from app.models.role import Role


class UserDAO(BaseDAO[User]):
    def __init__(self):
        super().__init__(User)

    async def get_by_username(self, db: AsyncSession, username: str) -> Optional[User]:
        query = (
            select(User)
            .options(selectinload(User.roles), selectinload(User.business_unit))
            .where(func.lower(User.username) == username.strip().lower())
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_by_email(self, db: AsyncSession, email: str) -> Optional[User]:
        query = (
            select(User)
            .options(selectinload(User.roles), selectinload(User.business_unit))
            .where(func.lower(User.email) == email.strip().lower())
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_user_by_id_with_relations(self, db: AsyncSession, user_id: str) -> Optional[User]:
        query = (
            select(User)
            .options(selectinload(User.roles), selectinload(User.business_unit))
            .where(User.id == user_id)
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_all_users_with_relations(
        self,
        db: AsyncSession,
        search: Optional[str] = None,
        role_id: Optional[str] = None,
        bu_id: Optional[str] = None,
        is_active: Optional[bool] = None
    ) -> List[User]:
        query = (
            select(User)
            .options(selectinload(User.roles), selectinload(User.business_unit))
            .order_by(User.created_at.desc())
        )

        if is_active is not None:
            query = query.where(User.is_active == is_active)

        if bu_id:
            query = query.where(User.business_unit_id == bu_id)

        if role_id:
            query = query.join(User.roles).where(Role.id == role_id)

        if search and search.strip():
            pattern = f"%{search.strip().lower()}%"
            query = query.where(
                or_(
                    func.lower(User.username).like(pattern),
                    func.lower(User.email).like(pattern),
                    func.lower(User.first_name).like(pattern),
                    func.lower(User.last_name).like(pattern),
                )
            )

        result = await db.execute(query)
        return list(result.scalars().unique().all())

    async def create_user_with_roles(
        self, db: AsyncSession, user_dict: dict, assigned_roles: List[Role]
    ) -> User:
        user = User(**user_dict)
        user.roles = assigned_roles
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user

    async def update_user_with_roles(
        self,
        db: AsyncSession,
        user: User,
        update_dict: dict,
        assigned_roles: Optional[List[Role]] = None
    ) -> User:
        for key, value in update_dict.items():
            setattr(user, key, value)

        if assigned_roles is not None:
            user.roles = assigned_roles

        await db.commit()
        await db.refresh(user)
        return user


user_dao = UserDAO()
