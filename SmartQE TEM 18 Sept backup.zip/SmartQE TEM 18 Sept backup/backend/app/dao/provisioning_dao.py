from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
from sqlalchemy import func, select, desc, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.dao.base_dao import BaseDAO
from app.models.provisioning import (
    ProvisioningRequest, ProvisioningStep, ProvisioningResource, ProvisioningDependency,
    ProvisioningLog, ProvisioningTemplate, ProvisioningApproval, ProvisioningAudit,
    ProvisioningStatus, StepStatus
)


class ProvisioningTemplateDAO(BaseDAO[ProvisioningTemplate]):
    def __init__(self):
        super().__init__(ProvisioningTemplate)

    async def get_by_name(self, db: AsyncSession, name: str) -> Optional[ProvisioningTemplate]:
        query = select(self.model).where(self.model.name == name)
        result = await db.execute(query)
        return result.scalars().first()

    async def get_active_templates(self, db: AsyncSession) -> List[ProvisioningTemplate]:
        query = select(self.model).where(self.model.is_active == True).order_by(self.model.name)
        result = await db.execute(query)
        return list(result.scalars().all())


class ProvisioningRequestDAO(BaseDAO[ProvisioningRequest]):
    def __init__(self):
        super().__init__(ProvisioningRequest)

    async def get_detailed(self, db: AsyncSession, request_id: str) -> Optional[ProvisioningRequest]:
        query = (
            select(self.model)
            .where(self.model.id == request_id)
            .options(
                selectinload(self.model.steps),
                selectinload(self.model.resources),
                selectinload(self.model.dependencies),
                selectinload(self.model.logs),
                selectinload(self.model.approvals),
                selectinload(self.model.audits),
                selectinload(self.model.template),
            )
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_next_request_number(self, db: AsyncSession) -> str:
        current_year = datetime.now(timezone.utc).year
        prefix = f"PR-{current_year}-"
        query = select(func.count(self.model.id)).where(self.model.request_number.like(f"{prefix}%"))
        result = await db.execute(query)
        count = (result.scalar() or 0) + 1
        return f"{prefix}{count:04d}"

    async def filter_requests(
        self,
        db: AsyncSession,
        business_unit: Optional[str] = None,
        project_name: Optional[str] = None,
        application_name: Optional[str] = None,
        environment_name: Optional[str] = None,
        status: Optional[str] = None,
        owner: Optional[str] = None,
        provisioning_mode: Optional[str] = None,
        search: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> tuple[List[ProvisioningRequest], int]:
        conditions = []
        if business_unit and business_unit != "ALL":
            conditions.append(self.model.business_unit == business_unit)
        if project_name and project_name != "ALL":
            conditions.append(self.model.project_name == project_name)
        if application_name and application_name != "ALL":
            conditions.append(self.model.application_name == application_name)
        if environment_name and environment_name != "ALL":
            conditions.append(self.model.environment_name.ilike(f"%{environment_name}%"))
        if status and status != "ALL":
            conditions.append(self.model.status == status)
        if owner and owner != "ALL":
            conditions.append(or_(self.model.environment_owner.ilike(f"%{owner}%"), self.model.requested_by.ilike(f"%{owner}%")))
        if provisioning_mode and provisioning_mode != "ALL":
            conditions.append(self.model.provisioning_mode == provisioning_mode)
        if search:
            s = f"%{search}%"
            conditions.append(
                or_(
                    self.model.request_number.ilike(s),
                    self.model.environment_name.ilike(s),
                    self.model.project_name.ilike(s),
                    self.model.application_name.ilike(s),
                    self.model.requested_by.ilike(s),
                )
            )

        base_filter = and_(*conditions) if conditions else True

        # Count total
        count_query = select(func.count(self.model.id)).where(base_filter)
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        # Query paginated with steps
        query = (
            select(self.model)
            .where(base_filter)
            .options(selectinload(self.model.steps), selectinload(self.model.approvals))
            .order_by(desc(self.model.created_at))
            .offset(skip)
            .limit(limit)
        )
        result = await db.execute(query)
        return list(result.scalars().all()), total

    async def get_dashboard_kpis(self, db: AsyncSession) -> Dict[str, int]:
        query = select(self.model.status, func.count(self.model.id)).group_by(self.model.status)
        result = await db.execute(query)
        counts = {row[0]: row[1] for row in result.all()}

        total_requests = sum(counts.values())
        in_progress = (
            counts.get(ProvisioningStatus.PROVISIONING, 0)
            + counts.get(ProvisioningStatus.CONFIGURING, 0)
            + counts.get(ProvisioningStatus.HEALTH_CHECK, 0)
            + counts.get(ProvisioningStatus.QUEUED, 0)
            + counts.get(ProvisioningStatus.VALIDATING, 0)
        )
        ready = counts.get(ProvisioningStatus.READY, 0) + counts.get(ProvisioningStatus.PARTIALLY_READY, 0)
        failed = counts.get(ProvisioningStatus.FAILED, 0)
        pending_approval = counts.get(ProvisioningStatus.PENDING_APPROVAL, 0)
        decommissioning = (
            counts.get(ProvisioningStatus.DECOMMISSIONING, 0)
            + counts.get(ProvisioningStatus.DECOMMISSIONED, 0)
        )

        return {
            "total_requests": total_requests,
            "in_progress": in_progress,
            "ready": ready,
            "failed": failed,
            "pending_approval": pending_approval,
            "decommissioning": decommissioning,
        }

    async def append_audit(
        self,
        db: AsyncSession,
        request_id: str,
        action: str,
        performed_by: str,
        old_status: Optional[str] = None,
        new_status: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        ip_address: str = "127.0.0.1",
    ) -> ProvisioningAudit:
        audit = ProvisioningAudit(
            request_id=request_id,
            action=action,
            performed_by=performed_by,
            old_status=old_status,
            new_status=new_status,
            details=details or {},
            ip_address=ip_address,
            timestamp=datetime.now(timezone.utc),
        )
        db.add(audit)
        await db.commit()
        await db.refresh(audit)
        return audit

    async def append_log(
        self,
        db: AsyncSession,
        request_id: str,
        message: str,
        log_level: str = "INFO",
        source: str = "ORCHESTRATOR",
        step_id: Optional[str] = None,
        step_key: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> ProvisioningLog:
        log = ProvisioningLog(
            request_id=request_id,
            step_id=step_id,
            step_key=step_key,
            log_level=log_level,
            message=message,
            source=source,
            details=details or {},
            timestamp=datetime.now(timezone.utc),
        )
        db.add(log)
        await db.commit()
        await db.refresh(log)
        return log


class ProvisioningStepDAO(BaseDAO[ProvisioningStep]):
    def __init__(self):
        super().__init__(ProvisioningStep)

    async def get_by_request_and_order(
        self, db: AsyncSession, request_id: str, step_order: int
    ) -> Optional[ProvisioningStep]:
        query = (
            select(self.model)
            .where(and_(self.model.request_id == request_id, self.model.step_order == step_order))
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_steps_for_request(self, db: AsyncSession, request_id: str) -> List[ProvisioningStep]:
        query = (
            select(self.model)
            .where(self.model.request_id == request_id)
            .order_by(self.model.step_order)
        )
        result = await db.execute(query)
        return list(result.scalars().all())


class ProvisioningResourceDAO(BaseDAO[ProvisioningResource]):
    def __init__(self):
        super().__init__(ProvisioningResource)

    async def get_by_request(self, db: AsyncSession, request_id: str) -> List[ProvisioningResource]:
        query = select(self.model).where(self.model.request_id == request_id)
        result = await db.execute(query)
        return list(result.scalars().all())


class ProvisioningDependencyDAO(BaseDAO[ProvisioningDependency]):
    def __init__(self):
        super().__init__(ProvisioningDependency)

    async def get_by_request(self, db: AsyncSession, request_id: str) -> List[ProvisioningDependency]:
        query = select(self.model).where(self.model.request_id == request_id)
        result = await db.execute(query)
        return list(result.scalars().all())


class ProvisioningLogDAO(BaseDAO[ProvisioningLog]):
    def __init__(self):
        super().__init__(ProvisioningLog)

    async def get_logs_for_request(
        self, db: AsyncSession, request_id: str, step_id: Optional[str] = None
    ) -> List[ProvisioningLog]:
        conditions = [self.model.request_id == request_id]
        if step_id:
            conditions.append(self.model.step_id == step_id)
        query = select(self.model).where(and_(*conditions)).order_by(self.model.timestamp)
        result = await db.execute(query)
        return list(result.scalars().all())


class ProvisioningApprovalDAO(BaseDAO[ProvisioningApproval]):
    def __init__(self):
        super().__init__(ProvisioningApproval)

    async def get_by_request(self, db: AsyncSession, request_id: str) -> Optional[ProvisioningApproval]:
        query = select(self.model).where(self.model.request_id == request_id)
        result = await db.execute(query)
        return result.scalars().first()


class ProvisioningAuditDAO(BaseDAO[ProvisioningAudit]):
    def __init__(self):
        super().__init__(ProvisioningAudit)

    async def get_audits_for_request(self, db: AsyncSession, request_id: str) -> List[ProvisioningAudit]:
        query = select(self.model).where(self.model.request_id == request_id).order_by(desc(self.model.timestamp))
        result = await db.execute(query)
        return list(result.scalars().all())


# Singleton DAO instances
provisioning_template_dao = ProvisioningTemplateDAO()
provisioning_request_dao = ProvisioningRequestDAO()
provisioning_step_dao = ProvisioningStepDAO()
provisioning_resource_dao = ProvisioningResourceDAO()
provisioning_dependency_dao = ProvisioningDependencyDAO()
provisioning_log_dao = ProvisioningLogDAO()
provisioning_approval_dao = ProvisioningApprovalDAO()
provisioning_audit_dao = ProvisioningAuditDAO()
