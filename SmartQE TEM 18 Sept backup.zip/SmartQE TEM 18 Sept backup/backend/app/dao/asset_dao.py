from typing import List, Optional, Tuple, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_, desc, asc
from datetime import datetime, timezone
import uuid

from app.models.asset import Asset, AssetAuditLog, AssetType, InfrastructureType, CloudProvider, AssetStatus


from app.dependencies.auth import is_user_super_admin


class AssetDao:
    def _build_user_filter(self, current_user: Optional[any]):
        from sqlalchemy import false
        visible_condition = or_(Asset.is_visible == True, Asset.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]
        if not current_user:
            return [false()]
        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)
        return [
            visible_condition,
            or_(
                Asset.owner_id == user_id,
                Asset.created_by.ilike(username),
                Asset.created_by.ilike(full_name),
            )
        ]

    async def get_all(
        self,
        db: AsyncSession,
        search: Optional[str] = None,
        business_unit: Optional[str] = None,
        account_name: Optional[str] = None,
        environment_id: Optional[str] = None,
        environment_name: Optional[str] = None,
        asset_type: Optional[str] = None,
        infrastructure_type: Optional[str] = None,
        cloud_provider: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        operating_system: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
        sort_by: str = "created_at",
        sort_order: str = "desc",
        current_user: Optional[any] = None,
    ) -> Tuple[List[Asset], int]:
        conditions = self._build_user_filter(current_user)

        if search:
            q = f"%{search.strip().lower()}%"
            conditions.append(
                or_(
                    func.lower(Asset.name).like(q),
                    func.lower(Asset.asset_id).like(q),
                    func.lower(Asset.ip_address).like(q),
                    func.lower(Asset.hostname).like(q),
                    func.lower(Asset.business_unit).like(q),
                    func.lower(Asset.account_name).like(q),
                    func.lower(Asset.environment_name).like(q),
                    func.lower(Asset.application_name).like(q),
                    func.lower(Asset.instance_id).like(q),
                    func.lower(Asset.owner_team).like(q),
                )
            )

        if business_unit and business_unit != "ALL":
            conditions.append(func.lower(Asset.business_unit) == business_unit.lower())

        if account_name and account_name != "ALL":
            conditions.append(func.lower(Asset.account_name) == account_name.lower())

        if environment_id and environment_id != "ALL":
            conditions.append(Asset.environment_id == environment_id)
        elif environment_name and environment_name != "ALL":
            conditions.append(func.lower(Asset.environment_name) == environment_name.lower())

        if asset_type and asset_type != "ALL":
            conditions.append(Asset.asset_type == asset_type)

        if infrastructure_type and infrastructure_type != "ALL":
            conditions.append(Asset.infrastructure_type == infrastructure_type)

        if cloud_provider and cloud_provider != "ALL":
            conditions.append(Asset.cloud_provider == cloud_provider)

        if region and region != "ALL":
            conditions.append(func.lower(Asset.region) == region.lower())

        if status and status != "ALL":
            conditions.append(Asset.status == status)

        if operating_system and operating_system != "ALL":
            conditions.append(func.lower(Asset.operating_system).like(f"%{operating_system.lower()}%"))

        # Total count query
        count_stmt = select(func.count(Asset.id))
        if conditions:
            count_stmt = count_stmt.where(and_(*conditions))
        total_res = await db.execute(count_stmt)
        total_count = total_res.scalar_one()

        # Data query
        stmt = select(Asset)
        if conditions:
            stmt = stmt.where(and_(*conditions))

        # Sorting
        sort_column = getattr(Asset, sort_by, Asset.created_at)
        if sort_order.lower() == "asc":
            stmt = stmt.order_by(asc(sort_column))
        else:
            stmt = stmt.order_by(desc(sort_column))

        stmt = stmt.offset(skip).limit(limit)
        res = await db.execute(stmt)
        assets = list(res.scalars().all())

        return assets, total_count

    async def get_by_id(self, db: AsyncSession, id: str) -> Optional[Asset]:
        stmt = select(Asset).where(Asset.id == id)
        res = await db.execute(stmt)
        return res.scalar_one_or_none()

    async def get_by_id_for_user(self, db: AsyncSession, id: str, current_user: Optional[any] = None) -> Optional[Asset]:
        conditions = [Asset.id == id] + self._build_user_filter(current_user)
        stmt = select(Asset).where(and_(*conditions))
        res = await db.execute(stmt)
        return res.scalar_one_or_none()

    async def get_by_asset_id(self, db: AsyncSession, asset_id: str) -> Optional[Asset]:
        stmt = select(Asset).where(Asset.asset_id == asset_id)
        res = await db.execute(stmt)
        return res.scalar_one_or_none()

    async def create_with_audit(self, db: AsyncSession, data: Dict[str, Any], user: str = "System Admin", owner_id: Optional[str] = None) -> Asset:
        # Generate asset_id if not provided
        if not data.get("asset_id"):
            count_res = await db.execute(select(func.count(Asset.id)))
            count = count_res.scalar_one() + 1
            data["asset_id"] = f"AST-{1000 + count}"

        data["created_by"] = user
        data["updated_by"] = user
        if owner_id:
            data["owner_id"] = owner_id

        asset = Asset(**data)
        db.add(asset)
        await db.flush()

        # Create initial audit log
        audit_log = AssetAuditLog(
            asset_id=asset.id,
            action="CREATE",
            changed_by=user,
            changed_at=datetime.now(timezone.utc),
            field_name="ALL",
            new_value=f"Asset created with status {asset.status}",
            notes=f"Initial asset creation in {asset.environment_name or 'unassigned'} environment."
        )
        db.add(audit_log)
        await db.commit()
        await db.refresh(asset)
        return asset

    async def update_with_audit(self, db: AsyncSession, id: str, data: Dict[str, Any], user: str = "System Admin") -> Optional[Asset]:
        asset = await self.get_by_id(db, id)
        if not asset:
            return None

        # Track field differences for audit logging
        changes = []
        for key, val in data.items():
            if val is not None:
                old_val = getattr(asset, key, None)
                if old_val != val:
                    setattr(asset, key, val)
                    changes.append((key, str(old_val), str(val)))

        asset.updated_by = user
        asset.updated_at = datetime.now(timezone.utc)
        await db.flush()

        # Create audit records for significant changes
        for field, old_v, new_v in changes:
            audit_log = AssetAuditLog(
                asset_id=asset.id,
                action="UPDATE",
                changed_by=user,
                changed_at=datetime.now(timezone.utc),
                field_name=field,
                old_value=old_v[:250] if old_v else None,
                new_value=new_v[:250] if new_v else None,
                notes=f"Field '{field}' modified from '{old_v}' to '{new_v}'."
            )
            db.add(audit_log)

        await db.commit()
        await db.refresh(asset)
        return asset

    async def update_status_with_audit(self, db: AsyncSession, id: str, new_status: AssetStatus, reason: Optional[str] = None, user: str = "System Admin") -> Optional[Asset]:
        asset = await self.get_by_id(db, id)
        if not asset:
            return None

        old_status = asset.status
        if old_status != new_status:
            asset.status = new_status
            asset.updated_by = user
            asset.updated_at = datetime.now(timezone.utc)
            await db.flush()

            action_name = "RETIRE" if new_status == AssetStatus.RETIRED else "STATUS_CHANGE"
            audit_log = AssetAuditLog(
                asset_id=asset.id,
                action=action_name,
                changed_by=user,
                changed_at=datetime.now(timezone.utc),
                field_name="status",
                old_value=str(old_status.value if hasattr(old_status, 'value') else old_status),
                new_value=str(new_status.value if hasattr(new_status, 'value') else new_status),
                notes=reason or f"Status transitioned from {old_status} to {new_status}."
            )
            db.add(audit_log)
            await db.commit()
            await db.refresh(asset)

        return asset

    async def toggle_status(self, db: AsyncSession, id: str, user: str = "System Admin") -> Optional[Asset]:
        asset = await self.get_by_id(db, id)
        if not asset:
            return None
        current_active = getattr(asset, "is_active", True) and asset.status == AssetStatus.ACTIVE
        new_status = AssetStatus.INACTIVE if current_active else AssetStatus.ACTIVE
        new_active = not current_active
        asset.is_active = new_active
        return await self.update_status_with_audit(
            db, id, new_status, f"Asset status toggled to {new_status.value}", user
        )

    async def delete_asset(self, db: AsyncSession, id: str, hard_delete: bool = False, user: str = "System Admin") -> bool:
        asset = await self.get_by_id(db, id)
        if not asset:
            return False

        # Soft deactivation: always preserve asset in database and maintain relationships
        asset.is_active = False
        return (await self.update_status_with_audit(db, id, AssetStatus.INACTIVE, "Asset soft-deactivated", user)) is not None

    async def get_metrics(self, db: AsyncSession, current_user: Optional[any] = None) -> Dict[str, Any]:
        conditions = self._build_user_filter(current_user)
        all_stmt = select(Asset).where(and_(*conditions))
        res = await db.execute(all_stmt)
        assets = list(res.scalars().all())

        total = len(assets)
        env_names = set(a.environment_name for a in assets if a.environment_name)
        
        servers_count = sum(1 for a in assets if a.asset_type == AssetType.SERVER)
        databases_count = sum(1 for a in assets if a.asset_type == AssetType.DATABASE)
        cloud_res_count = sum(1 for a in assets if a.asset_type == AssetType.CLOUD_RESOURCE)
        network_count = sum(1 for a in assets if a.asset_type == AssetType.NETWORK_COMPONENT)
        software_count = sum(1 for a in assets if a.asset_type == AssetType.SOFTWARE)

        cloud_count = sum(1 for a in assets if a.infrastructure_type == InfrastructureType.CLOUD)
        on_prem_count = sum(1 for a in assets if a.infrastructure_type == InfrastructureType.ON_PREMISES)
        hybrid_count = sum(1 for a in assets if a.infrastructure_type == InfrastructureType.HYBRID)

        active_count = sum(1 for a in assets if a.status == AssetStatus.ACTIVE)
        inactive_count = sum(1 for a in assets if a.status == AssetStatus.INACTIVE)
        maint_count = sum(1 for a in assets if a.status == AssetStatus.MAINTENANCE)
        retired_count = sum(1 for a in assets if a.status in (AssetStatus.RETIRED, AssetStatus.DECOMMISSIONED))

        # EOL approaching count (within 90 days or specified)
        approaching_eol = 0
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        for a in assets:
            if a.end_of_life_date and a.end_of_life_date <= "2027-01-01":
                approaching_eol += 1

        # Groupings
        assets_by_bu: Dict[str, int] = {}
        assets_by_provider: Dict[str, int] = {}
        assets_by_status: Dict[str, int] = {}
        assets_by_type: Dict[str, int] = {}
        assets_by_os: Dict[str, int] = {}

        for a in assets:
            bu = a.business_unit or "Unassigned"
            assets_by_bu[bu] = assets_by_bu.get(bu, 0) + 1

            prov = (a.cloud_provider.value if hasattr(a.cloud_provider, 'value') else a.cloud_provider) or "Other"
            assets_by_provider[prov] = assets_by_provider.get(prov, 0) + 1

            stat = (a.status.value if hasattr(a.status, 'value') else a.status) or "ACTIVE"
            assets_by_status[stat] = assets_by_status.get(stat, 0) + 1

            atype = (a.asset_type.value if hasattr(a.asset_type, 'value') else a.asset_type) or "SERVER"
            assets_by_type[atype] = assets_by_type.get(atype, 0) + 1

            os_name = a.operating_system or "Other / Appliance"
            assets_by_os[os_name] = assets_by_os.get(os_name, 0) + 1

        return {
            "total_assets": total,
            "total_environments": len(env_names),
            "total_servers": servers_count,
            "total_databases": databases_count,
            "total_cloud_resources": cloud_res_count,
            "total_network_components": network_count,
            "total_software": software_count,
            "cloud_assets_count": cloud_count,
            "on_prem_assets_count": on_prem_count,
            "hybrid_assets_count": hybrid_count,
            "active_assets_count": active_count,
            "inactive_assets_count": inactive_count,
            "maintenance_assets_count": maint_count,
            "retired_assets_count": retired_count,
            "approaching_eol_count": approaching_eol,
            "assets_by_bu": assets_by_bu,
            "assets_by_provider": assets_by_provider,
            "assets_by_status": assets_by_status,
            "assets_by_type": assets_by_type,
            "assets_by_os": assets_by_os,
        }

    async def get_audit_logs(self, db: AsyncSession, asset_id: Optional[str] = None, limit: int = 50) -> List[AssetAuditLog]:
        stmt = select(AssetAuditLog)
        if asset_id:
            stmt = stmt.where(AssetAuditLog.asset_id == asset_id)
        stmt = stmt.order_by(desc(AssetAuditLog.changed_at)).limit(limit)
        res = await db.execute(stmt)
        return list(res.scalars().all())


asset_dao = AssetDao()
