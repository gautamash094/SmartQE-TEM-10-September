from typing import Any, Dict, Generic, List, Optional, Type, TypeVar, Union
from sqlalchemy import func, select, update as sql_update, delete as sql_delete
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.base import Base

ModelType = TypeVar("ModelType", bound=Base)


class BaseDAO(Generic[ModelType]):
    def __init__(self, model: Type[ModelType]):
        self.model = model

    async def get_by_id(self, db: AsyncSession, id: Any) -> Optional[ModelType]:
        query = select(self.model).where(self.model.id == str(id))
        result = await db.execute(query)
        return result.scalars().first()

    async def get_all(
        self, db: AsyncSession, skip: int = 0, limit: int = 100
    ) -> List[ModelType]:
        query = select(self.model).offset(skip).limit(limit)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def create(self, db: AsyncSession, obj_in: Dict[str, Any]) -> ModelType:
        db_obj = self.model(**obj_in)
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def update(
        self, db: AsyncSession, db_obj: ModelType, obj_in: Dict[str, Any]
    ) -> ModelType:
        for field, value in obj_in.items():
            if hasattr(db_obj, field) and value is not None:
                setattr(db_obj, field, value)
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def delete(self, db: AsyncSession, id: Any) -> bool:
        db_obj = await self.get_by_id(db, id)
        if not db_obj:
            return False
        await db.delete(db_obj)
        await db.commit()
        return True

    async def count(self, db: AsyncSession, filters: Optional[Dict[str, Any]] = None) -> int:
        query = select(func.count(self.model.id))
        if filters:
            for attr, val in filters.items():
                if hasattr(self.model, attr) and val is not None:
                    query = query.where(getattr(self.model, attr) == val)
        result = await db.execute(query)
        return result.scalar() or 0

    async def exists(self, db: AsyncSession, id: Any) -> bool:
        query = select(func.count(self.model.id)).where(self.model.id == str(id))
        result = await db.execute(query)
        return (result.scalar() or 0) > 0

    async def filter(
        self, db: AsyncSession, filters: Dict[str, Any], skip: int = 0, limit: int = 100
    ) -> List[ModelType]:
        query = select(self.model)
        for attr, val in filters.items():
            if hasattr(self.model, attr) and val is not None:
                query = query.where(getattr(self.model, attr) == val)
        query = query.offset(skip).limit(limit)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def search(
        self, db: AsyncSession, search_term: str, search_fields: List[str], skip: int = 0, limit: int = 100
    ) -> List[ModelType]:
        query = select(self.model)
        conditions = []
        for field in search_fields:
            if hasattr(self.model, field):
                column = getattr(self.model, field)
                conditions.append(column.ilike(f"%{search_term}%"))
        if conditions:
            from sqlalchemy import or_
            query = query.where(or_(*conditions))
        query = query.offset(skip).limit(limit)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def paginate(
        self, db: AsyncSession, page: int = 1, page_size: int = 20, filters: Optional[Dict[str, Any]] = None
    ) -> tuple[List[ModelType], int]:
        total = await self.count(db, filters)
        skip = (page - 1) * page_size
        items = await self.filter(db, filters or {}, skip=skip, limit=page_size)
        return items, total
