from datetime import datetime, timezone
from typing import List, Optional
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.email_notification import EmailNotification, NotificationStatus


class EmailNotificationDAO(BaseDAO[EmailNotification]):
    def __init__(self):
        super().__init__(EmailNotification)

    async def get_by_booking_id(self, db: AsyncSession, booking_id: str) -> List[EmailNotification]:
        query = (
            select(EmailNotification)
            .where(EmailNotification.booking_id == booking_id)
            .order_by(EmailNotification.created_at.asc())
        )
        result = await db.execute(query)
        return list(result.scalars().all())

    async def is_already_sent(
        self,
        db: AsyncSession,
        booking_id: str,
        notification_type: str,
        step_order: Optional[int] = None,
        recipient_to: Optional[str] = None
    ) -> bool:
        """
        Idempotency check: returns True if a notification for this booking, type,
        (and optional step_order / recipient_to) has already been recorded and sent (or pending).
        """
        conditions = [
            EmailNotification.booking_id == booking_id,
            EmailNotification.notification_type == notification_type,
            EmailNotification.status == NotificationStatus.SENT.value,
        ]
        if step_order is not None:
            conditions.append(EmailNotification.step_order == step_order)
        if recipient_to is not None:
            conditions.append(EmailNotification.recipient_to == recipient_to.strip().lower())

        query = select(EmailNotification).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first() is not None

    async def create_notification_record(
        self,
        db: AsyncSession,
        booking_id: str,
        notification_type: str,
        recipient_to: str,
        subject: str,
        body: str,
        recipient_cc: Optional[str] = None,
        step_order: Optional[int] = None,
        status: str = NotificationStatus.PENDING.value,
        sent_at: Optional[datetime] = None,
        error_message: Optional[str] = None
    ) -> EmailNotification:
        record = EmailNotification(
            booking_id=booking_id,
            notification_type=notification_type,
            step_order=step_order,
            recipient_to=recipient_to.strip().lower(),
            recipient_cc=recipient_cc.strip().lower() if recipient_cc else None,
            subject=subject,
            body=body,
            status=status,
            sent_at=sent_at,
            error_message=error_message,
            retry_count=0
        )
        db.add(record)
        await db.commit()
        await db.refresh(record)
        return record

    async def update_status(
        self,
        db: AsyncSession,
        notification: EmailNotification,
        status: str,
        sent_at: Optional[datetime] = None,
        error_message: Optional[str] = None
    ) -> EmailNotification:
        notification.status = status
        if sent_at is not None:
            notification.sent_at = sent_at
        if error_message is not None:
            notification.error_message = error_message
        await db.commit()
        await db.refresh(notification)
        return notification

    async def increment_retry(
        self,
        db: AsyncSession,
        notification: EmailNotification,
        status: str,
        sent_at: Optional[datetime] = None,
        error_message: Optional[str] = None
    ) -> EmailNotification:
        notification.retry_count += 1
        notification.status = status
        if sent_at is not None:
            notification.sent_at = sent_at
        if error_message is not None:
            notification.error_message = error_message
        await db.commit()
        await db.refresh(notification)
        return notification


email_notification_dao = EmailNotificationDAO()
