from typing import List, Optional, Tuple
from sqlalchemy import select, func, delete
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.user_group import UserGroup, UserGroupMember


class UserGroupDAO(BaseDAO[UserGroup]):
    def __init__(self):
        super().__init__(UserGroup)

    async def get_by_name(self, db: AsyncSession, name: str) -> Optional[UserGroup]:
        query = (
            select(UserGroup)
            .options(
                selectinload(UserGroup.business_unit),
                selectinload(UserGroup.members).selectinload(UserGroupMember.user)
            )
            .where(func.lower(UserGroup.name) == name.strip().lower())
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_with_details(self, db: AsyncSession, group_id: str) -> Optional[UserGroup]:
        query = (
            select(UserGroup)
            .options(
                selectinload(UserGroup.business_unit),
                selectinload(UserGroup.members).selectinload(UserGroupMember.user)
            )
            .where(UserGroup.id == group_id)
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def get_all_groups(
        self,
        db: AsyncSession,
        page: int = 1,
        page_size: int = 50,
        search: Optional[str] = None,
        bu_id: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> Tuple[List[UserGroup], int]:
        query = (
            select(UserGroup)
            .options(
                selectinload(UserGroup.business_unit),
                selectinload(UserGroup.members).selectinload(UserGroupMember.user)
            )
        )

        if bu_id:
            query = query.where(UserGroup.bu_id == bu_id)

        if is_active is not None:
            query = query.where(UserGroup.is_active == is_active)

        if search:
            s = f"%{search.strip()}%"
            query = query.where(
                (UserGroup.name.ilike(s)) | (UserGroup.description.ilike(s))
            )

        # Count total
        count_query = select(func.count()).select_from(query.subquery())
        total_result = await db.execute(count_query)
        total = total_result.scalar_one()

        # Paginate
        query = query.order_by(UserGroup.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
        result = await db.execute(query)
        groups = list(result.scalars().all())

        return groups, total

    async def save_members(
        self, db: AsyncSession, group_id: str, user_ids: List[str], created_by: str = "Super Admin"
    ) -> List[UserGroupMember]:
        # Delete existing members
        await db.execute(delete(UserGroupMember).where(UserGroupMember.group_id == group_id))

        new_members = []
        for u_id in set(user_ids):
            member = UserGroupMember(group_id=group_id, user_id=u_id, created_by=created_by)
            db.add(member)
            new_members.append(member)

        await db.commit()
        return new_members


user_group_dao = UserGroupDAO()
