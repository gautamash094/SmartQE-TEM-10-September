from typing import List, Optional, Tuple
from sqlalchemy import select, and_, or_, func, false
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.runbook import Runbook
from app.dependencies.auth import is_user_super_admin


class RunbookDAO(BaseDAO[Runbook]):
    def __init__(self):
        super().__init__(Runbook)

    def _build_user_filter(self, current_user: Optional[any]):
        visible_condition = or_(Runbook.is_visible == True, Runbook.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]
        if not current_user:
            return [false()]
        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)
        return [
            visible_condition,
            or_(
                Runbook.owner_id == user_id,
                Runbook.created_by.ilike(username),
                Runbook.created_by.ilike(full_name),
            )
        ]

    async def get_by_category(self, db: AsyncSession, category: str, current_user: Optional[any] = None) -> List[Runbook]:
        conditions = [Runbook.category == category] + self._build_user_filter(current_user)
        query = select(Runbook).where(and_(*conditions))
        result = await db.execute(query)
        return list(result.scalars().all())

    async def paginate_for_user(
        self, db: AsyncSession, current_user: Optional[any], page: int = 1, page_size: int = 20
    ) -> Tuple[List[Runbook], int]:
        conditions = self._build_user_filter(current_user)
        count_query = select(func.count(Runbook.id)).where(and_(*conditions))
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        start = (page - 1) * page_size
        query = (
            select(Runbook)
            .where(and_(*conditions))
            .order_by(Runbook.created_at.desc())
            .offset(start)
            .limit(page_size)
        )
        result = await db.execute(query)
        items = list(result.scalars().all())
        return items, total

    async def get_by_id_for_user(
        self, db: AsyncSession, rb_id: str, current_user: Optional[any]
    ) -> Optional[Runbook]:
        conditions = [Runbook.id == rb_id] + self._build_user_filter(current_user)
        query = select(Runbook).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()


runbook_dao = RunbookDAO()
