from typing import List, Optional
from sqlalchemy import select, and_, or_, false
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.portfolio import BusinessUnit, Project, Component, Application
from app.dependencies.auth import is_user_super_admin


class BusinessUnitDAO(BaseDAO[BusinessUnit]):
    def __init__(self):
        super().__init__(BusinessUnit)

    def _build_user_filter(self, current_user: Optional[any]):
        visible_condition = or_(BusinessUnit.is_visible == True, BusinessUnit.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]
        if not current_user:
            return [false()]
        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)
        return [
            visible_condition,
            or_(
                BusinessUnit.owner_id == user_id,
                BusinessUnit.created_by.ilike(username),
                BusinessUnit.created_by.ilike(full_name),
            )
        ]

    async def get_all_for_user(self, db: AsyncSession, current_user: Optional[any]) -> List[BusinessUnit]:
        conditions = self._build_user_filter(current_user)
        query = select(BusinessUnit).where(and_(*conditions)).order_by(BusinessUnit.created_at.desc())
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_by_id_for_user(self, db: AsyncSession, bu_id: str, current_user: Optional[any]) -> Optional[BusinessUnit]:
        conditions = [BusinessUnit.id == bu_id] + self._build_user_filter(current_user)
        query = select(BusinessUnit).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()


class ProjectDAO(BaseDAO[Project]):
    def __init__(self):
        super().__init__(Project)

    def _build_user_filter(self, current_user: Optional[any]):
        visible_condition = or_(Project.is_visible == True, Project.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]
        if not current_user:
            return [false()]
        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)

        return [
            visible_condition,
            or_(
                Project.owner_id == user_id,
                Project.created_by.ilike(username),
                Project.created_by.ilike(full_name),
            )
        ]

    async def get_all_for_user(self, db: AsyncSession, current_user: Optional[any]) -> List[Project]:
        conditions = self._build_user_filter(current_user)
        query = select(Project).where(and_(*conditions)).order_by(Project.created_at.desc())
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_by_id_for_user(self, db: AsyncSession, proj_id: str, current_user: Optional[any]) -> Optional[Project]:
        conditions = [Project.id == proj_id] + self._build_user_filter(current_user)
        query = select(Project).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()


class ComponentDAO(BaseDAO[Component]):
    def __init__(self):
        super().__init__(Component)

    def _build_user_filter(self, current_user: Optional[any]):
        visible_condition = or_(Component.is_visible == True, Component.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]
        if not current_user:
            return [false()]
        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)

        return [
            visible_condition,
            or_(
                Component.owner_id == user_id,
                Component.created_by.ilike(username),
                Component.created_by.ilike(full_name),
            )
        ]

    async def get_all_for_user(self, db: AsyncSession, current_user: Optional[any]) -> List[Component]:
        conditions = self._build_user_filter(current_user)
        query = select(Component).where(and_(*conditions)).order_by(Component.created_at.desc())
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_by_id_for_user(self, db: AsyncSession, comp_id: str, current_user: Optional[any]) -> Optional[Component]:
        conditions = [Component.id == comp_id] + self._build_user_filter(current_user)
        query = select(Component).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()


class ApplicationDAO(BaseDAO[Application]):
    def __init__(self):
        super().__init__(Application)

    def _build_user_filter(self, current_user: Optional[any]):
        visible_condition = or_(Application.is_visible == True, Application.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]
        if not current_user:
            return [false()]
        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)

        return [
            visible_condition,
            or_(
                Application.owner_id == user_id,
                Application.created_by.ilike(username),
                Application.created_by.ilike(full_name),
            )
        ]

    async def get_all_for_user(self, db: AsyncSession, current_user: Optional[any]) -> List[Application]:
        conditions = self._build_user_filter(current_user)
        query = select(Application).where(and_(*conditions)).order_by(Application.created_at.desc())
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_by_id_for_user(self, db: AsyncSession, app_id: str, current_user: Optional[any]) -> Optional[Application]:
        conditions = [Application.id == app_id] + self._build_user_filter(current_user)
        query = select(Application).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()


business_unit_dao = BusinessUnitDAO()
project_dao = ProjectDAO()
component_dao = ComponentDAO()
application_dao = ApplicationDAO()
