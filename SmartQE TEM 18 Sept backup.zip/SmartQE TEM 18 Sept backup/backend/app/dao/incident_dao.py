from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy import func, select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.incident import Incident, IncidentSeverity, IncidentStatus


class IncidentDAO(BaseDAO[Incident]):
    def __init__(self):
        super().__init__(Incident)

    def _build_user_filter_condition(self, current_user: Optional[any]):
        from sqlalchemy import false
        from app.dependencies.auth import is_user_super_admin
        visible_condition = or_(Incident.is_visible == True, Incident.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]

        if not current_user:
            return [false()]

        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)

        user_or_clauses = [
            Incident.assignee_id == user_id,
            Incident.created_by.ilike(username),
            Incident.created_by.ilike(full_name),
            Incident.assignee.ilike(username),
            Incident.assignee.ilike(full_name),
        ]

        return [
            visible_condition,
            or_(*user_or_clauses)
        ]

    async def paginate_for_user(
        self, db: AsyncSession, current_user: Optional[any], page: int = 1, page_size: int = 20
    ) -> Tuple[List[Incident], int]:
        conditions = self._build_user_filter_condition(current_user)

        count_query = select(func.count(Incident.id)).where(and_(*conditions))
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        start = (page - 1) * page_size
        query = (
            select(Incident)
            .where(and_(*conditions))
            .order_by(Incident.opened_at.desc())
            .offset(start)
            .limit(page_size)
        )
        result = await db.execute(query)
        items = list(result.scalars().all())
        return items, total

    async def get_by_id_for_user(
        self, db: AsyncSession, inc_id: str, current_user: Optional[any]
    ) -> Optional[Incident]:
        conditions = [Incident.id == inc_id] + self._build_user_filter_condition(current_user)
        query = select(Incident).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()

    async def get_open_incidents(self, db: AsyncSession, current_user: Optional[any] = None) -> List[Incident]:
        conditions = [Incident.status.in_([IncidentStatus.OPEN, IncidentStatus.INVESTIGATING])] + self._build_user_filter_condition(current_user)
        query = select(Incident).where(and_(*conditions))
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_severity_counts(self, db: AsyncSession, current_user: Optional[any] = None) -> Dict[str, int]:
        conditions = self._build_user_filter_condition(current_user)

        sev1_q = select(func.count(Incident.id)).where(and_(*(conditions + [Incident.severity == IncidentSeverity.SEV1])))
        sev2_q = select(func.count(Incident.id)).where(and_(*(conditions + [Incident.severity == IncidentSeverity.SEV2])))
        sev3_q = select(func.count(Incident.id)).where(and_(*(conditions + [Incident.severity == IncidentSeverity.SEV3])))
        sev4_q = select(func.count(Incident.id)).where(and_(*(conditions + [Incident.severity == IncidentSeverity.SEV4])))

        sev1 = (await db.execute(sev1_q)).scalar() or 0
        sev2 = (await db.execute(sev2_q)).scalar() or 0
        sev3 = (await db.execute(sev3_q)).scalar() or 0
        sev4 = (await db.execute(sev4_q)).scalar() or 0

        return {
            "SEV1": sev1,
            "SEV2": sev2,
            "SEV3": sev3,
            "SEV4": sev4
        }


incident_dao = IncidentDAO()
