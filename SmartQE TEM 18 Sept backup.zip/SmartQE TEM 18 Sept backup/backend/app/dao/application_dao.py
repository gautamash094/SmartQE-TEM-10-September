from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.application import Application


class ApplicationDAO(BaseDAO[Application]):
    def __init__(self):
        super().__init__(Application)

    async def get_by_code(self, db: AsyncSession, code: str) -> Optional[Application]:
        query = select(Application).where(Application.code == code)
        result = await db.execute(query)
        return result.scalars().first()


application_dao = ApplicationDAO()
