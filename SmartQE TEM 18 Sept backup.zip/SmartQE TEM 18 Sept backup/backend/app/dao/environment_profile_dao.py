from typing import List, Optional
from sqlalchemy import select, and_, or_, false
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.environment_profile import EnvironmentProfile
from app.dependencies.auth import is_user_super_admin


class EnvironmentProfileDAO(BaseDAO[EnvironmentProfile]):
    def __init__(self):
        super().__init__(EnvironmentProfile)

    def _build_user_filter(self, current_user: Optional[any]):
        visible_condition = or_(EnvironmentProfile.is_visible == True, EnvironmentProfile.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]
        if not current_user:
            return [false()]
        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)
        return [
            visible_condition,
            or_(
                EnvironmentProfile.owner_id == user_id,
                EnvironmentProfile.created_by.ilike(username),
                EnvironmentProfile.created_by.ilike(full_name),
            )
        ]

    async def get_all_for_user(self, db: AsyncSession, current_user: Optional[any], skip: int = 0, limit: int = 100) -> List[EnvironmentProfile]:
        conditions = self._build_user_filter(current_user)
        query = select(EnvironmentProfile).where(and_(*conditions)).offset(skip).limit(limit)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_by_id_for_user(self, db: AsyncSession, profile_id: str, current_user: Optional[any]) -> Optional[EnvironmentProfile]:
        conditions = [EnvironmentProfile.id == profile_id] + self._build_user_filter(current_user)
        query = select(EnvironmentProfile).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()


environment_profile_dao = EnvironmentProfileDAO()
