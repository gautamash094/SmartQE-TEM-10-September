import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional, List
from sqlalchemy import select, update
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.session import UserSession
from app.models.user import User


class SessionDAO:
    async def create_session(
        self,
        db: AsyncSession,
        user_id: str,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        idle_minutes: int = 20,
        absolute_hours: int = 8,
    ) -> UserSession:
        now = datetime.now(timezone.utc)
        session_id = secrets.token_urlsafe(32)
        absolute_expires_at = now + timedelta(hours=absolute_hours)

        session = UserSession(
            session_id=session_id,
            user_id=user_id,
            created_at=now,
            last_activity_at=now,
            absolute_expires_at=absolute_expires_at,
            status="ACTIVE",
            ip_address=ip_address,
            user_agent=user_agent,
        )
        db.add(session)
        await db.commit()
        await db.refresh(session)
        return session

    async def get_by_session_id(self, db: AsyncSession, session_id: str) -> Optional[UserSession]:
        query = (
            select(UserSession)
            .where(UserSession.session_id == session_id)
            .options(
                selectinload(UserSession.user).selectinload(User.roles),
                selectinload(UserSession.user).selectinload(User.business_unit),
            )
        )
        result = await db.execute(query)
        return result.scalars().first()

    async def update_last_activity(self, db: AsyncSession, session: UserSession) -> None:
        session.last_activity_at = datetime.now(timezone.utc)
        await db.commit()

    async def invalidate_session(
        self, db: AsyncSession, session_id: str, status: str = "LOGGED_OUT"
    ) -> Optional[UserSession]:
        query = select(UserSession).where(UserSession.session_id == session_id)
        result = await db.execute(query)
        session = result.scalars().first()
        if session:
            session.status = status
            session.logout_at = datetime.now(timezone.utc)
            await db.commit()
            await db.refresh(session)
        return session

    async def invalidate_all_user_sessions(
        self, db: AsyncSession, user_id: str, except_session_id: Optional[str] = None
    ) -> int:
        now = datetime.now(timezone.utc)
        query = (
            update(UserSession)
            .where(
                UserSession.user_id == user_id,
                UserSession.status == "ACTIVE",
                UserSession.session_id != (except_session_id or ""),
            )
            .values(status="EXPIRED", logout_at=now)
        )
        result = await db.execute(query)
        await db.commit()
        return result.rowcount

    async def get_active_user_sessions(self, db: AsyncSession, user_id: str) -> List[UserSession]:
        query = select(UserSession).where(
            UserSession.user_id == user_id,
            UserSession.status == "ACTIVE",
        ).order_by(UserSession.last_activity_at.desc())
        result = await db.execute(query)
        return list(result.scalars().all())


session_dao = SessionDAO()
