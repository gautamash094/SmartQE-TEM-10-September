from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy import func, select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.environment import Environment, EnvironmentStatus, EnvironmentTier, ComponentTopology


class EnvironmentDAO(BaseDAO[Environment]):
    def __init__(self):
        super().__init__(Environment)

    async def get_by_name(self, db: AsyncSession, name: str) -> Optional[Environment]:
        query = select(Environment).where(Environment.name == name)
        result = await db.execute(query)
        return result.scalars().first()

    async def filter_by_tier(self, db: AsyncSession, tier: EnvironmentTier) -> List[Environment]:
        query = select(Environment).where(Environment.tier == tier)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_health_summary(self, db: AsyncSession, current_user: Optional[any] = None) -> Dict[str, Any]:
        conditions = self._build_user_filter_condition(current_user)

        total_q = select(func.count(Environment.id)).where(and_(*conditions))
        healthy_q = select(func.count(Environment.id)).where(and_(*(conditions + [Environment.status == EnvironmentStatus.HEALTHY])))
        down_q = select(func.count(Environment.id)).where(and_(*(conditions + [Environment.status == EnvironmentStatus.DOWN])))
        
        cpu_q = select(func.avg(Environment.cpu_usage)).where(and_(*conditions))
        mem_q = select(func.avg(Environment.memory_usage)).where(and_(*conditions))
        storage_q = select(func.avg(Environment.storage_usage)).where(and_(*conditions))

        total = (await db.execute(total_q)).scalar() or 0
        healthy = (await db.execute(healthy_q)).scalar() or 0
        down = (await db.execute(down_q)).scalar() or 0

        cpu_avg = (await db.execute(cpu_q)).scalar() or 0.0
        mem_avg = (await db.execute(mem_q)).scalar() or 0.0
        storage_avg = (await db.execute(storage_q)).scalar() or 0.0

        return {
            "total": total,
            "healthy": healthy,
            "down": down,
            "cpu_avg": round(float(cpu_avg), 1),
            "mem_avg": round(float(mem_avg), 1),
            "storage_avg": round(float(storage_avg), 1)
        }

    def _build_user_filter_condition(self, current_user: Optional[any]):
        from sqlalchemy import false
        from app.dependencies.auth import is_user_super_admin
        visible_condition = or_(Environment.is_visible == True, Environment.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]

        if not current_user:
            return [false()]

        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)

        user_or_clauses = [
            Environment.owner_id == user_id,
            Environment.created_by.ilike(username),
            Environment.created_by.ilike(full_name),
        ]

        return [
            visible_condition,
            or_(*user_or_clauses)
        ]

    async def paginate_for_user(
        self, db: AsyncSession, current_user: Optional[any], page: int = 1, page_size: int = 20, search: Optional[str] = None
    ) -> Tuple[List[Environment], int]:
        conditions = self._build_user_filter_condition(current_user)
        if search:
            conditions.append(Environment.name.ilike(f"%{search}%"))

        count_query = select(func.count(Environment.id)).where(and_(*conditions))
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        start = (page - 1) * page_size
        query = (
            select(Environment)
            .where(and_(*conditions))
            .order_by(Environment.created_at.desc())
            .offset(start)
            .limit(page_size)
        )
        result = await db.execute(query)
        items = list(result.scalars().all())
        return items, total

    async def get_by_id_for_user(
        self, db: AsyncSession, env_id: str, current_user: Optional[any]
    ) -> Optional[Environment]:
        conditions = [Environment.id == env_id] + self._build_user_filter_condition(current_user)
        query = select(Environment).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()


environment_dao = EnvironmentDAO()
