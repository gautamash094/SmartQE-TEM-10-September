from datetime import datetime, timezone
from typing import List, Optional, Tuple
from sqlalchemy import select, and_, or_, func
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.reservation import Reservation, ReservationStatus, ReservationMode


class ReservationDAO(BaseDAO[Reservation]):
    def __init__(self):
        super().__init__(Reservation)

    async def get_by_environment(self, db: AsyncSession, env_id: str) -> List[Reservation]:
        query = select(Reservation).where(Reservation.environment_id == env_id)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def check_conflicts(
        self,
        db: AsyncSession,
        env_id: str,
        start_date: datetime,
        end_date: datetime,
        reservation_mode: ReservationMode = ReservationMode.SHARED,
        exclude_reservation_id: Optional[str] = None
    ) -> List[Reservation]:
        query = select(Reservation).where(
            and_(
                Reservation.environment_id == env_id,
                Reservation.status.in_([
                    ReservationStatus.CONFIRMED,
                    ReservationStatus.APPROVED,
                    ReservationStatus.CONFLICT,
                    ReservationStatus.PENDING,
                ]),
                Reservation.start_date < end_date,
                Reservation.end_date > start_date
            )
        )
        if exclude_reservation_id:
            query = query.where(Reservation.id != exclude_reservation_id)
        result = await db.execute(query)
        overlapping = list(result.scalars().all())

        # Enforce Reservation Mode Matrix:
        # SHARED + SHARED -> No Conflict
        # SHARED + DISRUPTIVE -> Conflict
        # DISRUPTIVE + SHARED / DISRUPTIVE -> Conflict
        conflicting = []
        for other in overlapping:
            other_mode = getattr(other, "reservation_mode", ReservationMode.SHARED) or ReservationMode.SHARED
            if reservation_mode == ReservationMode.DISRUPTIVE or other_mode == ReservationMode.DISRUPTIVE:
                conflicting.append(other)

        return conflicting

    async def recalculate_environment_conflicts(self, db: AsyncSession, env_id: str) -> None:
        """
        Re-evaluates all active reservations for a given environment.
        Considers ReservationMode matrix (SHARED vs DISRUPTIVE).
        """
        query = select(Reservation).where(
            and_(
                Reservation.environment_id == env_id,
                Reservation.status.in_([
                    ReservationStatus.CONFIRMED,
                    ReservationStatus.APPROVED,
                    ReservationStatus.CONFLICT,
                    ReservationStatus.PENDING,
                ])
            )
        )
        result = await db.execute(query)
        active_reservations = list(result.scalars().all())

        for r in active_reservations:
            r_mode = getattr(r, "reservation_mode", ReservationMode.SHARED) or ReservationMode.SHARED
            has_conflict = any(
                other.id != r.id and
                r.start_date < other.end_date and
                r.end_date > other.start_date and
                (
                    r_mode == ReservationMode.DISRUPTIVE or
                    (getattr(other, "reservation_mode", ReservationMode.SHARED) or ReservationMode.SHARED) == ReservationMode.DISRUPTIVE
                )
                for other in active_reservations
            )
            if has_conflict and r.status != ReservationStatus.CONFLICT:
                r.status = ReservationStatus.CONFLICT
            elif not has_conflict and r.status == ReservationStatus.CONFLICT:
                r.status = ReservationStatus.PENDING

        await db.commit()

    async def auto_reject_expired_reservations(self, db: AsyncSession) -> int:
        """
        Finds all reservations whose end_date is in the past,
        and transitions them to AUTO_REJECTED with audit metadata.
        Idempotent: skips CANCELLED, REJECTED, AUTO_REJECTED, COMPLETED.
        """
        now = datetime.now(timezone.utc)
        # Note: SQLite / Postgres DateTime comparison
        query = select(Reservation).where(
            and_(
                Reservation.end_date < now,
                Reservation.status.notin_([
                    ReservationStatus.CANCELLED,
                    ReservationStatus.REJECTED,
                    ReservationStatus.AUTO_REJECTED,
                    ReservationStatus.COMPLETED
                ])
            )
        )
        result = await db.execute(query)
        expired = list(result.scalars().all())
        if not expired:
            return 0

        affected_env_ids = set()
        for r in expired:
            r.status = ReservationStatus.AUTO_REJECTED
            r.rejection_type = "AUTO"
            r.rejection_reason = "Booking end date and time has passed"
            r.rejected_at = now
            if r.environment_id:
                affected_env_ids.add(r.environment_id)

        await db.commit()

        # Recalculate remaining active reservations on affected environments
        for env_id in affected_env_ids:
            await self.recalculate_environment_conflicts(db, env_id)

        return len(expired)

    async def has_active_or_upcoming_reservations(
        self, db: AsyncSession, env_id: str, env_name: Optional[str] = None
    ) -> bool:
        """
        Checks if an environment has any confirmed, future, or conflicting reservations.
        """
        env_condition = [Reservation.environment_id == env_id]
        if env_name:
            env_condition.append(Reservation.environment_name.ilike(env_name.strip()))

        query = select(Reservation).where(
            and_(
                or_(*env_condition),
                Reservation.status.notin_([
                    ReservationStatus.CANCELLED,
                    ReservationStatus.REJECTED,
                    ReservationStatus.AUTO_REJECTED,
                    ReservationStatus.COMPLETED
                ])
            )
        )
        result = await db.execute(query)
        active_list = list(result.scalars().all())
        return len(active_list) > 0

    def _build_user_filter_condition(self, current_user: Optional[any]):
        """
        Builds SQL where conditions enforcing user-specific data isolation.
        Super Admin sees all visible records.
        Normal users see records created by them, owned by them, assigned to them,
        or where they are configured in the reservation's sequential workflow approval hierarchy.
        """
        from sqlalchemy import false
        from app.dependencies.auth import is_user_super_admin
        from app.models.workflow import WorkflowExecution, WorkflowExecutionStep, Workflow, WorkflowApprover
        visible_condition = or_(Reservation.is_visible == True, Reservation.is_visible.is_(None))
        if is_user_super_admin(current_user):
            return [visible_condition]

        if not current_user:
            return [false()]

        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)
        user_keys = [k for k in [user_id, username, full_name] if k]

        # Subquery 1: User is a step approver in WorkflowExecution for this reservation
        exec_subquery = (
            select(WorkflowExecution.entity_id)
            .join(WorkflowExecutionStep, WorkflowExecutionStep.execution_id == WorkflowExecution.id)
            .where(
                WorkflowExecution.entity_type == "RESERVATION",
                or_(
                    WorkflowExecutionStep.user_id.in_(user_keys),
                    WorkflowExecutionStep.action_by.in_(user_keys)
                )
            )
        )

        # Subquery 2: User is an approver in Workflow linked by workflow_id
        wf_subquery = (
            select(Workflow.id)
            .join(WorkflowApprover, WorkflowApprover.workflow_id == Workflow.id)
            .where(WorkflowApprover.user_id.in_(user_keys))
        )

        user_or_clauses = [
            Reservation.owner_id == user_id,
            Reservation.assigned_user_id == user_id,
            Reservation.created_by.in_(user_keys),
            Reservation.created_by.ilike(username),
            Reservation.created_by.ilike(full_name),
            Reservation.requested_by.in_(user_keys),
            Reservation.requested_by.ilike(username),
            Reservation.requested_by.ilike(full_name),
            Reservation.current_approver_id.in_(user_keys),
            Reservation.current_approver_name.ilike(username),
            Reservation.current_approver_name.ilike(full_name),
            Reservation.id.in_(exec_subquery),
            Reservation.workflow_id.in_(wf_subquery),
        ]

        return [
            visible_condition,
            or_(*user_or_clauses)
        ]

    async def paginate_for_user(
        self, db: AsyncSession, current_user: Optional[any], page: int = 1, page_size: int = 20
    ) -> Tuple[List[Reservation], int]:
        conditions = self._build_user_filter_condition(current_user)
        
        # Count total
        count_query = select(func.count(Reservation.id)).where(and_(*conditions))
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        # Paginated items
        start = (page - 1) * page_size
        query = (
            select(Reservation)
            .where(and_(*conditions))
            .order_by(Reservation.created_at.desc())
            .offset(start)
            .limit(page_size)
        )
        result = await db.execute(query)
        items = list(result.scalars().all())
        return items, total

    async def get_by_id_for_user(
        self, db: AsyncSession, res_id: str, current_user: Optional[any]
    ) -> Optional[Reservation]:
        conditions = [Reservation.id == res_id] + self._build_user_filter_condition(current_user)
        query = select(Reservation).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()


reservation_dao = ReservationDAO()

