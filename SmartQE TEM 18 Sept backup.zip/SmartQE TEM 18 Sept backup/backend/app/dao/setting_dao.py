import json
from typing import Optional, Dict, Any
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.setting import SystemSetting


class SettingDAO(BaseDAO[SystemSetting]):
    def __init__(self):
        super().__init__(SystemSetting)

    async def get_by_key(self, db: AsyncSession, key: str) -> Optional[SystemSetting]:
        query = select(self.model).where(self.model.key == key)
        result = await db.execute(query)
        return result.scalars().first()

    async def get_value(self, db: AsyncSession, key: str, default: Optional[str] = None) -> Optional[str]:
        setting = await self.get_by_key(db, key)
        return setting.value if setting and setting.value is not None else default

    async def set_value(self, db: AsyncSession, key: str, value: Any, description: Optional[str] = None) -> SystemSetting:
        val_str = json.dumps(value) if isinstance(value, (dict, list, bool)) else (str(value) if value is not None else "")
        setting = await self.get_by_key(db, key)
        if setting:
            setting.value = val_str
            if description:
                setting.description = description
            db.add(setting)
            await db.commit()
            await db.refresh(setting)
            return setting
        else:
            return await self.create(db, {
                "key": key,
                "value": val_str,
                "description": description or f"Setting for {key}"
            })

    async def get_app_config(self, db: AsyncSession) -> Dict[str, Any]:
        default_role_id = await self.get_value(db, "default_role_id", "")
        default_role_name = await self.get_value(db, "default_role_name", "")
        default_bu_id = await self.get_value(db, "default_business_unit_id", "")
        default_bu_name = await self.get_value(db, "default_business_unit_name", "")
        
        extra_str = await self.get_value(db, "extra_settings", "{}")
        try:
            extra_settings = json.loads(extra_str or "{}")
        except Exception:
            extra_settings = {}

        return {
            "default_role_id": default_role_id or None,
            "default_role_name": default_role_name or None,
            "default_business_unit_id": default_bu_id or None,
            "default_business_unit_name": default_bu_name or None,
            "extra_settings": extra_settings
        }

    async def update_app_config(self, db: AsyncSession, data: Dict[str, Any]) -> Dict[str, Any]:
        if "default_role_id" in data and data["default_role_id"] is not None:
            await self.set_value(db, "default_role_id", data["default_role_id"])
        if "default_role_name" in data and data["default_role_name"] is not None:
            await self.set_value(db, "default_role_name", data["default_role_name"])
        if "default_business_unit_id" in data and data["default_business_unit_id"] is not None:
            await self.set_value(db, "default_business_unit_id", data["default_business_unit_id"])
        if "default_business_unit_name" in data and data["default_business_unit_name"] is not None:
            await self.set_value(db, "default_business_unit_name", data["default_business_unit_name"])
        if "extra_settings" in data and data["extra_settings"] is not None:
            await self.set_value(db, "extra_settings", data["extra_settings"])

        return await self.get_app_config(db)


setting_dao = SettingDAO()
