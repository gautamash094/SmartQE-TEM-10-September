from typing import List, Tuple, Dict, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import EntityNotFoundException, PermissionDeniedException
from app.dao.release_dao import release_dao
from app.dao.environment_dao import environment_dao
from app.schemas.release import ReleaseCreate, ReleaseUpdate, ReleaseRead


class ReleaseService:
    async def create_release(
        self, db: AsyncSession, rel_in: ReleaseCreate, current_user: Optional[any] = None
    ) -> ReleaseRead:
        env = await environment_dao.get_by_id(db, rel_in.environment_id)
        if not env:
            env = await environment_dao.get_by_name(db, rel_in.environment_name)
            if not env:
                raise EntityNotFoundException("Environment", rel_in.environment_id)

        data = rel_in.model_dump()
        data["environment_id"] = env.id
        data["environment_name"] = env.name

        if current_user:
            data["created_by"] = current_user.username
            data["owner_id"] = str(current_user.id)
            if not data.get("lead_id"):
                data["lead_id"] = str(current_user.id)

        rel = await release_dao.create(db, data)
        return ReleaseRead.model_validate(rel)

    async def get_release_by_id(
        self, db: AsyncSession, rel_id: str, current_user: Optional[any] = None
    ) -> ReleaseRead:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("You do not have permission to access this resource.")
        return ReleaseRead.model_validate(rel)

    async def update_release(
        self, db: AsyncSession, rel_id: str, rel_in: ReleaseUpdate, current_user: Optional[any] = None
    ) -> ReleaseRead:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("You do not have permission to access this resource.")

        update_data = rel_in.model_dump(exclude_unset=True)
        update_data.pop("created_by", None)
        update_data.pop("owner_id", None)
        if current_user:
            update_data["modified_by"] = getattr(current_user, "username", "Super Admin")

        updated = await release_dao.update(db, rel, update_data)
        return ReleaseRead.model_validate(updated)

    async def delete_release(
        self, db: AsyncSession, rel_id: str, current_user: Optional[any] = None
    ) -> bool:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("You do not have permission to access this resource.")
        return await release_dao.delete(db, rel_id)

    async def get_releases_paginated(
        self, db: AsyncSession, page: int = 1, page_size: int = 20, current_user: Optional[any] = None
    ) -> Tuple[List[ReleaseRead], int]:
        items, total = await release_dao.paginate_for_user(db, current_user, page, page_size)
        return [ReleaseRead.model_validate(r) for r in items], total

    async def get_kanban_board(self, db: AsyncSession, current_user: Optional[any] = None) -> Dict[str, List[ReleaseRead]]:
        kanban = await release_dao.get_kanban_data(db, current_user=current_user)
        return {
            status: [ReleaseRead.model_validate(r) for r in items]
            for status, items in kanban.items()
        }


release_service = ReleaseService()
