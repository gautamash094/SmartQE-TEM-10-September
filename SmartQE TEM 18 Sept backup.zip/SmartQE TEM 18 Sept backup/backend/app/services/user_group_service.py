from typing import List, Optional, Tuple
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.user_group_dao import user_group_dao
from app.dao.portfolio_dao import business_unit_dao
from app.dao.user_dao import user_dao
from app.models.user_group import UserGroup, UserGroupMember
from app.models.user import User
from app.schemas.user_group import (
    UserGroupCreate,
    UserGroupUpdate,
    UserGroupRead,
    UserGroupMemberRead,
)


class UserGroupService:
    def _map_to_read(self, group: UserGroup) -> UserGroupRead:
        bu_name = group.business_unit.name if group.business_unit else None
        bu_code = group.business_unit.code if group.business_unit else None

        member_reads = []
        for m in (group.members or []):
            u: Optional[User] = m.user
            member_reads.append(
                UserGroupMemberRead(
                    id=m.id,
                    user_id=m.user_id,
                    username=u.username if u else None,
                    full_name=u.full_name if u else None,
                    email=u.email if u else None,
                    business_unit_id=u.business_unit_id if u else None,
                    is_active=u.is_active if u else True,
                    created_at=m.created_at,
                    created_by=m.created_by,
                )
            )

        return UserGroupRead(
            id=group.id,
            name=group.name,
            description=group.description,
            bu_id=group.bu_id,
            bu_name=bu_name,
            bu_code=bu_code,
            members=member_reads,
            member_count=len(member_reads),
            is_active=group.is_active,
            status=group.status,
            created_at=group.created_at,
            created_by=group.created_by,
            updated_at=group.updated_at,
            modified_by=group.modified_by,
        )

    async def _validate_bu_and_users(
        self, db: AsyncSession, bu_id: str, user_ids: List[str]
    ) -> None:
        # 1. Validate BU exists and is active
        bu = await business_unit_dao.get_by_id(db, bu_id)
        if not bu:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Business Unit with ID '{bu_id}' does not exist."
            )
        if not bu.is_active or bu.status == "INACTIVE":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Selected Business Unit '{bu.name}' is inactive. User groups can only be associated with active BUs."
            )

        # 2. Validate all users belong to the selected BU and are active
        if not user_ids or len(user_ids) == 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="At least one user must be selected for the User Group."
            )

        for u_id in user_ids:
            user = await user_dao.get_by_id(db, u_id)
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"User with ID '{u_id}' not found."
                )
            if not user.is_active or user.status == "INACTIVE":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"User '{user.username}' is inactive and cannot be added to a User Group."
                )
            if user.business_unit_id != bu_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"User '{user.username}' does not belong to the selected Business Unit '{bu.name}'. Only users tagged to '{bu.name}' can be added."
                )

    async def get_user_groups(
        self,
        db: AsyncSession,
        page: int = 1,
        page_size: int = 50,
        search: Optional[str] = None,
        bu_id: Optional[str] = None,
        is_active: Optional[bool] = None,
        current_user: Optional[User] = None,
    ) -> Tuple[List[UserGroupRead], int]:
        groups, total = await user_group_dao.get_all_groups(
            db,
            page=1,
            page_size=1000,
            search=search,
            bu_id=bu_id,
            is_active=is_active,
        )
        mapped = [self._map_to_read(g) for g in groups]

        if current_user:
            is_super = (
                getattr(current_user, "is_super_admin", False)
                or (getattr(current_user, "username", "").lower() == "admin")
                or any(getattr(r, "name", "").strip().lower() == "super admin" for r in (getattr(current_user, "roles", []) or []))
            )
            if not is_super:
                mapped = [
                    g for g in mapped
                    if any(
                        m.user_id == current_user.id
                        or (m.username and m.username.lower() == (current_user.username or "").lower())
                        for m in g.members
                    )
                    or (g.created_by and g.created_by.lower() == (current_user.username or "").lower())
                ]

        total = len(mapped)
        start = (page - 1) * page_size
        end = start + page_size
        return mapped[start:end], total

    async def get_user_group_by_id(self, db: AsyncSession, group_id: str) -> UserGroupRead:
        group = await user_group_dao.get_with_details(db, group_id)
        if not group:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User Group with ID '{group_id}' not found."
            )
        return self._map_to_read(group)

    async def create_user_group(
        self, db: AsyncSession, group_in: UserGroupCreate, actor: str = "Super Admin"
    ) -> UserGroupRead:
        # Check name uniqueness
        existing = await user_group_dao.get_by_name(db, group_in.name)
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"A User Group named '{group_in.name}' already exists."
            )

        # Validate BU and user membership
        await self._validate_bu_and_users(db, group_in.bu_id, group_in.user_ids)

        # Create group and members together
        group = UserGroup(
            name=group_in.name.strip(),
            description=group_in.description.strip() if group_in.description else "",
            bu_id=group_in.bu_id,
            status="ACTIVE" if group_in.is_active else "INACTIVE",
            is_active=group_in.is_active,
            created_by=actor,
            modified_by=actor,
        )
        for u_id in set(group_in.user_ids):
            group.members.append(UserGroupMember(user_id=u_id, created_by=actor))

        db.add(group)
        await db.commit()

        refreshed = await user_group_dao.get_with_details(db, group.id)
        return self._map_to_read(refreshed or group)

    async def update_user_group(
        self, db: AsyncSession, group_id: str, group_in: UserGroupUpdate, actor: str = "Super Admin"
    ) -> UserGroupRead:
        group = await user_group_dao.get_with_details(db, group_id)
        if not group:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User Group with ID '{group_id}' not found."
            )

        target_bu_id = group_in.bu_id or group.bu_id
        target_name = group_in.name or group.name

        # Check name uniqueness if name changed
        if group_in.name and group_in.name.strip().lower() != group.name.lower():
            existing = await user_group_dao.get_by_name(db, group_in.name)
            if existing and existing.id != group_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"A User Group named '{group_in.name}' already exists."
                )

        # Determine effective user IDs
        if group_in.user_ids is not None:
            effective_user_ids = group_in.user_ids
        else:
            effective_user_ids = [m.user_id for m in (group.members or [])]

        # Validate BU and membership
        await self._validate_bu_and_users(db, target_bu_id, effective_user_ids)

        if group_in.name is not None:
            group.name = group_in.name.strip()
        if group_in.description is not None:
            group.description = group_in.description.strip()
        if group_in.bu_id is not None:
            group.bu_id = group_in.bu_id
        if group_in.is_active is not None:
            group.is_active = group_in.is_active
            group.status = "ACTIVE" if group_in.is_active else "INACTIVE"
        elif group_in.status is not None:
            group.status = group_in.status
            group.is_active = group_in.status == "ACTIVE"
        group.modified_by = actor

        # Update members if provided
        if group_in.user_ids is not None:
            desired_user_ids = set(group_in.user_ids)
            current_members = list(group.members or [])

            # Remove members no longer in target list
            for member in current_members:
                if member.user_id not in desired_user_ids:
                    if member in group.members:
                        group.members.remove(member)
                    await db.delete(member)

            # Add newly selected members
            current_user_ids = {m.user_id for m in group.members}
            for u_id in desired_user_ids:
                if u_id not in current_user_ids:
                    group.members.append(UserGroupMember(user_id=u_id, created_by=actor))

        await db.commit()
        refreshed = await user_group_dao.get_with_details(db, group_id)
        return self._map_to_read(refreshed or group)

    async def toggle_group_status(
        self, db: AsyncSession, group_id: str, actor: str = "Super Admin"
    ) -> UserGroupRead:
        group = await user_group_dao.get_with_details(db, group_id)
        if not group:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User Group with ID '{group_id}' not found."
            )

        new_status = not group.is_active
        updated = await user_group_dao.update(
            db,
            group,
            {
                "is_active": new_status,
                "status": "ACTIVE" if new_status else "INACTIVE",
                "modified_by": actor,
            }
        )
        db.expire_all()
        refreshed = await user_group_dao.get_with_details(db, group_id)
        return self._map_to_read(refreshed or updated)

    async def delete_user_group(
        self, db: AsyncSession, group_id: str, actor: str = "Super Admin"
    ) -> None:
        group = await user_group_dao.get_with_details(db, group_id)
        if not group:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User Group with ID '{group_id}' not found."
            )

        # Soft deactivation
        await user_group_dao.update(
            db,
            group,
            {
                "is_active": False,
                "status": "INACTIVE",
                "modified_by": actor,
            }
        )


user_group_service = UserGroupService()
