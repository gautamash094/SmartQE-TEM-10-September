import random
from typing import List, Tuple, Dict, Optional
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import EntityNotFoundException, PermissionDeniedException
from app.dao.incident_dao import incident_dao
from app.dao.environment_dao import environment_dao
from app.schemas.incident import IncidentCreate, IncidentUpdate, IncidentRead


class IncidentService:
    async def create_incident(
        self, db: AsyncSession, inc_in: IncidentCreate, current_user: Optional[any] = None
    ) -> IncidentRead:
        env = await environment_dao.get_by_id(db, inc_in.environment_id)
        if not env:
            env = await environment_dao.get_by_name(db, inc_in.environment_name)
            if not env:
                raise EntityNotFoundException("Environment", inc_in.environment_id)

        data = inc_in.model_dump()
        data["environment_id"] = env.id
        data["environment_name"] = env.name

        if current_user:
            data["created_by"] = current_user.username
            data["owner_id"] = str(current_user.id)
            if not data.get("assignee_id"):
                data["assignee_id"] = str(current_user.id)

        if not data.get("incident_code"):
            data["incident_code"] = f"INC-{random.randint(10000, 99999)}"

        if not data.get("opened_at"):
            data["opened_at"] = datetime.now(timezone.utc)

        inc = await incident_dao.create(db, data)
        return IncidentRead.model_validate(inc)

    async def get_incident_by_id(
        self, db: AsyncSession, inc_id: str, current_user: Optional[any] = None
    ) -> IncidentRead:
        inc = await incident_dao.get_by_id_for_user(db, inc_id, current_user)
        if not inc:
            raise PermissionDeniedException("You do not have permission to access this resource.")
        return IncidentRead.model_validate(inc)

    async def update_incident(
        self, db: AsyncSession, inc_id: str, inc_in: IncidentUpdate, current_user: Optional[any] = None
    ) -> IncidentRead:
        inc = await incident_dao.get_by_id_for_user(db, inc_id, current_user)
        if not inc:
            raise PermissionDeniedException("You do not have permission to access this resource.")

        update_data = inc_in.model_dump(exclude_unset=True)
        update_data.pop("created_by", None)
        update_data.pop("owner_id", None)
        if update_data.get("status") == "RESOLVED" and not inc.resolved_at:
            update_data["resolved_at"] = datetime.now(timezone.utc)

        if current_user:
            update_data["modified_by"] = getattr(current_user, "username", "Super Admin")

        updated = await incident_dao.update(db, inc, update_data)
        return IncidentRead.model_validate(updated)

    async def delete_incident(
        self, db: AsyncSession, inc_id: str, current_user: Optional[any] = None
    ) -> bool:
        inc = await incident_dao.get_by_id_for_user(db, inc_id, current_user)
        if not inc:
            raise PermissionDeniedException("You do not have permission to access this resource.")
        return await incident_dao.delete(db, inc_id)

    async def get_incidents_paginated(
        self, db: AsyncSession, page: int = 1, page_size: int = 20, current_user: Optional[any] = None
    ) -> Tuple[List[IncidentRead], int]:
        items, total = await incident_dao.paginate_for_user(db, current_user, page, page_size)
        return [IncidentRead.model_validate(i) for i in items], total

    async def get_severity_summary(self, db: AsyncSession, current_user: Optional[any] = None) -> Dict[str, int]:
        return await incident_dao.get_severity_counts(db, current_user=current_user)


incident_service = IncidentService()
