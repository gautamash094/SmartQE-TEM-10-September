import re
import secrets
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Tuple
from fastapi import HTTPException, status
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import (
    get_password_hash,
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token,
)
from app.core.exceptions import AuthenticationFailedException
from app.dao.user_dao import user_dao
from app.dao.access_dao import access_dao
from app.models.auth_audit import AuthAuditLog, PasswordResetToken
from app.core.config import settings
from app.models.user import User
from app.models.session import UserSession
from app.dao.session_dao import session_dao


from app.schemas.auth import (
    LoginRequest, TokenResponse, AuthAuditLogRead,
    SessionStatusResponse, SessionRefreshResponse
)
from app.schemas.user import UserRoleInfo


def make_aware(dt: Optional[datetime]) -> datetime:
    if dt is None:
        return datetime.now(timezone.utc)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def validate_password_policy(password: str) -> None:
    """
    Validate that the password satisfies enterprise security policy:
    - At least 8 characters
    - At least 1 uppercase letter
    - At least 1 lowercase letter
    - At least 1 numeric digit
    - At least 1 special character
    """
    if len(password) < 8:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must be at least 8 characters in length."
        )
    if not re.search(r"[A-Z]", password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must contain at least one uppercase letter (A-Z)."
        )
    if not re.search(r"[a-z]", password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must contain at least one lowercase letter (a-z)."
        )
    if not re.search(r"\d", password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must contain at least one numeric digit (0-9)."
        )
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>\-_+=\[\]\\/`~]", password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must contain at least one special character (!@#$%^&*...)."
        )


class AuthService:
    async def log_auth_event(
        self,
        db: AsyncSession,
        username: str,
        event_type: str,
        status: str = "SUCCESS",
        user_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        details: Optional[str] = None,
    ) -> None:
        try:
            log_entry = AuthAuditLog(
                user_id=user_id,
                username=username,
                event_type=event_type,
                status=status,
                ip_address=ip_address,
                details=details,
            )
            db.add(log_entry)
            await db.commit()
        except Exception:
            pass

    async def authenticate_user(
        self,
        db: AsyncSession,
        login_data: LoginRequest,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> TokenResponse:
        uname = login_data.username.strip()
        user = await user_dao.get_by_username(db, uname)
        if not user:
            user = await user_dao.get_by_email(db, uname)

        if not user:
            await self.log_auth_event(
                db,
                username=uname,
                event_type="FAILED_LOGIN",
                status="FAILED",
                user_id=None,
                ip_address=ip_address,
                details="Invalid username/email or password",
            )
            raise AuthenticationFailedException("Invalid username/email or password.")

        if not user.hashed_password or not verify_password(login_data.password, user.hashed_password):
            await self.log_auth_event(
                db,
                username=uname,
                event_type="FAILED_LOGIN",
                status="FAILED",
                user_id=user.id if user else None,
                ip_address=ip_address,
                details="Invalid username/email or password",
            )
            raise AuthenticationFailedException("Invalid username/email or password.")

        if not user.is_active:
            await self.log_auth_event(
                db,
                username=user.username,
                event_type="FAILED_LOGIN",
                status="FAILED",
                user_id=user.id,
                ip_address=ip_address,
                details="Account is inactive",
            )
            raise AuthenticationFailedException("User account is inactive. Please contact an administrator.")

        # 1. Determine roles and allowed screens
        user_role_items: List[UserRoleInfo] = [
            UserRoleInfo.model_validate(r) for r in user.roles if r.is_active
        ]
        is_super_admin = any(r.name.lower().strip() == "super admin" for r in user.roles if r.is_active) or user.username.lower() == "admin"

        all_screens = await access_dao.get_all_screens(db)
        if is_super_admin:
            allowed_screens = [s.route for s in all_screens]
        else:
            allowed_screens_set = set()
            for r in user.roles:
                if not r.is_active:
                    continue
                entries = await access_dao.get_role_access_entries(db, r.id)
                for entry in entries:
                    if entry.has_access and entry.screen:
                        allowed_screens_set.add(entry.screen.route)
            allowed_screens = list(allowed_screens_set)

        primary_role = "SUPER_ADMIN" if is_super_admin else (user_role_items[0].name if user_role_items else "USER")

        # 2. Create server-side session in database
        server_session = await session_dao.create_session(
            db=db,
            user_id=user.id,
            ip_address=ip_address,
            user_agent=user_agent,
            idle_minutes=settings.SESSION_IDLE_TIMEOUT_MINUTES,
            absolute_hours=settings.SESSION_ABSOLUTE_TIMEOUT_HOURS,
        )

        # 3. Create tokens embedded with session_id
        access_token = create_access_token(
            subject=user.id,
            role=primary_role,
            session_id=server_session.session_id,
        )
        refresh_token = create_refresh_token(subject=user.id, role=primary_role)

        await self.log_auth_event(
            db,
            username=user.username,
            event_type="LOGIN",
            status="SUCCESS",
            user_id=user.id,
            ip_address=ip_address,
            details=f"Successful authentication. Server Session created: {server_session.session_id[:8]}...",
        )

        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            user_id=user.id,
            username=user.username,
            email=user.email,
            full_name=user.full_name,
            roles=user_role_items,
            is_super_admin=is_super_admin,
            allowed_screens=allowed_screens,
            session_id=server_session.session_id,
        )

    async def logout_session(
        self,
        db: AsyncSession,
        session_id: Optional[str],
        user: Optional[User] = None,
        ip_address: Optional[str] = None,
    ) -> bool:
        if session_id:
            await session_dao.invalidate_session(db, session_id, status="LOGGED_OUT")

        username = user.username if user else "anonymous"
        user_id = user.id if user else None

        await self.log_auth_event(
            db,
            username=username,
            event_type="LOGOUT",
            status="SUCCESS",
            user_id=user_id,
            ip_address=ip_address,
            details="User logged out successfully",
        )
        return True

    async def refresh_session_activity(
        self,
        db: AsyncSession,
        session_id: str,
        user: User,
    ) -> SessionRefreshResponse:
        session = await session_dao.get_by_session_id(db, session_id)
        if not session or session.status != "ACTIVE":
            raise AuthenticationFailedException("Session is invalid or already terminated.")

        now = datetime.now(timezone.utc)
        abs_exp = make_aware(session.absolute_expires_at)
        last_act = make_aware(session.last_activity_at)

        if abs_exp < now:
            session.status = "EXPIRED"
            session.logout_at = now
            await db.commit()
            await self.log_auth_event(
                db,
                username=user.username,
                event_type="SESSION_EXPIRED",
                status="EXPIRED",
                user_id=user.id,
                details="ABSOLUTE_TIMEOUT",
            )
            raise AuthenticationFailedException("Session expired: Maximum session duration exceeded.")

        idle_limit = timedelta(minutes=settings.SESSION_IDLE_TIMEOUT_MINUTES)
        if now - last_act > idle_limit:
            session.status = "EXPIRED"
            session.logout_at = now
            await db.commit()
            await self.log_auth_event(
                db,
                username=user.username,
                event_type="SESSION_EXPIRED",
                status="EXPIRED",
                user_id=user.id,
                details="IDLE_TIMEOUT",
            )
            raise AuthenticationFailedException("Session expired due to 20 minutes of inactivity.")

        # Extend idle session activity timestamp
        session.last_activity_at = now
        await db.commit()

        idle_rem = max(0, int(settings.SESSION_IDLE_TIMEOUT_MINUTES * 60 - (now - now).total_seconds()))
        abs_rem = max(0, int((abs_exp - now).total_seconds()))

        return SessionRefreshResponse(
            success=True,
            message="Session refreshed successfully.",
            idle_remaining_seconds=idle_rem,
            absolute_remaining_seconds=abs_rem,
            last_activity_at=now,
        )

    async def get_session_status(
        self,
        db: AsyncSession,
        session_id: Optional[str],
        user: Optional[User],
    ) -> SessionStatusResponse:
        if not user or not session_id:
            return SessionStatusResponse(
                is_authenticated=False,
                idle_timeout_minutes=settings.SESSION_IDLE_TIMEOUT_MINUTES,
                idle_remaining_seconds=0,
                absolute_remaining_seconds=0,
                warning_minutes=settings.SESSION_WARNING_MINUTES,
                warning_remaining_seconds=0,
            )

        session = await session_dao.get_by_session_id(db, session_id)
        if not session or session.status != "ACTIVE":
            return SessionStatusResponse(
                is_authenticated=False,
                idle_timeout_minutes=settings.SESSION_IDLE_TIMEOUT_MINUTES,
                idle_remaining_seconds=0,
                absolute_remaining_seconds=0,
                warning_minutes=settings.SESSION_WARNING_MINUTES,
                warning_remaining_seconds=0,
            )

        now = datetime.now(timezone.utc)
        abs_exp = make_aware(session.absolute_expires_at)
        last_act = make_aware(session.last_activity_at)

        idle_elapsed_sec = (now - last_act).total_seconds()
        idle_rem_sec = max(0, int(settings.SESSION_IDLE_TIMEOUT_MINUTES * 60 - idle_elapsed_sec))
        abs_rem_sec = max(0, int((abs_exp - now).total_seconds()))
        warn_rem_sec = max(0, int(idle_rem_sec - (settings.SESSION_WARNING_MINUTES * 60)))

        is_super_admin = any(r.name.lower().strip() == "super admin" for r in user.roles if r.is_active) or user.username.lower() == "admin"
        user_role_items: List[UserRoleInfo] = [
            UserRoleInfo.model_validate(r) for r in user.roles if r.is_active
        ]

        all_screens = await access_dao.get_all_screens(db)
        if is_super_admin:
            allowed_screens = [s.route for s in all_screens]
        else:
            allowed_screens_set = set()
            for r in user.roles:
                if not r.is_active:
                    continue
                entries = await access_dao.get_role_access_entries(db, r.id)
                for entry in entries:
                    if entry.has_access and entry.screen:
                        allowed_screens_set.add(entry.screen.route)
            allowed_screens = list(allowed_screens_set)

        return SessionStatusResponse(
            is_authenticated=True,
            session_id=session.session_id,
            user_id=user.id,
            username=user.username,
            email=user.email,
            full_name=user.full_name,
            is_super_admin=is_super_admin,
            roles=user_role_items,
            allowed_screens=allowed_screens,
            idle_timeout_minutes=settings.SESSION_IDLE_TIMEOUT_MINUTES,
            idle_remaining_seconds=idle_rem_sec,
            absolute_remaining_seconds=abs_rem_sec,
            warning_minutes=settings.SESSION_WARNING_MINUTES,
            warning_remaining_seconds=warn_rem_sec,
            created_at=session.created_at,
            last_activity_at=session.last_activity_at,
        )

    async def change_password(
        self,
        db: AsyncSession,
        user_id: str,
        current_password: str,
        new_password: str,
        ip_address: Optional[str] = None,
        current_session_id: Optional[str] = None,
    ) -> bool:
        user = await user_dao.get_user_by_id_with_relations(db, user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with ID '{user_id}' not found."
            )

        if not verify_password(current_password, user.hashed_password):
            await self.log_auth_event(
                db,
                username=user.username,
                event_type="PASSWORD_CHANGE",
                status="FAILED",
                user_id=user.id,
                ip_address=ip_address,
                details="Current password verification failed",
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Current password is incorrect."
            )

        validate_password_policy(new_password)
        hashed = get_password_hash(new_password)

        await user_dao.update_user_with_roles(
            db, user, {"hashed_password": hashed, "updated_by": user.username}
        )

        # Invalidate other active sessions for security
        await session_dao.invalidate_all_user_sessions(db, user_id, except_session_id=current_session_id)

        await self.log_auth_event(
            db,
            username=user.username,
            event_type="PASSWORD_CHANGE",
            status="SUCCESS",
            user_id=user.id,
            ip_address=ip_address,
            details="Password successfully changed by user. Other active sessions revoked.",
        )
        return True

    async def admin_reset_password(
        self,
        db: AsyncSession,
        target_user_id: str,
        new_password: str,
        admin_username: str,
        ip_address: Optional[str] = None,
    ) -> bool:
        user = await user_dao.get_user_by_id_with_relations(db, target_user_id)
        if not user:
            user = await user_dao.get_by_username(db, target_user_id)
        if not user and target_user_id.startswith("user-"):
            user = await user_dao.get_by_username(db, target_user_id.replace("user-", "", 1))
        if not user:
            user = await user_dao.get_by_email(db, target_user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with ID '{target_user_id}' not found."
            )

        validate_password_policy(new_password)
        hashed = get_password_hash(new_password)

        await user_dao.update_user_with_roles(
            db, user, {"hashed_password": hashed, "updated_by": admin_username}
        )

        # Invalidate all existing sessions for target user
        await session_dao.invalidate_all_user_sessions(db, user.id)

        await self.log_auth_event(
            db,
            username=user.username,
            event_type="PASSWORD_RESET",
            status="SUCCESS",
            user_id=user.id,
            ip_address=ip_address,
            details=f"Password reset by administrator ({admin_username}). All active sessions revoked.",
        )
        return True

    async def create_password_reset_token(
        self, db: AsyncSession, username_or_email: str
    ) -> Tuple[Optional[str], str]:
        uname = username_or_email.strip()
        user = await user_dao.get_by_username(db, uname)
        if not user:
            user = await user_dao.get_by_email(db, uname)

        if not user or not user.is_active:
            # Return generic message to avoid exposing user enumeration
            return None, "If an active account exists for this username/email, a password reset token has been generated."

        token = secrets.token_urlsafe(32)
        expires_at = datetime.now(timezone.utc) + timedelta(minutes=15)

        reset_token_entry = PasswordResetToken(
            user_id=user.id,
            token=token,
            expires_at=expires_at,
            is_used=False,
        )
        db.add(reset_token_entry)
        await db.commit()

        await self.log_auth_event(
            db,
            username=user.username,
            event_type="PASSWORD_RESET_REQUEST",
            status="SUCCESS",
            user_id=user.id,
            details="Password reset token generated (15 min validity)",
        )

        return token, "Password reset token generated successfully."

    async def reset_password_with_token(
        self, db: AsyncSession, token: str, new_password: str, ip_address: Optional[str] = None
    ) -> bool:
        query = select(PasswordResetToken).where(
            PasswordResetToken.token == token,
            PasswordResetToken.is_used == False,
        )
        result = await db.execute(query)
        token_entry = result.scalars().first()

        if not token_entry:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or already used password reset token."
            )

        now = datetime.now(timezone.utc)
        token_expiry = make_aware(token_entry.expires_at)

        if token_expiry < now:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Password reset token has expired. Please request a new token."
            )

        user = await user_dao.get_user_by_id_with_relations(db, token_entry.user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User associated with this reset token no longer exists."
            )

        validate_password_policy(new_password)
        hashed = get_password_hash(new_password)

        await user_dao.update_user_with_roles(
            db, user, {"hashed_password": hashed, "updated_by": "Self (Token Reset)"}
        )

        token_entry.is_used = True
        await db.commit()

        # Invalidate existing sessions
        await session_dao.invalidate_all_user_sessions(db, user.id)

        await self.log_auth_event(
            db,
            username=user.username,
            event_type="PASSWORD_RESET",
            status="SUCCESS",
            user_id=user.id,
            ip_address=ip_address,
            details="Password reset completed via token. All active sessions revoked.",
        )
        return True

    async def get_audit_logs(self, db: AsyncSession, limit: int = 50) -> List[AuthAuditLogRead]:
        query = select(AuthAuditLog).order_by(AuthAuditLog.created_at.desc()).limit(limit)
        result = await db.execute(query)
        logs = result.scalars().all()
        return [AuthAuditLogRead.model_validate(l) for l in logs]


auth_service = AuthService()

