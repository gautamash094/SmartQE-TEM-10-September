import asyncio
import json
from typing import Dict, Set, Any
from datetime import datetime, timezone


class ProvisioningEventStream:
    """Manages Server-Sent Events (SSE) subscriber queues per provisioning request."""

    def __init__(self):
        self._subscribers: Dict[str, Set[asyncio.Queue]] = {}

    def subscribe(self, request_id: str) -> asyncio.Queue:
        if request_id not in self._subscribers:
            self._subscribers[request_id] = set()
        queue = asyncio.Queue(maxsize=100)
        self._subscribers[request_id].add(queue)
        return queue

    def unsubscribe(self, request_id: str, queue: asyncio.Queue):
        if request_id in self._subscribers:
            self._subscribers[request_id].discard(queue)
            if not self._subscribers[request_id]:
                del self._subscribers[request_id]

    async def publish(self, request_id: str, event_type: str, data: Dict[str, Any]):
        """Broadcast event to all connected subscriber queues for this request."""
        payload = {
            "event": event_type,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if request_id in self._subscribers:
            for queue in list(self._subscribers[request_id]):
                try:
                    if not queue.full():
                        await queue.put(payload)
                except Exception:
                    pass


event_stream = ProvisioningEventStream()
