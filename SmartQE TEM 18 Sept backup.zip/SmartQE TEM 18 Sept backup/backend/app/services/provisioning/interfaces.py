from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class InfrastructureProvider(ABC):
    """Abstract interface for Compute, VM, Cloud, K8s, and Bare-Metal infrastructure operations."""

    @abstractmethod
    async def allocate(self, request_id: str, specs: Dict[str, Any]) -> Dict[str, Any]:
        """Allocate compute/VM/cluster node and return allocated resource metadata."""
        pass

    @abstractmethod
    async def configure(self, resource_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Configure allocated infrastructure resource (CPU, memory, tags, storage attachment)."""
        pass

    @abstractmethod
    async def deallocate(self, resource_id: str) -> bool:
        """Deallocate / terminate compute resource."""
        pass

    @abstractmethod
    async def get_status(self, resource_id: str) -> Dict[str, Any]:
        """Get live status of compute resource."""
        pass


class NetworkProvider(ABC):
    """Abstract interface for IP allocation, VLAN, Subnet, Load Balancer, and Firewall rules."""

    @abstractmethod
    async def allocate_ip(self, request_id: str, network_config: Dict[str, Any]) -> Dict[str, Any]:
        """Allocate static/DHCP IP address from subnet pool."""
        pass

    @abstractmethod
    async def configure_network(self, ip_address: str, network_config: Dict[str, Any]) -> Dict[str, Any]:
        """Configure VLAN, routing, subnet gateway, and DNS mappings."""
        pass

    @abstractmethod
    async def configure_firewall(self, ip_address: str, port_rules: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Open required ingress/egress ports and configure security groups."""
        pass

    @abstractmethod
    async def release_ip(self, ip_address: str) -> bool:
        """Release allocated IP back to network pool."""
        pass


class SoftwareProvider(ABC):
    """Abstract interface for OS provisioning, Runtime installation (JDK/Node/Python), and App deployment."""

    @abstractmethod
    async def install_os(self, resource_id: str, os_name: str, version: str) -> Dict[str, Any]:
        """Install or image baseline Operating System."""
        pass

    @abstractmethod
    async def install_package(self, resource_id: str, package_name: str, version: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Install software runtime, middleware, database, or tool."""
        pass

    @abstractmethod
    async def configure_service(self, resource_id: str, service_name: str, env_vars: List[Dict[str, Any]], properties: Dict[str, Any]) -> Dict[str, Any]:
        """Apply environment variables, application properties, and secrets."""
        pass

    @abstractmethod
    async def deploy_application(self, resource_id: str, app_name: str, artifact_url: Optional[str] = None) -> Dict[str, Any]:
        """Deploy application binary/container and start systemd/container service."""
        pass

    @abstractmethod
    async def uninstall(self, resource_id: str, package_name: str) -> bool:
        """Uninstall software package during rollback or decommission."""
        pass


class HealthCheckProvider(ABC):
    """Abstract interface for post-provisioning verification and automated health probes."""

    @abstractmethod
    async def probe_connectivity(self, ip_address: str) -> Dict[str, Any]:
        """Ping and TCP socket connection test."""
        pass

    @abstractmethod
    async def probe_ports(self, ip_address: str, ports: List[int]) -> List[Dict[str, Any]]:
        """Verify required service ports are listening."""
        pass

    @abstractmethod
    async def probe_database(self, connection_string: str) -> Dict[str, Any]:
        """Perform database connection handshake and query test."""
        pass

    @abstractmethod
    async def probe_endpoint(self, url: str) -> Dict[str, Any]:
        """Perform HTTP/HTTPS health endpoint GET request."""
        pass
