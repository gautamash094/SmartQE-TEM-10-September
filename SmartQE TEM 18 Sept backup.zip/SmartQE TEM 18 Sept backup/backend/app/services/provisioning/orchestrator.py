import asyncio
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import AsyncSessionLocal
from app.dao.provisioning_dao import (
    provisioning_request_dao,
    provisioning_step_dao,
    provisioning_resource_dao,
    provisioning_dependency_dao,
    provisioning_log_dao,
    provisioning_approval_dao,
    provisioning_audit_dao,
)
from app.models.provisioning import (
    ProvisioningRequest,
    ProvisioningStep,
    ProvisioningResource,
    ProvisioningDependency,
    ProvisioningLog,
    ProvisioningStatus,
    StepStatus,
    StepCategory,
)
from app.services.provisioning.mock_provider import (
    mock_infra_provider,
    mock_network_provider,
    mock_software_provider,
    mock_health_provider,
)
from app.services.provisioning.event_stream import event_stream
from app.models.environment import Environment, EnvironmentStatus, EnvironmentTier, ComponentTopology
from app.models.environment_profile import EnvironmentProfile
from app.models.asset import Asset, AssetType, InfrastructureType, AssetStatus, CloudProvider
from app.models.reservation import Reservation, ReservationStatus
from app.core.logging import logger


class ProvisioningOrchestrator:
    """Enterprise Provisioning Orchestration and State Machine Engine."""

    def generate_plan_steps(
        self,
        request_id: str,
        resource_specs: Dict[str, Any],
        software_stack: List[Dict[str, Any]],
        configuration_payload: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Generates sequential DAG execution steps for a provisioning request."""
        compute_type = resource_specs.get("compute_type", "VM")
        steps = [
            {
                "request_id": request_id,
                "step_order": 1,
                "step_key": "ALLOCATE_COMPUTE",
                "step_name": f"Allocate Compute Infrastructure ({compute_type})",
                "category": StepCategory.INFRASTRUCTURE,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 30,
                "parameters": resource_specs,
            },
            {
                "request_id": request_id,
                "step_order": 2,
                "step_key": "ALLOCATE_IP",
                "step_name": "Allocate Static IP & Subnet Mapping",
                "category": StepCategory.NETWORK,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 20,
                "parameters": resource_specs.get("network", {}),
            },
            {
                "request_id": request_id,
                "step_order": 3,
                "step_key": "CREATE_STORAGE",
                "step_name": "Provision & Attach Storage Volumes (OS + Data Disks)",
                "category": StepCategory.STORAGE,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 25,
                "parameters": {
                    "os_disk_gb": resource_specs.get("os_disk_gb", 50),
                    "data_disk_gb": resource_specs.get("data_disk_gb", 50),
                },
            },
            {
                "request_id": request_id,
                "step_order": 4,
                "step_key": "CONFIGURE_NETWORK",
                "step_name": "Configure Network Routing & Security Groups",
                "category": StepCategory.NETWORK,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 20,
                "parameters": {},
            },
            {
                "request_id": request_id,
                "step_order": 5,
                "step_key": "INSTALL_OS",
                "step_name": "Deploy Base OS & Apply Security Baseline",
                "category": StepCategory.SOFTWARE,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 45,
                "parameters": {"os": "RHEL 9.3 Enterprise Linux"},
            },
        ]

        # Dynamically append software packages
        step_idx = 6
        if software_stack:
            for sw in software_stack:
                sw_name = sw.get("name", "Software Package")
                sw_ver = sw.get("version", "Latest")
                steps.append({
                    "request_id": request_id,
                    "step_order": step_idx,
                    "step_key": f"INSTALL_{sw_name.upper().replace(' ', '_')}",
                    "step_name": f"Install & Configure {sw_name} ({sw_ver})",
                    "category": StepCategory.SOFTWARE,
                    "provider_type": "MOCK",
                    "status": StepStatus.PENDING,
                    "estimated_duration_sec": 35,
                    "parameters": sw,
                })
                step_idx += 1
        else:
            steps.append({
                "request_id": request_id,
                "step_order": step_idx,
                "step_key": "INSTALL_DEFAULT_STACK",
                "step_name": "Install Runtime Stack (OpenJDK 21 & Tomcat 10)",
                "category": StepCategory.SOFTWARE,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 35,
                "parameters": {},
            })
            step_idx += 1

        steps.extend([
            {
                "request_id": request_id,
                "step_order": step_idx,
                "step_key": "CONFIGURE_ENVIRONMENT",
                "step_name": "Apply Environment Variables, App Properties & Secret References",
                "category": StepCategory.CONFIGURATION,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 25,
                "parameters": configuration_payload,
            },
            {
                "request_id": request_id,
                "step_order": step_idx + 1,
                "step_key": "DEPLOY_APPLICATION",
                "step_name": "Deploy Application Services & Initialize Daemons",
                "category": StepCategory.DEPLOYMENT,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 40,
                "parameters": {},
            },
            {
                "request_id": request_id,
                "step_order": step_idx + 2,
                "step_key": "RUN_HEALTH_CHECKS",
                "step_name": "Execute Post-Provisioning Automated Health Probes",
                "category": StepCategory.HEALTH_CHECK,
                "provider_type": "MOCK",
                "status": StepStatus.PENDING,
                "estimated_duration_sec": 30,
                "parameters": {},
            },
        ])

        return steps

    async def execute_request_async(self, request_id: str, start_step_index: int = 1) -> None:
        """Asynchronous worker that drives the provisioning state machine through steps."""
        async with AsyncSessionLocal() as db:
            request = await provisioning_request_dao.get_detailed(db, request_id)
            if not request:
                logger.error(f"ProvisioningOrchestrator: Request {request_id} not found.")
                return

            try:
                # Update status to PROVISIONING
                old_status = request.status
                request.status = ProvisioningStatus.PROVISIONING
                request.execution_started_at = datetime.now(timezone.utc)
                await db.commit()

                await provisioning_request_dao.append_audit(
                    db, request_id, "PROVISION_STARTED", "System Orchestrator",
                    old_status=old_status, new_status=ProvisioningStatus.PROVISIONING
                )
                await provisioning_request_dao.append_log(
                    db, request_id,
                    f"🚀 Provisioning workflow started for environment '{request.environment_name}' (Mode: {request.provisioning_mode}).",
                    log_level="INFO", source="ORCHESTRATOR"
                )
                await event_stream.publish(request_id, "STATUS_CHANGE", {"status": ProvisioningStatus.PROVISIONING, "progress": 0.0})

                steps = await provisioning_step_dao.get_steps_for_request(db, request_id)
                total_steps = len(steps)
                request.total_steps = total_steps

                allocated_ip = "10.240.16.88"
                allocated_vm_id = f"i-{uuid.uuid4().hex[:8]}"
                allocated_hostname = f"tem-{request.environment_name.lower().replace(' ', '-')}-node01.infra.local"

                for i, step in enumerate(steps, 1):
                    if step.step_order < start_step_index:
                        continue  # Already executed in resume scenario

                    # Update step status to IN_PROGRESS
                    step.status = StepStatus.IN_PROGRESS
                    step.started_at = datetime.now(timezone.utc)
                    request.current_step_index = step.step_order
                    
                    # Update request status phase if entering configuration or health check
                    if step.category == StepCategory.CONFIGURATION and request.status != ProvisioningStatus.CONFIGURING:
                        request.status = ProvisioningStatus.CONFIGURING
                    elif step.category == StepCategory.HEALTH_CHECK and request.status != ProvisioningStatus.HEALTH_CHECK:
                        request.status = ProvisioningStatus.HEALTH_CHECK

                    await db.commit()

                    await provisioning_request_dao.append_log(
                        db, request_id,
                        f"▶ Step [{step.step_order}/{total_steps}]: Starting '{step.step_name}'...",
                        log_level="INFO", source="ORCHESTRATOR", step_id=step.id, step_key=step.step_key
                    )
                    await event_stream.publish(request_id, "STEP_STARTED", {
                        "step_id": step.id,
                        "step_order": step.step_order,
                        "step_name": step.step_name,
                        "status": StepStatus.IN_PROGRESS,
                        "request_status": request.status,
                    })

                    # Execute Step via Mock Provider
                    step_start_time = datetime.now(timezone.utc)
                    step_output: Dict[str, Any] = {}

                    if step.step_key == "ALLOCATE_COMPUTE":
                        step_output = await mock_infra_provider.allocate(request_id, request.resource_specs or {})
                        allocated_vm_id = step_output.get("resource_id", allocated_vm_id)
                        allocated_hostname = step_output.get("hostname", allocated_hostname)
                        
                        # Save resource record
                        res_rec = ProvisioningResource(
                            request_id=request_id,
                            resource_type="COMPUTE",
                            resource_name=f"VM Node - {allocated_hostname}",
                            resource_id=allocated_vm_id,
                            provider=step_output.get("provider", "Mock Engine"),
                            status="ALLOCATED",
                            configuration=step_output,
                        )
                        db.add(res_rec)
                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ Compute allocated: Instance ID {allocated_vm_id} ({step_output.get('instance_type', 'c6i.xlarge')}) on Host Hypervisor.",
                            log_level="SUCCESS", source="INFRASTRUCTURE_PROVIDER", step_id=step.id, step_key=step.step_key
                        )

                    elif step.step_key == "ALLOCATE_IP":
                        step_output = await mock_network_provider.allocate_ip(request_id, request.resource_specs.get("network", {}) if request.resource_specs else {})
                        allocated_ip = step_output.get("ip_address", allocated_ip)

                        res_rec = ProvisioningResource(
                            request_id=request_id,
                            resource_type="IP",
                            resource_name=f"Static IP - {allocated_ip}",
                            resource_id=allocated_ip,
                            provider="Mock Network Engine",
                            status="ALLOCATED",
                            configuration=step_output,
                        )
                        db.add(res_rec)
                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ Network IP mapped: {allocated_ip} bound to subnet {step_output.get('subnet')} (Gateway: {step_output.get('gateway')}).",
                            log_level="SUCCESS", source="NETWORK_PROVIDER", step_id=step.id, step_key=step.step_key
                        )

                    elif step.step_key == "CREATE_STORAGE":
                        step_output = await mock_infra_provider.configure(allocated_vm_id, step.parameters)
                        res_rec = ProvisioningResource(
                            request_id=request_id,
                            resource_type="STORAGE",
                            resource_name=f"EBS Volumes (OS + Data)",
                            resource_id=f"vol-{uuid.uuid4().hex[:8]}",
                            provider="Mock Storage Engine",
                            status="ATTACHED",
                            configuration=step_output,
                        )
                        db.add(res_rec)
                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ Storage initialized: Mounted / (OS Disk) and /data (Data Disk).",
                            log_level="SUCCESS", source="STORAGE_PROVIDER", step_id=step.id, step_key=step.step_key
                        )

                    elif step.step_key == "CONFIGURE_NETWORK":
                        step_output = await mock_network_provider.configure_firewall(allocated_ip, [])
                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ Firewall & Security Group {step_output.get('security_group_id')} attached with ports 22, 80, 443, 8080, 5432 allowed.",
                            log_level="SUCCESS", source="NETWORK_PROVIDER", step_id=step.id, step_key=step.step_key
                        )

                    elif step.step_key == "INSTALL_OS":
                        step_output = await mock_software_provider.install_os(allocated_vm_id, "RHEL", "9.3 Enterprise Linux")
                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ Operating system initialized: Red Hat Enterprise Linux 9.3 (Kernel: {step_output.get('kernel')}) with CIS security hardening applied.",
                            log_level="SUCCESS", source="SOFTWARE_PROVIDER", step_id=step.id, step_key=step.step_key
                        )

                    elif step.step_key.startswith("INSTALL_"):
                        sw_name = step.parameters.get("name", step.step_name)
                        sw_ver = step.parameters.get("version", "1.0")
                        step_output = await mock_software_provider.install_package(allocated_vm_id, sw_name, sw_ver, step.parameters)
                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ Package installed: {sw_name} v{sw_ver} -> {step_output.get('installation_path')}.",
                            log_level="SUCCESS", source="SOFTWARE_PROVIDER", step_id=step.id, step_key=step.step_key
                        )

                    elif step.step_key == "CONFIGURE_ENVIRONMENT":
                        env_vars = request.configuration_payload.get("env_vars", []) if request.configuration_payload else []
                        props = request.configuration_payload.get("application_properties", {}) if request.configuration_payload else {}
                        step_output = await mock_software_provider.configure_service(allocated_vm_id, "tem-application", env_vars, props)
                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ Environment configuration active: Applied {len(env_vars)} env variables and masked secret references.",
                            log_level="SUCCESS", source="CONFIGURATION_MANAGER", step_id=step.id, step_key=step.step_key
                        )

                    elif step.step_key == "DEPLOY_APPLICATION":
                        app_name = request.application_name or "TEM Service"
                        step_output = await mock_software_provider.deploy_application(allocated_vm_id, app_name)
                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ Application deployment ready: {app_name} daemon running on port 8080 (Health Endpoint: /actuator/health).",
                            log_level="SUCCESS", source="DEPLOYMENT_ENGINE", step_id=step.id, step_key=step.step_key
                        )

                    elif step.step_key == "RUN_HEALTH_CHECKS":
                        ping_res = await mock_health_provider.probe_connectivity(allocated_ip)
                        port_res = await mock_health_provider.probe_ports(allocated_ip, [8080, 5432])
                        db_res = await mock_health_provider.probe_database("postgresql://db.tem.local:5432/appdb")
                        app_res = await mock_health_provider.probe_endpoint(f"http://{allocated_ip}:8080/actuator/health")

                        health_results = [ping_res] + port_res + [db_res, app_res]
                        request.health_check_results = health_results
                        request.health_status = "HEALTHY"
                        step_output = {"health_probes": health_results}

                        await provisioning_request_dao.append_log(
                            db, request_id,
                            f"✓ All automated health probes PASSED: Ping {ping_res.get('latency_ms')}ms | Ports 8080/5432 OPEN | DB OK | App HTTP 200 OK.",
                            log_level="SUCCESS", source="HEALTH_CHECK_SERVICE", step_id=step.id, step_key=step.step_key
                        )

                    # Mark Step as Completed
                    step_end_time = datetime.now(timezone.utc)
                    step.status = StepStatus.COMPLETED
                    step.completed_at = step_end_time
                    step.actual_duration_sec = round((step_end_time - step_start_time).total_seconds(), 2)
                    step.execution_output = step_output

                    # Update Request Progress %
                    progress = round((step.step_order / total_steps) * 100.0, 1)
                    request.progress_percentage = progress
                    await db.commit()

                    await event_stream.publish(request_id, "STEP_COMPLETED", {
                        "step_id": step.id,
                        "step_order": step.step_order,
                        "status": StepStatus.COMPLETED,
                        "progress": progress,
                        "duration": step.actual_duration_sec,
                    })

                # ==========================================
                # ALL STEPS SUCCEEDED: SYNC TO TEM SYSTEM
                # ==========================================
                request.status = ProvisioningStatus.READY
                request.progress_percentage = 100.0
                request.execution_completed_at = datetime.now(timezone.utc)

                # 1. Register / Update in TEM Environments Table
                env_record = await self._sync_to_environments_table(db, request, allocated_ip, allocated_hostname)
                if env_record:
                    request.environment_id = env_record.id

                # 2. Register / Update in TEM Assets / Inventory Table
                await self._sync_to_inventory_table(db, request, allocated_ip, allocated_hostname, allocated_vm_id)

                # 3. Register Reservation if scheduled
                if request.scheduled_start and request.scheduled_end:
                    await self._sync_to_reservations_table(db, request)

                await db.commit()

                await provisioning_request_dao.append_audit(
                    db, request_id, "PROVISION_COMPLETED", "System Orchestrator",
                    old_status=ProvisioningStatus.HEALTH_CHECK, new_status=ProvisioningStatus.READY
                )
                await provisioning_request_dao.append_log(
                    db, request_id,
                    f"🎉 Environment '{request.environment_name}' is fully provisioned and marked READY for testing operations!",
                    log_level="SUCCESS", source="ORCHESTRATOR"
                )
                await event_stream.publish(request_id, "PROVISION_COMPLETED", {
                    "status": ProvisioningStatus.READY,
                    "progress": 100.0,
                    "environment_id": request.environment_id,
                })

            except Exception as ex:
                logger.error(f"ProvisioningOrchestrator: Execution failed on request {request_id}: {str(ex)}", exc_info=True)
                request.status = ProvisioningStatus.FAILED
                request.failure_reason = str(ex)
                await db.commit()

                await provisioning_request_dao.append_audit(
                    db, request_id, "PROVISION_FAILED", "System Orchestrator",
                    old_status=request.status, new_status=ProvisioningStatus.FAILED,
                    details={"error": str(ex)}
                )
                await provisioning_request_dao.append_log(
                    db, request_id,
                    f"❌ Provisioning step failed: {str(ex)}",
                    log_level="ERROR", source="ORCHESTRATOR"
                )
                await event_stream.publish(request_id, "PROVISION_FAILED", {
                    "status": ProvisioningStatus.FAILED,
                    "error": str(ex),
                })

    async def retry_step(self, request_id: str, step_id: Optional[str] = None) -> ProvisioningRequest:
        """Idempotently re-executes a failed step or resumes from the first incomplete step."""
        async with AsyncSessionLocal() as db:
            request = await provisioning_request_dao.get_detailed(db, request_id)
            if not request:
                raise ValueError(f"Request {request_id} not found.")

            target_step_order = 1
            if step_id:
                step = await provisioning_step_dao.get_by_id(db, step_id)
                if step:
                    target_step_order = step.step_order
                    step.status = StepStatus.PENDING
                    step.retry_count += 1
                    step.error_message = None
                    await db.commit()
            else:
                steps = await provisioning_step_dao.get_steps_for_request(db, request_id)
                for s in steps:
                    if s.status in [StepStatus.FAILED, StepStatus.PENDING, StepStatus.IN_PROGRESS]:
                        target_step_order = s.step_order
                        s.status = StepStatus.PENDING
                        s.retry_count += 1
                        s.error_message = None
                        await db.commit()
                        break

            request.status = ProvisioningStatus.QUEUED
            request.retry_count += 1
            request.failure_reason = None
            await db.commit()

            await provisioning_request_dao.append_audit(
                db, request_id, "RETRY_STEP", "Authorized User",
                old_status=ProvisioningStatus.FAILED, new_status=ProvisioningStatus.QUEUED,
                details={"target_step_order": target_step_order}
            )
            await provisioning_request_dao.append_log(
                db, request_id,
                f"🔄 Retrying provisioning from Step #{target_step_order} (Retry Attempt #{request.retry_count})...",
                log_level="INFO", source="USER"
            )

        # Launch async task
        asyncio.create_task(self.execute_request_async(request_id, start_step_index=target_step_order))
        return request

    async def rollback_request(self, request_id: str, performed_by: str = "Authorized User") -> ProvisioningRequest:
        """Executes a clean inverse teardown plan to release all allocated resources."""
        async with AsyncSessionLocal() as db:
            request = await provisioning_request_dao.get_detailed(db, request_id)
            if not request:
                raise ValueError(f"Request {request_id} not found.")

            old_status = request.status
            request.status = ProvisioningStatus.ROLLBACK
            await db.commit()

            await provisioning_request_dao.append_audit(
                db, request_id, "ROLLBACK_INITIATED", performed_by,
                old_status=old_status, new_status=ProvisioningStatus.ROLLBACK
            )
            await provisioning_request_dao.append_log(
                db, request_id,
                f"⚠️ Rollback initiated: Terminating compute instances, releasing IP allocation, and unmounting volumes.",
                log_level="WARN", source="ORCHESTRATOR"
            )

            # Mark allocated resources as RELEASED
            for res in request.resources:
                res.status = "RELEASED"
                res.released_at = datetime.now(timezone.utc)

            # Mark steps as ROLLED_BACK
            for step in request.steps:
                if step.status == StepStatus.COMPLETED:
                    step.rollback_status = "ROLLED_BACK"

            request.status = ProvisioningStatus.DECOMMISSIONED
            await db.commit()

            await provisioning_request_dao.append_audit(
                db, request_id, "ROLLBACK_COMPLETED", performed_by,
                old_status=ProvisioningStatus.ROLLBACK, new_status=ProvisioningStatus.DECOMMISSIONED
            )
            await provisioning_request_dao.append_log(
                db, request_id,
                f"✓ Rollback complete. All cloud & infrastructure assets safely deallocated.",
                log_level="SUCCESS", source="ORCHESTRATOR"
            )
            await event_stream.publish(request_id, "STATUS_CHANGE", {"status": ProvisioningStatus.DECOMMISSIONED})
            return request

    async def decommission_request(self, request_id: str, performed_by: str = "Authorized User") -> ProvisioningRequest:
        """Decommissions a ready/active environment, releasing its assets in TEM Inventory and Environments."""
        async with AsyncSessionLocal() as db:
            request = await provisioning_request_dao.get_detailed(db, request_id)
            if not request:
                raise ValueError(f"Request {request_id} not found.")

            old_status = request.status
            request.status = ProvisioningStatus.DECOMMISSIONING
            await db.commit()

            await provisioning_request_dao.append_audit(
                db, request_id, "DECOMMISSION_INITIATED", performed_by,
                old_status=old_status, new_status=ProvisioningStatus.DECOMMISSIONING
            )
            await provisioning_request_dao.append_log(
                db, request_id,
                f"🛑 Graceful decommission started: Stopping applications and releasing allocated inventory assets...",
                log_level="INFO", source="ORCHESTRATOR"
            )

            await asyncio.sleep(1.5)  # Simulate graceful teardown

            # Release resources
            for res in request.resources:
                res.status = "RELEASED"
                res.released_at = datetime.now(timezone.utc)

            # Update linked Environment if exists
            if request.environment_id:
                from sqlalchemy import select
                env_query = select(Environment).where(Environment.id == request.environment_id)
                env_res = await db.execute(env_query)
                env_obj = env_res.scalars().first()
                if env_obj:
                    env_obj.status = EnvironmentStatus.MAINTENANCE
                    env_obj.is_active = False

            request.status = ProvisioningStatus.DECOMMISSIONED
            await db.commit()

            await provisioning_request_dao.append_audit(
                db, request_id, "DECOMMISSION_COMPLETED", performed_by,
                old_status=ProvisioningStatus.DECOMMISSIONING, new_status=ProvisioningStatus.DECOMMISSIONED
            )
            await provisioning_request_dao.append_log(
                db, request_id,
                f"✓ Decommission complete: Environment '{request.environment_name}' teardown finalized.",
                log_level="SUCCESS", source="ORCHESTRATOR"
            )
            await event_stream.publish(request_id, "STATUS_CHANGE", {"status": ProvisioningStatus.DECOMMISSIONED})
            return request

    # ==========================================
    # TEM CROSS-MODULE SYNCHRONIZATION HELPERS
    # ==========================================

    async def _sync_to_environments_table(
        self, db: AsyncSession, request: ProvisioningRequest, ip_address: str, hostname: str
    ) -> Optional[Environment]:
        """Creates or updates Environment record in TEM Environments table."""
        from sqlalchemy import select
        query = select(Environment).where(Environment.name == request.environment_name)
        res = await db.execute(query)
        env = res.scalars().first()

        tier_map = {
            "DEV": EnvironmentTier.DEV,
            "QA": EnvironmentTier.QA,
            "SIT": EnvironmentTier.SIT,
            "UAT": EnvironmentTier.UAT,
            "PERFORMANCE": EnvironmentTier.PERF,
            "REGRESSION": EnvironmentTier.QA,
            "PRE-PRODUCTION": EnvironmentTier.PRE_PROD,
        }
        tier = tier_map.get(request.environment_type.upper(), EnvironmentTier.QA)

        tech_stack = [sw.get("name", "") for sw in (request.software_stack or []) if sw.get("name")]
        if not tech_stack:
            tech_stack = ["Linux RHEL 9", "Java 21", "Tomcat 10", "PostgreSQL 16"]

        if not env:
            env = Environment(
                name=request.environment_name,
                tier=tier,
                team=request.business_unit or "Enterprise QA",
                owner=request.environment_owner or request.requested_by,
                region=request.resource_specs.get("region", "us-east-1") if request.resource_specs else "us-east-1",
                status=EnvironmentStatus.HEALTHY,
                is_active=True,
                is_visible=True,
                uptime=99.9,
                cpu_usage=12.5,
                memory_usage=28.4,
                storage_usage=18.0,
                tech_stack=tech_stack,
                created_by=request.requested_by,
            )
            db.add(env)
            await db.flush()

            # Add Topology Components
            comp1 = ComponentTopology(
                environment_id=env.id,
                name=f"{request.application_name or 'Web'} App Server",
                category="SERVICE",
                version="2.4.1",
                status=EnvironmentStatus.HEALTHY,
            )
            comp2 = ComponentTopology(
                environment_id=env.id,
                name="PostgreSQL Primary Database",
                category="DATABASE",
                version="16.1",
                status=EnvironmentStatus.HEALTHY,
            )
            db.add_all([comp1, comp2])
        else:
            env.status = EnvironmentStatus.HEALTHY
            env.is_active = True
            env.tech_stack = tech_stack

        return env

    async def _sync_to_inventory_table(
        self, db: AsyncSession, request: ProvisioningRequest, ip_address: str, hostname: str, vm_id: str
    ) -> None:
        """Registers newly provisioned server in TEM Inventory (Asset Management)."""
        from sqlalchemy import select
        asset_id = f"AST-PRV-{request.request_number.split('-')[-1]}"
        query = select(Asset).where(Asset.asset_id == asset_id)
        res = await db.execute(query)
        existing_asset = res.scalars().first()

        if not existing_asset:
            specs = request.resource_specs or {}
            asset = Asset(
                asset_id=asset_id,
                name=f"VM-{request.environment_name}",
                asset_type=AssetType.SERVER,
                infrastructure_type=InfrastructureType.CLOUD,
                cloud_provider=CloudProvider.AWS,
                business_unit=request.business_unit or "Platform QE",
                account_name=request.project_name or "Enterprise Apps",
                environment_name=request.environment_name,
                environment_type=request.environment_type,
                application_name=request.application_name,
                ip_address=ip_address,
                hostname=hostname,
                operating_system="Red Hat Enterprise Linux 9.3",
                cpu_cores=specs.get("cpu_cores", 4),
                ram_gb=specs.get("ram_gb", 16.0),
                storage_gb=specs.get("storage_gb", 100.0),
                region=specs.get("region", "us-east-1"),
                instance_id=vm_id,
                instance_type=f"c6i.{specs.get('cpu_cores', 4) // 2 if specs.get('cpu_cores', 4) >= 4 else 1}xlarge",
                status=AssetStatus.ACTIVE,
                is_active=True,
                is_visible=True,
                owner_team=request.business_unit or "Platform QE",
                responsible_person=request.environment_owner,
                created_by=request.requested_by,
                updated_by="TEM Provisioning Orchestrator",
            )
            db.add(asset)

    async def _sync_to_reservations_table(self, db: AsyncSession, request: ProvisioningRequest) -> None:
        """Creates automatic booking reservation in Bookings Grid for scheduled provisioning."""
        start_dt = request.scheduled_start
        end_dt = request.scheduled_end
        if start_dt and end_dt:
            booking = Reservation(
                title=f"Provisioned Slot: {request.environment_name}",
                environment_name=request.environment_name,
                business_unit=request.business_unit or "Default BU",
                project_name=request.project_name or "Default Project",
                activity_type="AUTOMATED_PROVISIONING",
                requested_by=request.requested_by,
                requester_email=f"{request.requested_by.lower().replace(' ', '.')}@smartqe.io",
                start_date=start_dt,
                end_date=end_dt,
                status=ReservationStatus.CONFIRMED,
                allocated_server=request.environment_name,
                allocated_ip="10.240.16.88",
                environment_id=request.environment_id,
            )
            db.add(booking)
            await db.flush()
            request.booking_id = booking.id


# Singleton Orchestrator Instance
orchestrator = ProvisioningOrchestrator()
