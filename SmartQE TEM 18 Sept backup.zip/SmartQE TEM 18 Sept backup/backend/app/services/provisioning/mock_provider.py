import asyncio
import random
import uuid
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

from app.services.provisioning.interfaces import (
    InfrastructureProvider,
    NetworkProvider,
    SoftwareProvider,
    HealthCheckProvider,
)


class MockInfrastructureProvider(InfrastructureProvider):
    """High-fidelity simulated infrastructure adapter producing realistic cloud & VM telemetry."""

    async def allocate(self, request_id: str, specs: Dict[str, Any]) -> Dict[str, Any]:
        await asyncio.sleep(1.2)  # Simulate API call latency
        compute_type = specs.get("compute_type", "VM")
        cpu_cores = specs.get("cpu_cores", 4)
        ram_gb = specs.get("ram_gb", 16.0)
        storage_gb = specs.get("storage_gb", 100.0)
        vm_id = f"i-{uuid.uuid4().hex[:8]}"
        hostname = f"tem-{specs.get('environment_name', 'env').lower().replace(' ', '-')}-node01.infra.local"

        return {
            "resource_id": vm_id,
            "resource_type": "COMPUTE",
            "compute_type": compute_type,
            "hostname": hostname,
            "cpu_cores": cpu_cores,
            "ram_gb": ram_gb,
            "storage_gb": storage_gb,
            "status": "RUNNING",
            "provider": "Mock Cloud Engine",
            "hypervisor": "KVM / AWS Nitro",
            "instance_type": f"c6i.{cpu_cores // 2 if cpu_cores >= 4 else 1}xlarge",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

    async def configure(self, resource_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        await asyncio.sleep(0.8)
        return {
            "resource_id": resource_id,
            "status": "CONFIGURED",
            "attached_volumes": [
                {"mount": "/", "size_gb": config.get("os_disk_gb", 50), "fstype": "ext4", "device": "/dev/sda1"},
                {"mount": "/data", "size_gb": config.get("data_disk_gb", 50), "fstype": "xfs", "device": "/dev/sdb1"},
            ],
            "security_hardened": True,
            "configured_at": datetime.now(timezone.utc).isoformat(),
        }

    async def deallocate(self, resource_id: str) -> bool:
        await asyncio.sleep(0.8)
        return True

    async def get_status(self, resource_id: str) -> Dict[str, Any]:
        return {
            "resource_id": resource_id,
            "status": "ONLINE",
            "cpu_utilization": round(random.uniform(5.0, 25.0), 1),
            "memory_utilization": round(random.uniform(15.0, 45.0), 1),
            "disk_utilization": round(random.uniform(10.0, 30.0), 1),
        }


class MockNetworkProvider(NetworkProvider):
    """High-fidelity simulated network adapter managing IP allocation, VLAN, and Security Groups."""

    async def allocate_ip(self, request_id: str, network_config: Dict[str, Any]) -> Dict[str, Any]:
        await asyncio.sleep(1.0)
        vlan = network_config.get("vlan", "VLAN-100-QA")
        subnet = network_config.get("subnet", "10.240.16.0/24")
        ip_suffix = random.randint(15, 240)
        allocated_ip = f"10.240.16.{ip_suffix}"
        gateway = "10.240.16.1"
        dns_servers = ["10.240.0.10", "10.240.0.11"]

        return {
            "resource_id": allocated_ip,
            "resource_type": "IP",
            "ip_address": allocated_ip,
            "vlan": vlan,
            "subnet": subnet,
            "gateway": gateway,
            "dns_servers": dns_servers,
            "status": "ALLOCATED",
            "allocated_at": datetime.now(timezone.utc).isoformat(),
        }

    async def configure_network(self, ip_address: str, network_config: Dict[str, Any]) -> Dict[str, Any]:
        await asyncio.sleep(0.8)
        return {
            "ip_address": ip_address,
            "status": "CONFIGURED",
            "routing_table": "rtb-qa-primary-01",
            "mtu": 1500,
            "nat_gateway": "nat-09f1a234b8c",
        }

    async def configure_firewall(self, ip_address: str, port_rules: List[Dict[str, Any]]) -> Dict[str, Any]:
        await asyncio.sleep(0.9)
        default_rules = [
            {"port": 22, "protocol": "TCP", "source": "10.0.0.0/8", "action": "ALLOW", "description": "SSH Bastion"},
            {"port": 80, "protocol": "TCP", "source": "0.0.0.0/0", "action": "ALLOW", "description": "HTTP"},
            {"port": 443, "protocol": "TCP", "source": "0.0.0.0/0", "action": "ALLOW", "description": "HTTPS"},
            {"port": 8080, "protocol": "TCP", "source": "10.0.0.0/8", "action": "ALLOW", "description": "App Server / Tomcat"},
            {"port": 5432, "protocol": "TCP", "source": "10.240.0.0/16", "action": "ALLOW", "description": "PostgreSQL"},
        ]
        active_rules = port_rules if port_rules else default_rules
        return {
            "ip_address": ip_address,
            "security_group_id": f"sg-{uuid.uuid4().hex[:8]}",
            "rules_applied": active_rules,
            "status": "ACTIVE",
        }

    async def release_ip(self, ip_address: str) -> bool:
        await asyncio.sleep(0.5)
        return True


class MockSoftwareProvider(SoftwareProvider):
    """High-fidelity simulated software stack installer and runtime deployer."""

    async def install_os(self, resource_id: str, os_name: str, version: str) -> Dict[str, Any]:
        await asyncio.sleep(1.5)
        return {
            "resource_id": resource_id,
            "os_name": os_name,
            "os_version": version,
            "kernel": "5.14.0-362.8.1.el9_3.x86_64",
            "status": "INSTALLED",
            "security_patches_applied": 48,
        }

    async def install_package(self, resource_id: str, package_name: str, version: str, config: Dict[str, Any]) -> Dict[str, Any]:
        await asyncio.sleep(1.3)
        return {
            "resource_id": resource_id,
            "package_name": package_name,
            "version": version,
            "status": "INSTALLED",
            "installation_path": f"/opt/{package_name.lower().replace(' ', '-')}",
            "service_name": f"{package_name.lower().replace(' ', '-')}.service",
            "installed_at": datetime.now(timezone.utc).isoformat(),
        }

    async def configure_service(self, resource_id: str, service_name: str, env_vars: List[Dict[str, Any]], properties: Dict[str, Any]) -> Dict[str, Any]:
        await asyncio.sleep(1.0)
        return {
            "resource_id": resource_id,
            "service_name": service_name,
            "env_vars_count": len(env_vars),
            "properties_applied": len(properties),
            "status": "CONFIGURED",
        }

    async def deploy_application(self, resource_id: str, app_name: str, artifact_url: Optional[str] = None) -> Dict[str, Any]:
        await asyncio.sleep(1.8)
        return {
            "resource_id": resource_id,
            "app_name": app_name,
            "artifact": artifact_url or f"s3://smartqe-artifacts/builds/{app_name.lower()}-v2.4.1.war",
            "deployed_port": 8080,
            "health_endpoint": "/actuator/health",
            "status": "DEPLOYED",
            "deployed_at": datetime.now(timezone.utc).isoformat(),
        }

    async def uninstall(self, resource_id: str, package_name: str) -> bool:
        await asyncio.sleep(0.7)
        return True


class MockHealthCheckProvider(HealthCheckProvider):
    """High-fidelity simulated health probe and verification suite."""

    async def probe_connectivity(self, ip_address: str) -> Dict[str, Any]:
        await asyncio.sleep(0.8)
        latency_ms = round(random.uniform(1.2, 4.8), 2)
        return {
            "check": "ICMP_PING_CONNECTIVITY",
            "target": ip_address,
            "status": "PASSED",
            "latency_ms": latency_ms,
            "packet_loss_pct": 0.0,
            "message": f"Network reachability verified with {latency_ms}ms round-trip latency.",
        }

    async def probe_ports(self, ip_address: str, ports: List[int]) -> List[Dict[str, Any]]:
        await asyncio.sleep(1.0)
        results = []
        for port in ports:
            results.append({
                "check": f"PORT_PROBE_{port}",
                "port": port,
                "protocol": "TCP",
                "status": "PASSED",
                "open": True,
                "response_time_ms": round(random.uniform(2.0, 8.5), 2),
                "message": f"TCP port {port} is active and accepting connections.",
            })
        return results

    async def probe_database(self, connection_string: str) -> Dict[str, Any]:
        await asyncio.sleep(1.1)
        return {
            "check": "DATABASE_HANDSHAKE",
            "target": connection_string,
            "status": "PASSED",
            "connection_pool": "INITIALIZED",
            "query_latency_ms": round(random.uniform(3.5, 9.2), 2),
            "message": "PostgreSQL 16.1 connection handshake and schema verification successful.",
        }

    async def probe_endpoint(self, url: str) -> Dict[str, Any]:
        await asyncio.sleep(1.2)
        latency = round(random.uniform(15.0, 45.0), 1)
        return {
            "check": "HTTP_ACTUATOR_HEALTH",
            "url": url,
            "http_status": 200,
            "status": "PASSED",
            "response_time_ms": latency,
            "body": {"status": "UP", "components": {"db": {"status": "UP"}, "diskSpace": {"status": "UP"}}},
            "message": f"Health endpoint returned HTTP 200 OK ({latency}ms).",
        }


# Singleton mock provider instances
mock_infra_provider = MockInfrastructureProvider()
mock_network_provider = MockNetworkProvider()
mock_software_provider = MockSoftwareProvider()
mock_health_provider = MockHealthCheckProvider()
