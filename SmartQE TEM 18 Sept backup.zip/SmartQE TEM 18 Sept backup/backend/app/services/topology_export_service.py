import io
import csv
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.graphics.shapes import Drawing, Rect, String, Line, Circle


class TopologyExportService:

    @staticmethod
    def export_topology(
        graph_data: Dict[str, Any],
        scope: str = "ALL",
        selected_env_ids: Optional[List[str]] = None,
        export_format: str = "XLSX"
    ) -> Tuple[bytes, str, str]:
        """
        Main entry point for generating environment topology export.
        Returns: (file_bytes, filename, media_type)
        """
        fmt = export_format.upper()
        now_str = datetime.now().strftime("%Y-%m-%d")
        scope_str = scope.capitalize()
        
        # Filter nodes and edges if specific environments or scope applied
        nodes = graph_data.get("nodes", [])
        edges = graph_data.get("edges", [])
        metrics = graph_data.get("metrics", {})

        if scope == "SELECTED" and selected_env_ids:
            selected_set = set(selected_env_ids)
            matched_node_ids = set()
            for n in nodes:
                env_id = n.get("environment_id") or n.get("id")
                if env_id in selected_set or n.get("id") in selected_set:
                    matched_node_ids.add(n.get("id"))
            
            for e in edges:
                if e.get("source") in matched_node_ids or e.get("target") in matched_node_ids:
                    matched_node_ids.add(e.get("source"))
                    matched_node_ids.add(e.get("target"))

            nodes = [n for n in nodes if n.get("id") in matched_node_ids]
            valid_ids = set(n.get("id") for n in nodes)
            edges = [e for e in edges if e.get("source") in valid_ids and e.get("target") in valid_ids]

        if fmt == "CSV":
            data_bytes = TopologyExportService._generate_csv(nodes, edges, metrics)
            filename = f"Environment_Topology_{scope_str}_{now_str}.csv"
            media_type = "text/csv"
        elif fmt == "PDF":
            data_bytes = TopologyExportService._generate_pdf(nodes, edges, metrics, scope_str, now_str)
            filename = f"Environment_Topology_{scope_str}_{now_str}.pdf"
            media_type = "application/pdf"
        elif fmt == "DOCX":
            data_bytes = TopologyExportService._generate_docx(nodes, edges, metrics, scope_str, now_str)
            filename = f"Environment_Topology_{scope_str}_{now_str}.docx"
            media_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        else: # Default XLSX
            data_bytes = TopologyExportService._generate_xlsx(nodes, edges, metrics, scope_str, now_str)
            filename = f"Environment_Topology_{scope_str}_{now_str}.xlsx"
            media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

        return data_bytes, filename, media_type

    # -------------------------------------------------------------------------
    # 1. CSV EXPORT
    # -------------------------------------------------------------------------
    @staticmethod
    def _generate_csv(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]], metrics: Dict[str, Any]) -> bytes:
        output = io.StringIO()
        writer = csv.writer(output)

        # Section 1: Metrics & Overview
        writer.writerow(["=== ENVIRONMENT TOPOLOGY EXPORT ==="])
        writer.writerow(["Generated At", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
        writer.writerow(["Total Nodes", len(nodes)])
        writer.writerow(["Total Relationships", len(edges)])
        writer.writerow([])

        # Section 2: Environment Summary
        writer.writerow(["=== ENVIRONMENTS ==="])
        writer.writerow(["Environment ID", "Environment Name", "Type/Tier", "Status", "Business Unit", "Account/Network Zone", "Active Incidents"])
        env_nodes = [n for n in nodes if n.get("type") == "ENVIRONMENT"]
        for env in env_nodes:
            props = env.get("properties", {})
            writer.writerow([
                env.get("id", ""),
                env.get("name", ""),
                env.get("sub_type", props.get("type", "")),
                env.get("status", "HEALTHY"),
                env.get("business_unit", props.get("ownerTeam", "")),
                env.get("account_name", props.get("networkZone", "")),
                env.get("active_incidents_count", 0)
            ])
        writer.writerow([])

        # Section 3: Infrastructure & Servers
        writer.writerow(["=== SERVERS & INFRASTRUCTURE ==="])
        writer.writerow(["Server ID", "Server Name", "Environment ID", "Environment Name", "Type", "Status", "IP Address", "Hostname", "Cloud Provider", "Region", "Specs"])
        server_nodes = [n for n in nodes if n.get("type") == "SERVER"]
        for srv in server_nodes:
            writer.writerow([
                srv.get("id", ""),
                srv.get("name", ""),
                srv.get("environment_id", ""),
                srv.get("environment_name", ""),
                srv.get("sub_type", ""),
                srv.get("status", ""),
                srv.get("ip_address", ""),
                srv.get("hostname", ""),
                srv.get("cloud_provider", ""),
                srv.get("region", ""),
                srv.get("specs", "")
            ])
        writer.writerow([])

        # Section 4: Software Inventory
        writer.writerow(["=== SOFTWARE & SERVICES ==="])
        writer.writerow(["Software ID", "Software Name", "Environment ID", "Environment Name", "Category/Type", "Status", "Version", "Vendor"])
        sw_nodes = [n for n in nodes if n.get("type") in ["SOFTWARE", "SERVICE"]]
        for sw in sw_nodes:
            props = sw.get("properties", {})
            writer.writerow([
                sw.get("id", ""),
                sw.get("name", ""),
                sw.get("environment_id", ""),
                sw.get("environment_name", ""),
                sw.get("sub_type", props.get("category", "")),
                sw.get("status", ""),
                props.get("version", ""),
                props.get("vendor", "")
            ])
        writer.writerow([])

        # Section 5: Applications
        writer.writerow(["=== APPLICATIONS ==="])
        writer.writerow(["Application ID", "Application Name", "Business Unit", "Project", "Code", "Owner Team"])
        app_nodes = [n for n in nodes if n.get("type") in ["APPLICATION", "MICROSERVICE"]]
        for app in app_nodes:
            props = app.get("properties", {})
            writer.writerow([
                app.get("id", ""),
                app.get("name", ""),
                app.get("business_unit", ""),
                props.get("project", ""),
                props.get("code", ""),
                props.get("owner", "")
            ])
        writer.writerow([])

        # Section 6: Topology Relationships
        writer.writerow(["=== TOPOLOGY DEPENDENCIES & RELATIONSHIPS ==="])
        writer.writerow(["Relationship ID", "Source Node ID", "Source Node Name", "Source Type", "Relationship Type", "Target Node ID", "Target Node Name", "Target Type", "Port", "Protocol", "Latency (ms)"])
        node_map = {n.get("id"): n for n in nodes}
        for edge in edges:
            src = node_map.get(edge.get("source"), {})
            tgt = node_map.get(edge.get("target"), {})
            writer.writerow([
                edge.get("id", ""),
                edge.get("source", ""),
                src.get("name", edge.get("source", "")),
                src.get("type", ""),
                edge.get("relationship_type", "DEPENDS_ON"),
                edge.get("target", ""),
                tgt.get("name", edge.get("target", "")),
                tgt.get("type", ""),
                edge.get("port", ""),
                edge.get("protocol", ""),
                edge.get("latency_ms", "")
            ])

        return output.getvalue().encode('utf-8')

    # -------------------------------------------------------------------------
    # 2. XLSX EXPORT
    # -------------------------------------------------------------------------
    @staticmethod
    def _generate_xlsx(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]], metrics: Dict[str, Any], scope: str, date_str: str) -> bytes:
        wb = openpyxl.Workbook()
        wb.remove(wb.active)

        header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
        header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
        title_font = Font(name="Calibri", size=14, bold=True, color="0F172A")
        subtitle_font = Font(name="Calibri", size=10, italic=True, color="475569")
        regular_font = Font(name="Calibri", size=10)
        
        thin_border = Border(
            left=Side(style='thin', color='CBD5E1'),
            right=Side(style='thin', color='CBD5E1'),
            top=Side(style='thin', color='CBD5E1'),
            bottom=Side(style='thin', color='CBD5E1')
        )
        
        status_fills = {
            "HEALTHY": PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid"),
            "WARNING": PatternFill(start_color="FEF9C3", end_color="FEF9C3", fill_type="solid"),
            "CRITICAL": PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid"),
            "DOWN": PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid"),
            "DEGRADED": PatternFill(start_color="FFEDD5", end_color="FFEDD5", fill_type="solid")
        }

        node_map = {n.get("id"): n for n in nodes}

        # --- Sheet 1: Environment Summary ---
        ws_env = wb.create_sheet(title="Environment Summary")
        ws_env.views.sheetView[0].showGridLines = True

        ws_env.cell(row=1, column=1, value=f"SmartQE TEM - Environment Topology ({scope} Scope)").font = title_font
        ws_env.cell(row=2, column=1, value=f"Export Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Total Environments: {len([n for n in nodes if n.get('type') == 'ENVIRONMENT'])}").font = subtitle_font

        headers_env = ["Environment ID", "Environment Name", "Tier / Type", "Status", "Business Unit / Owner", "Network Zone / Region", "Incidents Count", "Description"]
        for col_num, header in enumerate(headers_env, 1):
            cell = ws_env.cell(row=4, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        env_nodes = [n for n in nodes if n.get("type") == "ENVIRONMENT"]
        row_idx = 5
        for env in env_nodes:
            props = env.get("properties", {})
            st = env.get("status", "HEALTHY")
            c1 = ws_env.cell(row=row_idx, column=1, value=env.get("id", ""))
            c2 = ws_env.cell(row=row_idx, column=2, value=env.get("name", ""))
            c3 = ws_env.cell(row=row_idx, column=3, value=env.get("sub_type", props.get("type", "")))
            c4 = ws_env.cell(row=row_idx, column=4, value=st)
            c5 = ws_env.cell(row=row_idx, column=5, value=env.get("business_unit", props.get("ownerTeam", "")))
            c6 = ws_env.cell(row=row_idx, column=6, value=env.get("account_name", props.get("networkZone", "")))
            c7 = ws_env.cell(row=row_idx, column=7, value=env.get("active_incidents_count", 0))
            c8 = ws_env.cell(row=row_idx, column=8, value=props.get("description", ""))

            for c in [c1, c2, c3, c4, c5, c6, c7, c8]:
                c.font = regular_font
                c.border = thin_border
            c4.alignment = Alignment(horizontal="center")
            if st in status_fills:
                c4.fill = status_fills[st]
            row_idx += 1

        # --- Sheet 2: Servers & Infrastructure ---
        ws_srv = wb.create_sheet(title="Servers")
        ws_srv.views.sheetView[0].showGridLines = True
        ws_srv.cell(row=1, column=1, value="Infrastructure & Server Catalog").font = title_font
        headers_srv = ["Server ID", "Server Name", "Environment ID", "Environment Name", "Server Type", "Status", "IP Address", "Hostname", "Cloud Provider", "Region", "Specs"]
        for col_num, header in enumerate(headers_srv, 1):
            cell = ws_srv.cell(row=3, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        srv_nodes = [n for n in nodes if n.get("type") == "SERVER"]
        row_idx = 4
        for srv in srv_nodes:
            st = srv.get("status", "HEALTHY")
            cells = [
                ws_srv.cell(row=row_idx, column=1, value=srv.get("id", "")),
                ws_srv.cell(row=row_idx, column=2, value=srv.get("name", "")),
                ws_srv.cell(row=row_idx, column=3, value=srv.get("environment_id", "")),
                ws_srv.cell(row=row_idx, column=4, value=srv.get("environment_name", "")),
                ws_srv.cell(row=row_idx, column=5, value=srv.get("sub_type", "")),
                ws_srv.cell(row=row_idx, column=6, value=st),
                ws_srv.cell(row=row_idx, column=7, value=srv.get("ip_address", "")),
                ws_srv.cell(row=row_idx, column=8, value=srv.get("hostname", "")),
                ws_srv.cell(row=row_idx, column=9, value=srv.get("cloud_provider", "")),
                ws_srv.cell(row=row_idx, column=10, value=srv.get("region", "")),
                ws_srv.cell(row=row_idx, column=11, value=srv.get("specs", ""))
            ]
            for c in cells:
                c.font = regular_font
                c.border = thin_border
            if st in status_fills:
                cells[5].fill = status_fills[st]
            row_idx += 1

        # --- Sheet 3: Software ---
        ws_sw = wb.create_sheet(title="Software")
        ws_sw.views.sheetView[0].showGridLines = True
        ws_sw.cell(row=1, column=1, value="Software & Services Catalog").font = title_font
        headers_sw = ["Software ID", "Software Name", "Environment ID", "Environment Name", "Category", "Status", "Version", "Vendor"]
        for col_num, header in enumerate(headers_sw, 1):
            cell = ws_sw.cell(row=3, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        sw_nodes = [n for n in nodes if n.get("type") in ["SOFTWARE", "SERVICE"]]
        row_idx = 4
        for sw in sw_nodes:
            props = sw.get("properties", {})
            st = sw.get("status", "HEALTHY")
            cells = [
                ws_sw.cell(row=row_idx, column=1, value=sw.get("id", "")),
                ws_sw.cell(row=row_idx, column=2, value=sw.get("name", "")),
                ws_sw.cell(row=row_idx, column=3, value=sw.get("environment_id", "")),
                ws_sw.cell(row=row_idx, column=4, value=sw.get("environment_name", "")),
                ws_sw.cell(row=row_idx, column=5, value=sw.get("sub_type", props.get("category", ""))),
                ws_sw.cell(row=row_idx, column=6, value=st),
                ws_sw.cell(row=row_idx, column=7, value=props.get("version", "")),
                ws_sw.cell(row=row_idx, column=8, value=props.get("vendor", ""))
            ]
            for c in cells:
                c.font = regular_font
                c.border = thin_border
            if st in status_fills:
                cells[5].fill = status_fills[st]
            row_idx += 1

        # --- Sheet 4: Applications ---
        ws_app = wb.create_sheet(title="Applications")
        ws_app.views.sheetView[0].showGridLines = True
        ws_app.cell(row=1, column=1, value="Business Applications").font = title_font
        headers_app = ["Application ID", "Application Name", "Type", "Business Unit", "Project Name", "App Code", "Owner"]
        for col_num, header in enumerate(headers_app, 1):
            cell = ws_app.cell(row=3, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        app_nodes = [n for n in nodes if n.get("type") in ["APPLICATION", "MICROSERVICE"]]
        row_idx = 4
        for app in app_nodes:
            props = app.get("properties", {})
            cells = [
                ws_app.cell(row=row_idx, column=1, value=app.get("id", "")),
                ws_app.cell(row=row_idx, column=2, value=app.get("name", "")),
                ws_app.cell(row=row_idx, column=3, value=app.get("sub_type", "Enterprise App")),
                ws_app.cell(row=row_idx, column=4, value=app.get("business_unit", "")),
                ws_app.cell(row=row_idx, column=5, value=props.get("project", "")),
                ws_app.cell(row=row_idx, column=6, value=props.get("code", "")),
                ws_app.cell(row=row_idx, column=7, value=props.get("owner", ""))
            ]
            for c in cells:
                c.font = regular_font
                c.border = thin_border
            row_idx += 1

        # --- Sheet 5: Topology Relationships ---
        ws_rel = wb.create_sheet(title="Topology Relationships")
        ws_rel.views.sheetView[0].showGridLines = True
        ws_rel.cell(row=1, column=1, value="Topology Dependency & Connection Map").font = title_font
        headers_rel = ["Relationship ID", "Source Node ID", "Source Node Name", "Source Type", "Relationship Type", "Target Node ID", "Target Node Name", "Target Type", "Port", "Protocol", "Latency (ms)", "Type Scope"]
        for col_num, header in enumerate(headers_rel, 1):
            cell = ws_rel.cell(row=3, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        row_idx = 4
        for edge in edges:
            src = node_map.get(edge.get("source"), {})
            tgt = node_map.get(edge.get("target"), {})
            cells = [
                ws_rel.cell(row=row_idx, column=1, value=edge.get("id", "")),
                ws_rel.cell(row=row_idx, column=2, value=edge.get("source", "")),
                ws_rel.cell(row=row_idx, column=3, value=src.get("name", edge.get("source", ""))),
                ws_rel.cell(row=row_idx, column=4, value=src.get("type", "")),
                ws_rel.cell(row=row_idx, column=5, value=edge.get("relationship_type", "")),
                ws_rel.cell(row=row_idx, column=6, value=edge.get("target", "")),
                ws_rel.cell(row=row_idx, column=7, value=tgt.get("name", edge.get("target", ""))),
                ws_rel.cell(row=row_idx, column=8, value=tgt.get("type", "")),
                ws_rel.cell(row=row_idx, column=9, value=edge.get("port", "")),
                ws_rel.cell(row=row_idx, column=10, value=edge.get("protocol", "")),
                ws_rel.cell(row=row_idx, column=11, value=edge.get("latency_ms", "")),
                ws_rel.cell(row=row_idx, column=12, value="Custom Link" if edge.get("is_custom") else "Standard Lineage")
            ]
            for c in cells:
                c.font = regular_font
                c.border = thin_border
            row_idx += 1

        for ws in wb.worksheets:
            for col in ws.columns:
                max_len = 0
                col_letter = get_column_letter(col[0].column)
                for cell in col:
                    if cell.row < 3:
                        continue
                    val_str = str(cell.value or '')
                    if len(val_str) > max_len:
                        max_len = len(val_str)
                ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

        output = io.BytesIO()
        wb.save(output)
        return output.getvalue()

    # -------------------------------------------------------------------------
    # 3. PDF EXPORT
    # -------------------------------------------------------------------------
    @staticmethod
    def _generate_pdf(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]], metrics: Dict[str, Any], scope: str, date_str: str) -> bytes:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=landscape(letter),
            rightMargin=36,
            leftMargin=36,
            topMargin=36,
            bottomMargin=36
        )

        styles = getSampleStyleSheet()
        
        title_style = ParagraphStyle(
            'DocTitle',
            parent=styles['Heading1'],
            fontName='Helvetica-Bold',
            fontSize=20,
            leading=24,
            textColor=colors.HexColor('#0F172A')
        )
        subtitle_style = ParagraphStyle(
            'DocSubTitle',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=10,
            leading=14,
            textColor=colors.HexColor('#475569')
        )
        section_style = ParagraphStyle(
            'SectionHeading',
            parent=styles['Heading2'],
            fontName='Helvetica-Bold',
            fontSize=13,
            leading=17,
            textColor=colors.HexColor('#C2410C'),
            spaceBefore=12,
            spaceAfter=6
        )
        cell_style = ParagraphStyle(
            'CellText',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=8,
            leading=10,
            textColor=colors.HexColor('#1E293B')
        )
        cell_bold = ParagraphStyle(
            'CellTextBold',
            parent=cell_style,
            fontName='Helvetica-Bold'
        )
        cell_header = ParagraphStyle(
            'CellHeader',
            parent=cell_style,
            fontName='Helvetica-Bold',
            fontSize=8,
            textColor=colors.white
        )

        elements = []

        elements.append(Paragraph("SmartQE TEM - Environment Topology Report", title_style))
        elements.append(Paragraph(f"Scope: <b>{scope} Environments</b> | Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Single Source of Truth: Environment Details", subtitle_style))
        elements.append(Spacer(1, 10))

        env_count = len([n for n in nodes if n.get("type") == "ENVIRONMENT"])
        srv_count = len([n for n in nodes if n.get("type") == "SERVER"])
        sw_count = len([n for n in nodes if n.get("type") in ["SOFTWARE", "SERVICE"]])
        app_count = len([n for n in nodes if n.get("type") in ["APPLICATION", "MICROSERVICE"]])
        edge_count = len(edges)

        metrics_data = [
            [
                Paragraph("<b>Total Environments</b>", cell_style),
                Paragraph("<b>Total Servers</b>", cell_style),
                Paragraph("<b>Total Software</b>", cell_style),
                Paragraph("<b>Total Applications</b>", cell_style),
                Paragraph("<b>Topology Links</b>", cell_style)
            ],
            [
                Paragraph(f"<font size=14 color='#EA580C'><b>{env_count}</b></font>", cell_style),
                Paragraph(f"<font size=14 color='#2563EB'><b>{srv_count}</b></font>", cell_style),
                Paragraph(f"<font size=14 color='#16A34A'><b>{sw_count}</b></font>", cell_style),
                Paragraph(f"<font size=14 color='#9333EA'><b>{app_count}</b></font>", cell_style),
                Paragraph(f"<font size=14 color='#0891B2'><b>{edge_count}</b></font>", cell_style)
            ]
        ]
        metrics_table = Table(metrics_data, colWidths=[140, 140, 140, 140, 140])
        metrics_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F8FAFC')),
            ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#E2E8F0')),
            ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('TOPPADDING', (0,0), (-1,-1), 6),
            ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ]))
        elements.append(metrics_table)
        elements.append(Spacer(1, 14))

        elements.append(Paragraph("1. Topology Canvas Blueprint Overview", section_style))
        
        drawing_width = 720
        drawing_height = 140
        d = Drawing(drawing_width, drawing_height)
        d.add(Rect(0, 0, drawing_width, drawing_height, fillColor=colors.HexColor('#0F172A'), strokeColor=colors.HexColor('#334155'), strokeWidth=1, rx=8, ry=8))
        d.add(String(15, drawing_height - 20, "ENVIRONMENT TOPOLOGY VISUAL BLUEPRINT MAP", fontName="Helvetica-Bold", fontSize=9, fillColor=colors.HexColor('#F97316')))

        env_list = [n for n in nodes if n.get("type") == "ENVIRONMENT"][:5]
        col_width = (drawing_width - 40) / max(len(env_list), 1)

        for idx, env in enumerate(env_list):
            x = 20 + (idx * col_width)
            y = 50
            d.add(Rect(x, y, col_width - 15, 55, fillColor=colors.HexColor('#1E293B'), strokeColor=colors.HexColor('#F97316'), strokeWidth=1.5, rx=4, ry=4))
            d.add(String(x + 8, y + 38, f"ENV: {env.get('name')[:14]}", fontName="Helvetica-Bold", fontSize=8, fillColor=colors.white))
            d.add(String(x + 8, y + 24, f"Tier: {env.get('sub_type', 'DEV')}", fontName="Helvetica", fontSize=7, fillColor=colors.HexColor('#94A3B8')))
            d.add(String(x + 8, y + 10, f"Status: {env.get('status', 'HEALTHY')}", fontName="Helvetica-Bold", fontSize=7, fillColor=colors.HexColor('#4ADE80') if env.get('status') == 'HEALTHY' else colors.HexColor('#F87171')))

            conn_edges = [e for e in edges if e.get("source") == env.get("id") or e.get("target") == env.get("id")]
            d.add(Line(x + (col_width - 15)/2, y, x + (col_width - 15)/2, 20, strokeColor=colors.HexColor('#38BDF8'), strokeWidth=1, strokeDashArray=[2,2]))
            d.add(Circle(x + (col_width - 15)/2, 20, 3, fillColor=colors.HexColor('#38BDF8'), strokeColor=None))
            d.add(String(x + (col_width - 15)/2 - 20, 8, f"{len(conn_edges)} Links", fontName="Helvetica", fontSize=6, fillColor=colors.HexColor('#CBD5E1')))

        elements.append(d)
        elements.append(Spacer(1, 14))

        elements.append(Paragraph("2. Environment Inventory Details", section_style))
        env_table_data = [[
            Paragraph("<b>Environment ID</b>", cell_header),
            Paragraph("<b>Environment Name</b>", cell_header),
            Paragraph("<b>Tier</b>", cell_header),
            Paragraph("<b>Status</b>", cell_header),
            Paragraph("<b>Owner / Team</b>", cell_header),
            Paragraph("<b>Network Zone</b>", cell_header),
            Paragraph("<b>Incidents</b>", cell_header)
        ]]
        for env in [n for n in nodes if n.get("type") == "ENVIRONMENT"]:
            props = env.get("properties", {})
            env_table_data.append([
                Paragraph(env.get("id", ""), cell_style),
                Paragraph(env.get("name", ""), cell_bold),
                Paragraph(env.get("sub_type", props.get("type", "")), cell_style),
                Paragraph(env.get("status", "HEALTHY"), cell_style),
                Paragraph(env.get("business_unit", props.get("ownerTeam", "")), cell_style),
                Paragraph(env.get("account_name", props.get("networkZone", "")), cell_style),
                Paragraph(str(env.get("active_incidents_count", 0)), cell_style)
            ])
        t_env = Table(env_table_data, colWidths=[90, 130, 80, 70, 140, 120, 70])
        t_env.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E293B')),
            ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#CBD5E1')),
            ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        elements.append(t_env)
        elements.append(Spacer(1, 14))

        elements.append(Paragraph("3. Infrastructure & Servers", section_style))
        srv_table_data = [[
            Paragraph("<b>Server ID</b>", cell_header),
            Paragraph("<b>Server Name</b>", cell_header),
            Paragraph("<b>Environment</b>", cell_header),
            Paragraph("<b>IP Address</b>", cell_header),
            Paragraph("<b>Hostname</b>", cell_header),
            Paragraph("<b>Cloud / Region</b>", cell_header),
            Paragraph("<b>Hardware Specs</b>", cell_header)
        ]]
        for srv in [n for n in nodes if n.get("type") == "SERVER"]:
            cloud_str = f"{srv.get('cloud_provider', 'On-Prem')} ({srv.get('region', 'N/A')})" if srv.get('cloud_provider') else "On-Premises"
            srv_table_data.append([
                Paragraph(srv.get("id", ""), cell_style),
                Paragraph(srv.get("name", ""), cell_bold),
                Paragraph(srv.get("environment_name", ""), cell_style),
                Paragraph(srv.get("ip_address", "N/A"), cell_style),
                Paragraph(srv.get("hostname", "N/A"), cell_style),
                Paragraph(cloud_str, cell_style),
                Paragraph(srv.get("specs", "N/A"), cell_style)
            ])
        t_srv = Table(srv_table_data, colWidths=[80, 130, 110, 95, 115, 100, 90])
        t_srv.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E293B')),
            ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#CBD5E1')),
            ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        elements.append(t_srv)
        elements.append(Spacer(1, 14))

        elements.append(Paragraph("4. Topology Relationships & Dependencies", section_style))
        node_map = {n.get("id"): n for n in nodes}
        rel_table_data = [[
            Paragraph("<b>Relationship ID</b>", cell_header),
            Paragraph("<b>Source Node</b>", cell_header),
            Paragraph("<b>Relationship Type</b>", cell_header),
            Paragraph("<b>Target Node</b>", cell_header),
            Paragraph("<b>Port / Protocol</b>", cell_header),
            Paragraph("<b>Latency</b>", cell_header)
        ]]
        for edge in edges:
            src = node_map.get(edge.get("source"), {})
            tgt = node_map.get(edge.get("target"), {})
            port_proto = f"{edge.get('port', 'N/A')}/{edge.get('protocol', 'TCP')}" if edge.get("port") else "N/A"
            lat = f"{edge.get('latency_ms')} ms" if edge.get("latency_ms") else "N/A"
            rel_table_data.append([
                Paragraph(edge.get("id", ""), cell_style),
                Paragraph(f"{src.get('name', edge.get('source'))} ({src.get('type', '')})", cell_style),
                Paragraph(f"<b>{edge.get('relationship_type', '')}</b>", cell_style),
                Paragraph(f"{tgt.get('name', edge.get('target'))} ({tgt.get('type', '')})", cell_style),
                Paragraph(port_proto, cell_style),
                Paragraph(lat, cell_style)
            ])
        t_rel = Table(rel_table_data, colWidths=[110, 170, 120, 170, 80, 70])
        t_rel.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E293B')),
            ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#CBD5E1')),
            ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        elements.append(t_rel)

        doc.build(elements)
        return buffer.getvalue()

    # -------------------------------------------------------------------------
    # 4. DOCX EXPORT
    # -------------------------------------------------------------------------
    @staticmethod
    def _generate_docx(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]], metrics: Dict[str, Any], scope: str, date_str: str) -> bytes:
        doc = Document()

        section = doc.sections[0]
        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(0.75)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)

        node_map = {n.get("id"): n for n in nodes}

        def set_cell_background(cell, fill_hex):
            tcPr = cell._tc.get_or_add_tcPr()
            shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
            tcPr.append(shd)

        def style_header_row(row):
            for cell in row.cells:
                set_cell_background(cell, "1E293B")
                for paragraph in cell.paragraphs:
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for run in paragraph.runs:
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(255, 255, 255)
                        run.font.size = Pt(9)

        p_title = doc.add_paragraph()
        run_title = p_title.add_run("Environment Topology Export")
        run_title.font.name = 'Calibri'
        run_title.font.size = Pt(22)
        run_title.font.bold = True
        run_title.font.color.rgb = RGBColor(15, 23, 42)

        p_sub = doc.add_paragraph()
        r_sub = p_sub.add_run(f"Scope: {scope} Environments | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Single Source: Environment Details")
        r_sub.font.name = 'Calibri'
        r_sub.font.size = Pt(10)
        r_sub.font.italic = True
        r_sub.font.color.rgb = RGBColor(71, 85, 105)

        doc.add_paragraph().paragraph_format.space_after = Pt(10)

        h1 = doc.add_heading("1. Executive Overview & Metrics", level=1)
        h1.runs[0].font.color.rgb = RGBColor(194, 65, 12)

        t_summary = doc.add_table(rows=2, cols=5)
        t_summary.alignment = WD_TABLE_ALIGNMENT.CENTER
        headers_sum = ["Environments", "Servers", "Software", "Applications", "Topology Links"]
        for idx, text in enumerate(headers_sum):
            t_summary.rows[0].cells[idx].paragraphs[0].text = text
        style_header_row(t_summary.rows[0])

        env_count = len([n for n in nodes if n.get("type") == "ENVIRONMENT"])
        srv_count = len([n for n in nodes if n.get("type") == "SERVER"])
        sw_count = len([n for n in nodes if n.get("type") in ["SOFTWARE", "SERVICE"]])
        app_count = len([n for n in nodes if n.get("type") in ["APPLICATION", "MICROSERVICE"]])
        edge_count = len(edges)

        counts = [env_count, srv_count, sw_count, app_count, edge_count]
        for idx, val in enumerate(counts):
            cell = t_summary.rows[1].cells[idx]
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(str(val))
            r.font.bold = True
            r.font.size = Pt(14)
            r.font.color.rgb = RGBColor(234, 88, 12)

        doc.add_paragraph().paragraph_format.space_after = Pt(12)

        h2 = doc.add_heading("2. Environment Catalog Details", level=1)
        h2.runs[0].font.color.rgb = RGBColor(194, 65, 12)

        env_nodes = [n for n in nodes if n.get("type") == "ENVIRONMENT"]
        for env in env_nodes:
            props = env.get("properties", {})
            h_env = doc.add_heading(f"Environment: {env.get('name')} ({env.get('id')})", level=2)
            h_env.runs[0].font.color.rgb = RGBColor(15, 23, 42)

            p_env_info = doc.add_paragraph()
            p_env_info.add_run(f"Tier: {env.get('sub_type', props.get('type', 'N/A'))} | ").font.bold = True
            p_env_info.add_run(f"Status: {env.get('status', 'HEALTHY')} | ")
            p_env_info.add_run(f"Owner Team: {env.get('business_unit', props.get('ownerTeam', 'N/A'))} | ")
            p_env_info.add_run(f"Network Zone: {env.get('account_name', props.get('networkZone', 'N/A'))}")

            if props.get("description"):
                p_desc = doc.add_paragraph()
                p_desc.add_run(f"Description: {props.get('description')}").font.italic = True

            env_srvs = [n for n in nodes if n.get("type") == "SERVER" and (n.get("environment_id") == env.get("id") or n.get("environment_name") == env.get("name"))]
            if env_srvs:
                p_srv_h = doc.add_paragraph()
                p_srv_h.add_run("Attached Servers:").font.bold = True
                t_env_srv = doc.add_table(rows=1 + len(env_srvs), cols=5)
                t_env_srv.alignment = WD_TABLE_ALIGNMENT.CENTER
                srv_cols = ["Server Name", "Server Type", "IP Address", "Hostname", "Cloud Provider"]
                for i, col_name in enumerate(srv_cols):
                    t_env_srv.rows[0].cells[i].paragraphs[0].text = col_name
                style_header_row(t_env_srv.rows[0])

                for r_i, srv in enumerate(env_srvs, 1):
                    t_env_srv.rows[r_i].cells[0].paragraphs[0].text = srv.get("name", "")
                    t_env_srv.rows[r_i].cells[1].paragraphs[0].text = srv.get("sub_type", "")
                    t_env_srv.rows[r_i].cells[2].paragraphs[0].text = srv.get("ip_address", "N/A")
                    t_env_srv.rows[r_i].cells[3].paragraphs[0].text = srv.get("hostname", "N/A")
                    t_env_srv.rows[r_i].cells[4].paragraphs[0].text = srv.get("cloud_provider", "On-Premises")

            doc.add_paragraph().paragraph_format.space_after = Pt(8)

        h3 = doc.add_heading("3. Infrastructure & Servers Master Table", level=1)
        h3.runs[0].font.color.rgb = RGBColor(194, 65, 12)
        
        all_srvs = [n for n in nodes if n.get("type") == "SERVER"]
        if all_srvs:
            t_srv_master = doc.add_table(rows=1 + len(all_srvs), cols=6)
            t_srv_master.alignment = WD_TABLE_ALIGNMENT.CENTER
            m_cols = ["Server Name", "Environment", "Status", "IP Address", "Cloud Provider", "Specs"]
            for i, col_name in enumerate(m_cols):
                t_srv_master.rows[0].cells[i].paragraphs[0].text = col_name
            style_header_row(t_srv_master.rows[0])

            for r_i, srv in enumerate(all_srvs, 1):
                t_srv_master.rows[r_i].cells[0].paragraphs[0].text = srv.get("name", "")
                t_srv_master.rows[r_i].cells[1].paragraphs[0].text = srv.get("environment_name", "")
                t_srv_master.rows[r_i].cells[2].paragraphs[0].text = srv.get("status", "HEALTHY")
                t_srv_master.rows[r_i].cells[3].paragraphs[0].text = srv.get("ip_address", "N/A")
                t_srv_master.rows[r_i].cells[4].paragraphs[0].text = srv.get("cloud_provider", "On-Prem")
                t_srv_master.rows[r_i].cells[5].paragraphs[0].text = srv.get("specs", "N/A")

        doc.add_paragraph().paragraph_format.space_after = Pt(12)

        h4 = doc.add_heading("4. Software Catalog", level=1)
        h4.runs[0].font.color.rgb = RGBColor(194, 65, 12)
        all_sw = [n for n in nodes if n.get("type") in ["SOFTWARE", "SERVICE"]]
        if all_sw:
            t_sw = doc.add_table(rows=1 + len(all_sw), cols=5)
            t_sw.alignment = WD_TABLE_ALIGNMENT.CENTER
            sw_headers = ["Software Name", "Environment", "Category", "Version", "Vendor"]
            for i, text in enumerate(sw_headers):
                t_sw.rows[0].cells[i].paragraphs[0].text = text
            style_header_row(t_sw.rows[0])

            for r_i, sw in enumerate(all_sw, 1):
                props = sw.get("properties", {})
                t_sw.rows[r_i].cells[0].paragraphs[0].text = sw.get("name", "")
                t_sw.rows[r_i].cells[1].paragraphs[0].text = sw.get("environment_name", "")
                t_sw.rows[r_i].cells[2].paragraphs[0].text = sw.get("sub_type", props.get("category", ""))
                t_sw.rows[r_i].cells[3].paragraphs[0].text = props.get("version", "N/A")
                t_sw.rows[r_i].cells[4].paragraphs[0].text = props.get("vendor", "N/A")

        doc.add_paragraph().paragraph_format.space_after = Pt(12)

        h5 = doc.add_heading("5. Applications Catalog", level=1)
        h5.runs[0].font.color.rgb = RGBColor(194, 65, 12)
        all_apps = [n for n in nodes if n.get("type") in ["APPLICATION", "MICROSERVICE"]]
        if all_apps:
            t_apps = doc.add_table(rows=1 + len(all_apps), cols=4)
            t_apps.alignment = WD_TABLE_ALIGNMENT.CENTER
            app_headers = ["Application Name", "Business Unit", "Project", "Owner Team"]
            for i, text in enumerate(app_headers):
                t_apps.rows[0].cells[i].paragraphs[0].text = text
            style_header_row(t_apps.rows[0])

            for r_i, app in enumerate(all_apps, 1):
                props = app.get("properties", {})
                t_apps.rows[r_i].cells[0].paragraphs[0].text = app.get("name", "")
                t_apps.rows[r_i].cells[1].paragraphs[0].text = app.get("business_unit", "Enterprise")
                t_apps.rows[r_i].cells[2].paragraphs[0].text = props.get("project", "N/A")
                t_apps.rows[r_i].cells[3].paragraphs[0].text = props.get("owner", "QE Lead")

        doc.add_paragraph().paragraph_format.space_after = Pt(12)

        h6 = doc.add_heading("6. Topology Dependencies & Relationships", level=1)
        h6.runs[0].font.color.rgb = RGBColor(194, 65, 12)
        if edges:
            t_rel = doc.add_table(rows=1 + len(edges), cols=5)
            t_rel.alignment = WD_TABLE_ALIGNMENT.CENTER
            rel_headers = ["Source Node", "Relationship Type", "Target Node", "Port / Protocol", "Latency"]
            for i, text in enumerate(rel_headers):
                t_rel.rows[0].cells[i].paragraphs[0].text = text
            style_header_row(t_rel.rows[0])

            for r_i, edge in enumerate(edges, 1):
                src = node_map.get(edge.get("source"), {})
                tgt = node_map.get(edge.get("target"), {})
                port_proto = f"{edge.get('port')}/{edge.get('protocol', 'TCP')}" if edge.get("port") else "N/A"
                lat = f"{edge.get('latency_ms')} ms" if edge.get("latency_ms") else "N/A"

                t_rel.rows[r_i].cells[0].paragraphs[0].text = f"{src.get('name', edge.get('source'))} ({src.get('type', '')})"
                t_rel.rows[r_i].cells[1].paragraphs[0].text = edge.get("relationship_type", "DEPENDS_ON")
                t_rel.rows[r_i].cells[2].paragraphs[0].text = f"{tgt.get('name', edge.get('target'))} ({tgt.get('type', '')})"
                t_rel.rows[r_i].cells[3].paragraphs[0].text = port_proto
                t_rel.rows[r_i].cells[4].paragraphs[0].text = lat

        output = io.BytesIO()
        doc.save(output)
        return output.getvalue()
