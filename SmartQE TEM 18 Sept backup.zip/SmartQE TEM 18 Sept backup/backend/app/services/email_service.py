import asyncio
import email.utils
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
import ssl
from datetime import datetime, timezone
from typing import List, Optional, Tuple, Dict, Any

from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.core.logging import logger
from app.dao.email_notification_dao import email_notification_dao
from app.dao.user_dao import user_dao
from app.models.email_notification import NotificationType, NotificationStatus, EmailNotification
from app.models.reservation import Reservation
from app.models.user import User


def format_dt(dt: Optional[datetime]) -> str:
    if not dt:
        return "-"
    try:
        return dt.strftime("%d %b %Y, %I:%M %p")
    except Exception:
        return str(dt)


def generate_email_html(
    title: str,
    header_subtitle: str,
    main_message: str,
    details: Dict[str, str],
    action_banner: Optional[str] = None,
    badge_color: str = "#2563eb",  # blue
    badge_text: str = "NOTIFICATION"
) -> str:
    """
    Generates a high-quality responsive HTML email template for TEM notifications.
    """
    rows_html = ""
    for label, val in details.items():
        if val:
            rows_html += f"""
            <tr>
                <td style="padding: 8px 12px; font-weight: 600; color: #475569; width: 35%; border-bottom: 1px solid #f1f5f9; font-size: 13px;">{label}</td>
                <td style="padding: 8px 12px; color: #0f172a; font-family: monospace, sans-serif; border-bottom: 1px solid #f1f5f9; font-size: 13px;">{val}</td>
            </tr>
            """

    action_html = ""
    if action_banner:
        action_html = f"""
        <div style="margin: 20px 0; padding: 14px 18px; background-color: #f8fafc; border-left: 4px solid {badge_color}; border-radius: 4px; font-size: 13px; color: #334155; line-height: 1.5;">
            {action_banner}
        </div>
        """

    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
</head>
<body style="margin: 0; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f1f5f9; color: #1e293b;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width: 620px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1); border: 1px solid #e2e8f0;">
        <!-- Header -->
        <tr>
            <td style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 24px; text-align: left;">
                <table width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                        <td>
                            <div style="font-size: 11px; font-weight: 700; letter-spacing: 1px; color: #94a3b8; text-transform: uppercase;">TESTOPS • TEST ENVIRONMENT MANAGEMENT</div>
                            <h1 style="margin: 6px 0 2px 0; color: #ffffff; font-size: 20px; font-weight: 700;">{title}</h1>
                            <div style="font-size: 13px; color: #cbd5e1;">{header_subtitle}</div>
                        </td>
                        <td align="right" valign="top">
                            <span style="display: inline-block; padding: 4px 10px; background-color: {badge_color}; color: #ffffff; font-size: 11px; font-weight: 700; border-radius: 4px; text-transform: uppercase; letter-spacing: 0.5px;">{badge_text}</span>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>

        <!-- Content -->
        <tr>
            <td style="padding: 24px;">
                <p style="font-size: 14px; line-height: 1.6; color: #334155; margin-top: 0; margin-bottom: 16px;">
                    {main_message}
                </p>

                {action_html}

                <!-- Details Table -->
                <div style="margin-top: 20px; border: 1px solid #e2e8f0; border-radius: 6px; overflow: hidden;">
                    <div style="background-color: #f8fafc; padding: 10px 14px; border-bottom: 1px solid #e2e8f0; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.5px;">
                        Reservation Specification
                    </div>
                    <table width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
                        {rows_html}
                    </table>
                </div>

                <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #64748b; line-height: 1.5;">
                    <p style="margin: 0;">This is an automated notification from the TEM Control System. Please do not reply directly to this email.</p>
                </div>
            </td>
        </tr>
    </table>
</body>
</html>"""
    return html


class EmailService:
    def _send_smtp_sync(
        self,
        to_emails: List[str],
        cc_emails: List[str],
        subject: str,
        text_content: str,
        html_content: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Synchronous worker executed in background thread via asyncio.to_thread.
        """
        if not to_emails:
            return False, "No recipient TO email address provided."

        if not settings.SMTP_ENABLED:
            logger.info(f"[MOCK/DISABLED EMAIL] Subject: '{subject}' | TO: {to_emails} | CC: {cc_emails}")
            return True, None

        # Build MIME Message
        sender_name = getattr(settings, "SMTP_SENDER_NAME", None) or getattr(settings, "SMTP_FROM_NAME", "TEM Notifications")
        sender_email = getattr(settings, "SMTP_SENDER_EMAIL", None) or getattr(settings, "SMTP_FROM_EMAIL", "no-reply@testops.io")

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = email.utils.formataddr((sender_name, sender_email))
        msg["To"] = ", ".join(to_emails)
        if cc_emails:
            msg["Cc"] = ", ".join(cc_emails)
        msg["Date"] = email.utils.formatdate(localtime=True)

        part_text = MIMEText(text_content, "plain", "utf-8")
        part_html = MIMEText(html_content, "html", "utf-8")
        msg.attach(part_text)
        msg.attach(part_html)

        all_recipients = list(set([e.strip() for e in (to_emails + cc_emails) if e and e.strip()]))

        try:
            smtp_host = settings.SMTP_HOST.strip() if settings.SMTP_HOST else "localhost"
            smtp_port = int(settings.SMTP_PORT) if settings.SMTP_PORT else 587
            smtp_user = settings.SMTP_USERNAME.strip() if settings.SMTP_USERNAME else ""
            smtp_pass = settings.SMTP_PASSWORD.replace(" ", "").strip() if ("gmail" in smtp_host.lower() and settings.SMTP_PASSWORD) else (settings.SMTP_PASSWORD.strip() if settings.SMTP_PASSWORD else "")
            from_addr = sender_email.strip() if sender_email else "no-reply@testops.io"

            if settings.SMTP_USE_SSL:
                context = ssl.create_default_context()
                server = smtplib.SMTP_SSL(
                    host=smtp_host,
                    port=smtp_port,
                    timeout=settings.SMTP_TIMEOUT,
                    context=context
                )
            else:
                server = smtplib.SMTP(
                    host=smtp_host,
                    port=smtp_port,
                    timeout=settings.SMTP_TIMEOUT
                )

            with server:
                if not settings.SMTP_USE_SSL and settings.SMTP_USE_TLS:
                    server.ehlo()
                    server.starttls(context=ssl.create_default_context())
                    server.ehlo()

                if smtp_user and smtp_pass:
                    server.login(smtp_user, smtp_pass)

                server.sendmail(from_addr, all_recipients, msg.as_string())

            logger.info(f"[SMTP SENT] Subject: '{subject}' successfully delivered to {all_recipients}")
            return True, None

        except Exception as exc:
            err_msg = f"SMTP Transmission Error: {type(exc).__name__}: {str(exc)}"
            logger.error(f"[SMTP FAILED] Failed to send email to {all_recipients}. Error: {err_msg}")
            return False, err_msg

    async def send_email(
        self,
        to_emails: List[str],
        cc_emails: List[str],
        subject: str,
        text_content: str,
        html_content: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Non-blocking async SMTP dispatcher.
        """
        try:
            return await asyncio.to_thread(
                self._send_smtp_sync,
                to_emails,
                cc_emails,
                subject,
                text_content,
                html_content
            )
        except Exception as exc:
            err = f"Async email task failure: {str(exc)}"
            logger.error(err)
            return False, err

    async def _resolve_user_email(self, db: AsyncSession, user_id_or_name: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
        """
        Resolves user email and full name from user record in database.
        Returns (email, display_name).
        """
        if not user_id_or_name:
            return None, None

        target = user_id_or_name.strip()
        user: Optional[User] = None

        # First check by ID
        user = await user_dao.get_by_id(db, target)
        if not user:
            # Check by username
            user = await user_dao.get_by_username(db, target)
        if not user:
            # Check by email
            user = await user_dao.get_by_email(db, target)

        if user:
            email_addr = (user.email or "").strip().lower()
            name = user.full_name or user.username
            return email_addr, name

        # Fallback if target looks like an email address
        if "@" in target:
            return target.lower(), target

        return None, target

    # =========================================================================
    # 1. Booking Creation Notification (TO: 1st Approver, CC: Owner)
    # =========================================================================
    async def trigger_booking_created_notification(
        self,
        db: AsyncSession,
        reservation: Reservation,
        first_approver_id: Optional[str],
        owner_id_or_name: Optional[str]
    ) -> Optional[EmailNotification]:
        """
        Triggers email on booking creation to the first approver, with owner in CC.
        """
        booking_id = reservation.id
        notification_type = NotificationType.BOOKING_CREATED.value

        # Idempotency check
        if await email_notification_dao.is_already_sent(db, booking_id, notification_type, step_order=1):
            logger.info(f"Booking created email already sent for booking {booking_id}. Skipping duplicate.")
            return None

        approver_email, approver_name = await self._resolve_user_email(db, first_approver_id)
        owner_email, owner_name = await self._resolve_user_email(db, owner_id_or_name or reservation.created_by or reservation.requested_by)

        if not approver_email:
            logger.warning(f"Could not resolve email for first approver '{first_approver_id}'. Notification will record FAILED status.")
            approver_email = "approver-unknown@testops.io"

        to_list = [approver_email]
        cc_list = [owner_email] if owner_email else []

        subject = f"TEM Booking Approval Required - {booking_id}"
        mode_val = reservation.reservation_mode.value if hasattr(reservation.reservation_mode, "value") else str(reservation.reservation_mode)
        status_val = reservation.status.value if hasattr(reservation.status, "value") else str(reservation.status)

        plain_text = f"""TEM Booking Approval Required - {booking_id}

A new reservation has been created and requires your approval.

Booking ID: {booking_id}
Environment: {reservation.environment_name}
Business Unit: {reservation.business_unit}
Project: {reservation.project or '-'}
Application: {reservation.application or '-'}
Service: Environment Reservation
Start: {format_dt(reservation.start_date)}
End: {format_dt(reservation.end_date)}
Mode: {mode_val}
Requested By: {owner_name or reservation.requested_by}
Current Status: {status_val}
Current Approver: {approver_name or first_approver_id}

Please review and approve or reject this reservation in the TEM Portal.
"""

        details = {
            "Booking ID": booking_id,
            "Environment": reservation.environment_name,
            "Business Unit": reservation.business_unit,
            "Project": reservation.project or "-",
            "Application": reservation.application or "-",
            "Service": "Environment Reservation",
            "Start Date/Time": format_dt(reservation.start_date),
            "End Date/Time": format_dt(reservation.end_date),
            "Reservation Mode": mode_val,
            "Requested By": owner_name or reservation.requested_by,
            "Current Status": status_val,
            "Designated Approver": approver_name or first_approver_id or "-",
        }

        html_content = generate_email_html(
            title=f"Approval Required • {booking_id}",
            header_subtitle=f"Environment: {reservation.environment_name}",
            main_message=f"A new environment reservation request has been submitted by <strong>{owner_name or reservation.requested_by}</strong> and requires your approval as the designated reviewer.",
            details=details,
            action_banner="<strong>Required Action:</strong> Please sign in to the TEM Worklist to review details and approve or reject this reservation.",
            badge_color="#f59e0b",
            badge_text="APPROVAL REQUIRED"
        )

        record = await email_notification_dao.create_notification_record(
            db=db,
            booking_id=booking_id,
            notification_type=notification_type,
            step_order=1,
            recipient_to=approver_email,
            recipient_cc=", ".join(cc_list) if cc_list else None,
            subject=subject,
            body=html_content,
            status=NotificationStatus.PENDING.value
        )

        success, err = await self.send_email(to_list, cc_list, subject, plain_text, html_content)
        now = datetime.now(timezone.utc)
        if success:
            await email_notification_dao.update_status(db, record, status=NotificationStatus.SENT.value, sent_at=now)
        else:
            await email_notification_dao.update_status(db, record, status=NotificationStatus.FAILED.value, error_message=err)

        return record

    # =========================================================================
    # 2. Sequential Step Approval Notification (Owner update + Next Approver request)
    # =========================================================================
    async def trigger_step_approval_notifications(
        self,
        db: AsyncSession,
        reservation: Reservation,
        current_approver_name: str,
        next_step_order: int,
        next_approver_id: str,
        owner_id_or_name: Optional[str]
    ) -> List[EmailNotification]:
        """
        When an approver approves:
        1. Notify owner that approver approved and next step is pending.
        2. Send approval request to next approver (with owner in CC).
        """
        booking_id = reservation.id
        results = []

        owner_email, owner_name = await self._resolve_user_email(db, owner_id_or_name or reservation.owner_id or reservation.created_by or reservation.requested_by)
        next_approver_email, next_approver_name = await self._resolve_user_email(db, next_approver_id)

        mode_val = reservation.reservation_mode.value if hasattr(reservation.reservation_mode, "value") else str(reservation.reservation_mode)

        # 1. Email to Owner
        if owner_email and not await email_notification_dao.is_already_sent(db, booking_id, NotificationType.APPROVAL_COMPLETED.value, step_order=next_step_order - 1):
            owner_subject = f"TEM Booking Approval Update - {booking_id}"
            owner_plain = f"""TEM Booking Approval Update - {booking_id}

{current_approver_name} has approved Booking {booking_id}.

The reservation is now pending approval from {next_approver_name or next_approver_id} (Step {next_step_order}).

Environment: {reservation.environment_name}
Start: {format_dt(reservation.start_date)}
End: {format_dt(reservation.end_date)}
Mode: {mode_val}
"""
            owner_details = {
                "Booking ID": booking_id,
                "Environment": reservation.environment_name,
                "Approved Step": f"Step {next_step_order - 1} by {current_approver_name}",
                "Next Step": f"Step {next_step_order} pending with {next_approver_name or next_approver_id}",
                "Start Date/Time": format_dt(reservation.start_date),
                "End Date/Time": format_dt(reservation.end_date),
            }
            owner_html = generate_email_html(
                title=f"Approval Step Completed • {booking_id}",
                header_subtitle=f"Approved by {current_approver_name}",
                main_message=f"<strong>{current_approver_name}</strong> has approved your reservation request. The reservation has advanced to Step {next_step_order} and is now pending approval from <strong>{next_approver_name or next_approver_id}</strong>.",
                details=owner_details,
                action_banner=None,
                badge_color="#3b82f6",
                badge_text="STEP APPROVED"
            )

            rec_owner = await email_notification_dao.create_notification_record(
                db=db,
                booking_id=booking_id,
                notification_type=NotificationType.APPROVAL_COMPLETED.value,
                step_order=next_step_order - 1,
                recipient_to=owner_email,
                recipient_cc=None,
                subject=owner_subject,
                body=owner_html,
                status=NotificationStatus.PENDING.value
            )
            success_owner, err_owner = await self.send_email([owner_email], [], owner_subject, owner_plain, owner_html)
            now = datetime.now(timezone.utc)
            if success_owner:
                await email_notification_dao.update_status(db, rec_owner, status=NotificationStatus.SENT.value, sent_at=now)
            else:
                await email_notification_dao.update_status(db, rec_owner, status=NotificationStatus.FAILED.value, error_message=err_owner)
            results.append(rec_owner)

        # 2. Email to Next Approver (CC: Owner)
        if not await email_notification_dao.is_already_sent(db, booking_id, NotificationType.APPROVAL_REQUEST.value, step_order=next_step_order):
            if not next_approver_email:
                next_approver_email = "approver-unknown@testops.io"

            next_to = [next_approver_email]
            next_cc = [owner_email] if owner_email else []
            next_subject = f"TEM Booking Approval Required - {booking_id}"
            next_plain = f"""TEM Booking Approval Required - {booking_id}

{current_approver_name} has approved this reservation.

The reservation is now pending your approval (Step {next_step_order}).

Booking ID: {booking_id}
Environment: {reservation.environment_name}
Business Unit: {reservation.business_unit}
Project: {reservation.project or '-'}
Application: {reservation.application or '-'}
Start: {format_dt(reservation.start_date)}
End: {format_dt(reservation.end_date)}
Mode: {mode_val}
Requested By: {owner_name or reservation.requested_by}

Please review and approve or reject this reservation.
"""
            next_details = {
                "Booking ID": booking_id,
                "Environment": reservation.environment_name,
                "Previous Approval": f"Approved by {current_approver_name} (Step {next_step_order - 1})",
                "Business Unit": reservation.business_unit,
                "Project": reservation.project or "-",
                "Application": reservation.application or "-",
                "Start Date/Time": format_dt(reservation.start_date),
                "End Date/Time": format_dt(reservation.end_date),
                "Reservation Mode": mode_val,
                "Requested By": owner_name or reservation.requested_by,
                "Current Workflow Step": f"Step {next_step_order}",
            }
            next_html = generate_email_html(
                title=f"Approval Required (Step {next_step_order}) • {booking_id}",
                header_subtitle=f"Environment: {reservation.environment_name}",
                main_message=f"<strong>{current_approver_name}</strong> has approved this reservation. The reservation has moved to your stage (Step {next_step_order}) and now requires your review and decision.",
                details=next_details,
                action_banner="<strong>Required Action:</strong> Please sign in to the TEM Worklist to review and approve or reject this reservation.",
                badge_color="#f59e0b",
                badge_text=f"STEP {next_step_order} APPROVAL"
            )

            rec_next = await email_notification_dao.create_notification_record(
                db=db,
                booking_id=booking_id,
                notification_type=NotificationType.APPROVAL_REQUEST.value,
                step_order=next_step_order,
                recipient_to=next_approver_email,
                recipient_cc=", ".join(next_cc) if next_cc else None,
                subject=next_subject,
                body=next_html,
                status=NotificationStatus.PENDING.value
            )
            success_next, err_next = await self.send_email(next_to, next_cc, next_subject, next_plain, next_html)
            now = datetime.now(timezone.utc)
            if success_next:
                await email_notification_dao.update_status(db, rec_next, status=NotificationStatus.SENT.value, sent_at=now)
            else:
                await email_notification_dao.update_status(db, rec_next, status=NotificationStatus.FAILED.value, error_message=err_next)
            results.append(rec_next)

        return results

    # =========================================================================
    # 3. Final Approval Notification (TO: Owner)
    # =========================================================================
    async def trigger_final_approval_notification(
        self,
        db: AsyncSession,
        reservation: Reservation,
        owner_id_or_name: Optional[str]
    ) -> Optional[EmailNotification]:
        """
        When the last approver approves the reservation, notify booking owner.
        """
        booking_id = reservation.id
        notification_type = NotificationType.FINAL_APPROVAL.value

        if await email_notification_dao.is_already_sent(db, booking_id, notification_type):
            logger.info(f"Final approval notification already sent for booking {booking_id}.")
            return None

        owner_email, owner_name = await self._resolve_user_email(db, owner_id_or_name or reservation.owner_id or reservation.created_by or reservation.requested_by)
        if not owner_email:
            logger.warning(f"Could not resolve owner email for final approval notification ({booking_id}).")
            owner_email = "owner-unknown@testops.io"

        subject = f"Booking Approved - {booking_id}"
        mode_val = reservation.reservation_mode.value if hasattr(reservation.reservation_mode, "value") else str(reservation.reservation_mode)

        plain_text = f"""Booking Approved - {booking_id}

Your reservation {booking_id} has been approved by all required approvers.

All workflow approvals have been completed.

Environment: {reservation.environment_name}
Start Date/Time: {format_dt(reservation.start_date)}
End Date/Time: {format_dt(reservation.end_date)}
Reservation Mode: {mode_val}

Status: Approved
"""

        details = {
            "Booking ID": booking_id,
            "Environment": reservation.environment_name,
            "Business Unit": reservation.business_unit,
            "Project": reservation.project or "-",
            "Application": reservation.application or "-",
            "Start Date/Time": format_dt(reservation.start_date),
            "End Date/Time": format_dt(reservation.end_date),
            "Reservation Mode": mode_val,
            "Status": "Approved",
        }

        html_content = generate_email_html(
            title=f"Booking Approved • {booking_id}",
            header_subtitle=f"Environment: {reservation.environment_name}",
            main_message=f"Great news! Your reservation request for <strong>{reservation.environment_name}</strong> has been <strong>approved by all designated workflow approvers</strong>. All sequential approvals are complete.",
            details=details,
            action_banner="<strong>Status: Approved.</strong> Your environment time slot is now confirmed and protected from conflicts.",
            badge_color="#10b981",
            badge_text="APPROVED"
        )

        record = await email_notification_dao.create_notification_record(
            db=db,
            booking_id=booking_id,
            notification_type=notification_type,
            recipient_to=owner_email,
            subject=subject,
            body=html_content,
            status=NotificationStatus.PENDING.value
        )

        success, err = await self.send_email([owner_email], [], subject, plain_text, html_content)
        now = datetime.now(timezone.utc)
        if success:
            await email_notification_dao.update_status(db, record, status=NotificationStatus.SENT.value, sent_at=now)
        else:
            await email_notification_dao.update_status(db, record, status=NotificationStatus.FAILED.value, error_message=err)

        return record

    # =========================================================================
    # 4. Rejection Notification (TO: Owner)
    # =========================================================================
    async def trigger_rejection_notification(
        self,
        db: AsyncSession,
        reservation: Reservation,
        rejected_by_name: str,
        rejection_reason: Optional[str],
        owner_id_or_name: Optional[str]
    ) -> Optional[EmailNotification]:
        """
        When any approver rejects the reservation, notify booking owner.
        """
        booking_id = reservation.id
        notification_type = NotificationType.REJECTION.value

        if await email_notification_dao.is_already_sent(db, booking_id, notification_type):
            logger.info(f"Rejection notification already sent for booking {booking_id}.")
            return None

        owner_email, owner_name = await self._resolve_user_email(db, owner_id_or_name or reservation.owner_id or reservation.created_by or reservation.requested_by)
        if not owner_email:
            logger.warning(f"Could not resolve owner email for rejection notification ({booking_id}).")
            owner_email = "owner-unknown@testops.io"

        subject = f"Booking Rejected - {booking_id}"
        reason_text = rejection_reason or "Environment is not available during the requested period or rejected by approver."

        plain_text = f"""Booking Rejected - {booking_id}

Your reservation {booking_id} has been rejected.

Rejected By: {rejected_by_name}
Environment: {reservation.environment_name}
Start Date/Time: {format_dt(reservation.start_date)}
End Date/Time: {format_dt(reservation.end_date)}

Status: Rejected
Reason: {reason_text}
"""

        details = {
            "Booking ID": booking_id,
            "Environment": reservation.environment_name,
            "Rejected By": rejected_by_name,
            "Reason": reason_text,
            "Start Date/Time": format_dt(reservation.start_date),
            "End Date/Time": format_dt(reservation.end_date),
            "Status": "Rejected",
        }

        html_content = generate_email_html(
            title=f"Booking Rejected • {booking_id}",
            header_subtitle=f"Environment: {reservation.environment_name}",
            main_message=f"Your reservation request for <strong>{reservation.environment_name}</strong> has been <strong>rejected by {rejected_by_name}</strong>. The approval workflow has ended.",
            details=details,
            action_banner=f"<strong>Rejection Reason:</strong> {reason_text}",
            badge_color="#ef4444",
            badge_text="REJECTED"
        )

        record = await email_notification_dao.create_notification_record(
            db=db,
            booking_id=booking_id,
            notification_type=notification_type,
            recipient_to=owner_email,
            subject=subject,
            body=html_content,
            status=NotificationStatus.PENDING.value
        )

        success, err = await self.send_email([owner_email], [], subject, plain_text, html_content)
        now = datetime.now(timezone.utc)
        if success:
            await email_notification_dao.update_status(db, record, status=NotificationStatus.SENT.value, sent_at=now)
        else:
            await email_notification_dao.update_status(db, record, status=NotificationStatus.FAILED.value, error_message=err)

        return record

    # =========================================================================
    # 5. Future Booking Reminder (1 hour before start time)
    # =========================================================================
    async def trigger_booking_reminder_notification(
        self,
        db: AsyncSession,
        reservation: Reservation,
        owner_id_or_name: Optional[str]
    ) -> Optional[EmailNotification]:
        """
        Sends 1-hour upcoming reminder to the booking owner.
        """
        booking_id = reservation.id
        notification_type = NotificationType.BOOKING_REMINDER.value

        if await email_notification_dao.is_already_sent(db, booking_id, notification_type):
            logger.info(f"Upcoming booking reminder already sent for booking {booking_id}.")
            return None

        owner_email, owner_name = await self._resolve_user_email(db, owner_id_or_name or reservation.owner_id or reservation.created_by or reservation.requested_by)
        if not owner_email:
            logger.warning(f"Could not resolve owner email for reminder ({booking_id}).")
            owner_email = "owner-unknown@testops.io"

        subject = f"Upcoming Booking Reminder - {booking_id}"
        mode_val = reservation.reservation_mode.value if hasattr(reservation.reservation_mode, "value") else str(reservation.reservation_mode)

        start_date_str = reservation.start_date.strftime("%d %B %Y") if reservation.start_date else "-"
        start_time_str = reservation.start_date.strftime("%I:%M %p") if reservation.start_date else "-"
        end_time_str = reservation.end_date.strftime("%I:%M %p") if reservation.end_date else "-"

        plain_text = f"""Upcoming Booking Reminder - {booking_id}

Reminder: You have an upcoming environment reservation.

Booking ID: {booking_id}
Environment: {reservation.environment_name}

Date: {start_date_str}
Start Time: {start_time_str}
End Time: {end_time_str}
Reservation Mode: {mode_val}

Your booking starts in 1 hour.
"""

        details = {
            "Booking ID": booking_id,
            "Environment": reservation.environment_name,
            "Date": start_date_str,
            "Start Time": start_time_str,
            "End Time": end_time_str,
            "Reservation Mode": mode_val,
        }

        html_content = generate_email_html(
            title=f"Upcoming Reservation Reminder • {booking_id}",
            header_subtitle=f"Environment: {reservation.environment_name}",
            main_message=f"This is a reminder that your scheduled reservation for <strong>{reservation.environment_name}</strong> starts in <strong>1 hour</strong>.",
            details=details,
            action_banner="<strong>Reminder:</strong> Your booking starts in 1 hour. Please ensure your test automation or manual execution steps are prepared.",
            badge_color="#6366f1",
            badge_text="REMINDER • 1 HOUR"
        )

        record = await email_notification_dao.create_notification_record(
            db=db,
            booking_id=booking_id,
            notification_type=notification_type,
            recipient_to=owner_email,
            subject=subject,
            body=html_content,
            status=NotificationStatus.PENDING.value
        )

        success, err = await self.send_email([owner_email], [], subject, plain_text, html_content)
        now = datetime.now(timezone.utc)
        if success:
            await email_notification_dao.update_status(db, record, status=NotificationStatus.SENT.value, sent_at=now)
        else:
            await email_notification_dao.update_status(db, record, status=NotificationStatus.FAILED.value, error_message=err)

        return record

    # =========================================================================
    # 6. Retry Mechanism
    # =========================================================================
    async def retry_notification(
        self,
        db: AsyncSession,
        notification_id: str
    ) -> Tuple[bool, str, Optional[EmailNotification]]:
        """
        Retries delivery for an existing failed or pending notification record.
        """
        record = await email_notification_dao.get_by_id(db, notification_id)
        if not record:
            return False, f"Notification record '{notification_id}' not found.", None

        to_list = [e.strip() for e in record.recipient_to.split(",") if e.strip()]
        cc_list = [e.strip() for e in (record.recipient_cc or "").split(",") if e.strip()]

        success, err = await self.send_email(
            to_emails=to_list,
            cc_emails=cc_list,
            subject=record.subject,
            text_content=record.subject,
            html_content=record.body
        )

        now = datetime.now(timezone.utc)
        if success:
            updated = await email_notification_dao.increment_retry(
                db=db,
                notification=record,
                status=NotificationStatus.SENT.value,
                sent_at=now,
                error_message=None
            )
            return True, "Email notification resent successfully.", updated
        else:
            updated = await email_notification_dao.increment_retry(
                db=db,
                notification=record,
                status=NotificationStatus.FAILED.value,
                error_message=err
            )
            return False, f"Retry failed: {err}", updated


email_service = EmailService()
