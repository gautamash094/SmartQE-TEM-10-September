from typing import List, Tuple, Optional
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import EntityNotFoundException
from app.dao.runbook_dao import runbook_dao
from app.schemas.runbook import RunbookCreate, RunbookRead, RunbookExecute
from app.models.runbook import RunbookStatus


class RunbookService:
    async def create_runbook(
        self, db: AsyncSession, rb_in: RunbookCreate, current_user: Optional[any] = None
    ) -> RunbookRead:
        data = rb_in.model_dump()
        if current_user:
            data["created_by"] = current_user.username
            data["owner_id"] = str(current_user.id)
        else:
            data["created_by"] = "Super Admin"
            data["owner_id"] = None
        rb = await runbook_dao.create(db, data)
        return RunbookRead.model_validate(rb)

    async def get_runbook_by_id(
        self, db: AsyncSession, rb_id: str, current_user: Optional[any] = None
    ) -> RunbookRead:
        rb = await runbook_dao.get_by_id_for_user(db, rb_id, current_user)
        if not rb:
            raise EntityNotFoundException("Runbook", rb_id)
        return RunbookRead.model_validate(rb)

    async def execute_runbook(
        self, db: AsyncSession, rb_id: str, exec_in: RunbookExecute, current_user: Optional[any] = None
    ) -> RunbookRead:
        rb = await runbook_dao.get_by_id_for_user(db, rb_id, current_user)
        if not rb:
            raise EntityNotFoundException("Runbook", rb_id)

        update_data = {
            "status": RunbookStatus.RUNNING,
            "last_executed": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            "target_environment_id": exec_in.target_environment_id or rb.target_environment_id
        }
        updated = await runbook_dao.update(db, rb, update_data)
        return RunbookRead.model_validate(updated)

    async def get_runbooks_paginated(
        self, db: AsyncSession, page: int = 1, page_size: int = 20, current_user: Optional[any] = None
    ) -> Tuple[List[RunbookRead], int]:
        items, total = await runbook_dao.paginate_for_user(db, current_user, page, page_size)
        return [RunbookRead.model_validate(r) for r in items], total


runbook_service = RunbookService()
