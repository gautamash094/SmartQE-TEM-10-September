from typing import List, Tuple, Optional
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.user_dao import user_dao
from app.dao.role_dao import role_dao
from app.dao.portfolio_dao import business_unit_dao
from app.models.user import User
from app.models.role import Role
from app.schemas.user import UserCreate, UserUpdate, UserRead


class UserService:
    async def _check_single_super_admin(
        self,
        db: AsyncSession,
        assigned_roles: List[Role],
        is_active: bool,
        exclude_user_id: Optional[str] = None,
    ) -> None:
        has_super_admin = any(r.name.lower().strip() == "super admin" for r in assigned_roles)
        if has_super_admin and is_active:
            all_users = await user_dao.get_all_users_with_relations(db, is_active=True)
            other_super_admins = [
                u
                for u in all_users
                if (exclude_user_id is None or u.id != exclude_user_id)
                and any(r.name.lower().strip() == "super admin" for r in u.roles)
            ]
            if other_super_admins:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="A Super Admin already exists. Only one active Super Admin user is allowed in the system."
                )

    async def get_users(
        self,
        db: AsyncSession,
        page: int = 1,
        page_size: int = 20,
        search: Optional[str] = None,
        role_id: Optional[str] = None,
        bu_id: Optional[str] = None,
        is_active: Optional[bool] = None,
        current_user: Optional[User] = None,
    ) -> Tuple[List[UserRead], int]:
        if current_user:
            is_super = (
                getattr(current_user, "is_super_admin", False)
                or (getattr(current_user, "username", "").lower() == "admin")
                or any(getattr(r, "name", "").strip().lower() == "super admin" for r in (getattr(current_user, "roles", []) or []))
            )
            if not is_super:
                all_users = [
                    u for u in all_users
                    if u.id == current_user.id
                    or (u.username and u.username.lower() == (current_user.username or "").lower())
                    or (u.email and current_user.email and u.email.lower() == current_user.email.lower())
                ]

        total = len(all_users)
        start = (page - 1) * page_size
        end = start + page_size
        paginated = all_users[start:end]

        return [UserRead.model_validate(u) for u in paginated], total

    async def _resolve_user(self, db: AsyncSession, user_id: str) -> Optional[User]:
        user = await user_dao.get_user_by_id_with_relations(db, user_id)
        if not user:
            user = await user_dao.get_by_username(db, user_id)
        if not user and user_id.startswith("user-"):
            user = await user_dao.get_by_username(db, user_id.replace("user-", "", 1))
        if not user:
            user = await user_dao.get_by_email(db, user_id)
        return user

    async def get_user_by_id(self, db: AsyncSession, user_id: str) -> UserRead:
        user = await self._resolve_user(db, user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with ID '{user_id}' not found."
            )
        return UserRead.model_validate(user)

    async def create_user(self, db: AsyncSession, user_in: UserCreate) -> UserRead:
        # 1. Check unique username
        existing_user = await user_dao.get_by_username(db, user_in.username)
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="A user with this username already exists."
            )

        # 2. Check unique email
        existing_email = await user_dao.get_by_email(db, user_in.email)
        if existing_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="A user with this email already exists."
            )

        # 3. Validate Roles
        if not user_in.role_ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="At least one active role must be assigned to the user."
            )

        roles_query = select(Role).where(Role.id.in_(user_in.role_ids))
        roles_result = await db.execute(roles_query)
        assigned_roles = list(roles_result.scalars().all())

        if len(assigned_roles) != len(set(user_in.role_ids)):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="One or more selected roles are invalid or do not exist."
            )

        inactive_roles = [r.name for r in assigned_roles if not r.is_active]
        if inactive_roles:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Cannot assign inactive role(s): {', '.join(inactive_roles)}."
            )

        # 4. Enforce Single Active Super Admin rule
        await self._check_single_super_admin(db, assigned_roles, user_in.is_active)

        # 5. Validate Business Unit (optional)
        bu_id = user_in.business_unit_id
        if bu_id and bu_id.strip():
            bu = await business_unit_dao.get_by_id(db, bu_id.strip())
            if not bu:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Selected Business Unit '{bu_id}' does not exist."
                )
            if not bu.is_active:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Business Unit '{bu.name}' is inactive."
                )
            bu_id = bu.id
        else:
            bu_id = None

        # 6. Build user dictionary
        from app.services.auth_service import get_password_hash
        plain_password = user_in.password or "Admin@123"
        user_dict = {
            "first_name": user_in.first_name.strip(),
            "last_name": user_in.last_name.strip(),
            "username": user_in.username.strip(),
            "email": user_in.email.strip().lower(),
            "hashed_password": get_password_hash(plain_password),
            "business_unit_id": bu_id,
            "is_active": user_in.is_active,
            "status": "ACTIVE" if user_in.is_active else "INACTIVE",
            "created_by": user_in.created_by or "Super Admin",
            "updated_by": user_in.created_by or "Super Admin",
        }

        created = await user_dao.create_user_with_roles(db, user_dict, assigned_roles)
        # Re-fetch with relations loaded
        refreshed = await user_dao.get_user_by_id_with_relations(db, created.id)
        return UserRead.model_validate(refreshed)

    async def update_user(self, db: AsyncSession, user_id: str, user_in: UserUpdate) -> UserRead:
        user = await self._resolve_user(db, user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with ID '{user_id}' not found."
            )

        update_dict = {}
        if user_in.first_name is not None:
            update_dict["first_name"] = user_in.first_name.strip()
        if user_in.last_name is not None:
            update_dict["last_name"] = user_in.last_name.strip()
        if user_in.email is not None:
            new_email = str(user_in.email).strip().lower()
            if new_email != (user.email or "").lower():
                existing_email = await user_dao.get_by_email(db, new_email)
                if existing_email and existing_email.id != user.id:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="A user with this email already exists."
                    )
                update_dict["email"] = new_email

        target_active = user.is_active
        if user_in.is_active is not None:
            target_active = user_in.is_active
            update_dict["is_active"] = user_in.is_active
            update_dict["status"] = "ACTIVE" if user_in.is_active else "INACTIVE"
        elif user_in.status is not None:
            target_active = user_in.status == "ACTIVE"
            update_dict["status"] = user_in.status
            update_dict["is_active"] = target_active

        update_dict["updated_by"] = user_in.updated_by or "Super Admin"

        # Validate Business Unit (optional)
        if user_in.business_unit_id is not None:
            if user_in.business_unit_id and user_in.business_unit_id.strip():
                bu = await business_unit_dao.get_by_id(db, user_in.business_unit_id.strip())
                if not bu:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Selected Business Unit does not exist."
                    )
                if not bu.is_active:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Business Unit '{bu.name}' is inactive."
                    )
                update_dict["business_unit_id"] = bu.id
            else:
                update_dict["business_unit_id"] = None

        # Validate & update Roles if provided
        assigned_roles = user.roles
        if user_in.role_ids is not None:
            if len(user_in.role_ids) == 0:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="At least one active role must be assigned to the user."
                )

            roles_query = select(Role).where(Role.id.in_(user_in.role_ids))
            roles_result = await db.execute(roles_query)
            assigned_roles = list(roles_result.scalars().all())

            if len(assigned_roles) != len(set(user_in.role_ids)):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="One or more selected roles are invalid."
                )

            inactive_roles = [r.name for r in assigned_roles if not r.is_active]
            if inactive_roles:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Cannot assign inactive role(s): {', '.join(inactive_roles)}."
                )

        # Enforce Single Active Super Admin rule on update
        await self._check_single_super_admin(db, assigned_roles, target_active, exclude_user_id=user.id)

        updated = await user_dao.update_user_with_roles(
            db, user, update_dict, assigned_roles if user_in.role_ids is not None else None
        )
        refreshed = await user_dao.get_user_by_id_with_relations(db, updated.id)
        return UserRead.model_validate(refreshed)

    async def toggle_user_status(self, db: AsyncSession, user_id: str) -> UserRead:
        user = await self._resolve_user(db, user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with ID '{user_id}' not found."
            )

        new_active = not user.is_active
        new_status = "ACTIVE" if new_active else "INACTIVE"

        if new_active:
            await self._check_single_super_admin(db, user.roles, True, exclude_user_id=user.id)

        updated = await user_dao.update_user_with_roles(
            db, user, {"is_active": new_active, "status": new_status, "updated_by": "Super Admin"}
        )
        refreshed = await user_dao.get_user_by_id_with_relations(db, updated.id)
        return UserRead.model_validate(refreshed)

    async def delete_user(self, db: AsyncSession, user_id: str) -> bool:
        user = await self._resolve_user(db, user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with ID '{user_id}' not found."
            )

        return await user_dao.delete(db, user.id)


user_service = UserService()
