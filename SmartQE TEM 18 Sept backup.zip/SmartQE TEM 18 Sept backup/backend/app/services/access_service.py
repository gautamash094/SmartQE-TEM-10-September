from typing import List
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.access_dao import access_dao
from app.dao.role_dao import role_dao
from app.dao.user_dao import user_dao
from app.schemas.access import (
    ApplicationScreenRead,
    RoleAccessRead,
    RoleScreenAccessItem,
    UserPermissionsRead,
)


class AccessService:
    async def get_all_screens(self, db: AsyncSession) -> List[ApplicationScreenRead]:
        screens = await access_dao.get_all_screens(db)
        return [ApplicationScreenRead.model_validate(s) for s in screens]

    async def get_role_access(self, db: AsyncSession, role_id: str) -> RoleAccessRead:
        role = await role_dao.get_by_id(db, role_id)
        if not role:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Role with ID '{role_id}' not found."
            )

        all_screens = await access_dao.get_all_screens(db)
        is_super_admin = role.name.lower().strip() == "super admin"

        if is_super_admin:
            screen_items = [
                RoleScreenAccessItem(
                    screen_id=s.id,
                    screen_key=s.key,
                    screen_name=s.name,
                    route=s.route,
                    parent_key=s.parent_key,
                    category=s.category,
                    display_order=s.display_order,
                    has_access=True,
                )
                for s in all_screens
            ]
        else:
            role_entries = await access_dao.get_role_access_entries(db, role_id)
            accessible_screen_ids = {entry.screen_id for entry in role_entries if entry.has_access}

            screen_items = [
                RoleScreenAccessItem(
                    screen_id=s.id,
                    screen_key=s.key,
                    screen_name=s.name,
                    route=s.route,
                    parent_key=s.parent_key,
                    category=s.category,
                    display_order=s.display_order,
                    has_access=s.id in accessible_screen_ids,
                )
                for s in all_screens
            ]

        return RoleAccessRead(
            role_id=role.id,
            role_name=role.name,
            is_super_admin=is_super_admin,
            screens=screen_items,
        )

    async def update_role_access(
        self, db: AsyncSession, role_id: str, screen_ids: List[str]
    ) -> RoleAccessRead:
        role = await role_dao.get_by_id(db, role_id)
        if not role:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Role with ID '{role_id}' not found."
            )

        if role.name.lower().strip() == "super admin":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Super Admin role permanently maintains full access to all application screens and cannot be modified."
            )

        # Validate that all screen_ids exist
        all_screens = await access_dao.get_all_screens(db)
        valid_screen_ids = {s.id for s in all_screens}
        invalid = [s_id for s_id in screen_ids if s_id not in valid_screen_ids]
        if invalid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"One or more screen IDs are invalid: {', '.join(invalid)}"
            )

        await access_dao.save_role_access(db, role_id, screen_ids)
        return await self.get_role_access(db, role_id)

    async def get_effective_user_permissions(
        self, db: AsyncSession, user_id: str
    ) -> UserPermissionsRead:
        user = await user_dao.get_user_by_id_with_relations(db, user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with ID '{user_id}' not found."
            )

        all_screens = await access_dao.get_all_screens(db)
        role_names = [r.name for r in user.roles if r.is_active]
        is_super_admin = any(r.name.lower().strip() == "super admin" for r in user.roles if r.is_active)

        if is_super_admin:
            allowed_keys = [s.key for s in all_screens]
            allowed_routes = [s.route for s in all_screens]
        else:
            allowed_keys_set = set()
            allowed_routes_set = set()

            for role in user.roles:
                if not role.is_active:
                    continue
                entries = await access_dao.get_role_access_entries(db, role.id)
                for entry in entries:
                    if entry.has_access and entry.screen:
                        allowed_keys_set.add(entry.screen.key)
                        allowed_routes_set.add(entry.screen.route)

            allowed_keys = list(allowed_keys_set)
            allowed_routes = list(allowed_routes_set)

        return UserPermissionsRead(
            user_id=user.id,
            username=user.username,
            roles=role_names,
            is_super_admin=is_super_admin,
            allowed_screen_keys=allowed_keys,
            allowed_routes=allowed_routes,
        )


access_service = AccessService()
