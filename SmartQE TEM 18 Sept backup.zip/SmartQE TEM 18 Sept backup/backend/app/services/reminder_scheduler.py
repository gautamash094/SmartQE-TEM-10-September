import asyncio
from datetime import datetime, timezone, timedelta
from typing import List
from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import logger
from app.database.session import AsyncSessionLocal
from app.dao.email_notification_dao import email_notification_dao
from app.models.reservation import Reservation, ReservationStatus
from app.services.email_service import email_service


async def process_upcoming_booking_reminders(db: AsyncSession) -> int:
    """
    Scans for reservations starting in the next 1 hour and sends reminder emails.
    Returns the count of reminder emails sent/attempted.
    """
    now = datetime.now(timezone.utc)
    one_hour_ahead = now + timedelta(hours=1, minutes=5)  # 5 min grace window

    # Query eligible reservations:
    # 1. Status is APPROVED or CONFIRMED
    # 2. Start date is in future: now <= start_date <= one_hour_ahead
    query = (
        select(Reservation)
        .where(
            and_(
                or_(
                    Reservation.status == ReservationStatus.APPROVED,
                    Reservation.status == ReservationStatus.CONFIRMED,
                ),
                Reservation.start_date >= now,
                Reservation.start_date <= one_hour_ahead,
            )
        )
    )

    result = await db.execute(query)
    reservations: List[Reservation] = list(result.scalars().all())

    sent_count = 0
    for res in reservations:
        try:
            # Check if reminder already sent for this reservation
            already_sent = await email_notification_dao.is_already_sent(
                db=db,
                booking_id=res.id,
                notification_type="BOOKING_REMINDER"
            )
            if not already_sent:
                owner_identifier = res.owner_id or res.created_by or res.requested_by
                await email_service.trigger_booking_reminder_notification(
                    db=db,
                    reservation=res,
                    owner_id_or_name=owner_identifier
                )
                sent_count += 1
                logger.info(f"[REMINDER TRIGGERED] 1-Hour Reminder sent for Booking ID {res.id} (Starts: {res.start_date})")
        except Exception as exc:
            logger.error(f"[REMINDER ERROR] Failed to process reminder for booking {res.id}: {str(exc)}")

    return sent_count


class ReminderScheduler:
    def __init__(self, interval_seconds: int = 60):
        self.interval_seconds = interval_seconds
        self._task: asyncio.Task | None = None
        self._is_running = False

    async def _run_loop(self):
        logger.info(f"TEM Booking Reminder Scheduler started (Interval: {self.interval_seconds}s)")
        while self._is_running:
            try:
                async with AsyncSessionLocal() as session:
                    await process_upcoming_booking_reminders(session)
            except Exception as exc:
                logger.error(f"Error during reminder scheduler execution: {str(exc)}")

            try:
                await asyncio.sleep(self.interval_seconds)
            except asyncio.CancelledError:
                break
        logger.info("TEM Booking Reminder Scheduler stopped.")

    def start(self):
        if not self._is_running:
            self._is_running = True
            self._task = asyncio.create_task(self._run_loop())

    def stop(self):
        self._is_running = False
        if self._task and not self._task.done():
            self._task.cancel()


reminder_scheduler = ReminderScheduler(interval_seconds=60)
