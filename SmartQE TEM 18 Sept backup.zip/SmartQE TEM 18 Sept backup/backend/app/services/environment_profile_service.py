from typing import List, Tuple, Optional
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import EntityNotFoundException, DuplicateEntityException, PermissionDeniedException
from app.dao.environment_profile_dao import environment_profile_dao
from app.dao.reservation_dao import reservation_dao
from app.schemas.environment_profile import (
    EnvironmentProfileCreate, EnvironmentProfileUpdate, EnvironmentProfileRead
)
from app.dependencies.auth import is_user_super_admin


def _check_profile_ownership(profile: any, current_user: Optional[any]):
    if is_user_super_admin(current_user):
        return
    if not current_user:
        raise PermissionDeniedException("Authentication required.")
    user_id = str(getattr(current_user, "id", "") or "")
    username = str(getattr(current_user, "username", "") or "").lower()
    full_name = str(getattr(current_user, "full_name", "") or username).lower()
    owner_id = str(getattr(profile, "owner_id", "") or "")
    created_by = str(getattr(profile, "created_by", "") or "").lower()
    if owner_id != user_id and created_by not in (username, full_name):
        raise PermissionDeniedException("You do not have permission to view, modify, or delete this environment profile.")


class EnvironmentProfileService:
    async def create_profile(
        self, db: AsyncSession, profile_in: EnvironmentProfileCreate, current_user: Optional[any] = None
    ) -> EnvironmentProfileRead:
        existing = await environment_profile_dao.filter(db, {"name": profile_in.name})
        if existing:
            raise DuplicateEntityException(f"Environment Profile with name '{profile_in.name}' already exists.")

        data = {
            "name": profile_in.name,
            "type": profile_in.type,
            "description": profile_in.description or "",
            "status": profile_in.status,
            "is_active": profile_in.is_active,
            "owner_team": profile_in.owner_team or "",
            "network_zone": profile_in.network_zone or "",
            "server_ids": profile_in.server_ids or [],
            "software_ids": profile_in.software_ids or [],
            "created_by": current_user.username if current_user else "Super Admin",
            "owner_id": str(current_user.id) if current_user else None,
        }
        created = await environment_profile_dao.create(db, data)
        return EnvironmentProfileRead.model_validate(created)

    async def get_profile_by_id(
        self, db: AsyncSession, profile_id: str, current_user: Optional[any] = None
    ) -> EnvironmentProfileRead:
        profile = await environment_profile_dao.get_by_id(db, profile_id)
        if not profile or getattr(profile, "is_visible", True) is False:
            raise EntityNotFoundException("EnvironmentProfile", profile_id)
        _check_profile_ownership(profile, current_user)
        return EnvironmentProfileRead.model_validate(profile)

    async def get_all_profiles(
        self, db: AsyncSession, current_user: Optional[any] = None, skip: int = 0, limit: int = 100
    ) -> List[EnvironmentProfileRead]:
        items = await environment_profile_dao.get_all_for_user(db, current_user, skip=skip, limit=limit)
        return [EnvironmentProfileRead.model_validate(p) for p in items]

    async def update_profile(
        self, db: AsyncSession, profile_id: str, profile_in: EnvironmentProfileUpdate, current_user: Optional[any] = None
    ) -> EnvironmentProfileRead:
        profile = await environment_profile_dao.get_by_id(db, profile_id)
        if not profile or getattr(profile, "is_visible", True) is False:
            raise EntityNotFoundException("EnvironmentProfile", profile_id)
        _check_profile_ownership(profile, current_user)

        # If deactivating, check active reservations
        if profile_in.is_active is False and getattr(profile, "is_active", True) is True:
            has_res = await reservation_dao.has_active_or_upcoming_reservations(db, profile_id, getattr(profile, "name", None))
            if has_res:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Environment '{profile.name}' has one or more confirmed, future, or conflicting reservations. Hence, this environment cannot be deactivated."
                )

        update_data = profile_in.model_dump(exclude_unset=True)
        update_data.pop("created_by", None)
        update_data.pop("owner_id", None)
        if profile_in.server_ids is not None:
            update_data["server_ids"] = profile_in.server_ids
        if profile_in.software_ids is not None:
            update_data["software_ids"] = profile_in.software_ids
        if current_user:
            update_data["modified_by"] = getattr(current_user, "username", "Super Admin")

        updated = await environment_profile_dao.update(db, profile, update_data)
        return EnvironmentProfileRead.model_validate(updated)

    async def toggle_profile_status(
        self, db: AsyncSession, profile_id: str, current_user: Optional[any] = None
    ) -> EnvironmentProfileRead:
        profile = await environment_profile_dao.get_by_id(db, profile_id)
        if not profile or getattr(profile, "is_visible", True) is False:
            raise EntityNotFoundException("EnvironmentProfile", profile_id)
        _check_profile_ownership(profile, current_user)
        current_status = getattr(profile, "is_active", True)
        
        # If currently active, we are trying to deactivate
        if current_status:
            has_res = await reservation_dao.has_active_or_upcoming_reservations(db, profile_id, getattr(profile, "name", None))
            if has_res:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Environment '{profile.name}' has one or more confirmed, future, or conflicting reservations. Hence, this environment cannot be deactivated."
                )

        updated = await environment_profile_dao.update(db, profile, {"is_active": not current_status})
        return EnvironmentProfileRead.model_validate(updated)

    async def delete_profile(
        self, db: AsyncSession, profile_id: str, current_user: Optional[any] = None
    ) -> bool:
        profile = await environment_profile_dao.get_by_id(db, profile_id)
        if not profile or getattr(profile, "is_visible", True) is False:
            raise EntityNotFoundException("EnvironmentProfile", profile_id)
        _check_profile_ownership(profile, current_user)
        
        # If currently active, check active reservations
        if getattr(profile, "is_active", True):
            has_res = await reservation_dao.has_active_or_upcoming_reservations(db, profile_id, getattr(profile, "name", None))
            if has_res:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Environment '{profile.name}' has one or more confirmed, future, or conflicting reservations. Hence, this environment cannot be deactivated."
                )

        # Soft deactivation: preserve all data, mark invisible
        await environment_profile_dao.update(db, profile, {"is_active": False, "is_visible": False})
        return True


environment_profile_service = EnvironmentProfileService()
