from datetime import datetime, timezone
from typing import List, Optional, Tuple
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.workflow_dao import workflow_dao
from app.dao.portfolio_dao import business_unit_dao, application_dao
from app.dao.environment_profile_dao import environment_profile_dao
from app.dao.user_dao import user_dao
from app.models.workflow import (
    Workflow,
    WorkflowApprover,
    WorkflowExecution,
    WorkflowExecutionStep,
    TEMServiceType,
    SERVICE_DISPLAY_NAMES,
)
from app.schemas.workflow import (
    WorkflowCreate,
    WorkflowUpdate,
    WorkflowRead,
    WorkflowApproverRead,
    WorkflowApproverItem,
    WorkflowExecutionRead,
    WorkflowExecutionStepRead,
)


class WorkflowService:
    def _map_to_read(self, workflow: Workflow) -> WorkflowRead:
        bu_name = workflow.business_unit.name if workflow.business_unit else None
        bu_code = workflow.business_unit.code if workflow.business_unit else None

        approver_reads = []
        for a in (workflow.approvers or []):
            u = a.user
            approver_reads.append(
                WorkflowApproverRead(
                    id=a.id,
                    workflow_id=a.workflow_id,
                    user_id=a.user_id,
                    workflow_order=a.workflow_order,
                    username=u.username if u else None,
                    full_name=u.full_name if u else None,
                    email=u.email if u else None,
                    created_at=a.created_at,
                    created_by=a.created_by,
                )
            )

        return WorkflowRead(
            id=workflow.id,
            bu_id=workflow.bu_id,
            bu_name=bu_name,
            bu_code=bu_code,
            environment_id=workflow.environment_id,
            environment_name=workflow.environment_name,
            application_id=workflow.application_id,
            application_name=workflow.application_name,
            service_code=workflow.service_code,
            service_name=workflow.service_name,
            approvers=approver_reads,
            approver_count=len(approver_reads),
            is_active=workflow.is_active,
            status=workflow.status,
            created_at=workflow.created_at,
            created_by=workflow.created_by,
            updated_at=workflow.updated_at,
            modified_by=workflow.modified_by,
        )

    def _map_execution_to_read(self, execution: WorkflowExecution) -> WorkflowExecutionRead:
        step_reads = []
        for s in (execution.steps or []):
            u = s.user
            step_reads.append(
                WorkflowExecutionStepRead(
                    id=s.id,
                    execution_id=s.execution_id,
                    user_id=s.user_id,
                    username=u.username if u else None,
                    full_name=u.full_name if u else None,
                    workflow_order=s.workflow_order,
                    status=s.status,
                    action_by=s.action_by,
                    action_at=s.action_at,
                    comments=s.comments,
                )
            )

        return WorkflowExecutionRead(
            id=execution.id,
            workflow_id=execution.workflow_id,
            entity_type=execution.entity_type,
            entity_id=execution.entity_id,
            current_step_order=execution.current_step_order,
            total_steps=execution.total_steps,
            status=execution.status,
            steps=step_reads,
            created_at=execution.created_at,
            updated_at=execution.updated_at,
        )

    async def _validate_workflow_context(
        self,
        db: AsyncSession,
        bu_id: str,
        environment_id: str,
        application_id: str,
        service_code: TEMServiceType,
        approvers: List[WorkflowApproverItem],
    ) -> Tuple[str, str]:
        # 1. Validate BU exists and is active
        bu = await business_unit_dao.get_by_id(db, bu_id)
        if not bu:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Business Unit with ID '{bu_id}' does not exist."
            )
        if not bu.is_active or bu.status == "INACTIVE":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Selected Business Unit '{bu.name}' is inactive."
            )

        # 2. Validate Environment
        env_profile = await environment_profile_dao.get_by_id(db, environment_id)
        environment_name = env_profile.name if env_profile else environment_id

        # 3. Validate Application
        app_obj = await application_dao.get_by_id(db, application_id)
        application_name = app_obj.name if app_obj else application_id

        # 4. Validate Approvers belong to the BU and are active
        if not approvers or len(approvers) == 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="At least one approver must be selected for the workflow."
            )

        user_ids = [a.user_id for a in approvers]
        if len(user_ids) != len(set(user_ids)):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="The same user cannot be added multiple times to the same workflow."
            )

        orders = [a.workflow_order for a in approvers]
        if len(orders) != len(set(orders)):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Duplicate approval order numbers are not allowed."
            )

        for a in approvers:
            user = await user_dao.get_by_id(db, a.user_id)
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"User with ID '{a.user_id}' not found."
                )
            if not user.is_active or user.status == "INACTIVE":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"User '{user.username}' is inactive and cannot participate in approval workflows."
                )
            if user.business_unit_id != bu_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Approver '{user.username}' does not belong to the selected Business Unit '{bu.name}'. Only users tagged to '{bu.name}' can be approvers."
                )

        return environment_name, application_name

    async def get_workflows(
        self,
        db: AsyncSession,
        page: int = 1,
        page_size: int = 50,
        bu_id: Optional[str] = None,
        environment_id: Optional[str] = None,
        application_id: Optional[str] = None,
        service_code: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> Tuple[List[WorkflowRead], int]:
        workflows, total = await workflow_dao.get_all_workflows(
            db,
            page=page,
            page_size=page_size,
            bu_id=bu_id,
            environment_id=environment_id,
            application_id=application_id,
            service_code=service_code,
            is_active=is_active,
        )
        return [self._map_to_read(w) for w in workflows], total

    async def get_workflow_by_id(self, db: AsyncSession, workflow_id: str) -> WorkflowRead:
        workflow = await workflow_dao.get_with_details(db, workflow_id)
        if not workflow:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow with ID '{workflow_id}' not found."
            )
        return self._map_to_read(workflow)

    async def create_workflow(
        self, db: AsyncSession, workflow_in: WorkflowCreate, actor: str = "Super Admin"
    ) -> WorkflowRead:
        # Check context uniqueness (bu + env + app + service)
        existing = await workflow_dao.get_by_context(
            db,
            workflow_in.bu_id,
            workflow_in.environment_id,
            workflow_in.application_id,
            workflow_in.service_code.value,
        )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"A workflow definition already exists for the selected BU, Environment, Application, and Service."
            )

        env_name, app_name = await self._validate_workflow_context(
            db,
            workflow_in.bu_id,
            workflow_in.environment_id,
            workflow_in.application_id,
            workflow_in.service_code,
            workflow_in.approvers,
        )

        service_display = SERVICE_DISPLAY_NAMES.get(
            workflow_in.service_code, workflow_in.service_code.value
        )

        workflow = Workflow(
            bu_id=workflow_in.bu_id,
            environment_id=workflow_in.environment_id,
            environment_name=env_name,
            application_id=workflow_in.application_id,
            application_name=app_name,
            service_code=workflow_in.service_code.value,
            service_name=service_display,
            status="ACTIVE" if workflow_in.is_active else "INACTIVE",
            is_active=workflow_in.is_active,
            created_by=actor,
            modified_by=actor,
        )
        for item in workflow_in.approvers:
            workflow.approvers.append(
                WorkflowApprover(
                    user_id=item.user_id,
                    workflow_order=item.workflow_order,
                    created_by=actor,
                )
            )

        db.add(workflow)
        await db.commit()

        refreshed = await workflow_dao.get_with_details(db, workflow.id)
        return self._map_to_read(refreshed or workflow)

    async def update_workflow(
        self, db: AsyncSession, workflow_id: str, workflow_in: WorkflowUpdate, actor: str = "Super Admin"
    ) -> WorkflowRead:
        workflow = await workflow_dao.get_with_details(db, workflow_id)
        if not workflow:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow with ID '{workflow_id}' not found."
            )

        target_bu_id = workflow_in.bu_id or workflow.bu_id
        target_env_id = workflow_in.environment_id or workflow.environment_id
        target_app_id = workflow_in.application_id or workflow.application_id
        target_service = workflow_in.service_code or TEMServiceType(workflow.service_code)

        # Check uniqueness if context changed
        if (
            target_bu_id != workflow.bu_id
            or target_env_id != workflow.environment_id
            or target_app_id != workflow.application_id
            or target_service.value != workflow.service_code
        ):
            existing = await workflow_dao.get_by_context(
                db, target_bu_id, target_env_id, target_app_id, target_service.value
            )
            if existing and existing.id != workflow_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="A workflow definition already exists for the updated BU, Environment, Application, and Service."
                )

        # Determine effective approvers
        if workflow_in.approvers is not None:
            effective_approvers = workflow_in.approvers
        else:
            effective_approvers = [
                WorkflowApproverItem(user_id=a.user_id, workflow_order=a.workflow_order)
                for a in (workflow.approvers or [])
            ]

        env_name, app_name = await self._validate_workflow_context(
            db,
            target_bu_id,
            target_env_id,
            target_app_id,
            target_service,
            effective_approvers,
        )

        workflow.bu_id = target_bu_id
        workflow.environment_id = target_env_id
        workflow.environment_name = env_name
        workflow.application_id = target_app_id
        workflow.application_name = app_name
        workflow.service_code = target_service.value
        workflow.service_name = SERVICE_DISPLAY_NAMES.get(target_service, target_service.value)
        workflow.modified_by = actor

        if workflow_in.is_active is not None:
            workflow.is_active = workflow_in.is_active
            workflow.status = "ACTIVE" if workflow_in.is_active else "INACTIVE"
        elif workflow_in.status is not None:
            workflow.status = workflow_in.status
            workflow.is_active = workflow_in.status == "ACTIVE"

        if workflow_in.approvers is not None:
            for a in list(workflow.approvers or []):
                await db.delete(a)
            await db.flush()
            for item in workflow_in.approvers:
                workflow.approvers.append(
                    WorkflowApprover(
                        user_id=item.user_id,
                        workflow_order=item.workflow_order,
                        created_by=actor,
                    )
                )

        await db.commit()
        refreshed = await workflow_dao.get_with_details(db, workflow_id)
        return self._map_to_read(refreshed or workflow)

    async def toggle_workflow_status(
        self, db: AsyncSession, workflow_id: str, actor: str = "Super Admin"
    ) -> WorkflowRead:
        workflow = await workflow_dao.get_with_details(db, workflow_id)
        if not workflow:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow with ID '{workflow_id}' not found."
            )

        new_status = not workflow.is_active
        updated = await workflow_dao.update(
            db,
            workflow,
            {
                "is_active": new_status,
                "status": "ACTIVE" if new_status else "INACTIVE",
                "modified_by": actor,
            }
        )
        db.expire_all()
        refreshed = await workflow_dao.get_with_details(db, workflow_id)
        return self._map_to_read(refreshed or updated)

    async def delete_workflow(
        self, db: AsyncSession, workflow_id: str, actor: str = "Super Admin"
    ) -> None:
        workflow = await workflow_dao.get_with_details(db, workflow_id)
        if not workflow:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow with ID '{workflow_id}' not found."
            )

        # Permanent deletion of workflow definition
        await db.delete(workflow)
        await db.commit()

    # --- Sequential Approval Execution Engine ---
    async def start_workflow_execution(
        self,
        db: AsyncSession,
        bu_id: str,
        environment_id: str,
        application_id: str,
        service_code: str,
        entity_type: str,
        entity_id: str,
        actor: str = "System"
    ) -> Optional[WorkflowExecutionRead]:
        # Find matching active workflow
        workflow = await workflow_dao.get_by_context(
            db, bu_id, environment_id, application_id, service_code
        )
        if not workflow or not workflow.is_active or len(workflow.approvers) == 0:
            return None

        # Create execution
        execution = WorkflowExecution(
            workflow_id=workflow.id,
            entity_type=entity_type,
            entity_id=entity_id,
            current_step_order=1,
            total_steps=len(workflow.approvers),
            status="PENDING",
            created_by=actor,
            modified_by=actor,
        )
        db.add(execution)
        await db.flush()

        # Create sequential execution steps
        for approver in workflow.approvers:
            step_status = "PENDING" if approver.workflow_order == 1 else "WAITING"
            step = WorkflowExecutionStep(
                execution_id=execution.id,
                user_id=approver.user_id,
                workflow_order=approver.workflow_order,
                status=step_status,
            )
            db.add(step)

        await db.commit()
        refreshed = await workflow_dao.get_execution_with_details(db, execution.id)
        return self._map_execution_to_read(refreshed or execution)

    async def get_execution_for_entity(
        self, db: AsyncSession, entity_type: str, entity_id: str
    ) -> Optional[WorkflowExecutionRead]:
        execution = await workflow_dao.get_execution_by_entity(db, entity_type, entity_id)
        if not execution:
            return None
        return self._map_execution_to_read(execution)

    async def process_approval_action(
        self,
        db: AsyncSession,
        execution_id: str,
        user_id: str,
        action: str,
        comments: Optional[str] = None,
        is_super_admin: bool = False,
    ) -> WorkflowExecutionRead:
        execution = await workflow_dao.get_execution_with_details(db, execution_id)
        if not execution:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow execution '{execution_id}' not found."
            )

        if execution.status != "PENDING":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Workflow execution is already finalized with status '{execution.status}'."
            )

        # Find current pending step
        current_step = None
        for step in execution.steps:
            if step.workflow_order == execution.current_step_order:
                current_step = step
                break

        if not current_step:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"No pending step found for order {execution.current_step_order}."
            )

        # Validate that the acting user is the configured approver for this step (or Super Admin)
        if not is_super_admin and current_step.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"You are not the designated approver for Order {current_step.workflow_order} in this sequential workflow."
            )

        now = datetime.now(timezone.utc)
        action_upper = action.strip().upper()

        if action_upper == "REJECT":
            # Immediate rejection: stop workflow
            current_step.status = "REJECTED"
            current_step.action_by = user_id
            current_step.action_at = now
            current_step.comments = comments or "Rejected"

            execution.status = "REJECTED"
            execution.modified_by = user_id

        elif action_upper == "APPROVE":
            current_step.status = "APPROVED"
            current_step.action_by = user_id
            current_step.action_at = now
            current_step.comments = comments or "Approved"

            # Check if there is a next step
            next_step_order = execution.current_step_order + 1
            next_step = None
            for step in execution.steps:
                if step.workflow_order == next_step_order:
                    next_step = step
                    break

            if next_step:
                # Progress to next step
                next_step.status = "PENDING"
                execution.current_step_order = next_step_order
                execution.modified_by = user_id
            else:
                # Final step completed -> All approved
                execution.status = "APPROVED"
                execution.modified_by = user_id

        await db.commit()
        refreshed = await workflow_dao.get_execution_with_details(db, execution.id)
        return self._map_execution_to_read(refreshed or execution)


workflow_service = WorkflowService()
