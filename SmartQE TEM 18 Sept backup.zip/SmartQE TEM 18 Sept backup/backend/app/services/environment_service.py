from typing import List, Tuple, Optional
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import EntityNotFoundException, DuplicateEntityException
from app.dao.environment_dao import environment_dao
from app.dao.reservation_dao import reservation_dao
from app.dao.incident_dao import incident_dao
from app.dao.release_dao import release_dao
from app.schemas.environment import (
    EnvironmentCreate, EnvironmentUpdate, EnvironmentRead, OverviewMetrics, ComponentTopologyCreate
)


class EnvironmentService:
    async def create_environment(
        self, db: AsyncSession, env_in: EnvironmentCreate, current_user: Optional[any] = None
    ) -> EnvironmentRead:
        if await environment_dao.get_by_name(db, env_in.name):
            raise DuplicateEntityException(f"Environment with name '{env_in.name}' already exists.")

        data = env_in.model_dump(exclude={"topology"})
        if current_user:
            data["owner_id"] = str(current_user.id)
            data["created_by"] = current_user.username
        else:
            data["owner_id"] = None
            data["created_by"] = "Super Admin"

        env = await environment_dao.create(db, data)

        if env_in.topology:
            for comp in env_in.topology:
                await environment_dao.add_component(db, env.id, comp.model_dump())

        # Re-fetch with topology relationship
        fresh = await environment_dao.get_by_id(db, env.id)
        return EnvironmentRead.model_validate(fresh)

    async def get_environment_by_id(
        self, db: AsyncSession, env_id: str, current_user: Optional[any] = None
    ) -> EnvironmentRead:
        env = await environment_dao.get_by_id_for_user(db, env_id, current_user)
        if not env:
            raise EntityNotFoundException("Environment", env_id)
        return EnvironmentRead.model_validate(env)

    async def update_environment(
        self, db: AsyncSession, env_id: str, env_in: EnvironmentUpdate, current_user: Optional[any] = None
    ) -> EnvironmentRead:
        env = await environment_dao.get_by_id_for_user(db, env_id, current_user)
        if not env:
            raise EntityNotFoundException("Environment", env_id)

        update_data = env_in.model_dump(exclude_unset=True)
        update_data.pop("created_by", None)
        update_data.pop("owner_id", None)
        if update_data.get("is_active") is False and getattr(env, "is_active", True) is True:
            has_res = await reservation_dao.has_active_or_upcoming_reservations(db, env_id, getattr(env, "name", None))
            if has_res:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Environment '{env.name}' has one or more confirmed, future, or conflicting reservations. Hence, this environment cannot be deactivated."
                )

        if current_user:
            update_data["modified_by"] = getattr(current_user, "username", "Super Admin")

        updated = await environment_dao.update(db, env, update_data)
        return EnvironmentRead.model_validate(updated)

    async def toggle_environment_status(
        self, db: AsyncSession, env_id: str, current_user: Optional[any] = None
    ) -> EnvironmentRead:
        env = await environment_dao.get_by_id_for_user(db, env_id, current_user)
        if not env:
            raise EntityNotFoundException("Environment", env_id)
        current_status = getattr(env, "is_active", True)
        if current_status:
            has_res = await reservation_dao.has_active_or_upcoming_reservations(db, env_id, getattr(env, "name", None))
            if has_res:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Environment '{env.name}' has one or more confirmed, future, or conflicting reservations. Hence, this environment cannot be deactivated."
                )

        updated = await environment_dao.update(db, env, {"is_active": not current_status})
        return EnvironmentRead.model_validate(updated)

    async def delete_environment(
        self, db: AsyncSession, env_id: str, current_user: Optional[any] = None
    ) -> bool:
        env = await environment_dao.get_by_id_for_user(db, env_id, current_user)
        if not env:
            raise EntityNotFoundException("Environment", env_id)
        if getattr(env, "is_active", True):
            has_res = await reservation_dao.has_active_or_upcoming_reservations(db, env_id, getattr(env, "name", None))
            if has_res:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Environment '{env.name}' has one or more confirmed, future, or conflicting reservations. Hence, this environment cannot be deactivated."
                )

        # Soft deactivation: preserve all data, ID, relationships
        await environment_dao.update(db, env, {"is_active": False})
        return True

    async def get_environments_paginated(
        self, db: AsyncSession, page: int = 1, page_size: int = 20, tier: Optional[str] = None, current_user: Optional[any] = None
    ) -> Tuple[List[EnvironmentRead], int]:
        items, total = await environment_dao.paginate_for_user(db, current_user, page, page_size)
        return [EnvironmentRead.model_validate(e) for e in items], total

    async def get_overview_metrics(self, db: AsyncSession, current_user: Optional[any] = None) -> OverviewMetrics:
        health_sum = await environment_dao.get_health_summary(db, current_user=current_user)
        total_envs = health_sum["total"]
        healthy_envs = health_sum["healthy"]
        down_envs = health_sum["down"]

        _, total_bookings = await reservation_dao.paginate_for_user(db, current_user, page=1, page_size=1)
        open_incs = await incident_dao.get_open_incidents(db, current_user=current_user)
        open_incidents = len(open_incs)
        _, upcoming_releases = await release_dao.paginate_for_user(db, current_user, page=1, page_size=1)

        utilization_rate = round((total_bookings / max(total_envs, 1)) * 100, 1)

        return OverviewMetrics(
            totalEnvironments=total_envs,
            healthyEnvironments=healthy_envs,
            activeBookings=total_bookings,
            utilizationRate=utilization_rate,
            openIncidents=open_incidents,
            downEnvironmentsCount=down_envs,
            upcomingReleases=upcoming_releases,
            trackedReleasesCount=upcoming_releases,
            cpuAverage=health_sum["cpu_avg"],
            memoryAverage=health_sum["mem_avg"],
            storageAverage=health_sum["storage_avg"]
        )


environment_service = EnvironmentService()
