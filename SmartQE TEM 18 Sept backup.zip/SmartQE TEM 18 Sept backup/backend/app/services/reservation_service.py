import json
import uuid
from datetime import datetime, timezone
from typing import List, Tuple, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import EntityNotFoundException, AppException, PermissionDeniedException
from app.core.logging import logger
from app.dao.reservation_dao import reservation_dao
from app.dao.environment_dao import environment_dao
from app.dao.environment_profile_dao import environment_profile_dao
from app.dao.workflow_dao import workflow_dao
from app.dao.user_dao import user_dao
from app.dependencies.auth import is_user_super_admin
from app.models.reservation import Reservation, ReservationStatus, ReservationMode, AutoApprovalRule, ReservationPriority
from app.models.workflow import WorkflowExecution, WorkflowExecutionStep
from app.schemas.reservation import ReservationCreate, ReservationUpdate, ReservationRead
from app.services.email_service import email_service


def append_audit_entry(
    audit_history_raw: Optional[str],
    field: str,
    old_val: str,
    new_val: str,
    changed_by: str,
    comments: Optional[str] = None,
    step_order: Optional[int] = None,
    status: Optional[str] = None
) -> str:
    try:
        history = json.loads(audit_history_raw) if audit_history_raw else []
        if not isinstance(history, list):
            history = []
    except Exception:
        history = []
    
    entry = {
        "id": f"audit-{uuid.uuid4().hex[:8]}",
        "field": field,
        "oldValue": str(old_val),
        "newValue": str(new_val),
        "changedBy": changed_by,
        "changedAt": datetime.now(timezone.utc).isoformat()
    }
    if comments is not None:
        entry["comments"] = str(comments)
    if step_order is not None:
        entry["stepOrder"] = step_order
    if status is not None:
        entry["status"] = status

    history.append(entry)
    return json.dumps(history)


class ReservationService:
    async def auto_reject_expired(self, db: AsyncSession) -> int:
        """Explicitly run the auto-rejection sweep on expired reservations."""
        return await reservation_dao.auto_reject_expired_reservations(db)

    async def create_reservation(
        self, db: AsyncSession, res_in: ReservationCreate, current_user: Optional[any] = None
    ) -> Tuple[ReservationRead, str]:
        """
        Creates a reservation and attaches active sequential workflow if defined.
        Returns tuple of (ReservationRead, success_message).
        """
        # Run auto-reject sweep first
        await reservation_dao.auto_reject_expired_reservations(db)

        # 1. Validate Environment exists in Environment Details profiles or legacy environments
        target_id = res_in.environment_id
        target_name = res_in.environment_name

        # First check Environment Details profiles
        env_profile = await environment_profile_dao.get_by_id(db, res_in.environment_id)
        if not env_profile and res_in.environment_name:
            profiles = await environment_profile_dao.filter(db, {"name": res_in.environment_name})
            if profiles:
                env_profile = profiles[0]

        if env_profile:
            target_id = env_profile.id
            target_name = env_profile.name
        else:
            # Fallback check on environments table
            env = await environment_dao.get_by_id(db, res_in.environment_id)
            if not env and res_in.environment_name:
                env = await environment_dao.get_by_name(db, res_in.environment_name)
            if env:
                target_id = env.id
                target_name = env.name
            else:
                if not target_id and not target_name:
                    raise EntityNotFoundException("Environment", res_in.environment_id)

        # 2. Domain Validation: Business Unit is required (Project and Application are optional)
        if not res_in.business_unit or not res_in.business_unit.strip():
            raise AppException("Business Unit is a required field for environment reservation.")

        # 3. Date validation
        if res_in.end_date <= res_in.start_date:
            raise AppException("Start date time is greater than the end date time.")

        # 4. Enterprise Conflict Check:
        res_mode = res_in.reservation_mode or getattr(res_in, "reservation_mode", None)
        conflicts = await reservation_dao.check_conflicts(
            db, target_id, res_in.start_date, res_in.end_date, reservation_mode=res_mode
        )

        data = res_in.model_dump()
        data["environment_id"] = target_id
        data["environment_name"] = target_name

        # 5. Populate Data Ownership (Store Creator's Permanent User ID)
        actor_name = "Super Admin"
        if current_user:
            if is_user_super_admin(current_user):
                raise AppException("System Admin users are not permitted to create reservations.")
            actor_name = getattr(current_user, "full_name", None) or current_user.username
            data["owner_id"] = str(current_user.id)
            data["created_by"] = current_user.username
            if not data.get("requested_by"):
                data["requested_by"] = actor_name

        # 6. Check Active Sequential Approval Workflow for Environment Reservation
        active_workflow = await workflow_dao.get_active_workflow_for_reservation(
            db,
            bu_id=data.get("business_unit"),
            bu_name=data.get("business_unit"),
            environment_id=target_id,
            environment_name=target_name,
            application_id=data.get("application"),
            application_name=data.get("application"),
            service_code="ENVIRONMENT_RESERVATION",
        )

        # Requirement: User cannot make any reservation unless an active workflow is defined
        if not active_workflow or not active_workflow.approvers or len(active_workflow.approvers) == 0:
            raise AppException("Define the workflow to make any reservation.")

        # Check if already expired at creation time (edge case)
        now = datetime.now(timezone.utc)
        res_end = res_in.end_date
        if res_end.tzinfo is None:
            res_end = res_end.replace(tzinfo=timezone.utc)

        auto_enabled = bool(data.get("auto_approval_enabled"))
        success_message = "Reservation confirmed successfully"

        approvers_sorted = sorted(active_workflow.approvers, key=lambda a: a.workflow_order)
        first_approver = approvers_sorted[0]
        first_user = first_approver.user
        first_approver_name = (first_user.full_name or first_user.username) if first_user else first_approver.user_id

        data["workflow_id"] = active_workflow.id
        data["current_workflow_order"] = 1
        data["current_approver_id"] = first_approver.user_id
        data["current_approver_name"] = first_approver_name

        if res_end < now:
            data["status"] = ReservationStatus.AUTO_REJECTED
            data["rejection_type"] = "AUTO"
            data["rejection_reason"] = "Booking end date and time has passed"
            data["rejected_at"] = now
            success_message = "Reservation expired and auto-rejected"
        elif conflicts:
            if auto_enabled:
                raise AppException("Auto Approval cannot be enabled for a reservation with a conflict. Please resolve the conflict first.")
            data["status"] = ReservationStatus.CONFLICT
            success_message = "Reservation created with schedule conflict"
        else:
            # Rule: When active workflow is configured, initial status MUST be PENDING (Never Confirmed or Approved)
            data["status"] = ReservationStatus.PENDING
            data["audit_history"] = append_audit_entry(
                data.get("audit_history"),
                "workflow",
                "Created",
                f"Pending approval from {first_approver_name} (Order 1)",
                actor_name
            )
            success_message = "Reservation created successfully and is pending approval from the configured workflow."

        created = await reservation_dao.create(db, data)

        # Snapshot workflow execution for audit consistency
        if active_workflow and active_workflow.approvers and len(active_workflow.approvers) > 0 and data["status"] in [ReservationStatus.PENDING, ReservationStatus.CONFLICT]:
            execution = WorkflowExecution(
                workflow_id=active_workflow.id,
                entity_type="RESERVATION",
                entity_id=created.id,
                current_step_order=1,
                total_steps=len(active_workflow.approvers),
                status="PENDING",
                created_by=actor_name,
                modified_by=actor_name,
            )
            db.add(execution)
            await db.flush()

            for app_item in sorted(active_workflow.approvers, key=lambda a: a.workflow_order):
                step_status = "PENDING" if app_item.workflow_order == 1 else "WAITING"
                step = WorkflowExecutionStep(
                    execution_id=execution.id,
                    user_id=app_item.user_id,
                    workflow_order=app_item.workflow_order,
                    status=step_status,
                )
                db.add(step)

            await db.commit()

        await reservation_dao.recalculate_environment_conflicts(db, target_id)
        refreshed = await reservation_dao.get_by_id(db, created.id)

        # Trigger Email Notification for First Approver (CC: Owner)
        if data.get("status") == ReservationStatus.PENDING and first_approver:
            try:
                await email_service.trigger_booking_created_notification(
                    db=db,
                    reservation=refreshed or created,
                    first_approver_id=first_approver.user_id,
                    owner_id_or_name=data.get("owner_id") or data.get("created_by") or data.get("requested_by")
                )
            except Exception as exc:
                logger.error(f"Failed to trigger booking created email for reservation {created.id}: {str(exc)}")

        return ReservationRead.model_validate(refreshed or created), success_message

    async def get_reservation_by_id(
        self, db: AsyncSession, res_id: str, current_user: Optional[any] = None
    ) -> ReservationRead:
        await reservation_dao.auto_reject_expired_reservations(db)
        res = await reservation_dao.get_by_id_for_user(db, res_id, current_user)
        if not res:
            raise PermissionDeniedException("You do not have permission to access this resource.")
        return ReservationRead.model_validate(res)

    async def process_approval_action(
        self,
        db: AsyncSession,
        res_id: str,
        action: str,
        comments: Optional[str] = None,
        current_user: Optional[any] = None,
    ) -> Tuple[ReservationRead, str]:
        """
        Executes sequential approval / rejection action on a pending reservation.
        Enforces:
        - Current approver authorization (Out of order approver is rejected).
        - State transition rules.
        - Next approver promotion or final APPROVED state.
        - Immediate termination on REJECT.
        """
        if not current_user:
            raise PermissionDeniedException("Authentication required to perform approval actions.")

        res = await reservation_dao.get_by_id(db, res_id)
        if not res:
            raise EntityNotFoundException("Reservation", res_id)

        if res.status != ReservationStatus.PENDING:
            raise AppException(f"Reservation is not in pending approval status (Current: {res.status.value if hasattr(res.status, 'value') else res.status}).")

        # Fetch active execution
        execution = await workflow_dao.get_execution_by_entity(db, "RESERVATION", res_id)
        if not execution:
            raise AppException("No active workflow execution found for this reservation.")

        if execution.status != "PENDING":
            raise AppException(f"Workflow execution is already finalized with status '{execution.status}'.")

        # Find current step
        current_step = next(
            (s for s in execution.steps if s.workflow_order == execution.current_step_order), None
        )
        if not current_step:
            raise AppException(f"No pending workflow step found for order {execution.current_step_order}.")

        user_id = str(current_user.id)
        actor_name = getattr(current_user, "full_name", None) or current_user.username

        # Backend Authorization Validation:
        # User must be the designated current approver for this step
        if current_step.user_id != user_id and current_step.user_id != getattr(current_user, "username", ""):
            raise PermissionDeniedException(
                "You are not the current approver for this reservation. Please wait for the previous approval step to be completed."
            )

        now = datetime.now(timezone.utc)
        action_upper = action.strip().upper()

        if action_upper == "REJECT":
            # Immediate rejection: stop workflow
            current_step.status = "REJECTED"
            current_step.action_by = actor_name
            current_step.action_at = now
            current_step.comments = comments or "Reservation rejected by approver"

            execution.status = "REJECTED"
            execution.modified_by = actor_name

            res.status = ReservationStatus.REJECTED
            res.rejection_reason = comments or "Reservation rejected successfully. The approval workflow has been terminated."
            res.rejection_type = "MANUAL"
            res.rejected_at = now
            res.current_approver_id = None
            res.current_approver_name = None
            res.modified_by = actor_name
            res.audit_history = append_audit_entry(
                res.audit_history,
                "workflow_rejection",
                f"Step {current_step.workflow_order} ({actor_name})",
                f"REJECTED: {comments or 'Workflow terminated'}",
                actor_name,
                comments=comments or "Reservation rejected by approver",
                step_order=current_step.workflow_order,
                status="REJECTED"
            )

            await db.commit()
            if res.environment_id:
                await reservation_dao.recalculate_environment_conflicts(db, res.environment_id)

            refreshed = await reservation_dao.get_by_id(db, res_id)

            # Trigger rejection email to owner
            try:
                await email_service.trigger_rejection_notification(
                    db=db,
                    reservation=refreshed or res,
                    rejected_by_name=actor_name,
                    rejection_reason=comments or "Reservation rejected by approver",
                    owner_id_or_name=res.owner_id or res.created_by or res.requested_by
                )
            except Exception as exc:
                logger.error(f"Failed to trigger rejection email for reservation {res_id}: {str(exc)}")

            return (
                ReservationRead.model_validate(refreshed or res),
                "Reservation rejected successfully. The approval workflow has been terminated."
            )

        elif action_upper == "APPROVE":
            # Guard: If reservation has an active conflict, block approval until conflict is resolved
            if res.environment_id:
                conflicts = await reservation_dao.check_conflicts(
                    db,
                    res.environment_id,
                    res.start_date,
                    res.end_date,
                    exclude_reservation_id=res.id,
                    reservation_mode=res.reservation_mode,
                )
                if conflicts:
                    raise AppException("Cannot approve reservation with active schedule conflict. Please resolve the conflict first.")

            current_step.status = "APPROVED"
            current_step.action_by = actor_name
            current_step.action_at = now
            current_step.comments = comments or "Approved"

            # Check next step
            next_step_order = execution.current_step_order + 1
            next_step = next(
                (s for s in execution.steps if s.workflow_order == next_step_order), None
            )

            if next_step:
                # Progress workflow to next approver
                next_step.status = "PENDING"
                execution.current_step_order = next_step_order
                execution.modified_by = actor_name

                # Fetch next approver user info
                next_user = next_step.user or await user_dao.get_by_id(db, next_step.user_id)
                next_name = (next_user.full_name or next_user.username) if next_user else next_step.user_id

                res.current_workflow_order = next_step_order
                res.current_approver_id = next_step.user_id
                res.current_approver_name = next_name
                res.status = ReservationStatus.PENDING
                res.modified_by = actor_name
                res.audit_history = append_audit_entry(
                    res.audit_history,
                    "workflow_approval",
                    f"Step {current_step.workflow_order} ({actor_name})",
                    f"Approved by {actor_name}. Moved to {next_name} (Step {next_step_order})",
                    actor_name,
                    comments=comments or "Approved",
                    step_order=current_step.workflow_order,
                    status="APPROVED"
                )

                await db.commit()
                refreshed = await reservation_dao.get_by_id(db, res_id)

                # Trigger step approval email (Owner update + Next approver request)
                try:
                    await email_service.trigger_step_approval_notifications(
                        db=db,
                        reservation=refreshed or res,
                        current_approver_name=actor_name,
                        next_step_order=next_step_order,
                        next_approver_id=next_step.user_id,
                        owner_id_or_name=res.owner_id or res.created_by or res.requested_by
                    )
                except Exception as exc:
                    logger.error(f"Failed to trigger step approval emails for reservation {res_id}: {str(exc)}")

                return (
                    ReservationRead.model_validate(refreshed or res),
                    "Reservation approved by you. The request has been moved to the next approver."
                )
            else:
                # Final approver approved -> All approved
                execution.status = "APPROVED"
                execution.modified_by = actor_name

                res.status = ReservationStatus.APPROVED
                res.current_approver_id = None
                res.current_approver_name = None
                res.modified_by = actor_name
                res.audit_history = append_audit_entry(
                    res.audit_history,
                    "workflow_approval",
                    f"Step {current_step.workflow_order} ({actor_name})",
                    f"Approved by {actor_name}. All workflow approvers have approved the reservation.",
                    actor_name,
                    comments=comments or "Approved",
                    step_order=current_step.workflow_order,
                    status="APPROVED"
                )

                await db.commit()
                if res.environment_id:
                    await reservation_dao.recalculate_environment_conflicts(db, res.environment_id)

                refreshed = await reservation_dao.get_by_id(db, res_id)

                # Trigger final approval email to owner
                try:
                    await email_service.trigger_final_approval_notification(
                        db=db,
                        reservation=refreshed or res,
                        owner_id_or_name=res.owner_id or res.created_by or res.requested_by
                    )
                except Exception as exc:
                    logger.error(f"Failed to trigger final approval email for reservation {res_id}: {str(exc)}")

                return (
                    ReservationRead.model_validate(refreshed or res),
                    "Reservation approved successfully. All workflow approvers have approved the reservation."
                )

        else:
            raise AppException("Invalid action. Must be 'APPROVE' or 'REJECT'.")

    async def cancel_reservation(
        self, db: AsyncSession, res_id: str, current_user: Optional[any] = None
    ) -> ReservationRead:
        """
        Cancels a reservation.
        Enforces Creator-Only rule: Only the user who raised/created the reservation
        (or System Admin) can cancel it.
        """
        res = await reservation_dao.get_by_id(db, res_id)
        if not res:
            raise EntityNotFoundException("Reservation", res_id)

        is_super = is_user_super_admin(current_user)
        user_id = str(getattr(current_user, "id", "")) if current_user else ""
        username = (getattr(current_user, "username", "") or "").lower().strip()
        full_name = (getattr(current_user, "full_name", "") or "").lower().strip()

        is_creator = False
        if current_user:
            if res.owner_id and str(res.owner_id) == user_id:
                is_creator = True
            elif res.created_by and (res.created_by.lower().strip() in (username, full_name)):
                is_creator = True
            elif res.requested_by and (res.requested_by.lower().strip() in (username, full_name)):
                is_creator = True

        if not is_super and not is_creator:
            raise PermissionDeniedException("Only the user who created this reservation can cancel it.")

        res.status = ReservationStatus.CANCELLED
        actor_name = getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
        res.modified_by = actor_name
        res.current_approver_id = None
        res.current_approver_name = None
        res.audit_history = append_audit_entry(
            res.audit_history,
            "status",
            "Active",
            "CANCELLED by creator",
            actor_name
        )

        # Terminate running workflow execution if any
        execution = await workflow_dao.get_execution_by_entity(db, "RESERVATION", res_id)
        if execution and execution.status == "PENDING":
            execution.status = "CANCELLED"
            execution.modified_by = actor_name

        await db.commit()
        if res.environment_id:
            await reservation_dao.recalculate_environment_conflicts(db, res.environment_id)

        refreshed = await reservation_dao.get_by_id(db, res_id)
        return ReservationRead.model_validate(refreshed or res)

    async def update_reservation(
        self, db: AsyncSession, res_id: str, res_in: ReservationUpdate, current_user: Optional[any] = None
    ) -> ReservationRead:
        res = await reservation_dao.get_by_id_for_user(db, res_id, current_user)
        if not res:
            raise PermissionDeniedException("You do not have permission to access this resource.")

        update_data = res_in.model_dump(exclude_unset=True)
        update_data.pop("created_by", None)
        update_data.pop("owner_id", None)

        target_start = update_data.get("start_date", res.start_date)
        target_end = update_data.get("end_date", res.end_date)
        target_mode = update_data.get("reservation_mode", res.reservation_mode)

        if target_end <= target_start:
            raise AppException("Start date time is greater than the end date time.")

        # Check conflicts with other bookings excluding this one
        conflicts = await reservation_dao.check_conflicts(
            db, res.environment_id, target_start, target_end, reservation_mode=target_mode, exclude_reservation_id=res.id
        )

        effective_auto_enabled = update_data.get("auto_approval_enabled") if "auto_approval_enabled" in update_data else res.auto_approval_enabled
        effective_rule = update_data.get("auto_approval_rule") if "auto_approval_rule" in update_data else res.auto_approval_rule
        effective_priority = update_data.get("priority") if "priority" in update_data else res.priority

        # Auto Approval Conflict Check (Rule C)
        if effective_auto_enabled and conflicts:
            raise AppException("Auto Approval cannot be enabled for a reservation with a conflict. Please resolve the conflict first.")

        actor_name = "Super Admin"
        if current_user:
            actor_name = getattr(current_user, "username", "Super Admin")
            update_data["modified_by"] = actor_name

        # Audit History Tracking
        curr_audit = res.audit_history
        if "auto_approval_enabled" in update_data and update_data["auto_approval_enabled"] != res.auto_approval_enabled:
            curr_audit = append_audit_entry(
                curr_audit,
                "auto_approval_enabled",
                str(res.auto_approval_enabled),
                str(update_data["auto_approval_enabled"]),
                actor_name
            )
        if "auto_approval_rule" in update_data and update_data["auto_approval_rule"] != res.auto_approval_rule:
            curr_audit = append_audit_entry(
                curr_audit,
                "auto_approval_rule",
                str(res.auto_approval_rule),
                str(update_data["auto_approval_rule"]),
                actor_name
            )
        if "priority" in update_data and update_data["priority"] != res.priority:
            curr_audit = append_audit_entry(
                curr_audit,
                "priority",
                str(res.priority),
                str(update_data["priority"]),
                actor_name
            )
        update_data["audit_history"] = curr_audit

        if "status" not in update_data:
            if conflicts:
                update_data["status"] = ReservationStatus.CONFLICT
            elif effective_auto_enabled:
                if isinstance(effective_priority, str):
                    priority_str = effective_priority.upper()
                else:
                    priority_str = getattr(effective_priority, "value", str(effective_priority)).upper()

                if effective_rule == AutoApprovalRule.ALL_REQUESTS or effective_rule == "ALL_REQUESTS":
                    update_data["status"] = ReservationStatus.CONFIRMED
                elif effective_rule == AutoApprovalRule.PRIORITY_REQUESTS or effective_rule == "PRIORITY_REQUESTS":
                    if priority_str in ["HIGH", "CRITICAL", "PRIORITY"]:
                        update_data["status"] = ReservationStatus.CONFIRMED
                    else:
                        update_data["status"] = ReservationStatus.PENDING
                elif effective_rule == AutoApprovalRule.SHORT_REQUESTS or effective_rule == "SHORT_REQUESTS":
                    duration_sec = (target_end - target_start).total_seconds()
                    if duration_sec < 3 * 3600:
                        update_data["status"] = ReservationStatus.CONFIRMED
                    else:
                        update_data["status"] = ReservationStatus.PENDING
                else:
                    update_data["status"] = ReservationStatus.CONFIRMED
            else:
                if res.status == ReservationStatus.CONFLICT:
                    execution = await workflow_dao.get_execution_by_entity(db, "RESERVATION", res_id)
                    if execution:
                        if execution.status == "PENDING":
                            update_data["status"] = ReservationStatus.PENDING
                        elif execution.status == "APPROVED":
                            update_data["status"] = ReservationStatus.APPROVED
                            update_data["current_approver_id"] = None
                            update_data["current_approver_name"] = None
                        elif execution.status == "REJECTED":
                            update_data["status"] = ReservationStatus.REJECTED
                    else:
                        is_all_approved = False
                        try:
                            history = json.loads(res.audit_history) if res.audit_history else []
                            for entry in history:
                                if "all workflow approvers have approved" in str(entry.get("newValue", "")).lower():
                                    is_all_approved = True
                                    break
                        except Exception:
                            pass

                        if is_all_approved:
                            update_data["status"] = ReservationStatus.APPROVED
                            update_data["current_approver_id"] = None
                            update_data["current_approver_name"] = None
                        elif res.workflow_id and res.current_approver_id:
                            update_data["status"] = ReservationStatus.PENDING
                        else:
                            update_data["status"] = ReservationStatus.CONFIRMED

        updated = await reservation_dao.update(db, res, update_data)
        if res.environment_id:
            await reservation_dao.recalculate_environment_conflicts(db, res.environment_id)
        refreshed = await reservation_dao.get_by_id(db, res.id)
        return ReservationRead.model_validate(refreshed or updated)

    async def reject_reservation(
        self, db: AsyncSession, res_id: str, reason: Optional[str] = None, current_user: Optional[any] = None
    ) -> ReservationRead:
        """Manual rejection of a booking by a user with audit tracking and workflow termination."""
        res = await reservation_dao.get_by_id_for_user(db, res_id, current_user)
        if not res:
            raise PermissionDeniedException("You do not have permission to access this resource.")

        now = datetime.now(timezone.utc)
        actor_name = getattr(current_user, "username", "Super Admin") if current_user else "Super Admin"
        update_data = {
            "status": ReservationStatus.REJECTED,
            "rejection_type": "MANUAL",
            "rejection_reason": reason or "Manually rejected by user",
            "rejected_at": now,
            "current_approver_id": None,
            "current_approver_name": None,
            "modified_by": actor_name,
        }

        # Terminate running workflow execution if any
        execution = await workflow_dao.get_execution_by_entity(db, "RESERVATION", res_id)
        if execution and execution.status == "PENDING":
            execution.status = "REJECTED"
            execution.modified_by = actor_name

        updated = await reservation_dao.update(db, res, update_data)
        if res.environment_id:
            await reservation_dao.recalculate_environment_conflicts(db, res.environment_id)

        # Trigger rejection email to owner
        try:
            await email_service.trigger_rejection_notification(
                db=db,
                reservation=updated,
                rejected_by_name=actor_name,
                rejection_reason=reason or "Manually rejected by user",
                owner_id_or_name=res.owner_id or res.created_by or res.requested_by
            )
        except Exception as exc:
            logger.error(f"Failed to trigger rejection email for reservation {res_id}: {str(exc)}")

        return ReservationRead.model_validate(updated)

    async def delete_reservation(
        self, db: AsyncSession, res_id: str, current_user: Optional[any] = None
    ) -> bool:
        """Cancels reservation with creator authorization validation."""
        await self.cancel_reservation(db, res_id, current_user)
        return True

    async def get_reservations_paginated(
        self, db: AsyncSession, page: int = 1, page_size: int = 20, current_user: Optional[any] = None
    ) -> Tuple[List[ReservationRead], int]:
        await reservation_dao.auto_reject_expired_reservations(db)
        items, total = await reservation_dao.paginate_for_user(db, current_user, page, page_size)
        return [ReservationRead.model_validate(r) for r in items], total


reservation_service = ReservationService()

