import uuid
from typing import Any, List, Optional
from fastapi import Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from app.core.logging import logger


class AppException(Exception):
    def __init__(self, message: str, status_code: int = status.HTTP_400_BAD_REQUEST, errors: Optional[List[Any]] = None):
        self.message = message
        self.status_code = status_code
        self.errors = errors or []
        super().__init__(message)


class EntityNotFoundException(AppException):
    def __init__(self, entity_name: str, entity_id: Any):
        super().__init__(
            message=f"{entity_name} with id '{entity_id}' was not found.",
            status_code=status.HTTP_404_NOT_FOUND
        )


class DuplicateEntityException(AppException):
    def __init__(self, message: str):
        super().__init__(
            message=message,
            status_code=status.HTTP_409_CONFLICT
        )


class AuthenticationFailedException(AppException):
    def __init__(self, message: str = "Authentication failed or token invalid."):
        super().__init__(
            message=message,
            status_code=status.HTTP_401_UNAUTHORIZED
        )


class PermissionDeniedException(AppException):
    def __init__(self, message: str = "Permission denied for this operation."):
        super().__init__(
            message=message,
            status_code=status.HTTP_403_FORBIDDEN
        )


async def app_exception_handler(request: Request, exc: AppException) -> JSONResponse:
    trace_id = str(uuid.uuid4())
    logger.error(f"AppException [{trace_id}]: {exc.message} (status: {exc.status_code})")
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "message": exc.message,
            "errors": exc.errors,
            "traceId": trace_id
        }
    )


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    trace_id = str(uuid.uuid4())
    errors = []
    for error in exc.errors():
        loc = " -> ".join([str(x) for x in error.get("loc", [])])
        msg = error.get("msg", "")
        errors.append({"location": loc, "message": msg})

    logger.warning(f"Validation Exception [{trace_id}]: {errors}")
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "success": False,
            "message": "Validation error in request payload.",
            "errors": errors,
            "traceId": trace_id
        }
    )


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    trace_id = str(uuid.uuid4())
    logger.exception(f"Unhandled Server Error [{trace_id}]: {str(exc)}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "success": False,
            "message": "An unexpected internal server error occurred.",
            "errors": [{"detail": str(exc)}],
            "traceId": trace_id
        }
    )
