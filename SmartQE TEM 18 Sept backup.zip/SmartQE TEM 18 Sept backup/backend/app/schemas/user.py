from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class UserRoleInfo(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    description: Optional[str] = None
    role_order: int = 1
    is_system: bool = False
    is_active: bool = True


class UserBUInfo(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    code: str


class UserBase(BaseModel):
    first_name: str = Field(..., description="First Name")
    last_name: str = Field(..., description="Last Name")
    username: str = Field(..., description="Unique Username")
    email: EmailStr = Field(..., description="Unique Valid Email Address")
    business_unit_id: Optional[str] = None
    role_ids: List[str] = Field(default_factory=list, description="List of assigned Role IDs")
    is_active: bool = True
    status: str = "ACTIVE"

    @field_validator("first_name", "last_name", "username")
    @classmethod
    def validate_non_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Field cannot be empty or contain only whitespace.")
        return v.strip()


class UserCreate(UserBase):
    password: Optional[str] = None
    created_by: Optional[str] = "Super Admin"

    @field_validator("role_ids")
    @classmethod
    def validate_roles(cls, v: List[str]) -> List[str]:
        if not v or len(v) == 0:
            raise ValueError("At least one active role must be assigned to the user.")
        return v


class UserUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    role_ids: Optional[List[str]] = None
    business_unit_id: Optional[str] = None
    is_active: Optional[bool] = None
    status: Optional[str] = None
    updated_by: Optional[str] = "Super Admin"

    @field_validator("first_name", "last_name")
    @classmethod
    def validate_names_if_provided(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            if not v.strip():
                raise ValueError("Name cannot be empty or contain only whitespace.")
            return v.strip()
        return v

    @field_validator("role_ids")
    @classmethod
    def validate_roles_if_provided(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        if v is not None and len(v) == 0:
            raise ValueError("At least one active role must be assigned to the user.")
        return v


class UserRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    first_name: str
    last_name: str
    full_name: str
    username: str
    email: str
    business_unit_id: Optional[str] = None
    business_unit: Optional[UserBUInfo] = None
    roles: List[UserRoleInfo] = Field(default_factory=list)
    is_active: bool
    status: str
    created_at: datetime
    created_by: str
    updated_at: datetime
    updated_by: str
