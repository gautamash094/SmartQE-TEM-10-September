from datetime import datetime
from typing import Optional, Self
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from app.models.reservation import (
    ReservationStatus,
    ReservationMode,
    AutoApprovalRule,
    ReservationPriority
)


class ReservationBase(BaseModel):
    environment_id: str = Field(..., min_length=1)
    environment_name: str = Field(..., min_length=1)
    
    # DOMAIN METADATA
    business_unit: str = Field(..., min_length=1, description="Business Unit (Required)")
    project: Optional[str] = Field(default="", description="Project Name (Optional)")
    application: Optional[str] = Field(default="", description="Application Name (Optional)")
    
    purpose: str = Field(..., min_length=1)
    team: str = Field(..., min_length=1)
    requested_by: str = Field(..., min_length=1)
    priority: Optional[ReservationPriority] = ReservationPriority.MEDIUM
    auto_approval_enabled: Optional[bool] = False
    auto_approval_rule: Optional[AutoApprovalRule] = None

    start_date: datetime = Field(..., description="Start Date & Time (YYYY-MM-DD HH:MM:SS)")
    end_date: datetime = Field(..., description="End Date & Time (YYYY-MM-DD HH:MM:SS)")
    status: ReservationStatus = ReservationStatus.CONFIRMED
    reservation_mode: Optional[ReservationMode] = ReservationMode.SHARED

    # Workflow Approval Tracking
    workflow_id: Optional[str] = None
    current_workflow_order: Optional[int] = None
    current_approver_id: Optional[str] = None
    current_approver_name: Optional[str] = None

    # Rejection Audit Tracking
    rejection_reason: Optional[str] = None
    rejected_at: Optional[datetime] = None
    rejection_type: Optional[str] = None
    audit_history: Optional[str] = None

    # Data Ownership & Visibility Controls
    created_by: Optional[str] = None
    owner_id: Optional[str] = None
    assigned_user_id: Optional[str] = None
    is_visible: Optional[bool] = True
    modified_by: Optional[str] = None

    @field_validator("reservation_mode", mode="before")
    @classmethod
    def set_default_reservation_mode(cls, v):
        if not v:
            return ReservationMode.SHARED
        return v

    @field_validator("priority", mode="before")
    @classmethod
    def set_default_priority(cls, v):
        if not v:
            return ReservationPriority.MEDIUM
        return v

    @field_validator("auto_approval_enabled", mode="before")
    @classmethod
    def set_default_auto_approval_enabled(cls, v):
        if v is None:
            return False
        return bool(v)

    @field_validator("is_visible", mode="before")
    @classmethod
    def set_default_is_visible(cls, v):
        if v is None:
            return True
        return bool(v)

    @field_validator("project", "application", mode="before")
    @classmethod
    def set_default_empty_str(cls, v):
        if v is None:
            return ""
        return str(v).strip()

    @field_validator("environment_id", "environment_name", "business_unit", "purpose", "team", "requested_by", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @model_validator(mode="after")
    def validate_dates_and_auto_approval(self) -> Self:
        if self.start_date and self.end_date:
            if self.start_date >= self.end_date:
                raise ValueError("Start date and time must be strictly earlier than end date and time")

        if not self.auto_approval_enabled:
            self.auto_approval_rule = None
        else:
            if not self.auto_approval_rule:
                raise ValueError("An Auto Approval rule must be selected when Auto Approval is enabled")
        return self


class ReservationCreate(ReservationBase):
    pass


class ReservationUpdate(BaseModel):
    business_unit: Optional[str] = None
    project: Optional[str] = None
    application: Optional[str] = None
    purpose: Optional[str] = None
    team: Optional[str] = None
    requested_by: Optional[str] = None
    priority: Optional[ReservationPriority] = None
    auto_approval_enabled: Optional[bool] = None
    auto_approval_rule: Optional[AutoApprovalRule] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    status: Optional[ReservationStatus] = None
    reservation_mode: Optional[ReservationMode] = None
    workflow_id: Optional[str] = None
    current_workflow_order: Optional[int] = None
    current_approver_id: Optional[str] = None
    current_approver_name: Optional[str] = None
    rejection_reason: Optional[str] = None
    rejected_at: Optional[datetime] = None
    rejection_type: Optional[str] = None
    audit_history: Optional[str] = None
    is_visible: Optional[bool] = None
    assigned_user_id: Optional[str] = None
    modified_by: Optional[str] = None

    @field_validator("business_unit", "purpose", "team", "requested_by", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @model_validator(mode="after")
    def validate_date_order_update(self) -> Self:
        if self.start_date is not None and self.end_date is not None:
            if self.start_date >= self.end_date:
                raise ValueError("Start date and time must be strictly earlier than end date and time")
        if self.auto_approval_enabled is False:
            self.auto_approval_rule = None
        elif self.auto_approval_enabled is True and self.auto_approval_rule is None:
            # If auto_approval_enabled is being set to True in update without a rule
            raise ValueError("An Auto Approval rule must be selected when Auto Approval is enabled")
        return self


class ReservationRejectRequest(BaseModel):
    reason: Optional[str] = Field(default=None, description="Optional or required rejection reason")


class ReservationApprovalActionRequest(BaseModel):
    action: str = Field(..., description="'APPROVE' or 'REJECT'")
    comments: Optional[str] = Field(default="", description="Optional remarks or rejection comments")

    @field_validator("action")
    @classmethod
    def validate_action(cls, v: str) -> str:
        upper = v.strip().upper()
        if upper not in ["APPROVE", "REJECT"]:
            raise ValueError("Action must be either 'APPROVE' or 'REJECT'")
        return upper


class ReservationRead(ReservationBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime
