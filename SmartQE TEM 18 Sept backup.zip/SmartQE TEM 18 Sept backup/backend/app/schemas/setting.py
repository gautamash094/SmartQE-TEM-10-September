from datetime import datetime
from typing import Optional, Any, Dict
from pydantic import BaseModel, Field, ConfigDict


class SystemSettingRead(BaseModel):
    id: str
    key: str
    value: Optional[str] = None
    description: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AppConfigRead(BaseModel):
    default_role_id: Optional[str] = None
    default_role_name: Optional[str] = None
    default_business_unit_id: Optional[str] = None
    default_business_unit_name: Optional[str] = None
    extra_settings: Optional[Dict[str, Any]] = Field(default_factory=dict)


class AppConfigUpdate(BaseModel):
    default_role_id: Optional[str] = None
    default_role_name: Optional[str] = None
    default_business_unit_id: Optional[str] = None
    default_business_unit_name: Optional[str] = None
    extra_settings: Optional[Dict[str, Any]] = None
