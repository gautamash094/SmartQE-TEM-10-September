from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.models.environment import EnvironmentStatus, EnvironmentTier


class ComponentTopologyRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    category: str
    version: str
    status: EnvironmentStatus


class ComponentTopologyCreate(BaseModel):
    name: str
    category: str
    version: str
    status: EnvironmentStatus = EnvironmentStatus.HEALTHY


class EnvironmentBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: str
    tier: EnvironmentTier
    team: str
    owner: str
    region: str
    status: Optional[EnvironmentStatus] = EnvironmentStatus.HEALTHY
    is_active: Optional[bool] = Field(default=True, alias="isActive")
    is_visible: Optional[bool] = Field(default=True, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")
    uptime: Optional[float] = Field(default=99.9, ge=0.0, le=100.0)
    cpu_usage: Optional[float] = Field(default=0.0, ge=0.0, le=100.0)
    memory_usage: Optional[float] = Field(default=0.0, ge=0.0, le=100.0)
    storage_usage: Optional[float] = Field(default=0.0, ge=0.0, le=100.0)
    tech_stack: Optional[List[str]] = Field(default_factory=list)

    @field_validator("status", "is_active", "is_visible", "uptime", "cpu_usage", "memory_usage", "storage_usage", "tech_stack", mode="before")
    @classmethod
    def set_default_env_fields(cls, v, info):
        if v is None:
            if info.field_name == "status":
                return EnvironmentStatus.HEALTHY
            elif info.field_name in ("is_active", "is_visible"):
                return True
            elif info.field_name == "uptime":
                return 99.9
            elif info.field_name == "tech_stack":
                return []
            return 0.0
        return v


class EnvironmentCreate(EnvironmentBase):
    topology: Optional[List[ComponentTopologyCreate]] = Field(default_factory=list)


class EnvironmentUpdate(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: Optional[str] = None
    tier: Optional[EnvironmentTier] = None
    team: Optional[str] = None
    owner: Optional[str] = None
    region: Optional[str] = None
    status: Optional[EnvironmentStatus] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")
    is_visible: Optional[bool] = Field(default=None, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")
    uptime: Optional[float] = None
    cpu_usage: Optional[float] = None
    memory_usage: Optional[float] = None
    storage_usage: Optional[float] = None
    tech_stack: Optional[List[str]] = None


class EnvironmentRead(EnvironmentBase):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    id: str
    topology: List[ComponentTopologyRead] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime


class OverviewMetrics(BaseModel):
    totalEnvironments: int
    healthyEnvironments: int
    activeBookings: int
    utilizationRate: float
    openIncidents: int
    downEnvironmentsCount: int
    upcomingReleases: int
    trackedReleasesCount: int
    cpuAverage: float
    memoryAverage: float
    storageAverage: float
