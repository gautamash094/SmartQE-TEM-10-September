from datetime import datetime
from typing import Optional, List, Dict, Any, Self
from pydantic import BaseModel, Field, ConfigDict, field_validator, model_validator
from app.models.topology import TopologyRelationshipType, TopologyNodeType


class TopologyRelationshipBase(BaseModel):
    source_id: str = Field(..., min_length=1)
    source_type: str = Field(..., min_length=1)
    source_name: str = Field(..., min_length=1)
    target_id: str = Field(..., min_length=1)
    target_type: str = Field(..., min_length=1)
    target_name: str = Field(..., min_length=1)
    relationship_type: TopologyRelationshipType = TopologyRelationshipType.DEPENDS_ON
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    port: Optional[str] = None
    protocol: Optional[str] = None
    latency_ms: Optional[float] = None
    is_active: bool = True
    notes: Optional[str] = None

    @field_validator("port", mode="before")
    @classmethod
    def validate_port(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                return None
            try:
                p = int(trimmed)
                if p < 1 or p > 65535:
                    raise ValueError("Port must be between 1 and 65535")
            except ValueError:
                raise ValueError("Port must be a valid integer between 1 and 65535")
            return trimmed
        return v

    @model_validator(mode="after")
    def validate_different_nodes(self) -> Self:
        if self.source_id and self.target_id:
            if self.source_id == self.target_id:
                raise ValueError("Source node and target node cannot be the same component")
        return self


class TopologyRelationshipCreate(TopologyRelationshipBase):
    pass


class TopologyRelationshipUpdate(BaseModel):
    relationship_type: Optional[TopologyRelationshipType] = None
    port: Optional[str] = None
    protocol: Optional[str] = None
    latency_ms: Optional[float] = None
    is_active: Optional[bool] = None
    notes: Optional[str] = None

    @field_validator("port", mode="before")
    @classmethod
    def validate_port(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                return None
            try:
                p = int(trimmed)
                if p < 1 or p > 65535:
                    raise ValueError("Port must be between 1 and 65535")
            except ValueError:
                raise ValueError("Port must be a valid integer between 1 and 65535")
            return trimmed
        return v


class TopologyRelationshipRead(TopologyRelationshipBase):
    id: str
    created_by: str
    updated_by: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class TopologyNode(BaseModel):
    id: str
    name: str
    type: str # ENVIRONMENT, APPLICATION, SERVER, SOFTWARE, DATABASE, etc.
    sub_type: Optional[str] = None
    status: str = "HEALTHY" # HEALTHY, WARNING, CRITICAL, MAINTENANCE, UNKNOWN
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    business_unit: Optional[str] = None
    account_name: Optional[str] = None
    ip_address: Optional[str] = None
    hostname: Optional[str] = None
    cloud_provider: Optional[str] = None
    region: Optional[str] = None
    cost_center: Optional[str] = None
    tier: Optional[str] = None
    owner: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    specs: Optional[str] = None
    active_incidents_count: int = 0
    active_incident_severities: List[str] = Field(default_factory=list)
    properties: Optional[Dict[str, Any]] = None


class TopologyEdge(BaseModel):
    id: str
    source: str
    target: str
    relationship_type: str
    label: Optional[str] = None
    port: Optional[str] = None
    protocol: Optional[str] = None
    latency_ms: Optional[float] = None
    is_custom: bool = False
    is_active: bool = True


class TopologyMetrics(BaseModel):
    total_nodes: int = 0
    total_edges: int = 0
    environments_count: int = 0
    applications_count: int = 0
    servers_count: int = 0
    software_count: int = 0
    databases_count: int = 0
    active_incidents_count: int = 0
    unhealthy_nodes_count: int = 0


class TopologyGraphResponse(BaseModel):
    nodes: List[TopologyNode]
    edges: List[TopologyEdge]
    metrics: Optional[TopologyMetrics] = None
    generated_at: Optional[datetime] = None


class ImpactAnalysisResponse(BaseModel):
    target_node: Optional[TopologyNode] = None
    impact_score: float = 0.0
    impact_level: str = "LOW"
    affected_environments: List[str] = Field(default_factory=list)
    affected_applications: List[str] = Field(default_factory=list)
    affected_servers: List[str] = Field(default_factory=list)
    affected_services: List[str] = Field(default_factory=list)
    affected_databases: List[str] = Field(default_factory=list)
    upstream_nodes: List[TopologyNode] = Field(default_factory=list)
    downstream_nodes: List[TopologyNode] = Field(default_factory=list)
    total_affected_count: int = 0


class TopologyExportRequest(BaseModel):
    scope: str = "ALL"
    selected_environment_ids: Optional[List[str]] = None
    selected_env_ids: Optional[List[str]] = None
    format: str = "XLSX"
    export_format: Optional[str] = None
    graph_data: Optional[Dict[str, Any]] = None


class TopologyGraph(BaseModel):
    nodes: List[TopologyNode]
    edges: List[TopologyRelationshipRead]
    generated_at: datetime


class ImpactNode(BaseModel):
    node: TopologyNode
    depth: int
    relationship_path: List[str]
    impact_level: str # CRITICAL, HIGH, MEDIUM, LOW


class ImpactAnalysisResult(BaseModel):
    root_node_id: str
    root_node_name: str
    affected_nodes: List[ImpactNode]
    total_affected: int
    critical_count: int
    high_count: int
    medium_count: int
    low_count: int
    analyzed_at: datetime
