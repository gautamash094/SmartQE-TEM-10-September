from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.models.workflow import TEMServiceType, SERVICE_DISPLAY_NAMES


class WorkflowApproverItem(BaseModel):
    user_id: str = Field(..., description="User ID")
    workflow_order: int = Field(..., ge=1, description="1-based sequential approval order")


class WorkflowApproverRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    workflow_id: str
    user_id: str
    workflow_order: int
    username: Optional[str] = None
    full_name: Optional[str] = None
    email: Optional[str] = None
    created_at: datetime
    created_by: str


class WorkflowBase(BaseModel):
    bu_id: str = Field(..., min_length=1, description="Business Unit ID")
    environment_id: str = Field(..., min_length=1, description="Environment ID (from Environment Details)")
    application_id: str = Field(..., min_length=1, description="Application ID (from Entity Management)")
    service_code: TEMServiceType = Field(..., description="Target TEM Service")
    approvers: List[WorkflowApproverItem] = Field(..., min_length=1, description="Ordered list of workflow approvers")
    is_active: bool = True
    status: str = "ACTIVE"

    @field_validator("approvers")
    @classmethod
    def validate_approver_list(cls, v: List[WorkflowApproverItem]) -> List[WorkflowApproverItem]:
        if not v or len(v) == 0:
            raise ValueError("At least one approver must be configured for the workflow.")

        user_ids = [item.user_id for item in v]
        if len(user_ids) != len(set(user_ids)):
            raise ValueError("The same user cannot be added multiple times to the same workflow.")

        orders = [item.workflow_order for item in v]
        if len(orders) != len(set(orders)):
            raise ValueError("Duplicate workflow orders are not allowed.")

        # Sort by workflow_order
        sorted_approvers = sorted(v, key=lambda x: x.workflow_order)
        return sorted_approvers


class WorkflowCreate(WorkflowBase):
    created_by: Optional[str] = "Super Admin"


class WorkflowUpdate(BaseModel):
    bu_id: Optional[str] = None
    environment_id: Optional[str] = None
    application_id: Optional[str] = None
    service_code: Optional[TEMServiceType] = None
    approvers: Optional[List[WorkflowApproverItem]] = None
    is_active: Optional[bool] = None
    status: Optional[str] = None
    modified_by: Optional[str] = "Super Admin"

    @field_validator("approvers")
    @classmethod
    def validate_approver_list_if_provided(cls, v: Optional[List[WorkflowApproverItem]]) -> Optional[List[WorkflowApproverItem]]:
        if v is not None:
            if len(v) == 0:
                raise ValueError("At least one approver must be configured for the workflow.")
            user_ids = [item.user_id for item in v]
            if len(user_ids) != len(set(user_ids)):
                raise ValueError("The same user cannot be added multiple times to the same workflow.")
            orders = [item.workflow_order for item in v]
            if len(orders) != len(set(orders)):
                raise ValueError("Duplicate workflow orders are not allowed.")
            return sorted(v, key=lambda x: x.workflow_order)
        return v


class WorkflowRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    bu_id: str
    bu_name: Optional[str] = None
    bu_code: Optional[str] = None
    environment_id: str
    environment_name: Optional[str] = None
    application_id: str
    application_name: Optional[str] = None
    service_code: str
    service_name: str
    approvers: List[WorkflowApproverRead] = Field(default_factory=list)
    approver_count: int = 0
    is_active: bool
    status: str
    created_at: datetime
    created_by: str
    updated_at: datetime
    modified_by: str


class WorkflowExecutionStepRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    execution_id: str
    user_id: str
    username: Optional[str] = None
    full_name: Optional[str] = None
    workflow_order: int
    status: str
    action_by: Optional[str] = None
    action_at: Optional[datetime] = None
    comments: Optional[str] = None


class WorkflowExecutionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    workflow_id: Optional[str] = None
    entity_type: str
    entity_id: str
    current_step_order: int
    total_steps: int
    status: str
    steps: List[WorkflowExecutionStepRead] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime


class WorkflowApprovalAction(BaseModel):
    action: str = Field(..., description="'APPROVE' or 'REJECT'")
    comments: Optional[str] = Field(default="", description="Optional remarks/comments")

    @field_validator("action")
    @classmethod
    def validate_action(cls, v: str) -> str:
        upper = v.strip().upper()
        if upper not in ["APPROVE", "REJECT"]:
            raise ValueError("Action must be either 'APPROVE' or 'REJECT'")
        return upper
