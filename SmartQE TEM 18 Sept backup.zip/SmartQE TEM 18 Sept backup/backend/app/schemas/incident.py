from datetime import datetime
from typing import Optional, Self
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from app.models.incident import IncidentSeverity, IncidentStatus


class IncidentBase(BaseModel):
    title: str = Field(..., min_length=3)
    severity: IncidentSeverity = IncidentSeverity.SEV3
    environment_id: str = Field(..., min_length=1)
    environment_name: str = Field(..., min_length=1)
    assignee: str = Field(..., min_length=1)
    assignee_id: Optional[str] = None
    created_by: Optional[str] = None
    modified_by: Optional[str] = None
    is_visible: Optional[bool] = True
    status: Optional[IncidentStatus] = IncidentStatus.OPEN
    opened_at: datetime
    description: Optional[str] = None

    @field_validator("is_visible", "status", "severity", mode="before")
    @classmethod
    def set_default_incident_fields(cls, v, info):
        if v is None:
            if info.field_name == "is_visible":
                return True
            elif info.field_name == "status":
                return IncidentStatus.OPEN
            elif info.field_name == "severity":
                return IncidentSeverity.SEV3
        return v

    @field_validator("title", "environment_id", "environment_name", "assignee", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v


class IncidentCreate(IncidentBase):
    incident_code: Optional[str] = None  # Generated if not provided


class IncidentUpdate(BaseModel):
    title: Optional[str] = None
    severity: Optional[IncidentSeverity] = None
    assignee: Optional[str] = None
    assignee_id: Optional[str] = None
    status: Optional[IncidentStatus] = None
    resolved_at: Optional[datetime] = None
    description: Optional[str] = None
    is_visible: Optional[bool] = None
    modified_by: Optional[str] = None

    @field_validator("title", "assignee", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v


class IncidentRead(IncidentBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    incident_code: str
    resolved_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
