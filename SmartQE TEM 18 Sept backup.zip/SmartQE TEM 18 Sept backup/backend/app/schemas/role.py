from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict, field_validator


class RoleBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="Unique Role Name")
    description: Optional[str] = Field(default=None, max_length=500, description="Optional Role Description")
    role_order: Optional[int] = Field(default=None, ge=1, description="Order / Hierarchy Priority")
    is_active: bool = Field(default=True, description="Active status")
    status: Optional[str] = Field(default="ACTIVE", description="Status string: ACTIVE or INACTIVE")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Role Name is mandatory and cannot be empty or contain only spaces.")
        return v.strip()


class RoleCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="Unique Role Name")
    description: Optional[str] = Field(default="", max_length=500, description="Optional Role Description")
    role_order: Optional[int] = Field(default=None, ge=1)
    is_active: bool = Field(default=True)
    status: Optional[str] = Field(default="ACTIVE")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Role Name is mandatory and cannot be empty or contain only spaces.")
        return v.strip()


class RoleUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=100)
    description: Optional[str] = Field(default=None, max_length=500)
    role_order: Optional[int] = Field(default=None, ge=1)
    is_active: Optional[bool] = None
    status: Optional[str] = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            if not v.strip():
                raise ValueError("Role Name cannot be empty or contain only spaces.")
            return v.strip()
        return v


class RoleRead(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    role_order: int
    is_system: bool = False
    is_active: bool = True
    status: str = "ACTIVE"
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class RoleReorderItem(BaseModel):
    id: str
    role_order: int = Field(..., ge=1)


class RoleReorderRequest(BaseModel):
    roles: List[RoleReorderItem]
