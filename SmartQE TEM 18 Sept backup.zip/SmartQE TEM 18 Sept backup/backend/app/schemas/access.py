from typing import List, Optional
from pydantic import BaseModel, ConfigDict


class ApplicationScreenRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    key: str
    name: str
    route: str
    parent_key: Optional[str] = None
    category: str
    display_order: int
    is_active: bool


class RoleScreenAccessItem(BaseModel):
    screen_id: str
    screen_key: str
    screen_name: str
    route: str
    parent_key: Optional[str] = None
    category: str
    display_order: int
    has_access: bool


class RoleAccessRead(BaseModel):
    role_id: str
    role_name: str
    is_super_admin: bool
    screens: List[RoleScreenAccessItem]


class RoleAccessUpdate(BaseModel):
    screen_ids: List[str]


class UserPermissionsRead(BaseModel):
    user_id: str
    username: str
    roles: List[str]
    is_super_admin: bool
    allowed_screen_keys: List[str]
    allowed_routes: List[str]
