from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict
from app.models.email_notification import NotificationType, NotificationStatus


class EmailNotificationBase(BaseModel):
    booking_id: str
    notification_type: str
    step_order: Optional[int] = None
    recipient_to: str
    recipient_cc: Optional[str] = None
    subject: str
    body: str
    status: str = NotificationStatus.PENDING.value
    sent_at: Optional[datetime] = None
    error_message: Optional[str] = None
    retry_count: int = 0


class EmailNotificationCreate(EmailNotificationBase):
    pass


class EmailNotificationRead(EmailNotificationBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime


class EmailNotificationRetryResponse(BaseModel):
    success: bool
    message: str
    notification: EmailNotificationRead
