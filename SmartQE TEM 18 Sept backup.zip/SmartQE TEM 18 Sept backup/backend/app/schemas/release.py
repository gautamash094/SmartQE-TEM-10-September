from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.models.release import ReleaseRisk, ReleaseStatus


class ReleaseBase(BaseModel):
    name: str = Field(..., min_length=1)
    version: str = Field(..., min_length=1)
    environment_id: str = Field(..., min_length=1)
    environment_name: str = Field(..., min_length=1)
    lead: str = Field(..., min_length=1)
    change_ref: str = Field(..., min_length=1)
    lead_id: Optional[str] = None
    created_by: Optional[str] = None
    modified_by: Optional[str] = None
    is_visible: Optional[bool] = True
    scheduled_date: datetime = Field(..., description="Scheduled Date & Time (YYYY-MM-DD HH:MM:SS)")
    risk: Optional[ReleaseRisk] = ReleaseRisk.LOW_RISK
    status: Optional[ReleaseStatus] = ReleaseStatus.SCHEDULED

    @field_validator("is_visible", "risk", "status", mode="before")
    @classmethod
    def set_default_release_fields(cls, v, info):
        if v is None:
            if info.field_name == "is_visible":
                return True
            elif info.field_name == "risk":
                return ReleaseRisk.LOW_RISK
            elif info.field_name == "status":
                return ReleaseStatus.SCHEDULED
        return v

    @field_validator("name", "version", "environment_id", "environment_name", "lead", "change_ref", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v


class ReleaseCreate(ReleaseBase):
    pass


class ReleaseUpdate(BaseModel):
    name: Optional[str] = None
    version: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    lead: Optional[str] = None
    lead_id: Optional[str] = None
    change_ref: Optional[str] = None
    scheduled_date: Optional[datetime] = None
    risk: Optional[ReleaseRisk] = None
    status: Optional[ReleaseStatus] = None
    is_visible: Optional[bool] = None
    modified_by: Optional[str] = None

    @field_validator("name", "version", "lead", "change_ref", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v


class ReleaseRead(ReleaseBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime
