from typing import Generic, List, Optional, TypeVar, Any
from pydantic import BaseModel, Field

T = TypeVar("T")


class MetaParams(BaseModel):
    page: int = Field(default=1, description="Current page number")
    pageSize: int = Field(default=20, description="Items per page")
    total: int = Field(default=0, description="Total count of records")


class ErrorDetail(BaseModel):
    location: Optional[str] = None
    message: str


class StandardResponse(BaseModel, Generic[T]):
    success: bool = Field(default=True, description="Success status flag")
    message: str = Field(default="Operation completed successfully", description="Status message")
    data: Optional[T] = Field(default=None, description="Payload data")
    meta: Optional[MetaParams] = Field(default=None, description="Pagination metadata")
    errors: Optional[List[ErrorDetail]] = Field(default=None, description="Error breakdown if any")
    traceId: Optional[str] = Field(default=None, description="Unique trace identifier")


class PaginationQueryParams(BaseModel):
    page: int = Field(default=1, ge=1)
    pageSize: int = Field(default=20, ge=1, le=100)
    search: Optional[str] = None
    sortBy: Optional[str] = None
    sortOrder: Optional[str] = Field(default="asc", pattern="^(asc|desc)$")
