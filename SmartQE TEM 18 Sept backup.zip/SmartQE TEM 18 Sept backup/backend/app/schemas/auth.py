from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field, ConfigDict
from app.schemas.user import UserRoleInfo


class LoginRequest(BaseModel):
    username: str = Field(..., description="Username or email address")
    password: str = Field(..., description="User password")


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user_id: str
    username: str
    email: str
    full_name: str
    roles: List[UserRoleInfo] = Field(default_factory=list)
    is_super_admin: bool = False
    allowed_screens: List[str] = Field(default_factory=list)
    session_id: Optional[str] = None


class SessionStatusResponse(BaseModel):
    is_authenticated: bool
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    username: Optional[str] = None
    email: Optional[str] = None
    full_name: Optional[str] = None
    is_super_admin: bool = False
    roles: List[UserRoleInfo] = Field(default_factory=list)
    allowed_screens: List[str] = Field(default_factory=list)
    idle_timeout_minutes: int
    idle_remaining_seconds: int
    absolute_remaining_seconds: int
    warning_minutes: int
    warning_remaining_seconds: int
    created_at: Optional[datetime] = None
    last_activity_at: Optional[datetime] = None


class SessionRefreshResponse(BaseModel):
    success: bool
    message: str
    idle_remaining_seconds: int
    absolute_remaining_seconds: int
    last_activity_at: datetime



class RefreshTokenRequest(BaseModel):
    refresh_token: str


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(..., min_length=1, description="Current password")
    new_password: str = Field(..., min_length=8, description="New password meeting enterprise policy")


class AdminResetPasswordRequest(BaseModel):
    new_password: str = Field(..., min_length=8, description="New password set by administrator")


class ForgotPasswordRequest(BaseModel):
    username_or_email: str = Field(..., description="Username or registered email address")


class ResetPasswordWithTokenRequest(BaseModel):
    token: str = Field(..., description="Password reset verification token")
    new_password: str = Field(..., min_length=8, description="New password meeting enterprise policy")


class AuthAuditLogRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    user_id: Optional[str] = None
    username: str
    event_type: str
    status: str
    ip_address: Optional[str] = None
    details: Optional[str] = None
    created_at: datetime
