from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict
from app.models.runbook import RunbookStatus


class RunbookBase(BaseModel):
    name: str
    category: str
    estimated_time_minutes: int = 5
    last_executed: Optional[str] = None
    target_environment_id: Optional[str] = None
    status: RunbookStatus = RunbookStatus.IDLE
    steps: List[str] = []


class RunbookCreate(RunbookBase):
    pass


class RunbookExecute(BaseModel):
    target_environment_id: Optional[str] = None


class RunbookRead(RunbookBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime
