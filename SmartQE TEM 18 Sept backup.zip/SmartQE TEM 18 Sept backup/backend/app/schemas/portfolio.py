from datetime import datetime
from typing import Optional, List
import re
from pydantic import BaseModel, ConfigDict, Field, field_validator

URL_PATTERN = re.compile(
    r'^https?://(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}(?:\.[a-zA-Z0-9()]{1,6})?\b(?:[-a-zA-Z0-9()@:%_+.~#?&/=]*)$',
    re.IGNORECASE
)
CODE_PATTERN = re.compile(r'^[A-Za-z0-9_-]{2,30}$')


# --- Business Unit Schemas ---
class BusinessUnitBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: str = Field(..., min_length=1)
    code: str = Field(..., min_length=1)
    lead: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = "ACTIVE"
    is_active: Optional[bool] = Field(default=True, alias="isActive")
    is_visible: Optional[bool] = Field(default=True, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")

    @field_validator("status", "is_active", "is_visible", mode="before")
    @classmethod
    def set_defaults_if_none(cls, v, info):
        if v is None:
            if info.field_name == "status":
                return "ACTIVE"
            return True
        return v

    @field_validator("name", "code", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @field_validator("code")
    @classmethod
    def validate_code_format(cls, v: str) -> str:
        if not CODE_PATTERN.match(v):
            raise ValueError("Code must be 2-30 characters (letters, numbers, dashes, underscores)")
        return v.upper()


class BusinessUnitCreate(BusinessUnitBase):
    pass


class BusinessUnitUpdate(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: Optional[str] = None
    code: Optional[str] = None
    lead: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")
    is_visible: Optional[bool] = Field(default=None, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")

    @field_validator("name", "code", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v


class BusinessUnitRead(BusinessUnitBase):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime


# --- Project Schemas ---
class ProjectBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: str = Field(..., min_length=1)
    code: str = Field(..., min_length=1)
    business_unit: str = Field(..., min_length=1, alias="businessUnit")
    lead: Optional[str] = None
    status: Optional[str] = "ACTIVE"
    is_active: Optional[bool] = Field(default=True, alias="isActive")
    is_visible: Optional[bool] = Field(default=True, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")

    @field_validator("status", "is_active", "is_visible", mode="before")
    @classmethod
    def set_defaults_if_none(cls, v, info):
        if v is None:
            if info.field_name == "status":
                return "ACTIVE"
            return True
        return v

    @field_validator("name", "code", "business_unit", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @field_validator("code")
    @classmethod
    def validate_code_format(cls, v: str) -> str:
        if not CODE_PATTERN.match(v):
            raise ValueError("Code must be 2-30 characters (letters, numbers, dashes, underscores)")
        return v.upper()


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: Optional[str] = None
    code: Optional[str] = None
    business_unit: Optional[str] = Field(None, alias="businessUnit")
    lead: Optional[str] = None
    status: Optional[str] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")
    is_visible: Optional[bool] = Field(default=None, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")

    @field_validator("name", "code", "business_unit", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v


class ProjectRead(ProjectBase):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime


# --- Component Schemas ---
class ComponentBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: str = Field(..., min_length=1)
    code: Optional[str] = Field(default=None)
    business_unit: str = Field(..., min_length=1, alias="businessUnit")
    project_name: Optional[str] = Field(default=None, alias="projectName")
    description: Optional[str] = None
    endpoint_url: Optional[str] = Field(None, alias="endpointUrl")
    status: Optional[str] = "ACTIVE"
    is_active: Optional[bool] = Field(default=True, alias="isActive")
    is_visible: Optional[bool] = Field(default=True, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")

    @field_validator("status", "is_active", "is_visible", mode="before")
    @classmethod
    def set_defaults_if_none(cls, v, info):
        if v is None:
            if info.field_name == "status":
                return "ACTIVE"
            return True
        return v

    @field_validator("name", "business_unit", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @field_validator("endpoint_url", mode="before")
    @classmethod
    def validate_endpoint_url(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                return None
            if not URL_PATTERN.match(trimmed):
                raise ValueError("Endpoint URL must be a valid HTTP or HTTPS URL (e.g. https://api.company.com/v1)")
            return trimmed
        return v

    @field_validator("code", mode="before")
    @classmethod
    def validate_code_format(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                return None
            if not CODE_PATTERN.match(trimmed):
                raise ValueError("Code must be 2-30 characters (letters, numbers, dashes, underscores)")
            return trimmed.upper()
        return v


class ComponentCreate(ComponentBase):
    pass


class ComponentUpdate(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: Optional[str] = None
    code: Optional[str] = None
    business_unit: Optional[str] = Field(None, alias="businessUnit")
    project_name: Optional[str] = Field(None, alias="projectName")
    description: Optional[str] = None
    endpoint_url: Optional[str] = Field(None, alias="endpointUrl")
    status: Optional[str] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")
    is_visible: Optional[bool] = Field(default=None, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")

    @field_validator("name", "business_unit", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @field_validator("endpoint_url", mode="before")
    @classmethod
    def validate_endpoint_url(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                return None
            if not URL_PATTERN.match(trimmed):
                raise ValueError("Endpoint URL must be a valid HTTP or HTTPS URL (e.g. https://api.company.com/v1)")
            return trimmed
        return v

    @field_validator("code", mode="before")
    @classmethod
    def validate_code_format(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                return None
            if not CODE_PATTERN.match(trimmed):
                raise ValueError("Code must be 2-30 characters (letters, numbers, dashes, underscores)")
            return trimmed.upper()
        return v


class ComponentRead(ComponentBase):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    id: str
    code: Optional[str] = None
    project_name: Optional[str] = Field(default=None, alias="projectName")
    created_at: datetime
    updated_at: datetime

    @field_validator("endpoint_url", mode="before")
    @classmethod
    def validate_endpoint_url(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                return None
            if not URL_PATTERN.match(trimmed):
                raise ValueError("Endpoint URL must be a valid HTTP or HTTPS URL (e.g. https://api.company.com/v1)")
            return trimmed
        return v


class ComponentRead(ComponentBase):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime


# --- Application Schemas ---
class ApplicationBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: str = Field(..., min_length=1)
    code: str = Field(..., min_length=1)
    business_unit: str = Field(..., min_length=1, alias="businessUnit")
    project_name: str = Field(..., min_length=1, alias="projectName")
    component_name: Optional[str] = Field(default="", alias="componentName")
    owner: str = Field(..., min_length=1)
    status: Optional[str] = "ACTIVE"
    is_active: Optional[bool] = Field(default=True, alias="isActive")
    is_visible: Optional[bool] = Field(default=True, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")

    @field_validator("component_name", mode="before")
    @classmethod
    def set_default_component_name(cls, v):
        if v is None:
            return ""
        return v

    @field_validator("status", "is_active", "is_visible", mode="before")
    @classmethod
    def set_defaults_if_none(cls, v, info):
        if v is None:
            if info.field_name == "status":
                return "ACTIVE"
            return True
        return v

    @field_validator("name", "code", "business_unit", "project_name", "owner", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @field_validator("code")
    @classmethod
    def validate_code_format(cls, v: str) -> str:
        if not CODE_PATTERN.match(v):
            raise ValueError("Code must be 2-30 characters (letters, numbers, dashes, underscores)")
        return v.upper()


class ApplicationCreate(ApplicationBase):
    pass


class ApplicationUpdate(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: Optional[str] = None
    code: Optional[str] = None
    business_unit: Optional[str] = Field(None, alias="businessUnit")
    project_name: Optional[str] = Field(None, alias="projectName")
    component_name: Optional[str] = Field(None, alias="componentName")
    owner: Optional[str] = None
    status: Optional[str] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")
    is_visible: Optional[bool] = Field(default=None, alias="isVisible")
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    owner_id: Optional[str] = Field(default=None, alias="ownerId")
    modified_by: Optional[str] = Field(default=None, alias="modifiedBy")

    @field_validator("name", "code", "business_unit", "project_name", "component_name", "owner", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v


class ApplicationRead(ApplicationBase):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime


# --- Unified Hierarchy View ---
class PortfolioHierarchy(BaseModel):
    business_units: List[BusinessUnitRead]
    projects: List[ProjectRead]
    components: List[ComponentRead]
    applications: List[ApplicationRead]
