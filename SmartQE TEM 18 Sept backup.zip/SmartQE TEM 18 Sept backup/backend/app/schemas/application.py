from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict


class ApplicationBase(BaseModel):
    name: str
    code: str
    business_unit: str
    owner: str


class ApplicationCreate(ApplicationBase):
    pass


class ApplicationUpdate(BaseModel):
    name: Optional[str] = None
    code: Optional[str] = None
    business_unit: Optional[str] = None
    owner: Optional[str] = None


class ApplicationRead(ApplicationBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime
