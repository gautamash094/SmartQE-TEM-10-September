from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator


class UserGroupMemberRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    user_id: str
    username: Optional[str] = None
    full_name: Optional[str] = None
    email: Optional[str] = None
    business_unit_id: Optional[str] = None
    is_active: Optional[bool] = True
    created_at: datetime
    created_by: str


class UserGroupBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="Unique Group Name")
    description: Optional[str] = Field(default="", max_length=500, description="Group Description")
    bu_id: str = Field(..., min_length=1, description="Business Unit ID")
    user_ids: List[str] = Field(default_factory=list, description="List of member User IDs (must belong to selected BU)")
    is_active: bool = True
    status: str = "ACTIVE"

    @field_validator("name")
    @classmethod
    def validate_name_not_empty(cls, v: str) -> str:
        trimmed = v.strip()
        if not trimmed:
            raise ValueError("Group Name cannot be empty or contain only whitespace.")
        return trimmed

    @field_validator("bu_id")
    @classmethod
    def validate_bu_not_empty(cls, v: str) -> str:
        trimmed = v.strip()
        if not trimmed:
            raise ValueError("Business Unit is mandatory.")
        return trimmed


class UserGroupCreate(UserGroupBase):
    created_by: Optional[str] = "Super Admin"

    @field_validator("user_ids")
    @classmethod
    def validate_members(cls, v: List[str]) -> List[str]:
        if not v or len(v) == 0:
            raise ValueError("At least one user must be selected for the User Group.")
        # Ensure no duplicate users in payload
        if len(v) != len(set(v)):
            raise ValueError("Duplicate users cannot be added to the same group.")
        return v


class UserGroupUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    bu_id: Optional[str] = None
    user_ids: Optional[List[str]] = None
    is_active: Optional[bool] = None
    status: Optional[str] = None
    modified_by: Optional[str] = "Super Admin"

    @field_validator("name")
    @classmethod
    def validate_name_if_provided(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Group Name cannot be empty or contain only whitespace.")
            return trimmed
        return v

    @field_validator("bu_id")
    @classmethod
    def validate_bu_if_provided(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Business Unit cannot be empty.")
            return trimmed
        return v

    @field_validator("user_ids")
    @classmethod
    def validate_members_if_provided(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        if v is not None:
            if len(v) == 0:
                raise ValueError("At least one user must be selected for the User Group.")
            if len(v) != len(set(v)):
                raise ValueError("Duplicate users cannot be added to the same group.")
        return v


class UserGroupRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    description: Optional[str] = None
    bu_id: str
    bu_name: Optional[str] = None
    bu_code: Optional[str] = None
    members: List[UserGroupMemberRead] = Field(default_factory=list)
    member_count: int = 0
    is_active: bool
    status: str
    created_at: datetime
    created_by: str
    updated_at: datetime
    modified_by: str
