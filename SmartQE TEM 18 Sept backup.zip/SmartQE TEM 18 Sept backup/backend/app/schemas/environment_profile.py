from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.models.environment import EnvironmentStatus


class EnvironmentProfileBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: str = Field(..., min_length=1)
    type: str = Field(default="Development")
    description: Optional[str] = ""
    status: Optional[EnvironmentStatus] = EnvironmentStatus.HEALTHY
    is_active: Optional[bool] = Field(default=True, alias="isActive")
    owner_team: Optional[str] = Field(default="", alias="ownerTeam")
    network_zone: Optional[str] = Field(default="", alias="networkZone")
    server_ids: List[str] = Field(default_factory=list, alias="serverIds")
    software_ids: List[str] = Field(default_factory=list, alias="softwareIds")

    @field_validator("status", "is_active", mode="before")
    @classmethod
    def set_defaults_if_none(cls, v, info):
        if v is None:
            if info.field_name == "status":
                return EnvironmentStatus.HEALTHY
            return True
        return v

    @field_validator("name", mode="before")
    @classmethod
    def validate_name_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Environment Profile name cannot be empty or whitespace only")
            return trimmed
        return v


class EnvironmentProfileCreate(EnvironmentProfileBase):
    pass


class EnvironmentProfileUpdate(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    name: Optional[str] = None
    type: Optional[str] = None
    description: Optional[str] = None
    status: Optional[EnvironmentStatus] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")
    owner_team: Optional[str] = Field(default=None, alias="ownerTeam")
    network_zone: Optional[str] = Field(default=None, alias="networkZone")
    server_ids: Optional[List[str]] = Field(default=None, alias="serverIds")
    software_ids: Optional[List[str]] = Field(default=None, alias="softwareIds")

    @field_validator("name", mode="before")
    @classmethod
    def validate_name_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Environment Profile name cannot be empty or whitespace only")
            return trimmed
        return v


class EnvironmentProfileRead(EnvironmentProfileBase):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    id: str
    created_at: datetime
    updated_at: datetime
