from typing import Optional, List, Dict, Any
from datetime import datetime
import re
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.models.asset import AssetType, InfrastructureType, CloudProvider, AssetStatus

IPV4_REGEX = re.compile(r'^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$')


class AssetAuditLogRead(BaseModel):
    id: str
    asset_id: str
    action: str
    changed_by: str
    changed_at: datetime
    field_name: Optional[str] = None
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    notes: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class AssetBase(BaseModel):
    name: str = Field(..., min_length=1)
    asset_id: Optional[str] = None
    asset_type: AssetType = AssetType.SERVER
    infrastructure_type: InfrastructureType = InfrastructureType.CLOUD
    cloud_provider: CloudProvider = CloudProvider.AWS

    business_unit: str = Field(..., min_length=1)
    account_name: str = Field(..., min_length=1)
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    environment_type: Optional[str] = "UAT / Staging"
    application_name: Optional[str] = None

    ip_address: Optional[str] = None
    hostname: Optional[str] = None
    operating_system: Optional[str] = None
    os_version: Optional[str] = None
    runtime_stack: Optional[str] = None
    cpu_cores: Optional[int] = Field(default=4, ge=1)
    ram_gb: Optional[float] = Field(default=16.0, gt=0)
    storage_gb: Optional[float] = Field(default=250.0, gt=0)

    region: Optional[str] = "us-east-1"
    availability_zone: Optional[str] = "us-east-1a"
    datacenter: Optional[str] = None
    rack_unit: Optional[str] = None
    instance_id: Optional[str] = None
    instance_type: Optional[str] = None
    vpc_subnet: Optional[str] = None

    installed_software: Optional[List[Dict[str, Any]]] = []

    status: Optional[AssetStatus] = AssetStatus.ACTIVE
    is_active: Optional[bool] = True
    owner_team: Optional[str] = "Platform QE"
    responsible_person: Optional[str] = "Ops Engineer"
    cost_center: Optional[str] = "CC-ENG-402"
    end_of_life_date: Optional[str] = None
    notes: Optional[str] = None
    tags: Optional[Dict[str, Any]] = {}

    @field_validator("status", "is_active", "owner_team", mode="before")
    @classmethod
    def set_default_asset_fields(cls, v, info):
        if v is None:
            if info.field_name == "status":
                return AssetStatus.ACTIVE
            elif info.field_name == "is_active":
                return True
            elif info.field_name == "owner_team":
                return "Platform QE"
        return v

    @field_validator("name", "business_unit", "account_name", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @field_validator("ip_address", mode="before")
    @classmethod
    def validate_ip(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                return None
            if not IPV4_REGEX.match(trimmed) and not ":" in trimmed:
                raise ValueError("Invalid IP address format")
            return trimmed
        return v


class AssetCreate(AssetBase):
    pass


class AssetUpdate(BaseModel):
    name: Optional[str] = None
    asset_id: Optional[str] = None
    asset_type: Optional[AssetType] = None
    infrastructure_type: Optional[InfrastructureType] = None
    cloud_provider: Optional[CloudProvider] = None

    business_unit: Optional[str] = None
    account_name: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    environment_type: Optional[str] = None
    application_name: Optional[str] = None

    ip_address: Optional[str] = None
    hostname: Optional[str] = None
    operating_system: Optional[str] = None
    os_version: Optional[str] = None
    runtime_stack: Optional[str] = None
    cpu_cores: Optional[int] = Field(default=None, ge=1)
    ram_gb: Optional[float] = Field(default=None, gt=0)
    storage_gb: Optional[float] = Field(default=None, gt=0)

    region: Optional[str] = None
    availability_zone: Optional[str] = None
    datacenter: Optional[str] = None
    rack_unit: Optional[str] = None
    instance_id: Optional[str] = None
    instance_type: Optional[str] = None
    vpc_subnet: Optional[str] = None

    installed_software: Optional[List[Dict[str, Any]]] = None

    status: Optional[AssetStatus] = None
    is_active: Optional[bool] = None
    owner_team: Optional[str] = None
    responsible_person: Optional[str] = None
    cost_center: Optional[str] = None
    end_of_life_date: Optional[str] = None
    notes: Optional[str] = None
    tags: Optional[Dict[str, Any]] = None

    @field_validator("name", "business_unit", "account_name", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v


class AssetStatusUpdate(BaseModel):
    status: AssetStatus
    reason: Optional[str] = None


class AssetRead(AssetBase):
    id: str
    owner_id: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    created_by: str
    updated_by: str
    audit_logs: Optional[List[AssetAuditLogRead]] = []

    model_config = ConfigDict(populate_by_name=True, from_attributes=True)


class InventoryMetrics(BaseModel):
    total_assets: int
    total_environments: int
    total_servers: int
    total_databases: int
    total_cloud_resources: int
    total_network_components: int
    total_software: int
    cloud_assets_count: int
    on_prem_assets_count: int
    hybrid_assets_count: int
    active_assets_count: int
    inactive_assets_count: int
    maintenance_assets_count: int
    retired_assets_count: int
    approaching_eol_count: int
    assets_by_bu: Dict[str, int]
    assets_by_provider: Dict[str, int]
    assets_by_status: Dict[str, int]
    assets_by_type: Dict[str, int]
    assets_by_os: Dict[str, int]
