from typing import Any, Dict, List, Optional
from datetime import datetime
from pydantic import BaseModel, Field


# -------------------------------------------------------------
# TEMPLATE SCHEMAS
# -------------------------------------------------------------
class ProvisioningTemplateBase(BaseModel):
    name: str
    description: Optional[str] = None
    environment_type: str = "QA"
    business_unit: Optional[str] = None
    project_name: Optional[str] = None
    compute_type: str = "VM"
    cpu_cores: int = 4
    ram_gb: float = 16.0
    storage_gb: float = 100.0
    os_disk_gb: float = 50.0
    data_disk_gb: float = 50.0
    software_stack: List[Dict[str, Any]] = Field(default_factory=list)
    network_config: Dict[str, Any] = Field(default_factory=dict)
    env_vars: List[Dict[str, Any]] = Field(default_factory=list)
    secrets_references: List[Dict[str, Any]] = Field(default_factory=list)
    health_check_config: Dict[str, Any] = Field(default_factory=dict)
    estimated_duration_min: int = 15
    is_active: bool = True
    tags: List[str] = Field(default_factory=list)


class ProvisioningTemplateCreate(ProvisioningTemplateBase):
    pass


class ProvisioningTemplateUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    environment_type: Optional[str] = None
    compute_type: Optional[str] = None
    cpu_cores: Optional[int] = None
    ram_gb: Optional[float] = None
    storage_gb: Optional[float] = None
    software_stack: Optional[List[Dict[str, Any]]] = None
    network_config: Optional[Dict[str, Any]] = None
    env_vars: Optional[List[Dict[str, Any]]] = None
    is_active: Optional[bool] = None


class ProvisioningTemplateResponse(ProvisioningTemplateBase):
    id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# -------------------------------------------------------------
# STEP & LOG SCHEMAS
# -------------------------------------------------------------
class ProvisioningStepResponse(BaseModel):
    id: str
    request_id: str
    step_order: int
    step_key: str
    step_name: str
    category: str
    provider_type: str
    status: str
    estimated_duration_sec: int
    actual_duration_sec: float
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None
    retry_count: int
    max_retries: int
    parameters: Dict[str, Any]
    execution_output: Dict[str, Any]
    rollback_supported: bool
    rollback_status: str

    class Config:
        from_attributes = True


class ProvisioningResourceResponse(BaseModel):
    id: str
    request_id: str
    resource_type: str
    resource_name: str
    resource_id: str
    provider: str
    status: str
    configuration: Dict[str, Any]
    allocated_at: datetime
    released_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ProvisioningDependencyResponse(BaseModel):
    id: str
    request_id: str
    name: str
    dependency_type: str
    target_endpoint: Optional[str] = None
    required: bool
    status: str
    health_status: str
    details: Dict[str, Any]

    class Config:
        from_attributes = True


class ProvisioningLogResponse(BaseModel):
    id: str
    request_id: str
    step_id: Optional[str] = None
    step_key: Optional[str] = None
    log_level: str
    message: str
    source: str
    details: Dict[str, Any]
    timestamp: datetime

    class Config:
        from_attributes = True


class ProvisioningApprovalResponse(BaseModel):
    id: str
    request_id: str
    approver_role: str
    approver_user: Optional[str] = None
    status: str
    comments: Optional[str] = None
    auto_approved: bool
    decision_reason: Optional[str] = None
    approved_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ProvisioningAuditResponse(BaseModel):
    id: str
    request_id: str
    action: str
    performed_by: str
    old_status: Optional[str] = None
    new_status: Optional[str] = None
    details: Dict[str, Any]
    ip_address: Optional[str] = None
    timestamp: datetime

    class Config:
        from_attributes = True


# -------------------------------------------------------------
# REQUEST SCHEMAS
# -------------------------------------------------------------
class ProvisioningRequestCreate(BaseModel):
    environment_name: str
    environment_type: str = "QA"
    business_unit: str
    project_name: str
    application_name: str
    component_name: Optional[str] = None
    environment_owner: str
    requested_by: str
    description: Optional[str] = None
    provisioning_mode: str = "ON_DEMAND"
    template_id: Optional[str] = None
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    resource_specs: Dict[str, Any] = Field(default_factory=dict)
    software_stack: List[Dict[str, Any]] = Field(default_factory=list)
    configuration_payload: Dict[str, Any] = Field(default_factory=dict)
    dependency_graph: List[Dict[str, Any]] = Field(default_factory=list)
    custom_tags: Dict[str, Any] = Field(default_factory=dict)
    auto_validate: bool = True


class ProvisioningRequestUpdate(BaseModel):
    environment_name: Optional[str] = None
    description: Optional[str] = None
    environment_owner: Optional[str] = None
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    resource_specs: Optional[Dict[str, Any]] = None
    software_stack: Optional[List[Dict[str, Any]]] = None
    configuration_payload: Optional[Dict[str, Any]] = None
    dependency_graph: Optional[List[Dict[str, Any]]] = None


class ProvisioningRequestListItem(BaseModel):
    id: str
    request_number: str
    environment_name: str
    environment_type: str
    business_unit: str
    project_name: str
    application_name: str
    environment_owner: str
    requested_by: str
    provisioning_mode: str
    status: str
    progress_percentage: float
    current_step_index: int
    total_steps: int
    health_status: str
    failure_reason: Optional[str] = None
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ProvisioningRequestDetailResponse(ProvisioningRequestListItem):
    description: Optional[str] = None
    template_id: Optional[str] = None
    execution_started_at: Optional[datetime] = None
    execution_completed_at: Optional[datetime] = None
    environment_id: Optional[str] = None
    booking_id: Optional[str] = None
    incident_id: Optional[str] = None
    resource_specs: Dict[str, Any]
    software_stack: List[Dict[str, Any]]
    configuration_payload: Dict[str, Any]
    dependency_graph: List[Dict[str, Any]]
    validation_results: Dict[str, Any]
    health_check_results: List[Dict[str, Any]]
    custom_tags: Dict[str, Any]
    steps: List[ProvisioningStepResponse] = Field(default_factory=list)
    resources: List[ProvisioningResourceResponse] = Field(default_factory=list)
    dependencies: List[ProvisioningDependencyResponse] = Field(default_factory=list)
    approvals: List[ProvisioningApprovalResponse] = Field(default_factory=list)
    audits: List[ProvisioningAuditResponse] = Field(default_factory=list)

    class Config:
        from_attributes = True


# -------------------------------------------------------------
# ACTION SCHEMAS
# -------------------------------------------------------------
class ApprovalActionRequest(BaseModel):
    action: str = Field(..., description="'APPROVE' or 'REJECT'")
    comments: Optional[str] = None
    approver_user: Optional[str] = "Environment Manager"


class RetryActionRequest(BaseModel):
    step_id: Optional[str] = None
    mode: str = "RETRY_STEP"  # RETRY_STEP | RESUME


class DashboardKPIsResponse(BaseModel):
    total_requests: int
    in_progress: int
    ready: int
    failed: int
    pending_approval: int
    decommissioning: int
