from datetime import datetime, timedelta, timezone
from typing import List, Optional, Tuple, Callable
from fastapi import Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordBearer, HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.core.security import decode_token
from app.core.exceptions import AuthenticationFailedException, PermissionDeniedException
from app.database.session import get_db
from app.dao.user_dao import user_dao
from app.dao.access_dao import access_dao
from app.dao.session_dao import session_dao
from app.models.user import User, UserRole
from app.models.session import UserSession
from app.services.auth_service import auth_service, make_aware

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)
security_bearer = HTTPBearer(auto_error=False)


def is_user_super_admin(user: Optional[User]) -> bool:
    if not user:
        return False
    username = str(getattr(user, "username", "") or "").lower().strip()
    if username in ("admin", "superadmin", "super admin", "system admin"):
        return True
    roles = getattr(user, "roles", []) or []
    return any(
        getattr(r, "name", "").lower().strip() in ("super admin", "superadmin")
        for r in roles
        if getattr(r, "is_active", True)
    )


def extract_raw_token(
    request: Request,
    oauth_token: Optional[str] = None,
    bearer_creds: Optional[HTTPAuthorizationCredentials] = None
) -> Optional[str]:
    # 1. Check Authorization Bearer / OAuth2 (Explicit client header)
    if bearer_creds and bearer_creds.credentials and bearer_creds.credentials.strip():
        return bearer_creds.credentials.strip()
    if oauth_token and oauth_token.strip():
        return oauth_token.strip()
    auth_hdr = request.headers.get("Authorization", "").strip()
    if auth_hdr.lower().startswith("bearer "):
        return auth_hdr[7:].strip()
    elif auth_hdr:
        return auth_hdr


    # 2. Check X-Session-ID header
    header_session = request.headers.get("X-Session-ID")
    if header_session and header_session.strip():
        return header_session.strip()

    # 3. Check HttpOnly session cookie
    cookie_token = request.cookies.get(settings.SESSION_COOKIE_NAME)
    if cookie_token and cookie_token.strip():
        return cookie_token.strip()

    # 4. Check query param if provided (e.g. for SSE / download)
    query_token = request.query_params.get("session_token")
    if query_token and query_token.strip():
        return query_token.strip()

    return None



async def resolve_session_and_user(
    request: Request,
    db: AsyncSession,
    raw_token: str
) -> Tuple[User, Optional[UserSession]]:
    """
    Validates token or session ID against server-side session store.
    Enforces 20-minute idle timeout and absolute session timeout.
    Respects X-Background-Request header to prevent background polling from extending session.
    """
    now = datetime.now(timezone.utc)
    is_background = (
        request.headers.get("X-Background-Request", "").strip().lower() in ("true", "1") or
        request.headers.get("X-Activity-Track", "").strip().lower() in ("false", "0")
    )

    session_id: Optional[str] = None
    jwt_user_id: Optional[str] = None

    # Determine if raw_token is JWT or direct session ID
    jwt_payload = decode_token(raw_token)
    if jwt_payload:
        session_id = jwt_payload.get("session_id")
        jwt_user_id = jwt_payload.get("sub")
    else:
        session_id = raw_token

    # 1. Validate against UserSession if session_id is available
    if session_id:
        session = await session_dao.get_by_session_id(db, session_id)
        if session:
            # Verify session active status
            if session.status != "ACTIVE":
                raise AuthenticationFailedException("Session has been terminated or logged out. Please log in again.")

            # Check Absolute Session Lifetime (e.g. 8 hours)
            abs_exp = make_aware(session.absolute_expires_at)
            if abs_exp < now:
                session.status = "EXPIRED"
                session.logout_at = now
                await db.commit()
                await auth_service.log_auth_event(
                    db,
                    username=session.user.username if session.user else "unknown",
                    event_type="SESSION_EXPIRED",
                    status="EXPIRED",
                    user_id=session.user_id,
                    details="ABSOLUTE_TIMEOUT",
                )
                raise AuthenticationFailedException("Session expired: Maximum session duration exceeded. Please log in again.")

            # Check Idle Inactivity Timeout (e.g. 20 minutes)
            last_act = make_aware(session.last_activity_at)
            idle_limit = timedelta(minutes=settings.SESSION_IDLE_TIMEOUT_MINUTES)
            if now - last_act > idle_limit:
                session.status = "EXPIRED"
                session.logout_at = now
                await db.commit()
                await auth_service.log_auth_event(
                    db,
                    username=session.user.username if session.user else "unknown",
                    event_type="SESSION_EXPIRED",
                    status="EXPIRED",
                    user_id=session.user_id,
                    details="IDLE_TIMEOUT",
                )
                raise AuthenticationFailedException("Session expired due to 20 minutes of inactivity. Please log in again.")

            # Meaningful user activity -> update last_activity_at ONLY if not background polling
            if not is_background:
                session.last_activity_at = now
                await db.commit()

            user = session.user
            if not user or not user.is_active:
                raise AuthenticationFailedException("User account is inactive or deleted.")

            return user, session

    # 2. Fallback to direct JWT decoding if token was issued without session table entry (e.g. testing / service-to-service)
    if jwt_user_id:
        user = await user_dao.get_user_by_id_with_relations(db, jwt_user_id)
        if not user:
            user = await user_dao.get_by_username(db, jwt_user_id)
        if not user or not user.is_active:
            raise AuthenticationFailedException("User not found or account disabled.")
        return user, None

    raise AuthenticationFailedException("Invalid or expired session identifier.")


async def get_current_user(
    request: Request,
    db: AsyncSession = Depends(get_db),
    oauth_token: Optional[str] = Depends(oauth2_scheme),
    bearer_creds: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer)
) -> User:
    token = extract_raw_token(request, oauth_token, bearer_creds)
    if not token:
        raise AuthenticationFailedException("Not authenticated. Session cookie or Bearer token missing.")

    user, _ = await resolve_session_and_user(request, db, token)
    return user


async def get_current_user_and_session(
    request: Request,
    db: AsyncSession = Depends(get_db),
    oauth_token: Optional[str] = Depends(oauth2_scheme),
    bearer_creds: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer)
) -> Tuple[User, Optional[UserSession], Optional[str]]:
    token = extract_raw_token(request, oauth_token, bearer_creds)
    if not token:
        raise AuthenticationFailedException("Not authenticated. Session cookie or Bearer token missing.")

    user, session = await resolve_session_and_user(request, db, token)
    session_id = session.session_id if session else None
    return user, session, session_id


async def get_current_user_optional(
    request: Request,
    db: AsyncSession = Depends(get_db),
    oauth_token: Optional[str] = Depends(oauth2_scheme),
    bearer_creds: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer)
) -> Optional[User]:
    token = extract_raw_token(request, oauth_token, bearer_creds)
    if not token:
        return None
    user, _ = await resolve_session_and_user(request, db, token)
    return user




def require_screen_access(screen_route: str) -> Callable:
    """
    FastAPI dependency factory to enforce RBAC Screen Access permissions.
    Super Admin permanently maintains 100% unrestricted access to every screen and module.
    For regular users, effective permissions are computed dynamically from all assigned active roles.
    """
    async def dependency(
        current_user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db),
    ) -> User:
        # Super Admin has 100% unrestricted access to every single screen and endpoint
        if is_user_super_admin(current_user):
            return current_user

        roles = current_user.roles or []
        for role in roles:
            if not role.is_active:
                continue
            entries = await access_dao.get_role_access_entries(db, role.id)
            for entry in entries:
                if entry.has_access and entry.screen:
                    # Match exact route or prefix
                    if entry.screen.route == screen_route or entry.screen.route.startswith(screen_route.rstrip('/') + '/') or screen_route.startswith(entry.screen.route.rstrip('/') + '/'):
                        return current_user

        raise PermissionDeniedException("You do not have permission to access this resource.")

    return dependency


class RoleChecker:
    def __init__(self, allowed_roles: List[UserRole]):
        self.allowed_roles = allowed_roles

    def __call__(self, current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in self.allowed_roles:
            raise PermissionDeniedException(
                f"Role '{current_user.role.value}' is not authorized. Allowed roles: {[r.value for r in self.allowed_roles]}"
            )
        return current_user
