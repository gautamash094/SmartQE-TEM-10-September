import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession


async def seed_test_workflow(db_session: AsyncSession, bu_name: str, env_id: str, env_name: str, app_name: str = ""):
    from app.models.workflow import Workflow, WorkflowApprover
    from app.dao.user_dao import user_dao
    from app.dao.role_dao import role_dao
    from app.dao.portfolio_dao import business_unit_dao
    from app.core.security import create_access_token

    bu_list = await business_unit_dao.filter(db_session, {"name": bu_name})
    if bu_list:
        bu = bu_list[0]
    else:
        bu = await business_unit_dao.create(db_session, {
            "name": bu_name,
            "code": bu_name[:4].upper(),
            "description": f"{bu_name} BU",
            "is_active": True,
            "status": "ACTIVE"
        })

    dev_role = await role_dao.get_by_name(db_session, "Developer")
    if not dev_role:
        dev_role = await role_dao.create(db_session, {
            "name": "Developer",
            "description": "Developer",
            "role_order": 2,
            "is_system": False,
            "is_active": True,
            "status": "ACTIVE"
        })

    user = await user_dao.get_by_username(db_session, "approver_tester")
    if not user:
        user = await user_dao.create_user_with_roles(db_session, {
            "first_name": "Approver",
            "last_name": "Tester",
            "username": "approver_tester",
            "email": "approver_tester@test.com",
            "business_unit_id": bu.id,
            "is_active": True,
            "status": "ACTIVE",
        }, [dev_role])

    creator = await user_dao.get_by_username(db_session, "creator_tester")
    if not creator:
        creator = await user_dao.create_user_with_roles(db_session, {
            "first_name": "Creator",
            "last_name": "Tester",
            "username": "creator_tester",
            "email": "creator_tester@test.com",
            "business_unit_id": bu.id,
            "is_active": True,
            "status": "ACTIVE",
        }, [dev_role])

    wf = Workflow(
        bu_id=bu.id,
        environment_id=env_id,
        environment_name=env_name,
        application_id=app_name or "",
        service_code="ENVIRONMENT_RESERVATION",
        service_name="Environment Reservation",
        is_active=True,
        status="ACTIVE",
    )
    db_session.add(wf)
    await db_session.flush()

    appr = WorkflowApprover(
        workflow_id=wf.id,
        user_id=user.id,
        workflow_order=1,
    )
    db_session.add(appr)
    await db_session.commit()
    return wf, create_access_token(subject=creator.id), create_access_token(subject=user.id)


@pytest.mark.asyncio
async def test_create_reservation_with_required_metadata(client: AsyncClient, db_session: AsyncSession):
    # 1. Create environment
    env_res = await client.post("/api/v1/environments", json={
        "name": "Reservation-ENV",
        "tier": "UAT",
        "team": "Banking Team",
        "owner": "Nadia",
        "region": "eu-west-1",
        "status": "HEALTHY"
    })
    env_id = env_res.json()["data"]["id"]

    _, c_token1, _ = await seed_test_workflow(db_session, "Retail Banking", env_id, "Reservation-ENV")
    _, c_token2, _ = await seed_test_workflow(db_session, "Global Payments", env_id, "Reservation-ENV")

    # 2. Create first reservation
    booking_payload = {
        "environment_id": env_id,
        "environment_name": "Reservation-ENV",
        "business_unit": "Retail Banking",
        "project": "Onboarding V3",
        "application": "Aurora Mobile",
        "purpose": "UAT Regression Cycle",
        "team": "QA Team",
        "requested_by": "Tester 1",
        "start_date": "2026-10-10T09:30:00",
        "end_date": "2026-10-14T18:00:00",
        "reservation_mode": "SHARED",
    }

    res = await client.post("/api/v1/reservations", json=booking_payload, headers={"Authorization": f"Bearer {c_token1}"})
    assert res.status_code == 201
    data = res.json()["data"]
    assert data["business_unit"] == "Retail Banking"
    assert data["status"] == "PENDING"

    # 3. Create second conflicting reservation on the same environment and overlapping time window
    conflicting_payload = {
        "environment_id": env_id,
        "environment_name": "Reservation-ENV",
        "business_unit": "Global Payments",
        "project": "Real-Time FX Settlement",
        "application": "Payment Core Gateway",
        "purpose": "Performance Stress Run",
        "team": "Payments Team",
        "requested_by": "Tester 2",
        "start_date": "2026-10-12T10:00:00",
        "end_date": "2026-10-15T12:00:00",
        "reservation_mode": "DISRUPTIVE",
    }

    conf_res = await client.post("/api/v1/reservations", json=conflicting_payload, headers={"Authorization": f"Bearer {c_token2}"})
    assert conf_res.status_code == 201
    conf_data = conf_res.json()["data"]
    assert conf_data["status"] == "CONFLICT"
    assert conf_data["business_unit"] == "Global Payments"


@pytest.mark.asyncio
async def test_create_reservation_against_environment_details_profile(client: AsyncClient, db_session: AsyncSession):
    # 1. Create environment profile via Environment Details API
    prof_res = await client.post("/api/v1/environment-profiles", json={
        "name": "Phoenix-DEV-Cluster",
        "type": "Development",
        "description": "Created from Environment Details module",
        "status": "HEALTHY",
        "ownerTeam": "Core Payments Guild",
        "networkZone": "VPC-DEV-01",
        "serverIds": [],
        "softwareIds": []
    })
    assert prof_res.status_code == 201
    prof_data = prof_res.json()["data"]
    prof_id = prof_data["id"]

    _, c_token, _ = await seed_test_workflow(db_session, "Retail Banking", prof_id, "Phoenix-DEV-Cluster")

    # 2. Create reservation referencing the Environment Profile ID
    booking_payload = {
        "environment_id": prof_id,
        "environment_name": "Phoenix-DEV-Cluster",
        "business_unit": "Retail Banking",
        "project": "Onboarding V3",
        "application": "Aurora Mobile",
        "purpose": "Sprint 24 Integration Testing",
        "team": "DevOps",
        "requested_by": "Alex M.",
        "start_date": "2026-10-20T10:00:00",
        "end_date": "2026-10-22T18:00:00",
    }

    res = await client.post("/api/v1/reservations", json=booking_payload, headers={"Authorization": f"Bearer {c_token}"})
    assert res.status_code == 201
    data = res.json()["data"]
    assert data["environment_id"] == prof_id
    assert data["environment_name"] == "Phoenix-DEV-Cluster"
    assert data["status"] == "PENDING"


@pytest.mark.asyncio
async def test_manual_reject_reservation_workflow(client: AsyncClient, db_session: AsyncSession):
    _, c_token, a_token = await seed_test_workflow(db_session, "Wealth Management", "test-env-reject", "Reject-Target-Env")

    # 1. Create a reservation
    booking_payload = {
        "environment_id": "test-env-reject",
        "environment_name": "Reject-Target-Env",
        "business_unit": "Wealth Management",
        "project": "Portfolio Optimizer",
        "application": "Wealth Portal",
        "purpose": "Manual Reject Test Run",
        "team": "Wealth QE",
        "requested_by": "Senior QA",
        "start_date": "2026-09-01T09:00:00",
        "end_date": "2026-09-05T17:00:00",
    }

    res = await client.post("/api/v1/reservations", json=booking_payload, headers={"Authorization": f"Bearer {c_token}"})
    assert res.status_code == 201
    res_id = res.json()["data"]["id"]

    # 2. Manually reject with reason
    reject_res = await client.post(f"/api/v1/reservations/{res_id}/reject", json={
        "reason": "Environment required for emergency vulnerability remediation"
    }, headers={"Authorization": f"Bearer {a_token}"})
    assert reject_res.status_code == 200
    reject_data = reject_res.json()["data"]
    assert reject_data["status"] == "REJECTED"
    assert reject_data["rejection_type"] == "MANUAL"
    assert reject_data["rejection_reason"] == "Environment required for emergency vulnerability remediation"
    assert reject_data["rejected_at"] is not None


@pytest.mark.asyncio
async def test_auto_reject_expired_reservation(client: AsyncClient, db_session: AsyncSession):
    _, c_token, _ = await seed_test_workflow(db_session, "Digital Lending", "test-env-expired", "Expired-Target-Env")

    # 1. Create a reservation whose end_date is in the past (e.g., 2020)
    past_booking_payload = {
        "environment_id": "test-env-expired",
        "environment_name": "Expired-Target-Env",
        "business_unit": "Digital Lending",
        "project": "Fast Loan",
        "application": "Lending Core",
        "purpose": "Past Integration Run",
        "team": "Lending Dev",
        "requested_by": "Auto Tester",
        "start_date": "2020-01-01T09:00:00",
        "end_date": "2020-01-02T17:00:00",
    }

    res = await client.post("/api/v1/reservations", json=past_booking_payload, headers={"Authorization": f"Bearer {c_token}"})
    assert res.status_code == 201
    data = res.json()["data"]
    # Should be auto rejected upon creation or retrieval
    assert data["status"] == "AUTO_REJECTED"
    assert data["rejection_type"] == "AUTO"
    assert data["rejection_reason"] == "Booking end date and time has passed"
    assert data["rejected_at"] is not None

    # 2. Test the auto-reject sweep endpoint
    sweep_res = await client.post("/api/v1/reservations/auto-reject-expired")
    assert sweep_res.status_code == 200
    assert "auto_rejected_count" in sweep_res.json()["data"]


@pytest.mark.asyncio
async def test_rejected_booking_does_not_cause_conflict(client: AsyncClient, db_session: AsyncSession):
    _, c_token_a, a_token_a = await seed_test_workflow(db_session, "Retail Banking", "test-env-conflict-resolve", "Conflict-Resolution-Env")
    _, c_token_b, _ = await seed_test_workflow(db_session, "Commercial Banking", "test-env-conflict-resolve", "Conflict-Resolution-Env")
    _, c_token_c, _ = await seed_test_workflow(db_session, "Wealth", "test-env-conflict-resolve", "Conflict-Resolution-Env")

    # 1. Create initial active reservation (Slot A: 10:00 to 14:00)
    slot_a = {
        "environment_id": "test-env-conflict-resolve",
        "environment_name": "Conflict-Resolution-Env",
        "business_unit": "Retail Banking",
        "project": "Proj 1",
        "application": "App 1",
        "purpose": "Slot A Booking",
        "team": "Team A",
        "requested_by": "Tester A",
        "start_date": "2026-10-01T10:00:00",
        "end_date": "2026-10-01T14:00:00",
    }
    res_a = await client.post("/api/v1/reservations", json=slot_a, headers={"Authorization": f"Bearer {c_token_a}"})
    assert res_a.status_code == 201
    id_a = res_a.json()["data"]["id"]
    assert res_a.json()["data"]["status"] == "PENDING"

    # 2. Create overlapping reservation (Slot B: 12:00 to 16:00) -> Status CONFLICT
    slot_b = {
        "environment_id": "test-env-conflict-resolve",
        "environment_name": "Conflict-Resolution-Env",
        "business_unit": "Commercial Banking",
        "project": "Proj 2",
        "application": "App 2",
        "purpose": "Slot B Booking",
        "team": "Team B",
        "requested_by": "Tester B",
        "start_date": "2026-10-01T12:00:00",
        "end_date": "2026-10-01T16:00:00",
        "reservation_mode": "DISRUPTIVE",
    }
    res_b = await client.post("/api/v1/reservations", json=slot_b, headers={"Authorization": f"Bearer {c_token_b}"})
    assert res_b.status_code == 201
    id_b = res_b.json()["data"]["id"]
    assert res_b.json()["data"]["status"] == "CONFLICT"

    # 3. Reject Slot A
    reject_a = await client.post(f"/api/v1/reservations/{id_a}/reject", json={"reason": "User cancelled run"}, headers={"Authorization": f"Bearer {a_token_a}"})
    assert reject_a.status_code == 200
    assert reject_a.json()["data"]["status"] == "REJECTED"

    # 4. Check Slot B -> should automatically be recalculated from CONFLICT to PENDING
    get_b = await client.get(f"/api/v1/reservations/{id_b}", headers={"Authorization": f"Bearer {c_token_b}"})
    assert get_b.status_code == 200
    assert get_b.json()["data"]["status"] == "PENDING"

    # 5. Create Slot C for the exact same date and time as rejected Slot A (10:00 to 11:30, no overlap with Slot B)
    slot_c = {
        "environment_id": "test-env-conflict-resolve",
        "environment_name": "Conflict-Resolution-Env",
        "business_unit": "Wealth",
        "project": "Proj 3",
        "application": "App 3",
        "purpose": "Slot C Booking on previously rejected slot",
        "team": "Team C",
        "requested_by": "Tester C",
        "start_date": "2026-10-01T10:00:00",
        "end_date": "2026-10-01T11:30:00",
    }
    res_c = await client.post("/api/v1/reservations", json=slot_c, headers={"Authorization": f"Bearer {c_token_c}"})
    assert res_c.status_code == 201
    assert res_c.json()["data"]["status"] == "PENDING"


