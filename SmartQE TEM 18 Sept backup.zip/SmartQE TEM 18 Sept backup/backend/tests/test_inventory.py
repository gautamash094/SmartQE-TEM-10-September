import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app


@pytest.mark.asyncio
async def test_inventory_metrics(client: AsyncClient):
    response = await client.get("/api/v1/inventory/metrics")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "total_assets" in data["data"]
    assert "cloud_assets_count" in data["data"]
    assert "on_prem_assets_count" in data["data"]
    assert "assets_by_bu" in data["data"]
    assert "assets_by_provider" in data["data"]


@pytest.mark.asyncio
async def test_create_and_filter_inventory_asset(client: AsyncClient):
    payload = {
            "name": "GCP-GKE-Compute-Node99",
            "asset_type": "SERVER",
            "infrastructure_type": "CLOUD",
            "cloud_provider": "GCP",
            "business_unit": "Retail Banking",
            "account_name": "Retail Core",
            "environment_name": "AKASH",
            "environment_type": "QA / Testing",
            "application_name": "Core Banking Ledger",
            "ip_address": "10.240.0.55",
            "hostname": "gke-node-99.gcp.smartqe.io",
            "operating_system": "Container-Optimized OS",
            "cpu_cores": 16,
            "ram_gb": 64.0,
            "storage_gb": 500.0,
            "region": "us-central1",
            "status": "ACTIVE",
            "owner_team": "Core QE Squad",
            "installed_software": [
                {"name": "Kubernetes Kubelet", "version": "v1.29.2", "port": "10250", "status": "ACTIVE"}
            ]
        }

    # Create Asset
    create_res = await client.post("/api/v1/inventory/assets?user=TestRunner", json=payload)
    assert create_res.status_code == 201
    created = create_res.json()["data"]
    asset_id = created["id"]
    assert created["name"] == "GCP-GKE-Compute-Node99"
    assert created["cloud_provider"] == "GCP"
    assert created["asset_id"].startswith("AST-")

    # Get Asset by ID
    get_res = await client.get(f"/api/v1/inventory/assets/{asset_id}")
    assert get_res.status_code == 200
    assert get_res.json()["data"]["name"] == "GCP-GKE-Compute-Node99"
    assert len(get_res.json()["data"]["audit_logs"]) >= 1

    # Filter by Cloud Provider GCP
    filter_res = await client.get("/api/v1/inventory/assets?cloud_provider=GCP")
    assert filter_res.status_code == 200
    gcp_assets = filter_res.json()["data"]
    assert any(a["id"] == asset_id for a in gcp_assets)

    # Update Asset
    update_res = await client.put(f"/api/v1/inventory/assets/{asset_id}?user=TestRunner", json={
        "cpu_cores": 32,
        "notes": "Upgraded CPU cores to 32"
    })
    assert update_res.status_code == 200
    assert update_res.json()["data"]["cpu_cores"] == 32

    # Status Transition (Lifecycle to RETIRED)
    status_res = await client.post(f"/api/v1/inventory/assets/{asset_id}/status?user=TestRunner", json={
        "status": "RETIRED",
        "reason": "Decommissioned after stress test"
    })
    assert status_res.status_code == 200
    assert status_res.json()["data"]["status"] == "RETIRED"

    # Verify Audit Logs
    audit_res = await client.get(f"/api/v1/inventory/audit-logs?asset_id={asset_id}")
    assert audit_res.status_code == 200
    logs = audit_res.json()["data"]
    assert len(logs) >= 3  # CREATE, UPDATE, RETIRE
