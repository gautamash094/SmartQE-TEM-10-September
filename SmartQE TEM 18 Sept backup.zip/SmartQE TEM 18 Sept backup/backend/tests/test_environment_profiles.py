import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_create_and_get_environment_profile_with_initial_status(client: AsyncClient):
    # Test creating profile with default Initial Status HEALTHY
    payload_healthy = {
        "name": "QA Core Profile",
        "type": "QA / Testing",
        "description": "Primary QA environment profile",
        "status": "HEALTHY",
        "ownerTeam": "Core Banking Platform QE",
        "networkZone": "VPC-QA-EAST (10.240.20.0/24)",
        "serverIds": ["srv-101", "srv-102"],
        "softwareIds": ["soft-201"]
    }
    create_res = await client.post("/api/v1/environment-profiles", json=payload_healthy)
    assert create_res.status_code == 201
    data = create_res.json()["data"]
    assert data["name"] == "QA Core Profile"
    assert data["status"] == "HEALTHY"
    assert data["type"] == "QA / Testing"
    assert data["ownerTeam"] == "Core Banking Platform QE"
    profile_id = data["id"]

    # Test GET by ID
    get_res = await client.get(f"/api/v1/environment-profiles/{profile_id}")
    assert get_res.status_code == 200
    get_data = get_res.json()["data"]
    assert get_data["id"] == profile_id
    assert get_data["status"] == "HEALTHY"


@pytest.mark.asyncio
async def test_create_profile_with_other_initial_statuses(client: AsyncClient):
    statuses = ["DEGRADED", "MAINTENANCE", "DOWN"]
    for idx, stat in enumerate(statuses):
        payload = {
            "name": f"Env Profile {stat} {idx}",
            "type": "Development",
            "description": f"Testing initial status {stat}",
            "status": stat,
            "ownerTeam": "DevOps",
            "networkZone": "VPC-DEV-01",
            "serverIds": [],
            "softwareIds": []
        }
        res = await client.post("/api/v1/environment-profiles", json=payload)
        assert res.status_code == 201
        assert res.json()["data"]["status"] == stat


@pytest.mark.asyncio
async def test_update_profile_status(client: AsyncClient):
    create_res = await client.post("/api/v1/environment-profiles", json={
        "name": "Profile To Update",
        "type": "Development",
        "status": "HEALTHY"
    })
    assert create_res.status_code == 201
    profile_id = create_res.json()["data"]["id"]

    # Update status to DEGRADED
    update_res = await client.put(f"/api/v1/environment-profiles/{profile_id}", json={
        "status": "DEGRADED",
        "description": "Updated description"
    })
    assert update_res.status_code == 200
    assert update_res.json()["data"]["status"] == "DEGRADED"

    # Verify update persisted
    get_res = await client.get(f"/api/v1/environment-profiles/{profile_id}")
    assert get_res.status_code == 200
    assert get_res.json()["data"]["status"] == "DEGRADED"


@pytest.mark.asyncio
async def test_delete_profile(client: AsyncClient):
    create_res = await client.post("/api/v1/environment-profiles", json={
        "name": "Profile To Delete",
        "type": "Sandbox",
        "status": "DOWN"
    })
    profile_id = create_res.json()["data"]["id"]

    delete_res = await client.delete(f"/api/v1/environment-profiles/{profile_id}")
    assert delete_res.status_code == 200

    get_res = await client.get(f"/api/v1/environment-profiles/{profile_id}")
    assert get_res.status_code == 404
