import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_create_and_get_environment(client: AsyncClient):
    payload = {
        "name": "Test-ENV-1",
        "tier": "DEV",
        "team": "QA Guild",
        "owner": "Tester",
        "region": "us-east-1",
        "status": "HEALTHY",
        "uptime": 99.9,
        "cpu_usage": 25.0,
        "memory_usage": 40.0,
        "storage_usage": 30.0,
        "tech_stack": ["PYTHON", "FASTAPI"]
    }
    create_res = await client.post("/api/v1/environments", json=payload)
    assert create_res.status_code == 201
    created_data = create_res.json()["data"]
    assert created_data["name"] == "Test-ENV-1"
    env_id = created_data["id"]

    get_res = await client.get(f"/api/v1/environments/{env_id}")
    assert get_res.status_code == 200
    assert get_res.json()["data"]["id"] == env_id
