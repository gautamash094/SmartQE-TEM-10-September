import asyncio
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from datetime import datetime, timezone
from app.database.session import AsyncSessionLocal, fallback_to_sqlite
from app.database.base import Base
from app.dao.provisioning_dao import (
    provisioning_request_dao,
    provisioning_template_dao,
    provisioning_step_dao,
    provisioning_log_dao,
)
from app.services.provisioning.preflight_validator import preflight_validator
from app.services.provisioning.orchestrator import orchestrator
from app.models.provisioning import ProvisioningStatus, StepStatus
from app.utils.seed_data import seed_initial_data


async def run_test():
    print("=== Starting Automated Verification for Environment Provisioning ===")

    # Initialize SQLite database schema
    engine = fallback_to_sqlite()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Seed initial data
    async with AsyncSessionLocal() as db:
        await seed_initial_data(db)

    # 1. Test Templates
    async with AsyncSessionLocal() as db:
        templates = await provisioning_template_dao.get_active_templates(db)
        print(f"[OK] Found {len(templates)} active provisioning templates: {[t.name for t in templates]}")
        assert len(templates) >= 4, "Expected at least 4 default templates"

        qa_template = templates[0]
        print(f"[OK] Selected template: {qa_template.name} ({qa_template.compute_type}, {qa_template.cpu_cores} Cores, {qa_template.ram_gb} GB RAM)")

    # 2. Test Pre-flight Validation
    async with AsyncSessionLocal() as db:
        test_payload = {
            "environment_name": "QA-Payment-Gateway-01",
            "environment_type": "QA",
            "business_unit": "Retail Banking",
            "project_name": "Digital Channels",
            "application_name": "Payment Service",
            "environment_owner": "qa.engineer@smartqe.io",
            "requested_by": "System Test Runner",
            "provisioning_mode": "ON_DEMAND",
            "resource_specs": {
                "compute_type": "VM",
                "cpu_cores": 4,
                "ram_gb": 16.0,
                "storage_gb": 100.0,
                "os_disk_gb": 50.0,
                "data_disk_gb": 50.0,
                "network": {"vlan": "VLAN-100-QA", "subnet": "10.240.16.0/24"},
            },
            "software_stack": qa_template.software_stack,
            "configuration_payload": {
                "env_vars": [{"key": "SPRING_PROFILES_ACTIVE", "value": "qa"}],
                "secrets_references": [{"key": "DB_PASS", "reference": "vault://tem/qa/postgres"}],
            },
            "dependency_graph": [
                {"name": "PostgreSQL DB", "type": "DATABASE", "endpoint": "10.240.16.88:5432", "required": True},
            ],
        }

        validation_report = await preflight_validator.validate(db, test_payload)
        print(f"[OK] Pre-flight validation executed. Overall status: {validation_report['overall_status']}")
        assert not validation_report["has_blocking_errors"], "Pre-flight should not have blocking errors"

        # 3. Create Provisioning Request
        req_number = await provisioning_request_dao.get_next_request_number(db)
        req_data = {
            **test_payload,
            "request_number": req_number,
            "status": ProvisioningStatus.APPROVED,
            "validation_results": validation_report,
            "health_status": "PENDING",
            "progress_percentage": 0.0,
        }
        req_obj = await provisioning_request_dao.create(db, req_data)
        print(f"[OK] Created Provisioning Request: ID={req_obj.id}, Number={req_obj.request_number}, Status={req_obj.status}")

        # Plan Steps
        plan_steps = orchestrator.generate_plan_steps(
            req_obj.id,
            req_obj.resource_specs or {},
            req_obj.software_stack or [],
            req_obj.configuration_payload or {},
        )
        for s in plan_steps:
            await provisioning_step_dao.create(db, s)
        req_obj.total_steps = len(plan_steps)
        await db.commit()
        print(f"[OK] Generated {len(plan_steps)} sequential DAG provisioning execution steps.")

    # 4. Execute Async Orchestration
    request_id = req_obj.id
    print("\n--- Running Asynchronous Provisioning Execution ---")
    await orchestrator.execute_request_async(request_id, start_step_index=1)

    # 5. Verify Final Status & Telemetry
    async with AsyncSessionLocal() as db:
        detailed = await provisioning_request_dao.get_detailed(db, request_id)
        print(f"[OK] Execution Finished. Request Status: {detailed.status}")
        print(f"[OK] Progress Percentage: {detailed.progress_percentage}%")
        print(f"[OK] Health Status: {detailed.health_status}")
        print(f"[OK] Total Allocated Resources: {len(detailed.resources)}")
        print(f"[OK] Total Execution Logs: {len(detailed.logs)}")

        assert detailed.status == ProvisioningStatus.READY, f"Expected READY, got {detailed.status}"
        assert detailed.progress_percentage == 100.0, "Expected 100% progress"
        assert len(detailed.resources) >= 3, "Expected at least 3 allocated resources (Compute, IP, Storage)"

        # Check logs
        for log in detailed.logs[:5]:
            clean_msg = log.message.encode("ascii", errors="replace").decode("ascii")
            print(f"   [{log.log_level}] {clean_msg}")

    # 6. Test Decommissioning
    print("\n--- Testing Decommissioning Workflow ---")
    async with AsyncSessionLocal() as db:
        decom_res = await orchestrator.decommission_request(request_id, "Test Automation")
        print(f"[OK] Decommission Status: {decom_res.status}")
        assert decom_res.status == ProvisioningStatus.DECOMMISSIONED, "Expected DECOMMISSIONED status"

    print("\n=== All Automated Verification Tests Passed Successfully! ===")


if __name__ == "__main__":
    asyncio.run(run_test())
