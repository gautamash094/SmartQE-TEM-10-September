import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.portfolio_dao import business_unit_dao, project_dao, application_dao
from app.dao.environment_profile_dao import environment_profile_dao
from app.dao.user_dao import user_dao
from app.dao.role_dao import role_dao
from app.core.security import create_access_token


@pytest.mark.asyncio
async def test_reservation_without_workflow_is_rejected(client: AsyncClient, db_session: AsyncSession):
    """When no active approval workflow matches BU/Env/App, reservation creation is rejected with error."""
    # 1. Seed BU, Env, Project, App, User
    bu = await business_unit_dao.create(db_session, {
        "name": "Wealth Management",
        "code": "WM",
        "description": "Wealth Management BU",
        "is_active": True,
        "status": "ACTIVE"
    })

    env_profile = await environment_profile_dao.create(db_session, {
        "name": "Direct-Env",
        "type": "Development",
        "description": "Dev environment",
        "is_active": True,
        "status": "HEALTHY"
    })

    proj = await project_dao.create(db_session, {
        "name": "Portfolio Tracker",
        "code": "PTRK",
        "business_unit": bu.name,
        "is_active": True,
        "status": "ACTIVE"
    })

    app = await application_dao.create(db_session, {
        "name": "WealthApp",
        "code": "WAPP",
        "business_unit": bu.name,
        "project_name": proj.name,
        "component_name": "Web",
        "owner": "Wealth Lead",
        "is_active": True,
        "status": "ACTIVE"
    })

    role = await role_dao.get_by_name(db_session, "User")
    if not role:
        role = await role_dao.create(db_session, {"name": "User", "description": "Standard User", "is_active": True})

    user_1 = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Direct",
        "last_name": "User",
        "username": "direct_user",
        "email": "direct_user@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    token = create_access_token(subject=user_1.id)
    headers = {"Authorization": f"Bearer {token}"}

    # 2. Attempt to create reservation without defined workflow
    res = await client.post("/api/v1/reservations", json={
        "environment_id": env_profile.id,
        "environment_name": env_profile.name,
        "business_unit": bu.name,
        "project": proj.name,
        "application": app.name,
        "purpose": "Sprint Dev Testing",
        "team": "Wealth Team",
        "requested_by": user_1.username,
        "start_date": "2026-11-01T09:00:00",
        "end_date": "2026-11-01T17:00:00",
        "reservation_mode": "SHARED"
    }, headers=headers)

    assert res.status_code == 400
    assert "Define the workflow to make any reservation." in (res.json().get("message") or res.json().get("detail", ""))


@pytest.mark.asyncio
async def test_system_admin_cannot_create_reservation(client: AsyncClient, db_session: AsyncSession):
    """System Admin / Admin users are not permitted to create reservations."""
    bu = await business_unit_dao.create(db_session, {
        "name": "Admin BU",
        "code": "ADMN",
        "description": "Admin BU",
        "is_active": True,
        "status": "ACTIVE"
    })

    env_profile = await environment_profile_dao.create(db_session, {
        "name": "Admin-Env",
        "type": "Development",
        "description": "Dev environment",
        "is_active": True,
        "status": "HEALTHY"
    })

    admin_role = await role_dao.get_by_name(db_session, "Super Admin")

    admin_user = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Admin",
        "last_name": "User",
        "username": "admin_restricted",
        "email": "admin_restricted@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [admin_role])

    admin_token = create_access_token(subject=admin_user.id)

    res = await client.post("/api/v1/reservations", json={
        "environment_id": env_profile.id,
        "environment_name": env_profile.name,
        "business_unit": bu.name,
        "purpose": "Admin Booking Attempt",
        "team": "Admin Team",
        "requested_by": admin_user.username,
        "start_date": "2026-11-01T09:00:00",
        "end_date": "2026-11-01T17:00:00",
        "reservation_mode": "SHARED"
    }, headers={"Authorization": f"Bearer {admin_token}"})

    assert res.status_code == 400
    assert "System Admin users are not permitted to create reservations." in (res.json().get("message") or res.json().get("detail", ""))


@pytest.mark.asyncio
async def test_admin_role_user_can_create_reservation(client: AsyncClient, db_session: AsyncSession):
    """A user with a standard 'Admin' role (not Super Admin) can define workflows and create reservations."""
    bu = await business_unit_dao.create(db_session, {
        "name": "Admin Role BU",
        "code": "ARBU",
        "description": "Admin Role BU",
        "is_active": True,
        "status": "ACTIVE"
    })

    env_profile = await environment_profile_dao.create(db_session, {
        "name": "Admin-Role-Env",
        "type": "Development",
        "description": "Dev environment",
        "is_active": True,
        "status": "HEALTHY"
    })

    admin_role = await role_dao.create(db_session, {
        "name": "Admin",
        "description": "Custom Admin Role",
        "role_order": 2,
        "is_system": False,
        "is_active": True,
        "status": "ACTIVE"
    })

    ashish_user = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Ashish",
        "last_name": "Gautam",
        "username": "ashish",
        "email": "ashish@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [admin_role])

    ashish_token = create_access_token(subject=ashish_user.id)

    app = await application_dao.create(db_session, {
        "name": "AdminApp",
        "code": "AAPP",
        "business_unit": bu.name,
        "project_name": "AdminProject",
        "component_name": "API",
        "owner": "Ashish Gautam",
        "is_active": True,
        "status": "ACTIVE"
    })

    # 1. Ashish defines workflow
    wf_res = await client.post("/api/v1/workflows", json={
        "bu_id": bu.id,
        "environment_id": env_profile.id,
        "application_id": app.id,
        "service_code": "ENVIRONMENT_RESERVATION",
        "is_active": True,
        "approvers": [
            {"user_id": ashish_user.id, "workflow_order": 1}
        ]
    }, headers={"Authorization": f"Bearer {ashish_token}"})
    assert wf_res.status_code == 201

    # 2. Ashish creates reservation
    res = await client.post("/api/v1/reservations", json={
        "environment_id": env_profile.id,
        "environment_name": env_profile.name,
        "business_unit": bu.name,
        "purpose": "Ashish Admin Booking",
        "team": "Admin Team",
        "requested_by": "Ashish Gautam",
        "start_date": "2026-11-01T09:00:00",
        "end_date": "2026-11-01T17:00:00",
        "reservation_mode": "SHARED"
    }, headers={"Authorization": f"Bearer {ashish_token}"})

    assert res.status_code == 201
    assert res.json()["data"]["status"] == "PENDING"


@pytest.mark.asyncio
async def test_workflow_sequential_approval_success(client: AsyncClient, db_session: AsyncSession):
    """
    Test complete 3-step sequential approval hierarchy:
    PENDING -> Approver 1 approves -> Approver 2 approves -> Approver 3 approves -> APPROVED.
    """
    # 1. Seed Business Unit, Environment Profile, and Application
    bu = await business_unit_dao.create(db_session, {
        "name": "Payments BU",
        "code": "PAY_WF",
        "description": "Payments domain",
        "is_active": True,
        "status": "ACTIVE"
    })

    env_profile = await environment_profile_dao.create(db_session, {
        "name": "E2E-Workflow-Env",
        "type": "UAT",
        "description": "Payments UAT environment",
        "is_active": True,
        "status": "HEALTHY"
    })

    proj = await project_dao.create(db_session, {
        "name": "FastPay",
        "code": "FPAY",
        "business_unit": bu.name,
        "is_active": True,
        "status": "ACTIVE"
    })

    app = await application_dao.create(db_session, {
        "name": "Checkout Service",
        "code": "CHK",
        "business_unit": bu.name,
        "project_name": proj.name,
        "component_name": "API",
        "owner": "Payment Lead",
        "is_active": True,
        "status": "ACTIVE"
    })

    regular_role = await role_dao.get_by_name(db_session, "User")
    if not regular_role:
        regular_role = await role_dao.create(db_session, {"name": "User", "description": "Standard User", "is_active": True})

    # 2. Seed Users
    creator = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Creator",
        "last_name": "User",
        "username": "creator_user",
        "email": "creator@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [regular_role])

    lead_approver = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Lead",
        "last_name": "Approver",
        "username": "lead_approver",
        "email": "lead@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [regular_role])

    manager_approver = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Manager",
        "last_name": "Approver",
        "username": "manager_approver",
        "email": "manager@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [regular_role])

    director_approver = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Director",
        "last_name": "Approver",
        "username": "director_approver",
        "email": "director@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [regular_role])

    creator_token = create_access_token(subject=creator.id)
    lead_token = create_access_token(subject=lead_approver.id)
    manager_token = create_access_token(subject=manager_approver.id)
    director_token = create_access_token(subject=director_approver.id)

    # 3. Create Approval Workflow
    wf_payload = {
        "bu_id": bu.id,
        "environment_id": env_profile.id,
        "application_id": app.id,
        "service_code": "ENVIRONMENT_RESERVATION",
        "is_active": True,
        "approvers": [
            {"user_id": lead_approver.id, "workflow_order": 1},
            {"user_id": manager_approver.id, "workflow_order": 2},
            {"user_id": director_approver.id, "workflow_order": 3}
        ]
    }
    wf_res = await client.post("/api/v1/workflows", json=wf_payload, headers={"Authorization": f"Bearer {lead_token}"})
    assert wf_res.status_code == 201
    wf_id = wf_res.json()["data"]["id"]

    # 4. Creator submits reservation
    res_payload = {
        "environment_id": env_profile.id,
        "environment_name": env_profile.name,
        "business_unit": bu.name,
        "project": proj.name,
        "application": app.name,
        "purpose": "Load Performance Testing",
        "team": "Payments QE",
        "requested_by": creator.username,
        "start_date": "2026-11-05T10:00:00",
        "end_date": "2026-11-05T18:00:00",
        "reservation_mode": "SHARED"
    }
    res = await client.post("/api/v1/reservations", json=res_payload, headers={"Authorization": f"Bearer {creator_token}"})
    assert res.status_code == 201
    data = res.json()["data"]
    res_id = data["id"]
    assert data["status"] == "PENDING"
    assert data["workflow_id"] == wf_id
    assert data["current_workflow_order"] == 1
    assert data["current_approver_id"] == lead_approver.id

    # 5. Out-of-order approval attempt by Step 2 Approver (manager_approver) MUST FAIL
    invalid_step_res = await client.post(
        f"/api/v1/reservations/{res_id}/approval",
        json={"action": "APPROVE", "comments": "Premature approval"},
        headers={"Authorization": f"Bearer {manager_token}"}
    )
    assert invalid_step_res.status_code == 403
    assert "not the current approver" in invalid_step_res.json()["message"].lower()

    # 6. Step 1 Approver (lead_approver) Approves
    app1_res = await client.post(
        f"/api/v1/reservations/{res_id}/approval",
        json={"action": "APPROVE", "comments": "Lead sign-off complete"},
        headers={"Authorization": f"Bearer {lead_token}"}
    )
    assert app1_res.status_code == 200
    app1_data = app1_res.json()["data"]
    assert app1_data["status"] == "PENDING"
    assert app1_data["current_workflow_order"] == 2
    assert app1_data["current_approver_id"] == manager_approver.id

    # 7. Step 2 Approver (manager_approver) Approves
    app2_res = await client.post(
        f"/api/v1/reservations/{res_id}/approval",
        json={"action": "APPROVE", "comments": "Manager sign-off complete"},
        headers={"Authorization": f"Bearer {manager_token}"}
    )
    assert app2_res.status_code == 200
    app2_data = app2_res.json()["data"]
    assert app2_data["status"] == "PENDING"
    assert app2_data["current_workflow_order"] == 3
    assert app2_data["current_approver_id"] == director_approver.id

    # 8. Step 3 Approver (director_approver) Approves -> Final Step Promotes to APPROVED
    app3_res = await client.post(
        f"/api/v1/reservations/{res_id}/approval",
        json={"action": "APPROVE", "comments": "Director final sign-off"},
        headers={"Authorization": f"Bearer {director_token}"}
    )
    assert app3_res.status_code == 200
    app3_data = app3_res.json()["data"]
    assert app3_data["status"] in ["APPROVED", "CONFIRMED"]
    assert app3_data["current_approver_name"] is None


@pytest.mark.asyncio
async def test_workflow_rejection_terminates_workflow(client: AsyncClient, db_session: AsyncSession):
    """When any approver rejects, reservation immediately transitions to REJECTED."""
    # 1. Seed BU, Env, Project, App, Users
    bu = await business_unit_dao.create(db_session, {
        "name": "Card Services",
        "code": "CARD_WF",
        "description": "Card Services BU",
        "is_active": True,
        "status": "ACTIVE"
    })

    env_profile = await environment_profile_dao.create(db_session, {
        "name": "Reject-Workflow-Env",
        "type": "QA",
        "description": "QA environment",
        "is_active": True,
        "status": "HEALTHY"
    })

    proj = await project_dao.create(db_session, {
        "name": "Card Migration",
        "code": "CMIG",
        "business_unit": bu.name,
        "is_active": True,
        "status": "ACTIVE"
    })

    app = await application_dao.create(db_session, {
        "name": "CardApp",
        "code": "CAPP",
        "business_unit": bu.name,
        "project_name": proj.name,
        "component_name": "API",
        "owner": "Card Lead",
        "is_active": True,
        "status": "ACTIVE"
    })

    role = await role_dao.get_by_name(db_session, "Developer")
    if not role:
        role = await role_dao.create(db_session, {
            "name": "Developer",
            "description": "Developer role",
            "role_order": 2,
            "is_system": False,
            "is_active": True,
            "status": "ACTIVE"
        })

    dev_user = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Developer",
        "last_name": "One",
        "username": "developer1",
        "email": "dev1@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    lead_user = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Lead",
        "last_name": "One",
        "username": "lead1",
        "email": "lead1@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    manager_user = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Manager",
        "last_name": "One",
        "username": "manager1",
        "email": "mgr1@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    dev_token = create_access_token(subject=dev_user.id)
    lead_token = create_access_token(subject=lead_user.id)
    manager_token = create_access_token(subject=manager_user.id)

    # 2. Create 2-step workflow
    wf_res = await client.post("/api/v1/workflows", json={
        "bu_id": bu.id,
        "environment_id": env_profile.id,
        "application_id": app.id,
        "service_code": "ENVIRONMENT_RESERVATION",
        "is_active": True,
        "approvers": [
            {"user_id": lead_user.id, "workflow_order": 1},
            {"user_id": manager_user.id, "workflow_order": 2}
        ]
    }, headers={"Authorization": f"Bearer {lead_token}"})
    assert wf_res.status_code == 201

    # 3. Create reservation
    res = await client.post("/api/v1/reservations", json={
        "environment_id": env_profile.id,
        "environment_name": env_profile.name,
        "business_unit": bu.name,
        "project": proj.name,
        "application": app.name,
        "purpose": "Load Test",
        "team": "Card Team",
        "requested_by": dev_user.username,
        "start_date": "2026-11-10T10:00:00",
        "end_date": "2026-11-10T18:00:00",
        "reservation_mode": "SHARED"
    }, headers={"Authorization": f"Bearer {dev_token}"})
    assert res.status_code == 201
    res_id = res.json()["data"]["id"]

    # 4. Approver 1 Rejects
    rej_res = await client.post(
        f"/api/v1/reservations/{res_id}/approval",
        json={"action": "REJECT", "comments": "Environment under maintenance during requested window"},
        headers={"Authorization": f"Bearer {lead_token}"}
    )
    assert rej_res.status_code == 200
    rej_data = rej_res.json()["data"]
    assert rej_data["status"] == "REJECTED"
    assert rej_data["rejection_reason"] == "Environment under maintenance during requested window"

    # 5. Subsequent approval attempt on rejected reservation is forbidden
    sub_app = await client.post(
        f"/api/v1/reservations/{res_id}/approval",
        json={"action": "APPROVE"},
        headers={"Authorization": f"Bearer {manager_token}"}
    )
    assert sub_app.status_code in [400, 403]


@pytest.mark.asyncio
async def test_creator_cancellation_permission(client: AsyncClient, db_session: AsyncSession):
    """
    Only creator (or Super Admin) can cancel their reservation.
    Unauthorized cancellation attempt returns 403 with exact error message.
    """
    # 1. Seed BU, Env, Project, App, Users
    bu = await business_unit_dao.create(db_session, {
        "name": "Loans BU",
        "code": "LOANS_WF",
        "description": "Loans BU",
        "is_active": True,
        "status": "ACTIVE"
    })

    env_profile = await environment_profile_dao.create(db_session, {
        "name": "Cancel-Test-Env",
        "type": "Development",
        "description": "Dev environment",
        "is_active": True,
        "status": "HEALTHY"
    })

    proj = await project_dao.create(db_session, {
        "name": "Loan Approval",
        "code": "LNAPP",
        "business_unit": bu.name,
        "is_active": True,
        "status": "ACTIVE"
    })

    app = await application_dao.create(db_session, {
        "name": "LoanApp",
        "code": "LAPP",
        "business_unit": bu.name,
        "project_name": proj.name,
        "component_name": "API",
        "owner": "Loan Lead",
        "is_active": True,
        "status": "ACTIVE"
    })

    regular_role = await role_dao.get_by_name(db_session, "User")
    if not regular_role:
        regular_role = await role_dao.create(db_session, {"name": "User", "description": "Standard User", "is_active": True})

    alice = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Alice",
        "last_name": "Creator",
        "username": "alice",
        "email": "alice@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [regular_role])

    bob = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Bob",
        "last_name": "Intruder",
        "username": "bob",
        "email": "bob@company.com",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [regular_role])

    alice_token = create_access_token(subject=alice.id)
    bob_token = create_access_token(subject=bob.id)

    # Seed approval workflow
    wf_res = await client.post("/api/v1/workflows", json={
        "bu_id": bu.id,
        "environment_id": env_profile.id,
        "application_id": app.name,
        "service_code": "ENVIRONMENT_RESERVATION",
        "approvers": [
            {"user_id": alice.id, "workflow_order": 1}
        ],
        "is_active": True
    })
    assert wf_res.status_code == 201

    res = await client.post("/api/v1/reservations", json={
        "environment_id": env_profile.id,
        "environment_name": env_profile.name,
        "business_unit": bu.name,
        "project": proj.name,
        "application": app.name,
        "purpose": "Mortgage Testing",
        "team": "Mortgage Team",
        "requested_by": alice.username,
        "start_date": "2026-11-15T09:00:00",
        "end_date": "2026-11-15T17:00:00"
    }, headers={"Authorization": f"Bearer {alice_token}"})
    assert res.status_code == 201
    res_id = res.json()["data"]["id"]

    # 2. Non-creator 'bob' tries to cancel -> 403 Forbidden
    unauth_cancel = await client.post(
        f"/api/v1/reservations/{res_id}/cancel",
        headers={"Authorization": f"Bearer {bob_token}"}
    )
    assert unauth_cancel.status_code == 403
    assert "Only the user who created this reservation can cancel it" in unauth_cancel.json()["message"]

    # 3. Creator 'alice' cancels -> 200 OK
    auth_cancel = await client.post(
        f"/api/v1/reservations/{res_id}/cancel",
        headers={"Authorization": f"Bearer {alice_token}"}
    )
    assert auth_cancel.status_code == 200
    assert auth_cancel.json()["data"]["status"] == "CANCELLED"

