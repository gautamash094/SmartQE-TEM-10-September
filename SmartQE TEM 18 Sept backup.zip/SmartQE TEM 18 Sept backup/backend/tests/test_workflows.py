import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.portfolio_dao import business_unit_dao, project_dao, application_dao
from app.dao.environment_profile_dao import environment_profile_dao
from app.dao.user_dao import user_dao
from app.dao.role_dao import role_dao
from app.services.workflow_service import workflow_service


@pytest.mark.asyncio
async def test_workflow_definition_and_sequential_approval(client: AsyncClient, db_session: AsyncSession):
    # 1. Seed Business Unit, Environment Profile, and Application
    bu = await business_unit_dao.create(db_session, {
        "name": "Payments BU",
        "code": "PAY",
        "description": "Payments domain",
        "is_active": True,
        "status": "ACTIVE"
    })
    bu_other = await business_unit_dao.create(db_session, {
        "name": "Retail BU",
        "code": "RET",
        "description": "Retail domain",
        "is_active": True,
        "status": "ACTIVE"
    })

    env_profile = await environment_profile_dao.create(db_session, {
        "name": "PAY-DEV-ENV-01",
        "type": "Development",
        "description": "Payments development environment",
        "is_active": True,
        "status": "HEALTHY"
    })

    proj = await project_dao.create(db_session, {
        "name": "Payment Gateway",
        "code": "PGW",
        "business_unit": bu.name,
        "is_active": True,
        "status": "ACTIVE"
    })

    app = await application_dao.create(db_session, {
        "name": "Payment Gateway App",
        "code": "PGW-APP",
        "business_unit": bu.name,
        "project_name": proj.name,
        "component_name": "API Service",
        "owner": "Payment Lead",
        "is_active": True,
        "status": "ACTIVE"
    })

    role = await role_dao.get_by_name(db_session, "Super Admin")

    # 2. Seed Users
    user_1 = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Ashish",
        "last_name": "Sharma",
        "username": "ashish",
        "email": "ashish@testops.io",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    user_2 = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Rahul",
        "last_name": "Verma",
        "username": "rahul",
        "email": "rahul@testops.io",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    user_other_bu = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Other",
        "last_name": "BU",
        "username": "other_user",
        "email": "other@testops.io",
        "business_unit_id": bu_other.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    # 3. Test: Approver not from BU must be rejected
    res_inv_user = await client.post("/api/v1/workflows", json={
        "bu_id": bu.id,
        "environment_id": env_profile.id,
        "application_id": app.id,
        "service_code": "ENVIRONMENT_RESERVATION",
        "approvers": [
            {"user_id": user_1.id, "workflow_order": 1},
            {"user_id": user_other_bu.id, "workflow_order": 2}
        ],
        "is_active": True
    })
    assert res_inv_user.status_code == 400
    assert "Only users tagged to" in res_inv_user.json()["detail"]

    # 4. Test: Create valid workflow definition with sequential approvers: Ashish (Order 1) -> Rahul (Order 2)
    res_create = await client.post("/api/v1/workflows", json={
        "bu_id": bu.id,
        "environment_id": env_profile.id,
        "application_id": app.id,
        "service_code": "ENVIRONMENT_RESERVATION",
        "approvers": [
            {"user_id": user_1.id, "workflow_order": 1},
            {"user_id": user_2.id, "workflow_order": 2}
        ],
        "is_active": True
    })
    assert res_create.status_code == 201
    wf_data = res_create.json()["data"]
    wf_id = wf_data["id"]
    assert wf_data["approver_count"] == 2
    assert wf_data["service_code"] == "ENVIRONMENT_RESERVATION"

    # 5. Test: Duplicate workflow context must fail
    res_dup = await client.post("/api/v1/workflows", json={
        "bu_id": bu.id,
        "environment_id": env_profile.id,
        "application_id": app.id,
        "service_code": "ENVIRONMENT_RESERVATION",
        "approvers": [{"user_id": user_1.id, "workflow_order": 1}],
    })
    assert res_dup.status_code == 400

    # 6. Test: Sequential Approval Execution Success Flow
    # Start execution for a mock booking request
    mock_booking_id = "booking-test-123"
    execution = await workflow_service.start_workflow_execution(
        db_session,
        bu_id=bu.id,
        environment_id=env_profile.id,
        application_id=app.id,
        service_code="ENVIRONMENT_RESERVATION",
        entity_type="RESERVATION",
        entity_id=mock_booking_id,
    )
    assert execution is not None
    assert execution.current_step_order == 1
    assert execution.status == "PENDING"
    assert len(execution.steps) == 2
    assert execution.steps[0].status == "PENDING"
    assert execution.steps[1].status == "WAITING"

    # Approver 2 tries to approve prematurely (when step 1 is pending) - non super-admin would fail
    # Approver 1 approves Step 1
    res_step1 = await workflow_service.process_approval_action(
        db_session,
        execution_id=execution.id,
        user_id=user_1.id,
        action="APPROVE",
        comments="Approved by lead",
        is_super_admin=False
    )
    assert res_step1.current_step_order == 2
    assert res_step1.status == "PENDING"
    assert res_step1.steps[0].status == "APPROVED"
    assert res_step1.steps[1].status == "PENDING"

    # Approver 2 approves Step 2 -> Finalized APPROVED
    res_step2 = await workflow_service.process_approval_action(
        db_session,
        execution_id=execution.id,
        user_id=user_2.id,
        action="APPROVE",
        comments="Final approval granted",
        is_super_admin=False
    )
    assert res_step2.status == "APPROVED"
    assert res_step2.steps[1].status == "APPROVED"

    # 7. Test: Sequential Approval Rejection Flow
    mock_booking_id_2 = "booking-test-456"
    execution_2 = await workflow_service.start_workflow_execution(
        db_session,
        bu_id=bu.id,
        environment_id=env_profile.id,
        application_id=app.id,
        service_code="ENVIRONMENT_RESERVATION",
        entity_type="RESERVATION",
        entity_id=mock_booking_id_2,
    )
    assert execution_2.status == "PENDING"

    # Approver 1 rejects
    res_reject = await workflow_service.process_approval_action(
        db_session,
        execution_id=execution_2.id,
        user_id=user_1.id,
        action="REJECT",
        comments="Schedule conflict detected",
        is_super_admin=False
    )
    assert res_reject.status == "REJECTED"
    assert res_reject.steps[0].status == "REJECTED"
    assert res_reject.steps[1].status == "WAITING"

    # 8. Test: Get execution via REST API
    res_exec_api = await client.get(f"/api/v1/workflows/executions/RESERVATION/{mock_booking_id}")
    assert res_exec_api.status_code == 200
    assert res_exec_api.json()["data"]["status"] == "APPROVED"
