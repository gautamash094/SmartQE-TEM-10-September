import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_super_admin_login_username_and_email(client: AsyncClient):
    """
    Test logging in with default Super Admin credentials via username and email.
    """
    # 1. Login via username
    uname_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "Admin@123"
    })
    assert uname_res.status_code == 200
    uname_data = uname_res.json()["data"]
    assert uname_data["username"] == "admin"
    assert uname_data["is_super_admin"] is True
    assert "access_token" in uname_data
    assert len(uname_data["allowed_screens"]) >= 10

    # 2. Login via email
    email_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin@testops.io",
        "password": "Admin@123"
    })
    assert email_res.status_code == 200
    email_data = email_res.json()["data"]
    assert email_data["email"] == "admin@testops.io"
    assert email_data["is_super_admin"] is True


@pytest.mark.asyncio
async def test_login_invalid_password(client: AsyncClient):
    """
    Verify rejection of wrong credentials.
    """
    wrong_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "WrongPassword!999"
    })
    assert wrong_res.status_code == 401 or wrong_res.status_code == 400


@pytest.mark.asyncio
async def test_forgot_password_and_token_reset_flow(client: AsyncClient):
    """
    Verify forgot password token request and reset password with token.
    """
    # 1. Request token
    forgot_res = await client.post("/api/v1/auth/forgot-password", json={
        "username_or_email": "admin@testops.io"
    })
    assert forgot_res.status_code == 200
    token = forgot_res.json()["data"].get("reset_token")
    assert token is not None

    # 2. Reset password with policy-compliant new password
    reset_res = await client.post("/api/v1/auth/reset-password", json={
        "token": token,
        "new_password": "NewSecurePassword@2026"
    })
    assert reset_res.status_code == 200

    # 3. Log in with new password
    new_login_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "NewSecurePassword@2026"
    })
    assert new_login_res.status_code == 200

    # 4. Invalidate used token -> Must reject on reuse
    reuse_res = await client.post("/api/v1/auth/reset-password", json={
        "token": token,
        "new_password": "AnotherPassword@2026"
    })
    assert reuse_res.status_code == 400

    # Reset back to Admin@123 for test idempotency
    token2_res = await client.post("/api/v1/auth/forgot-password", json={"username_or_email": "admin"})
    token2 = token2_res.json()["data"]["reset_token"]
    await client.post("/api/v1/auth/reset-password", json={"token": token2, "new_password": "Admin@123"})


@pytest.mark.asyncio
async def test_auth_audit_logs(client: AsyncClient):
    """
    Verify auth audit logs tracking.
    """
    # 1. Trigger a login
    await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "Admin@123"
    })

    # 2. Trigger a failed login
    await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "InvalidPassword"
    })

    logs_res = await client.get("/api/v1/auth/audit-logs")
    assert logs_res.status_code == 200
    logs = logs_res.json()["data"]
    assert len(logs) >= 2
    events = [l["event_type"] for l in logs]
    assert "LOGIN" in events
    assert "FAILED_LOGIN" in events
