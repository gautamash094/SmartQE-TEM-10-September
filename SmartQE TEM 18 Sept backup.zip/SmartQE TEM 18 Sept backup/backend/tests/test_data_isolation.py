import pytest
from datetime import datetime, timezone, timedelta
from httpx import AsyncClient
from sqlalchemy import select
from app.models.user import User
from app.models.role import Role
from app.models.reservation import Reservation, ReservationStatus, ReservationMode
from app.models.environment import Environment, EnvironmentStatus, EnvironmentTier
from app.core.security import get_password_hash, create_access_token


@pytest.mark.asyncio
async def test_user_data_isolation_and_rbac(client: AsyncClient, db_session):
    # 1. Fetch existing roles seeded by database initializer
    admin_role_res = await db_session.execute(select(Role).where(Role.name == "Super Admin"))
    admin_role = admin_role_res.scalars().first()

    tester_role = Role(name="QE Tester", description="Tester Access", is_system=False)
    db_session.add(tester_role)
    await db_session.commit()
    await db_session.refresh(tester_role)

    # 2. Fetch existing super admin user
    super_admin_res = await db_session.execute(select(User).where(User.username == "admin"))
    super_admin_user = super_admin_res.scalars().first()

    # 3. Create normal users Alice and Bob
    user_alice = User(
        username="alice",
        email="alice@testops.io",
        first_name="Alice",
        last_name="Smith",
        hashed_password=get_password_hash("Demo$12345"),
        roles=[tester_role]
    )
    user_bob = User(
        username="bob",
        email="bob@testops.io",
        first_name="Bob",
        last_name="Jones",
        hashed_password=get_password_hash("Demo$12345"),
        roles=[tester_role]
    )
    db_session.add_all([user_alice, user_bob])
    await db_session.commit()
    await db_session.refresh(user_alice)
    await db_session.refresh(user_bob)

    # 4. Fetch or create test Environment
    env_res = await db_session.execute(select(Environment))
    env1 = env_res.scalars().first()
    if not env1:
        env1 = Environment(
            name="DEV-ENV-01",
            tier=EnvironmentTier.DEV,
            team="Retail Banking",
            owner="Platform QE",
            region="us-east-1"
        )
        db_session.add(env1)
        await db_session.commit()
        await db_session.refresh(env1)

    # 5. Create Sample Bookings:
    now = datetime.now(timezone.utc)
    res_admin = Reservation(
        environment_id=env1.id,
        environment_name=env1.name,
        business_unit="Core Banking",
        project="Payment Gateway",
        application="Checkout API",
        purpose="Admin System Maintenance",
        team="Platform Admin",
        requested_by="Super Admin",
        created_by="admin",
        owner_id=super_admin_user.id,
        start_date=now + timedelta(days=1),
        end_date=now + timedelta(days=2),
        status=ReservationStatus.CONFIRMED,
        reservation_mode=ReservationMode.SHARED
    )
    res_alice = Reservation(
        environment_id=env1.id,
        environment_name=env1.name,
        business_unit="Digital Banking",
        project="Mobile App",
        application="Mobile Frontend",
        purpose="Regression Testing",
        team="Mobile QE",
        requested_by="Alice Smith",
        created_by="alice",
        owner_id=user_alice.id,
        start_date=now + timedelta(days=3),
        end_date=now + timedelta(days=4),
        status=ReservationStatus.CONFIRMED,
        reservation_mode=ReservationMode.SHARED
    )
    res_bob = Reservation(
        environment_id=env1.id,
        environment_name=env1.name,
        business_unit="Wealth Management",
        project="Trading Platform",
        application="Trading Engine",
        purpose="Load Testing",
        team="Trading QE",
        requested_by="Bob Jones",
        created_by="bob",
        owner_id=user_bob.id,
        start_date=now + timedelta(days=5),
        end_date=now + timedelta(days=6),
        status=ReservationStatus.CONFIRMED,
        reservation_mode=ReservationMode.SHARED
    )
    db_session.add_all([res_admin, res_alice, res_bob])
    await db_session.commit()
    await db_session.refresh(res_admin)
    await db_session.refresh(res_alice)
    await db_session.refresh(res_bob)

    # Generate Access Tokens
    admin_token = create_access_token(super_admin_user.id)
    alice_token = create_access_token(user_alice.id)
    bob_token = create_access_token(user_bob.id)

    # TEST 1: Super Admin should see all bookings
    admin_res = await client.get("/api/v1/reservations", headers={"Authorization": f"Bearer {admin_token}"})
    assert admin_res.status_code == 200
    admin_data = admin_res.json()["data"]
    admin_ids = [b["id"] for b in admin_data]
    assert res_admin.id in admin_ids
    assert res_alice.id in admin_ids
    assert res_bob.id in admin_ids

    # TEST 2: Alice should ONLY see Alice's booking
    alice_res = await client.get("/api/v1/reservations", headers={"Authorization": f"Bearer {alice_token}"})
    assert alice_res.status_code == 200
    alice_data = alice_res.json()["data"]
    alice_ids = [b["id"] for b in alice_data]
    assert res_alice.id in alice_ids
    assert res_admin.id not in alice_ids
    assert res_bob.id not in alice_ids

    # TEST 3: Bob should ONLY see Bob's booking
    bob_res = await client.get("/api/v1/reservations", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_res.status_code == 200
    bob_data = bob_res.json()["data"]
    bob_ids = [b["id"] for b in bob_data]
    assert res_bob.id in bob_ids
    assert res_admin.id not in bob_ids
    assert res_alice.id not in bob_ids

    # TEST 4: Alice attempting to access Bob's booking directly via ID should be blocked (403 Permission Denied)
    alice_direct_bob = await client.get(f"/api/v1/reservations/{res_bob.id}", headers={"Authorization": f"Bearer {alice_token}"})
    assert alice_direct_bob.status_code == 403

    # TEST 5: Alice accessing Alice's own booking should succeed
    alice_direct_own = await client.get(f"/api/v1/reservations/{res_alice.id}", headers={"Authorization": f"Bearer {alice_token}"})
    assert alice_direct_own.status_code == 200
    assert alice_direct_own.json()["data"]["id"] == res_alice.id

    # TEST 6: User creating a booking automatically assigns created_by and owner_id
    from app.models.workflow import Workflow, WorkflowApprover
    wf_alice = Workflow(
        bu_id="Digital Banking",
        environment_id=env1.id,
        environment_name=env1.name,
        application_id="",
        service_code="ENVIRONMENT_RESERVATION",
        service_name="Environment Reservation",
        is_active=True,
        status="ACTIVE"
    )
    db_session.add(wf_alice)
    await db_session.flush()
    db_session.add(WorkflowApprover(workflow_id=wf_alice.id, user_id=user_alice.id, workflow_order=1))
    await db_session.commit()

    new_booking_payload = {
        "environment_id": env1.id,
        "environment_name": env1.name,
        "business_unit": "Digital Banking",
        "project": "Mobile App",
        "application": "Mobile Frontend",
        "purpose": "Alice Personal QE Run",
        "team": "Mobile QE",
        "requested_by": "Alice Smith",
        "start_date": (now + timedelta(days=10)).isoformat(),
        "end_date": (now + timedelta(days=11)).isoformat(),
        "reservation_mode": "SHARED"
    }
    create_res = await client.post("/api/v1/reservations", json=new_booking_payload, headers={"Authorization": f"Bearer {alice_token}"})
    assert create_res.status_code == 201
    created_booking = create_res.json()["data"]
    assert created_booking["created_by"] == "alice"
    assert created_booking["owner_id"] == user_alice.id

    # TEST 7: Bob should not see this newly created Alice booking in Bob's listing
    bob_res_after = await client.get("/api/v1/reservations", headers={"Authorization": f"Bearer {bob_token}"})
    bob_ids_after = [b["id"] for b in bob_res_after.json()["data"]]
    assert created_booking["id"] not in bob_ids_after

    # TEST 8: Super Admin sees the newly created Alice booking
    admin_res_after = await client.get("/api/v1/reservations", headers={"Authorization": f"Bearer {admin_token}"})
    admin_ids_after = [b["id"] for b in admin_res_after.json()["data"]]
    assert created_booking["id"] in admin_ids_after

    # TEST 9: Portfolio Isolation: Business Units, Projects, Applications
    # Alice creates BU
    bu_res = await client.post("/api/v1/portfolio/business-units", json={
        "name": "Alice Exclusive BU",
        "code": "AEBU",
        "lead": "Alice Smith",
        "description": "Alice BU description"
    }, headers={"Authorization": f"Bearer {alice_token}"})
    assert bu_res.status_code == 201
    alice_bu_id = bu_res.json()["data"]["id"]

    # Bob's BU list should NOT contain Alice's BU
    bob_bus = await client.get("/api/v1/portfolio/business-units", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_bus.status_code == 200
    bob_bu_ids = [b["id"] for b in bob_bus.json()["data"]]
    assert alice_bu_id not in bob_bu_ids

    # Super Admin sees Alice's BU
    admin_bus = await client.get("/api/v1/portfolio/business-units", headers={"Authorization": f"Bearer {admin_token}"})
    assert admin_bus.status_code == 200
    admin_bu_ids = [b["id"] for b in admin_bus.json()["data"]]
    assert alice_bu_id in admin_bu_ids

    # Bob cannot delete or toggle Alice's BU
    bob_del_bu = await client.delete(f"/api/v1/portfolio/business-units/{alice_bu_id}", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_del_bu.status_code == 403

    # TEST 10: Environment Profile Isolation
    # Alice creates an Environment Profile
    prof_res = await client.post("/api/v1/environment-profiles", json={
        "name": "Alice QA Profile",
        "type": "QA / Testing",
        "description": "Isolated profile for Alice",
        "status": "HEALTHY",
        "is_active": True,
        "owner_team": "Alice Team",
        "network_zone": "INTERNAL"
    }, headers={"Authorization": f"Bearer {alice_token}"})
    assert prof_res.status_code == 201
    alice_prof_id = prof_res.json()["data"]["id"]

    # Bob should not see Alice's profile
    bob_profs = await client.get("/api/v1/environment-profiles", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_profs.status_code == 200
    bob_prof_ids = [p["id"] for p in bob_profs.json()["data"]]
    assert alice_prof_id not in bob_prof_ids

    # Bob cannot modify Alice's profile
    bob_mod_prof = await client.put(f"/api/v1/environment-profiles/{alice_prof_id}", json={
        "name": "Hacked Profile",
        "description": "Unauthorized change"
    }, headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_mod_prof.status_code == 403

    # Super Admin sees Alice's profile
    admin_profs = await client.get("/api/v1/environment-profiles", headers={"Authorization": f"Bearer {admin_token}"})
    assert admin_profs.status_code == 200
    admin_prof_ids = [p["id"] for p in admin_profs.json()["data"]]
    assert alice_prof_id in admin_prof_ids

    # TEST 11: Inventory / Asset Isolation
    # Alice creates an Asset
    asset_res = await client.post("/api/v1/inventory/assets", json={
        "name": "Alice-DB-Server",
        "asset_type": "SERVER",
        "business_unit": "Digital Banking",
        "account_name": "Alice-AWS-Account",
        "ip_address": "10.0.0.50",
        "environment_id": env1.id,
        "status": "ACTIVE"
    }, headers={"Authorization": f"Bearer {alice_token}"})
    assert asset_res.status_code == 201
    alice_asset = asset_res.json()["data"]
    assert alice_asset["created_by"] == "alice"
    assert alice_asset["owner_id"] == user_alice.id
    alice_asset_id = alice_asset["id"]

    # Bob should not see Alice's asset
    bob_assets = await client.get("/api/v1/inventory/assets", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_assets.status_code == 200
    bob_asset_ids = [a["id"] for a in bob_assets.json()["data"]]
    assert alice_asset_id not in bob_asset_ids

    # Bob cannot fetch Alice's asset directly
    bob_asset_direct = await client.get(f"/api/v1/inventory/assets/{alice_asset_id}", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_asset_direct.status_code in [403, 404]

    # Super Admin sees Alice's asset
    admin_assets = await client.get("/api/v1/inventory/assets", headers={"Authorization": f"Bearer {admin_token}"})
    assert admin_assets.status_code == 200
    admin_asset_ids = [a["id"] for a in admin_assets.json()["data"]]
    assert alice_asset_id in admin_asset_ids

    # TEST 12: Incident Isolation & Aggregated Metrics
    # Alice creates an Incident
    inc_res = await client.post("/api/v1/incidents", json={
        "title": "Alice DB Latency Spike",
        "description": "High latency observed on DB",
        "severity": "SEV1",
        "status": "OPEN",
        "environment_id": env1.id,
        "environment_name": env1.name,
        "assignee": "Alice Smith",
        "opened_at": now.isoformat()
    }, headers={"Authorization": f"Bearer {alice_token}"})
    assert inc_res.status_code == 201
    alice_inc = inc_res.json()["data"]
    alice_inc_id = alice_inc["id"]
    assert alice_inc["created_by"] == "alice"

    # Bob should not see Alice's incident in list
    bob_incs = await client.get("/api/v1/incidents", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_incs.status_code == 200
    bob_inc_ids = [i["id"] for i in bob_incs.json()["data"]]
    assert alice_inc_id not in bob_inc_ids

    # Bob's severity summary should show 0 SEV1 incidents
    bob_summary = await client.get("/api/v1/incidents/severity-summary", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_summary.status_code == 200
    assert bob_summary.json()["data"].get("SEV1", 0) == 0

    # Alice's severity summary should show 1 SEV1 incident
    alice_summary = await client.get("/api/v1/incidents/severity-summary", headers={"Authorization": f"Bearer {alice_token}"})
    assert alice_summary.status_code == 200
    assert alice_summary.json()["data"].get("SEV1", 0) >= 1

    # Super Admin sees Alice's incident in list and summary
    admin_incs = await client.get("/api/v1/incidents", headers={"Authorization": f"Bearer {admin_token}"})
    assert admin_incs.status_code == 200
    admin_inc_ids = [i["id"] for i in admin_incs.json()["data"]]
    assert alice_inc_id in admin_inc_ids

    # TEST 13: Releases & Kanban Isolation
    # Alice creates a Release
    rel_res = await client.post("/api/v1/releases", json={
        "name": "Alice Release v1.0",
        "version": "1.0.0",
        "environment_id": env1.id,
        "environment_name": env1.name,
        "lead": "Alice Smith",
        "change_ref": "CHG-99881",
        "scheduled_date": (now + timedelta(days=15)).isoformat(),
        "status": "SCHEDULED"
    }, headers={"Authorization": f"Bearer {alice_token}"})
    assert rel_res.status_code == 201
    alice_rel = rel_res.json()["data"]
    alice_rel_id = alice_rel["id"]

    # Bob should not see Alice's release in list or Kanban
    bob_rels = await client.get("/api/v1/releases", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_rels.status_code == 200
    bob_rel_ids = [r["id"] for r in bob_rels.json()["data"]]
    assert alice_rel_id not in bob_rel_ids

    bob_kanban = await client.get("/api/v1/releases/kanban", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_kanban.status_code == 200
    bob_kanban_data = bob_kanban.json()["data"]
    bob_kanban_ids = [r["id"] for r in bob_kanban_data.get("SCHEDULED", [])]
    assert alice_rel_id not in bob_kanban_ids

    # Alice sees her release in Kanban
    alice_kanban = await client.get("/api/v1/releases/kanban", headers={"Authorization": f"Bearer {alice_token}"})
    assert alice_kanban.status_code == 200
    alice_kanban_ids = [r["id"] for r in alice_kanban.json()["data"].get("SCHEDULED", [])]
    assert alice_rel_id in alice_kanban_ids

    # TEST 14: Runbooks Isolation
    # Alice creates a Runbook
    rb_res = await client.post("/api/v1/runbooks", json={
        "name": "Alice Automated Healthcheck",
        "category": "MAINTENANCE",
        "estimated_duration_mins": 10,
        "parameters": {}
    }, headers={"Authorization": f"Bearer {alice_token}"})
    assert rb_res.status_code == 201
    alice_rb = rb_res.json()["data"]
    alice_rb_id = alice_rb["id"]

    # Bob should not see Alice's runbook
    bob_rbs = await client.get("/api/v1/runbooks", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_rbs.status_code == 200
    bob_rb_ids = [r["id"] for r in bob_rbs.json()["data"]]
    assert alice_rb_id not in bob_rb_ids

    # Bob cannot execute Alice's runbook
    bob_exec = await client.post(f"/api/v1/runbooks/{alice_rb_id}/execute", json={}, headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_exec.status_code in [403, 404]

    # Super Admin sees Alice's runbook
    admin_rbs = await client.get("/api/v1/runbooks", headers={"Authorization": f"Bearer {admin_token}"})
    assert admin_rbs.status_code == 200
    admin_rb_ids = [r["id"] for r in admin_rbs.json()["data"]]
    assert alice_rb_id in admin_rb_ids

    # TEST 15: Overview Metrics & Topology Isolation
    # Alice's overview metrics
    alice_overview = await client.get("/api/v1/environments/metrics/overview", headers={"Authorization": f"Bearer {alice_token}"})
    assert alice_overview.status_code == 200

    # Bob's overview metrics
    bob_overview = await client.get("/api/v1/environments/metrics/overview", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_overview.status_code == 200

    # Alice's Topology graph contains Alice's profile and apps
    alice_topo = await client.get("/api/v1/topology/graph", headers={"Authorization": f"Bearer {alice_token}"})
    assert alice_topo.status_code == 200
    alice_topo_node_ids = [n["id"] for n in alice_topo.json()["nodes"]]
    assert alice_prof_id in alice_topo_node_ids

    # Bob's Topology graph does NOT contain Alice's profile
    bob_topo = await client.get("/api/v1/topology/graph", headers={"Authorization": f"Bearer {bob_token}"})
    assert bob_topo.status_code == 200
    bob_topo_node_ids = [n["id"] for n in bob_topo.json()["nodes"]]
    assert alice_prof_id not in bob_topo_node_ids

