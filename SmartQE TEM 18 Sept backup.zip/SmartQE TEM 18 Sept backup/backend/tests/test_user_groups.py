import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.portfolio_dao import business_unit_dao
from app.dao.user_dao import user_dao
from app.dao.role_dao import role_dao


@pytest.mark.asyncio
async def test_user_group_lifecycle_and_bu_restriction(client: AsyncClient, db_session: AsyncSession):
    # 1. Create two BUs: Finance and HR
    bu_fin = await business_unit_dao.create(db_session, {
        "name": "Finance BU",
        "code": "FIN",
        "description": "Financial operations",
        "is_active": True,
        "status": "ACTIVE"
    })
    bu_hr = await business_unit_dao.create(db_session, {
        "name": "HR BU",
        "code": "HR",
        "description": "Human resources",
        "is_active": True,
        "status": "ACTIVE"
    })

    role = await role_dao.get_by_name(db_session, "Super Admin")

    # 2. Create Users tagged to Finance BU (User A, User B) and HR BU (User C)
    user_a = await user_dao.create_user_with_roles(db_session, {
        "first_name": "User",
        "last_name": "A",
        "username": "usera",
        "email": "usera@testops.io",
        "business_unit_id": bu_fin.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    user_b = await user_dao.create_user_with_roles(db_session, {
        "first_name": "User",
        "last_name": "B",
        "username": "userb",
        "email": "userb@testops.io",
        "business_unit_id": bu_fin.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    user_c = await user_dao.create_user_with_roles(db_session, {
        "first_name": "User",
        "last_name": "C",
        "username": "userc",
        "email": "userc@testops.io",
        "business_unit_id": bu_hr.id,
        "is_active": True,
        "status": "ACTIVE",
    }, [role])

    # Inactive user in Finance BU
    user_inactive = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Inactive",
        "last_name": "User",
        "username": "user_inactive",
        "email": "inactive@testops.io",
        "business_unit_id": bu_fin.id,
        "is_active": False,
        "status": "INACTIVE",
    }, [role])

    # 3. Test: Attempting to create User Group for Finance BU with User C (who belongs to HR) must fail
    res_invalid_bu = await client.post("/api/v1/user-groups", json={
        "name": "Finance Core Approvers",
        "description": "Finance group",
        "bu_id": bu_fin.id,
        "user_ids": [user_a.id, user_c.id],
        "is_active": True
    })
    assert res_invalid_bu.status_code == 400
    assert "does not belong to the selected Business Unit" in res_invalid_bu.json()["detail"]

    # 4. Test: Attempting to add an inactive user must fail
    res_inactive = await client.post("/api/v1/user-groups", json={
        "name": "Finance Core Approvers",
        "description": "Finance group",
        "bu_id": bu_fin.id,
        "user_ids": [user_a.id, user_inactive.id],
        "is_active": True
    })
    assert res_inactive.status_code == 400
    assert "is inactive and cannot be added" in res_inactive.json()["detail"]

    # 5. Test: Successfully create User Group with User A and User B
    res_create = await client.post("/api/v1/user-groups", json={
        "name": "Finance Core Approvers",
        "description": "Finance group",
        "bu_id": bu_fin.id,
        "user_ids": [user_a.id, user_b.id],
        "is_active": True
    })
    assert res_create.status_code == 201
    group_data = res_create.json()["data"]
    group_id = group_data["id"]
    assert group_data["name"] == "Finance Core Approvers"
    assert group_data["bu_id"] == bu_fin.id
    assert group_data["member_count"] == 2

    # 6. Test: Duplicate group name must fail
    res_dup = await client.post("/api/v1/user-groups", json={
        "name": "Finance Core Approvers",
        "bu_id": bu_fin.id,
        "user_ids": [user_a.id],
    })
    assert res_dup.status_code == 400

    # 7. Test: Get User Groups list and by ID
    res_list = await client.get("/api/v1/user-groups")
    assert res_list.status_code == 200
    assert len(res_list.json()["data"]) >= 1

    res_get = await client.get(f"/api/v1/user-groups/{group_id}")
    assert res_get.status_code == 200
    assert res_get.json()["data"]["name"] == "Finance Core Approvers"

    # 8. Test: Edit group (update description and member list)
    res_edit = await client.put(f"/api/v1/user-groups/{group_id}", json={
        "description": "Updated Finance Approvers",
        "user_ids": [user_a.id]
    })
    assert res_edit.status_code == 200
    assert res_edit.json()["data"]["member_count"] == 1
    assert res_edit.json()["data"]["description"] == "Updated Finance Approvers"

    # 9. Test: Toggle Status and Soft Deactivation
    res_toggle = await client.patch(f"/api/v1/user-groups/{group_id}/toggle-status")
    assert res_toggle.status_code == 200
    assert res_toggle.json()["data"]["is_active"] is False

    res_del = await client.delete(f"/api/v1/user-groups/{group_id}")
    assert res_del.status_code == 200
    assert res_del.json()["data"]["is_active"] is False
