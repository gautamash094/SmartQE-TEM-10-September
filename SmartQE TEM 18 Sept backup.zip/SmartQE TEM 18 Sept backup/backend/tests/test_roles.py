import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_get_roles_and_super_admin_default(client: AsyncClient):
    """
    Verify roles endpoint returns Super Admin as the initial order #1 system role.
    No dummy roles should be present initially.
    """
    response = await client.get("/api/v1/roles")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    roles = data["data"]
    assert len(roles) >= 1

    super_admin = roles[0]
    assert super_admin["name"] == "Super Admin"
    assert super_admin["role_order"] == 1
    assert super_admin["is_system"] is True
    assert super_admin["is_active"] is True


@pytest.mark.asyncio
async def test_create_role_validation(client: AsyncClient):
    """
    Test creating a role dynamically with validation for empty name, duplicate name, and success case.
    """
    # 1. Reject empty / whitespace name
    empty_res = await client.post("/api/v1/roles", json={"name": "   ", "description": "Invalid"})
    assert empty_res.status_code == 422 or empty_res.status_code == 400

    # 2. Successfully create new role dynamically
    payload = {
        "name": "Quality Lead",
        "description": "Oversees test automation and quality gates.",
        "is_active": True
    }
    create_res = await client.post("/api/v1/roles", json=payload)
    assert create_res.status_code == 201
    created_role = create_res.json()["data"]
    assert created_role["name"] == "Quality Lead"
    assert created_role["description"] == payload["description"]
    assert created_role["is_system"] is False
    assert created_role["role_order"] > 1

    # 3. Reject duplicate role name (case-insensitive)
    dup_res = await client.post("/api/v1/roles", json={"name": "quality lead", "description": "Duplicate"})
    assert dup_res.status_code == 400
    err_json = dup_res.json()
    assert "already exists" in (err_json.get("detail") or err_json.get("message") or "")


@pytest.mark.asyncio
async def test_reorder_roles(client: AsyncClient):
    """
    Test batch reordering of dynamically created role hierarchy.
    """
    # Create a dynamic role
    await client.post("/api/v1/roles", json={"name": "Release Coordinator", "description": "Manages releases"})

    list_res = await client.get("/api/v1/roles")
    roles = list_res.json()["data"]
    assert len(roles) >= 2

    # Swap orders
    reorder_payload = {
        "roles": [
            {"id": roles[0]["id"], "role_order": 2},
            {"id": roles[1]["id"], "role_order": 1}
        ]
    }
    reorder_res = await client.put("/api/v1/roles/reorder", json=reorder_payload)
    assert reorder_res.status_code == 200
    updated_roles = reorder_res.json()["data"]
    # Check that roles are returned ordered by role_order
    assert updated_roles[0]["id"] == roles[1]["id"]
    assert updated_roles[0]["role_order"] == 1


@pytest.mark.asyncio
async def test_super_admin_protection(client: AsyncClient):
    """
    Verify Super Admin cannot be deleted or deactivated.
    """
    list_res = await client.get("/api/v1/roles")
    roles = list_res.json()["data"]
    super_admin = next(r for r in roles if r["name"] == "Super Admin")

    # Try to delete
    del_res = await client.delete(f"/api/v1/roles/{super_admin['id']}")
    assert del_res.status_code == 400

    # Try to toggle status / deactivate
    toggle_res = await client.patch(f"/api/v1/roles/{super_admin['id']}/toggle-status")
    assert toggle_res.status_code == 400


@pytest.mark.asyncio
async def test_app_config_default_role_and_bu(client: AsyncClient):
    """
    Test setting and retrieving Default Role and Default Business Unit in app config without hardcoded roles.
    """
    # 1. Get current config
    get_res = await client.get("/api/v1/settings/config")
    assert get_res.status_code == 200

    # 2. Create a dynamic role
    role_res = await client.post("/api/v1/roles", json={"name": "Environment Engineer", "description": "Ops engineer"})
    assert role_res.status_code == 201
    target_role = role_res.json()["data"]

    # 3. Create a Business Unit
    bu_payload = {
        "name": "Retail Banking",
        "code": "BU-RETAIL",
        "lead": "Sarah Connor",
        "description": "Retail digital banking division"
    }
    bu_res = await client.post("/api/v1/portfolio/business-units", json=bu_payload)
    bu_data = bu_res.json()["data"]

    # 4. Configure Default Role and Default BU
    config_update = {
        "default_role_id": target_role["id"],
        "default_business_unit_id": bu_data["id"]
    }
    update_res = await client.put("/api/v1/settings/config", json=config_update)
    assert update_res.status_code == 200
    config_data = update_res.json()["data"]
    assert config_data["default_role_id"] == target_role["id"]
    assert config_data["default_role_name"] == target_role["name"]
    assert config_data["default_business_unit_id"] == bu_data["id"]
    assert config_data["default_business_unit_name"] == bu_data["name"]
