import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_get_topology_graph(client: AsyncClient):
    response = await client.get("/api/v1/topology/graph")
    assert response.status_code == 200
    data = response.json()
    assert "nodes" in data
    assert "edges" in data
    assert "metrics" in data
    assert isinstance(data["nodes"], list)
    assert isinstance(data["edges"], list)


@pytest.mark.asyncio
async def test_create_and_delete_topology_relationship(client: AsyncClient):
    # 1. Create Relationship
    payload = {
        "source_id": "app_checkout",
        "source_type": "APPLICATION",
        "source_name": "Checkout Service",
        "target_id": "db_payments",
        "target_type": "DATABASE",
        "target_name": "Payments PostgreSQL",
        "relationship_type": "USES_DATABASE",
        "port": "5432",
        "protocol": "JDBC",
        "latency_ms": 4.5,
        "notes": "Direct transactional connection"
    }
    create_res = await client.post("/api/v1/topology/relationships", json=payload)
    assert create_res.status_code == 201
    created_rel = create_res.json()
    assert created_rel["id"] is not None
    assert created_rel["relationship_type"] == "USES_DATABASE"
    rel_id = created_rel["id"]

    # 2. List Relationships
    list_res = await client.get("/api/v1/topology/relationships")
    assert list_res.status_code == 200
    rels = list_res.json()
    assert any(r["id"] == rel_id for r in rels)

    # 3. Simulate Impact Analysis
    impact_res = await client.get(f"/api/v1/topology/impact?node_id={created_rel['source_id']}")
    assert impact_res.status_code == 200
    impact_data = impact_res.json()
    assert "impact_score" in impact_data
    assert "impact_level" in impact_data

    # 4. Delete Relationship
    del_res = await client.delete(f"/api/v1/topology/relationships/{rel_id}")
    assert del_res.status_code == 204


@pytest.mark.asyncio
async def test_export_topology(client: AsyncClient):
    formats = ["CSV", "XLSX", "PDF", "DOCX"]
    scopes = ["ALL", "SELECTED"]

    for fmt in formats:
        for scope in scopes:
            payload = {
                "scope": scope,
                "selected_environment_ids": ["env-prof-001"],
                "format": fmt
            }
            res = await client.post("/api/v1/topology/export", json=payload)
            assert res.status_code == 200
            assert len(res.content) > 0
            assert "Content-Disposition" in res.headers
            assert f"Environment_Topology_{scope.capitalize()}_" in res.headers["Content-Disposition"]

