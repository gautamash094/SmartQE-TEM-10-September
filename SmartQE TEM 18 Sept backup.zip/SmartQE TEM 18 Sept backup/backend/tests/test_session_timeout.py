import pytest
from datetime import datetime, timedelta, timezone
from httpx import AsyncClient
from sqlalchemy import select
from app.models.user import User
from app.models.role import Role
from app.models.session import UserSession
from app.models.auth_audit import AuthAuditLog
from app.core.security import get_password_hash
from app.core.config import settings
from app.services.auth_service import make_aware


@pytest.mark.asyncio
async def test_login_creates_server_session_and_cookie(client: AsyncClient, db_session):

    """
    Test 1: Successful login generates an active server-side session in database
    and issues an HttpOnly session cookie.
    """
    res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "Admin@123"
    })
    assert res.status_code == 200
    data = res.json()["data"]
    assert "access_token" in data
    assert "session_id" in data
    session_id = data["session_id"]
    assert session_id is not None
    assert len(session_id) >= 32

    # Verify session stored in database
    db_sess_res = await db_session.execute(
        select(UserSession).where(UserSession.session_id == session_id)
    )
    db_sess = db_sess_res.scalars().first()
    assert db_sess is not None
    assert db_sess.status == "ACTIVE"
    assert db_sess.user_id == data["user_id"]

    # Verify cookie in response headers
    set_cookie_header = res.headers.get("set-cookie", "")
    assert settings.SESSION_COOKIE_NAME in set_cookie_header or session_id in set_cookie_header


@pytest.mark.asyncio
async def test_idle_timeout_expiration_20_minutes(client: AsyncClient, db_session):
    """
    Test 2: When user has no meaningful activity for 20+ minutes,
    backend invalidates the session, returns 401, and logs SESSION_EXPIRED audit event.
    """
    # 1. Login
    login_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "Admin@123"
    })
    session_id = login_res.json()["data"]["session_id"]

    # 2. Simulate 21 minutes of idle inactivity
    db_sess_res = await db_session.execute(
        select(UserSession).where(UserSession.session_id == session_id)
    )
    session = db_sess_res.scalars().first()
    now = datetime.now(timezone.utc)
    session.last_activity_at = now - timedelta(minutes=21)
    await db_session.commit()

    # 3. Next protected request must fail with 401 Unauthorized
    api_res = await client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {session_id}"})
    res_json = api_res.json()
    err_text = (res_json.get("message") or res_json.get("detail") or "").lower()
    assert "inactivity" in err_text or "expired" in err_text


    # 4. Verify DB session status updated to EXPIRED
    await db_session.refresh(session)
    assert session.status == "EXPIRED"

    # 5. Verify audit log entry
    audit_res = await db_session.execute(
        select(AuthAuditLog).where(
            AuthAuditLog.event_type == "SESSION_EXPIRED",
            AuthAuditLog.details == "IDLE_TIMEOUT"
        ).order_by(AuthAuditLog.created_at.desc())
    )
    audit_log = audit_res.scalars().first()
    assert audit_log is not None
    assert audit_log.username == "admin"


@pytest.mark.asyncio
async def test_meaningful_activity_extends_idle_timeout(client: AsyncClient, db_session):
    """
    Test 3: Meaningful user activity refreshes last_activity_at, keeping session active.
    """
    # 1. Login
    login_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "Admin@123"
    })
    session_id = login_res.json()["data"]["session_id"]

    # 2. Set last_activity_at to 10 minutes ago
    db_sess_res = await db_session.execute(
        select(UserSession).where(UserSession.session_id == session_id)
    )
    session = db_sess_res.scalars().first()
    past_time = datetime.now(timezone.utc) - timedelta(minutes=10)
    session.last_activity_at = past_time
    await db_session.commit()

    # 3. User makes a request (meaningful activity)
    api_res = await client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {session_id}"})
    assert api_res.status_code == 200

    # 4. Verify last_activity_at was refreshed to now (> past_time)
    await db_session.refresh(session)
    assert make_aware(session.last_activity_at) > make_aware(past_time)


@pytest.mark.asyncio
async def test_background_polling_does_not_extend_idle_timeout(client: AsyncClient, db_session):
    """
    Test 4: Background polling requests with X-Background-Request: true MUST NOT
    extend the 20-minute inactivity timer.
    """
    # 1. Login
    login_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "Admin@123"
    })
    session_id = login_res.json()["data"]["session_id"]

    # 2. Set last_activity_at to 15 minutes ago
    db_sess_res = await db_session.execute(
        select(UserSession).where(UserSession.session_id == session_id)
    )
    session = db_sess_res.scalars().first()
    activity_15m_ago = datetime.now(timezone.utc) - timedelta(minutes=15)
    session.last_activity_at = activity_15m_ago
    await db_session.commit()

    # 3. Automated background poll sends request with X-Background-Request: true
    bg_res = await client.get(
        "/api/v1/auth/me",
        headers={
            "Authorization": f"Bearer {session_id}",
            "X-Background-Request": "true"
        }
    )
    assert bg_res.status_code == 200

    # 4. Verify last_activity_at was NOT modified by the background poll
    await db_session.refresh(session)
    time_diff = abs((make_aware(session.last_activity_at) - make_aware(activity_15m_ago)).total_seconds())
    assert time_diff < 2  # Remains at 15m ago timestamp

    # 5. Now advance time to 21 minutes ago -> Background poll or any request must fail with 401
    session.last_activity_at = datetime.now(timezone.utc) - timedelta(minutes=21)
    await db_session.commit()

    poll_after_21m = await client.get(
        "/api/v1/auth/me",
        headers={
            "Authorization": f"Bearer {session_id}",
            "X-Background-Request": "true"
        }
    )
    assert poll_after_21m.status_code == 401


@pytest.mark.asyncio
async def test_session_status_and_continue_session_refresh(client: AsyncClient, db_session):
    """
    Test 5: Session status check and explicit 'Continue Session' refresh endpoint.
    """
    # 1. Login
    login_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "Admin@123"
    })
    session_id = login_res.json()["data"]["session_id"]

    # 2. Check session status
    status_res = await client.get("/api/v1/auth/session", headers={"Authorization": f"Bearer {session_id}"})
    assert status_res.status_code == 200
    status_data = status_res.json()["data"]
    assert status_data["is_authenticated"] is True
    assert status_data["idle_timeout_minutes"] == 20
    assert status_data["idle_remaining_seconds"] > 1100  # close to 1200 seconds (20 mins)

    # 3. Set last_activity_at to 18 minutes ago (2 mins remaining, warning trigger)
    db_sess_res = await db_session.execute(
        select(UserSession).where(UserSession.session_id == session_id)
    )
    session = db_sess_res.scalars().first()
    session.last_activity_at = datetime.now(timezone.utc) - timedelta(minutes=18)
    await db_session.commit()

    # 4. User clicks 'Continue Session' -> calls POST /api/v1/auth/session/refresh
    refresh_res = await client.post("/api/v1/auth/session/refresh", headers={"Authorization": f"Bearer {session_id}"})
    assert refresh_res.status_code == 200
    refresh_data = refresh_res.json()["data"]
    assert refresh_data["success"] is True
    assert refresh_data["idle_remaining_seconds"] >= 1190

    # 5. Verify database session is reset
    await db_session.refresh(session)
    elapsed = (datetime.now(timezone.utc) - make_aware(session.last_activity_at)).total_seconds()
    assert elapsed < 5



@pytest.mark.asyncio
async def test_logout_invalidates_server_session_immediately(client: AsyncClient, db_session):
    """
    Test 6: Explicit logout immediately terminates the server-side session.
    """
    # 1. Login
    login_res = await client.post("/api/v1/auth/json-login", json={
        "username": "admin",
        "password": "Admin@123"
    })
    session_id = login_res.json()["data"]["session_id"]

    # 2. Call logout endpoint
    logout_res = await client.post("/api/v1/auth/logout", headers={"Authorization": f"Bearer {session_id}"})
    assert logout_res.status_code == 200

    # 3. Verify session in DB marked LOGGED_OUT
    db_sess_res = await db_session.execute(
        select(UserSession).where(UserSession.session_id == session_id)
    )
    session = db_sess_res.scalars().first()
    assert session.status == "LOGGED_OUT"
    assert session.logout_at is not None

    # 4. Subsequent API calls with old session must return 401
    post_logout_res = await client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {session_id}"})
    assert post_logout_res.status_code == 401


@pytest.mark.asyncio
async def test_multi_user_session_independence(client: AsyncClient, db_session):
    """
    Test 7: Sessions for multiple users (Alice & Bob) are isolated and independent.
    Expiration of Alice's session does not affect Bob.
    """
    # 1. Create users Alice & Bob if not present
    r_res = await db_session.execute(select(Role).where(Role.name == "Super Admin"))
    role = r_res.scalars().first()

    u_alice = await db_session.execute(select(User).where(User.username == "alice_test"))
    alice = u_alice.scalars().first()
    if not alice:
        alice = User(
            username="alice_test",
            email="alice_test@testops.io",
            first_name="Alice",
            last_name="Tester",
            hashed_password=get_password_hash("Demo$12345"),
            roles=[role]
        )
        db_session.add(alice)

    u_bob = await db_session.execute(select(User).where(User.username == "bob_test"))
    bob = u_bob.scalars().first()
    if not bob:
        bob = User(
            username="bob_test",
            email="bob_test@testops.io",
            first_name="Bob",
            last_name="Tester",
            hashed_password=get_password_hash("Demo$12345"),
            roles=[role]
        )
        db_session.add(bob)
    await db_session.commit()

    # 2. Login Alice and Bob
    alice_login = await client.post("/api/v1/auth/json-login", json={"username": "alice_test", "password": "Demo$12345"})
    bob_login = await client.post("/api/v1/auth/json-login", json={"username": "bob_test", "password": "Demo$12345"})

    alice_sid = alice_login.json()["data"]["session_id"]
    bob_sid = bob_login.json()["data"]["session_id"]
    assert alice_sid != bob_sid

    # 3. Expire Alice's session
    a_sess_res = await db_session.execute(select(UserSession).where(UserSession.session_id == alice_sid))
    a_sess = a_sess_res.scalars().first()
    a_sess.last_activity_at = datetime.now(timezone.utc) - timedelta(minutes=25)
    await db_session.commit()

    # 4. Alice gets 401
    alice_api = await client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {alice_sid}"})
    assert alice_api.status_code == 401

    # 5. Bob remains 200 OK
    bob_api = await client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {bob_sid}"})
    assert bob_api.status_code == 200
    assert bob_api.json()["data"]["username"] == "bob_test"


@pytest.mark.asyncio
async def test_super_admin_session_timeout_enforcement(client: AsyncClient, db_session):
    """
    Test 8: Super Admin is subject to the exact same 20-minute idle session timeout.
    """
    # 1. Login Super Admin
    admin_login = await client.post("/api/v1/auth/json-login", json={"username": "admin", "password": "Admin@123"})
    admin_sid = admin_login.json()["data"]["session_id"]

    # 2. Expire Super Admin session
    db_sess_res = await db_session.execute(select(UserSession).where(UserSession.session_id == admin_sid))
    session = db_sess_res.scalars().first()
    session.last_activity_at = datetime.now(timezone.utc) - timedelta(minutes=22)
    await db_session.commit()

    # 3. Super Admin must receive 401 Unauthorized
    admin_api = await client.get("/api/v1/environments", headers={"Authorization": f"Bearer {admin_sid}"})
    assert admin_api.status_code == 401
