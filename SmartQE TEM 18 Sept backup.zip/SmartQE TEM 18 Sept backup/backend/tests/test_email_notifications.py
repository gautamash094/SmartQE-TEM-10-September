import pytest
import pytest_asyncio
from datetime import datetime, timezone, timedelta
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from unittest.mock import patch, MagicMock

from app.core.config import settings
from app.dao.user_dao import user_dao
from app.dao.role_dao import role_dao
from app.dao.portfolio_dao import business_unit_dao, application_dao
from app.dao.environment_profile_dao import environment_profile_dao
from app.dao.reservation_dao import reservation_dao
from app.dao.email_notification_dao import email_notification_dao
from app.models.reservation import ReservationStatus, ReservationMode
from app.models.email_notification import NotificationType, NotificationStatus
from app.models.workflow import TEMServiceType
from app.schemas.workflow import WorkflowCreate, WorkflowApproverItem
from app.schemas.reservation import ReservationCreate
from app.services.email_service import email_service
from app.services.reservation_service import reservation_service
from app.services.workflow_service import workflow_service
from app.services.reminder_scheduler import process_upcoming_booking_reminders


@pytest.fixture(autouse=True)
def mock_smtp_sender():
    """Mock SMTP network transmission by default so unit tests execute instantly."""
    with patch.object(email_service, "_send_smtp_sync", return_value=(True, None)) as mock:
        yield mock


@pytest_asyncio.fixture
async def setup_workflow_and_users(db_session: AsyncSession):
    """
    Creates BU, Environment, Application, 4 Users (Owner, Approver 1, Approver 2, Approver 3),
    and a sequential workflow: Approver 1 -> Approver 2 -> Approver 3.
    """
    # 1. BU
    bu = await business_unit_dao.create(db_session, {
        "name": "Finance Services BU",
        "code": "FIN",
        "is_active": True,
        "status": "ACTIVE"
    })

    # 2. Environment Profile
    env = await environment_profile_dao.create(db_session, {
        "name": "QA-Financial-01",
        "description": "Financial QA testbed",
        "is_active": True,
        "status": "HEALTHY"
    })

    # 3. Application
    app_record = await application_dao.create(db_session, {
        "name": "CoreBanking",
        "code": "CB",
        "business_unit": bu.name,
        "project_name": "FinanceCore",
        "component_name": "BankingAPI",
        "owner": "Finance Lead",
        "is_active": True,
        "status": "ACTIVE"
    })

    # 4. Roles
    user_role = await role_dao.create(db_session, {
        "name": "QA Engineer",
        "role_order": 2,
        "is_active": True
    })

    # 5. Users
    owner = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Oliver",
        "last_name": "Owner",
        "username": "oliver_owner",
        "email": "oliver.owner@testops.io",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE"
    }, [user_role])

    approver1 = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Alice",
        "last_name": "Approver1",
        "username": "alice_app1",
        "email": "alice@testops.io",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE"
    }, [user_role])

    approver2 = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Bob",
        "last_name": "Approver2",
        "username": "bob_app2",
        "email": "bob@testops.io",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE"
    }, [user_role])

    approver3 = await user_dao.create_user_with_roles(db_session, {
        "first_name": "Charlie",
        "last_name": "Approver3",
        "username": "charlie_app3",
        "email": "charlie@testops.io",
        "business_unit_id": bu.id,
        "is_active": True,
        "status": "ACTIVE"
    }, [user_role])

    # 6. Define Workflow with 3 Sequential Approvers
    wf_read = await workflow_service.create_workflow(
        db_session,
        WorkflowCreate(
            bu_id=bu.id,
            environment_id=env.id,
            application_id=app_record.id,
            service_code=TEMServiceType.ENVIRONMENT_RESERVATION,
            is_active=True,
            approvers=[
                WorkflowApproverItem(user_id=approver1.id, workflow_order=1),
                WorkflowApproverItem(user_id=approver2.id, workflow_order=2),
                WorkflowApproverItem(user_id=approver3.id, workflow_order=3),
            ]
        )
    )

    return {
        "bu_id": bu.id,
        "bu_name": bu.name,
        "env_id": env.id,
        "env_name": env.name,
        "app_id": app_record.id,
        "app_name": app_record.name,
        "owner_id": owner.id,
        "owner_name": owner.full_name,
        "owner_email": owner.email,
        "owner_user": owner,
        "approver1_id": approver1.id,
        "approver1_name": approver1.full_name,
        "approver1_email": approver1.email,
        "approver1_user": approver1,
        "approver2_id": approver2.id,
        "approver2_name": approver2.full_name,
        "approver2_email": approver2.email,
        "approver2_user": approver2,
        "approver3_id": approver3.id,
        "approver3_name": approver3.full_name,
        "approver3_email": approver3.email,
        "approver3_user": approver3,
        "workflow_id": wf_read.id,
    }


@pytest.mark.asyncio
async def test_smtp_config_defaults():
    """Verify SMTP configuration parameters are properly defined and loaded from settings."""
    assert hasattr(settings, "SMTP_HOST")
    assert hasattr(settings, "SMTP_PORT")
    assert hasattr(settings, "SMTP_USERNAME")
    assert hasattr(settings, "SMTP_PASSWORD")
    assert hasattr(settings, "SMTP_SENDER_EMAIL")
    assert hasattr(settings, "SMTP_SENDER_NAME")
    assert hasattr(settings, "SMTP_USE_TLS")
    assert hasattr(settings, "SMTP_USE_SSL")
    assert hasattr(settings, "SMTP_ENABLED")
    assert hasattr(settings, "SMTP_TIMEOUT")


@pytest.mark.asyncio
async def test_booking_creation_email_trigger(db_session: AsyncSession, setup_workflow_and_users):
    """
    Test that on booking creation:
    1. First approver (Alice) receives initial approval email.
    2. Owner is in CC.
    3. Later approvers (Bob, Charlie) do NOT receive emails yet.
    """
    data = setup_workflow_and_users
    now = datetime.now(timezone.utc)

    res_in = ReservationCreate(
        environment_id=data["env_id"],
        environment_name=data["env_name"],
        business_unit=data["bu_id"],
        application=data["app_name"],
        purpose="Regression Testing Phase 1",
        team="FinTech QA",
        requested_by=data["owner_name"],
        start_date=now + timedelta(days=2),
        end_date=now + timedelta(days=2, hours=4),
        reservation_mode=ReservationMode.SHARED
    )

    created, msg = await reservation_service.create_reservation(
        db=db_session,
        res_in=res_in,
        current_user=data["owner_user"]
    )

    assert created.status == ReservationStatus.PENDING
    assert created.current_workflow_order == 1
    assert created.current_approver_id == data["approver1_id"]

    # Check Email Notifications in DB
    notifications = await email_notification_dao.get_by_booking_id(db_session, created.id)
    assert len(notifications) == 1

    notif = notifications[0]
    assert notif.notification_type == NotificationType.BOOKING_CREATED.value
    assert notif.step_order == 1
    assert notif.recipient_to == data["approver1_email"]
    assert notif.recipient_cc == data["owner_email"]
    assert f"TEM Booking Approval Required - {created.id}" in notif.subject
    assert notif.status in [NotificationStatus.SENT.value, NotificationStatus.PENDING.value]

    # Verify Bob and Charlie did not receive emails
    assert not await email_notification_dao.is_already_sent(db_session, created.id, NotificationType.APPROVAL_REQUEST.value, step_order=2)
    assert not await email_notification_dao.is_already_sent(db_session, created.id, NotificationType.APPROVAL_REQUEST.value, step_order=3)


@pytest.mark.asyncio
async def test_sequential_workflow_approvals_and_notifications(db_session: AsyncSession, setup_workflow_and_users):
    """
    Test full 3-step sequential approval:
    Step 1: Alice approves -> Owner gets update, Bob gets approval request.
    Step 2: Bob approves -> Owner gets update, Charlie gets approval request.
    Step 3: Charlie approves (Final) -> Owner gets Final Approval email ('Booking Approved - BK...').
    """
    data = setup_workflow_and_users
    now = datetime.now(timezone.utc)

    res_in = ReservationCreate(
        environment_id=data["env_id"],
        environment_name=data["env_name"],
        business_unit=data["bu_id"],
        application=data["app_name"],
        purpose="Payment Gateway Integration Test",
        team="FinTech QA",
        requested_by=data["owner_name"],
        start_date=now + timedelta(days=5),
        end_date=now + timedelta(days=5, hours=6),
        reservation_mode=ReservationMode.SHARED
    )

    created, _ = await reservation_service.create_reservation(db=db_session, res_in=res_in, current_user=data["owner_user"])

    # Step 1: Alice (Approver 1) Approves
    updated1, msg1 = await reservation_service.process_approval_action(
        db=db_session,
        res_id=created.id,
        action="APPROVE",
        comments="Alice approved step 1",
        current_user=data["approver1_user"]
    )
    assert updated1.status == ReservationStatus.PENDING
    assert updated1.current_workflow_order == 2
    assert updated1.current_approver_id == data["approver2_id"]

    notifs_after_step1 = await email_notification_dao.get_by_booking_id(db_session, created.id)
    # 1 from creation + 1 to Owner + 1 to Approver 2 = 3 notifications
    assert len(notifs_after_step1) == 3

    # Check notification to Owner for step 1 completion
    owner_step1_notif = next((n for n in notifs_after_step1 if n.notification_type == NotificationType.APPROVAL_COMPLETED.value and n.step_order == 1), None)
    assert owner_step1_notif is not None
    assert owner_step1_notif.recipient_to == data["owner_email"]

    # Check notification to Bob (Approver 2)
    bob_step2_notif = next((n for n in notifs_after_step1 if n.notification_type == NotificationType.APPROVAL_REQUEST.value and n.step_order == 2), None)
    assert bob_step2_notif is not None
    assert bob_step2_notif.recipient_to == data["approver2_email"]
    assert bob_step2_notif.recipient_cc == data["owner_email"]

    # Charlie should NOT have received request yet
    assert not any(n.recipient_to == data["approver3_email"] for n in notifs_after_step1)

    # Step 2: Bob (Approver 2) Approves
    updated2, msg2 = await reservation_service.process_approval_action(
        db=db_session,
        res_id=created.id,
        action="APPROVE",
        comments="Bob approved step 2",
        current_user=data["approver2_user"]
    )
    assert updated2.status == ReservationStatus.PENDING
    assert updated2.current_workflow_order == 3
    assert updated2.current_approver_id == data["approver3_id"]

    notifs_after_step2 = await email_notification_dao.get_by_booking_id(db_session, created.id)
    # Previous 3 + 1 to Owner + 1 to Charlie = 5
    assert len(notifs_after_step2) == 5

    charlie_step3_notif = next((n for n in notifs_after_step2 if n.notification_type == NotificationType.APPROVAL_REQUEST.value and n.step_order == 3), None)
    assert charlie_step3_notif is not None
    assert charlie_step3_notif.recipient_to == data["approver3_email"]

    # Step 3: Charlie (Approver 3 - Final) Approves
    updated3, msg3 = await reservation_service.process_approval_action(
        db=db_session,
        res_id=created.id,
        action="APPROVE",
        comments="Charlie approved final step",
        current_user=data["approver3_user"]
    )
    assert updated3.status == ReservationStatus.APPROVED
    assert updated3.current_approver_id is None

    notifs_after_step3 = await email_notification_dao.get_by_booking_id(db_session, created.id)
    # Previous 5 + 1 Final Approval to Owner = 6
    assert len(notifs_after_step3) == 6

    final_notif = next((n for n in notifs_after_step3 if n.notification_type == NotificationType.FINAL_APPROVAL.value), None)
    assert final_notif is not None
    assert final_notif.recipient_to == data["owner_email"]
    assert f"Booking Approved - {created.id}" in final_notif.subject


@pytest.mark.asyncio
async def test_rejection_workflow_and_email(db_session: AsyncSession, setup_workflow_and_users):
    """
    Test that if an approver rejects:
    1. Status becomes REJECTED and workflow terminates.
    2. Owner receives Rejection email with reason.
    3. Next approvers do not receive any approval requests.
    """
    data = setup_workflow_and_users
    now = datetime.now(timezone.utc)

    res_in = ReservationCreate(
        environment_id=data["env_id"],
        environment_name=data["env_name"],
        business_unit=data["bu_id"],
        application=data["app_name"],
        purpose="Stress Testing",
        team="FinTech QA",
        requested_by=data["owner_name"],
        start_date=now + timedelta(days=3),
        end_date=now + timedelta(days=3, hours=2),
        reservation_mode=ReservationMode.SHARED
    )

    created, _ = await reservation_service.create_reservation(db=db_session, res_in=res_in, current_user=data["owner_user"])

    # Alice rejects the reservation
    rejection_reason = "Maintenance scheduled on QA-Financial-01 during requested period."
    rejected, msg = await reservation_service.process_approval_action(
        db=db_session,
        res_id=created.id,
        action="REJECT",
        comments=rejection_reason,
        current_user=data["approver1_user"]
    )

    assert rejected.status == ReservationStatus.REJECTED
    assert rejected.rejection_reason == rejection_reason

    notifs = await email_notification_dao.get_by_booking_id(db_session, created.id)
    # 1 creation + 1 rejection = 2
    assert len(notifs) == 2

    reject_notif = next((n for n in notifs if n.notification_type == NotificationType.REJECTION.value), None)
    assert reject_notif is not None
    assert reject_notif.recipient_to == data["owner_email"]
    assert f"Booking Rejected - {created.id}" in reject_notif.subject
    assert rejection_reason in reject_notif.body

    # Ensure neither Bob nor Charlie received any approval request
    assert not await email_notification_dao.is_already_sent(db_session, created.id, NotificationType.APPROVAL_REQUEST.value, step_order=2)
    assert not await email_notification_dao.is_already_sent(db_session, created.id, NotificationType.APPROVAL_REQUEST.value, step_order=3)


@pytest.mark.asyncio
async def test_upcoming_booking_1hour_reminder(db_session: AsyncSession, setup_workflow_and_users):
    """
    Test 1-hour future booking reminder:
    - Approved booking starting in 40 minutes receives a reminder email.
    - Cancelled / Rejected / Distant future booking does not receive a reminder email.
    """
    data = setup_workflow_and_users
    now = datetime.now(timezone.utc)

    # 1. Eligible Booking: APPROVED, starting in 40 minutes
    res_eligible = await reservation_dao.create(db_session, {
        "environment_id": data["env_id"],
        "environment_name": data["env_name"],
        "business_unit": data["bu_name"],
        "purpose": "Upcoming test in 40 min",
        "team": "QA",
        "requested_by": data["owner_name"],
        "owner_id": data["owner_id"],
        "created_by": data["owner_name"],
        "start_date": now + timedelta(minutes=40),
        "end_date": now + timedelta(hours=2),
        "status": ReservationStatus.APPROVED,
        "reservation_mode": ReservationMode.SHARED
    })

    # 2. Ineligible Booking: CANCELLED, starting in 40 minutes
    res_cancelled = await reservation_dao.create(db_session, {
        "environment_id": data["env_id"],
        "environment_name": data["env_name"],
        "business_unit": data["bu_name"],
        "purpose": "Cancelled booking",
        "team": "QA",
        "requested_by": data["owner_name"],
        "owner_id": data["owner_id"],
        "created_by": data["owner_name"],
        "start_date": now + timedelta(minutes=40),
        "end_date": now + timedelta(hours=2),
        "status": ReservationStatus.CANCELLED,
        "reservation_mode": ReservationMode.SHARED
    })

    # 3. Ineligible Booking: APPROVED, but starts in 5 days (far future)
    res_future = await reservation_dao.create(db_session, {
        "environment_id": data["env_id"],
        "environment_name": data["env_name"],
        "business_unit": data["bu_name"],
        "purpose": "Distant booking",
        "team": "QA",
        "requested_by": data["owner_name"],
        "owner_id": data["owner_id"],
        "created_by": data["owner_name"],
        "start_date": now + timedelta(days=5),
        "end_date": now + timedelta(days=5, hours=2),
        "status": ReservationStatus.APPROVED,
        "reservation_mode": ReservationMode.SHARED
    })

    # Run reminder processor
    dispatched_count = await process_upcoming_booking_reminders(db_session)
    assert dispatched_count == 1

    # Check reminder notification for eligible booking
    notifs_eligible = await email_notification_dao.get_by_booking_id(db_session, res_eligible.id)
    assert len(notifs_eligible) == 1
    assert notifs_eligible[0].notification_type == NotificationType.BOOKING_REMINDER.value
    assert notifs_eligible[0].recipient_to == data["owner_email"]
    assert f"Upcoming Booking Reminder - {res_eligible.id}" in notifs_eligible[0].subject

    # Check no reminders for cancelled or distant bookings
    notifs_cancelled = await email_notification_dao.get_by_booking_id(db_session, res_cancelled.id)
    assert len(notifs_cancelled) == 0

    notifs_future = await email_notification_dao.get_by_booking_id(db_session, res_future.id)
    assert len(notifs_future) == 0

    # Idempotency check: running reminder processor a second time should NOT resend
    second_run_count = await process_upcoming_booking_reminders(db_session)
    assert second_run_count == 0


@pytest.mark.asyncio
async def test_email_failure_does_not_rollback_booking(db_session: AsyncSession, setup_workflow_and_users):
    """
    Test failure handling:
    If SMTP throws an exception (e.g. network failure), the booking creation
    remains completely successful, and the notification is stored with status FAILED.
    """
    data = setup_workflow_and_users
    now = datetime.now(timezone.utc)

    res_in = ReservationCreate(
        environment_id=data["env_id"],
        environment_name=data["env_name"],
        business_unit=data["bu_id"],
        application=data["app_name"],
        purpose="Fault tolerance test",
        team="FinTech QA",
        requested_by=data["owner_name"],
        start_date=now + timedelta(days=7),
        end_date=now + timedelta(days=7, hours=2),
        reservation_mode=ReservationMode.SHARED
    )

    with patch.object(email_service, "send_email", return_value=(False, "ConnectionRefusedError: [Errno 111] Connection refused")):
        created, msg = await reservation_service.create_reservation(
            db=db_session,
            res_in=res_in,
            current_user=data["owner_user"]
        )

        # Booking is successfully created despite email failure
        assert created is not None
        assert created.status == ReservationStatus.PENDING

        # Notification record captured the failure
        notifs = await email_notification_dao.get_by_booking_id(db_session, created.id)
        assert len(notifs) == 1
        assert notifs[0].status == NotificationStatus.FAILED.value
        assert "Connection refused" in notifs[0].error_message


@pytest.mark.asyncio
async def test_notification_endpoints(client: AsyncClient, db_session: AsyncSession, setup_workflow_and_users):
    """
    Test notification API endpoints:
    - GET /api/v1/notifications/booking/{id}
    - POST /api/v1/notifications/{id}/retry
    - POST /api/v1/notifications/trigger-reminders
    """
    data = setup_workflow_and_users
    now = datetime.now(timezone.utc)

    # 1. Create a reservation
    res_in = ReservationCreate(
        environment_id=data["env_id"],
        environment_name=data["env_name"],
        business_unit=data["bu_id"],
        application=data["app_name"],
        purpose="API Notification test",
        team="FinTech QA",
        requested_by=data["owner_name"],
        start_date=now + timedelta(days=4),
        end_date=now + timedelta(days=4, hours=2),
        reservation_mode=ReservationMode.SHARED
    )

    created, _ = await reservation_service.create_reservation(db=db_session, res_in=res_in, current_user=data["owner_user"])

    # Test GET booking notifications
    response = await client.get(f"/api/v1/notifications/booking/{created.id}")
    assert response.status_code == 200
    res_json = response.json()
    assert res_json["success"] is True
    assert len(res_json["data"]) >= 1
    notif_id = res_json["data"][0]["id"]

    # Test POST retry notification
    retry_response = await client.post(f"/api/v1/notifications/{notif_id}/retry")
    assert retry_response.status_code == 200
    retry_json = retry_response.json()
    assert retry_json["success"] is True
    assert retry_json["data"]["retry_count"] >= 1

    # Test POST trigger reminders
    reminder_response = await client.post("/api/v1/notifications/trigger-reminders")
    assert reminder_response.status_code == 200
    reminder_json = reminder_response.json()
    assert reminder_json["success"] is True
    assert "reminders_dispatched" in reminder_json["data"]
