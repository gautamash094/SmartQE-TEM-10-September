import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_get_users_list(client: AsyncClient):
    """
    Verify /api/v1/users returns user list with roles and audit details.
    """
    response = await client.get("/api/v1/users")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    users = data["data"]
    assert len(users) >= 1
    admin_user = users[0]
    assert admin_user["username"] == "admin"
    assert "roles" in admin_user
    assert len(admin_user["roles"]) >= 1
    assert admin_user["created_by"] is not None


@pytest.mark.asyncio
async def test_create_user_validation_and_multi_role(client: AsyncClient):
    """
    Test creating user with validation for first name, last name, unique username/email,
    multiple roles, and optional BU.
    """
    # Create roles for test
    create_role1_res = await client.post("/api/v1/roles", json={
        "name": "DevOps Engineer",
        "description": "DevOps role"
    })
    role1_id = create_role1_res.json()["data"]["id"]

    create_role2_res = await client.post("/api/v1/roles", json={
        "name": "Release Manager",
        "description": "Manages releases"
    })
    role2_id = create_role2_res.json()["data"]["id"]

    # 2. Create a Business Unit
    bu_res = await client.post("/api/v1/portfolio/business-units", json={
        "name": "Payments Core",
        "code": "BU-PAY",
        "lead": "Alice",
        "description": "Payments BU"
    })
    bu_id = bu_res.json()["data"]["id"]

    # 3. Test empty name validation
    empty_res = await client.post("/api/v1/users", json={
        "first_name": "  ",
        "last_name": "Smith",
        "username": "jsmith",
        "email": "jsmith@example.com",
        "role_ids": [role1_id]
    })
    assert empty_res.status_code == 422 or empty_res.status_code == 400

    # 4. Successfully create user with multi-roles and optional BU
    valid_payload = {
        "first_name": "John",
        "last_name": "Smith",
        "username": "john.smith",
        "email": "john.smith@company.com",
        "business_unit_id": bu_id,
        "role_ids": [role1_id, role2_id],
        "is_active": True
    }
    create_res = await client.post("/api/v1/users", json=valid_payload)
    assert create_res.status_code == 201
    created_user = create_res.json()["data"]
    assert created_user["first_name"] == "John"
    assert created_user["last_name"] == "Smith"
    assert created_user["full_name"] == "John Smith"
    assert created_user["username"] == "john.smith"
    assert created_user["email"] == "john.smith@company.com"
    assert len(created_user["roles"]) == 2
    assert created_user["business_unit_id"] == bu_id
    assert created_user["business_unit"]["name"] == "Payments Core"
    assert created_user["created_by"] == "Super Admin"

    # 5. Reject duplicate username
    dup_uname_res = await client.post("/api/v1/users", json={
        "first_name": "Johnny",
        "last_name": "Doe",
        "username": "JOHN.SMITH",  # case-insensitive check
        "email": "another@company.com",
        "role_ids": [role1_id]
    })
    assert dup_uname_res.status_code == 400
    assert "already exists" in dup_uname_res.json().get("detail", "")

    # 6. Reject duplicate email
    dup_email_res = await client.post("/api/v1/users", json={
        "first_name": "Johnny",
        "last_name": "Doe",
        "username": "jdoe",
        "email": "JOHN.SMITH@company.com",
        "role_ids": [role1_id]
    })
    assert dup_email_res.status_code == 400
    assert "already exists" in dup_email_res.json().get("detail", "")


@pytest.mark.asyncio
async def test_update_user_and_immutability(client: AsyncClient):
    """
    Verify updating first name, last name, roles, BU, status.
    Ensure username and email are immutable (cannot be modified).
    """
    create_role_res = await client.post("/api/v1/roles", json={
        "name": "QA Lead",
        "description": "QA lead role"
    })
    role_id = create_role_res.json()["data"]["id"]

    # Create user
    create_res = await client.post("/api/v1/users", json={
        "first_name": "Elena",
        "last_name": "Rostova",
        "username": "elena.rostova",
        "email": "elena.rostova@company.com",
        "role_ids": [role_id]
    })
    assert create_res.status_code == 201
    user_id = create_res.json()["data"]["id"]

    # Update names and roles
    update_res = await client.put(f"/api/v1/users/{user_id}", json={
        "first_name": "Helena",
        "last_name": "Rostov",
        "role_ids": [role_id],
        "status": "ACTIVE"
    })
    assert update_res.status_code == 200
    updated_user = update_res.json()["data"]
    assert updated_user["first_name"] == "Helena"
    assert updated_user["last_name"] == "Rostov"
    assert updated_user["full_name"] == "Helena Rostov"
    # Username and email remain unchanged
    assert updated_user["username"] == "elena.rostova"
    assert updated_user["email"] == "elena.rostova@company.com"


@pytest.mark.asyncio
async def test_toggle_user_status_and_delete(client: AsyncClient):
    """
    Verify toggling user active status and deletion.
    """
    create_role_res = await client.post("/api/v1/roles", json={
        "name": "Security Auditor",
        "description": "Auditor role"
    })
    role_id = create_role_res.json()["data"]["id"]

    create_res = await client.post("/api/v1/users", json={
        "first_name": "David",
        "last_name": "Miller",
        "username": "david.miller",
        "email": "david.miller@company.com",
        "role_ids": [role_id]
    })
    assert create_res.status_code == 201
    user_id = create_res.json()["data"]["id"]

    # Toggle status to inactive
    toggle_res = await client.patch(f"/api/v1/users/{user_id}/toggle-status")
    assert toggle_res.status_code == 200
    assert toggle_res.json()["data"]["is_active"] is False
    assert toggle_res.json()["data"]["status"] == "INACTIVE"

    # Delete user
    del_res = await client.delete(f"/api/v1/users/{user_id}")
    assert del_res.status_code == 200

    # Verify 404
    get_res = await client.get(f"/api/v1/users/{user_id}")
    assert get_res.status_code == 404
