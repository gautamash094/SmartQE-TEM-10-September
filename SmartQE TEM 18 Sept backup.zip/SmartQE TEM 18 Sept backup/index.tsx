import React from 'react';
import ReactDOM from 'react-dom';
import { App } from './src/App';
import './src/index.css';

const rootElement = document.getElementById('root');

if (rootElement) {
  if (typeof (ReactDOM as any).createRoot === 'function') {
    const root = (ReactDOM as any).createRoot(rootElement);
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
  } else {
    (ReactDOM as any).render(
      <React.StrictMode>
        <App />
      </React.StrictMode>,
      rootElement
    );
  }
}

export default App;
