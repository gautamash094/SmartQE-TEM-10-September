import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authService, AuthSessionUser } from '../services/authService';
import { accessService } from '../services/accessService';
import { useSessionTimeout } from '../hooks/useSessionTimeout';
import { SessionTimeoutWarningModal } from '../components/common/SessionTimeoutWarningModal';

interface AuthContextType {
  currentUser: AuthSessionUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (usernameOrEmail: string, password: string) => Promise<AuthSessionUser>;
  logout: () => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  hasPermission: (screenRoute: string) => boolean;
  refreshPermissions: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<AuthSessionUser | null>(() => {
    return authService.getCurrentSessionUser();
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Initialize and verify session on bootstrap
  useEffect(() => {
    const existing = authService.getCurrentSessionUser();
    if (existing) {
      setCurrentUser(existing);
      // Verify server session validity on startup
      authService.checkSessionStatus().then((status) => {
        if (status && !status.is_authenticated) {
          authService.clearSession();
          setCurrentUser(null);
        }
      });
    }
    setIsLoading(false);

    const handleAuthChange = () => {
      const user = authService.getCurrentSessionUser();
      setCurrentUser(user);
    };

    window.addEventListener('auth_state_changed', handleAuthChange);
    return () => {
      window.removeEventListener('auth_state_changed', handleAuthChange);
    };
  }, []);

  const refreshPermissions = useCallback(async () => {
    const sessionUser = authService.getCurrentSessionUser();
    if (!sessionUser) return;
    try {
      const allowed = await accessService.getEffectiveAllowedRoutes(sessionUser.roles);
      const updatedUser: AuthSessionUser = {
        ...sessionUser,
        allowedScreens: allowed,
      };
      setCurrentUser(updatedUser);
      authService.setSession(updatedUser, updatedUser.token);
    } catch {}
  }, []);

  const login = async (usernameOrEmail: string, password: string): Promise<AuthSessionUser> => {
    const sessionUser = await authService.login(usernameOrEmail, password);
    setCurrentUser(sessionUser);
    return sessionUser;
  };

  const logout = async (): Promise<void> => {
    await authService.logout();
    setCurrentUser(null);
    if (typeof window !== 'undefined' && !window.location.pathname.includes('/login')) {
      window.location.href = '/login';
    }
  };

  const handleSessionExpired = useCallback(async () => {
    authService.clearSession();
    setCurrentUser(null);
    if (typeof window !== 'undefined' && !window.location.pathname.includes('/login')) {
      window.location.href = '/login?expired=true';
    }
  }, []);

  const changePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
    await authService.changePassword(currentPassword, newPassword);
  };

  // Enterprise Session Inactivity Timeout Hook
  const {
    isWarningOpen,
    remainingSeconds,
    isRefreshing,
    handleContinueSession,
    handleExplicitLogout,
  } = useSessionTimeout({
    isAuthenticated: !!currentUser,
    onLogout: logout,
    onSessionExpired: handleSessionExpired,
  });

  const hasPermission = useCallback(
    (screenRoute: string): boolean => {
      if (!currentUser) return false;

      // 1. Super Admin ALWAYS has 100% unrestricted access to each and every screen, module, and functionality
      const isSuperAdmin =
        Boolean(currentUser.isSuperAdmin) ||
        currentUser.username.toLowerCase() === 'admin' ||
        (currentUser.roles || []).some((r) => r.name.toLowerCase().trim() === 'super admin');

      if (isSuperAdmin) {
        return true;
      }

      // 2. If a non-Super Admin user has no allowed screens configured, they have 0 permissions
      if (!currentUser.allowedScreens || currentUser.allowedScreens.length === 0) {
        return false;
      }

      if (currentUser.allowedScreens.includes('*')) {
        return true;
      }

      const normalizedRoute = screenRoute.toLowerCase().trim();

      // Exact match (e.g. '/settings/access' === '/settings/access')
      if (currentUser.allowedScreens.some((r) => (r || '').toLowerCase().trim() === normalizedRoute)) {
        return true;
      }

      // Parent container route match (e.g. checking parent menu '/settings' when user has '/settings/users')
      if (normalizedRoute === '/settings') {
        return currentUser.allowedScreens.some((r) => (r || '').toLowerCase().trim().startsWith('/settings/'));
      }

      // Deep child sub-routes under an allowed screen (e.g. '/environment-monitoring/123' under '/environment-monitoring')
      // Only allow if nr is NOT a generic top-level parent like '/settings'
      return currentUser.allowedScreens.some((r) => {
        const nr = (r || '').toLowerCase().trim();
        if (nr === '/settings' || nr === '/' || !nr) return false;
        return normalizedRoute.startsWith(nr + '/');
      });
    },
    [currentUser]
  );

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        isLoading,
        login,
        logout,
        changePassword,
        hasPermission,
        refreshPermissions,
      }}
    >
      {children}

      {/* Enterprise Session Timeout Warning Modal */}
      <SessionTimeoutWarningModal
        isOpen={isWarningOpen}
        remainingSeconds={remainingSeconds}
        isRefreshing={isRefreshing}
        onContinueSession={handleContinueSession}
        onLogout={handleExplicitLogout}
      />
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
