import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { Environment, Incident, Release, Booking, Runbook, OverviewMetrics } from '../types';
import {
  INITIAL_INCIDENTS,
  INITIAL_RELEASES,
  INITIAL_BOOKINGS,
  INITIAL_RUNBOOKS,
} from '../constants/mockData';
import { bookingService } from '../services/bookingService';
import { releaseService } from '../services/releaseService';
import { incidentService } from '../services/incidentService';
import { runbookService } from '../services/runbookService';
import {
  portfolioService,
  BusinessUnit,
  Project,
  ComponentEntity,
  ApplicationEntity,
  INITIAL_BUSINESS_UNITS,
  INITIAL_PROJECTS,
  INITIAL_COMPONENTS,
  INITIAL_APPLICATIONS
} from '../services/portfolioService';

// Read persisted portfolio data from localStorage for instant initial render
function loadPortfolioFromStorage<T>(key: string, defaults: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return defaults;
}
import {
  ServerDetail,
  SoftwareDetail,
  EnvironmentProfile,
  EnvironmentType
} from '../types/environmentDetails';
import {
  environmentDetailsService
} from '../services/environmentDetailsService';
import {
  CICDPipelineEventPayload,
  IntegrationConfig,
  IntegrationHealthSummary,
  IntegrationLogEntry,
  IntegrationProvider,
  ITSMTicketSyncPayload
} from '../types/integrations';
import { integrationService } from '../services/integrationService';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface TEMContextType {
  environments: Environment[];
  incidents: Incident[];
  releases: Release[];
  bookings: Booking[];
  runbooks: Runbook[];
  businessUnits: BusinessUnit[];
  projects: Project[];
  components: ComponentEntity[];
  applications: ApplicationEntity[];
  servers: ServerDetail[];
  softwareList: SoftwareDetail[];
  environmentProfiles: EnvironmentProfile[];
  integrationConfigs: IntegrationConfig[];
  integrationLogs: IntegrationLogEntry[];
  integrationHealth: IntegrationHealthSummary;
  metrics: OverviewMetrics;
  toasts: Toast[];
  isLoading: boolean;
  addEnvironment: (envData: Omit<Environment, 'id' | 'uptime' | 'cpuUsage' | 'memoryUsage' | 'storageUsage' | 'topology'>) => Promise<void>;
  addBooking: (bookingData: Omit<Booking, 'id' | 'status'>) => Promise<Booking>;
  updateBooking: (id: string, updateData: Partial<Booking>) => Promise<Booking>;
  approveBooking: (id: string, action: 'APPROVE' | 'REJECT', comments?: string) => Promise<{ booking: Booking; message: string }>;
  cancelBooking: (id: string) => Promise<void>;
  rejectBooking: (id: string, reason?: string) => Promise<void>;
  addRelease: (releaseData: Omit<Release, 'id' | 'status'>) => Promise<void>;
  addIncident: (incidentData: Omit<Incident, 'id' | 'status' | 'openedAt'>) => Promise<void>;
  addBusinessUnit: (buData: Omit<BusinessUnit, 'id'>) => Promise<void>;
  updateBusinessUnit: (id: string, buData: Partial<BusinessUnit>) => Promise<void>;
  toggleBusinessUnit: (id: string) => Promise<void>;
  addProject: (projData: Omit<Project, 'id'>) => Promise<void>;
  updateProject: (id: string, projData: Partial<Project>) => Promise<void>;
  toggleProject: (id: string) => Promise<void>;
  addComponent: (compData: Omit<ComponentEntity, 'id'>) => Promise<void>;
  updateComponent: (id: string, compData: Partial<ComponentEntity>) => Promise<void>;
  toggleComponent: (id: string) => Promise<void>;
  addApplication: (appData: Omit<ApplicationEntity, 'id'>) => Promise<void>;
  updateApplication: (id: string, appData: Partial<ApplicationEntity>) => Promise<void>;
  toggleApplication: (id: string) => Promise<void>;
  // Server Management
  addServer: (serverData: Omit<ServerDetail, 'id' | 'createdAt'>) => Promise<ServerDetail>;
  updateServer: (id: string, serverData: Partial<ServerDetail>) => Promise<void>;
  toggleServer: (id: string) => Promise<void>;
  deleteServer: (id: string) => Promise<void>;
  // Software Management
  addSoftware: (softwareData: Omit<SoftwareDetail, 'id' | 'createdAt'>) => Promise<SoftwareDetail>;
  updateSoftware: (id: string, softwareData: Partial<SoftwareDetail>) => Promise<void>;
  toggleSoftware: (id: string) => Promise<void>;
  deleteSoftware: (id: string) => Promise<void>;
  // Environment Profiles
  addEnvironmentProfile: (profileData: Omit<EnvironmentProfile, 'id' | 'updatedAt'>) => Promise<EnvironmentProfile>;
  updateEnvironmentProfile: (id: string, profileData: Partial<EnvironmentProfile>) => Promise<void>;
  toggleEnvironmentProfile: (id: string) => Promise<void>;
  deleteEnvironmentProfile: (id: string) => Promise<void>;
  // Integration Management
  updateIntegrationConfig: (id: string, update: Partial<IntegrationConfig>) => void;
  testIntegrationConnection: (provider: IntegrationProvider) => Promise<{ success: boolean; message: string; latencyMs: number }>;
  simulateCICDEvent: (payload: CICDPipelineEventPayload) => Promise<void>;
  syncITSMTicket: (payload: ITSMTicketSyncPayload) => Promise<void>;
  reconcileIntegrations: () => Promise<void>;
  clearIntegrationLogs: () => void;
  executeRunbook: (id: string, targetEnvId?: string) => Promise<void>;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  refreshData: () => Promise<void>;
}

const TEMContext = createContext<TEMContextType | undefined>(undefined);

// Helper to ensure local state active conflict statuses are strictly evaluated considering ReservationMode
const recalculateLocalBookingConflicts = (list: Booking[]): Booking[] => {
  return list.map((b) => {
    if (
      b.status === 'CANCELLED' ||
      b.status === 'REJECTED' ||
      b.status === 'AUTO_REJECTED' ||
      b.status === 'PENDING' ||
      b.status === 'APPROVED'
    ) {
      return b;
    }
    const bStart = b.startDate ? new Date(b.startDate).getTime() : 0;
    const bEnd = b.endDate ? new Date(b.endDate).getTime() : 0;
    if (!bStart || !bEnd) return b;

    const bMode = b.reservationMode || 'SHARED';

    const hasConflict = list.some((other) => {
      if (
        other.id === b.id ||
        other.status === 'CANCELLED' ||
        other.status === 'REJECTED' ||
        other.status === 'AUTO_REJECTED'
      ) {
        return false;
      }
      const sameEnv =
        (other.environmentId && b.environmentId && other.environmentId === b.environmentId) ||
        (other.environmentName && b.environmentName && other.environmentName.toLowerCase() === b.environmentName.toLowerCase());
      if (!sameEnv || !other.startDate || !other.endDate) return false;

      const oStart = new Date(other.startDate).getTime();
      const oEnd = new Date(other.endDate).getTime();
      const isTimeOverlap = bStart < oEnd && bEnd > oStart;
      if (!isTimeOverlap) return false;

      const otherMode = other.reservationMode || 'SHARED';
      // SHARED + SHARED -> No Conflict
      // SHARED + DISRUPTIVE -> Conflict
      // DISRUPTIVE + SHARED / DISRUPTIVE -> Conflict
      return bMode === 'DISRUPTIVE' || otherMode === 'DISRUPTIVE';
    });

    // Check if fully approved via workflow audit trail
    const audit = Array.isArray(b.auditHistory)
      ? b.auditHistory
      : typeof b.auditHistory === 'string'
      ? JSON.parse(b.auditHistory || '[]')
      : [];
    const isAllApproved = audit.some(
      (a: any) =>
        a.status === 'APPROVED' &&
        a.newValue &&
        a.newValue.toLowerCase().includes('all workflow approvers have approved')
    );

    if (hasConflict) {
      return b.status === 'CONFLICT' ? b : { ...b, status: 'CONFLICT' };
    }

    if (isAllApproved) {
      // Heal previously corrupted ghost PENDING state back to APPROVED
      const curStatus = b.status as string;
      if (curStatus === 'CONFLICT' || curStatus === 'PENDING' || curStatus === 'CONFIRMED' || !curStatus) {
        return {
          ...b,
          status: 'APPROVED',
          currentApproverId: undefined,
          currentApproverName: undefined,
        };
      }
      return b;
    }

    const targetStatus = 'CONFIRMED';
    if (b.status === 'CONFLICT' || b.status === 'CONFIRMED' || !b.status) {
      return b.status === targetStatus ? b : { ...b, status: targetStatus };
    }
    return b;
  });
};

export const TEMProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [releases, setReleases] = useState<Release[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [runbooks, setRunbooks] = useState<Runbook[]>([]);
  const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [components, setComponents] = useState<ComponentEntity[]>([]);
  const [applications, setApplications] = useState<ApplicationEntity[]>([]);
  
  // Environment Details Module State (AUTHORITATIVE SINGLE SOURCE OF TRUTH)
  const [servers, setServers] = useState<ServerDetail[]>(() => environmentDetailsService.getServers());
  const [softwareList, setSoftwareList] = useState<SoftwareDetail[]>(() => environmentDetailsService.getSoftware());
  const [environmentProfiles, setEnvironmentProfiles] = useState<EnvironmentProfile[]>(() => environmentDetailsService.getProfiles());

  // Integration Module State
  const [integrationConfigs, setIntegrationConfigs] = useState<IntegrationConfig[]>(() => integrationService.getConfigs());
  const [integrationLogs, setIntegrationLogs] = useState<IntegrationLogEntry[]>(() => integrationService.getLogs());

  const integrationHealth: IntegrationHealthSummary = useMemo(() => {
    return integrationService.getHealthSummary();
  }, [integrationConfigs, integrationLogs]);

  // Derive legacy environments compatibility layer dynamically from environmentProfiles
  const environments: Environment[] = useMemo(() => {
    return (environmentProfiles || []).map((p) => ({
      id: p.id,
      name: p.name,
      tier: (p.type === 'Development' ? 'DEV' : p.type === 'QA / Testing' ? 'QA' : p.type === 'UAT / Staging' ? 'UAT' : p.type === 'Production' ? 'PRE-PROD' : 'QA') as any,
      team: p.ownerTeam || 'Platform QE',
      owner: p.ownerTeam || 'QE Guild',
      region: p.networkZone || 'VPC-EAST',
      status: p.status,
      isActive: p.isActive !== false,
      uptime: 99.9,
      cpuUsage: 45,
      memoryUsage: 60,
      storageUsage: 30,
      techStack: [],
      topology: [],
    }));
  }, [environmentProfiles]);

  const [toasts, setToasts] = useState<Toast[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const refreshData = async () => {
    setIsLoading(true);
    try {
      const [fetchedBookings, fetchedReleases, fetchedIncidents, fetchedRunbooks, fetchedBUs, fetchedProjs, fetchedComps, fetchedApps, fetchedProfiles] = await Promise.all([
        bookingService.getBookings(),
        releaseService.getReleases(),
        incidentService.getIncidents(),
        runbookService.getRunbooks(),
        portfolioService.getBusinessUnits(),
        portfolioService.getProjects(),
        portfolioService.getComponents(),
        portfolioService.getApplications(),
        environmentDetailsService.fetchProfiles()
      ]);

      if (fetchedBookings !== null && Array.isArray(fetchedBookings)) {
        setBookings(recalculateLocalBookingConflicts(fetchedBookings));
      }
      if (fetchedReleases !== null && Array.isArray(fetchedReleases)) {
        setReleases(fetchedReleases);
      }
      if (fetchedIncidents !== null && Array.isArray(fetchedIncidents)) {
        setIncidents(fetchedIncidents);
      }
      if (fetchedRunbooks !== null && Array.isArray(fetchedRunbooks)) {
        setRunbooks(fetchedRunbooks);
      }
      if (fetchedBUs !== null && Array.isArray(fetchedBUs)) {
        setBusinessUnits(fetchedBUs);
      }
      if (fetchedProjs !== null && Array.isArray(fetchedProjs)) {
        setProjects(fetchedProjs);
      }
      if (fetchedComps !== null && Array.isArray(fetchedComps)) {
        setComponents(fetchedComps);
      }
      if (fetchedApps !== null && Array.isArray(fetchedApps)) {
        setApplications(fetchedApps);
      }
      if (fetchedProfiles !== null && Array.isArray(fetchedProfiles)) {
        setEnvironmentProfiles(fetchedProfiles);
      }
      setServers(environmentDetailsService.getServers());
      setSoftwareList(environmentDetailsService.getSoftware());
    } catch (e) {
      console.log('Using fallback state for context load.');
    } finally {
      setIsLoading(false);
    }
  };

  // Initial fetch from FastAPI backend when available, and reload on auth state changes
  useEffect(() => {
    refreshData();
    const handleAuthChange = () => {
      refreshData();
    };
    window.addEventListener('auth_state_changed', handleAuthChange);
    return () => {
      window.removeEventListener('auth_state_changed', handleAuthChange);
    };
  }, []);

  // Automated Expiration Monitoring: Sweeps bookings whose end_date has passed
  useEffect(() => {
    const sweepExpiredBookings = () => {
      const now = Date.now();
      setBookings((prev) => {
        let hasExpired = false;
        const updated = prev.map((b) => {
          if (
            b.status !== 'CANCELLED' &&
            b.status !== 'REJECTED' &&
            b.status !== 'AUTO_REJECTED' &&
            b.endDate
          ) {
            const endMs = new Date(b.endDate).getTime();
            if (!isNaN(endMs) && endMs < now) {
              hasExpired = true;
              return {
                ...b,
                status: 'AUTO_REJECTED' as const,
                rejectionType: 'AUTO' as const,
                rejectionReason: 'Booking end date and time has passed',
                rejectedAt: b.rejectedAt || new Date().toISOString(),
              };
            }
          }
          return b;
        });

        if (hasExpired) {
          bookingService.autoRejectExpiredBookings().catch(() => {});
        }
        return hasExpired ? recalculateLocalBookingConflicts(updated) : prev;
      });
    };

    // Initial check
    sweepExpiredBookings();

    // Check periodically every 15 seconds
    const interval = setInterval(sweepExpiredBookings, 15000);
    return () => clearInterval(interval);
  }, []);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `toast-${Date.now()}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const metrics: OverviewMetrics = {
    totalEnvironments: (environmentProfiles || []).length,
    healthyEnvironments: (environmentProfiles || []).filter((e) => e.status === 'HEALTHY').length,
    activeBookings: (bookings || []).filter((b) => b.status === 'CONFIRMED' || b.status === 'CONFLICT').length,
    utilizationRate: Number((((bookings || []).length / ((environmentProfiles || []).length || 1)) * 10).toFixed(1)),
    openIncidents: (incidents || []).filter((i) => i.status !== 'RESOLVED').length,
    downEnvironmentsCount: (environmentProfiles || []).filter((e) => e.status === 'DOWN').length,
    upcomingReleases: (releases || []).filter((r) => r.status === 'SCHEDULED').length,
    trackedReleasesCount: (releases || []).length,
    cpuAverage: 38,
    memoryAverage: 52,
    storageAverage: 44,
  };

  const addEnvironment = async (envData: Omit<Environment, 'id' | 'uptime' | 'cpuUsage' | 'memoryUsage' | 'storageUsage' | 'topology'>) => {
    setIsLoading(true);
    try {
      await addEnvironmentProfile({
        name: envData.name,
        type: (envData.tier === 'DEV' ? 'Development' : envData.tier === 'UAT' ? 'UAT / Staging' : envData.tier === 'PRE-PROD' ? 'Production' : 'QA / Testing') as EnvironmentType,
        description: `Environment ${envData.name} owned by ${envData.team}`,
        status: envData.status || 'HEALTHY',
        ownerTeam: envData.team || 'Platform QE',
        networkZone: envData.region || 'VPC-QA-EAST',
        serverIds: [],
        softwareIds: [],
      });
    } catch (err: any) {
      showToast(err.message || 'Failed to register environment profile', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const addBooking = async (bookingData: Omit<Booking, 'id' | 'status'>): Promise<Booking> => {
    setIsLoading(true);
    try {
      const created = await bookingService.createBooking(bookingData);
      setBookings((prev) => recalculateLocalBookingConflicts([created, ...prev]));
      return created;
    } catch (err: any) {
      showToast(err.message || 'Failed to create reservation', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const updateBooking = async (id: string, updateData: Partial<Booking>) => {
    setIsLoading(true);
    try {
      const updated = await bookingService.updateBooking(id, updateData);
      setBookings((prev) =>
        recalculateLocalBookingConflicts(prev.map((b) => (b.id === id ? { ...b, ...updated } : b)))
      );
      return updated;
    } catch (err: any) {
      showToast(err.message || 'Failed to update reservation', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const approveBooking = async (id: string, action: 'APPROVE' | 'REJECT', comments?: string) => {
    setIsLoading(true);
    try {
      const result = await bookingService.approveBooking(id, action, comments);
      setBookings((prev) =>
        recalculateLocalBookingConflicts(prev.map((b) => (b.id === id ? { ...b, ...result.booking } : b)))
      );
      return result;
    } catch (err: any) {
      showToast(err.message || `Failed to ${action.toLowerCase()} reservation`, 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const cancelBooking = async (id: string) => {
    setIsLoading(true);
    try {
      const cancelled = await bookingService.cancelBooking(id);
      setBookings((prev) =>
        recalculateLocalBookingConflicts(prev.map((b) => (b.id === id ? { ...b, ...cancelled } : b)))
      );
      showToast('Reservation cancelled successfully.', 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to cancel reservation', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const rejectBooking = async (id: string, reason?: string) => {
    setIsLoading(true);
    try {
      const rejected = await bookingService.rejectBooking(id, reason);
      setBookings((prev) =>
        recalculateLocalBookingConflicts(
          prev.map((b) =>
            b.id === id
              ? {
                  ...b,
                  ...rejected,
                  status: 'REJECTED',
                  rejectionReason: reason || 'Manually rejected by user',
                  rejectedAt: new Date().toISOString(),
                  rejectionType: 'MANUAL',
                }
              : b
          )
        )
      );
      showToast('Reservation rejected successfully.', 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to reject reservation', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const addRelease = async (releaseData: Omit<Release, 'id' | 'status'>) => {
    setIsLoading(true);
    try {
      const created = await releaseService.createRelease(releaseData);
      setReleases((prev) => [created, ...prev]);
      showToast(`Release '${created.name}' (${created.version}) scheduled successfully!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to schedule release', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const addIncident = async (incidentData: Omit<Incident, 'id' | 'status' | 'openedAt'>) => {
    setIsLoading(true);
    try {
      const created = await incidentService.createIncident(incidentData);
      setIncidents((prev) => [created, ...prev]);
      showToast(`Incident ${created.id} (${created.severity}) raised!`, 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to raise incident', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const addBusinessUnit = async (buData: Omit<BusinessUnit, 'id'>) => {
    setIsLoading(true);
    try {
      const created = await portfolioService.createBusinessUnit(buData);
      setBusinessUnits((prev) => [...prev, created]);
      showToast(`Business Unit '${created.name}' created!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to create Business Unit', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const addProject = async (projData: Omit<Project, 'id'>) => {
    setIsLoading(true);
    try {
      const created = await portfolioService.createProject(projData);
      setProjects((prev) => [...prev, created]);
      showToast(`Project '${created.name}' added to ${created.businessUnit}!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to add project', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const addComponent = async (compData: Omit<ComponentEntity, 'id'>) => {
    setIsLoading(true);
    try {
      const created = await portfolioService.createComponent(compData);
      setComponents((prev) => [...prev, created]);
      showToast(`Component '${created.name}' created!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to create component', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const addApplication = async (appData: Omit<ApplicationEntity, 'id'>) => {
    setIsLoading(true);
    try {
      const created = await portfolioService.createApplication(appData);
      setApplications((prev) => [...prev, created]);
      showToast(`Application '${created.name}' registered!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to register application', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const updateBusinessUnit = async (id: string, buData: Partial<BusinessUnit>): Promise<void> => {
    setIsLoading(true);
    try {
      const existingBU = businessUnits.find((b) => b.id === id);
      const oldName = existingBU?.name;
      const updated = await portfolioService.updateBusinessUnit(id, buData);

      setBusinessUnits((prev) => prev.map((b) => (b.id === id ? updated : b)));

      // If BU name changed, cascade update projects, components and applications in state
      if (oldName && buData.name && oldName.toLowerCase() !== buData.name.toLowerCase()) {
        setProjects((prev) =>
          prev.map((p) => (p.businessUnit.toLowerCase() === oldName.toLowerCase() ? { ...p, businessUnit: buData.name! } : p))
        );
        setComponents((prev) =>
          prev.map((c) => (c.businessUnit.toLowerCase() === oldName.toLowerCase() ? { ...c, businessUnit: buData.name! } : c))
        );
        setApplications((prev) =>
          prev.map((a) => (a.businessUnit.toLowerCase() === oldName.toLowerCase() ? { ...a, businessUnit: buData.name! } : a))
        );
      }

      showToast(`Business Unit '${updated.name}' updated!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update Business Unit', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleBusinessUnit = async (id: string) => {
    setIsLoading(true);
    try {
      const target = businessUnits.find((b) => b.id === id);
      const updated = await portfolioService.toggleBusinessUnit(id);
      setBusinessUnits(updated);
      const newActive = updated.find((b) => b.id === id)?.isActive !== false;
      showToast(`Business Unit '${target?.name || id}' ${newActive ? 'activated' : 'deactivated'}.`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle Business Unit status', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const updateProject = async (id: string, projData: Partial<Project>): Promise<void> => {
    setIsLoading(true);
    try {
      const existingProj = projects.find((p) => p.id === id);
      const oldName = existingProj?.name;
      const updated = await portfolioService.updateProject(id, projData);

      setProjects((prev) => prev.map((p) => (p.id === id ? updated : p)));

      // If Project name changed, cascade update components and applications in state
      if (oldName && projData.name && oldName.toLowerCase() !== projData.name.toLowerCase()) {
        setComponents((prev) =>
          prev.map((c) =>
            c.projectName && c.projectName.toLowerCase() === oldName.toLowerCase()
              ? { ...c, projectName: projData.name! }
              : c
          )
        );
        setApplications((prev) =>
          prev.map((a) =>
            a.projectName && a.projectName.toLowerCase() === oldName.toLowerCase()
              ? { ...a, projectName: projData.name! }
              : a
          )
        );
      }

      showToast(`Project '${updated.name}' updated!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update Project', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleProject = async (id: string) => {
    setIsLoading(true);
    try {
      const target = projects.find((p) => p.id === id);
      const updated = await portfolioService.toggleProject(id);
      setProjects(updated);
      const newActive = updated.find((p) => p.id === id)?.isActive !== false;
      showToast(`Project '${target?.name || id}' ${newActive ? 'activated' : 'deactivated'}.`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle Project status', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const updateComponent = async (id: string, compData: Partial<ComponentEntity>): Promise<void> => {
    setIsLoading(true);
    try {
      const updated = await portfolioService.updateComponent(id, compData);
      setComponents((prev) => prev.map((c) => (c.id === id ? updated : c)));
      showToast(`Component '${updated.name}' updated!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update Component', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleComponent = async (id: string) => {
    setIsLoading(true);
    try {
      const target = components.find((c) => c.id === id);
      const updated = await portfolioService.toggleComponent(id);
      setComponents(updated);
      const newActive = updated.find((c) => c.id === id)?.isActive !== false;
      showToast(`Component '${target?.name || id}' ${newActive ? 'activated' : 'deactivated'}.`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle Component status', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const updateApplication = async (id: string, appData: Partial<ApplicationEntity>) => {
    setIsLoading(true);
    try {
      const updated = await portfolioService.updateApplication(id, appData);
      setApplications((prev) => prev.map((a) => (a.id === id ? updated : a)));
      showToast(`Application '${updated.name}' updated!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update Application', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleApplication = async (id: string) => {
    setIsLoading(true);
    try {
      const target = applications.find((a) => a.id === id);
      const updated = await portfolioService.toggleApplication(id);
      setApplications(updated);
      const newActive = updated.find((a) => a.id === id)?.isActive !== false;
      showToast(`Application '${target?.name || id}' ${newActive ? 'activated' : 'deactivated'}.`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle Application status', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // --- SERVER MANAGEMENT ACTIONS ---
  const addServer = async (serverData: Omit<ServerDetail, 'id' | 'createdAt'>): Promise<ServerDetail> => {
    const newServer = await environmentDetailsService.createServer(serverData);
    setServers(environmentDetailsService.getServers());
    showToast(`Server '${newServer.name}' added successfully!`, 'success');
    return newServer;
  };

  const updateServer = async (id: string, serverData: Partial<ServerDetail>): Promise<void> => {
    await environmentDetailsService.updateServer(id, serverData);
    setServers(environmentDetailsService.getServers());
    showToast('Server details updated.', 'success');
  };

  const toggleServer = async (id: string): Promise<void> => {
    const updated = await environmentDetailsService.toggleServer(id);
    setServers(environmentDetailsService.getServers());
    const target = updated.find((s) => s.id === id);
    const newActive = target ? target.isActive !== false : true;
    showToast(`Server '${target?.name || id}' ${newActive ? 'activated' : 'deactivated'}.`, 'success');
  };

  const deleteServer = async (id: string): Promise<void> => {
    const target = servers.find((s) => s.id === id);
    await environmentDetailsService.deleteServer(id);
    setServers(environmentDetailsService.getServers());
    showToast(`Server '${target?.name || id}' deactivated.`, 'info');
  };

  // --- SOFTWARE MANAGEMENT ACTIONS ---
  const addSoftware = async (softwareData: Omit<SoftwareDetail, 'id' | 'createdAt'>): Promise<SoftwareDetail> => {
    const newSoftware = await environmentDetailsService.createSoftware(softwareData);
    setSoftwareList(environmentDetailsService.getSoftware());
    showToast(`Software '${newSoftware.name}' registered!`, 'success');
    return newSoftware;
  };

  const updateSoftware = async (id: string, softwareData: Partial<SoftwareDetail>): Promise<void> => {
    await environmentDetailsService.updateSoftware(id, softwareData);
    setSoftwareList(environmentDetailsService.getSoftware());
    showToast('Software details updated.', 'success');
  };

  const toggleSoftware = async (id: string): Promise<void> => {
    const updated = await environmentDetailsService.toggleSoftware(id);
    setSoftwareList(environmentDetailsService.getSoftware());
    const target = updated.find((s) => s.id === id);
    const newActive = target ? target.isActive !== false : true;
    showToast(`Software '${target?.name || id}' ${newActive ? 'activated' : 'deactivated'}.`, 'success');
  };

  const deleteSoftware = async (id: string): Promise<void> => {
    const target = softwareList.find((s) => s.id === id);
    await environmentDetailsService.deleteSoftware(id);
    setSoftwareList(environmentDetailsService.getSoftware());
    showToast(`Software '${target?.name || id}' deactivated.`, 'info');
  };

  // --- ENVIRONMENT PROFILES ACTIONS ---
  const addEnvironmentProfile = async (profileData: Omit<EnvironmentProfile, 'id' | 'updatedAt'>): Promise<EnvironmentProfile> => {
    const newProfile = await environmentDetailsService.createProfile(profileData);
    const updated = [newProfile, ...environmentProfiles.filter((p) => p.id !== newProfile.id)];
    setEnvironmentProfiles(updated);
    environmentDetailsService.saveProfiles(updated);
    showToast(`Environment Profile '${newProfile.name}' created!`, 'success');
    return newProfile;
  };

  const updateEnvironmentProfile = async (id: string, profileData: Partial<EnvironmentProfile>): Promise<void> => {
    await environmentDetailsService.updateProfile(id, profileData);
    const updated = environmentProfiles.map((p) =>
      p.id === id
        ? { ...p, ...profileData, updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) }
        : p
    );
    setEnvironmentProfiles(updated);
    environmentDetailsService.saveProfiles(updated);
    showToast('Environment Profile updated.', 'success');
  };

  const toggleEnvironmentProfile = async (id: string): Promise<void> => {
    const target = environmentProfiles.find((p) => p.id === id);
    if (!target) return;

    // If currently active and user is deactivating, check active reservations
    const isCurrentlyActive = target.isActive !== false;
    if (isCurrentlyActive) {
      const activeRes = (bookings || []).filter((b) => {
        if (!b.status) return true;
        const st = String(b.status).toUpperCase();
        const isNotCancelled = st !== 'CANCELLED' && st !== 'REJECTED' && st !== 'AUTO_REJECTED';
        const matchesEnv =
          (b.environmentId && b.environmentId === target.id) ||
          (b.environmentName && b.environmentName.toLowerCase().trim() === target.name.toLowerCase().trim());
        return isNotCancelled && matchesEnv;
      });

      if (activeRes.length > 0) {
        const errorMsg = `Environment '${target.name}' has one or more confirmed, future, or conflicting reservations. Hence, this environment cannot be deactivated.`;
        throw new Error(errorMsg);
      }
    }

    const updated = await environmentDetailsService.toggleProfile(id);
    setEnvironmentProfiles(updated);
    const newActive = updated.find((p) => p.id === id)?.isActive !== false;
    showToast(`Environment Profile '${target.name}' ${newActive ? 'activated' : 'deactivated'}.`, 'success');
  };

  const deleteEnvironmentProfile = async (id: string): Promise<void> => {
    const target = environmentProfiles.find((p) => p.id === id);
    await environmentDetailsService.deleteProfile(id);
    const updated = environmentProfiles.map((p) => (p.id === id ? { ...p, isActive: false } : p));
    setEnvironmentProfiles(updated);
    environmentDetailsService.saveProfiles(updated);
    showToast(`Environment Profile '${target?.name || id}' deactivated.`, 'info');
  };

  // Integration Action Handlers
  const updateIntegrationConfig = (id: string, update: Partial<IntegrationConfig>) => {
    const updated = integrationService.updateConfig(id, update);
    setIntegrationConfigs(updated);
    showToast('Integration configuration updated successfully.', 'success');
  };

  const testIntegrationConnection = async (provider: IntegrationProvider) => {
    const res = await integrationService.testConnection(provider);
    setIntegrationConfigs(integrationService.getConfigs());
    setIntegrationLogs(integrationService.getLogs());
    if (res.success) {
      showToast(`${provider} connected successfully! (${res.latencyMs}ms)`, 'success');
    } else {
      showToast(`${provider} connection failed: ${res.message}`, 'error');
    }
    return res;
  };

  const simulateCICDEvent = async (payload: CICDPipelineEventPayload) => {
    const res = await integrationService.simulateCICDPipelineEvent(payload);
    setIntegrationLogs(integrationService.getLogs());
    if (res.success && res.targetEnvironmentId) {
      updateEnvironmentProfile(res.targetEnvironmentId, {
        status: res.mappedStatus as any,
      });
      showToast(`CI/CD Event '${payload.eventType}' updated Environment ID '${res.targetEnvironmentId}' -> ${res.mappedStatus}`, 'info');
    } else {
      showToast(res.message, res.success ? 'success' : 'error');
    }
  };

  const syncITSMTicket = async (payload: ITSMTicketSyncPayload) => {
    const res = await integrationService.syncITSMTicket(payload);
    setIntegrationLogs(integrationService.getLogs());
    if (res.success && payload.temIncidentId) {
      const targetInc = incidents.find((i) => i.id === payload.temIncidentId);
      if (targetInc && res.syncedPayload) {
        setIncidents((prev) =>
          prev.map((inc) =>
            inc.id === payload.temIncidentId
              ? {
                  ...inc,
                  status: res.syncedPayload?.status as any || inc.status,
                  description: `${inc.description || ''}\n\n[Synced via ${payload.provider} ${payload.externalKeyOrNumber}]: ${payload.title}`,
                }
              : inc
          )
        );
      }
    }
    showToast(res.message, res.success ? 'success' : 'error');
  };

  const reconcileIntegrations = async () => {
    setIsLoading(true);
    try {
      const res = await integrationService.reconcileAll();
      setIntegrationConfigs(integrationService.getConfigs());
      setIntegrationLogs(integrationService.getLogs());
      showToast(res.message, 'success');
    } catch (err: any) {
      showToast('Reconciliation scan failed', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const clearIntegrationLogs = () => {
    integrationService.clearLogs();
    setIntegrationLogs([]);
    showToast('Integration activity logs cleared.', 'info');
  };

  const executeRunbook = async (id: string, targetEnvId?: string) => {
    setIsLoading(true);
    try {
      const res = await runbookService.executeRunbook(id, targetEnvId);
      setRunbooks((prev) =>
        prev.map((r) => (r.id === id ? { ...r, lastExecuted: new Date().toLocaleString('en-US') } : r))
      );
      showToast(`Runbook executed successfully at ${res.executedAt}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Runbook execution failed', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <TEMContext.Provider
      value={{
        environments,
        incidents,
        releases,
        bookings,
        runbooks,
        businessUnits,
        projects,
        components,
        applications,
        servers,
        softwareList,
        environmentProfiles,
        integrationConfigs,
        integrationLogs,
        integrationHealth,
        metrics,
        toasts,
        isLoading,
        addEnvironment,
        addBooking,
        updateBooking,
        approveBooking,
        cancelBooking,
        rejectBooking,
        addRelease,
        addIncident,
        addBusinessUnit,
        updateBusinessUnit,
        toggleBusinessUnit,
        addProject,
        updateProject,
        toggleProject,
        addComponent,
        updateComponent,
        toggleComponent,
        addApplication,
        updateApplication,
        toggleApplication,
        addServer,
        updateServer,
        toggleServer,
        deleteServer,
        addSoftware,
        updateSoftware,
        toggleSoftware,
        deleteSoftware,
        addEnvironmentProfile,
        updateEnvironmentProfile,
        toggleEnvironmentProfile,
        deleteEnvironmentProfile,
        updateIntegrationConfig,
        testIntegrationConnection,
        simulateCICDEvent,
        syncITSMTicket,
        reconcileIntegrations,
        clearIntegrationLogs,
        executeRunbook,
        showToast,
        removeToast,
        refreshData,
      }}
    >
      {children}
    </TEMContext.Provider>
  );
};

export const useTEM = () => {
  const context = useContext(TEMContext);
  if (!context) {
    throw new Error('useTEM must be used within a TEMProvider');
  }
  return context;
};
