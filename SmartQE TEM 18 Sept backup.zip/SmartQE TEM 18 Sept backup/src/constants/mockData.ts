import { Environment, Incident, Release, Booking, Runbook, OverviewMetrics } from '../types';

export const INITIAL_ENVIRONMENTS: Environment[] = [];

export const INITIAL_INCIDENTS: Incident[] = [];

export const INITIAL_RELEASES: Release[] = [];

export const INITIAL_BOOKINGS: Booking[] = [];

export const INITIAL_RUNBOOKS: Runbook[] = [];

export const INITIAL_METRICS: OverviewMetrics = {
  totalEnvironments: 0,
  healthyEnvironments: 0,
  activeBookings: 0,
  utilizationRate: 0,
  openIncidents: 0,
  downEnvironmentsCount: 0,
  upcomingReleases: 0,
  trackedReleasesCount: 0,
  cpuAverage: 0,
  memoryAverage: 0,
  storageAverage: 0,
};
