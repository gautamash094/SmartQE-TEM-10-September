import { fetchApi } from './apiClient';
import { authService } from './authService';

export interface BusinessUnit {
  id: string;
  name: string;
  code: string;
  lead?: string;
  description?: string;
  status?: string;
  isActive?: boolean;
  isVisible?: boolean;
  createdBy?: string;
  ownerId?: string;
}

export interface Project {
  id: string;
  name: string;
  code: string;
  businessUnit: string;
  lead?: string;
  status?: string;
  isActive?: boolean;
  isVisible?: boolean;
  createdBy?: string;
  ownerId?: string;
}

export interface ComponentEntity {
  id: string;
  name: string;
  code?: string;
  description?: string;
  businessUnit: string;
  projectName?: string;
  endpointUrl?: string;
  status?: string;
  isActive?: boolean;
  isVisible?: boolean;
  createdBy?: string;
  ownerId?: string;
}

export interface ApplicationEntity {
  id: string;
  name: string;
  code: string;
  businessUnit: string;
  projectName: string;
  componentName: string;
  owner: string;
  status?: string;
  isActive?: boolean;
  isVisible?: boolean;
  createdBy?: string;
  ownerId?: string;
}

export const INITIAL_BUSINESS_UNITS: BusinessUnit[] = [
  { id: '7286e4db-20ff-49d9-bafa-822945863dfb', name: 'Ash_BU1', code: 'ASH1', lead: 'Ashish Gautam', description: 'Ashish BU', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'ashish', ownerId: 'user-1788328' },
  { id: 'ae7d4571-5377-431f-a364-676b4dc5ce8c', name: 'Pratyush111', code: 'P111', lead: 'Ashish Gautam', description: 'Ashish BU 2', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'ashish', ownerId: 'user-1788328' },
  { id: 'c79dc699-6f1f-4079-84ba-643d982e1d32', name: 'AkashBU', code: 'AKASH1', lead: 'Akash Verma', description: 'Akash BU', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'akash', ownerId: 'user-1788331' },
  { id: '7710368c-5a44-4a6a-8a72-f55d0b4ede70', name: 'UTK_BU', code: 'UTK1', lead: 'utk tiwari', description: 'Utk BU', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'utk', ownerId: 'user-1788349' },
  { id: '8f6ca06d-9cdd-4718-8140-9c4f4634fe9a', name: 'qqqqqqqqqqqqqqqqq', code: 'QQQ', lead: 'System Admin', description: '', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'admin', ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd' },
  { id: 'bf2d4091-e7a1-4efc-9a3f-881442a1127e', name: 'qwerty', code: 'QWE', lead: 'System Admin', description: '', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'admin', ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd' },
  { id: 'ed65a71e-b816-4fd9-a918-912605dfa16e', name: 'poiuytre', code: 'POI', lead: 'System Admin', description: '', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'admin', ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd' },
  { id: 'db424309-0a4a-4d8f-8133-fd74f10bb21b', name: 'Pratyush', code: 'PRAT', lead: 'System Admin', description: '', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'admin', ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd' },
];

export const INITIAL_PROJECTS: Project[] = [
  { id: '7a05ba62-a5e2-4ea5-8025-b4aa366a7b3c', name: 'AshProject1', code: 'PRJ1', businessUnit: 'Ash_BU1', lead: 'Ashish Gautam', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'ashish', ownerId: 'user-1788328' },
  { id: 'a781216d-3e6f-4d6b-bfa1-e221d8b67119', name: 'Akash_Project', code: 'AKASHPRJ', businessUnit: 'AkashBU', lead: 'Akash Verma', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'akash', ownerId: 'user-1788331' },
  { id: '3c1bc917-2f3b-48ae-94a1-b6845c1171a8', name: 'ppppppppppp', code: 'PPP', businessUnit: 'qqqqqqqqqqqqqqqqq', lead: 'System Admin', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'admin', ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd' },
];

export const INITIAL_COMPONENTS: ComponentEntity[] = [
  { id: '2ef0b77e-2cf0-4bb5-8664-d75faeb55f00', name: 'AshComponent1', code: 'COMP1', description: 'Ashish component', businessUnit: 'Ash_BU1', projectName: 'AshProject1', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'ashish', ownerId: 'user-1788328' },
  { id: 'a564528c-612b-430f-88d7-f3dd5ff8c05d', name: 'Akash_Component', code: 'AKASHCOMP', description: 'Akash component', businessUnit: 'AkashBU', projectName: 'Akash_Project', endpointUrl: 'https://api.akash.smartqe.internal/v1', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'akash', ownerId: 'user-1788331' },
  { id: '2219e574-4af0-4914-8668-f022309fd852', name: 'cccccccccccc', code: '11111', description: '', businessUnit: 'qqqqqqqqqqqqqqqqq', projectName: 'ppppppppppp', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'admin', ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd' },
];

export const INITIAL_APPLICATIONS: ApplicationEntity[] = [
  { id: '94f2718f-f140-45e5-8120-9bdcee4ea4cd', name: 'AshApp', code: 'TEST', businessUnit: 'Ash_BU1', projectName: 'AshProject1', componentName: 'AshComponent1', owner: 'Shweta P', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'ashish', ownerId: 'user-1788328' },
  { id: 'a6bd8a91-38eb-4326-918e-845703c08400', name: 'Akash_Application', code: 'APP1', businessUnit: 'AkashBU', projectName: 'Akash_Project', componentName: 'Akash_Component', owner: 'Shweta P', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'akash', ownerId: 'user-1788331' },
  { id: '17698d8e-1555-4909-9466-ddbca296ac71', name: 'aaaaaaaaaaaa', code: '11', businessUnit: 'qqqqqqqqqqqqqqqqq', projectName: 'ppppppppppp', componentName: 'cccccccccccc', owner: '11qqq', status: 'ACTIVE', isActive: true, isVisible: true, createdBy: 'admin', ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd' },
];

// ── LocalStorage Keys (versioned to avoid stale schema conflicts) ──
const BU_STORAGE_KEY = 'smartqe_tem_business_units_v1';
const PROJ_STORAGE_KEY = 'smartqe_tem_projects_v1';
const COMP_STORAGE_KEY = 'smartqe_tem_components_v1';
const APP_STORAGE_KEY = 'smartqe_tem_applications_v1';

// ── Storage Helpers ──
function loadFromStorage<T extends { id: string }>(key: string, defaults: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Merge defaults to ensure no baseline entities are lost
        const map = new Map<string, T>();
        defaults.forEach(d => map.set(d.id, d));
        parsed.forEach((p: T) => { if (p && p.id) map.set(p.id, p); });
        return Array.from(map.values());
      }
    }
  } catch {}
  return defaults;
}

function saveToStorage<T>(key: string, data: T[]): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {}
}

function filterForSessionUser<T extends { ownerId?: string; createdBy?: string }>(items: T[]): T[] {
  const sessionUser = authService.getCurrentSessionUser();
  if (!sessionUser) return items;
  const isSuperAdmin =
    sessionUser.isSuperAdmin ||
    sessionUser.username?.toLowerCase() === 'admin' ||
    (sessionUser.roles || []).some((r: any) =>
      ['super admin', 'superadmin', 'admin'].includes(r.name?.toLowerCase()?.trim()) && sessionUser.username?.toLowerCase() === 'admin'
    );
  if (isSuperAdmin) return items;

  const userId = sessionUser.id;
  const username = (sessionUser.username || '').toLowerCase().trim();
  const fullName = (sessionUser.fullName || '').toLowerCase().trim();

  return items.filter((item) => {
    const ownerId = item.ownerId || '';
    const createdBy = (item.createdBy || '').toLowerCase().trim();
    return (
      (ownerId && ownerId === userId) ||
      (createdBy && (createdBy === username || createdBy === fullName))
    );
  });
}

export const portfolioService = {
  // ── Business Units ──
  async getBusinessUnits(): Promise<BusinessUnit[]> {
    try {
      const apiData = await fetchApi<any[]>('/portfolio/business-units');
      if (apiData && Array.isArray(apiData)) {
        const mapped: BusinessUnit[] = apiData.map(b => {
          const isActive = b.isActive !== undefined ? b.isActive : (b.is_active !== undefined ? b.is_active : b.status !== 'INACTIVE');
          return {
            id: b.id,
            name: b.name,
            code: b.code,
            lead: b.lead,
            description: b.description,
            status: b.status || (isActive ? 'ACTIVE' : 'INACTIVE'),
            isActive,
            createdBy: b.createdBy || b.created_by,
            ownerId: b.ownerId || b.owner_id
          };
        });
        const stored = loadFromStorage<BusinessUnit>(BU_STORAGE_KEY, [...INITIAL_BUSINESS_UNITS]);
        const map = new Map<string, BusinessUnit>();
        stored.forEach(s => map.set(s.id, s));
        mapped.forEach(m => map.set(m.id, m));
        saveToStorage(BU_STORAGE_KEY, Array.from(map.values()));
        return mapped;
      }
    } catch {}
    // Backend offline — read from localStorage and filter
    const local = loadFromStorage<BusinessUnit>(BU_STORAGE_KEY, [...INITIAL_BUSINESS_UNITS]);
    const prepared = local.map(b => ({
      ...b,
      isActive: b.isActive !== false,
      status: b.status || (b.isActive !== false ? 'ACTIVE' : 'INACTIVE')
    }));
    return filterForSessionUser(prepared);
  },

  async createBusinessUnit(bu: Omit<BusinessUnit, 'id'>): Promise<BusinessUnit> {
    const sessionUser = authService.getCurrentSessionUser();
    const isActive = bu.isActive !== false;
    const newBU: BusinessUnit = {
      ...bu,
      id: `bu-${Date.now()}`,
      isActive,
      status: bu.status || (isActive ? 'ACTIVE' : 'INACTIVE'),
      createdBy: sessionUser?.fullName || sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id
    };
    try {
      const apiData = await fetchApi<any>('/portfolio/business-units', {
        method: 'POST',
        body: JSON.stringify({
          name: bu.name,
          code: bu.code,
          lead: bu.lead,
          description: bu.description,
          status: newBU.status,
          isActive: newBU.isActive
        })
      });
      if (apiData) {
        const created: BusinessUnit = {
          id: apiData.id,
          name: apiData.name,
          code: apiData.code,
          lead: apiData.lead,
          description: apiData.description,
          status: apiData.status || (apiData.isActive !== false ? 'ACTIVE' : 'INACTIVE'),
          isActive: apiData.isActive !== undefined ? apiData.isActive : (apiData.is_active !== undefined ? apiData.is_active : true),
          createdBy: apiData.createdBy || apiData.created_by || newBU.createdBy,
          ownerId: apiData.ownerId || apiData.owner_id || newBU.ownerId
        };
        const existing = loadFromStorage<BusinessUnit>(BU_STORAGE_KEY, [...INITIAL_BUSINESS_UNITS]);
        saveToStorage(BU_STORAGE_KEY, [...existing.filter(b => b.id !== created.id), created]);
        return created;
      }
    } catch {}
    const existing = loadFromStorage<BusinessUnit>(BU_STORAGE_KEY, [...INITIAL_BUSINESS_UNITS]);
    saveToStorage(BU_STORAGE_KEY, [...existing.filter(b => b.id !== newBU.id), newBU]);
    return newBU;
  },

  async toggleBusinessUnit(id: string): Promise<BusinessUnit[]> {
    const existing = loadFromStorage<BusinessUnit>(BU_STORAGE_KEY, [...INITIAL_BUSINESS_UNITS]);
    const target = existing.find(b => b.id === id);
    if (!target) return existing;

    const newActive = !(target.isActive !== false);
    const updated: BusinessUnit = {
      ...target,
      isActive: newActive,
      status: newActive ? 'ACTIVE' : 'INACTIVE'
    };

    try {
      await fetchApi(`/portfolio/business-units/${id}/toggle-status`, {
        method: 'PATCH'
      });
    } catch {}

    const updatedList = existing.map(b => b.id === id ? updated : b);
    saveToStorage(BU_STORAGE_KEY, updatedList);
    return updatedList;
  },

  // ── Projects ──
  async getProjects(): Promise<Project[]> {
    try {
      const apiData = await fetchApi<any[]>('/portfolio/projects');
      if (apiData && Array.isArray(apiData)) {
        const mapped: Project[] = apiData.map(p => {
          const isActive = p.isActive !== undefined ? p.isActive : (p.is_active !== undefined ? p.is_active : p.status !== 'INACTIVE');
          return {
            id: p.id,
            name: p.name,
            code: p.code,
            businessUnit: p.business_unit || p.businessUnit,
            lead: p.lead,
            status: p.status || (isActive ? 'ACTIVE' : 'INACTIVE'),
            isActive,
            createdBy: p.createdBy || p.created_by,
            ownerId: p.ownerId || p.owner_id
          };
        });
        const stored = loadFromStorage<Project>(PROJ_STORAGE_KEY, [...INITIAL_PROJECTS]);
        const map = new Map<string, Project>();
        stored.forEach(s => map.set(s.id, s));
        mapped.forEach(m => map.set(m.id, m));
        saveToStorage(PROJ_STORAGE_KEY, Array.from(map.values()));
        return mapped;
      }
    } catch {}
    const local = loadFromStorage<Project>(PROJ_STORAGE_KEY, [...INITIAL_PROJECTS]);
    const prepared = local.map(p => ({
      ...p,
      isActive: p.isActive !== false,
      status: p.status || (p.isActive !== false ? 'ACTIVE' : 'INACTIVE')
    }));
    return filterForSessionUser(prepared);
  },

  async createProject(proj: Omit<Project, 'id'>): Promise<Project> {
    const sessionUser = authService.getCurrentSessionUser();
    const isActive = proj.isActive !== false;
    const newProj: Project = {
      ...proj,
      id: `proj-${Date.now()}`,
      isActive,
      status: proj.status || (isActive ? 'ACTIVE' : 'INACTIVE'),
      createdBy: sessionUser?.fullName || sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id
    };
    try {
      const apiData = await fetchApi<any>('/portfolio/projects', {
        method: 'POST',
        body: JSON.stringify({
          name: proj.name,
          code: proj.code,
          business_unit: proj.businessUnit,
          lead: proj.lead,
          status: newProj.status,
          isActive: newProj.isActive
        })
      });
      if (apiData) {
        const created: Project = {
          id: apiData.id,
          name: apiData.name,
          code: apiData.code,
          businessUnit: apiData.business_unit || apiData.businessUnit,
          lead: apiData.lead,
          status: apiData.status || (apiData.isActive !== false ? 'ACTIVE' : 'INACTIVE'),
          isActive: apiData.isActive !== undefined ? apiData.isActive : (apiData.is_active !== undefined ? apiData.is_active : true),
          createdBy: apiData.createdBy || apiData.created_by || newProj.createdBy,
          ownerId: apiData.ownerId || apiData.owner_id || newProj.ownerId
        };
        const existing = loadFromStorage<Project>(PROJ_STORAGE_KEY, [...INITIAL_PROJECTS]);
        saveToStorage(PROJ_STORAGE_KEY, [...existing.filter(p => p.id !== created.id), created]);
        return created;
      }
    } catch {}
    const existing = loadFromStorage<Project>(PROJ_STORAGE_KEY, [...INITIAL_PROJECTS]);
    saveToStorage(PROJ_STORAGE_KEY, [...existing.filter(p => p.id !== newProj.id), newProj]);
    return newProj;
  },

  async toggleProject(id: string): Promise<Project[]> {
    const existing = loadFromStorage<Project>(PROJ_STORAGE_KEY, [...INITIAL_PROJECTS]);
    const target = existing.find(p => p.id === id);
    if (!target) return existing;

    const newActive = !(target.isActive !== false);
    const updated: Project = {
      ...target,
      isActive: newActive,
      status: newActive ? 'ACTIVE' : 'INACTIVE'
    };

    try {
      await fetchApi(`/portfolio/projects/${id}/toggle-status`, {
        method: 'PATCH'
      });
    } catch {}

    const updatedList = existing.map(p => p.id === id ? updated : p);
    saveToStorage(PROJ_STORAGE_KEY, updatedList);
    return updatedList;
  },

  // ── Components ──
  async getComponents(): Promise<ComponentEntity[]> {
    try {
      const apiData = await fetchApi<any[]>('/portfolio/components');
      if (apiData && Array.isArray(apiData)) {
        const mapped: ComponentEntity[] = apiData.map(c => {
          const isActive = c.isActive !== undefined ? c.isActive : (c.is_active !== undefined ? c.is_active : c.status !== 'INACTIVE');
          return {
            id: c.id,
            name: c.name,
            code: c.code,
            description: c.description || '',
            businessUnit: c.business_unit || c.businessUnit,
            projectName: c.project_name || c.projectName,
            endpointUrl: c.endpoint_url || c.endpointUrl || '',
            status: c.status || (isActive ? 'ACTIVE' : 'INACTIVE'),
            isActive,
            createdBy: c.createdBy || c.created_by,
            ownerId: c.ownerId || c.owner_id
          };
        });
        const stored = loadFromStorage<ComponentEntity>(COMP_STORAGE_KEY, [...INITIAL_COMPONENTS]);
        const map = new Map<string, ComponentEntity>();
        stored.forEach(s => map.set(s.id, s));
        mapped.forEach(m => map.set(m.id, m));
        saveToStorage(COMP_STORAGE_KEY, Array.from(map.values()));
        return mapped;
      }
    } catch {}
    const local = loadFromStorage<ComponentEntity>(COMP_STORAGE_KEY, [...INITIAL_COMPONENTS]);
    const prepared = local.map(c => ({
      ...c,
      isActive: c.isActive !== false,
      status: c.status || (c.isActive !== false ? 'ACTIVE' : 'INACTIVE')
    }));
    return filterForSessionUser(prepared);
  },

  async createComponent(compData: Omit<ComponentEntity, 'id'>): Promise<ComponentEntity> {
    const sessionUser = authService.getCurrentSessionUser();
    const isActive = compData.isActive !== false;
    const newComp: ComponentEntity = {
      ...compData,
      id: `comp-${Date.now()}`,
      isActive,
      status: compData.status || (isActive ? 'ACTIVE' : 'INACTIVE'),
      createdBy: sessionUser?.fullName || sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id
    };
    try {
      const apiData = await fetchApi<any>('/portfolio/components', {
        method: 'POST',
        body: JSON.stringify({
          name: compData.name,
          code: compData.code,
          description: compData.description,
          business_unit: compData.businessUnit,
          project_name: compData.projectName,
          endpoint_url: compData.endpointUrl,
          status: newComp.status,
          isActive: newComp.isActive
        })
      });
      if (apiData) {
        const created: ComponentEntity = {
          id: apiData.id,
          name: apiData.name,
          code: apiData.code,
          description: apiData.description || '',
          businessUnit: apiData.business_unit || apiData.businessUnit,
          projectName: apiData.project_name || apiData.projectName,
          endpointUrl: apiData.endpoint_url || apiData.endpointUrl || '',
          status: apiData.status || (apiData.isActive !== false ? 'ACTIVE' : 'INACTIVE'),
          isActive: apiData.isActive !== undefined ? apiData.isActive : (apiData.is_active !== undefined ? apiData.is_active : true),
          createdBy: apiData.createdBy || apiData.created_by || newComp.createdBy,
          ownerId: apiData.ownerId || apiData.owner_id || newComp.ownerId
        };
        const existing = loadFromStorage<ComponentEntity>(COMP_STORAGE_KEY, [...INITIAL_COMPONENTS]);
        saveToStorage(COMP_STORAGE_KEY, [...existing.filter(c => c.id !== created.id), created]);
        return created;
      }
    } catch {}
    const existing = loadFromStorage<ComponentEntity>(COMP_STORAGE_KEY, [...INITIAL_COMPONENTS]);
    saveToStorage(COMP_STORAGE_KEY, [...existing.filter(c => c.id !== newComp.id), newComp]);
    return newComp;
  },

  async toggleComponent(id: string): Promise<ComponentEntity[]> {
    const existing = loadFromStorage<ComponentEntity>(COMP_STORAGE_KEY, [...INITIAL_COMPONENTS]);
    const target = existing.find(c => c.id === id);
    if (!target) return existing;

    const newActive = !(target.isActive !== false);
    const updated: ComponentEntity = {
      ...target,
      isActive: newActive,
      status: newActive ? 'ACTIVE' : 'INACTIVE'
    };

    try {
      await fetchApi(`/portfolio/components/${id}/toggle-status`, {
        method: 'PATCH'
      });
    } catch {}

    const updatedList = existing.map(c => c.id === id ? updated : c);
    saveToStorage(COMP_STORAGE_KEY, updatedList);
    return updatedList;
  },

  async updateComponent(id: string, compData: Partial<ComponentEntity>): Promise<ComponentEntity> {
    const existing = loadFromStorage<ComponentEntity>(COMP_STORAGE_KEY, [...INITIAL_COMPONENTS]);
    const target = existing.find(c => c.id === id);
    if (!target) {
      throw new Error(`Component with ID ${id} not found.`);
    }

    const updated: ComponentEntity = {
      ...target,
      ...compData,
      id,
      isActive: compData.isActive !== undefined ? compData.isActive : target.isActive,
      status: compData.status || target.status
    };

    try {
      await fetchApi<any>(`/portfolio/components/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: updated.name,
          code: updated.code,
          description: updated.description,
          business_unit: updated.businessUnit,
          project_name: updated.projectName,
          endpoint_url: updated.endpointUrl,
          status: updated.status,
          isActive: updated.isActive
        })
      });
    } catch {}

    const updatedList = existing.map(c => c.id === id ? updated : c);
    saveToStorage(COMP_STORAGE_KEY, updatedList);

    return updated;
  },

  // ── Applications ──
  async getApplications(): Promise<ApplicationEntity[]> {
    try {
      const apiData = await fetchApi<any[]>('/portfolio/applications');
      if (apiData && Array.isArray(apiData)) {
        const mapped: ApplicationEntity[] = apiData.map(a => {
          const isActive = a.isActive !== undefined ? a.isActive : (a.is_active !== undefined ? a.is_active : a.status !== 'INACTIVE');
          return {
            id: a.id,
            name: a.name,
            code: a.code,
            businessUnit: a.business_unit || a.businessUnit,
            projectName: a.project_name || a.projectName,
            componentName: a.component_name || a.componentName,
            owner: a.owner,
            status: a.status || (isActive ? 'ACTIVE' : 'INACTIVE'),
            isActive,
            createdBy: a.createdBy || a.created_by,
            ownerId: a.ownerId || a.owner_id
          };
        });
        const stored = loadFromStorage<ApplicationEntity>(APP_STORAGE_KEY, [...INITIAL_APPLICATIONS]);
        const map = new Map<string, ApplicationEntity>();
        stored.forEach(s => map.set(s.id, s));
        mapped.forEach(m => map.set(m.id, m));
        saveToStorage(APP_STORAGE_KEY, Array.from(map.values()));
        return mapped;
      }
    } catch {}
    const local = loadFromStorage<ApplicationEntity>(APP_STORAGE_KEY, [...INITIAL_APPLICATIONS]);
    const prepared = local.map(a => ({
      ...a,
      isActive: a.isActive !== false,
      status: a.status || (a.isActive !== false ? 'ACTIVE' : 'INACTIVE')
    }));
    return filterForSessionUser(prepared);
  },

  async createApplication(appData: Omit<ApplicationEntity, 'id'>): Promise<ApplicationEntity> {
    const sessionUser = authService.getCurrentSessionUser();
    const isActive = appData.isActive !== false;
    const newApp: ApplicationEntity = {
      ...appData,
      id: `app-${Date.now()}`,
      isActive,
      status: appData.status || (isActive ? 'ACTIVE' : 'INACTIVE'),
      createdBy: sessionUser?.fullName || sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id
    };
    try {
      const apiData = await fetchApi<any>('/portfolio/applications', {
        method: 'POST',
        body: JSON.stringify({
          name: appData.name,
          code: appData.code,
          business_unit: appData.businessUnit,
          project_name: appData.projectName,
          component_name: appData.componentName,
          owner: appData.owner,
          status: newApp.status,
          isActive: newApp.isActive
        })
      });
      if (apiData) {
        const created: ApplicationEntity = {
          id: apiData.id,
          name: apiData.name,
          code: apiData.code,
          businessUnit: apiData.business_unit || apiData.businessUnit,
          projectName: apiData.project_name || apiData.projectName,
          componentName: apiData.component_name || apiData.componentName,
          owner: apiData.owner,
          status: apiData.status || (apiData.isActive !== false ? 'ACTIVE' : 'INACTIVE'),
          isActive: apiData.isActive !== undefined ? apiData.isActive : (apiData.is_active !== undefined ? apiData.is_active : true),
          createdBy: apiData.createdBy || apiData.created_by || newApp.createdBy,
          ownerId: apiData.ownerId || apiData.owner_id || newApp.ownerId
        };
        const existing = loadFromStorage<ApplicationEntity>(APP_STORAGE_KEY, [...INITIAL_APPLICATIONS]);
        saveToStorage(APP_STORAGE_KEY, [...existing.filter(a => a.id !== created.id), created]);
        return created;
      }
    } catch {}
    const existing = loadFromStorage<ApplicationEntity>(APP_STORAGE_KEY, [...INITIAL_APPLICATIONS]);
    saveToStorage(APP_STORAGE_KEY, [...existing.filter(a => a.id !== newApp.id), newApp]);
    return newApp;
  },

  async toggleApplication(id: string): Promise<ApplicationEntity[]> {
    const existing = loadFromStorage<ApplicationEntity>(APP_STORAGE_KEY, [...INITIAL_APPLICATIONS]);
    const target = existing.find(a => a.id === id);
    if (!target) return existing;

    const newActive = !(target.isActive !== false);
    const updated: ApplicationEntity = {
      ...target,
      isActive: newActive,
      status: newActive ? 'ACTIVE' : 'INACTIVE'
    };

    try {
      await fetchApi(`/portfolio/applications/${id}/toggle-status`, {
        method: 'PATCH'
      });
    } catch {}

    const updatedList = existing.map(a => a.id === id ? updated : a);
    saveToStorage(APP_STORAGE_KEY, updatedList);
    return updatedList;
  },

  // ── Edit / Update Business Unit ──
  async updateBusinessUnit(id: string, buData: Partial<BusinessUnit>): Promise<BusinessUnit> {
    const existing = loadFromStorage<BusinessUnit>(BU_STORAGE_KEY, [...INITIAL_BUSINESS_UNITS]);
    const target = existing.find(b => b.id === id);
    if (!target) {
      throw new Error(`Business Unit with ID ${id} not found.`);
    }

    const oldName = target.name;
    const updated: BusinessUnit = {
      ...target,
      ...buData,
      id,
      isActive: buData.isActive !== undefined ? buData.isActive : target.isActive,
      status: buData.status || target.status
    };

    try {
      await fetchApi<any>(`/portfolio/business-units/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updated)
      });
    } catch {}

    // Persist updated BU list
    const updatedList = existing.map(b => b.id === id ? updated : b);
    saveToStorage(BU_STORAGE_KEY, updatedList);

    // Cascading Relationship Update: If BU name changed, update child Projects, Components & Applications
    if (buData.name && oldName !== buData.name) {
      const projects = loadFromStorage<Project>(PROJ_STORAGE_KEY, [...INITIAL_PROJECTS]);
      const updatedProjects = projects.map(p =>
        p.businessUnit.toLowerCase() === oldName.toLowerCase() ? { ...p, businessUnit: buData.name! } : p
      );
      saveToStorage(PROJ_STORAGE_KEY, updatedProjects);

      const comps = loadFromStorage<ComponentEntity>(COMP_STORAGE_KEY, [...INITIAL_COMPONENTS]);
      const updatedComps = comps.map(c =>
        c.businessUnit.toLowerCase() === oldName.toLowerCase() ? { ...c, businessUnit: buData.name! } : c
      );
      saveToStorage(COMP_STORAGE_KEY, updatedComps);

      const apps = loadFromStorage<ApplicationEntity>(APP_STORAGE_KEY, [...INITIAL_APPLICATIONS]);
      const updatedApps = apps.map(a =>
        a.businessUnit.toLowerCase() === oldName.toLowerCase() ? { ...a, businessUnit: buData.name! } : a
      );
      saveToStorage(APP_STORAGE_KEY, updatedApps);
    }

    return updated;
  },

  // ── Edit / Update Project ──
  async updateProject(id: string, projData: Partial<Project>): Promise<Project> {
    const existing = loadFromStorage<Project>(PROJ_STORAGE_KEY, [...INITIAL_PROJECTS]);
    const target = existing.find(p => p.id === id);
    if (!target) {
      throw new Error(`Project with ID ${id} not found.`);
    }

    const oldName = target.name;
    const updated: Project = {
      ...target,
      ...projData,
      id,
      isActive: projData.isActive !== undefined ? projData.isActive : target.isActive,
      status: projData.status || target.status
    };

    try {
      await fetchApi<any>(`/portfolio/projects/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: updated.name,
          code: updated.code,
          business_unit: updated.businessUnit,
          lead: updated.lead,
          status: updated.status,
          isActive: updated.isActive
        })
      });
    } catch {}

    const updatedList = existing.map(p => p.id === id ? updated : p);
    saveToStorage(PROJ_STORAGE_KEY, updatedList);

    // Cascading Relationship Update: If Project name changed, update child Components & Applications
    if (projData.name && oldName !== projData.name) {
      const comps = loadFromStorage<ComponentEntity>(COMP_STORAGE_KEY, [...INITIAL_COMPONENTS]);
      const updatedComps = comps.map(c =>
        c.projectName && c.projectName.toLowerCase() === oldName.toLowerCase() ? { ...c, projectName: projData.name! } : c
      );
      saveToStorage(COMP_STORAGE_KEY, updatedComps);

      const apps = loadFromStorage<ApplicationEntity>(APP_STORAGE_KEY, [...INITIAL_APPLICATIONS]);
      const updatedApps = apps.map(a =>
        a.projectName && a.projectName.toLowerCase() === oldName.toLowerCase() ? { ...a, projectName: projData.name! } : a
      );
      saveToStorage(APP_STORAGE_KEY, updatedApps);
    }

    return updated;
  },

  // ── Edit / Update Application ──
  async updateApplication(id: string, appData: Partial<ApplicationEntity>): Promise<ApplicationEntity> {
    const existing = loadFromStorage<ApplicationEntity>(APP_STORAGE_KEY, [...INITIAL_APPLICATIONS]);
    const target = existing.find(a => a.id === id);
    if (!target) {
      throw new Error(`Application with ID ${id} not found.`);
    }

    const updated: ApplicationEntity = {
      ...target,
      ...appData,
      id,
      isActive: appData.isActive !== undefined ? appData.isActive : target.isActive,
      status: appData.status || target.status
    };

    try {
      await fetchApi<any>(`/portfolio/applications/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: updated.name,
          code: updated.code,
          business_unit: updated.businessUnit,
          project_name: updated.projectName,
          component_name: updated.componentName,
          owner: updated.owner,
          status: updated.status,
          isActive: updated.isActive
        })
      });
    } catch {}

    const updatedList = existing.map(a => a.id === id ? updated : a);
    saveToStorage(APP_STORAGE_KEY, updatedList);

    return updated;
  }
};
