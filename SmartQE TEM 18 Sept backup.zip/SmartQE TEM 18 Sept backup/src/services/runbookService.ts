import { Runbook } from '../types';
import { INITIAL_RUNBOOKS } from '../constants/mockData';
import { fetchApi } from './apiClient';

export const runbookService = {
  async getRunbooks(): Promise<Runbook[]> {
    const apiData = await fetchApi<any[]>('/runbooks');
    if (apiData && Array.isArray(apiData) && apiData.length > 0) {
      return apiData.map((rb) => ({
        id: rb.id,
        name: rb.name,
        category: rb.category,
        estimatedTimeMinutes: rb.estimated_time_minutes || rb.estimatedTimeMinutes || 5,
        lastExecuted: rb.last_executed || rb.lastExecuted || 'Never',
        targetEnvironmentId: rb.target_environment_id || rb.targetEnvironmentId,
        steps: rb.steps || [],
      }));
    }
    return [...INITIAL_RUNBOOKS];
  },

  async executeRunbook(id: string, targetEnvironmentId?: string): Promise<{ id: string; status: string; executedAt: string }> {
    const apiData = await fetchApi<any>(`/runbooks/${id}/execute`, {
      method: 'POST',
      body: JSON.stringify({ target_environment_id: targetEnvironmentId }),
    });

    return {
      id,
      status: apiData?.status || 'SUCCESS',
      executedAt: new Date().toLocaleString(),
    };
  },
};
