import { fetchApiStrict } from './apiClient';
import { portfolioService } from './portfolioService';
import { userService } from './userService';

export type TEMServiceCode =
  | 'ENVIRONMENT_RESERVATION'
  | 'ENVIRONMENT_PROVISIONING'
  | 'ENVIRONMENT_MONITORING'
  | 'ENVIRONMENT_HEALTH_CHECK';

export interface TEMServiceOption {
  code: TEMServiceCode;
  name: string;
  description: string;
}

export const TEM_SERVICES: TEMServiceOption[] = [
  {
    code: 'ENVIRONMENT_RESERVATION',
    name: 'Environment Reservation',
    description: 'Booking, scheduling and capacity allocation for test environments',
  },
  {
    code: 'ENVIRONMENT_PROVISIONING',
    name: 'Environment Provisioning',
    description: 'Automated deployment and provisioning of infrastructure stacks',
  },
  {
    code: 'ENVIRONMENT_MONITORING',
    name: 'Environment Monitoring',
    description: 'Real-time telemetry, readiness checks, and threshold monitoring',
  },
  {
    code: 'ENVIRONMENT_HEALTH_CHECK',
    name: 'Environment Health Check',
    description: 'Automated health and sanity assessment validation pipelines',
  },
];

export interface WorkflowApprover {
  id: string;
  workflowId: string;
  userId: string;
  workflowOrder: number;
  username?: string;
  fullName?: string;
  email?: string;
  createdAt: string;
  createdBy: string;
}

export interface Workflow {
  id: string;
  buId: string;
  buName?: string;
  buCode?: string;
  environmentId: string;
  environmentName?: string;
  applicationId: string;
  applicationName?: string;
  serviceCode: TEMServiceCode;
  serviceName: string;
  approvers: WorkflowApprover[];
  approverCount: number;
  isActive: boolean;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  createdBy: string;
  updatedAt: string;
  modifiedBy: string;
}

export interface WorkflowApproverInput {
  userId: string;
  workflowOrder: number;
}

export interface WorkflowCreatePayload {
  buId: string;
  environmentId: string;
  applicationId: string;
  serviceCode: TEMServiceCode;
  approvers: WorkflowApproverInput[];
  isActive?: boolean;
}

export interface WorkflowUpdatePayload {
  buId?: string;
  environmentId?: string;
  applicationId?: string;
  serviceCode?: TEMServiceCode;
  approvers?: WorkflowApproverInput[];
  isActive?: boolean;
  status?: 'ACTIVE' | 'INACTIVE';
}

export interface WorkflowExecutionStep {
  id: string;
  executionId: string;
  userId: string;
  username?: string;
  fullName?: string;
  workflowOrder: number;
  status: 'WAITING' | 'PENDING' | 'APPROVED' | 'REJECTED';
  actionBy?: string;
  actionAt?: string;
  comments?: string;
}

export interface WorkflowExecution {
  id: string;
  workflowId?: string;
  entityType: string;
  entityId: string;
  currentStepOrder: number;
  totalSteps: number;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  steps: WorkflowExecutionStep[];
  createdAt: string;
  updatedAt: string;
}

const WORKFLOWS_STORAGE_KEY = 'smartqe_tem_workflows_v1';
const WORKFLOW_EXECS_STORAGE_KEY = 'smartqe_tem_workflow_executions_v1';

function isNetworkError(err: any): boolean {
  if (!err) return false;
  const msg = (err.message || String(err)).toLowerCase();
  return (
    msg.includes('failed to fetch') ||
    msg.includes('networkerror') ||
    msg.includes('network error') ||
    msg.includes('load failed') ||
    msg.includes('connection refused') ||
    msg.includes('aborterror')
  );
}

class WorkflowService {
  private getLocalWorkflows(): Workflow[] {
    try {
      const raw = localStorage.getItem(WORKFLOWS_STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch {}
    return [];
  }

  private saveLocalWorkflows(workflows: Workflow[]): void {
    try {
      localStorage.setItem(WORKFLOWS_STORAGE_KEY, JSON.stringify(workflows));
    } catch {}
  }

  private normalizeWorkflow(data: any): Workflow {
    const rawApprovers = data.approvers || [];
    const approvers: WorkflowApprover[] = rawApprovers.map((a: any) => ({
      id: a.id || `approver-${Math.random().toString(36).substring(2, 9)}`,
      workflowId: a.workflow_id || a.workflowId || data.id,
      userId: a.user_id || a.userId,
      workflowOrder: a.workflow_order !== undefined ? a.workflow_order : a.workflowOrder,
      username: a.username,
      fullName: a.full_name || a.fullName,
      email: a.email,
      createdAt: a.created_at || a.createdAt || new Date().toISOString(),
      createdBy: a.created_by || a.createdBy || 'Super Admin',
    }));

    return {
      id: data.id,
      buId: data.bu_id || data.buId,
      buName: data.bu_name || data.buName,
      buCode: data.bu_code || data.buCode,
      environmentId: data.environment_id || data.environmentId,
      environmentName: data.environment_name || data.environmentName,
      applicationId: data.application_id || data.applicationId,
      applicationName: data.application_name || data.applicationName,
      serviceCode: (data.service_code || data.serviceCode) as TEMServiceCode,
      serviceName: data.service_name || data.serviceName || 'Environment Service',
      approvers,
      approverCount: data.approver_count !== undefined ? data.approver_count : approvers.length,
      isActive: data.is_active !== undefined ? data.is_active : data.isActive ?? true,
      status: (data.status || (data.is_active !== false ? 'ACTIVE' : 'INACTIVE')) as 'ACTIVE' | 'INACTIVE',
      createdAt: data.created_at || data.createdAt || new Date().toISOString(),
      createdBy: data.created_by || data.createdBy || 'Super Admin',
      updatedAt: data.updated_at || data.updatedAt || new Date().toISOString(),
      modifiedBy: data.modified_by || data.modifiedBy || 'Super Admin',
    };
  }

  async getWorkflows(params?: {
    buId?: string;
    environmentId?: string;
    applicationId?: string;
    serviceCode?: string;
    isActive?: boolean;
  }): Promise<Workflow[]> {
    try {
      const query = new URLSearchParams();
      if (params?.buId) query.append('buId', params.buId);
      if (params?.environmentId) query.append('environmentId', params.environmentId);
      if (params?.applicationId) query.append('applicationId', params.applicationId);
      if (params?.serviceCode) query.append('serviceCode', params.serviceCode);
      if (params?.isActive !== undefined) query.append('isActive', String(params.isActive));
      query.append('pageSize', '100');

      const data = await fetchApiStrict<any[]>(`/workflows?${query.toString()}`);
      if (Array.isArray(data)) {
        const normalized = data.map((d) => this.normalizeWorkflow(d));
        this.saveLocalWorkflows(normalized);
        return normalized;
      }
    } catch (err: any) {
      if (!isNetworkError(err)) {
        console.warn('[WorkflowService] API error when fetching workflows:', err.message);
      }
    }

    let workflows = this.getLocalWorkflows();
    if (params?.buId) {
      workflows = workflows.filter((w) => w.buId === params.buId);
    }
    if (params?.environmentId) {
      workflows = workflows.filter((w) => w.environmentId === params.environmentId);
    }
    if (params?.applicationId) {
      workflows = workflows.filter((w) => w.applicationId === params.applicationId);
    }
    if (params?.serviceCode) {
      workflows = workflows.filter((w) => w.serviceCode === params.serviceCode);
    }
    if (params?.isActive !== undefined) {
      workflows = workflows.filter((w) => w.isActive === params.isActive);
    }
    return workflows;
  }

  async getWorkflowById(workflowId: string): Promise<Workflow> {
    try {
      const data = await fetchApiStrict<any>(`/workflows/${workflowId}`);
      return this.normalizeWorkflow(data);
    } catch (err: any) {
      if (!isNetworkError(err)) throw err;
    }

    const workflow = this.getLocalWorkflows().find((w) => w.id === workflowId);
    if (!workflow) {
      throw new Error(`Workflow with ID "${workflowId}" not found.`);
    }
    return workflow;
  }

  async createWorkflow(payload: WorkflowCreatePayload): Promise<Workflow> {
    const apiPayload = {
      bu_id: payload.buId,
      environment_id: payload.environmentId,
      application_id: payload.applicationId,
      service_code: payload.serviceCode,
      approvers: payload.approvers.map((a) => ({
        user_id: a.userId,
        workflow_order: a.workflowOrder,
      })),
      is_active: payload.isActive ?? true,
    };

    try {
      const data = await fetchApiStrict<any>('/workflows', {
        method: 'POST',
        body: JSON.stringify(apiPayload),
      });

      const normalized = this.normalizeWorkflow(data);
      const existing = this.getLocalWorkflows();
      this.saveLocalWorkflows([normalized, ...existing.filter((w) => w.id !== normalized.id)]);
      return normalized;
    } catch (err: any) {
      if (!isNetworkError(err)) {
        throw err;
      }
    }

    // --- Local Fallback Creation with Context Validation ---
    const allBUs = await portfolioService.getBusinessUnits();
    const bu = allBUs.find((b) => b.id === payload.buId || b.name.toLowerCase() === payload.buId.toLowerCase());
    const resolvedBuId = bu?.id || payload.buId;
    const resolvedBuName = bu?.name || 'Selected BU';
    const resolvedBuCode = bu?.code || 'BU';

    const allApps = await portfolioService.getApplications();
    const app = allApps.find((a) => a.id === payload.applicationId || a.name.toLowerCase() === payload.applicationId.toLowerCase());
    const resolvedAppId = app?.id || payload.applicationId;
    const resolvedAppName = app?.name || 'Selected Application';

    const allUsers = await userService.getUsers();
    const existingWorkflows = this.getLocalWorkflows();

    // Check duplicate workflow for scope
    const duplicate = existingWorkflows.find(
      (w) =>
        w.buId === resolvedBuId &&
        w.environmentId === payload.environmentId &&
        w.applicationId === resolvedAppId &&
        w.serviceCode === payload.serviceCode
    );
    if (duplicate) {
      throw new Error('An active workflow is already defined for this BU, Environment, Application, and Service combination.');
    }

    if (!payload.approvers || payload.approvers.length === 0) {
      throw new Error('Workflow must have at least one approver in the sequence.');
    }

    const serviceInfo = TEM_SERVICES.find((s) => s.code === payload.serviceCode);
    const serviceName = serviceInfo ? serviceInfo.name : payload.serviceCode;

    const approvers: WorkflowApprover[] = [];
    for (const a of payload.approvers) {
      const user = allUsers.find((u) => u.id === a.userId);
      if (!user) {
        throw new Error(`Approver user ID "${a.userId}" does not exist.`);
      }
      if (!user.isActive || user.status === 'INACTIVE') {
        throw new Error(`Approver user "${user.fullName || user.username}" is inactive.`);
      }

      approvers.push({
        id: `wa-${Date.now()}-${a.workflowOrder}`,
        workflowId: `wf-${Date.now()}`,
        userId: user.id,
        workflowOrder: a.workflowOrder,
        username: user.username,
        fullName: user.fullName || `${user.firstName} ${user.lastName}`,
        email: user.email,
        createdAt: new Date().toISOString(),
        createdBy: 'Super Admin',
      });
    }

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newWorkflow: Workflow = {
      id: `wf-${Date.now()}`,
      buId: resolvedBuId,
      buName: resolvedBuName,
      buCode: resolvedBuCode,
      environmentId: payload.environmentId,
      environmentName: payload.environmentId,
      applicationId: resolvedAppId,
      applicationName: resolvedAppName,
      serviceCode: payload.serviceCode,
      serviceName,
      approvers,
      approverCount: approvers.length,
      isActive: payload.isActive ?? true,
      status: (payload.isActive ?? true) ? 'ACTIVE' : 'INACTIVE',
      createdAt: now,
      createdBy: 'Super Admin',
      updatedAt: now,
      modifiedBy: 'Super Admin',
    };

    this.saveLocalWorkflows([newWorkflow, ...existingWorkflows]);
    return newWorkflow;
  }

  async updateWorkflow(workflowId: string, payload: WorkflowUpdatePayload): Promise<Workflow> {
    const apiPayload: any = {};
    if (payload.buId !== undefined) apiPayload.bu_id = payload.buId;
    if (payload.environmentId !== undefined) apiPayload.environment_id = payload.environmentId;
    if (payload.applicationId !== undefined) apiPayload.application_id = payload.applicationId;
    if (payload.serviceCode !== undefined) apiPayload.service_code = payload.serviceCode;
    if (payload.approvers !== undefined) {
      apiPayload.approvers = payload.approvers.map((a) => ({
        user_id: a.userId,
        workflow_order: a.workflowOrder,
      }));
    }
    if (payload.isActive !== undefined) apiPayload.is_active = payload.isActive;
    if (payload.status !== undefined) apiPayload.status = payload.status;

    try {
      const data = await fetchApiStrict<any>(`/workflows/${workflowId}`, {
        method: 'PUT',
        body: JSON.stringify(apiPayload),
      });

      const normalized = this.normalizeWorkflow(data);
      const existing = this.getLocalWorkflows();
      this.saveLocalWorkflows(existing.map((w) => (w.id === workflowId ? normalized : w)));
      return normalized;
    } catch (err: any) {
      if (!isNetworkError(err)) {
        throw err;
      }
    }

    // --- Local Fallback Update ---
    const existingWorkflows = this.getLocalWorkflows();
    const existing = existingWorkflows.find((w) => w.id === workflowId);
    if (!existing) {
      throw new Error(`Workflow with ID "${workflowId}" not found.`);
    }

    const allUsers = await userService.getUsers();
    let approvers = existing.approvers;
    if (payload.approvers) {
      approvers = payload.approvers.map((a) => {
        const user = allUsers.find((u) => u.id === a.userId);
        return {
          id: `wa-${Date.now()}-${a.workflowOrder}`,
          workflowId,
          userId: a.userId,
          workflowOrder: a.workflowOrder,
          username: user?.username,
          fullName: user?.fullName,
          email: user?.email,
          createdAt: new Date().toISOString(),
          createdBy: 'Super Admin',
        };
      });
    }

    const nextIsActive =
      payload.isActive !== undefined
        ? payload.isActive
        : payload.status !== undefined
        ? payload.status === 'ACTIVE'
        : existing.isActive;

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const updated: Workflow = {
      ...existing,
      buId: payload.buId || existing.buId,
      environmentId: payload.environmentId || existing.environmentId,
      applicationId: payload.applicationId || existing.applicationId,
      serviceCode: payload.serviceCode || existing.serviceCode,
      approvers,
      approverCount: approvers.length,
      isActive: nextIsActive,
      status: nextIsActive ? 'ACTIVE' : 'INACTIVE',
      updatedAt: now,
      modifiedBy: 'Super Admin',
    };

    this.saveLocalWorkflows(existingWorkflows.map((w) => (w.id === workflowId ? updated : w)));
    return updated;
  }

  async toggleWorkflowStatus(workflowId: string): Promise<Workflow> {
    try {
      const data = await fetchApiStrict<any>(`/workflows/${workflowId}/toggle-status`, {
        method: 'PATCH',
      });
      const normalized = this.normalizeWorkflow(data);
      const existing = this.getLocalWorkflows();
      this.saveLocalWorkflows(existing.map((w) => (w.id === workflowId ? normalized : w)));
      return normalized;
    } catch (err: any) {
      if (!isNetworkError(err)) {
        throw err;
      }
    }

    const existingWorkflows = this.getLocalWorkflows();
    const existing = existingWorkflows.find((w) => w.id === workflowId);
    if (!existing) {
      throw new Error(`Workflow with ID "${workflowId}" not found.`);
    }

    const nextActive = !existing.isActive;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const updated: Workflow = {
      ...existing,
      isActive: nextActive,
      status: nextActive ? 'ACTIVE' : 'INACTIVE',
      updatedAt: now,
      modifiedBy: 'Super Admin',
    };

    this.saveLocalWorkflows(existingWorkflows.map((w) => (w.id === workflowId ? updated : w)));
    return updated;
  }

  async deleteWorkflow(workflowId: string): Promise<void> {
    try {
      await fetchApiStrict<any>(`/workflows/${workflowId}`, {
        method: 'DELETE',
      });
      const existing = this.getLocalWorkflows();
      this.saveLocalWorkflows(existing.filter((w) => w.id !== workflowId));
      return;
    } catch (err: any) {
      if (!isNetworkError(err)) {
        throw err;
      }
    }

    const existing = this.getLocalWorkflows();
    this.saveLocalWorkflows(existing.filter((w) => w.id !== workflowId));
  }

  async getExecutionForEntity(entityType: string, entityId: string): Promise<WorkflowExecution | null> {
    try {
      const data = await fetchApiStrict<any>(`/workflows/executions/${entityType}/${entityId}`);
      if (!data) return null;
      return {
        id: data.id,
        workflowId: data.workflow_id || data.workflowId,
        entityType: data.entity_type || data.entityType,
        entityId: data.entity_id || data.entityId,
        currentStepOrder: data.current_step_order ?? data.currentStepOrder ?? 1,
        totalSteps: data.total_steps ?? data.totalSteps ?? 1,
        status: data.status,
        steps: (data.steps || []).map((s: any) => ({
          id: s.id,
          executionId: s.execution_id || s.executionId,
          userId: s.user_id || s.userId,
          username: s.username,
          fullName: s.full_name || s.fullName,
          workflowOrder: s.workflow_order ?? s.workflowOrder,
          status: s.status,
          actionBy: s.action_by || s.actionBy,
          actionAt: s.action_at || s.actionAt,
          comments: s.comments,
        })),
        createdAt: data.created_at || data.createdAt,
        updatedAt: data.updated_at || data.updatedAt,
      };
    } catch {
      return null;
    }
  }

  async submitApprovalAction(
    executionId: string,
    action: 'APPROVE' | 'REJECT',
    comments?: string
  ): Promise<WorkflowExecution> {
    const data = await fetchApiStrict<any>(`/workflows/executions/${executionId}/action`, {
      method: 'POST',
      body: JSON.stringify({ action, comments: comments || '' }),
    });

    return {
      id: data.id,
      workflowId: data.workflow_id || data.workflowId,
      entityType: data.entity_type || data.entityType,
      entityId: data.entity_id || data.entityId,
      currentStepOrder: data.current_step_order ?? data.currentStepOrder,
      totalSteps: data.total_steps ?? data.totalSteps,
      status: data.status,
      steps: (data.steps || []).map((s: any) => ({
        id: s.id,
        executionId: s.execution_id || s.executionId,
        userId: s.user_id || s.userId,
        username: s.username,
        fullName: s.full_name || s.fullName,
        workflowOrder: s.workflow_order ?? s.workflowOrder,
        status: s.status,
        actionBy: s.action_by || s.actionBy,
        actionAt: s.action_at || s.actionAt,
        comments: s.comments,
      })),
      createdAt: data.created_at || data.createdAt,
      updatedAt: data.updated_at || data.updatedAt,
    };
  }
}

export const workflowService = new WorkflowService();
