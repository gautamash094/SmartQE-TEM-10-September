import { fetchApi, fetchApiStrict } from './apiClient';
import {
  ProvisioningRequest,
  ProvisioningTemplate,
  ProvisioningLogItem,
  ProvisioningDashboardKPIs,
  PreflightValidationReport,
} from '../types/provisioning';

const API_BASE_URL = (import.meta as any).env?.VITE_API_BASE_URL || 'http://localhost:8000/api/v1';

export const provisioningService = {
  // -------------------------------------------------------------
  // TEMPLATES
  // -------------------------------------------------------------
  async getTemplates(): Promise<ProvisioningTemplate[]> {
    try {
      const data = await fetchApi<ProvisioningTemplate[]>('/provisioning/templates');
      if (data && Array.isArray(data)) return data;
    } catch {}
    return [];
  },

  async createTemplate(templateData: Partial<ProvisioningTemplate>): Promise<ProvisioningTemplate> {
    return await fetchApiStrict<ProvisioningTemplate>('/provisioning/templates', {
      method: 'POST',
      body: JSON.stringify(templateData),
    });
  },

  async getTemplateById(id: string): Promise<ProvisioningTemplate | null> {
    try {
      return await fetchApi<ProvisioningTemplate>(`/provisioning/templates/${id}`);
    } catch {
      return null;
    }
  },

  // -------------------------------------------------------------
  // DASHBOARD KPIS
  // -------------------------------------------------------------
  async getDashboardKPIs(): Promise<ProvisioningDashboardKPIs> {
    try {
      const data = await fetchApi<ProvisioningDashboardKPIs>('/provisioning/dashboard-kpis');
      if (data) return data;
    } catch {}
    return {
      total_requests: 0,
      in_progress: 0,
      ready: 0,
      failed: 0,
      pending_approval: 0,
      decommissioning: 0,
    };
  },

  // -------------------------------------------------------------
  // REQUESTS CRUD & FILTERING
  // -------------------------------------------------------------
  async getRequests(params: {
    businessUnit?: string;
    projectName?: string;
    applicationName?: string;
    environmentName?: string;
    status?: string;
    owner?: string;
    provisioningMode?: string;
    search?: string;
    page?: number;
    pageSize?: number;
  }): Promise<{ items: ProvisioningRequest[]; total: number; page: number; total_pages: number }> {
    const query = new URLSearchParams();
    if (params.businessUnit && params.businessUnit !== 'ALL') query.append('business_unit', params.businessUnit);
    if (params.projectName && params.projectName !== 'ALL') query.append('project_name', params.projectName);
    if (params.applicationName && params.applicationName !== 'ALL') query.append('application_name', params.applicationName);
    if (params.environmentName) query.append('environment_name', params.environmentName);
    if (params.status && params.status !== 'ALL') query.append('status', params.status);
    if (params.owner && params.owner !== 'ALL') query.append('owner', params.owner);
    if (params.provisioningMode && params.provisioningMode !== 'ALL') query.append('provisioning_mode', params.provisioningMode);
    if (params.search) query.append('search', params.search);
    query.append('page', String(params.page || 1));
    query.append('page_size', String(params.pageSize || 20));

    try {
      const res = await fetchApi<{ items: ProvisioningRequest[]; total: number; page: number; total_pages: number }>(
        `/provisioning/requests?${query.toString()}`
      );
      if (res) return res;
    } catch {}

    return { items: [], total: 0, page: 1, total_pages: 1 };
  },

  async getRequestById(id: string): Promise<ProvisioningRequest | null> {
    try {
      return await fetchApi<ProvisioningRequest>(`/provisioning/requests/${id}`);
    } catch {
      return null;
    }
  },

  async createRequest(payload: any): Promise<ProvisioningRequest> {
    return await fetchApiStrict<ProvisioningRequest>('/provisioning/requests', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async updateRequest(id: string, payload: any): Promise<ProvisioningRequest> {
    return await fetchApiStrict<ProvisioningRequest>(`/provisioning/requests/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  async deleteRequest(id: string): Promise<void> {
    await fetchApiStrict<void>(`/provisioning/requests/${id}`, {
      method: 'DELETE',
    });
  },

  // -------------------------------------------------------------
  // VALIDATION & ACTIONS
  // -------------------------------------------------------------
  async validatePreflight(id: string): Promise<PreflightValidationReport> {
    return await fetchApiStrict<PreflightValidationReport>(`/provisioning/requests/${id}/validate`, {
      method: 'POST',
    });
  },

  async approveRequest(id: string, action: 'APPROVE' | 'REJECT', comments?: string, user?: string): Promise<ProvisioningRequest> {
    return await fetchApiStrict<ProvisioningRequest>(`/provisioning/requests/${id}/approve`, {
      method: 'POST',
      body: JSON.stringify({ action, comments, approver_user: user }),
    });
  },

  async triggerProvisioning(id: string): Promise<ProvisioningRequest> {
    return await fetchApiStrict<ProvisioningRequest>(`/provisioning/requests/${id}/provision`, {
      method: 'POST',
    });
  },

  async retryRequest(id: string, stepId?: string, mode: 'RETRY_STEP' | 'RESUME' = 'RETRY_STEP'): Promise<ProvisioningRequest> {
    return await fetchApiStrict<ProvisioningRequest>(`/provisioning/requests/${id}/retry`, {
      method: 'POST',
      body: JSON.stringify({ step_id: stepId, mode }),
    });
  },

  async rollbackRequest(id: string): Promise<ProvisioningRequest> {
    return await fetchApiStrict<ProvisioningRequest>(`/provisioning/requests/${id}/rollback`, {
      method: 'POST',
    });
  },

  async decommissionRequest(id: string): Promise<ProvisioningRequest> {
    return await fetchApiStrict<ProvisioningRequest>(`/provisioning/requests/${id}/decommission`, {
      method: 'POST',
    });
  },

  async getLogs(id: string, stepId?: string): Promise<ProvisioningLogItem[]> {
    const query = stepId ? `?step_id=${stepId}` : '';
    try {
      const data = await fetchApi<ProvisioningLogItem[]>(`/provisioning/requests/${id}/logs${query}`);
      if (data && Array.isArray(data)) return data;
    } catch {}
    return [];
  },

  async getHealthResults(id: string): Promise<{ health_status: string; probes: any[] }> {
    try {
      const data = await fetchApi<{ health_status: string; probes: any[] }>(`/provisioning/requests/${id}/health`);
      if (data) return data;
    } catch {}
    return { health_status: 'PENDING', probes: [] };
  },

  // -------------------------------------------------------------
  // SSE REAL-TIME SUBSCRIPTION
  // -------------------------------------------------------------
  subscribeToEvents(requestId: string, onEvent: (event: any) => void): () => void {
    const eventSource = new EventSource(`${API_BASE_URL}/provisioning/requests/${requestId}/events`);

    eventSource.onmessage = (e) => {
      try {
        const parsed = JSON.parse(e.data);
        onEvent(parsed);
      } catch {}
    };

    eventSource.onerror = () => {
      // In case of SSE error, the browser automatically attempts reconnect
    };

    return () => {
      eventSource.close();
    };
  },
};
