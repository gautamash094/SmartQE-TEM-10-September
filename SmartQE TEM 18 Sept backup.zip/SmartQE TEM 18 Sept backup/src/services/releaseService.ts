import { Release } from '../types';
import { INITIAL_RELEASES } from '../constants/mockData';
import { fetchApi } from './apiClient';

export const releaseService = {
  async getReleases(): Promise<Release[]> {
    const apiData = await fetchApi<any[]>('/releases');
    if (apiData && Array.isArray(apiData)) {
      return apiData.map((r) => ({
        id: r.id,
        name: r.name,
        version: r.version,
        environmentId: r.environment_id || r.environmentId,
        environmentName: r.environment_name || r.environmentName,
        lead: r.lead,
        changeRef: r.change_ref || r.changeRef,
        scheduledDate: r.scheduled_date || r.scheduledDate,
        risk: r.risk,
        status: r.status,
      }));
    }
    return [];
  },

  async createRelease(relData: Omit<Release, 'id' | 'status'>): Promise<Release> {
    const payload = {
      name: relData.name,
      version: relData.version,
      environment_id: relData.environmentId,
      environment_name: relData.environmentName,
      lead: relData.lead,
      change_ref: relData.changeRef,
      scheduled_date: relData.scheduledDate,
      risk: relData.risk,
      status: 'SCHEDULED',
    };

    const apiData = await fetchApi<any>('/releases', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    if (apiData) {
      return {
        id: apiData.id,
        name: apiData.name,
        version: apiData.version,
        environmentId: apiData.environment_id || relData.environmentId,
        environmentName: apiData.environment_name || relData.environmentName,
        lead: apiData.lead,
        changeRef: apiData.change_ref || relData.changeRef,
        scheduledDate: apiData.scheduled_date || relData.scheduledDate,
        risk: apiData.risk,
        status: apiData.status,
      };
    }

    return {
      ...relData,
      id: `rel-${Date.now()}`,
      status: 'SCHEDULED',
    };
  },
};
