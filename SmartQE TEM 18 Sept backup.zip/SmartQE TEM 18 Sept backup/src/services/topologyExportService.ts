import { TopologyGraphResponse, TopologyFilterState } from '../types/topology';
import { EnvironmentProfile, ServerDetail, SoftwareDetail } from '../types/environmentDetails';
import { ApplicationEntity } from './portfolioService';

export type ExportScope = 'ALL' | 'FILTERED' | 'SELECTED';
export type ExportFormat = 'CSV' | 'XLSX' | 'PDF' | 'DOCX';

export interface ExportOptions {
  scope: ExportScope;
  format: ExportFormat;
  selectedEnvironmentIds?: string[];
  filters?: TopologyFilterState;
  graphData: TopologyGraphResponse;
  environmentProfiles: EnvironmentProfile[];
  servers: ServerDetail[];
  softwareList: SoftwareDetail[];
  applications: ApplicationEntity[];
}

export const topologyExportService = {
  /**
   * Main export handler: Calls backend endpoint first, falls back to client generation
   */
  async exportTopology(options: ExportOptions): Promise<void> {
    const { scope, format, selectedEnvironmentIds, filters, graphData } = options;

    const payload = {
      scope,
      format,
      selected_environment_ids: selectedEnvironmentIds || [],
      filters,
      graph_data: graphData
    };

    try {
      const response = await fetch('/api/v1/topology/export', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        const blob = await response.blob();
        let filename = `Environment_Topology_${scope}_${new Date().toISOString().slice(0, 10)}.${format.toLowerCase()}`;
        
        const contentDisposition = response.headers.get('Content-Disposition');
        if (contentDisposition) {
          const match = contentDisposition.match(/filename="?([^";]+)"?/);
          if (match && match[1]) {
            filename = match[1];
          }
        }

        this.triggerBlobDownload(blob, filename);
        return;
      }
    } catch (err) {
      console.warn('Backend export endpoint unavailable, triggering client-side export fallback:', err);
    }

    // Client-side fallback exporter
    this.exportClientSide(options);
  },

  /**
   * Trigger browser file download via anchor
   */
  triggerBlobDownload(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  },

  /**
   * Client-side CSV & Document fallback builder
   */
  exportClientSide(options: ExportOptions): void {
    const { scope, format, selectedEnvironmentIds, graphData } = options;
    const dateStr = new Date().toISOString().slice(0, 10);
    const scopeStr = scope.charAt(0).toUpperCase() + scope.slice(1).toLowerCase();

    let nodes = graphData.nodes || [];
    let edges = graphData.edges || [];

    if (scope === 'SELECTED' && selectedEnvironmentIds && selectedEnvironmentIds.length > 0) {
      const selSet = new Set(selectedEnvironmentIds);
      const matchedNodeIds = new Set<string>();

      nodes.forEach(n => {
        const envId = n.environment_id || n.id;
        if (selSet.has(envId) || selSet.has(n.id)) {
          matchedNodeIds.add(n.id);
        }
      });

      edges.forEach(e => {
        if (matchedNodeIds.has(e.source) || matchedNodeIds.has(e.target)) {
          matchedNodeIds.add(e.source);
          matchedNodeIds.add(e.target);
        }
      });

      nodes = nodes.filter(n => matchedNodeIds.has(n.id));
      const validIds = new Set(nodes.map(n => n.id));
      edges = edges.filter(e => validIds.has(e.source) && validIds.has(e.target));
    }

    const filename = `Environment_Topology_${scopeStr}_${dateStr}.${format.toLowerCase()}`;

    if (format === 'CSV') {
      const csvContent = this.generateCsvString(nodes, edges);
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      this.triggerBlobDownload(blob, filename);
    } else {
      // For XLSX, PDF, DOCX in fallback mode if backend endpoint is offline, generate formatted structured document blob
      const docContent = this.generateStructuredDocText(nodes, edges, scopeStr, format);
      const mimeType = format === 'XLSX' 
        ? 'application/vnd.ms-excel'
        : format === 'PDF' 
        ? 'application/pdf'
        : 'application/msword';
      
      const blob = new Blob([docContent], { type: `${mimeType};charset=utf-8;` });
      this.triggerBlobDownload(blob, filename);
    }
  },

  /**
   * Helper to build structured CSV
   */
  generateCsvString(nodes: any[], edges: any[]): string {
    const escapeCsv = (str: any) => {
      if (str === null || str === undefined) return '""';
      let s = String(str).replace(/"/g, '""');
      // Prevent formula injection in Excel / LibreOffice Calc (Err:510)
      if (/^[=+\-@]/.test(s)) {
        s = `'${s}`;
      }
      return `"${s}"`;
    };

    const lines: string[] = [];

    // Header
    lines.push(escapeCsv('--- ENVIRONMENT TOPOLOGY EXPORT ---'));
    lines.push(`Generated At,${escapeCsv(new Date().toISOString())}`);
    lines.push(`Total Nodes,${nodes.length}`);
    lines.push(`Total Relationships,${edges.length}`);
    lines.push('');

    // Environments
    lines.push(escapeCsv('--- ENVIRONMENTS ---'));
    lines.push(['Environment ID', 'Environment Name', 'Type/Tier', 'Status', 'Business Unit', 'Network Zone', 'Incidents Count'].map(escapeCsv).join(','));
    const envNodes = nodes.filter(n => n.type === 'ENVIRONMENT');
    envNodes.forEach(env => {
      const props = env.properties || {};
      lines.push([
        env.id,
        env.name,
        env.sub_type || props.type || '',
        env.status || 'HEALTHY',
        env.business_unit || props.ownerTeam || '',
        env.account_name || props.networkZone || '',
        env.active_incidents_count || 0
      ].map(escapeCsv).join(','));
    });
    lines.push('');

    // Servers
    lines.push(escapeCsv('--- SERVERS AND INFRASTRUCTURE ---'));
    lines.push(['Server ID', 'Server Name', 'Environment ID', 'Environment Name', 'Type', 'Status', 'IP Address', 'Hostname', 'Cloud Provider', 'Region', 'Specs'].map(escapeCsv).join(','));
    const srvNodes = nodes.filter(n => n.type === 'SERVER');
    srvNodes.forEach(srv => {
      lines.push([
        srv.id,
        srv.name,
        srv.environment_id || '',
        srv.environment_name || '',
        srv.sub_type || '',
        srv.status || '',
        srv.ip_address || '',
        srv.hostname || '',
        srv.cloud_provider || '',
        srv.region || '',
        srv.specs || ''
      ].map(escapeCsv).join(','));
    });
    lines.push('');

    // Software
    lines.push(escapeCsv('--- SOFTWARE AND SERVICES ---'));
    lines.push(['Software ID', 'Software Name', 'Environment ID', 'Environment Name', 'Category', 'Status', 'Version', 'Vendor'].map(escapeCsv).join(','));
    const swNodes = nodes.filter(n => n.type === 'SOFTWARE' || n.type === 'SERVICE');
    swNodes.forEach(sw => {
      const props = sw.properties || {};
      lines.push([
        sw.id,
        sw.name,
        sw.environment_id || '',
        sw.environment_name || '',
        sw.sub_type || props.category || '',
        sw.status || '',
        props.version || '',
        props.vendor || ''
      ].map(escapeCsv).join(','));
    });
    lines.push('');

    // Applications
    lines.push(escapeCsv('--- APPLICATIONS ---'));
    lines.push(['Application ID', 'Application Name', 'Business Unit', 'Project', 'Code', 'Owner Team'].map(escapeCsv).join(','));
    const appNodes = nodes.filter(n => n.type === 'APPLICATION' || n.type === 'MICROSERVICE');
    appNodes.forEach(app => {
      const props = app.properties || {};
      lines.push([
        app.id,
        app.name,
        app.business_unit || '',
        props.project || '',
        props.code || '',
        props.owner || ''
      ].map(escapeCsv).join(','));
    });
    lines.push('');

    // Relationships
    lines.push(escapeCsv('--- TOPOLOGY DEPENDENCIES AND RELATIONSHIPS ---'));
    lines.push(['Relationship ID', 'Source Node ID', 'Source Node Name', 'Source Type', 'Relationship Type', 'Target Node ID', 'Target Node Name', 'Target Type', 'Port', 'Protocol', 'Latency (ms)'].map(escapeCsv).join(','));
    const nodeMap = new Map(nodes.map(n => [n.id, n]));
    edges.forEach(edge => {
      const src = nodeMap.get(edge.source) || {};
      const tgt = nodeMap.get(edge.target) || {};
      lines.push([
        edge.id,
        edge.source,
        src.name || edge.source,
        src.type || '',
        edge.relationship_type || 'DEPENDS_ON',
        edge.target,
        tgt.name || edge.target,
        tgt.type || '',
        edge.port || '',
        edge.protocol || '',
        edge.latency_ms || ''
      ].map(escapeCsv).join(','));
    });

    return lines.join('\n');
  },

  /**
   * Helper to format text fallback for non-CSV formats when client-side only
   */
  generateStructuredDocText(nodes: any[], edges: any[], scope: string, format: string): string {
    const nodeMap = new Map(nodes.map(n => [n.id, n]));
    const envNodes = nodes.filter(n => n.type === 'ENVIRONMENT');
    const srvNodes = nodes.filter(n => n.type === 'SERVER');
    const swNodes = nodes.filter(n => n.type === 'SOFTWARE' || n.type === 'SERVICE');
    const appNodes = nodes.filter(n => n.type === 'APPLICATION' || n.type === 'MICROSERVICE');

    return `
================================================================================
SMARTQE TEM - ENVIRONMENT TOPOLOGY REPORT (${scope} Scope - ${format})
Single Source of Truth: Environment Details Module
Generated At: ${new Date().toISOString()}
================================================================================

1. EXECUTIVE OVERVIEW
--------------------------------------------------------------------------------
Total Environments  : ${envNodes.length}
Total Servers       : ${srvNodes.length}
Total Software      : ${swNodes.length}
Total Applications  : ${appNodes.length}
Total Relationships : ${edges.length}

2. ENVIRONMENT CATALOG DETAILS
--------------------------------------------------------------------------------
${envNodes.map(env => `
[ENVIRONMENT] ID: ${env.id} | Name: ${env.name}
  Tier/Type    : ${env.sub_type || env.properties?.type || 'N/A'}
  Status       : ${env.status}
  Owner Team   : ${env.business_unit || env.properties?.ownerTeam || 'Platform QE'}
  Network Zone : ${env.account_name || env.properties?.networkZone || 'VPC-QA'}
  Incidents    : ${env.active_incidents_count || 0}
`).join('\n')}

3. INFRASTRUCTURE & SERVERS
--------------------------------------------------------------------------------
${srvNodes.map(srv => `
[SERVER] ID: ${srv.id} | Name: ${srv.name}
  Environment  : ${srv.environment_name} (${srv.environment_id})
  Type         : ${srv.sub_type} | Status: ${srv.status}
  Host Details : IP ${srv.ip_address || 'N/A'} | Hostname ${srv.hostname || 'N/A'}
  Cloud/Region : ${srv.cloud_provider || 'On-Premises'} (${srv.region || 'N/A'})
  Hardware     : ${srv.specs || 'N/A'}
`).join('\n')}

4. SOFTWARE & SERVICES
--------------------------------------------------------------------------------
${swNodes.map(sw => `
[SOFTWARE] ID: ${sw.id} | Name: ${sw.name}
  Environment  : ${sw.environment_name} (${sw.environment_id})
  Category     : ${sw.sub_type || sw.properties?.category} | Version: ${sw.properties?.version || 'N/A'}
  Vendor       : ${sw.properties?.vendor || 'N/A'}
`).join('\n')}

5. APPLICATIONS
--------------------------------------------------------------------------------
${appNodes.map(app => `
[APPLICATION] ID: ${app.id} | Name: ${app.name}
  Business Unit: ${app.business_unit || 'Enterprise'}
  Project      : ${app.properties?.project || 'N/A'} | Code: ${app.properties?.code || 'N/A'}
`).join('\n')}

6. TOPOLOGY DEPENDENCIES & RELATIONSHIPS
--------------------------------------------------------------------------------
${edges.map(e => {
  const src = nodeMap.get(e.source);
  const tgt = nodeMap.get(e.target);
  return `[RELATIONSHIP] ID: ${e.id}
  ${src?.name || e.source} (${src?.type}) --[ ${e.relationship_type} ]--> ${tgt?.name || e.target} (${tgt?.type})
  Port/Protocol : ${e.port || 'N/A'}/${e.protocol || 'TCP'} | Latency: ${e.latency_ms ? e.latency_ms + 'ms' : 'N/A'}`;
}).join('\n\n')}
`;
  }
};
