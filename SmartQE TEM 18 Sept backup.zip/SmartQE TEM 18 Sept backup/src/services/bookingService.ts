import { Booking, ReservationMode } from '../types';
import { INITIAL_BOOKINGS } from '../constants/mockData';
import { fetchApi, fetchApiStrict } from './apiClient';
import { authService } from './authService';
import { workflowService } from './workflowService';

const STORAGE_KEY = 'tem_bookings';

const normalizeStoredBooking = (b: Booking): Booking => {
  const audit = Array.isArray(b.auditHistory)
    ? b.auditHistory
    : typeof b.auditHistory === 'string'
    ? JSON.parse(b.auditHistory || '[]')
    : [];
  const isAllApproved = audit.some(
    (a: any) =>
      a.status === 'APPROVED' &&
      a.newValue &&
      a.newValue.toLowerCase().includes('all workflow approvers have approved')
  );

  if (isAllApproved && b.status === 'PENDING') {
    return {
      ...b,
      status: 'APPROVED',
      currentApproverId: undefined,
      currentApproverName: undefined,
    };
  }
  return b;
};

const getStoredBookings = (): Booking[] | null => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map(normalizeStoredBooking);
      }
    }
  } catch {}
  return null;
};

const setStoredBookings = (bookings: Booking[]) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings.map(normalizeStoredBooking)));
  } catch {}
};

export const bookingService = {
  /**
   * Fetch all environment reservations/bookings
   * Corresponds to FastAPI endpoint GET /api/v1/reservations
   */
  async getBookings(): Promise<Booking[]> {
    const sessionUser = authService.getCurrentSessionUser();
    let allBookings: Booking[] = [];

    const apiData = await fetchApi<any[]>('/reservations?pageSize=200');
    if (apiData && Array.isArray(apiData)) {
      allBookings = apiData.map((b) => ({
        id: b.id,
        environmentId: b.environment_id || b.environmentId,
        environmentName: b.environment_name || b.environmentName,
        businessUnit: b.business_unit || b.businessUnit,
        project: b.project,
        application: b.application,
        purpose: b.purpose,
        team: b.team,
        requestedBy: b.requested_by || b.requestedBy,
        priority: b.priority || 'MEDIUM',
        autoApprovalEnabled: Boolean(b.auto_approval_enabled || b.autoApprovalEnabled),
        autoApprovalRule: b.auto_approval_rule || b.autoApprovalRule || null,
        startDate: b.start_date || b.startDate,
        endDate: b.end_date || b.endDate,
        status: b.status,
        reservationMode: b.reservation_mode || b.reservationMode || 'SHARED',
        workflowId: b.workflow_id || b.workflowId,
        currentWorkflowOrder: b.current_workflow_order ?? b.currentWorkflowOrder,
        currentApproverId: b.current_approver_id || b.currentApproverId,
        currentApproverName: b.current_approver_name || b.currentApproverName,
        rejectionReason: b.rejection_reason || b.rejectionReason,
        rejectedAt: b.rejected_at || b.rejectedAt,
        rejectionType: b.rejection_type || b.rejectionType,
        auditHistory: b.audit_history ? (typeof b.audit_history === 'string' ? JSON.parse(b.audit_history) : b.audit_history) : b.auditHistory || [],
        ownerId: b.owner_id || b.ownerId,
        createdBy: b.created_by || b.createdBy,
      }));
      setStoredBookings(allBookings);
    } else {
      const stored = getStoredBookings();
      if (stored) {
        allBookings = stored;
      } else {
        allBookings = [...INITIAL_BOOKINGS];
      }
    }

    // If Super Admin / Admin, return all bookings
    const isSuperOrAdmin = Boolean(
      sessionUser?.isSuperAdmin ||
      sessionUser?.username?.toLowerCase() === 'admin' ||
      sessionUser?.username?.toLowerCase() === 'superadmin' ||
      (sessionUser?.roles || []).some((r: any) =>
        ['super admin', 'superadmin', 'admin'].includes(r.name?.toLowerCase()?.trim())
      )
    );

    if (isSuperOrAdmin) {
      return allBookings;
    }

    if (!sessionUser) {
      return [];
    }

    // For non-admin regular users, filter bookings to their own or those in their approval workflow
    const userId = (sessionUser.id || '').toLowerCase().trim();
    const username = (sessionUser.username || '').toLowerCase().trim();
    const fullName = (sessionUser.fullName || '').toLowerCase().trim();
    const email = (sessionUser.email || '').toLowerCase().trim();

    let workflows: any[] = [];
    try {
      workflows = await workflowService.getWorkflows();
    } catch {}

    return allBookings.filter((b) => {
      const reqBy = (b.requestedBy || '').toLowerCase().trim();
      const ownerId = ((b as any).ownerId || '').toLowerCase().trim();
      const createdBy = ((b as any).createdBy || '').toLowerCase().trim();
      const approverId = ((b as any).currentApproverId || '').toLowerCase().trim();
      const approverName = ((b as any).currentApproverName || '').toLowerCase().trim();

      const matchesOwnerId = Boolean(ownerId && ownerId === userId);
      const matchesCreatedBy = Boolean(
        createdBy && (createdBy === username || createdBy === fullName || createdBy === email || (username && createdBy.includes(username)))
      );
      const matchesRequestedBy = Boolean(
        reqBy && (
          reqBy === username ||
          reqBy === fullName ||
          reqBy === email ||
          (fullName && (reqBy.includes(fullName) || fullName.includes(reqBy))) ||
          (username && (reqBy.includes(username) || username.includes(reqBy)))
        )
      );
      const matchesApprover = Boolean(
        (approverId && (approverId === userId || approverId === username)) ||
        (approverName && (approverName === username || approverName === fullName || approverName === email))
      );

      // Check if user is configured as ANY step approver in the reservation's workflow
      let isTaggedInWorkflow = false;
      if (workflows.length > 0) {
        const matchingWfs = workflows.filter((w) => {
          if (b.workflowId && w.id === b.workflowId) return true;
          const bBU = (b.businessUnit || '').toLowerCase().trim();
          const bEnvId = (b.environmentId || '').toLowerCase().trim();
          const bEnvName = (b.environmentName || '').toLowerCase().trim();
          const buMatch = (w.buId && w.buId.toLowerCase().trim() === bBU) || (w.buName && w.buName.toLowerCase().trim() === bBU) || (w.buCode && w.buCode.toLowerCase().trim() === bBU);
          const envMatch = (w.environmentId && (w.environmentId.toLowerCase().trim() === bEnvId || w.environmentId.toLowerCase().trim() === bEnvName)) || (w.environmentName && (w.environmentName.toLowerCase().trim() === bEnvName || w.environmentName.toLowerCase().trim() === bEnvId));
          return buMatch && envMatch;
        });

        isTaggedInWorkflow = matchingWfs.some((w: any) =>
          (w.approvers || []).some((a: any) => {
            const aId = (a.userId || '').toLowerCase().trim();
            const aUser = (a.username || '').toLowerCase().trim();
            const aName = (a.fullName || '').toLowerCase().trim();
            const aEmail = (a.email || '').toLowerCase().trim();
            return (
              (aId && (aId === userId || aId === username)) ||
              (aUser && (aUser === username || aUser === userId)) ||
              (aName && (aName === fullName || (fullName && aName.includes(fullName)))) ||
              (aEmail && aEmail === email)
            );
          })
        );
      }

      return matchesOwnerId || matchesCreatedBy || matchesRequestedBy || matchesApprover || isTaggedInWorkflow;
    });
  },

  /**
   * Create a new reservation/booking with mandatory Business Unit (Project and Application optional)
   * Corresponds to FastAPI endpoint POST /api/v1/reservations
   */
  async createBooking(bookingData: Omit<Booking, 'id' | 'status'>): Promise<Booking> {
    if (!bookingData.businessUnit) {
      throw new Error('Business Unit is a required field for creating a reservation.');
    }

    if (bookingData.startDate && bookingData.endDate) {
      const s = new Date(bookingData.startDate).getTime();
      const e = new Date(bookingData.endDate).getTime();
      if (isNaN(s) || isNaN(e) || s >= e) {
        throw new Error('Start date and time cannot be greater than end date and time.');
      }
    }

    const currentUser = authService.getCurrentSessionUser();
    const createdByUserName = currentUser?.fullName || currentUser?.username || bookingData.requestedBy || 'Super Admin';

    const payload = {
      environment_id: bookingData.environmentId,
      environment_name: bookingData.environmentName,
      business_unit: bookingData.businessUnit,
      project: bookingData.project || '',
      application: bookingData.application || '',
      purpose: bookingData.purpose,
      team: bookingData.team,
      requested_by: createdByUserName,
      priority: bookingData.priority || 'MEDIUM',
      auto_approval_enabled: Boolean(bookingData.autoApprovalEnabled),
      auto_approval_rule: bookingData.autoApprovalEnabled ? bookingData.autoApprovalRule : null,
      start_date: bookingData.startDate,
      end_date: bookingData.endDate,
      reservation_mode: bookingData.reservationMode || 'SHARED',
    };

    let apiData: any = null;
    let apiError: any = null;

    try {
      apiData = await fetchApiStrict<any>('/reservations', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    } catch (err: any) {
      apiError = err;
      // If it's a validation error or AppException from server, bubble it up immediately
      if (err?.message && !err.message.toLowerCase().includes('failed to fetch') && !err.message.toLowerCase().includes('networkerror')) {
        throw err;
      }
    }

    let defaultFallbackStatus: Booking['status'] = 'PENDING';
    let matchedWfId: string | undefined;
    let matchedOrder: number | undefined;
    let matchedApproverId: string | undefined;
    let matchedApproverName: string | undefined;

    // Check if active approval workflow is defined locally
    let matchingWf: any = null;
    try {
      const workflows = await workflowService.getWorkflows({ isActive: true });
      const targetBU = bookingData.businessUnit.toLowerCase().trim();
      const targetEnvId = (bookingData.environmentId || '').toLowerCase().trim();
      const targetEnvName = (bookingData.environmentName || '').toLowerCase().trim();
      const targetApp = (bookingData.application || '').toLowerCase().trim();

      matchingWf = workflows.find((w) => {
        if (!w.isActive || !w.approvers || w.approvers.length === 0) return false;
        if (w.serviceCode && w.serviceCode !== 'ENVIRONMENT_RESERVATION') return false;

        const buMatch =
          (w.buId && w.buId.toLowerCase().trim() === targetBU) ||
          (w.buName && w.buName.toLowerCase().trim() === targetBU) ||
          (w.buCode && w.buCode.toLowerCase().trim() === targetBU);
        if (!buMatch) return false;

        const envMatch =
          (w.environmentId && (w.environmentId.toLowerCase().trim() === targetEnvId || w.environmentId.toLowerCase().trim() === targetEnvName)) ||
          (w.environmentName && (w.environmentName.toLowerCase().trim() === targetEnvName || w.environmentName.toLowerCase().trim() === targetEnvId));
        if (!envMatch) return false;

        if (targetApp && w.applicationName) {
          return w.applicationName.toLowerCase().trim() === targetApp || (w.applicationId && w.applicationId.toLowerCase().trim() === targetApp);
        }
        return true;
      });

      if (matchingWf && matchingWf.approvers && matchingWf.approvers.length > 0) {
        defaultFallbackStatus = 'PENDING';
        matchedWfId = matchingWf.id;
        matchedOrder = 1;
        const sorted = [...matchingWf.approvers].sort((a, b) => a.workflowOrder - b.workflowOrder);
        matchedApproverId = sorted[0].userId;
        matchedApproverName = sorted[0].fullName || sorted[0].username || sorted[0].userId;
      }
    } catch {}

    // In fallback mode, require active workflow
    if (!apiData) {
      if (!matchingWf || !matchingWf.approvers || matchingWf.approvers.length === 0) {
        throw new Error('Define the workflow to make any reservation.');
      }
    }

    if (defaultFallbackStatus !== 'PENDING' && bookingData.autoApprovalEnabled) {
      if (bookingData.autoApprovalRule === 'ALL_REQUESTS') {
        defaultFallbackStatus = 'CONFIRMED';
      } else if (bookingData.autoApprovalRule === 'PRIORITY_REQUESTS') {
        defaultFallbackStatus = (bookingData.priority === 'HIGH' || bookingData.priority === 'CRITICAL') ? 'CONFIRMED' : 'PENDING';
      } else if (bookingData.autoApprovalRule === 'SHORT_REQUESTS') {
        const s = new Date(bookingData.startDate).getTime();
        const e = new Date(bookingData.endDate).getTime();
        const durationHours = (e - s) / (1000 * 60 * 60);
        defaultFallbackStatus = durationHours < 3 ? 'CONFIRMED' : 'PENDING';
      }
    }

    const finalStatus = defaultFallbackStatus === 'PENDING' ? 'PENDING' : (apiData?.status || defaultFallbackStatus);
    const finalWfId = defaultFallbackStatus === 'PENDING' ? (matchedWfId || apiData?.workflow_id) : (apiData?.workflow_id || matchedWfId);
    const finalOrder = defaultFallbackStatus === 'PENDING' ? (matchedOrder || apiData?.current_workflow_order || 1) : (apiData?.current_workflow_order ?? matchedOrder);
    const finalApprId = defaultFallbackStatus === 'PENDING' ? (matchedApproverId || apiData?.current_approver_id) : (apiData?.current_approver_id || matchedApproverId);
    const finalApprName = defaultFallbackStatus === 'PENDING' ? (matchedApproverName || apiData?.current_approver_name) : (apiData?.current_approver_name || matchedApproverName);

    const created: Booking = apiData
      ? {
          id: apiData.id,
          environmentId: apiData.environment_id || bookingData.environmentId,
          environmentName: apiData.environment_name || bookingData.environmentName,
          businessUnit: apiData.business_unit || bookingData.businessUnit,
          project: apiData.project || bookingData.project || '',
          application: apiData.application || bookingData.application || '',
          purpose: apiData.purpose || bookingData.purpose,
          team: apiData.team || bookingData.team,
          requestedBy: apiData.requested_by || bookingData.requestedBy,
          priority: apiData.priority || bookingData.priority || 'MEDIUM',
          autoApprovalEnabled: Boolean(apiData.auto_approval_enabled ?? bookingData.autoApprovalEnabled),
          autoApprovalRule: apiData.auto_approval_rule ?? bookingData.autoApprovalRule,
          startDate: apiData.start_date || bookingData.startDate,
          endDate: apiData.end_date || bookingData.endDate,
          status: finalStatus,
          reservationMode: apiData.reservation_mode || bookingData.reservationMode || 'SHARED',
          workflowId: finalWfId,
          currentWorkflowOrder: finalOrder,
          currentApproverId: finalApprId,
          currentApproverName: finalApprName,
          rejectionReason: apiData.rejection_reason,
          rejectedAt: apiData.rejected_at,
          rejectionType: apiData.rejection_type,
          auditHistory: [],
        }
      : {
          ...bookingData,
          priority: bookingData.priority || 'MEDIUM',
          autoApprovalEnabled: Boolean(bookingData.autoApprovalEnabled),
          autoApprovalRule: bookingData.autoApprovalEnabled ? bookingData.autoApprovalRule : null,
          reservationMode: bookingData.reservationMode || 'SHARED',
          id: `booking-${Date.now()}`,
          status: defaultFallbackStatus,
          workflowId: matchedWfId,
          currentWorkflowOrder: matchedOrder,
          currentApproverId: matchedApproverId,
          currentApproverName: matchedApproverName,
          auditHistory: [],
        };

    const current = getStoredBookings() || [...INITIAL_BOOKINGS];
    setStoredBookings([created, ...current.filter((b) => b.id !== created.id)]);
    return created;
  },

  /**
   * Submit sequential workflow approval or rejection action
   */
  async approveBooking(id: string, action: 'APPROVE' | 'REJECT', comments?: string): Promise<{ booking: Booking; message: string }> {
    const sessionUser = authService.getCurrentSessionUser();
    const actorName = sessionUser ? (sessionUser.fullName || sessionUser.username) : 'Approver';

    let apiData: any = null;
    try {
      apiData = await fetchApi<any>(`/reservations/${id}/approval`, {
        method: 'POST',
        body: JSON.stringify({ action, comments: comments || '' }),
      });
    } catch {}

    if (apiData) {
      const updated: Booking = {
        id: apiData.id || id,
        environmentId: apiData.environment_id || '',
        environmentName: apiData.environment_name || '',
        businessUnit: apiData.business_unit || '',
        project: apiData.project || '',
        application: apiData.application || '',
        purpose: apiData.purpose || '',
        team: apiData.team || '',
        requestedBy: apiData.requested_by || '',
        priority: apiData.priority || 'MEDIUM',
        autoApprovalEnabled: Boolean(apiData.auto_approval_enabled),
        autoApprovalRule: apiData.auto_approval_rule,
        startDate: apiData.start_date || '',
        endDate: apiData.end_date || '',
        status: apiData.status,
        reservationMode: apiData.reservation_mode || 'SHARED',
        workflowId: apiData.workflow_id,
        currentWorkflowOrder: apiData.current_workflow_order,
        currentApproverId: apiData.current_approver_id,
        currentApproverName: apiData.current_approver_name,
        rejectionReason: apiData.rejection_reason,
        rejectedAt: apiData.rejected_at,
        rejectionType: apiData.rejection_type,
        auditHistory: apiData.audit_history ? (typeof apiData.audit_history === 'string' ? JSON.parse(apiData.audit_history) : apiData.audit_history) : [],
      };

      const current = getStoredBookings() || [...INITIAL_BOOKINGS];
      setStoredBookings(current.map((b) => (b.id === id ? { ...b, ...updated } : b)));
      
      const successMsg = action === 'REJECT'
        ? 'Reservation rejected successfully. The approval workflow has been terminated.'
        : apiData.status === 'PENDING'
        ? `Reservation approved by you. The request has been moved to the next approver (${apiData.current_approver_name || 'Next Approver'}).`
        : 'Reservation approved successfully. All workflow approvers have approved the reservation.';
      return { booking: updated, message: successMsg };
    }

    // --- Sequential Workflow Evaluation in Local / Fallback State ---
    const current = getStoredBookings() || [...INITIAL_BOOKINGS];
    const targetBooking = current.find((b) => b.id === id);
    if (!targetBooking) {
      throw new Error(`Reservation #${id} not found.`);
    }

    if (action === 'APPROVE') {
      const modeCheck = this.validateSlotAvailability(
        targetBooking.id,
        targetBooking.environmentId,
        targetBooking.environmentName,
        targetBooking.startDate,
        targetBooking.endDate,
        targetBooking.reservationMode || 'SHARED',
        current
      );
      if (!modeCheck.isAvailable) {
        throw new Error('Cannot approve reservation with active schedule conflict. Please resolve the conflict first.');
      }
    }

    // Look up workflows to find the step configuration
    let allWorkflows: any[] = [];
    try {
      allWorkflows = await workflowService.getWorkflows();
    } catch {}

    let matchingWf = allWorkflows.find((w) => w.id === targetBooking.workflowId);
    if (!matchingWf) {
      const bBU = (targetBooking.businessUnit || '').toLowerCase().trim();
      const bEnvId = (targetBooking.environmentId || '').toLowerCase().trim();
      const bEnvName = (targetBooking.environmentName || '').toLowerCase().trim();
      matchingWf = allWorkflows.find((w) => {
        const buMatch = (w.buId && w.buId.toLowerCase().trim() === bBU) || (w.buName && w.buName.toLowerCase().trim() === bBU) || (w.buCode && w.buCode.toLowerCase().trim() === bBU);
        const envMatch = (w.environmentId && (w.environmentId.toLowerCase().trim() === bEnvId || w.environmentId.toLowerCase().trim() === bEnvName)) || (w.environmentName && (w.environmentName.toLowerCase().trim() === bEnvName || w.environmentName.toLowerCase().trim() === bEnvId));
        return buMatch && envMatch && w.isActive !== false;
      });
    }

    const approvers = (matchingWf?.approvers || []).slice().sort((a: any, b: any) => a.workflowOrder - b.workflowOrder);
    const currentOrder = targetBooking.currentWorkflowOrder || 1;
    const nowIso = new Date().toISOString();

    const existingAudit = Array.isArray(targetBooking.auditHistory)
      ? [...targetBooking.auditHistory]
      : (typeof targetBooking.auditHistory === 'string' ? JSON.parse(targetBooking.auditHistory || '[]') : []);

    if (action === 'REJECT') {
      const updated: Booking = {
        ...targetBooking,
        status: 'REJECTED',
        rejectionReason: comments || 'Reservation rejected by approver',
        rejectionType: 'MANUAL',
        rejectedAt: nowIso,
        currentApproverId: undefined,
        currentApproverName: undefined,
        auditHistory: [
          ...existingAudit,
          {
            id: `audit-${Date.now()}`,
            field: 'workflow_rejection',
            oldValue: `Step ${currentOrder} (${actorName})`,
            newValue: `REJECTED: ${comments || 'Workflow terminated'}`,
            changedBy: actorName,
            changedAt: nowIso,
            comments: comments || 'Reservation rejected by approver',
            stepOrder: currentOrder,
            status: 'REJECTED',
          }
        ]
      };
      setStoredBookings(current.map((b) => (b.id === id ? { ...b, ...updated } : b)));
      return {
        booking: updated,
        message: 'Reservation rejected successfully. The approval workflow has been terminated.'
      };
    }

    // Action: APPROVE
    if (approvers.length > 0) {
      const nextApprover = approvers.find((a: any) => a.workflowOrder === currentOrder + 1);
      if (nextApprover) {
        // Multi-Step: Progress to next approver, status remains PENDING!
        const nextApproverName = nextApprover.fullName || nextApprover.username || nextApprover.userId;
        const updated: Booking = {
          ...targetBooking,
          status: 'PENDING',
          workflowId: matchingWf?.id || targetBooking.workflowId,
          currentWorkflowOrder: currentOrder + 1,
          currentApproverId: nextApprover.userId,
          currentApproverName: nextApproverName,
          auditHistory: [
            ...existingAudit,
            {
              id: `audit-${Date.now()}`,
              field: 'workflow_approval',
              oldValue: `Step ${currentOrder} (${actorName})`,
              newValue: `Approved by ${actorName}. Moved to ${nextApproverName} (Step ${currentOrder + 1})`,
              changedBy: actorName,
              changedAt: nowIso,
              comments: comments || 'Approved',
              stepOrder: currentOrder,
              status: 'APPROVED',
            }
          ]
        };
        setStoredBookings(current.map((b) => (b.id === id ? { ...b, ...updated } : b)));
        return {
          booking: updated,
          message: `Reservation approved by you. The request has been moved to the next approver (${nextApproverName}).`
        };
      }
    }

    // Final Approver Approved -> All approved!
    const updated: Booking = {
      ...targetBooking,
      status: 'APPROVED',
      currentApproverId: undefined,
      currentApproverName: undefined,
      auditHistory: [
        ...existingAudit,
        {
          id: `audit-${Date.now()}`,
          field: 'workflow_approval',
          oldValue: `Step ${currentOrder} (${actorName})`,
          newValue: `Approved by ${actorName}. All workflow approvers have approved the reservation.`,
          changedBy: actorName,
          changedAt: nowIso,
          comments: comments || 'Approved',
          stepOrder: currentOrder,
          status: 'APPROVED',
        }
      ]
    };
    setStoredBookings(current.map((b) => (b.id === id ? { ...b, ...updated } : b)));
    return {
      booking: updated,
      message: 'Reservation approved successfully. All workflow approvers have approved the reservation.'
    };
  },

  /**
   * Cancel a reservation - enforces creator authorization
   */
  async cancelBooking(id: string): Promise<Booking> {
    const apiData = await fetchApi<any>(`/reservations/${id}/cancel`, {
      method: 'POST',
    });

    if (apiData) {
      const cancelled: Booking = {
        id: apiData.id || id,
        environmentId: apiData.environment_id || '',
        environmentName: apiData.environment_name || '',
        businessUnit: apiData.business_unit || '',
        project: apiData.project || '',
        application: apiData.application || '',
        purpose: apiData.purpose || '',
        team: apiData.team || '',
        requestedBy: apiData.requested_by || '',
        priority: apiData.priority || 'MEDIUM',
        autoApprovalEnabled: Boolean(apiData.auto_approval_enabled),
        autoApprovalRule: apiData.auto_approval_rule,
        startDate: apiData.start_date || '',
        endDate: apiData.end_date || '',
        status: 'CANCELLED',
        reservationMode: apiData.reservation_mode || 'SHARED',
        rejectionReason: apiData.rejection_reason,
        rejectedAt: apiData.rejected_at,
        rejectionType: apiData.rejection_type,
        auditHistory: apiData.audit_history ? (typeof apiData.audit_history === 'string' ? JSON.parse(apiData.audit_history) : apiData.audit_history) : [],
      };
      const current = getStoredBookings() || [...INITIAL_BOOKINGS];
      setStoredBookings(current.map((b) => (b.id === id ? { ...b, ...cancelled } : b)));
      return cancelled;
    }

    return await this.updateBooking(id, { status: 'CANCELLED' });
  },

  /**
   * Reject a reservation - updates status to REJECTED with audit tracking
   */
  async rejectBooking(id: string, reason?: string): Promise<Booking> {
    const apiData = await fetchApi<any>(`/reservations/${id}/reject`, {
      method: 'POST',
      body: JSON.stringify({ reason: reason || 'Manually rejected by user' }),
    });

    if (apiData) {
      const rejected: Booking = {
        id: apiData.id || id,
        environmentId: apiData.environment_id || '',
        environmentName: apiData.environment_name || '',
        businessUnit: apiData.business_unit || '',
        project: apiData.project || '',
        application: apiData.application || '',
        purpose: apiData.purpose || '',
        team: apiData.team || '',
        requestedBy: apiData.requested_by || '',
        priority: apiData.priority || 'MEDIUM',
        autoApprovalEnabled: Boolean(apiData.auto_approval_enabled),
        autoApprovalRule: apiData.auto_approval_rule,
        startDate: apiData.start_date || '',
        endDate: apiData.end_date || '',
        status: apiData.status || 'REJECTED',
        rejectionReason: apiData.rejection_reason || reason || 'Manually rejected by user',
        rejectedAt: apiData.rejected_at || new Date().toISOString(),
        rejectionType: 'MANUAL',
      };
      const current = getStoredBookings() || [...INITIAL_BOOKINGS];
      setStoredBookings(current.map((b) => (b.id === id ? { ...b, ...rejected } : b)));
      return rejected;
    }

    return await this.updateBooking(id, {
      status: 'REJECTED',
      rejectionReason: reason || 'Manually rejected by user',
      rejectedAt: new Date().toISOString(),
      rejectionType: 'MANUAL',
    });
  },

  /**
   * Sweep and auto-reject expired reservations on backend
   */
  async autoRejectExpiredBookings(): Promise<number> {
    try {
      const apiData = await fetchApi<any>('/reservations/auto-reject-expired', {
        method: 'POST',
        isBackground: true,
      });
      return apiData?.auto_rejected_count || 0;
    } catch {
      return 0;
    }
  },


  /**
   * Update an existing reservation
   * Corresponds to FastAPI endpoint PUT /api/v1/reservations/{id}
   */
  async updateBooking(id: string, bookingData: Partial<Booking>): Promise<Booking> {
    if (bookingData.startDate && bookingData.endDate) {
      const s = new Date(bookingData.startDate).getTime();
      const e = new Date(bookingData.endDate).getTime();
      if (isNaN(s) || isNaN(e) || s >= e) {
        throw new Error('Start date and time cannot be greater than end date and time.');
      }
    }

    const payload: any = {};
    if (bookingData.environmentId !== undefined) payload.environment_id = bookingData.environmentId;
    if (bookingData.environmentName !== undefined) payload.environment_name = bookingData.environmentName;
    if (bookingData.businessUnit !== undefined) payload.business_unit = bookingData.businessUnit;
    if (bookingData.project !== undefined) payload.project = bookingData.project;
    if (bookingData.application !== undefined) payload.application = bookingData.application;
    if (bookingData.purpose !== undefined) payload.purpose = bookingData.purpose;
    if (bookingData.team !== undefined) payload.team = bookingData.team;
    if (bookingData.requestedBy !== undefined) payload.requested_by = bookingData.requestedBy;
    if (bookingData.priority !== undefined) payload.priority = bookingData.priority;
    if (bookingData.autoApprovalEnabled !== undefined) {
      payload.auto_approval_enabled = Boolean(bookingData.autoApprovalEnabled);
      payload.auto_approval_rule = bookingData.autoApprovalEnabled ? (bookingData.autoApprovalRule || null) : null;
    } else if (bookingData.autoApprovalRule !== undefined) {
      payload.auto_approval_rule = bookingData.autoApprovalRule;
    }
    if (bookingData.startDate !== undefined) payload.start_date = bookingData.startDate;
    if (bookingData.endDate !== undefined) payload.end_date = bookingData.endDate;
    if (bookingData.status !== undefined) payload.status = bookingData.status;
    if (bookingData.reservationMode !== undefined) payload.reservation_mode = bookingData.reservationMode;
    if (bookingData.rejectionReason !== undefined) payload.rejection_reason = bookingData.rejectionReason;
    if (bookingData.rejectedAt !== undefined) payload.rejected_at = bookingData.rejectedAt;
    if (bookingData.rejectionType !== undefined) payload.rejection_type = bookingData.rejectionType;
    if (bookingData.auditHistory !== undefined) payload.audit_history = JSON.stringify(bookingData.auditHistory);

    const apiData = await fetchApi<any>(`/reservations/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });

    const current = getStoredBookings() || [...INITIAL_BOOKINGS];
    const existing = current.find((b) => b.id === id);

    const updated: Booking = apiData
      ? {
          id: apiData.id || id,
          environmentId: apiData.environment_id || bookingData.environmentId || existing?.environmentId || '',
          environmentName: apiData.environment_name || bookingData.environmentName || existing?.environmentName || '',
          businessUnit: apiData.business_unit || bookingData.businessUnit || existing?.businessUnit || '',
          project: apiData.project !== undefined ? apiData.project : (bookingData.project ?? existing?.project ?? ''),
          application: apiData.application !== undefined ? apiData.application : (bookingData.application ?? existing?.application ?? ''),
          purpose: apiData.purpose || bookingData.purpose || existing?.purpose || '',
          team: apiData.team || bookingData.team || existing?.team || '',
          requestedBy: apiData.requested_by || bookingData.requestedBy || existing?.requestedBy || '',
          priority: apiData.priority || bookingData.priority || existing?.priority || 'MEDIUM',
          autoApprovalEnabled: Boolean(apiData.auto_approval_enabled ?? bookingData.autoApprovalEnabled ?? existing?.autoApprovalEnabled),
          autoApprovalRule: apiData.auto_approval_rule ?? bookingData.autoApprovalRule ?? existing?.autoApprovalRule,
          startDate: apiData.start_date || bookingData.startDate || existing?.startDate || '',
          endDate: apiData.end_date || bookingData.endDate || existing?.endDate || '',
          status: apiData.status || bookingData.status || existing?.status || 'CONFIRMED',
          reservationMode: apiData.reservation_mode || bookingData.reservationMode || existing?.reservationMode || 'SHARED',
          rejectionReason: apiData.rejection_reason || bookingData.rejectionReason || existing?.rejectionReason,
          rejectedAt: apiData.rejected_at || bookingData.rejectedAt || existing?.rejectedAt,
          rejectionType: apiData.rejection_type || bookingData.rejectionType || existing?.rejectionType,
          auditHistory: bookingData.auditHistory || existing?.auditHistory || [],
        }
      : ({
          ...existing,
          ...bookingData,
          id,
        } as Booking);

    const currentList = getStoredBookings() || [...INITIAL_BOOKINGS];
    setStoredBookings(currentList.map((b) => (b.id === id ? { ...b, ...updated } : b)));
    return updated;
  },

  /**
   * Check Availability - Find non-overlapping alternative slots based on duration & environment
   */
  findAvailableAlternativeSlots(
    targetBooking: Booking,
    allBookings: Booking[]
  ): AvailableSlotOption[] {
    if (!targetBooking.startDate || !targetBooking.endDate) return [];

    const reqStart = new Date(targetBooking.startDate).getTime();
    const reqEnd = new Date(targetBooking.endDate).getTime();
    if (isNaN(reqStart) || isNaN(reqEnd) || reqEnd <= reqStart) return [];

    const durationMs = reqEnd - reqStart;
    const durationHours = Math.round((durationMs / 3600000) * 10) / 10;

    const envName = targetBooking.environmentName || 'Target Environment';
    const envId = targetBooking.environmentId;

    // Filter active bookings on the same environment (excluding targetBooking)
    const activeEnvsBookings = allBookings.filter((b) => {
      if (
        b.id === targetBooking.id ||
        b.status === 'CANCELLED' ||
        b.status === 'REJECTED' ||
        b.status === 'AUTO_REJECTED'
      ) {
        return false;
      }
      return (
        (b.environmentId && envId && b.environmentId === envId) ||
        (b.environmentName && b.environmentName.toLowerCase() === envName.toLowerCase())
      );
    });

    const candidateSlots: AvailableSlotOption[] = [];
    const shiftOffsetsMs = [
      4 * 3600000,
      24 * 3600000,
      48 * 3600000,
      72 * 3600000,
      120 * 3600000,
    ];

    const pad = (n: number) => n.toString().padStart(2, '0');

    shiftOffsetsMs.forEach((offset, idx) => {
      const candStartMs = reqStart + offset;
      const candEndMs = candStartMs + durationMs;

      const candStartObj = new Date(candStartMs);
      const candEndObj = new Date(candEndMs);

      // Check collision
      const hasConflict = activeEnvsBookings.some((b) => {
        if (!b.startDate || !b.endDate) return false;
        const bStart = new Date(b.startDate).getTime();
        const bEnd = new Date(b.endDate).getTime();
        const isOverlap = candStartMs < bEnd && candEndMs > bStart;
        if (!isOverlap) return false;

        const modeA = targetBooking.reservationMode || 'SHARED';
        const modeB = b.reservationMode || 'SHARED';
        return modeA === 'DISRUPTIVE' || modeB === 'DISRUPTIVE';
      });

      const candStartIso = `${candStartObj.getFullYear()}-${pad(candStartObj.getMonth() + 1)}-${pad(candStartObj.getDate())}T${pad(candStartObj.getHours())}:${pad(candStartObj.getMinutes())}:${pad(candStartObj.getSeconds())}`;
      const candEndIso = `${candEndObj.getFullYear()}-${pad(candEndObj.getMonth() + 1)}-${pad(candEndObj.getDate())}T${pad(candEndObj.getHours())}:${pad(candEndObj.getMinutes())}:${pad(candEndObj.getSeconds())}`;

      const displayDate = candStartObj.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
      const displayStartTime = candStartObj.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
      const displayEndTime = candEndObj.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

      candidateSlots.push({
        id: `slot-${idx}-${Date.now()}`,
        startDate: candStartIso,
        endDate: candEndIso,
        displayDate,
        displayStartTime,
        displayEndTime,
        durationHours,
        environmentName: envName,
        status: hasConflict ? 'ALREADY_BOOKED' : 'AVAILABLE',
        reservationModeCompatibility: hasConflict
          ? 'Conflicting with existing reservation'
          : `Compatible with ${targetBooking.reservationMode || 'SHARED'} mode`,
      });
    });

    return candidateSlots;
  },

  /**
   * Final Validation right before resolving conflict to prevent race conditions
   */
  validateSlotAvailability(
    bookingId: string,
    environmentId: string,
    environmentName: string,
    startDateStr: string,
    endDateStr: string,
    mode: ReservationMode = 'SHARED',
    allBookings: Booking[]
  ): { isAvailable: boolean; conflictReason?: string } {
    const s = new Date(startDateStr).getTime();
    const e = new Date(endDateStr).getTime();
    if (isNaN(s) || isNaN(e) || s >= e) {
      return { isAvailable: false, conflictReason: 'Start date and time cannot be greater than end date and time.' };
    }

    const conflicting = allBookings.find((other) => {
      if (
        other.id === bookingId ||
        other.status === 'CANCELLED' ||
        other.status === 'REJECTED' ||
        other.status === 'AUTO_REJECTED'
      ) {
        return false;
      }
      const sameEnv =
        (other.environmentId && environmentId && other.environmentId === environmentId) ||
        (other.environmentName && environmentName && other.environmentName.toLowerCase() === environmentName.toLowerCase());
      if (!sameEnv || !other.startDate || !other.endDate) return false;

      const oStart = new Date(other.startDate).getTime();
      const oEnd = new Date(other.endDate).getTime();
      const isOverlap = s < oEnd && e > oStart;
      if (!isOverlap) return false;

      const otherMode = other.reservationMode || 'SHARED';
      return mode === 'DISRUPTIVE' || otherMode === 'DISRUPTIVE';
    });

    if (conflicting) {
      return {
        isAvailable: false,
        conflictReason: `The selected slot is no longer available. Overlaps with booking #${conflicting.id} (${conflicting.purpose}).`,
      };
    }

    return { isAvailable: true };
  },
};

export interface AvailableSlotOption {
  id: string;
  startDate: string;
  endDate: string;
  displayDate: string;
  displayStartTime: string;
  displayEndTime: string;
  durationHours: number;
  environmentName: string;
  status: 'AVAILABLE' | 'ALREADY_BOOKED';
  reservationModeCompatibility: string;
}

