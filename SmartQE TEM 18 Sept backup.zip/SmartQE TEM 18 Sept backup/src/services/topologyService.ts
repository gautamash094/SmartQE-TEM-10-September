import { fetchApi } from './apiClient';
import { environmentDetailsService } from './environmentDetailsService';
import { authService } from './authService';
import {
  TopologyGraphResponse,
  TopologyNode,
  TopologyEdge,
  ImpactAnalysisResult,
  TopologyFilterState,
  TopologyRelationshipType
} from '../types/topology';

export interface CustomRelationshipPayload {
  source_id: string;
  source_type: string;
  source_name: string;
  target_id: string;
  target_type: string;
  target_name: string;
  relationship_type: TopologyRelationshipType;
  environment_id?: string;
  environment_name?: string;
  port?: string;
  protocol?: string;
  latency_ms?: number;
  notes?: string;
}

const LOCAL_STORAGE_CUSTOM_RELS_KEY = 'smartqe_tem_custom_topology_relationships';

export const topologyService = {
  /**
   * Fetch consolidated topology graph from backend with fallback
   */
  async getTopologyGraph(filters?: Partial<TopologyFilterState>): Promise<TopologyGraphResponse> {
    try {
      const queryParams = new URLSearchParams();
      if (filters?.environmentId && filters.environmentId !== 'ALL') {
        queryParams.append('environment_id', filters.environmentId);
      }
      if (filters?.businessUnit && filters.businessUnit !== 'ALL') {
        queryParams.append('business_unit', filters.businessUnit);
      }
      if (filters?.status && filters.status !== 'ALL') {
        queryParams.append('status', filters.status);
      }

      const queryString = queryParams.toString();
      const endpoint = `/topology/graph${queryString ? `?${queryString}` : ''}`;
      const data = await fetchApi<TopologyGraphResponse>(endpoint);
      if (data && data.nodes && data.nodes.length > 0) {
        return data;
      }
      return this.synthesizeLocalTopologyGraph(filters);
    } catch (err) {
      console.warn('Backend topology API unreachable, generating dynamic local topology fallback:', err);
      return this.synthesizeLocalTopologyGraph(filters);
    }
  },

  /**
   * Run Impact Analysis / Blast Radius Calculation
   */
  async getImpactAnalysis(nodeId: string, fullGraph?: TopologyGraphResponse): Promise<ImpactAnalysisResult> {
    try {
      const endpoint = `/topology/impact?node_id=${encodeURIComponent(nodeId)}`;
      const data = await fetchApi<ImpactAnalysisResult>(endpoint);
      if (data && data.impact_level) {
        return data;
      }
      return this.computeLocalImpactAnalysis(nodeId, fullGraph);
    } catch (err) {
      console.warn('Backend impact API unreachable, computing locally:', err);
      return this.computeLocalImpactAnalysis(nodeId, fullGraph);
    }
  },

  /**
   * Create custom relationship
   */
  async createRelationship(payload: CustomRelationshipPayload): Promise<any> {
    try {
      const data = await fetchApi<any>('/topology/relationships', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      if (data) return data;
      throw new Error('Fallback required');
    } catch (err) {
      console.warn('Backend unreachable, storing relationship in localStorage:', err);
      const saved = this.getLocalCustomRelationships();
      const newRel = {
        ...payload,
        id: `local_rel_${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_active: true
      };
      saved.push(newRel);
      localStorage.setItem(LOCAL_STORAGE_CUSTOM_RELS_KEY, JSON.stringify(saved));
      return newRel;
    }
  },

  /**
   * Delete custom relationship
   */
  async deleteRelationship(id: string): Promise<void> {
    try {
      await fetchApi<any>(`/topology/relationships/${id}`, {
        method: 'DELETE'
      });
    } catch (err) {
      const saved = this.getLocalCustomRelationships().filter((r: any) => r.id !== id);
      localStorage.setItem(LOCAL_STORAGE_CUSTOM_RELS_KEY, JSON.stringify(saved));
    }
  },

  getLocalCustomRelationships(): any[] {
    try {
      const raw = localStorage.getItem(LOCAL_STORAGE_CUSTOM_RELS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  /**
   * Client-side synthesis fallback aggregating TEM entities from Environment Details module.
   * Reads from the same localStorage keys as environmentDetailsService to ensure consistency.
   */
  synthesizeLocalTopologyGraph(filters?: Partial<TopologyFilterState>): TopologyGraphResponse {
    const nodesMap = new Map<string, TopologyNode>();
    const edgesMap = new Map<string, TopologyEdge>();

    const sessionUser = authService.getCurrentSessionUser();
    const isSuperAdmin = !sessionUser || sessionUser.isSuperAdmin;

    // ── 1. Load Environments from Environment Details (filtered by session user) ──
    const rawProfiles: any[] = environmentDetailsService.getProfiles() as any[];

    // ── 2. Load Servers from Environment Details (filtered by session user) ──
    const rawServers: any[] = environmentDetailsService.getServers() as any[];

    // ── 3. Load Software from Environment Details (filtered by session user) ──
    const rawSoftware: any[] = environmentDetailsService.getSoftware() as any[];

    // ── 4. Load Applications from Portfolio ──
    let rawApps: any[] = [];
    try {
      const appStr = localStorage.getItem('smartqe_tem_applications_v1');
      if (appStr) {
        const parsed = JSON.parse(appStr);
        rawApps = isSuperAdmin
          ? parsed
          : parsed.filter((a: any) => a.ownerId === sessionUser?.id || a.createdBy?.toLowerCase() === sessionUser?.username?.toLowerCase());
      }
    } catch {}

    // ── 5. Load Bookings for Application mappings ──
    let rawBookings: any[] = [];
    try {
      const bStr = localStorage.getItem('smartqe_bookings_v2');
      if (bStr) rawBookings = JSON.parse(bStr);
    } catch {}

    // ── 6. Load Incidents for status overlay ──
    let incidents: any[] = [];
    try {
      const incStr = localStorage.getItem('smartqe_incidents');
      if (incStr) incidents = JSON.parse(incStr);
    } catch {}
    const incidentsByEnv: Record<string, any[]> = {};
    incidents.forEach(inc => {
      if (inc.environmentId) {
        if (!incidentsByEnv[inc.environmentId]) incidentsByEnv[inc.environmentId] = [];
        incidentsByEnv[inc.environmentId].push(inc);
      }
    });

    // ── 7. Build Environment Nodes from EnvironmentProfiles ──
    rawProfiles.forEach(profile => {
      const envIncs = incidentsByEnv[profile.id] || [];
      const nodeStatus: 'HEALTHY' | 'WARNING' | 'DOWN' | 'DEGRADED' =
        envIncs.length > 0 ? 'WARNING' :
        profile.status === 'ACTIVE' ? 'HEALTHY' :
        profile.status === 'INACTIVE' ? 'DOWN' :
        profile.status === 'MAINTENANCE' ? 'DEGRADED' :
        'HEALTHY';

      nodesMap.set(profile.id, {
        id: profile.id,
        name: profile.name,
        type: 'ENVIRONMENT',
        sub_type: profile.type || 'DEV',
        status: nodeStatus,
        environment_id: profile.id,
        environment_name: profile.name,
        business_unit: profile.ownerTeam || '',
        account_name: profile.networkZone || 'Enterprise',
        active_incidents_count: envIncs.length,
        active_incident_severities: envIncs.map((i: any) => i.severity),
        properties: {
          type: profile.type,
          description: profile.description,
          networkZone: profile.networkZone,
          ownerTeam: profile.ownerTeam,
        }
      });

      // Build Server Nodes linked to this Environment
      const profileServerIds: string[] = profile.serverIds || profile.server_ids || [];
      profileServerIds.forEach(serverId => {
        const srv = rawServers.find((s: any) => s.id === serverId);
        if (!srv) return;

        const isCloudSrv = srv.infrastructureType ? srv.infrastructureType === 'CLOUD' : !!srv.cloudProvider;
        if (!nodesMap.has(srv.id)) {
          nodesMap.set(srv.id, {
            id: srv.id,
            name: srv.name,
            type: 'SERVER',
            sub_type: srv.serverType || srv.type || 'Application Server',
            status: (srv.status as any) || 'HEALTHY',
            environment_id: profile.id,
            environment_name: profile.name,
            ip_address: srv.hostIp || srv.ipAddress,
            hostname: srv.hostname || srv.name,
            cloud_provider: isCloudSrv ? srv.cloudProvider : undefined,
            region: isCloudSrv ? srv.region : undefined,
            specs: [srv.cpuCores ? `${srv.cpuCores} vCPU` : null, srv.ramGb ? `${srv.ramGb}GB RAM` : null].filter(Boolean).join(' / ') || undefined,
            properties: { os: srv.operatingSystem, type: srv.serverType || srv.type }
          });
        }

        // Edge: Environment → Server (HOSTED_ON)
        const edgeId = `edge_${profile.id}_${srv.id}_hosted_on`;
        if (!edgesMap.has(edgeId)) {
          edgesMap.set(edgeId, {
            id: edgeId,
            source: profile.id,
            target: srv.id,
            relationship_type: 'HOSTED_ON',
            label: 'Hosted On',
            is_custom: false,
            is_active: true
          });
        }
      });

      // Build Software Nodes linked to this Environment
      const profileSoftwareIds: string[] = profile.softwareIds || profile.software_ids || [];
      profileSoftwareIds.forEach(softwareId => {
        const sw = rawSoftware.find((s: any) => s.id === softwareId);
        if (!sw) return;

        if (!nodesMap.has(sw.id)) {
          nodesMap.set(sw.id, {
            id: sw.id,
            name: sw.name,
            type: 'SOFTWARE',
            sub_type: sw.category || 'Application',
            status: (sw.status as any) || 'HEALTHY',
            environment_id: profile.id,
            environment_name: profile.name,
            properties: { version: sw.version, vendor: sw.vendor, category: sw.category }
          });
        }

        // Edge: Environment → Software (RUNS_ON)
        const swEdgeId = `edge_${profile.id}_${sw.id}_runs_on`;
        if (!edgesMap.has(swEdgeId)) {
          edgesMap.set(swEdgeId, {
            id: swEdgeId,
            source: profile.id,
            target: sw.id,
            relationship_type: 'RUNS_ON',
            label: 'Runs On',
            is_custom: false,
            is_active: true
          });
        }

        if (sw.serverId && nodesMap.has(sw.serverId)) {
          const swSrvEdgeId = `edge_${sw.serverId}_${sw.id}_runs_on`;
          if (!edgesMap.has(swSrvEdgeId)) {
            edgesMap.set(swSrvEdgeId, {
              id: swSrvEdgeId,
              source: sw.serverId,
              target: sw.id,
              relationship_type: 'RUNS_ON',
              label: 'Runs On',
              is_custom: false,
              is_active: true
            });
          }
        }
      });
    });

    // ── 8. Ensure ALL Servers in rawServers are added as SERVER nodes ──
    rawServers.forEach((srv: any) => {
      const profile = rawProfiles.find(
        (p: any) => (p.serverIds || p.server_ids || []).includes(srv.id) || p.name === srv.environmentName || p.id === srv.environmentId
      );

      const isCloudSrv = srv.infrastructureType ? srv.infrastructureType === 'CLOUD' : !!srv.cloudProvider;
      if (!nodesMap.has(srv.id)) {
        nodesMap.set(srv.id, {
          id: srv.id,
          name: srv.name,
          type: 'SERVER',
          sub_type: srv.serverType || srv.type || 'Application Server',
          status: (srv.status as any) || 'HEALTHY',
          environment_id: profile?.id || srv.environmentId,
          environment_name: profile?.name || srv.environmentName,
          ip_address: srv.hostIp || srv.ipAddress,
          hostname: srv.hostname || srv.name,
          cloud_provider: isCloudSrv ? srv.cloudProvider : undefined,
          region: isCloudSrv ? srv.region : undefined,
          specs: [srv.cpuCores ? `${srv.cpuCores} vCPU` : null, srv.ramGb ? `${srv.ramGb}GB RAM` : null].filter(Boolean).join(' / ') || undefined,
          properties: { os: srv.operatingSystem, type: srv.serverType || srv.type }
        });
      } else {
        const existingNode = nodesMap.get(srv.id)!;
        existingNode.type = 'SERVER';
      }

      if (profile) {
        const edgeId = `edge_${profile.id}_${srv.id}_hosted_on`;
        if (!edgesMap.has(edgeId)) {
          edgesMap.set(edgeId, {
            id: edgeId,
            source: profile.id,
            target: srv.id,
            relationship_type: 'HOSTED_ON',
            label: 'Hosted On',
            is_custom: false,
            is_active: true
          });
        }
      }
    });

    // ── 9. Build Application Nodes from Portfolio Applications and Bookings ──
    const appSet = new Set<string>();

    rawApps.forEach((app: any) => {
      if (app.name && !nodesMap.has(`app-${app.id || app.name}`)) {
        const appId = `app-${app.id || app.name}`;
        appSet.add(app.name.toLowerCase());
        nodesMap.set(appId, {
          id: appId,
          name: app.name,
          type: 'APPLICATION',
          sub_type: 'Enterprise App',
          status: 'HEALTHY',
          business_unit: app.businessUnit || '',
          properties: { code: app.code, owner: app.owner, project: app.projectName }
        });

        const matchingBooking = rawBookings.find((b: any) => b.application?.toLowerCase() === app.name.toLowerCase());
        const matchingProfile = rawProfiles.find((p: any) => p.name === matchingBooking?.environmentName || p.id === matchingBooking?.environmentId);
        
        if (matchingProfile) {
          const appEdgeId = `edge_${matchingProfile.id}_${appId}_runs_on`;
          if (!edgesMap.has(appEdgeId)) {
            edgesMap.set(appEdgeId, {
              id: appEdgeId,
              source: matchingProfile.id,
              target: appId,
              relationship_type: 'RUNS_ON',
              label: 'Runs On',
              is_custom: false,
              is_active: true
            });
          }
        }
      }
    });

    rawBookings.forEach((b: any) => {
      if (b.application && !appSet.has(b.application.toLowerCase())) {
        const appId = `app-${b.application.toLowerCase().replace(/\s+/g, '-')}`;
        appSet.add(b.application.toLowerCase());
        nodesMap.set(appId, {
          id: appId,
          name: b.application,
          type: 'APPLICATION',
          sub_type: 'Business Application',
          status: 'HEALTHY',
          business_unit: b.businessUnit || '',
          properties: { project: b.project }
        });

        const profile = rawProfiles.find((p: any) => p.name === b.environmentName || p.id === b.environmentId);
        if (profile) {
          const appEdgeId = `edge_${profile.id}_${appId}_runs_on`;
          if (!edgesMap.has(appEdgeId)) {
            edgesMap.set(appEdgeId, {
              id: appEdgeId,
              source: profile.id,
              target: appId,
              relationship_type: 'RUNS_ON',
              label: 'Runs On',
              is_custom: false,
              is_active: true
            });
          }
        }
      }
    });

    // ── 8. Merge Custom Stored Relationships ──
    const customRels = this.getLocalCustomRelationships();
    customRels.forEach((rel: any) => {
      if (!nodesMap.has(rel.source_id)) {
        nodesMap.set(rel.source_id, {
          id: rel.source_id,
          name: rel.source_name,
          type: rel.source_type,
          status: 'HEALTHY'
        });
      }
      if (!nodesMap.has(rel.target_id)) {
        nodesMap.set(rel.target_id, {
          id: rel.target_id,
          name: rel.target_name,
          type: rel.target_type,
          status: 'HEALTHY'
        });
      }
      edgesMap.set(rel.id, {
        id: rel.id,
        source: rel.source_id,
        target: rel.target_id,
        relationship_type: rel.relationship_type,
        label: rel.relationship_type.replace(/_/g, ' '),
        port: rel.port,
        protocol: rel.protocol,
        latency_ms: rel.latency_ms,
        is_custom: true,
        is_active: rel.is_active !== false
      });
    });

    let allNodes = Array.from(nodesMap.values());
    let allEdges = Array.from(edgesMap.values());

    // ── 9. Apply Filter State ──
    if (filters?.environmentId && filters.environmentId !== 'ALL') {
      const matchedNodeIds = new Set<string>();
      allNodes.forEach(n => {
        if (n.environment_id === filters.environmentId || n.id === filters.environmentId) {
          matchedNodeIds.add(n.id);
        }
      });
      allEdges.forEach(e => {
        if (matchedNodeIds.has(e.source) || matchedNodeIds.has(e.target)) {
          matchedNodeIds.add(e.source);
          matchedNodeIds.add(e.target);
        }
      });
      allNodes = allNodes.filter(n => matchedNodeIds.has(n.id));
      allEdges = allEdges.filter(e => matchedNodeIds.has(e.source) && matchedNodeIds.has(e.target));
    }

    if (filters?.businessUnit && filters.businessUnit !== 'ALL') {
      allNodes = allNodes.filter(n => !n.business_unit || n.business_unit === filters.businessUnit);
    }

    if (filters?.nodeTypes && filters.nodeTypes.length > 0) {
      allNodes = allNodes.filter(n => filters.nodeTypes!.includes(n.type));
      const validIds = new Set(allNodes.map(n => n.id));
      allEdges = allEdges.filter(e => validIds.has(e.source) && validIds.has(e.target));
    }

    if (filters?.hasActiveIncidentsOnly) {
      allNodes = allNodes.filter(n => (n.active_incidents_count || 0) > 0);
      const validIds = new Set(allNodes.map(n => n.id));
      allEdges = allEdges.filter(e => validIds.has(e.source) && validIds.has(e.target));
    }

    return {
      nodes: allNodes,
      edges: allEdges,
      metrics: {
        total_nodes: allNodes.length,
        total_edges: allEdges.length,
        environments_count: allNodes.filter(n => n.type === 'ENVIRONMENT').length,
        applications_count: allNodes.filter(n => n.type === 'APPLICATION' || n.type === 'SOFTWARE' || n.type === 'MICROSERVICE').length,
        servers_count: allNodes.filter(n => n.type === 'SERVER').length,
        software_count: allNodes.filter(n => n.type === 'SOFTWARE').length,
        databases_count: allNodes.filter(n => n.type === 'DATABASE').length,
        active_incidents_count: allNodes.reduce((acc, n) => acc + (n.active_incidents_count || 0), 0),
        unhealthy_nodes_count: allNodes.filter(n => n.status !== 'HEALTHY').length
      }
    };
  },

  /**
   * Local BFS Impact Analysis
   */
  computeLocalImpactAnalysis(nodeId: string, graph?: TopologyGraphResponse): ImpactAnalysisResult {
    const currentGraph = graph || this.synthesizeLocalTopologyGraph();
    const targetNode = currentGraph.nodes.find(n => n.id === nodeId) || {
      id: nodeId,
      name: `Component ${nodeId}`,
      type: 'SERVER',
      status: 'HEALTHY'
    };

    const outgoingAdj = new Map<string, string[]>();
    const incomingAdj = new Map<string, string[]>();

    currentGraph.edges.forEach(e => {
      if (!outgoingAdj.has(e.source)) outgoingAdj.set(e.source, []);
      outgoingAdj.get(e.source)!.push(e.target);

      if (!incomingAdj.has(e.target)) incomingAdj.set(e.target, []);
      incomingAdj.get(e.target)!.push(e.source);
    });

    // Traverse Downstream
    const downstreamIds = new Set<string>();
    const qDown = [nodeId];
    while (qDown.length > 0) {
      const curr = qDown.shift()!;
      (outgoingAdj.get(curr) || []).forEach(next => {
        if (!downstreamIds.has(next) && next !== nodeId) {
          downstreamIds.add(next);
          qDown.push(next);
        }
      });
    }

    // Traverse Upstream
    const upstreamIds = new Set<string>();
    const qUp = [nodeId];
    while (qUp.length > 0) {
      const curr = qUp.shift()!;
      (incomingAdj.get(curr) || []).forEach(prev => {
        if (!upstreamIds.has(prev) && prev !== nodeId) {
          upstreamIds.add(prev);
          qUp.push(prev);
        }
      });
    }

    const nodeMap = new Map<string, TopologyNode>(currentGraph.nodes.map(n => [n.id, n]));
    const upstreamNodes = Array.from(upstreamIds).map(id => nodeMap.get(id)!).filter(Boolean);
    const downstreamNodes = Array.from(downstreamIds).map(id => nodeMap.get(id)!).filter(Boolean);

    const allAffected = [...upstreamNodes, ...downstreamNodes];
    const affectedEnvs = Array.from(new Set(allAffected.map(n => n.environment_name || n.name).filter(Boolean)));
    const affectedApps = Array.from(new Set(allAffected.filter(n => n.type === 'APPLICATION' || n.type === 'MICROSERVICE').map(n => n.name)));
    const affectedServers = Array.from(new Set(allAffected.filter(n => n.type === 'SERVER').map(n => n.name)));
    const affectedServices = Array.from(new Set(allAffected.filter(n => n.type === 'SOFTWARE' || n.type === 'SERVICE').map(n => n.name)));
    const affectedDbs = Array.from(new Set(allAffected.filter(n => n.type === 'DATABASE').map(n => n.name)));

    const score = Math.min(100, (affectedEnvs.length * 25) + (affectedApps.length * 15) + (affectedServers.length * 10) + (affectedDbs.length * 15) + 10);
    const level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = score >= 75 ? 'CRITICAL' : score >= 50 ? 'HIGH' : score >= 25 ? 'MEDIUM' : 'LOW';

    return {
      target_node: targetNode,
      impact_score: score,
      impact_level: level,
      affected_environments: affectedEnvs,
      affected_applications: affectedApps,
      affected_servers: affectedServers,
      affected_services: affectedServices,
      affected_databases: affectedDbs,
      upstream_nodes: upstreamNodes,
      downstream_nodes: downstreamNodes,
      total_affected_count: allAffected.length
    };
  }
};
