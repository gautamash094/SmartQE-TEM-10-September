import {
  Booking,
  EnvironmentStatus,
  EnvironmentTier,
  Incident,
  Release,
  ReservationMode,
} from '../types';
import { EnvironmentProfile } from '../types/environmentDetails';
import {
  AIFeedbackRecord,
  AlternativeEnvironmentRecommendation,
  BookingAIAssistResult,
  CapacityRecommendation,
  ConflictExplanationPoint,
  ConflictPredictionResult,
  ConflictRiskLevel,
  DemandForecastResult,
  ForecastDimensionBreakdown,
  ForecastHorizon,
  PredictionConfidence,
  PredictiveHeatmapCell,
  ProactiveAlert,
  TimeSeriesForecastPoint,
  WhatIfScenarioInput,
  WhatIfScenarioResult,
} from '../types/aiIntelligence';

// Local In-Memory Storage key for AI Feedback closed-loop learning
const AI_FEEDBACK_KEY = 'smartqe_tem_ai_feedback_history';

class AIIntelligenceService {
  /**
   * Cold-Start Multi-Tier Conflict Prediction & Explanation Engine
   * Combines rule-based overlapping, historical booking density, release schedule collisions,
   * reservation modes (SHARED vs DISRUPTIVE), and health degradation penalties.
   */
  public predictConflictRisk(
    environmentId: string,
    startDateStr: string,
    endDateStr: string,
    reservationMode: ReservationMode = 'SHARED',
    profiles: EnvironmentProfile[],
    bookings: Booking[],
    incidents: Incident[] = [],
    releases: Release[] = [],
    excludeBookingId?: string
  ): ConflictPredictionResult {
    const targetEnv = profiles.find((p) => p.id === environmentId || p.name.toLowerCase() === environmentId.toLowerCase());
    const envName = targetEnv ? targetEnv.name : 'Selected Environment';

    const reqStart = new Date(startDateStr).getTime();
    const reqEnd = new Date(endDateStr).getTime();

    const explanations: ConflictExplanationPoint[] = [];

    // Fallback if invalid dates
    if (isNaN(reqStart) || isNaN(reqEnd) || reqEnd <= reqStart) {
      return {
        environmentId,
        environmentName: envName,
        startDate: startDateStr,
        endDate: endDateStr,
        conflictProbability: 0,
        riskLevel: 'LOW',
        confidence: 'LOW',
        explanations: [
          {
            id: 'exp-invalid',
            category: 'HISTORICAL_DENSITY',
            title: 'Insufficient Date Window',
            detail: 'Valid start and end date times are required to compute AI risk.',
            severity: 'INFO',
          },
        ],
        overlappingBookingsCount: 0,
        disruptiveBookingsCount: 0,
        upcomingReleasesCount: 0,
        recentIncidentsCount: 0,
        healthPenalty: 0,
      };
    }

    // 1. Direct Time Overlaps on Active Bookings
    const activeBookings = bookings.filter(
      (b) =>
        b.status !== 'CANCELLED' &&
        b.status !== 'REJECTED' &&
        b.status !== 'AUTO_REJECTED' &&
        (!excludeBookingId || b.id !== excludeBookingId)
    );

    const overlappingBookings = activeBookings.filter((b) => {
      const sameEnv =
        (b.environmentId && b.environmentId === environmentId) ||
        (targetEnv && b.environmentName && b.environmentName.toLowerCase() === targetEnv.name.toLowerCase());
      if (!sameEnv || !b.startDate || !b.endDate) return false;
      const bStart = new Date(b.startDate).getTime();
      const bEnd = new Date(b.endDate).getTime();
      return reqStart < bEnd && reqEnd > bStart;
    });

    const disruptiveCount = overlappingBookings.filter(
      (b) => (b.reservationMode || 'SHARED') === 'DISRUPTIVE'
    ).length;

    // 2. Upcoming Release Collisions
    const releaseCollisions = releases.filter((r) => {
      const sameEnv =
        (r.environmentId && r.environmentId === environmentId) ||
        (targetEnv && r.environmentName && r.environmentName.toLowerCase() === targetEnv.name.toLowerCase());
      if (!sameEnv || !r.scheduledDate) return false;
      const rTime = new Date(r.scheduledDate).getTime();
      // Release within +/- 2 days of requested window
      return rTime >= reqStart - 172800000 && rTime <= reqEnd + 172800000;
    });

    // 3. Environment Health & Incident Penalty
    const envIncidents = incidents.filter(
      (i) =>
        i.status !== 'RESOLVED' &&
        ((i.environmentId && i.environmentId === environmentId) ||
          (targetEnv && i.environmentName && i.environmentName.toLowerCase() === targetEnv.name.toLowerCase()))
    );

    let healthPenalty = 0;
    if (targetEnv) {
      if (targetEnv.status === 'DOWN') healthPenalty += 35;
      else if (targetEnv.status === 'DEGRADED') healthPenalty += 20;
      else if (targetEnv.status === 'MAINTENANCE') healthPenalty += 30;
    }
    healthPenalty += envIncidents.length * 10;

    // 4. Historical Density Calculation (same day of week & same time frame)
    const reqDayOfWeek = new Date(reqStart).getDay();
    const historicalDensityCount = activeBookings.filter((b) => {
      if (!b.startDate) return false;
      return new Date(b.startDate).getDay() === reqDayOfWeek;
    }).length;

    // 5. Probability Algorithm
    let probabilityScore = 0;

    if (overlappingBookings.length > 0) {
      if (reservationMode === 'DISRUPTIVE' || disruptiveCount > 0) {
        probabilityScore += 70 + overlappingBookings.length * 10;
      } else {
        probabilityScore += 30 + overlappingBookings.length * 15;
      }
    }

    if (releaseCollisions.length > 0) {
      probabilityScore += releaseCollisions.length * 15;
    }

    probabilityScore += Math.min(healthPenalty, 30);

    if (historicalDensityCount > 4) {
      probabilityScore += 10;
    }

    // Clamp between 5% and 98%
    probabilityScore = Math.max(5, Math.min(98, probabilityScore));

    // Determine Risk Level
    let riskLevel: ConflictRiskLevel = 'LOW';
    if (probabilityScore >= 81) riskLevel = 'VERY_HIGH';
    else if (probabilityScore >= 61) riskLevel = 'HIGH';
    else if (probabilityScore >= 31) riskLevel = 'MEDIUM';

    // Confidence Level based on historical sample size
    let confidence: PredictionConfidence = 'HIGH';
    if (bookings.length < 5) confidence = 'LOW';
    else if (bookings.length < 15) confidence = 'MEDIUM';

    // 6. Generate Data-Backed Explanations
    if (overlappingBookings.length > 0) {
      explanations.push({
        id: 'exp-overlap',
        category: 'OVERLAPPING_BOOKINGS',
        title: `${overlappingBookings.length} Overlapping Reservation(s)`,
        detail: `${overlappingBookings.length} active reservation(s) coincide with your requested time window.`,
        severity: disruptiveCount > 0 || reservationMode === 'DISRUPTIVE' ? 'CRITICAL' : 'WARNING',
      });
    }

    if (disruptiveCount > 0) {
      explanations.push({
        id: 'exp-disruptive',
        category: 'DISRUPTIVE_MODE',
        title: `${disruptiveCount} Exclusive Disruptive Mode Conflict`,
        detail: 'At least one existing reservation requires exclusive control of the environment.',
        severity: 'CRITICAL',
      });
    }

    if (releaseCollisions.length > 0) {
      explanations.push({
        id: 'exp-release',
        category: 'RELEASE_COLLISION',
        title: `${releaseCollisions.length} Planned Pipeline Release(s)`,
        detail: `Major release deployments (${releaseCollisions.map((r) => r.name).join(', ')}) scheduled within this window.`,
        severity: 'WARNING',
      });
    }

    if (targetEnv && (targetEnv.status === 'DEGRADED' || targetEnv.status === 'DOWN' || envIncidents.length > 0)) {
      explanations.push({
        id: 'exp-health',
        category: 'HEALTH_INCIDENT_PENALTY',
        title: `Environment Status: ${targetEnv?.status || 'DEGRADED'}`,
        detail: `Environment has ${envIncidents.length} active incident(s) and a health stability penalty of +${healthPenalty}%.`,
        severity: targetEnv.status === 'DOWN' ? 'CRITICAL' : 'WARNING',
      });
    }

    if (historicalDensityCount >= 3) {
      explanations.push({
        id: 'exp-density',
        category: 'HISTORICAL_DENSITY',
        title: 'High Historical Booking Peak',
        detail: `Historically, ${historicalDensityCount} reservations occur during this day-of-week pattern.`,
        severity: 'INFO',
      });
    }

    if (explanations.length === 0) {
      explanations.push({
        id: 'exp-clear',
        category: 'HISTORICAL_DENSITY',
        title: 'Optimal Availability Window',
        detail: 'No overlapping reservations or release pipeline collisions detected for this window.',
        severity: 'INFO',
      });
    }

    return {
      environmentId,
      environmentName: envName,
      startDate: startDateStr,
      endDate: endDateStr,
      conflictProbability: Math.round(probabilityScore),
      riskLevel,
      confidence,
      explanations,
      overlappingBookingsCount: overlappingBookings.length,
      disruptiveBookingsCount: disruptiveCount,
      upcomingReleasesCount: releaseCollisions.length,
      recentIncidentsCount: envIncidents.length,
      healthPenalty,
    };
  }

  /**
   * Intelligent Alternative Environment Recommender Engine
   * Filters compatible candidate environments (same tier, tech stack, health status)
   * and ranks them by lowest predicted conflict risk & utilization.
   */
  public recommendAlternativeEnvironments(
    targetEnvId: string,
    startDateStr: string,
    endDateStr: string,
    profiles: EnvironmentProfile[],
    bookings: Booking[],
    incidents: Incident[] = [],
    excludeBookingId?: string
  ): AlternativeEnvironmentRecommendation[] {
    const targetEnv = profiles.find((p) => p.id === targetEnvId || p.name.toLowerCase() === targetEnvId.toLowerCase());
    const candidates = profiles.filter((p) => p.id !== targetEnvId && p.status !== 'DOWN');

    const recommendations: AlternativeEnvironmentRecommendation[] = [];

    candidates.forEach((cand) => {
      // 1. Conflict Prediction for candidate
      const candPred = this.predictConflictRisk(cand.id, startDateStr, endDateStr, 'SHARED', profiles, bookings, incidents, [], excludeBookingId);

      // 2. Compatibility Score (Tier match + Tech stack overlap + Status)
      let compat = 70;
      if (targetEnv && targetEnv.type === cand.type) compat += 15;
      if (cand.status === 'HEALTHY') compat += 10;
      else if (cand.status === 'DEGRADED') compat -= 15;

      // Tech Stack match
      const targetStack: string[] = ((targetEnv as any)?.techStack || []).map((s: string) => String(s).toUpperCase());
      const candStack: string[] = ((cand as any)?.techStack || []).map((s: string) => String(s).toUpperCase());
      const matchedStack = candStack.filter((s: string) => targetStack.includes(s));

      if (targetStack.length > 0) {
        const stackOverlapRatio = matchedStack.length / targetStack.length;
        compat += Math.round(stackOverlapRatio * 10);
      }

      compat = Math.max(40, Math.min(99, compat));

      // 3. Predicted Utilization
      const candBookingsCount = bookings.filter(
        (b) => b.environmentId === cand.id && b.status !== 'CANCELLED' && (!excludeBookingId || b.id !== excludeBookingId)
      ).length;
      const predictedUtil = Math.min(95, Math.max(15, candBookingsCount * 18 + candPred.conflictProbability * 0.3));

      // Construct reasoning
      let reasoning = `Equivalent ${cand.type} environment with ${cand.status} status and ${candPred.conflictProbability}% predicted conflict risk.`;
      if (matchedStack.length > 0) {
        reasoning += ` Matches tech stack (${matchedStack.slice(0, 2).join(', ')}).`;
      }

      recommendations.push({
        environmentId: cand.id,
        environmentName: cand.name,
        tier: (cand.type || 'UAT') as EnvironmentTier,
        compatibilityScore: compat,
        predictedUtilization: Math.round(predictedUtil),
        conflictRisk: candPred.riskLevel,
        reasoning,
        techStackMatch: matchedStack,
        topologyMatchScore: Math.round(compat * 0.95),
      });
    });

    // Sort by lowest conflict risk, then highest compatibility score
    return recommendations
      .sort((a, b) => {
        if (a.conflictRisk !== b.conflictRisk) {
          const riskWeight: Record<ConflictRiskLevel, number> = { LOW: 1, MEDIUM: 2, HIGH: 3, VERY_HIGH: 4 };
          return riskWeight[a.conflictRisk] - riskWeight[b.conflictRisk];
        }
        return b.compatibilityScore - a.compatibilityScore;
      })
      .slice(0, 3);
  }

  /**
   * Booking-Time AI Assistant facade
   */
  public getBookingAIAssistance(
    environmentId: string,
    startDateStr: string,
    endDateStr: string,
    reservationMode: ReservationMode = 'SHARED',
    profiles: EnvironmentProfile[],
    bookings: Booking[],
    incidents: Incident[] = [],
    releases: Release[] = [],
    excludeBookingId?: string
  ): BookingAIAssistResult {
    const prediction = this.predictConflictRisk(
      environmentId,
      startDateStr,
      endDateStr,
      reservationMode,
      profiles,
      bookings,
      incidents,
      releases,
      excludeBookingId
    );

    let recommendations: AlternativeEnvironmentRecommendation[] = [];
    if (prediction.conflictProbability >= 25 || prediction.riskLevel !== 'LOW') {
      recommendations = this.recommendAlternativeEnvironments(
        environmentId,
        startDateStr,
        endDateStr,
        profiles,
        bookings,
        incidents,
        excludeBookingId
      );
    }

    let summaryMessage = `AI Risk Rating: ${prediction.riskLevel} (${prediction.conflictProbability}% Probability).`;
    if (recommendations.length > 0) {
      summaryMessage += ` ${recommendations.length} lower-risk alternative environment(s) recommended.`;
    }

    return {
      prediction,
      recommendations,
      summaryMessage,
    };
  }

  /**
   * Predictive Demand Forecasting Engine (7d, 14d, 30d, 90d)
   */
  public generateDemandForecast(
    horizon: ForecastHorizon = '30d',
    profiles: EnvironmentProfile[],
    bookings: Booking[],
    businessUnits: { name: string; code: string }[] = [],
    releases: Release[] = []
  ): DemandForecastResult {
    const days = horizon === '7d' ? 7 : horizon === '14d' ? 14 : horizon === '90d' ? 90 : 30;
    const timeSeries: TimeSeriesForecastPoint[] = [];

    const activeEnvsCount = Math.max(1, profiles.length);
    const dailyCapacity = activeEnvsCount * 2; // Each env can handle ~2 typical non-overlapping slots/day

    let totalPredictedDemand = 0;
    let totalAvailableCapacity = 0;
    let totalShortage = 0;
    let peakDayLabel = 'N/A';
    let maxDemandOnSingleDay = 0;

    const now = new Date();

    for (let i = 0; i < days; i++) {
      const d = new Date(now.getTime() + i * 86400000);
      const dateStr = d.toISOString().split('T')[0];
      const dayLabel = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', weekday: 'short' });

      // Base demand calculation + release factor + day of week multiplier
      const dayOfWeek = d.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const dayOfWeekMultiplier = isWeekend ? 0.3 : dayOfWeek === 3 || dayOfWeek === 4 ? 1.35 : 1.0;

      // Count scheduled bookings on this day
      const existingBookingsOnDay = bookings.filter((b) => {
        if (b.status === 'CANCELLED' || !b.startDate) return false;
        const bDate = b.startDate.split('T')[0];
        return bDate === dateStr;
      }).length;

      // Count scheduled releases on this day
      const releasesOnDay = releases.filter((r) => {
        if (!r.scheduledDate) return false;
        return r.scheduledDate.split('T')[0] === dateStr;
      }).length;

      const predictedDemand = Math.round(
        (existingBookingsOnDay * 1.4 + releasesOnDay * 3 + Math.sin(i / 3) * 1.5 + 4) * dayOfWeekMultiplier
      );

      const reservedCapacity = Math.min(dailyCapacity, Math.round(predictedDemand * 0.75));
      const availableCapacity = Math.max(0, dailyCapacity - reservedCapacity);
      const shortage = Math.max(0, predictedDemand - dailyCapacity);

      if (predictedDemand > maxDemandOnSingleDay) {
        maxDemandOnSingleDay = predictedDemand;
        peakDayLabel = dayLabel;
      }

      totalPredictedDemand += predictedDemand;
      totalAvailableCapacity += dailyCapacity;
      totalShortage += shortage;

      timeSeries.push({
        date: dateStr,
        dayLabel,
        predictedDemand,
        availableCapacity: dailyCapacity,
        reservedCapacity,
        shortage,
        isCapacityRisk: shortage > 0,
      });
    }

    // Dimension Breakdown by Business Unit
    const buList = businessUnits.length > 0 ? businessUnits.map((b) => b.name) : ['Retail Banking', 'Global Payments', 'Wealth Management', 'Digital Lending'];
    const byBusinessUnit: ForecastDimensionBreakdown[] = buList.map((buName) => {
      const buBookings = bookings.filter((b) => b.businessUnit?.toLowerCase() === buName.toLowerCase());
      const curDemand = buBookings.length;
      const predDemand = Math.round(curDemand * 1.25 + 6);
      const util = Math.min(98, Math.round(predDemand * 8.5));
      let risk: ConflictRiskLevel = util > 85 ? 'HIGH' : util > 65 ? 'MEDIUM' : 'LOW';
      if (util > 92) risk = 'VERY_HIGH';

      return {
        dimensionName: buName,
        currentDemand: curDemand,
        predictedDemand: predDemand,
        growthPercentage: 25,
        predictedUtilization: util,
        capacityRiskLevel: risk,
      };
    });

    // Dimension Breakdown by Account
    const accounts = ['Account Alpha (Retail)', 'Account Beta (Payments)', 'Account Gamma (Wealth)', 'Account Delta (Mortgage)'];
    const byAccount: ForecastDimensionBreakdown[] = accounts.map((accName, idx) => {
      const curDemand = Math.round(bookings.length * (0.35 - idx * 0.05));
      const predDemand = Math.round(curDemand * 1.2 + 4);
      const util = Math.min(95, Math.round(predDemand * 9));
      let risk: ConflictRiskLevel = util > 80 ? 'HIGH' : util > 60 ? 'MEDIUM' : 'LOW';

      return {
        dimensionName: accName,
        currentDemand: curDemand,
        predictedDemand: predDemand,
        growthPercentage: 20,
        predictedUtilization: util,
        capacityRiskLevel: risk,
      };
    });

    // Dimension Breakdown by Tier
    const tiers: EnvironmentTier[] = ['UAT', 'SIT', 'PERF', 'DEV', 'PRE-PROD', 'QA'];
    const byTier: ForecastDimensionBreakdown[] = tiers.map((tierName) => {
      const tierEnvs = profiles.filter((p) => String(p.type).toUpperCase().includes(tierName) || (p.type as string) === tierName);
      const tierBookings = bookings.filter((b) => {
        const env = profiles.find((p) => p.id === b.environmentId);
        return env ? String(env.type).toUpperCase().includes(tierName) || (env.type as string) === tierName : false;
      });
      const curDemand = tierBookings.length;
      const predDemand = Math.round(curDemand * 1.3 + tierEnvs.length * 2);
      const util = Math.min(98, Math.round((predDemand / Math.max(1, tierEnvs.length * 3)) * 100));
      let risk: ConflictRiskLevel = util > 85 ? 'HIGH' : util > 65 ? 'MEDIUM' : 'LOW';
      if (util > 93) risk = 'VERY_HIGH';

      return {
        dimensionName: `${tierName} Tier`,
        currentDemand: curDemand,
        predictedDemand: predDemand,
        growthPercentage: 30,
        predictedUtilization: util,
        capacityRiskLevel: risk,
      };
    });

    // Dimension Breakdown by Env Type
    const envTypes = ['Shared Core Stacks', 'Dedicated Performance Rigs', 'Integration Sandboxes'];
    const byEnvType: ForecastDimensionBreakdown[] = envTypes.map((typeName, idx) => {
      const curDemand = Math.round(bookings.length * 0.4);
      const predDemand = Math.round(curDemand * 1.18 + idx * 3);
      const util = Math.min(94, Math.round(predDemand * 8));
      return {
        dimensionName: typeName,
        currentDemand: curDemand,
        predictedDemand: predDemand,
        growthPercentage: 18,
        predictedUtilization: util,
        capacityRiskLevel: util > 80 ? 'HIGH' : 'MEDIUM',
      };
    });

    return {
      horizon,
      totalPredictedDemand,
      totalAvailableCapacity,
      totalCapacityShortage: totalShortage,
      peakPeriodLabel: peakDayLabel,
      timeSeries,
      byBusinessUnit,
      byAccount,
      byTier,
      byEnvType,
    };
  }

  /**
   * Predictive Conflict Heatmap Generator (Environments x Days of Week)
   */
  public generatePredictiveHeatmap(
    profiles: EnvironmentProfile[],
    bookings: Booking[],
    releases: Release[] = [],
    incidents: Incident[] = []
  ): PredictiveHeatmapCell[] {
    const cells: PredictiveHeatmapCell[] = [];
    const now = new Date();
    const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

    profiles.forEach((profile) => {
      daysOfWeek.forEach((dayLabel, idx) => {
        // Compute date offset for current week
        const d = new Date(now.getTime() + (idx + 1) * 86400000);
        const dateStr = d.toISOString().split('T')[0];

        const envBookings = bookings.filter(
          (b) => b.environmentId === profile.id && b.status !== 'CANCELLED'
        );
        const activeReleases = releases.filter(
          (r) => r.environmentId === profile.id || r.environmentName?.toLowerCase() === profile.name.toLowerCase()
        );
        const activeIncidents = incidents.filter(
          (i) => (i.environmentId === profile.id || i.environmentName?.toLowerCase() === profile.name.toLowerCase()) && i.status !== 'RESOLVED'
        );

        // Calculate cell probability
        let prob = envBookings.length * 15 + (idx === 2 || idx === 3 ? 25 : 10);
        if (activeReleases.length > 0) prob += 30;
        if (activeIncidents.length > 0) prob += 20;
        if (profile.status === 'DOWN') prob += 40;

        prob = Math.max(8, Math.min(96, prob));

        let risk: ConflictRiskLevel = 'LOW';
        if (prob >= 80) risk = 'VERY_HIGH';
        else if (prob >= 60) risk = 'HIGH';
        else if (prob >= 30) risk = 'MEDIUM';

        cells.push({
          environmentId: profile.id,
          environmentName: profile.name,
          tier: (profile.type || 'UAT') as EnvironmentTier,
          dateStr,
          dayOfWeek: dayLabel,
          conflictProbability: Math.round(prob),
          riskLevel: risk,
          hasActiveRelease: activeReleases.length > 0,
          hasIncident: activeIncidents.length > 0,
          bookingCount: envBookings.length,
        });
      });
    });

    return cells;
  }

  /**
   * What-If Scenario Analysis Simulator
   */
  public runWhatIfScenario(
    input: WhatIfScenarioInput,
    profiles: EnvironmentProfile[],
    bookings: Booking[],
    releases: Release[] = [],
    businessUnits: { name: string }[] = []
  ): WhatIfScenarioResult {
    const activeCount = Math.max(1, profiles.length - input.offlineEnvironmentIds.length);
    const baselineDemand = bookings.length;

    // Simulate demand growth & parameters
    const surgeFactor = 1 + input.demandGrowthPercentage / 100;
    const releasePenalty = input.additionalReleaseCount * 4;
    const simulatedDemand = Math.round(baselineDemand * surgeFactor + releasePenalty);

    const baselineCapacity = profiles.length * 4;
    const simulatedCapacity = activeCount * 4;

    const baselineShortage = Math.max(0, baselineDemand - baselineCapacity);
    const simulatedShortage = Math.max(0, simulatedDemand - simulatedCapacity);

    const additionalConflicts = Math.round(
      (simulatedDemand - baselineDemand) * 0.8 + (input.convertAllToDisruptive ? 8 : 0) + input.offlineEnvironmentIds.length * 3
    );

    const utilPct = Math.min(99, Math.round((simulatedDemand / simulatedCapacity) * 100));

    const recommendations: string[] = [];
    if (simulatedShortage > 0) {
      recommendations.push(`Provision ${Math.ceil(simulatedShortage / 2)} temporary UAT/PERF environment instance(s).`);
    }
    if (input.convertAllToDisruptive) {
      recommendations.push('Convert non-critical disruptive bookings to Shared mode to alleviate 40% of collisions.');
    }
    if (input.offlineEnvironmentIds.length > 0) {
      recommendations.push(`Accelerate maintenance recovery on offline nodes (${input.offlineEnvironmentIds.length} node(s)).`);
    }
    if (recommendations.length === 0) {
      recommendations.push('Current environment capacity is sufficient to absorb the simulated demand growth.');
    }

    return {
      baselineDemand,
      simulatedDemand,
      baselineShortage,
      simulatedShortage,
      additionalConflictsCount: Math.max(0, additionalConflicts),
      averageUtilizationPercentage: utilPct,
      affectedBusinessUnits: businessUnits.map((b) => b.name).slice(0, 3),
      affectedAccounts: ['Retail Banking Account', 'Payments Core Account'],
      recommendedAdditionalCapacityCount: Math.ceil(simulatedShortage / 2),
      recommendations,
    };
  }

  /**
   * Proactive Risk Alerts Generator
   */
  public getProactiveAlerts(
    profiles: EnvironmentProfile[],
    bookings: Booking[],
    incidents: Incident[] = [],
    releases: Release[] = []
  ): ProactiveAlert[] {
    const alerts: ProactiveAlert[] = [];

    profiles.forEach((p) => {
      const pBookings = bookings.filter((b) => b.environmentId === p.id && b.status !== 'CANCELLED');
      const pIncidents = incidents.filter((i) => i.environmentId === p.id && i.status !== 'RESOLVED');
      const pReleases = releases.filter((r) => r.environmentId === p.id);

      if (pBookings.length >= 3 || pReleases.length > 0) {
        alerts.push({
          id: `alert-${p.id}-util`,
          title: `Upcoming Capacity Risk: ${p.name}`,
          environmentId: p.id,
          environmentName: p.name,
          severity: pBookings.length >= 4 ? 'CRITICAL' : 'WARNING',
          predictedUtilization: Math.min(96, 65 + pBookings.length * 10),
          timeframe: 'Next 7 Days',
          message: `${p.name} (${p.type}) is predicted to reach high utilization during upcoming release testing.`,
          actionableRecommendation: `Consider shifting non-disruptive bookings or allocating alternative ${p.type} tier capacity.`,
          createdTimestamp: new Date().toISOString(),
        });
      }

      if (p.status === 'DEGRADED' || pIncidents.length > 0) {
        alerts.push({
          id: `alert-${p.id}-degraded`,
          title: `Stability & Health Risk: ${p.name}`,
          environmentId: p.id,
          environmentName: p.name,
          severity: 'CRITICAL',
          predictedUtilization: 88,
          timeframe: 'Immediate',
          message: `${p.name} has ${pIncidents.length} active incident(s) and degraded status, risking upcoming reservation failures.`,
          actionableRecommendation: 'Triage active incidents or failover workloads to secondary standby node.',
          createdTimestamp: new Date().toISOString(),
        });
      }
    });

    return alerts.slice(0, 5);
  }

  /**
   * Capacity Recommendations Generator
   */
  public getCapacityRecommendations(forecast: DemandForecastResult): CapacityRecommendation[] {
    const list: CapacityRecommendation[] = [];

    if (forecast.totalCapacityShortage > 0) {
      list.push({
        id: 'rec-add-uat',
        title: 'Provision 2 Temporary Tier-1 UAT Environments',
        type: 'ADD_CAPACITY',
        timeframe: `Peak Window (${forecast.peakPeriodLabel})`,
        impactScore: 'High Risk Reduction (-45% Conflicts)',
        reasoning: `Predicted demand (${forecast.totalPredictedDemand}) exceeds available capacity during ${forecast.peakPeriodLabel}.`,
      });
    }

    list.push({
      id: 'rec-convert-mode',
      title: 'Optimize Reservation Modes to Shared',
      type: 'CONVERT_MODE',
      timeframe: 'Ongoing',
      impactScore: 'Unlocks +25% Capacity',
      reasoning: 'Converting non-interfering disruptive reservations to Shared mode resolves 35% of schedule contention.',
    });

    list.push({
      id: 'rec-shift-window',
      title: 'Shift Non-Critical Regression to Off-Peak Windows',
      type: 'SHIFT_TIMING',
      timeframe: 'Mid-Week Peak',
      impactScore: 'Smooths Demand Curve',
      reasoning: 'Re-balancing Wednesday/Thursday peak bookings to Friday off-peak hours avoids capacity bottlenecks.',
    });

    return list;
  }

  /**
   * Closed-Loop Feedback Logger
   */
  public logAIFeedback(feedback: AIFeedbackRecord): void {
    try {
      const existingStr = localStorage.getItem(AI_FEEDBACK_KEY);
      const logs: AIFeedbackRecord[] = existingStr ? JSON.parse(existingStr) : [];
      logs.push(feedback);
      localStorage.setItem(AI_FEEDBACK_KEY, JSON.stringify(logs));
    } catch (e) {
      console.error('Failed to log AI feedback:', e);
    }
  }

  public getAIFeedbackLogs(): AIFeedbackRecord[] {
    try {
      const existingStr = localStorage.getItem(AI_FEEDBACK_KEY);
      return existingStr ? JSON.parse(existingStr) : [];
    } catch (e) {
      return [];
    }
  }
}

export const aiIntelligenceService = new AIIntelligenceService();
