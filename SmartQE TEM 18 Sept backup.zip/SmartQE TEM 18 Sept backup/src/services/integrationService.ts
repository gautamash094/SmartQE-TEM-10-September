import {
  CICDPipelineEventPayload,
  IntegrationConfig,
  IntegrationHealthSummary,
  IntegrationLogEntry,
  IntegrationProvider,
  ITSMTicketSyncPayload
} from '../types/integrations';
import { ConnectorFactory } from './integrationConnectors';
import { fetchApi } from './apiClient';

const CONFIGS_STORAGE_KEY = 'smartqe_tem_integration_configs_v2';
const LOGS_STORAGE_KEY = 'smartqe_tem_integration_logs_v2';
const RETRY_STORAGE_KEY = 'smartqe_tem_integration_retry_v2';

export const INITIAL_INTEGRATION_CONFIGS: IntegrationConfig[] = [
  {
    id: 'cfg-snow',
    name: 'ServiceNow ITSM & Change Control',
    provider: 'SERVICENOW',
    type: 'ITSM',
    enabled: false,
    connectionStatus: 'UNCONFIGURED',
    syncDirection: 'BI_DIRECTIONAL',
    baseUrl: '',
    authType: 'OAUTH2',
    usernameOrClient: '',
    apiTokenOrSecret: '',
    webhookUrl: '',
    syncIntervalMinutes: 15,
    conflictPolicy: 'TEM_AUTHORITATIVE',
    eventsEnabled: {
      incidents: true,
      changes: true,
    },
    fieldMappings: [],
    statusMappings: [],
    environmentMappings: [],
    retryAttemptsMax: 5,
  },
  {
    id: 'cfg-ado',
    name: 'Azure DevOps Pipelines & Environments',
    provider: 'AZURE_DEVOPS',
    type: 'CICD',
    enabled: false,
    connectionStatus: 'UNCONFIGURED',
    syncDirection: 'INBOUND_ONLY',
    baseUrl: '',
    authType: 'WEBHOOK_SECRET',
    apiTokenOrSecret: '',
    webhookUrl: '',
    syncIntervalMinutes: 5,
    conflictPolicy: 'EXTERNAL_AUTHORITATIVE',
    eventsEnabled: {
      pipelines: true,
      deployments: true,
      testExecutions: true,
    },
    fieldMappings: [],
    statusMappings: [],
    environmentMappings: [],
    retryAttemptsMax: 3,
  },
  {
    id: 'cfg-jenkins',
    name: 'Jenkins Automation Server',
    provider: 'JENKINS',
    type: 'CICD',
    enabled: false,
    connectionStatus: 'UNCONFIGURED',
    syncDirection: 'INBOUND_ONLY',
    baseUrl: '',
    authType: 'API_TOKEN',
    usernameOrClient: '',
    apiTokenOrSecret: '',
    webhookUrl: '',
    syncIntervalMinutes: 10,
    conflictPolicy: 'EXTERNAL_AUTHORITATIVE',
    eventsEnabled: {
      pipelines: true,
      deployments: true,
      testExecutions: true,
    },
    fieldMappings: [],
    statusMappings: [],
    environmentMappings: [],
    retryAttemptsMax: 3,
  },
];

export const INITIAL_INTEGRATION_LOGS: IntegrationLogEntry[] = [];

export const integrationService = {
  getConfigs(): IntegrationConfig[] {
    try {
      // Clear old v1 cache if present
      localStorage.removeItem('smartqe_tem_integration_configs_v1');
      const raw = localStorage.getItem(CONFIGS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Purge legacy Jira configs or dummy URLs
          const sanitized = parsed.filter(
            (c: any) => c.id !== 'cfg-jira' && c.provider !== 'JIRA' && !c.name?.toLowerCase().includes('jira')
          );
          if (sanitized.length > 0 && sanitized.length === parsed.length) {
            return sanitized;
          }
        }
      }
    } catch {}
    localStorage.setItem(CONFIGS_STORAGE_KEY, JSON.stringify(INITIAL_INTEGRATION_CONFIGS));
    return INITIAL_INTEGRATION_CONFIGS;
  },

  saveConfigs(configs: IntegrationConfig[]): void {
    localStorage.setItem(CONFIGS_STORAGE_KEY, JSON.stringify(configs));
  },

  updateConfig(id: string, update: Partial<IntegrationConfig>): IntegrationConfig[] {
    const current = this.getConfigs();
    const updated = current.map((c) => (c.id === id ? { ...c, ...update } : c));
    this.saveConfigs(updated);
    return updated;
  },

  getLogs(): IntegrationLogEntry[] {
    try {
      localStorage.removeItem('smartqe_tem_integration_logs_v1');
      const raw = localStorage.getItem(LOGS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          const sanitized = parsed.filter(
            (l: any) => l.provider !== 'JIRA' && !l.message?.toLowerCase().includes('jira')
          );
          return sanitized;
        }
      }
    } catch {}
    localStorage.setItem(LOGS_STORAGE_KEY, JSON.stringify(INITIAL_INTEGRATION_LOGS));
    return INITIAL_INTEGRATION_LOGS;
  },

  saveLogs(logs: IntegrationLogEntry[]): void {
    localStorage.setItem(LOGS_STORAGE_KEY, JSON.stringify(logs.slice(0, 100))); // Keep last 100 logs
  },

  addLogEntry(entry: Omit<IntegrationLogEntry, 'id' | 'timestamp'>): IntegrationLogEntry {
    const newLog: IntegrationLogEntry = {
      ...entry,
      id: `log-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };
    const logs = [newLog, ...this.getLogs()];
    this.saveLogs(logs);
    return newLog;
  },

  clearLogs(): void {
    this.saveLogs([]);
  },

  async testConnection(provider: IntegrationProvider): Promise<{ success: boolean; message: string; latencyMs: number }> {
    const config = this.getConfigs().find((c) => c.provider === provider);
    if (!config) {
      return { success: false, message: `No configuration found for ${provider}.`, latencyMs: 0 };
    }

    try {
      const connector = ConnectorFactory.getConnector(provider);
      const res = await connector.testConnection(config);

      const status = res.success ? 'CONNECTED' : 'DISCONNECTED';
      this.updateConfig(config.id, {
        connectionStatus: status,
        lastSuccessfulSync: res.success ? new Date().toISOString() : config.lastSuccessfulSync,
        lastFailedSync: !res.success ? new Date().toISOString() : config.lastFailedSync,
      });

      this.addLogEntry({
        provider,
        eventType: 'CONNECTION_TEST',
        direction: 'TEM_TO_EXTERNAL',
        status: res.success ? 'SUCCESS' : 'FAILED',
        message: res.message,
        retryCount: 0,
        maxRetries: config.retryAttemptsMax,
      });

      return res;
    } catch (err: any) {
      this.updateConfig(config.id, { connectionStatus: 'DISCONNECTED', lastFailedSync: new Date().toISOString() });
      return { success: false, message: err.message || 'Connection test failed.', latencyMs: 0 };
    }
  },

  async simulateCICDPipelineEvent(payload: CICDPipelineEventPayload): Promise<{ success: boolean; message: string; targetEnvironmentId?: string; mappedStatus: string }> {
    const config = this.getConfigs().find((c) => c.provider === payload.provider);
    if (!config || !config.enabled) {
      return { success: false, message: `Integration ${payload.provider} is disabled.`, mappedStatus: 'N/A' };
    }

    const connector = ConnectorFactory.getConnector(payload.provider);
    const res = await connector.processCICDPipelineEvent(config, payload);

    this.addLogEntry({
      provider: payload.provider,
      eventType: payload.eventType,
      direction: 'EXTERNAL_TO_TEM',
      externalEntityId: `${payload.pipelineName} #${payload.buildNumber}`,
      temEntityId: res.targetEnvironmentId || payload.targetEnvironmentIdentifier,
      status: res.success ? 'SUCCESS' : 'FAILED',
      message: res.message,
      payloadSnippet: JSON.stringify(payload),
      retryCount: 0,
      maxRetries: config.retryAttemptsMax,
    });

    if (res.success) {
      this.updateConfig(config.id, { lastSuccessfulSync: new Date().toISOString() });
    }

    return res;
  },

  async syncITSMTicket(payload: ITSMTicketSyncPayload): Promise<{ success: boolean; syncedPayload?: ITSMTicketSyncPayload; message: string }> {
    const config = this.getConfigs().find((c) => c.provider === payload.provider);
    if (!config || !config.enabled) {
      return { success: false, message: `ITS Integration ${payload.provider} is disabled.` };
    }

    const connector = ConnectorFactory.getConnector(payload.provider);
    const res = await connector.syncITSMTicket(config, payload);

    this.addLogEntry({
      provider: payload.provider,
      eventType: 'ITSM_TICKET_SYNC',
      direction: 'BI_DIRECTIONAL',
      externalEntityId: payload.externalKeyOrNumber,
      temEntityId: payload.temIncidentId || payload.title,
      status: res.success ? 'SUCCESS' : 'FAILED',
      message: res.message,
      payloadSnippet: JSON.stringify(payload),
      retryCount: 0,
      maxRetries: config.retryAttemptsMax,
    });

    if (res.success) {
      this.updateConfig(config.id, { lastSuccessfulSync: new Date().toISOString() });
    }

    return res;
  },

  async reconcileAll(): Promise<{ success: boolean; syncedCount: number; message: string }> {
    const configs = this.getConfigs().filter((c) => c.enabled);
    let count = 0;

    for (const cfg of configs) {
      try {
        await this.testConnection(cfg.provider);
        count++;
      } catch {}
    }

    return {
      success: true,
      syncedCount: count,
      message: `Reconciliation scan completed. Synchronized ${count} active toolchain provider(s).`,
    };
  },

  getHealthSummary(): IntegrationHealthSummary {
    const configs = this.getConfigs();
    const logs = this.getLogs();

    const activeIntegrations = configs.filter((c) => c.enabled).length;
    const connectedCount = configs.filter((c) => c.enabled && c.connectionStatus === 'CONNECTED').length;
    const failedCount = configs.filter((c) => c.enabled && c.connectionStatus === 'DISCONNECTED').length;

    const last24h = Date.now() - 86400000;
    const logs24h = logs.filter((l) => new Date(l.timestamp).getTime() >= last24h);
    const successLogs24h = logs24h.filter((l) => l.status === 'SUCCESS');
    const successRate24h = logs24h.length > 0 ? Math.round((successLogs24h.length / logs24h.length) * 100) : 100;

    return {
      totalIntegrations: configs.length,
      activeIntegrations,
      connectedCount,
      failedCount,
      events24hCount: logs24h.length,
      successRate24h,
      lastGlobalSync: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };
  },
};
