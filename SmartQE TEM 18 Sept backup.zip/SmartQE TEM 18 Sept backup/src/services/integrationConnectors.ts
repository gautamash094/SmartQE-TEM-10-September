import {
  IntegrationConfig,
  IntegrationProvider,
  ITSMTicketSyncPayload,
  CICDPipelineEventPayload
} from '../types/integrations';

export interface ConnectorTestResult {
  success: boolean;
  latencyMs: number;
  message: string;
}

export interface IExternalConnector {
  provider: IntegrationProvider;
  testConnection(config: IntegrationConfig): Promise<ConnectorTestResult>;
  syncITSMTicket(
    config: IntegrationConfig,
    payload: ITSMTicketSyncPayload
  ): Promise<{ success: boolean; syncedPayload: ITSMTicketSyncPayload; message: string }>;
  processCICDPipelineEvent(
    config: IntegrationConfig,
    event: CICDPipelineEventPayload
  ): Promise<{ success: boolean; targetEnvironmentId?: string; mappedStatus: string; message: string }>;
  generateExternalUrl(config: IntegrationConfig, externalId: string): string;
}

// ── 1. SERVICENOW CONNECTOR ──
export class ServiceNowConnector implements IExternalConnector {
  public provider: IntegrationProvider = 'SERVICENOW';

  public async testConnection(config: IntegrationConfig): Promise<ConnectorTestResult> {
    const start = Date.now();
    await new Promise((resolve) => setTimeout(resolve, 420));
    const latencyMs = Date.now() - start;

    if (!config.baseUrl) {
      return {
        success: false,
        latencyMs,
        message: 'ServiceNow instance URL required (e.g. https://company.service-now.com).',
      };
    }

    return {
      success: true,
      latencyMs,
      message: `ServiceNow Table API connected (Latency: ${latencyMs}ms). Instance: ${config.baseUrl}`,
    };
  }

  public async syncITSMTicket(
    config: IntegrationConfig,
    payload: ITSMTicketSyncPayload
  ): Promise<{ success: boolean; syncedPayload: ITSMTicketSyncPayload; message: string }> {
    await new Promise((resolve) => setTimeout(resolve, 320));
    const externalUrl = this.generateExternalUrl(config, payload.externalKeyOrNumber || payload.externalId);

    const statusMapping = config.statusMappings.find((m) => m.externalStatus === payload.status);
    const temStatus = statusMapping ? statusMapping.temStatus : payload.status === 'Resolved' || payload.status === 'Closed' ? 'RESOLVED' : 'INVESTIGATING';

    return {
      success: true,
      syncedPayload: {
        ...payload,
        externalUrl,
        status: temStatus,
        updatedAt: new Date().toISOString(),
      },
      message: `ServiceNow ticket '${payload.externalKeyOrNumber}' synchronized. Status: ${temStatus}.`,
    };
  }

  public async processCICDPipelineEvent(
    _config: IntegrationConfig,
    _event: CICDPipelineEventPayload
  ): Promise<{ success: boolean; targetEnvironmentId?: string; mappedStatus: string; message: string }> {
    return {
      success: false,
      mappedStatus: 'N/A',
      message: 'ServiceNow connector does not process CI/CD build events directly.',
    };
  }

  public generateExternalUrl(config: IntegrationConfig, externalId: string): string {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/$/, '') : 'https://company.service-now.com';
    const isChange = externalId.toUpperCase().startsWith('CHG');
    const table = isChange ? 'change_request' : 'incident';
    return `${baseUrl}/nav_to.do?uri=${table}.do?sysparm_query=number=${externalId}`;
  }
}

// ── 3. AZURE DEVOPS CONNECTOR ──
export class AzureDevOpsConnector implements IExternalConnector {
  public provider: IntegrationProvider = 'AZURE_DEVOPS';

  public async testConnection(config: IntegrationConfig): Promise<ConnectorTestResult> {
    const start = Date.now();
    await new Promise((resolve) => setTimeout(resolve, 290));
    const latencyMs = Date.now() - start;

    return {
      success: true,
      latencyMs,
      message: `Azure DevOps Service Endpoint verified (Latency: ${latencyMs}ms). Webhook listener ready.`,
    };
  }

  public async syncITSMTicket(
    _config: IntegrationConfig,
    _payload: ITSMTicketSyncPayload
  ): Promise<{ success: boolean; syncedPayload: ITSMTicketSyncPayload; message: string }> {
    throw new Error('Azure DevOps Connector is dedicated to CI/CD pipeline events.');
  }

  public async processCICDPipelineEvent(
    config: IntegrationConfig,
    event: CICDPipelineEventPayload
  ): Promise<{ success: boolean; targetEnvironmentId?: string; mappedStatus: string; message: string }> {
    await new Promise((resolve) => setTimeout(resolve, 200));

    // Resolve target TEM Environment Details ID
    const envRule = config.environmentMappings.find(
      (m) =>
        m.externalEnvIdentifier.toLowerCase() === event.targetEnvironmentIdentifier.toLowerCase() ||
        m.temEnvironmentName.toLowerCase() === event.targetEnvironmentIdentifier.toLowerCase()
    );

    const targetEnvironmentId = envRule ? envRule.temEnvironmentId : event.targetEnvironmentId;

    // Map CI/CD Pipeline event to TEM Environment Status
    let mappedStatus = 'HEALTHY';
    switch (event.eventType) {
      case 'PIPELINE_STARTED':
      case 'DEPLOYMENT_STARTED':
        mappedStatus = 'MAINTENANCE';
        break;
      case 'TEST_STARTED':
        mappedStatus = 'DEGRADED';
        break;
      case 'DEPLOYMENT_SUCCESS':
      case 'TEST_COMPLETED':
      case 'PIPELINE_COMPLETED':
        mappedStatus = 'HEALTHY';
        break;
      case 'DEPLOYMENT_FAILED':
      case 'PIPELINE_CANCELED':
        mappedStatus = 'DOWN';
        break;
      default:
        mappedStatus = 'HEALTHY';
    }

    return {
      success: true,
      targetEnvironmentId,
      mappedStatus,
      message: `Azure DevOps pipeline run #${event.buildNumber} (${event.pipelineName}) mapped event '${event.eventType}' -> TEM Environment status '${mappedStatus}'.`,
    };
  }

  public generateExternalUrl(config: IntegrationConfig, externalId: string): string {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/$/, '') : 'https://dev.azure.com/company';
    return `${baseUrl}/_build/results?buildId=${externalId}`;
  }
}

// ── 4. JENKINS CONNECTOR ──
export class JenkinsConnector implements IExternalConnector {
  public provider: IntegrationProvider = 'JENKINS';

  public async testConnection(config: IntegrationConfig): Promise<ConnectorTestResult> {
    const start = Date.now();
    await new Promise((resolve) => setTimeout(resolve, 310));
    const latencyMs = Date.now() - start;

    return {
      success: true,
      latencyMs,
      message: `Jenkins Remote API & Webhook Notification Plugin validated (Latency: ${latencyMs}ms).`,
    };
  }

  public async syncITSMTicket(
    _config: IntegrationConfig,
    _payload: ITSMTicketSyncPayload
  ): Promise<{ success: boolean; syncedPayload: ITSMTicketSyncPayload; message: string }> {
    throw new Error('Jenkins Connector is dedicated to CI/CD pipeline events.');
  }

  public async processCICDPipelineEvent(
    config: IntegrationConfig,
    event: CICDPipelineEventPayload
  ): Promise<{ success: boolean; targetEnvironmentId?: string; mappedStatus: string; message: string }> {
    await new Promise((resolve) => setTimeout(resolve, 220));

    const envRule = config.environmentMappings.find(
      (m) =>
        m.externalEnvIdentifier.toLowerCase() === event.targetEnvironmentIdentifier.toLowerCase() ||
        m.temEnvironmentName.toLowerCase() === event.targetEnvironmentIdentifier.toLowerCase()
    );

    const targetEnvironmentId = envRule ? envRule.temEnvironmentId : event.targetEnvironmentId;

    let mappedStatus = 'HEALTHY';
    switch (event.eventType) {
      case 'PIPELINE_STARTED':
      case 'DEPLOYMENT_STARTED':
        mappedStatus = 'MAINTENANCE';
        break;
      case 'TEST_STARTED':
        mappedStatus = 'DEGRADED';
        break;
      case 'DEPLOYMENT_SUCCESS':
      case 'TEST_COMPLETED':
      case 'PIPELINE_COMPLETED':
        mappedStatus = 'HEALTHY';
        break;
      case 'DEPLOYMENT_FAILED':
      case 'PIPELINE_CANCELED':
        mappedStatus = 'DOWN';
        break;
      default:
        mappedStatus = 'HEALTHY';
    }

    return {
      success: true,
      targetEnvironmentId,
      mappedStatus,
      message: `Jenkins job '${event.pipelineName}' build #${event.buildNumber} event '${event.eventType}' -> TEM Environment status '${mappedStatus}'.`,
    };
  }

  public generateExternalUrl(config: IntegrationConfig, externalId: string): string {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/$/, '') : 'http://jenkins.company.internal:8080';
    return `${baseUrl}/job/${externalId}`;
  }
}

// Connector Factory & Registry
export class ConnectorFactory {
  private static registry: Map<IntegrationProvider, IExternalConnector> = new Map([
    ['SERVICENOW', new ServiceNowConnector()],
    ['AZURE_DEVOPS', new AzureDevOpsConnector()],
    ['JENKINS', new JenkinsConnector()],
  ]);

  public static getConnector(provider: IntegrationProvider): IExternalConnector {
    const connector = this.registry.get(provider);
    if (!connector) {
      throw new Error(`Unsupported integration provider '${provider}'.`);
    }
    return connector;
  }
}
