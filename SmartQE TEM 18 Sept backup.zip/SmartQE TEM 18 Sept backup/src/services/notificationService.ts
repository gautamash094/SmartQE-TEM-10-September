import { EmailNotification } from '../types';
import { fetchApi } from './apiClient';

export const notificationService = {
  /**
   * Fetches the full email notification audit trail for a specific reservation.
   * Corresponds to GET /api/v1/notifications/booking/:id
   */
  async getBookingNotifications(bookingId: string): Promise<EmailNotification[]> {
    try {
      const response = await fetchApi<{ success: boolean; data: EmailNotification[] }>(
        `/notifications/booking/${bookingId}`
      );
      if (response && response.success && Array.isArray(response.data)) {
        return response.data;
      }
      return [];
    } catch (err) {
      console.error(`Failed to fetch notifications for booking ${bookingId}:`, err);
      return [];
    }
  },

  /**
   * Retries delivery of a pending or failed notification.
   * Corresponds to POST /api/v1/notifications/:id/retry
   */
  async retryNotification(notificationId: string): Promise<{ success: boolean; message: string; notification?: EmailNotification }> {
    try {
      const response = await fetchApi<{ success: boolean; message: string; data: EmailNotification }>(
        `/notifications/${notificationId}/retry`,
        {
          method: 'POST',
        }
      );
      if (response && response.success) {
        return {
          success: true,
          message: response.message || 'Notification resent successfully.',
          notification: response.data,
        };
      }
      return {
        success: false,
        message: response?.message || 'Failed to retry notification delivery.',
      };
    } catch (err: any) {
      return {
        success: false,
        message: err?.message || 'Error occurred while attempting retry.',
      };
    }
  },

  /**
   * Manually triggers upcoming 1-hour booking reminder processing.
   */
  async triggerUpcomingReminders(): Promise<{ dispatched: number }> {
    try {
      const response = await fetchApi<{ success: boolean; data: { reminders_dispatched: number } }>(
        `/notifications/trigger-reminders`,
        {
          method: 'POST',
        }
      );
      return { dispatched: response?.data?.reminders_dispatched || 0 };
    } catch (err) {
      console.error('Failed to trigger reminders:', err);
      return { dispatched: 0 };
    }
  }
};
