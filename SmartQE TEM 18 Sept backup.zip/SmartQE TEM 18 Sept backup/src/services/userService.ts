import { Role, roleService } from './roleService';
import { BusinessUnit, portfolioService } from './portfolioService';
import { fetchApi } from './apiClient';
import { authService } from './authService';

export interface UserRoleItem {
  id: string;
  name: string;
  description?: string;
  roleOrder?: number;
  isSystem?: boolean;
  isActive?: boolean;
}

export interface UserBUItem {
  id: string;
  name: string;
  code: string;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  fullName: string;
  username: string;
  email: string;
  password?: string;
  businessUnitId?: string;
  businessUnit?: UserBUItem;
  roles: UserRoleItem[];
  isActive: boolean;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  createdBy: string;
  updatedAt: string;
  updatedBy: string;
}

export interface UserCreatePayload {
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  password?: string;
  roleIds: string[];
  businessUnitId?: string;
  isActive?: boolean;
}

export interface UserUpdatePayload {
  firstName?: string;
  lastName?: string;
  email?: string;
  password?: string;
  roleIds?: string[];
  businessUnitId?: string;
  isActive?: boolean;
  status?: 'ACTIVE' | 'INACTIVE';
}

const USERS_STORAGE_KEY = 'smartqe_tem_users_v2';

const INITIAL_USERS: User[] = [
  {
    id: 'user-admin',
    firstName: 'System',
    lastName: 'Admin',
    fullName: 'System Admin',
    username: 'admin',
    email: 'admin@testops.io',
    password: 'Admin@123',
    roles: [
      {
        id: 'role-super-admin',
        name: 'Super Admin',
        description: 'Default initial system role with top-level administrative authority across the TEM application.',
        roleOrder: 1,
        isSystem: true,
        isActive: true,
      },
    ],
    isActive: true,
    status: 'ACTIVE',
    createdAt: '2026-08-01 09:00:00',
    createdBy: 'System',
    updatedAt: '2026-08-01 09:00:00',
    updatedBy: 'System',
  },
];

function loadFromStorage<T>(key: string, defaults: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed) return parsed;
    }
  } catch {}
  return defaults;
}

function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {}
}

function mapApiUser(apiUser: any): User {
  const firstName = apiUser.first_name || apiUser.firstName || '';
  const lastName = apiUser.last_name || apiUser.lastName || '';
  const computedName = `${firstName} ${lastName}`.trim();
  const rawFullName = apiUser.full_name || apiUser.fullName;
  const username = apiUser.username || '';

  let fullName = rawFullName || computedName;
  if (!fullName || fullName.toLowerCase() === 'admin') {
    fullName = username.toLowerCase() === 'admin' ? 'System Admin' : username;
  }

  return {
    id: apiUser.id,
    firstName: firstName || (username.toLowerCase() === 'admin' ? 'System' : ''),
    lastName: lastName || (username.toLowerCase() === 'admin' ? 'Admin' : ''),
    fullName,
    username: apiUser.username,
    email: apiUser.email,
    businessUnitId: apiUser.business_unit_id || apiUser.businessUnitId,
    businessUnit: apiUser.business_unit || apiUser.businessUnit,
    roles: (apiUser.roles || []).map((r: any) => ({
      id: r.id,
      name: r.name,
      description: r.description,
      roleOrder: r.role_order ?? r.roleOrder ?? 1,
      isSystem: r.is_system ?? r.isSystem ?? false,
      isActive: r.is_active ?? r.isActive ?? true,
    })),
    isActive: apiUser.is_active ?? apiUser.isActive ?? true,
    status: apiUser.status || ((apiUser.is_active ?? apiUser.isActive) ? 'ACTIVE' : 'INACTIVE'),
    createdAt: typeof apiUser.created_at === 'string'
      ? apiUser.created_at.replace('T', ' ').substring(0, 19)
      : (apiUser.createdAt || '2026-09-01 10:00:00'),
    createdBy: apiUser.created_by || apiUser.createdBy || 'Super Admin',
    updatedAt: typeof apiUser.updated_at === 'string'
      ? apiUser.updated_at.replace('T', ' ').substring(0, 19)
      : (apiUser.updatedAt || '2026-09-01 10:00:00'),
    updatedBy: apiUser.updated_by || apiUser.updatedBy || 'Super Admin',
  };
}

function filterUsersForSessionUser(users: User[]): User[] {
  return users;
}

export const userService = {
  async getUsers(params?: { search?: string; roleId?: string; buId?: string; isActive?: boolean }): Promise<User[]> {
    try {
      const queryParts: string[] = [];
      if (params?.search) queryParts.push(`search=${encodeURIComponent(params.search)}`);
      if (params?.roleId) queryParts.push(`roleId=${encodeURIComponent(params.roleId)}`);
      if (params?.buId) queryParts.push(`buId=${encodeURIComponent(params.buId)}`);
      if (params?.isActive !== undefined) queryParts.push(`isActive=${params.isActive}`);

      const qs = queryParts.length > 0 ? `?${queryParts.join('&')}` : '';
      const apiData = await fetchApi<any[]>(`/users${qs}`);
      if (apiData && Array.isArray(apiData)) {
        const users = apiData.map(mapApiUser);
        saveToStorage(USERS_STORAGE_KEY, users);
        return filterUsersForSessionUser(users);
      }
    } catch (err) {
      console.warn('Backend API unreachable, using localStorage user service state', err);
    }

    let users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
    if (params?.search) {
      const q = params.search.toLowerCase();
      users = users.filter(
        (u) =>
          u.username.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q) ||
          u.firstName.toLowerCase().includes(q) ||
          u.lastName.toLowerCase().includes(q) ||
          u.fullName.toLowerCase().includes(q)
      );
    }
    if (params?.roleId) {
      users = users.filter((u) => u.roles.some((r) => r.id === params.roleId));
    }
    if (params?.buId) {
      users = users.filter((u) => u.businessUnitId === params.buId);
    }
    if (params?.isActive !== undefined) {
      users = users.filter((u) => u.isActive === params.isActive);
    }
    return filterUsersForSessionUser(users);
  },

  getUsersLocal(params?: { search?: string; roleId?: string; buId?: string; isActive?: boolean }): User[] {
    let users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
    if (params?.search) {
      const q = params.search.toLowerCase();
      users = users.filter(
        (u) =>
          u.username.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q) ||
          u.firstName.toLowerCase().includes(q) ||
          u.lastName.toLowerCase().includes(q) ||
          u.fullName.toLowerCase().includes(q)
      );
    }
    if (params?.roleId) {
      users = users.filter((u) => u.roles.some((r) => r.id === params.roleId));
    }
    if (params?.buId) {
      users = users.filter((u) => u.businessUnitId === params.buId);
    }
    if (params?.isActive !== undefined) {
      users = users.filter((u) => u.isActive === params.isActive);
    }
    return users;
  },

  async getUserById(userId: string): Promise<User | null> {
    try {
      const apiData = await fetchApi<any>(`/users/${userId}`);
      if (apiData) return mapApiUser(apiData);
    } catch {}

    const users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
    return users.find((u) => u.id === userId) || null;
  },

  async createUser(payload: UserCreatePayload): Promise<User> {
    const trimmedFirst = payload.firstName.trim();
    const trimmedLast = payload.lastName.trim();
    const trimmedUsername = payload.username.trim();
    const trimmedEmail = payload.email.trim().toLowerCase();

    if (!trimmedFirst || !trimmedLast) {
      throw new Error('First Name and Last Name are required.');
    }
    if (!trimmedUsername) {
      throw new Error('Username is required.');
    }
    if (!trimmedEmail) {
      throw new Error('Email is required.');
    }
    if (!payload.roleIds || payload.roleIds.length === 0) {
      throw new Error('At least one active role must be assigned.');
    }

    try {
      const apiData = await fetchApi<any>('/users', {
        method: 'POST',
        body: JSON.stringify({
          first_name: trimmedFirst,
          last_name: trimmedLast,
          username: trimmedUsername,
          email: trimmedEmail,
          password: payload.password || 'Admin@123',
          business_unit_id: payload.businessUnitId || null,
          role_ids: payload.roleIds,
          is_active: payload.isActive !== false,
          status: payload.isActive !== false ? 'ACTIVE' : 'INACTIVE',
          created_by: 'Super Admin',
        }),
      });

      if (apiData) {
        const created: User = {
          ...mapApiUser(apiData),
          password: payload.password || 'Admin@123',
        };
        const users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
        saveToStorage(USERS_STORAGE_KEY, [created, ...users.filter((u) => u.id !== created.id)]);
        return created;
      }
    } catch (err: any) {
      if (err.message && !err.message.includes('Failed to fetch')) {
        throw err;
      }
    }

    // Local fallback creation
    const users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
    if (users.some((u) => u.username.toLowerCase() === trimmedUsername.toLowerCase())) {
      throw new Error('A user with this username already exists.');
    }
    if (users.some((u) => u.email.toLowerCase() === trimmedEmail.toLowerCase())) {
      throw new Error('A user with this email already exists.');
    }

    const allRoles = await roleService.getRoles();
    const assignedRoles: UserRoleItem[] = allRoles
      .filter((r) => payload.roleIds.includes(r.id) && r.isActive)
      .map((r) => ({
        id: r.id,
        name: r.name,
        description: r.description,
        roleOrder: r.roleOrder,
        isSystem: r.isSystem,
        isActive: r.isActive,
      }));

    const isAssigningSuperAdmin = assignedRoles.some((r) => r.name.toLowerCase().trim() === 'super admin');
    if (isAssigningSuperAdmin && payload.isActive !== false) {
      const hasOtherActiveSuperAdmin = users.some(
        (u) => u.isActive && u.roles.some((r) => r.name.toLowerCase().trim() === 'super admin')
      );
      if (hasOtherActiveSuperAdmin) {
        throw new Error('A Super Admin already exists. Only one active Super Admin user is allowed in the system.');
      }
    }

    let buItem: UserBUItem | undefined = undefined;
    if (payload.businessUnitId) {
      const allBUs = await portfolioService.getBusinessUnits();
      const match = allBUs.find((b) => b.id === payload.businessUnitId);
      if (match) {
        buItem = { id: match.id, name: match.name, code: match.code };
      }
    }

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newUser: User = {
      id: `user-${Date.now()}`,
      firstName: trimmedFirst,
      lastName: trimmedLast,
      fullName: `${trimmedFirst} ${trimmedLast}`,
      username: trimmedUsername,
      email: trimmedEmail,
      password: payload.password || 'Admin@123',
      businessUnitId: payload.businessUnitId,
      businessUnit: buItem,
      roles: assignedRoles,
      isActive: payload.isActive !== false,
      status: payload.isActive !== false ? 'ACTIVE' : 'INACTIVE',
      createdAt: now,
      createdBy: 'Super Admin',
      updatedAt: now,
      updatedBy: 'Super Admin',
    };

    saveToStorage(USERS_STORAGE_KEY, [newUser, ...users]);
    return newUser;
  },

  async updateUser(userId: string, payload: UserUpdatePayload): Promise<User> {
    try {
      const apiData = await fetchApi<any>(`/users/${userId}`, {
        method: 'PUT',
        body: JSON.stringify({
          first_name: payload.firstName ? payload.firstName.trim() : undefined,
          last_name: payload.lastName ? payload.lastName.trim() : undefined,
          email: payload.email ? payload.email.trim().toLowerCase() : undefined,
          business_unit_id: payload.businessUnitId !== undefined ? payload.businessUnitId : undefined,
          role_ids: payload.roleIds,
          is_active: payload.isActive,
          status: payload.status,
          updated_by: 'Super Admin',
        }),
      });

      if (apiData) {
        const updated = mapApiUser(apiData);
        const users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
        saveToStorage(
          USERS_STORAGE_KEY,
          users.map((u) => (u.id === userId ? updated : u))
        );
        return updated;
      }
    } catch (err: any) {
      if (err.message && !err.message.includes('Failed to fetch') && !err.message.includes('not found')) {
        throw err;
      }
    }

    const users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
    const targetIdx = users.findIndex((u) => u.id === userId);
    if (targetIdx === -1) {
      throw new Error('User not found.');
    }

    const existing = users[targetIdx];
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    let updatedRoles = existing.roles;
    if (payload.roleIds) {
      const allRoles = await roleService.getRoles();
      updatedRoles = allRoles
        .filter((r) => payload.roleIds!.includes(r.id) && r.isActive)
        .map((r) => ({
          id: r.id,
          name: r.name,
          description: r.description,
          roleOrder: r.roleOrder,
          isSystem: r.isSystem,
          isActive: r.isActive,
        }));
    }

    let updatedBU = existing.businessUnit;
    if (payload.businessUnitId !== undefined) {
      if (payload.businessUnitId) {
        const allBUs = await portfolioService.getBusinessUnits();
        const match = allBUs.find((b) => b.id === payload.businessUnitId);
        updatedBU = match ? { id: match.id, name: match.name, code: match.code } : undefined;
      } else {
        updatedBU = undefined;
      }
    }

    const updatedFirstName = payload.firstName ? payload.firstName.trim() : existing.firstName;
    const updatedLastName = payload.lastName ? payload.lastName.trim() : existing.lastName;
    const updatedEmail = payload.email ? payload.email.trim().toLowerCase() : existing.email;

    const updatedUser: User = {
      ...existing,
      firstName: updatedFirstName,
      lastName: updatedLastName,
      email: updatedEmail,
      fullName: `${updatedFirstName} ${updatedLastName}`,
      businessUnitId: payload.businessUnitId !== undefined ? payload.businessUnitId : existing.businessUnitId,
      businessUnit: updatedBU,
      roles: updatedRoles,
      isActive: payload.isActive !== undefined ? payload.isActive : existing.isActive,
      status: payload.status || (payload.isActive !== undefined ? (payload.isActive ? 'ACTIVE' : 'INACTIVE') : existing.status),
      updatedAt: now,
      updatedBy: 'Super Admin',
    };

    users[targetIdx] = updatedUser;
    saveToStorage(USERS_STORAGE_KEY, users);
    return updatedUser;
  },

  async toggleUserStatus(userId: string): Promise<User> {
    try {
      const apiData = await fetchApi<any>(`/users/${userId}/toggle-status`, {
        method: 'PATCH',
      });
      if (apiData) {
        const updated = mapApiUser(apiData);
        const users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
        saveToStorage(
          USERS_STORAGE_KEY,
          users.map((u) => (u.id === userId ? updated : u))
        );
        return updated;
      }
    } catch (err: any) {
      // If network error or backend 404 for local mock entity, proceed to local fallback
      if (err.message && !err.message.includes('Failed to fetch') && !err.message.includes('not found')) {
        throw err;
      }
    }

    const users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
    const user = users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found.');

    const newActive = !user.isActive;
    const updated: User = {
      ...user,
      isActive: newActive,
      status: newActive ? 'ACTIVE' : 'INACTIVE',
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      updatedBy: 'Super Admin',
    };

    saveToStorage(
      USERS_STORAGE_KEY,
      users.map((u) => (u.id === userId ? updated : u))
    );
    return updated;
  },

  async deleteUser(userId: string): Promise<boolean> {
    try {
      await fetchApi<any>(`/users/${userId}`, {
        method: 'DELETE',
      });
    } catch (err: any) {
      if (err.message && !err.message.includes('Failed to fetch') && !err.message.includes('not found')) {
        throw err;
      }
    }

    const users = loadFromStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
    saveToStorage(
      USERS_STORAGE_KEY,
      users.filter((u) => u.id !== userId)
    );
    return true;
  },
};
