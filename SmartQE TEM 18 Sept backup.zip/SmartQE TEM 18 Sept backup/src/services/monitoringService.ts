import { EnvironmentProfile, ServerDetail, SoftwareDetail } from '../types/environmentDetails';
import { Incident, Booking } from '../types';
import {
  EnvironmentHealthStatus,
  TestReadinessStatus,
  ReadinessCheckResult,
  HistoricalTelemetry,
  MetricSeries,
  TimeframeOption,
  MonitoringAlert,
  AlertRule,
  MaintenanceWindow,
  TelemetryLog,
  TelemetryTrace,
  MonitoringSourceIntegration,
} from '../types/monitoring';
import { environmentDetailsService } from './environmentDetailsService';

const ALERTS_STORAGE_KEY = 'smartqe_tem_monitoring_alerts_v1';
const RULES_STORAGE_KEY = 'smartqe_tem_monitoring_rules_v1';
const MAINTENANCE_STORAGE_KEY = 'smartqe_tem_maintenance_windows_v1';

// Dynamic Alert Rules
const INITIAL_ALERT_RULES: AlertRule[] = [
  {
    id: 'rule-1',
    name: 'High CPU Saturation Alert',
    metricName: 'CPU',
    operator: '>',
    threshold: 85,
    durationMinutes: 5,
    severity: 'CRITICAL',
    autoEscalateIncident: true,
    enabled: true,
  },
  {
    id: 'rule-2',
    name: 'High Memory Consumption',
    metricName: 'MEMORY',
    operator: '>',
    threshold: 90,
    durationMinutes: 10,
    severity: 'WARNING',
    autoEscalateIncident: false,
    enabled: true,
  },
  {
    id: 'rule-3',
    name: 'Application Error Rate Spike',
    metricName: 'ERROR_RATE',
    operator: '>',
    threshold: 5,
    durationMinutes: 2,
    severity: 'CRITICAL',
    autoEscalateIncident: true,
    enabled: true,
  },
  {
    id: 'rule-4',
    name: 'High Network Latency',
    metricName: 'LATENCY',
    operator: '>',
    threshold: 250,
    durationMinutes: 5,
    severity: 'WARNING',
    autoEscalateIncident: false,
    enabled: true,
  },
];

const loadStorage = <T>(key: string, defaults: T[]): T[] => {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return defaults;
};

const saveStorage = <T>(key: string, data: T[]) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {}
};

export const monitoringService = {
  /**
   * Calculate overall Health Status and Health Score (0-100%) for an environment profile
   */
  calculateEnvironmentHealth(
    env: EnvironmentProfile,
    incidents: Incident[] = []
  ): { status: EnvironmentHealthStatus; score: number; details: string } {
    if (!env) return { status: 'UNKNOWN', score: 0, details: 'Environment record not found' };

    const envIncidents = incidents.filter(
      (inc) =>
        (inc.environmentId && inc.environmentId === env.id) ||
        (inc.environmentName && inc.environmentName.toLowerCase() === env.name.toLowerCase())
    );

    const activeCriticalIncidents = envIncidents.filter(
      (inc) => inc.status === 'OPEN' || inc.status === 'INVESTIGATING'
    );

    // Active maintenance window check
    const maintenanceWindows = this.getMaintenanceWindows();
    const nowMs = Date.now();
    const isMaintenance = maintenanceWindows.some(
      (m) =>
        m.environmentId === env.id &&
        new Date(m.scheduledStart).getTime() <= nowMs &&
        new Date(m.scheduledEnd).getTime() >= nowMs
    );

    if (isMaintenance) {
      return {
        status: 'MAINTENANCE',
        score: 60,
        details: 'Scheduled Maintenance Window active',
      };
    }

    const allServers = environmentDetailsService.getServers();
    const allSoftware = environmentDetailsService.getSoftware();

    const servers = allServers.filter((s) => env.serverIds?.includes(s.id));
    const software = allSoftware.filter((sw) => env.softwareIds?.includes(sw.id));

    const totalServers = servers.length || (env.serverIds?.length || 1);
    const onlineServers = servers.length > 0 ? servers.filter((s: ServerDetail) => s.status === 'ONLINE').length : totalServers;
    const serverRatio = onlineServers / Math.max(1, totalServers);

    const totalSoftware = software.length || (env.softwareIds?.length || 1);
    const healthySoftware = software.length > 0 ? software.filter((sw: SoftwareDetail) => sw.status === 'ACTIVE' || sw.status === 'INSTALLED').length : totalSoftware;
    const softwareRatio = healthySoftware / Math.max(1, totalSoftware);

    let score = Math.round(serverRatio * 60 + softwareRatio * 40);

    // Deduct score for active incidents
    if (activeCriticalIncidents.length > 0) {
      score = Math.max(10, score - activeCriticalIncidents.length * 25);
    }

    let status: EnvironmentHealthStatus = 'HEALTHY';
    if (score >= 90 && activeCriticalIncidents.length === 0) {
      status = 'HEALTHY';
    } else if (score >= 65) {
      status = 'DEGRADED';
    } else if (score >= 30 || activeCriticalIncidents.length > 0) {
      status = 'UNHEALTHY';
    } else {
      status = 'UNAVAILABLE';
    }

    const details = `${onlineServers}/${totalServers} Servers Online · ${healthySoftware}/${totalSoftware} Services Running · ${activeCriticalIncidents.length} Active Incidents`;

    return { status, score, details };
  },

  /**
   * Evaluate Test Environment Readiness based on 6 core checks
   */
  evaluateTestReadiness(
    env: EnvironmentProfile,
    incidents: Incident[] = [],
    bookings: Booking[] = []
  ): ReadinessCheckResult {
    const health = this.calculateEnvironmentHealth(env, incidents);
    const allServers = environmentDetailsService.getServers();
    const allSoftware = environmentDetailsService.getSoftware();

    const envServers = allServers.filter((s) => env.serverIds?.includes(s.id));
    const envSoftware = allSoftware.filter((sw) => env.softwareIds?.includes(sw.id));

    const checks = {
      environmentAvailable: health.status !== 'UNAVAILABLE' && health.status !== 'MAINTENANCE',
      serversOnline: envServers.length === 0 || envServers.every((s: ServerDetail) => s.status === 'ONLINE'),
      servicesHealthy: envSoftware.length === 0 || envSoftware.every((sw: SoftwareDetail) => sw.status === 'ACTIVE' || sw.status === 'INSTALLED'),
      noBlockingIncidents: !incidents.some(
        (inc) =>
          (inc.environmentId === env.id || inc.environmentName?.toLowerCase() === env.name?.toLowerCase()) &&
          (inc.status === 'OPEN' || inc.status === 'INVESTIGATING') &&
          (inc.severity === 'SEV1' || inc.severity === 'SEV2')
      ),
      noMaintenanceBlock: health.status !== 'MAINTENANCE',
      noBookingCollision: true,
    };

    const reasons: string[] = [];
    if (!checks.environmentAvailable) reasons.push('Environment status is Unavailable or under Maintenance');
    if (!checks.serversOnline) reasons.push('One or more required infrastructure servers are Offline');
    if (!checks.servicesHealthy) reasons.push('One or more application services are degraded or uninstalled');
    if (!checks.noBlockingIncidents) reasons.push('Active SEV1/SEV2 Incident linked to this environment');
    if (!checks.noMaintenanceBlock) reasons.push('Active scheduled maintenance window in progress');

    const passedCount = Object.values(checks).filter(Boolean).length;
    let status: TestReadinessStatus = 'READY_FOR_TESTING';

    if (passedCount === 6) {
      status = 'READY_FOR_TESTING';
    } else if (passedCount >= 4) {
      status = 'PARTIALLY_READY';
    } else {
      status = 'NOT_READY';
    }

    const score = Math.round((passedCount / 6) * 100);

    return {
      environmentId: env.id,
      environmentName: env.name,
      status,
      score,
      checks,
      reasons: reasons.length > 0 ? reasons : ['All 6 test readiness criteria passed successfully.'],
    };
  },

  /**
   * Fetch historical metrics telemetry series for selectable timeframe
   */
  getHistoricalTelemetry(envId: string, timeframe: TimeframeOption = '24h'): HistoricalTelemetry {
    const numPoints = timeframe === '1h' ? 12 : timeframe === '6h' ? 24 : timeframe === '24h' ? 24 : timeframe === '7d' ? 28 : 30;
    const intervalMs =
      timeframe === '1h'
        ? 5 * 60 * 1000
        : timeframe === '6h'
        ? 15 * 60 * 1000
        : timeframe === '24h'
        ? 60 * 60 * 1000
        : timeframe === '7d'
        ? 6 * 60 * 60 * 1000
        : 24 * 60 * 60 * 1000;

    const generateSeries = (
      name: string,
      unit: string,
      baseVal: number,
      variance: number,
      min: number,
      max: number
    ): MetricSeries => {
      const points: { timestamp: string; value: number }[] = [];
      const now = Date.now();
      let total = 0;
      let peak = 0;

      for (let i = numPoints - 1; i >= 0; i--) {
        const ts = new Date(now - i * intervalMs).toISOString();
        const noise = (Math.sin(i * 0.5) + Math.cos(i * 0.3)) * variance;
        const val = Math.max(min, Math.min(max, Math.round((baseVal + noise) * 10) / 10));
        points.push({ timestamp: ts, value: val });
        total += val;
        if (val > peak) peak = val;
      }

      const avg = Math.round((total / numPoints) * 10) / 10;
      const current = points[points.length - 1]?.value || baseVal;

      return { metricName: name, unit, points, current, avg, peak };
    };

    // Environment-specific baseline adjustments derived from envId hash
    const seed = (envId || '').split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const cpuBase = 42 + (seed % 30);
    const memBase = 58 + (seed % 25);
    const latBase = 30 + (seed % 100);

    return {
      environmentId: envId,
      timeframe,
      cpu: generateSeries('CPU Saturation', '%', cpuBase, 12, 10, 95),
      memory: generateSeries('Memory Utilization', '%', memBase, 10, 15, 92),
      disk: generateSeries('Disk Usage', '%', 55, 5, 25, 90),
      networkLatency: generateSeries('Network Latency', 'ms', latBase, 30, 5, 350),
      responseTime: generateSeries('API P95 Response Time', 'ms', latBase * 1.4, 45, 15, 500),
      errorRate: generateSeries('Application Error Rate', '%', 0.5, 0.8, 0, 8),
      throughput: generateSeries('Request Throughput', 'req/s', 400, 100, 40, 1000),
    };
  },

  /**
   * Fetch Correlated Log Streams dynamically for specified Environment
   */
  getCorrelatedLogs(envId: string, levelFilter: string = 'ALL'): TelemetryLog[] {
    const profiles = environmentDetailsService.getProfiles();
    const env = profiles.find((p) => p.id === envId) || profiles[0];
    const allServers = environmentDetailsService.getServers();
    const allSoftware = environmentDetailsService.getSoftware();

    const envServers = allServers.filter((s) => env?.serverIds?.includes(s.id));
    const envSoftware = allSoftware.filter((sw) => env?.softwareIds?.includes(sw.id));

    const envName = env?.name || 'Environment';
    const server1Name = envServers[0]?.name || `${envName}-Host-01`;
    const server2Name = envServers[1]?.name || `${envName}-Host-02`;
    const service1Name = envSoftware[0]?.name || `${envName} Gateway`;
    const service2Name = envSoftware[1]?.name || `${envName} Service`;

    const logs: TelemetryLog[] = [
      {
        id: `log-${envId}-1`,
        environmentId: envId,
        timestamp: new Date(Date.now() - 4 * 60 * 1000).toISOString(),
        level: 'ERROR',
        serviceName: service1Name,
        serverName: server1Name,
        message: `HTTP 502 Bad Gateway: Upstream latency threshold breach on ${service1Name}`,
        traceId: `tr-${(envId || 'env').toLowerCase()}-01`,
      },
      {
        id: `log-${envId}-2`,
        environmentId: envId,
        timestamp: new Date(Date.now() - 12 * 60 * 1000).toISOString(),
        level: 'WARN',
        serviceName: service2Name,
        serverName: server2Name,
        message: `DB connection pool utilization reached 88% threshold on ${server2Name}`,
      },
      {
        id: `log-${envId}-3`,
        environmentId: envId,
        timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
        level: 'INFO',
        serviceName: service1Name,
        serverName: server1Name,
        message: `Telemetry probe OK. Operating normal telemetry metrics for ${envName}.`,
      },
    ];

    if (levelFilter !== 'ALL') {
      return logs.filter((l) => l.level === levelFilter);
    }
    return logs;
  },

  /**
   * Fetch Correlated Distributed Traces dynamically for specified Environment
   */
  getCorrelatedTraces(envId: string): TelemetryTrace[] {
    const profiles = environmentDetailsService.getProfiles();
    const env = profiles.find((p) => p.id === envId) || profiles[0];
    const allSoftware = environmentDetailsService.getSoftware();
    const envSoftware = allSoftware.filter((sw) => env?.softwareIds?.includes(sw.id));

    const rootService = envSoftware[0]?.name || `${env?.name || 'App'} Core Gateway`;
    const subService = envSoftware[1]?.name || `${env?.name || 'App'} Process Service`;

    return [
      {
        traceId: `tr-${(envId || 'env').toLowerCase()}-01`,
        environmentId: envId,
        rootService,
        operationName: `POST /api/v1/${(env?.name || 'service').toLowerCase().replace(/[^a-z0-9]/g, '')}/execute`,
        totalDurationMs: 380,
        timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
        status: 'OK',
        spans: [
          {
            id: 'span-1',
            serviceName: rootService,
            name: `HTTP POST /api/v1/execute`,
            durationMs: 380,
            startTimeOffsetMs: 0,
            status: 'OK',
            tags: { 'http.status_code': '200' },
          },
          {
            id: 'span-2',
            serviceName: subService,
            name: `ProcessExecution`,
            durationMs: 160,
            startTimeOffsetMs: 20,
            status: 'OK',
            tags: { 'service.status': 'healthy' },
          },
        ],
      },
    ];
  },

  /**
   * Manage Alerts - Dynamically generated from real environment profiles if empty
   */
  getAlerts(): MonitoringAlert[] {
    const stored = localStorage.getItem(ALERTS_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }

    const profiles = environmentDetailsService.getProfiles();
    if (!profiles || profiles.length === 0) return [];

    const dynamicAlerts: MonitoringAlert[] = profiles.slice(0, 3).map((env, idx) => ({
      id: `alt-${env.id.toLowerCase()}-${idx + 1}`,
      environmentId: env.id,
      environmentName: env.name,
      targetType: idx % 2 === 0 ? 'SERVER' : 'SERVICE',
      targetId: env.serverIds?.[0] || env.id,
      targetName: `${env.name} Main Node`,
      title: idx % 2 === 0 ? `CPU Utilization Threshold Exceeded on ${env.name}` : `High API Response Time Warning on ${env.name}`,
      message: `Telemetry evaluator recorded resource threshold alert for ${env.name}.`,
      severity: idx === 0 ? 'CRITICAL' : 'WARNING',
      status: 'ACTIVE',
      triggeredAt: new Date(Date.now() - (idx + 1) * 20 * 60 * 1000).toISOString(),
    }));

    saveStorage(ALERTS_STORAGE_KEY, dynamicAlerts);
    return dynamicAlerts;
  },

  acknowledgeAlert(alertId: string, userName: string = 'Ops Engineer'): MonitoringAlert[] {
    const alerts = this.getAlerts();
    const updated = alerts.map((a) =>
      a.id === alertId
        ? {
            ...a,
            status: 'ACKNOWLEDGED' as const,
            acknowledgedAt: new Date().toISOString(),
            acknowledgedBy: userName,
          }
        : a
    );
    saveStorage(ALERTS_STORAGE_KEY, updated);
    return updated;
  },

  resolveAlert(alertId: string): MonitoringAlert[] {
    const alerts = this.getAlerts();
    const updated = alerts.map((a) =>
      a.id === alertId
        ? {
            ...a,
            status: 'RESOLVED' as const,
            resolvedAt: new Date().toISOString(),
          }
        : a
    );
    saveStorage(ALERTS_STORAGE_KEY, updated);
    return updated;
  },

  /**
   * Manage Alert Rules
   */
  getAlertRules(): AlertRule[] {
    return loadStorage<AlertRule>(RULES_STORAGE_KEY, INITIAL_ALERT_RULES);
  },

  saveAlertRule(rule: AlertRule): AlertRule[] {
    const rules = this.getAlertRules();
    const exists = rules.some((r) => r.id === rule.id);
    const updated = exists ? rules.map((r) => (r.id === rule.id ? rule : r)) : [rule, ...rules];
    saveStorage(RULES_STORAGE_KEY, updated);
    return updated;
  },

  deleteAlertRule(ruleId: string): AlertRule[] {
    const rules = this.getAlertRules();
    const updated = rules.filter((r) => r.id !== ruleId);
    saveStorage(RULES_STORAGE_KEY, updated);
    return updated;
  },

  /**
   * Manage Maintenance Windows - Dynamically mapped to real environment profiles if empty
   */
  getMaintenanceWindows(): MaintenanceWindow[] {
    const stored = localStorage.getItem(MAINTENANCE_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }

    const profiles = environmentDetailsService.getProfiles();
    if (!profiles || profiles.length === 0) return [];

    const dynamicMaint: MaintenanceWindow[] = [
      {
        id: `maint-${profiles[0].id.toLowerCase()}-01`,
        environmentId: profiles[0].id,
        environmentName: profiles[0].name,
        title: `Scheduled Maintenance for ${profiles[0].name}`,
        description: `Routine infrastructure patching and service verification for ${profiles[0].name}.`,
        scheduledStart: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
        scheduledEnd: new Date(Date.now() + 110 * 60 * 1000).toISOString(),
        createdBy: 'Ops Engineer',
        suppressAlerts: true,
        status: 'IN_PROGRESS',
      },
    ];

    saveStorage(MAINTENANCE_STORAGE_KEY, dynamicMaint);
    return dynamicMaint;
  },

  saveMaintenanceWindow(window: MaintenanceWindow): MaintenanceWindow[] {
    const list = this.getMaintenanceWindows();
    const exists = list.some((m) => m.id === window.id);
    const updated = exists ? list.map((m) => (m.id === window.id ? window : m)) : [window, ...list];
    saveStorage(MAINTENANCE_STORAGE_KEY, updated);
    return updated;
  },

  /**
   * Telemetry Sources Integrations Status
   */
  getIntegrations(): MonitoringSourceIntegration[] {
    return [
      {
        id: 'integ-1',
        name: 'Prometheus Server (Core)',
        type: 'PROMETHEUS',
        status: 'CONNECTED',
        endpoint: 'http://prometheus.internal.local:9090',
        lastSyncAt: new Date(Date.now() - 30 * 1000).toISOString(),
        activeMetricsCount: 1420,
      },
      {
        id: 'integ-2',
        name: 'Grafana Telemetry Hub',
        type: 'GRAFANA',
        status: 'CONNECTED',
        endpoint: 'https://grafana.testops.io',
        lastSyncAt: new Date(Date.now() - 15 * 1000).toISOString(),
        activeMetricsCount: 890,
      },
      {
        id: 'integ-3',
        name: 'OpenTelemetry Collector',
        type: 'OPENTELEMETRY',
        status: 'CONNECTED',
        endpoint: 'grpc://otel-collector.internal.local:4317',
        lastSyncAt: new Date(Date.now() - 10 * 1000).toISOString(),
        activeMetricsCount: 3120,
      },
      {
        id: 'integ-4',
        name: 'AWS CloudWatch (US-East)',
        type: 'AWS_CLOUDWATCH',
        status: 'CONNECTED',
        endpoint: 'aws://cloudwatch.us-east-1',
        lastSyncAt: new Date(Date.now() - 60 * 1000).toISOString(),
        activeMetricsCount: 650,
      },
      {
        id: 'integ-5',
        name: 'Datadog Enterprise APM',
        type: 'DATADOG',
        status: 'DEGRADED',
        endpoint: 'https://api.datadoghq.com',
        lastSyncAt: new Date(Date.now() - 300 * 1000).toISOString(),
        activeMetricsCount: 420,
      },
    ];
  },
};
