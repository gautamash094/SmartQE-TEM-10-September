import { fetchApiStrict } from './apiClient';
import { userService } from './userService';
import { portfolioService } from './portfolioService';

export interface UserGroupMember {
  id: string;
  userId: string;
  username?: string;
  fullName?: string;
  email?: string;
  businessUnitId?: string;
  isActive?: boolean;
  createdAt: string;
  createdBy: string;
}

export interface UserGroup {
  id: string;
  name: string;
  description?: string;
  buId: string;
  buName?: string;
  buCode?: string;
  members: UserGroupMember[];
  memberCount: number;
  isActive: boolean;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  createdBy: string;
  updatedAt: string;
  modifiedBy: string;
}

export interface UserGroupCreatePayload {
  name: string;
  description?: string;
  buId: string;
  userIds: string[];
  isActive?: boolean;
}

export interface UserGroupUpdatePayload {
  name?: string;
  description?: string;
  buId?: string;
  userIds?: string[];
  isActive?: boolean;
  status?: 'ACTIVE' | 'INACTIVE';
}

const USER_GROUPS_STORAGE_KEY = 'smartqe_tem_user_groups_v1';

function isNetworkError(err: any): boolean {
  if (!err) return false;
  const msg = (err.message || String(err)).toLowerCase();
  return (
    msg.includes('failed to fetch') ||
    msg.includes('networkerror') ||
    msg.includes('network error') ||
    msg.includes('load failed') ||
    msg.includes('connection refused') ||
    msg.includes('aborterror')
  );
}

class UserGroupService {
  private getLocalGroups(): UserGroup[] {
    try {
      const raw = localStorage.getItem(USER_GROUPS_STORAGE_KEY);
      if (raw) {
        return JSON.parse(raw);
      }
    } catch {}
    return [];
  }

  private saveLocalGroups(groups: UserGroup[]): void {
    try {
      localStorage.setItem(USER_GROUPS_STORAGE_KEY, JSON.stringify(groups));
    } catch {}
  }

  private normalizeGroup(data: any): UserGroup {
    const rawMembers = data.members || [];
    const members: UserGroupMember[] = rawMembers.map((m: any) => ({
      id: m.id || `member-${Math.random().toString(36).substring(2, 9)}`,
      userId: m.user_id || m.userId,
      username: m.username,
      fullName: m.full_name || m.fullName,
      email: m.email,
      businessUnitId: m.business_unit_id || m.businessUnitId,
      isActive: m.is_active !== undefined ? m.is_active : m.isActive,
      createdAt: m.created_at || m.createdAt || new Date().toISOString(),
      createdBy: m.created_by || m.createdBy || 'Super Admin',
    }));

    return {
      id: data.id,
      name: data.name,
      description: data.description || '',
      buId: data.bu_id || data.buId,
      buName: data.bu_name || data.buName,
      buCode: data.bu_code || data.buCode,
      members,
      memberCount: data.member_count !== undefined ? data.member_count : members.length,
      isActive: data.is_active !== undefined ? data.is_active : data.isActive ?? true,
      status: (data.status || (data.is_active !== false ? 'ACTIVE' : 'INACTIVE')) as 'ACTIVE' | 'INACTIVE',
      createdAt: data.created_at || data.createdAt || new Date().toISOString(),
      createdBy: data.created_by || data.createdBy || 'Super Admin',
      updatedAt: data.updated_at || data.updatedAt || new Date().toISOString(),
      modifiedBy: data.modified_by || data.modifiedBy || 'Super Admin',
    };
  }

  async getUserGroups(params?: { search?: string; buId?: string; isActive?: boolean }): Promise<UserGroup[]> {
    try {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.buId) query.append('buId', params.buId);
      if (params?.isActive !== undefined) query.append('isActive', String(params.isActive));
      query.append('pageSize', '100');

      const data = await fetchApiStrict<any[]>(`/user-groups?${query.toString()}`);
      if (Array.isArray(data)) {
        const normalized = data.map((d) => this.normalizeGroup(d));
        this.saveLocalGroups(normalized);
        return normalized;
      }
    } catch (err: any) {
      if (!isNetworkError(err)) {
        console.warn('[UserGroupService] API error when fetching user groups:', err.message);
      }
    }

    let groups = this.getLocalGroups();
    if (params?.search) {
      const q = params.search.toLowerCase().trim();
      groups = groups.filter(
        (g) =>
          g.name.toLowerCase().includes(q) ||
          (g.description && g.description.toLowerCase().includes(q))
      );
    }
    if (params?.buId) {
      groups = groups.filter((g) => g.buId === params.buId);
    }
    if (params?.isActive !== undefined) {
      groups = groups.filter((g) => g.isActive === params.isActive);
    }
    return groups;
  }

  async getUserGroupById(groupId: string): Promise<UserGroup> {
    try {
      const data = await fetchApiStrict<any>(`/user-groups/${groupId}`);
      const normalized = this.normalizeGroup(data);
      return normalized;
    } catch (err: any) {
      if (!isNetworkError(err)) throw err;
    }

    const group = this.getLocalGroups().find((g) => g.id === groupId);
    if (!group) {
      throw new Error(`User Group with ID "${groupId}" not found.`);
    }
    return group;
  }

  async createUserGroup(payload: UserGroupCreatePayload): Promise<UserGroup> {
    const apiPayload = {
      name: payload.name.trim(),
      description: payload.description?.trim() || '',
      bu_id: payload.buId,
      user_ids: payload.userIds,
      is_active: payload.isActive ?? true,
    };

    try {
      const data = await fetchApiStrict<any>('/user-groups', {
        method: 'POST',
        body: JSON.stringify(apiPayload),
      });

      const normalized = this.normalizeGroup(data);
      const existing = this.getLocalGroups();
      this.saveLocalGroups([normalized, ...existing.filter((g) => g.id !== normalized.id)]);
      return normalized;
    } catch (err: any) {
      if (!isNetworkError(err)) {
        throw err;
      }
    }

    // --- Local Fallback Creation with Strict BU Restriction ---
    const allBUs = await portfolioService.getBusinessUnits();
    const bu = allBUs.find(
      (b) => b.id === payload.buId || b.name.toLowerCase() === payload.buId.toLowerCase()
    );
    const resolvedBuId = bu?.id || payload.buId;
    const resolvedBuName = bu?.name || 'Selected BU';
    const resolvedBuCode = bu?.code || 'BU';

    const allUsers = await userService.getUsers();
    const existingGroups = this.getLocalGroups();

    // Check duplicate group name
    const duplicate = existingGroups.find(
      (g) => g.name.toLowerCase().trim() === payload.name.toLowerCase().trim()
    );
    if (duplicate) {
      throw new Error(`A User Group with name "${payload.name.trim()}" already exists.`);
    }

    // Validate users and strict BU membership
    if (!payload.userIds || payload.userIds.length === 0) {
      throw new Error('User group must contain at least one user.');
    }

    const members: UserGroupMember[] = [];
    for (const userId of payload.userIds) {
      const user = allUsers.find((u) => u.id === userId);
      if (!user) {
        throw new Error(`User ID "${userId}" does not exist.`);
      }
      if (!user.isActive || user.status === 'INACTIVE') {
        throw new Error(`User "${user.fullName || user.username}" is inactive.`);
      }

      // Check BU match
      const userBuId = user.businessUnitId || user.businessUnit?.id;
      const userBuName = user.businessUnit?.name?.toLowerCase().trim() || '';
      const isBuMatch =
        userBuId === resolvedBuId ||
        userBuId === payload.buId ||
        (resolvedBuName && userBuName === resolvedBuName.toLowerCase().trim());

      if (!isBuMatch) {
        throw new Error(
          `User "${user.fullName || user.username}" does not belong to Business Unit "${resolvedBuName}".`
        );
      }

      members.push({
        id: `ugm-${Date.now()}-${userId}`,
        userId: user.id,
        username: user.username,
        fullName: user.fullName || `${user.firstName} ${user.lastName}`,
        email: user.email,
        businessUnitId: resolvedBuId,
        isActive: true,
        createdAt: new Date().toISOString(),
        createdBy: 'Super Admin',
      });
    }

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newGroup: UserGroup = {
      id: `group-${Date.now()}`,
      name: payload.name.trim(),
      description: payload.description?.trim() || '',
      buId: resolvedBuId,
      buName: resolvedBuName,
      buCode: resolvedBuCode,
      members,
      memberCount: members.length,
      isActive: payload.isActive ?? true,
      status: (payload.isActive ?? true) ? 'ACTIVE' : 'INACTIVE',
      createdAt: now,
      createdBy: 'Super Admin',
      updatedAt: now,
      modifiedBy: 'Super Admin',
    };

    this.saveLocalGroups([newGroup, ...existingGroups]);
    return newGroup;
  }

  async updateUserGroup(groupId: string, payload: UserGroupUpdatePayload): Promise<UserGroup> {
    const apiPayload: any = {};
    if (payload.name !== undefined) apiPayload.name = payload.name.trim();
    if (payload.description !== undefined) apiPayload.description = payload.description.trim();
    if (payload.buId !== undefined) apiPayload.bu_id = payload.buId;
    if (payload.userIds !== undefined) apiPayload.user_ids = payload.userIds;
    if (payload.isActive !== undefined) apiPayload.is_active = payload.isActive;
    if (payload.status !== undefined) apiPayload.status = payload.status;

    try {
      const data = await fetchApiStrict<any>(`/user-groups/${groupId}`, {
        method: 'PUT',
        body: JSON.stringify(apiPayload),
      });

      const normalized = this.normalizeGroup(data);
      const existing = this.getLocalGroups();
      this.saveLocalGroups(existing.map((g) => (g.id === groupId ? normalized : g)));
      return normalized;
    } catch (err: any) {
      if (!isNetworkError(err)) {
        throw err;
      }
    }

    // --- Local Fallback Update ---
    const existingGroups = this.getLocalGroups();
    const existing = existingGroups.find((g) => g.id === groupId);
    if (!existing) {
      throw new Error(`User Group with ID "${groupId}" not found.`);
    }

    if (payload.name) {
      const duplicate = existingGroups.find(
        (g) => g.id !== groupId && g.name.toLowerCase().trim() === payload.name!.toLowerCase().trim()
      );
      if (duplicate) {
        throw new Error(`A User Group with name "${payload.name.trim()}" already exists.`);
      }
    }

    const targetBuId = payload.buId || existing.buId;
    const allBUs = await portfolioService.getBusinessUnits();
    const bu = allBUs.find((b) => b.id === targetBuId || b.name.toLowerCase() === targetBuId.toLowerCase());
    const resolvedBuId = bu?.id || targetBuId;
    const resolvedBuName = bu?.name || existing.buName || 'Selected BU';
    const resolvedBuCode = bu?.code || existing.buCode || 'BU';

    let members = existing.members;
    if (payload.userIds) {
      const allUsers = await userService.getUsers();
      members = [];
      for (const userId of payload.userIds) {
        const user = allUsers.find((u) => u.id === userId);
        if (!user) {
          throw new Error(`User ID "${userId}" does not exist.`);
        }
        if (!user.isActive || user.status === 'INACTIVE') {
          throw new Error(`User "${user.fullName || user.username}" is inactive.`);
        }
        const userBuId = user.businessUnitId || user.businessUnit?.id;
        const userBuName = user.businessUnit?.name?.toLowerCase().trim() || '';
        const isBuMatch =
          userBuId === resolvedBuId ||
          userBuId === targetBuId ||
          (resolvedBuName && userBuName === resolvedBuName.toLowerCase().trim());
        if (!isBuMatch) {
          throw new Error(
            `User "${user.fullName || user.username}" does not belong to Business Unit "${resolvedBuName}".`
          );
        }
        members.push({
          id: `ugm-${Date.now()}-${userId}`,
          userId: user.id,
          username: user.username,
          fullName: user.fullName || `${user.firstName} ${user.lastName}`,
          email: user.email,
          businessUnitId: resolvedBuId,
          isActive: true,
          createdAt: new Date().toISOString(),
          createdBy: 'Super Admin',
        });
      }
    }

    const nextIsActive =
      payload.isActive !== undefined
        ? payload.isActive
        : payload.status !== undefined
        ? payload.status === 'ACTIVE'
        : existing.isActive;

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const updated: UserGroup = {
      ...existing,
      name: payload.name !== undefined ? payload.name.trim() : existing.name,
      description: payload.description !== undefined ? payload.description.trim() : existing.description,
      buId: resolvedBuId,
      buName: resolvedBuName,
      buCode: resolvedBuCode,
      members,
      memberCount: members.length,
      isActive: nextIsActive,
      status: nextIsActive ? 'ACTIVE' : 'INACTIVE',
      updatedAt: now,
      modifiedBy: 'Super Admin',
    };

    this.saveLocalGroups(existingGroups.map((g) => (g.id === groupId ? updated : g)));
    return updated;
  }

  async toggleUserGroupStatus(groupId: string): Promise<UserGroup> {
    try {
      const data = await fetchApiStrict<any>(`/user-groups/${groupId}/toggle-status`, {
        method: 'PATCH',
      });
      const normalized = this.normalizeGroup(data);
      const existing = this.getLocalGroups();
      this.saveLocalGroups(existing.map((g) => (g.id === groupId ? normalized : g)));
      return normalized;
    } catch (err: any) {
      if (!isNetworkError(err)) {
        throw err;
      }
    }

    const existingGroups = this.getLocalGroups();
    const existing = existingGroups.find((g) => g.id === groupId);
    if (!existing) {
      throw new Error(`User Group with ID "${groupId}" not found.`);
    }

    const nextActive = !existing.isActive;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const updated: UserGroup = {
      ...existing,
      isActive: nextActive,
      status: nextActive ? 'ACTIVE' : 'INACTIVE',
      updatedAt: now,
      modifiedBy: 'Super Admin',
    };

    this.saveLocalGroups(existingGroups.map((g) => (g.id === groupId ? updated : g)));
    return updated;
  }

  async deleteUserGroup(groupId: string): Promise<void> {
    try {
      await fetchApiStrict<any>(`/user-groups/${groupId}`, {
        method: 'DELETE',
      });
      const existing = this.getLocalGroups();
      this.saveLocalGroups(existing.filter((g) => g.id !== groupId));
      return;
    } catch (err: any) {
      if (!isNetworkError(err)) {
        throw err;
      }
    }

    const existingGroups = this.getLocalGroups();
    this.saveLocalGroups(existingGroups.filter((g) => g.id !== groupId));
  }
}

export const userGroupService = new UserGroupService();
