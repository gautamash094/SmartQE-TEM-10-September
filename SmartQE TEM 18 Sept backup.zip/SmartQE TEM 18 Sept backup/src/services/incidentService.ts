import { Incident } from '../types';
import { INITIAL_INCIDENTS } from '../constants/mockData';
import { fetchApi } from './apiClient';

export const incidentService = {
  async getIncidents(): Promise<Incident[]> {
    const apiData = await fetchApi<any[]>('/incidents');
    if (apiData && Array.isArray(apiData)) {
      return apiData.map((inc) => ({
        id: inc.incident_code || inc.id,
        title: inc.title,
        severity: inc.severity,
        environmentId: inc.environment_id || inc.environmentId,
        environmentName: inc.environment_name || inc.environmentName,
        assignee: inc.assignee,
        status: inc.status,
        openedAt: inc.opened_at || inc.openedAt,
        description: inc.description,
      }));
    }
    return [];
  },

  async createIncident(incData: Omit<Incident, 'id' | 'openedAt' | 'status'>): Promise<Incident> {
    const payload = {
      title: incData.title,
      severity: incData.severity,
      environment_id: incData.environmentId,
      environment_name: incData.environmentName,
      assignee: incData.assignee,
      status: 'OPEN',
      opened_at: new Date().toISOString(),
      description: incData.description,
    };

    const apiData = await fetchApi<any>('/incidents', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    if (apiData) {
      return {
        id: apiData.incident_code || apiData.id,
        title: apiData.title,
        severity: apiData.severity,
        environmentId: apiData.environment_id || incData.environmentId,
        environmentName: apiData.environment_name || incData.environmentName,
        assignee: apiData.assignee,
        status: apiData.status,
        openedAt: apiData.opened_at || new Date().toLocaleString(),
        description: apiData.description,
      };
    }

    return {
      ...incData,
      id: `INC-${Math.floor(Math.random() * 90000) + 10000}`,
      openedAt: new Date().toLocaleString(),
      status: 'OPEN',
    };
  },
};
