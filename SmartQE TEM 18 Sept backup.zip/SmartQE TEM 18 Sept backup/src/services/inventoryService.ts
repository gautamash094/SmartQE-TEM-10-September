import {
  InventoryAsset,
  InventoryMetrics,
  AssetAuditLog,
  AssetStatus,
  AssetType,
  CloudProvider,
  InfrastructureType
} from '../types/inventory';
import { fetchApi } from './apiClient';

const STORAGE_KEY = 'smartqe_tem_inventory_v1';

export const INITIAL_INVENTORY_ASSETS: InventoryAsset[] = [];

const getStoredAssets = (): InventoryAsset[] | null => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return null;
};

const setStoredAssets = (assets: InventoryAsset[]) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(assets));
  } catch {}
};

const mapBackendAsset = (item: any): InventoryAsset => {
  return {
    id: item.id,
    assetId: item.asset_id || item.assetId || `AST-${item.id.slice(-4)}`,
    name: item.name,
    assetType: (item.asset_type || item.assetType || 'SERVER') as AssetType,
    infrastructureType: (item.infrastructure_type || item.infrastructureType || 'ON_PREMISES') as InfrastructureType,
    cloudProvider: (item.cloud_provider || item.cloudProvider || 'On-Premises') as CloudProvider,
    businessUnit: item.business_unit || item.businessUnit || 'General Banking',
    accountName: item.account_name || item.accountName || 'Core Project',
    environmentId: item.environment_id || item.environmentId,
    environmentName: item.environment_name || item.environmentName,
    environmentType: item.environment_type || item.environmentType || 'UAT / Staging',
    applicationName: item.application_name || item.applicationName,
    ipAddress: item.ip_address || item.ipAddress,
    hostname: item.hostname,
    operatingSystem: item.operating_system || item.operatingSystem,
    osVersion: item.os_version || item.osVersion,
    runtimeStack: item.runtime_stack || item.runtimeStack,
    cpuCores: item.cpu_cores || item.cpuCores || 4,
    ramGb: item.ram_gb || item.ramGb || 16,
    storageGb: item.storage_gb || item.storageGb || 250,
    region: item.region || 'us-east-1',
    availabilityZone: item.availability_zone || item.availabilityZone,
    datacenter: item.datacenter,
    rackUnit: item.rack_unit || item.rackUnit,
    instanceId: item.instance_id || item.instanceId,
    instanceType: item.instance_type || item.instanceType,
    vpcSubnet: item.vpc_subnet || item.vpcSubnet,
    installedSoftware: item.installed_software || item.installedSoftware || [],
    status: (item.status || 'ACTIVE') as AssetStatus,
    ownerTeam: item.owner_team || item.ownerTeam || 'Platform QE',
    responsiblePerson: item.responsible_person || item.responsiblePerson || 'Ops Engineer',
    costCenter: item.cost_center || item.costCenter || 'CC-GEN-001',
    endOfLifeDate: item.end_of_life_date || item.endOfLifeDate,
    notes: item.notes,
    tags: item.tags || {},
    createdAt: item.created_at || item.createdAt || new Date().toISOString(),
    updatedAt: item.updated_at || item.updatedAt || new Date().toISOString(),
    createdBy: item.created_by || item.createdBy || 'System Admin',
    updatedBy: item.updated_by || item.updatedBy || 'System Admin',
    auditLogs: (item.audit_logs || item.auditLogs || []).map((l: any) => ({
      id: l.id || `log-${Date.now()}`,
      assetId: l.asset_id || l.assetId,
      action: l.action,
      changedBy: l.changed_by || l.changedBy,
      changedAt: l.changed_at || l.changedAt,
      fieldName: l.field_name || l.fieldName,
      oldValue: l.old_value || l.oldValue,
      newValue: l.new_value || l.newValue,
      notes: l.notes,
    })),
  };
};

export const inventoryService = {
  /**
   * Fetch all inventory assets with optional query parameters
   */
  async getAssets(params: Record<string, any> = {}): Promise<InventoryAsset[]> {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== 'ALL' && v !== '') {
        query.append(k, String(v));
      }
    });

    const queryString = query.toString() ? `?${query.toString()}` : '';
    const apiData = await fetchApi<any[]>(`/inventory/assets${queryString}`);

    if (apiData && Array.isArray(apiData)) {
      const mapped = apiData.map(mapBackendAsset);
      setStoredAssets(mapped);
      return mapped;
    }

    const stored = getStoredAssets();
    if (stored) return stored;
    return [...INITIAL_INVENTORY_ASSETS];
  },

  /**
   * Fetch single asset by ID with complete audit history
   */
  async getAssetById(id: string): Promise<InventoryAsset | null> {
    const apiData = await fetchApi<any>(`/inventory/assets/${id}`);
    if (apiData) {
      return mapBackendAsset(apiData);
    }
    const current = getStoredAssets() || INITIAL_INVENTORY_ASSETS;
    const found = current.find((a) => a.id === id || a.assetId === id);
    return found ? { ...found } : null;
  },

  /**
   * Create a new inventory asset
   */
  async createAsset(assetData: Omit<InventoryAsset, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'updatedBy' | 'auditLogs'>): Promise<InventoryAsset> {
    const payload = {
      name: assetData.name,
      asset_id: assetData.assetId,
      asset_type: assetData.assetType,
      infrastructure_type: assetData.infrastructureType,
      cloud_provider: assetData.cloudProvider,
      business_unit: assetData.businessUnit,
      account_name: assetData.accountName,
      environment_id: assetData.environmentId,
      environment_name: assetData.environmentName,
      environment_type: assetData.environmentType,
      application_name: assetData.applicationName,
      ip_address: assetData.ipAddress,
      hostname: assetData.hostname,
      operating_system: assetData.operatingSystem,
      os_version: assetData.osVersion,
      runtime_stack: assetData.runtimeStack,
      cpu_cores: assetData.cpuCores,
      ram_gb: assetData.ramGb,
      storage_gb: assetData.storageGb,
      region: assetData.region,
      availability_zone: assetData.availabilityZone,
      datacenter: assetData.datacenter,
      rack_unit: assetData.rackUnit,
      instance_id: assetData.instanceId,
      instance_type: assetData.instanceType,
      vpc_subnet: assetData.vpcSubnet,
      installed_software: assetData.installedSoftware,
      status: assetData.status,
      owner_team: assetData.ownerTeam,
      responsible_person: assetData.responsiblePerson,
      cost_center: assetData.costCenter,
      end_of_life_date: assetData.endOfLifeDate,
      notes: assetData.notes,
      tags: assetData.tags,
    };

    const apiData = await fetchApi<any>('/inventory/assets?user=Ops Engineer', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    const created: InventoryAsset = apiData
      ? mapBackendAsset(apiData)
      : {
          ...assetData,
          id: `ast-${Date.now()}`,
          assetId: assetData.assetId || `AST-${Date.now().toString().slice(-4)}`,
          createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          createdBy: 'Ops Engineer',
          updatedBy: 'Ops Engineer',
          auditLogs: [
            {
              id: `log-${Date.now()}`,
              action: 'CREATE',
              changedBy: 'Ops Engineer',
              changedAt: new Date().toISOString(),
              notes: 'Created via Inventory Management modal',
            },
          ],
        };

    const current = getStoredAssets() || INITIAL_INVENTORY_ASSETS;
    setStoredAssets([created, ...current.filter((a) => a.id !== created.id)]);
    return created;
  },

  /**
   * Update an existing inventory asset
   */
  async updateAsset(id: string, assetData: Partial<InventoryAsset>): Promise<InventoryAsset> {
    const payload: any = {};
    if (assetData.name !== undefined) payload.name = assetData.name;
    if (assetData.assetType !== undefined) payload.asset_type = assetData.assetType;
    if (assetData.infrastructureType !== undefined) payload.infrastructure_type = assetData.infrastructureType;
    if (assetData.cloudProvider !== undefined) payload.cloud_provider = assetData.cloudProvider;
    if (assetData.businessUnit !== undefined) payload.business_unit = assetData.businessUnit;
    if (assetData.accountName !== undefined) payload.account_name = assetData.accountName;
    if (assetData.environmentId !== undefined) payload.environment_id = assetData.environmentId;
    if (assetData.environmentName !== undefined) payload.environment_name = assetData.environmentName;
    if (assetData.environmentType !== undefined) payload.environment_type = assetData.environmentType;
    if (assetData.applicationName !== undefined) payload.application_name = assetData.applicationName;
    if (assetData.ipAddress !== undefined) payload.ip_address = assetData.ipAddress;
    if (assetData.hostname !== undefined) payload.hostname = assetData.hostname;
    if (assetData.operatingSystem !== undefined) payload.operating_system = assetData.operatingSystem;
    if (assetData.osVersion !== undefined) payload.os_version = assetData.osVersion;
    if (assetData.runtimeStack !== undefined) payload.runtime_stack = assetData.runtimeStack;
    if (assetData.cpuCores !== undefined) payload.cpu_cores = assetData.cpuCores;
    if (assetData.ramGb !== undefined) payload.ram_gb = assetData.ramGb;
    if (assetData.storageGb !== undefined) payload.storage_gb = assetData.storageGb;
    if (assetData.region !== undefined) payload.region = assetData.region;
    if (assetData.availabilityZone !== undefined) payload.availability_zone = assetData.availabilityZone;
    if (assetData.datacenter !== undefined) payload.datacenter = assetData.datacenter;
    if (assetData.rackUnit !== undefined) payload.rack_unit = assetData.rackUnit;
    if (assetData.instanceId !== undefined) payload.instance_id = assetData.instanceId;
    if (assetData.instanceType !== undefined) payload.instance_type = assetData.instanceType;
    if (assetData.vpcSubnet !== undefined) payload.vpc_subnet = assetData.vpcSubnet;
    if (assetData.installedSoftware !== undefined) payload.installed_software = assetData.installedSoftware;
    if (assetData.status !== undefined) payload.status = assetData.status;
    if (assetData.ownerTeam !== undefined) payload.owner_team = assetData.ownerTeam;
    if (assetData.responsiblePerson !== undefined) payload.responsible_person = assetData.responsiblePerson;
    if (assetData.costCenter !== undefined) payload.cost_center = assetData.costCenter;
    if (assetData.endOfLifeDate !== undefined) payload.end_of_life_date = assetData.endOfLifeDate;
    if (assetData.notes !== undefined) payload.notes = assetData.notes;
    if (assetData.tags !== undefined) payload.tags = assetData.tags;

    const apiData = await fetchApi<any>(`/inventory/assets/${id}?user=Ops Engineer`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });

    const updated: InventoryAsset = apiData
      ? mapBackendAsset(apiData)
      : ({
          id,
          ...assetData,
          updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          updatedBy: 'Ops Engineer',
        } as InventoryAsset);

    const current = getStoredAssets() || INITIAL_INVENTORY_ASSETS;
    setStoredAssets(current.map((a) => (a.id === id ? { ...a, ...updated } : a)));
    return updated;
  },

  /**
   * Transition asset lifecycle status (e.g. ACTIVE -> MAINTENANCE -> RETIRED)
   */
  async changeAssetStatus(id: string, newStatus: AssetStatus, reason?: string): Promise<InventoryAsset> {
    const apiData = await fetchApi<any>(`/inventory/assets/${id}/status?user=Ops Engineer`, {
      method: 'POST',
      body: JSON.stringify({ status: newStatus, reason }),
    });

    if (apiData) {
      const updated = mapBackendAsset(apiData);
      const current = getStoredAssets() || INITIAL_INVENTORY_ASSETS;
      setStoredAssets(current.map((a) => (a.id === id ? updated : a)));
      return updated;
    }

    const current = getStoredAssets() || INITIAL_INVENTORY_ASSETS;
    const target = current.find((a) => a.id === id);
    const updated: InventoryAsset = target
      ? {
          ...target,
          status: newStatus,
          updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          updatedBy: 'Ops Engineer',
          auditLogs: [
            ...(target.auditLogs || []),
            {
              id: `log-${Date.now()}`,
              action: newStatus === 'RETIRED' ? 'RETIRE' : 'STATUS_CHANGE',
              changedBy: 'Ops Engineer',
              changedAt: new Date().toISOString(),
              fieldName: 'status',
              oldValue: target.status,
              newValue: newStatus,
              notes: reason || `Status updated to ${newStatus}`,
            },
          ],
        }
      : ({ id, status: newStatus } as any);

    setStoredAssets(current.map((a) => (a.id === id ? updated : a)));
    return updated;
  },

  /**
   * Soft deactivate an asset (Toggle between ACTIVE and INACTIVE)
   */
  async toggleAssetStatus(id: string): Promise<InventoryAsset> {
    const current = getStoredAssets() || INITIAL_INVENTORY_ASSETS;
    const target = current.find((a) => a.id === id);
    const nextStatus: AssetStatus = target?.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';

    const res = await fetchApi<any>(`/inventory/assets/${id}/toggle-status?user=Ops Engineer`, {
      method: 'PATCH',
    });

    const updated: InventoryAsset = res
      ? {
          ...res,
          auditLogs: res.audit_logs || res.auditLogs || [],
        }
      : ({ ...(target || {}), id, status: nextStatus, updatedAt: new Date().toISOString() } as any);

    setStoredAssets(current.map((a) => (a.id === id ? updated : a)));
    return updated;
  },

  /**
   * Soft deactivate an asset without deleting records
   */
  async deleteAsset(id: string, hardDelete: boolean = false): Promise<void> {
    await fetchApi(`/inventory/assets/${id}?hard_delete=false&user=Ops Engineer`, {
      method: 'DELETE',
    });

    const current = getStoredAssets() || INITIAL_INVENTORY_ASSETS;
    setStoredAssets(
      current.map((a) =>
        a.id === id
          ? {
              ...a,
              status: 'INACTIVE' as AssetStatus,
              updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
            }
          : a
      )
    );
  },

  /**
   * Calculate or fetch executive inventory metrics
   */
  async getMetrics(): Promise<InventoryMetrics> {
    const apiData = await fetchApi<any>('/inventory/metrics');
    if (apiData) {
      return {
        totalAssets: apiData.total_assets,
        totalEnvironments: apiData.total_environments,
        totalServers: apiData.total_servers,
        totalDatabases: apiData.total_databases,
        totalCloudResources: apiData.total_cloud_resources,
        totalNetworkComponents: apiData.total_network_components,
        totalSoftware: apiData.total_software,
        cloudAssetsCount: apiData.cloud_assets_count,
        onPremAssetsCount: apiData.on_prem_assets_count,
        hybridAssetsCount: apiData.hybrid_assets_count,
        activeAssetsCount: apiData.active_assets_count,
        inactiveAssetsCount: apiData.inactive_assets_count,
        maintenanceAssetsCount: apiData.maintenance_assets_count,
        retiredAssetsCount: apiData.retired_assets_count,
        approachingEolCount: apiData.approaching_eol_count,
        assetsByBu: apiData.assets_by_bu || {},
        assetsByProvider: apiData.assets_by_provider || {},
        assetsByStatus: apiData.assets_by_status || {},
        assetsByType: apiData.assets_by_type || {},
        assetsByOs: apiData.assets_by_os || {},
      };
    }

    const current = getStoredAssets() || INITIAL_INVENTORY_ASSETS;
    const total = current.length;
    const envSet = new Set(current.map((a) => a.environmentName).filter(Boolean));

    const assetsByBu: Record<string, number> = {};
    const assetsByProvider: Record<string, number> = {};
    const assetsByStatus: Record<string, number> = {};
    const assetsByType: Record<string, number> = {};
    const assetsByOs: Record<string, number> = {};

    let cloudCount = 0;
    let onPremCount = 0;
    let hybridCount = 0;
    let activeCount = 0;
    let inactiveCount = 0;
    let maintCount = 0;
    let retiredCount = 0;
    let approachingEol = 0;

    let servers = 0;
    let dbs = 0;
    let cloudRes = 0;
    let networks = 0;
    let software = 0;

    current.forEach((a) => {
      assetsByBu[a.businessUnit || 'General'] = (assetsByBu[a.businessUnit || 'General'] || 0) + 1;
      assetsByProvider[a.cloudProvider || 'Other'] = (assetsByProvider[a.cloudProvider || 'Other'] || 0) + 1;
      assetsByStatus[a.status || 'ACTIVE'] = (assetsByStatus[a.status || 'ACTIVE'] || 0) + 1;
      assetsByType[a.assetType || 'SERVER'] = (assetsByType[a.assetType || 'SERVER'] || 0) + 1;
      assetsByOs[a.operatingSystem || 'Other'] = (assetsByOs[a.operatingSystem || 'Other'] || 0) + 1;

      if (a.infrastructureType === 'CLOUD') cloudCount++;
      else if (a.infrastructureType === 'ON_PREMISES') onPremCount++;
      else if (a.infrastructureType === 'HYBRID') hybridCount++;

      if (a.status === 'ACTIVE') activeCount++;
      else if (a.status === 'INACTIVE') inactiveCount++;
      else if (a.status === 'MAINTENANCE') maintCount++;
      else if (a.status === 'RETIRED' || a.status === 'DECOMMISSIONED') retiredCount++;

      if (a.assetType === 'SERVER') servers++;
      else if (a.assetType === 'DATABASE') dbs++;
      else if (a.assetType === 'CLOUD_RESOURCE') cloudRes++;
      else if (a.assetType === 'NETWORK_COMPONENT') networks++;
      else if (a.assetType === 'SOFTWARE') software++;

      if (a.endOfLifeDate && a.endOfLifeDate <= '2027-01-01') approachingEol++;
    });

    return {
      totalAssets: total,
      totalEnvironments: envSet.size,
      totalServers: servers,
      totalDatabases: dbs,
      totalCloudResources: cloudRes,
      totalNetworkComponents: networks,
      totalSoftware: software,
      cloudAssetsCount: cloudCount,
      onPremAssetsCount: onPremCount,
      hybridAssetsCount: hybridCount,
      activeAssetsCount: activeCount,
      inactiveAssetsCount: inactiveCount,
      maintenanceAssetsCount: maintCount,
      retiredAssetsCount: retiredCount,
      approachingEolCount: approachingEol,
      assetsByBu,
      assetsByProvider,
      assetsByStatus,
      assetsByType,
      assetsByOs,
    };
  },
};
