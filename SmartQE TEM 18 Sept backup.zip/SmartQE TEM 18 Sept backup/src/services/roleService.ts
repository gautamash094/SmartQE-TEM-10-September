import { fetchApi } from './apiClient';
import { BusinessUnit, portfolioService } from './portfolioService';

export interface Role {
  id: string;
  name: string;
  description?: string;
  roleOrder: number;
  isSystem: boolean;
  isActive: boolean;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt?: string;
  updatedAt?: string;
}

export interface RoleCreateInput {
  name: string;
  description?: string;
  roleOrder?: number;
  isActive?: boolean;
}

export interface RoleUpdateInput {
  name?: string;
  description?: string;
  roleOrder?: number;
  isActive?: boolean;
}

export interface RoleReorderItem {
  id: string;
  roleOrder: number;
}

export interface AppConfig {
  defaultRoleId?: string;
  defaultRoleName?: string;
  defaultBusinessUnitId?: string;
  defaultBusinessUnitName?: string;
}

export const INITIAL_ROLES: Role[] = [
  {
    id: 'role-super-admin',
    name: 'Super Admin',
    description: 'Default initial system role with top-level administrative authority across the TEM application.',
    roleOrder: 1,
    isSystem: true,
    isActive: true,
    status: 'ACTIVE',
    createdAt: '2026-08-01 09:00:00',
    updatedAt: '2026-08-01 09:00:00'
  }
];

const ROLES_STORAGE_KEY = 'smartqe_tem_roles_v2';
const APP_CONFIG_STORAGE_KEY = 'smartqe_tem_app_config_v2';

function loadFromStorage<T>(key: string, defaults: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed) return parsed;
    }
  } catch {}
  return defaults;
}

function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {}
}

export const roleService = {
  // ── Roles ──
  async getRoles(): Promise<Role[]> {
    try {
      const apiData = await fetchApi<any[]>('/roles');
      if (apiData && Array.isArray(apiData) && apiData.length > 0) {
        const mapped: Role[] = apiData.map(r => {
          const isActive = r.is_active !== undefined ? r.is_active : (r.isActive !== undefined ? r.isActive : r.status !== 'INACTIVE');
          return {
            id: r.id,
            name: r.name,
            description: r.description || '',
            roleOrder: r.role_order !== undefined ? r.role_order : (r.roleOrder || 1),
            isSystem: !!(r.is_system || r.isSystem),
            isActive,
            status: isActive ? 'ACTIVE' : 'INACTIVE',
            createdAt: r.created_at || r.createdAt,
            updatedAt: r.updated_at || r.updatedAt
          };
        });
        // Sort by roleOrder ascending
        mapped.sort((a, b) => a.roleOrder - b.roleOrder);
        saveToStorage(ROLES_STORAGE_KEY, mapped);
        return mapped;
      }
    } catch {}

    const local = loadFromStorage<Role[]>(ROLES_STORAGE_KEY, [...INITIAL_ROLES]);
    // Ensure Super Admin is always present
    if (!local.some(r => r.name.toLowerCase() === 'super admin')) {
      local.unshift(INITIAL_ROLES[0]);
    }
    local.sort((a, b) => a.roleOrder - b.roleOrder);
    return local;
  },

  async createRole(roleData: RoleCreateInput): Promise<Role> {
    const cleanName = roleData.name.trim();
    if (!cleanName) {
      throw new Error('Role Name is mandatory and cannot be empty or contain only spaces.');
    }

    const currentRoles = await this.getRoles();
    if (currentRoles.some(r => r.name.toLowerCase() === cleanName.toLowerCase())) {
      throw new Error('A role with this name already exists.');
    }

    const nextOrder = roleData.roleOrder || (Math.max(0, ...currentRoles.map(r => r.roleOrder)) + 1);
    const isActive = roleData.isActive !== false;

    const newRole: Role = {
      id: `role-${Date.now()}`,
      name: cleanName,
      description: roleData.description?.trim() || '',
      roleOrder: nextOrder,
      isSystem: false,
      isActive,
      status: isActive ? 'ACTIVE' : 'INACTIVE',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };

    try {
      const apiData = await fetchApi<any>('/roles', {
        method: 'POST',
        body: JSON.stringify({
          name: cleanName,
          description: newRole.description,
          role_order: newRole.roleOrder,
          is_active: newRole.isActive,
          status: newRole.status
        })
      });

      if (apiData) {
        const created: Role = {
          id: apiData.id,
          name: apiData.name,
          description: apiData.description || '',
          roleOrder: apiData.role_order || newRole.roleOrder,
          isSystem: !!(apiData.is_system || apiData.isSystem),
          isActive: apiData.is_active !== undefined ? apiData.is_active : true,
          status: (apiData.is_active !== false) ? 'ACTIVE' : 'INACTIVE',
          createdAt: apiData.created_at || newRole.createdAt,
          updatedAt: apiData.updated_at || newRole.updatedAt
        };
        const updatedList = [...currentRoles, created].sort((a, b) => a.roleOrder - b.roleOrder);
        saveToStorage(ROLES_STORAGE_KEY, updatedList);
        return created;
      }
    } catch (err: any) {
      if (err.message && err.message.includes('already exists')) {
        throw err;
      }
    }

    const updatedList = [...currentRoles, newRole].sort((a, b) => a.roleOrder - b.roleOrder);
    saveToStorage(ROLES_STORAGE_KEY, updatedList);
    return newRole;
  },

  async updateRole(id: string, updateData: RoleUpdateInput): Promise<Role> {
    const currentRoles = await this.getRoles();
    const target = currentRoles.find(r => r.id === id);
    if (!target) {
      throw new Error(`Role with ID ${id} not found.`);
    }

    if (updateData.name) {
      const cleanName = updateData.name.trim();
      if (!cleanName) {
        throw new Error('Role Name cannot be empty or contain only spaces.');
      }
      if (cleanName.toLowerCase() !== target.name.toLowerCase()) {
        if (currentRoles.some(r => r.id !== id && r.name.toLowerCase() === cleanName.toLowerCase())) {
          throw new Error('A role with this name already exists.');
        }
      }
      updateData.name = cleanName;
    }

    if (target.isSystem && updateData.isActive === false) {
      throw new Error('The default system role (Super Admin) cannot be deactivated.');
    }

    const isActive = updateData.isActive !== undefined ? updateData.isActive : target.isActive;
    const updated: Role = {
      ...target,
      ...updateData,
      id,
      isActive,
      status: isActive ? 'ACTIVE' : 'INACTIVE',
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };

    try {
      await fetchApi(`/roles/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: updated.name,
          description: updated.description,
          role_order: updated.roleOrder,
          is_active: updated.isActive,
          status: updated.status
        })
      });
    } catch {}

    const updatedList = currentRoles.map(r => r.id === id ? updated : r).sort((a, b) => a.roleOrder - b.roleOrder);
    saveToStorage(ROLES_STORAGE_KEY, updatedList);
    return updated;
  },

  async toggleRole(id: string): Promise<Role[]> {
    const currentRoles = await this.getRoles();
    const target = currentRoles.find(r => r.id === id);
    if (!target) return currentRoles;

    if (target.isSystem) {
      throw new Error('The default system role (Super Admin) cannot be deactivated.');
    }

    const newActive = !target.isActive;
    const updated: Role = {
      ...target,
      isActive: newActive,
      status: newActive ? 'ACTIVE' : 'INACTIVE',
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };

    try {
      await fetchApi(`/roles/${id}/toggle-status`, {
        method: 'PATCH'
      });
    } catch {}

    const updatedList = currentRoles.map(r => r.id === id ? updated : r);
    saveToStorage(ROLES_STORAGE_KEY, updatedList);
    return updatedList;
  },

  async deleteRole(id: string): Promise<Role[]> {
    const currentRoles = await this.getRoles();
    const target = currentRoles.find(r => r.id === id);
    if (!target) return currentRoles;

    if (target.isSystem) {
      throw new Error('The default system role (Super Admin) cannot be deleted.');
    }

    try {
      await fetchApi(`/roles/${id}`, {
        method: 'DELETE'
      });
    } catch {}

    const updatedList = currentRoles.filter(r => r.id !== id);
    // Re-index remaining role orders
    const reindexed = updatedList.map((r, idx) => ({ ...r, roleOrder: idx + 1 }));
    saveToStorage(ROLES_STORAGE_KEY, reindexed);
    return reindexed;
  },

  async reorderRoles(reorderList: RoleReorderItem[]): Promise<Role[]> {
    const currentRoles = await this.getRoles();
    const orderMap = new Map<string, number>();
    reorderList.forEach(item => orderMap.set(item.id, item.roleOrder));

    const updated = currentRoles.map(r => ({
      ...r,
      roleOrder: orderMap.has(r.id) ? orderMap.get(r.id)! : r.roleOrder
    }));

    updated.sort((a, b) => a.roleOrder - b.roleOrder);

    try {
      await fetchApi('/roles/reorder', {
        method: 'PUT',
        body: JSON.stringify({
          roles: reorderList.map(r => ({ id: r.id, role_order: r.roleOrder }))
        })
      });
    } catch {}

    saveToStorage(ROLES_STORAGE_KEY, updated);
    return updated;
  },

  // ── App Configuration (Default Role & Default BU) ──
  async getAppConfig(): Promise<AppConfig> {
    try {
      const apiData = await fetchApi<any>('/settings/config');
      if (apiData) {
        const config: AppConfig = {
          defaultRoleId: apiData.default_role_id || apiData.defaultRoleId,
          defaultRoleName: apiData.default_role_name || apiData.defaultRoleName,
          defaultBusinessUnitId: apiData.default_business_unit_id || apiData.defaultBusinessUnitId,
          defaultBusinessUnitName: apiData.default_business_unit_name || apiData.defaultBusinessUnitName
        };
        saveToStorage(APP_CONFIG_STORAGE_KEY, config);
        return config;
      }
    } catch {}

    const localConfig = loadFromStorage<AppConfig>(APP_CONFIG_STORAGE_KEY, {
      defaultRoleId: 'role-super-admin',
      defaultRoleName: 'Super Admin',
      defaultBusinessUnitId: undefined,
      defaultBusinessUnitName: undefined
    });
    return localConfig;
  },

  async updateAppConfig(config: AppConfig): Promise<AppConfig> {
    try {
      const apiData = await fetchApi<any>('/settings/config', {
        method: 'PUT',
        body: JSON.stringify({
          default_role_id: config.defaultRoleId,
          default_role_name: config.defaultRoleName,
          default_business_unit_id: config.defaultBusinessUnitId,
          default_business_unit_name: config.defaultBusinessUnitName
        })
      });
      if (apiData) {
        const updated: AppConfig = {
          defaultRoleId: apiData.default_role_id || apiData.defaultRoleId,
          defaultRoleName: apiData.default_role_name || apiData.defaultRoleName,
          defaultBusinessUnitId: apiData.default_business_unit_id || apiData.defaultBusinessUnitId,
          defaultBusinessUnitName: apiData.default_business_unit_name || apiData.defaultBusinessUnitName
        };
        saveToStorage(APP_CONFIG_STORAGE_KEY, updated);
        return updated;
      }
    } catch {}

    saveToStorage(APP_CONFIG_STORAGE_KEY, config);
    return config;
  }
};
