import { EnvironmentProfile, ServerDetail, SoftwareDetail } from './environmentDetails';
import { Incident, Booking } from './index';

export type EnvironmentHealthStatus =
  | 'HEALTHY'
  | 'DEGRADED'
  | 'UNHEALTHY'
  | 'UNAVAILABLE'
  | 'MAINTENANCE'
  | 'UNKNOWN';

export type TestReadinessStatus =
  | 'READY_FOR_TESTING'
  | 'PARTIALLY_READY'
  | 'NOT_READY'
  | 'UNKNOWN';

export type AlertSeverity = 'CRITICAL' | 'WARNING' | 'INFO';
export type AlertStatus = 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED';
export type TimeframeOption = '1h' | '6h' | '24h' | '7d' | '30d';

export interface MetricPoint {
  timestamp: string; // ISO string
  value: number;
}

export interface MetricSeries {
  metricName: string;
  unit: string;
  points: MetricPoint[];
  current: number;
  avg: number;
  peak: number;
}

export interface HistoricalTelemetry {
  environmentId: string;
  timeframe: TimeframeOption;
  cpu: MetricSeries;
  memory: MetricSeries;
  disk: MetricSeries;
  networkLatency: MetricSeries;
  responseTime: MetricSeries;
  errorRate: MetricSeries;
  throughput: MetricSeries;
}

export interface ReadinessCheckResult {
  environmentId: string;
  environmentName: string;
  status: TestReadinessStatus;
  score: number; // 0 to 100
  checks: {
    environmentAvailable: boolean;
    serversOnline: boolean;
    servicesHealthy: boolean;
    noBlockingIncidents: boolean;
    noMaintenanceBlock: boolean;
    noBookingCollision: boolean;
  };
  reasons: string[];
}

export interface MonitoringAlert {
  id: string;
  environmentId: string;
  environmentName: string;
  targetType: 'SERVER' | 'SERVICE' | 'APPLICATION' | 'ENVIRONMENT';
  targetId: string;
  targetName: string;
  title: string;
  message: string;
  severity: AlertSeverity;
  status: AlertStatus;
  triggeredAt: string;
  acknowledgedAt?: string;
  acknowledgedBy?: string;
  resolvedAt?: string;
  linkedIncidentId?: string;
}

export interface AlertRule {
  id: string;
  name: string;
  environmentId?: string; // 'ALL' or specific
  metricName: 'CPU' | 'MEMORY' | 'DISK' | 'LATENCY' | 'ERROR_RATE' | 'SERVICE_DOWN';
  operator: '>' | '>=' | '<' | '==';
  threshold: number;
  durationMinutes: number;
  severity: AlertSeverity;
  autoEscalateIncident: boolean;
  enabled: boolean;
}

export interface MaintenanceWindow {
  id: string;
  environmentId: string;
  environmentName: string;
  title: string;
  description: string;
  scheduledStart: string;
  scheduledEnd: string;
  createdBy: string;
  suppressAlerts: boolean;
  status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED';
}

export interface TelemetryLog {
  id: string;
  environmentId: string;
  timestamp: string;
  level: 'ERROR' | 'WARN' | 'INFO' | 'DEBUG';
  serviceName: string;
  serverName: string;
  message: string;
  traceId?: string;
}

export interface TelemetryTraceSpan {
  id: string;
  serviceName: string;
  name: string;
  durationMs: number;
  startTimeOffsetMs: number;
  status: 'OK' | 'ERROR';
  tags: Record<string, string>;
}

export interface TelemetryTrace {
  traceId: string;
  environmentId: string;
  rootService: string;
  operationName: string;
  totalDurationMs: number;
  timestamp: string;
  status: 'OK' | 'ERROR';
  spans: TelemetryTraceSpan[];
}

export interface MonitoringSourceIntegration {
  id: string;
  name: string;
  type: 'PROMETHEUS' | 'GRAFANA' | 'DATADOG' | 'DYNATRACE' | 'AWS_CLOUDWATCH' | 'OPENTELEMETRY';
  status: 'CONNECTED' | 'DEGRADED' | 'DISCONNECTED';
  endpoint: string;
  lastSyncAt: string;
  activeMetricsCount: number;
}
