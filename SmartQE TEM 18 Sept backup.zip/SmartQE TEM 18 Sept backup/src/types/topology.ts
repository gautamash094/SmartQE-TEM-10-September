export type TopologyNodeType =
  | 'ENVIRONMENT'
  | 'APPLICATION'
  | 'SERVER'
  | 'SOFTWARE'
  | 'DATABASE'
  | 'MICROSERVICE'
  | 'CLOUD_RESOURCE'
  | 'NETWORK_COMPONENT'
  | 'STORAGE'
  | 'GATEWAY';

export type TopologyRelationshipType =
  | 'HOSTED_ON'
  | 'RUNS_ON'
  | 'DEPENDS_ON'
  | 'CONNECTS_TO'
  | 'CALLS'
  | 'SENDS_DATA_TO'
  | 'USES_DATABASE'
  | 'USES_SERVICE'
  | 'PART_OF'
  | 'DEPLOYED_ON';

export type TopologyNodeStatus =
  | 'HEALTHY'
  | 'WARNING'
  | 'CRITICAL'
  | 'UNAVAILABLE'
  | 'MAINTENANCE'
  | 'UNKNOWN';

export interface TopologyNode {
  id: string;
  name: string;
  type: TopologyNodeType | string;
  sub_type?: string;
  status: TopologyNodeStatus | string;
  environment_id?: string;
  environment_name?: string;
  business_unit?: string;
  account_name?: string;
  ip_address?: string;
  hostname?: string;
  cloud_provider?: string;
  region?: string;
  specs?: string;
  active_incidents_count?: number;
  active_incident_severities?: string[];
  properties?: Record<string, any>;
  x?: number;
  y?: number;
}

export interface TopologyEdge {
  id: string;
  source: string;
  target: string;
  relationship_type: TopologyRelationshipType | string;
  label?: string;
  port?: string;
  protocol?: string;
  latency_ms?: number;
  is_custom?: boolean;
  is_active?: boolean;
}

export interface TopologyMetrics {
  total_nodes: number;
  total_edges: number;
  environments_count: number;
  applications_count: number;
  servers_count: number;
  software_count: number;
  databases_count: number;
  active_incidents_count: number;
  unhealthy_nodes_count: number;
}

export interface TopologyGraphResponse {
  nodes: TopologyNode[];
  edges: TopologyEdge[];
  metrics: TopologyMetrics;
}

export interface ImpactAnalysisResult {
  target_node: TopologyNode;
  impact_score: number;
  impact_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  affected_environments: string[];
  affected_applications: string[];
  affected_servers: string[];
  affected_services: string[];
  affected_databases: string[];
  upstream_nodes: TopologyNode[];
  downstream_nodes: TopologyNode[];
  total_affected_count: number;
}

export type TopologyViewMode =
  | 'ENVIRONMENT'
  | 'APPLICATION'
  | 'INFRASTRUCTURE'
  | 'DEPENDENCY'
  | 'IMPACT';

export type TopologyLayoutType =
  | 'HIERARCHICAL'
  | 'LAYERED'
  | 'GROUPED_ENV'
  | 'FLOW';

export interface TopologyFilterState {
  searchQuery: string;
  environmentId: string;
  businessUnit: string;
  account: string;
  nodeTypes: string[];
  status: string;
  cloudProvider: string;
  region: string;
  hasActiveIncidentsOnly: boolean;
}
