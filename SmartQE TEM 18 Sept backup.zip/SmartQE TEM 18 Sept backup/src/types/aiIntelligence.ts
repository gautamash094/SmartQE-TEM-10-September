import { EnvironmentTier, ReservationMode } from './index';

export type ConflictRiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'VERY_HIGH';
export type PredictionConfidence = 'HIGH' | 'MEDIUM' | 'LOW';

export interface ConflictExplanationPoint {
  id: string;
  category: 'HISTORICAL_DENSITY' | 'BU_DEMAND_SURGE' | 'OVERLAPPING_BOOKINGS' | 'DISRUPTIVE_MODE' | 'RELEASE_COLLISION' | 'HEALTH_INCIDENT_PENALTY';
  title: string;
  detail: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
}

export interface ConflictPredictionResult {
  environmentId: string;
  environmentName: string;
  startDate: string;
  endDate: string;
  conflictProbability: number; // 0 - 100 %
  riskLevel: ConflictRiskLevel;
  confidence: PredictionConfidence;
  explanations: ConflictExplanationPoint[];
  overlappingBookingsCount: number;
  disruptiveBookingsCount: number;
  upcomingReleasesCount: number;
  recentIncidentsCount: number;
  healthPenalty: number;
}

export interface AlternativeEnvironmentRecommendation {
  environmentId: string;
  environmentName: string;
  tier: EnvironmentTier;
  compatibilityScore: number; // 0 - 100 %
  predictedUtilization: number; // 0 - 100 %
  conflictRisk: ConflictRiskLevel;
  reasoning: string;
  techStackMatch: string[];
  topologyMatchScore: number;
}

export interface BookingAIAssistResult {
  prediction: ConflictPredictionResult;
  recommendations: AlternativeEnvironmentRecommendation[];
  summaryMessage: string;
}

export type ForecastHorizon = '7d' | '14d' | '30d' | '90d';

export interface TimeSeriesForecastPoint {
  date: string;
  dayLabel: string;
  predictedDemand: number;
  availableCapacity: number;
  reservedCapacity: number;
  shortage: number;
  isCapacityRisk: boolean;
}

export interface ForecastDimensionBreakdown {
  dimensionName: string; // BU name, Account, Tier, or Env Type
  currentDemand: number;
  predictedDemand: number;
  growthPercentage: number;
  predictedUtilization: number;
  capacityRiskLevel: ConflictRiskLevel;
}

export interface DemandForecastResult {
  horizon: ForecastHorizon;
  totalPredictedDemand: number;
  totalAvailableCapacity: number;
  totalCapacityShortage: number;
  peakPeriodLabel: string;
  timeSeries: TimeSeriesForecastPoint[];
  byBusinessUnit: ForecastDimensionBreakdown[];
  byAccount: ForecastDimensionBreakdown[];
  byTier: ForecastDimensionBreakdown[];
  byEnvType: ForecastDimensionBreakdown[];
}

export interface PredictiveHeatmapCell {
  environmentId: string;
  environmentName: string;
  tier: EnvironmentTier;
  dateStr: string;
  dayOfWeek: string;
  conflictProbability: number;
  riskLevel: ConflictRiskLevel;
  hasActiveRelease: boolean;
  hasIncident: boolean;
  bookingCount: number;
}

export interface WhatIfScenarioInput {
  demandGrowthPercentage: number; // e.g. 20 for +20%
  offlineEnvironmentIds: string[];
  additionalReleaseCount: number;
  convertAllToDisruptive: boolean;
  maintenanceWindowHours: number;
}

export interface WhatIfScenarioResult {
  baselineDemand: number;
  simulatedDemand: number;
  baselineShortage: number;
  simulatedShortage: number;
  additionalConflictsCount: number;
  averageUtilizationPercentage: number;
  affectedBusinessUnits: string[];
  affectedAccounts: string[];
  recommendedAdditionalCapacityCount: number;
  recommendations: string[];
}

export interface CapacityRecommendation {
  id: string;
  title: string;
  type: 'ADD_CAPACITY' | 'SHIFT_TIMING' | 'USE_ALTERNATIVE' | 'CONVERT_MODE' | 'RELEASE_UNUSED';
  targetEnvironmentId?: string;
  targetEnvironmentName?: string;
  timeframe: string;
  impactScore: string;
  reasoning: string;
}

export interface ProactiveAlert {
  id: string;
  title: string;
  environmentId: string;
  environmentName: string;
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  predictedUtilization: number;
  timeframe: string;
  message: string;
  actionableRecommendation: string;
  createdTimestamp: string;
}

export interface AIFeedbackRecord {
  id: string;
  timestamp: string;
  predictionId: string;
  userDecision: 'ACCEPTED' | 'REJECTED' | 'MODIFIED';
  targetEnvironmentId: string;
  chosenEnvironmentId: string;
  rejectionReason?: string;
}
