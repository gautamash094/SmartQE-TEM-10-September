export type EnvironmentStatus = 'HEALTHY' | 'DOWN' | 'DEGRADED' | 'MAINTENANCE';
export type EnvironmentTier = 'DEV' | 'SIT' | 'UAT' | 'PRE-PROD' | 'PERF' | 'QA';

export interface ComponentTopology {
  id: string;
  name: string;
  category: 'SERVICE' | 'COMPUTE' | 'DATABASE' | 'CACHE' | 'QUEUE';
  version: string;
  status: EnvironmentStatus;
}

export interface Environment {
  id: string;
  name: string;
  tier: EnvironmentTier;
  team: string;
  owner: string;
  region: string;
  status: EnvironmentStatus;
  isActive?: boolean;
  isVisible?: boolean;
  createdBy?: string;
  ownerId?: string;
  uptime: number; // e.g. 97.54
  cpuUsage: number; // e.g. 63.4
  memoryUsage: number; // e.g. 76.0
  storageUsage: number; // e.g. 45.5
  techStack: string[];
  topology: ComponentTopology[];
}

export type ReservationMode = 'SHARED' | 'DISRUPTIVE';
export type AutoApprovalRule = 'ALL_REQUESTS' | 'PRIORITY_REQUESTS' | 'SHORT_REQUESTS';
export type ReservationPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface BookingAuditEntry {
  id: string;
  field: string;
  oldValue: string;
  newValue: string;
  changedBy: string;
  changedAt: string;
  comments?: string;
  stepOrder?: number;
  status?: string;
}

export interface Booking {
  id: string;
  environmentId: string;
  environmentName: string;
  businessUnit: string; // REQUIRED BY USER
  project?: string;     // OPTIONAL
  application?: string; // OPTIONAL
  purpose: string;
  team: string;
  requestedBy: string;
  priority?: ReservationPriority;
  autoApprovalEnabled?: boolean;
  autoApprovalRule?: AutoApprovalRule | null;
  startDate: string; // YYYY-MM-DDTHH:mm:ss (Includes Date, Hours, Minutes, Seconds)
  endDate: string;   // YYYY-MM-DDTHH:mm:ss (Includes Date, Hours, Minutes, Seconds)
  status: 'CONFIRMED' | 'APPROVED' | 'CONFLICT' | 'PENDING' | 'CANCELLED' | 'REJECTED' | 'AUTO_REJECTED';
  reservationMode?: ReservationMode; // 'SHARED' | 'DISRUPTIVE' (Default 'SHARED')
  workflowId?: string;
  currentWorkflowOrder?: number;
  currentApproverId?: string;
  currentApproverName?: string;
  rejectionReason?: string;
  rejectedAt?: string;
  rejectionType?: 'MANUAL' | 'AUTO';
  auditHistory?: BookingAuditEntry[];
  isVisible?: boolean;
  createdBy?: string;
  ownerId?: string;
  assignedUserId?: string;
}

export type ReleaseRisk = 'LOW RISK' | 'MEDIUM RISK' | 'HIGH RISK';
export type ReleaseStatus = 'SCHEDULED' | 'IN_PROGRESS' | 'DEPLOYED';

export interface Release {
  id: string;
  name: string;
  version: string;
  environmentId: string;
  environmentName: string;
  lead: string;
  changeRef: string;
  scheduledDate: string; // YYYY-MM-DDTHH:mm:ss (Includes Date, Hours, Minutes, Seconds)
  risk: ReleaseRisk;
  status: ReleaseStatus;
  isVisible?: boolean;
  createdBy?: string;
  leadId?: string;
}

export type IncidentSeverity = 'SEV1' | 'SEV2' | 'SEV3' | 'SEV4';
export type IncidentStatus = 'OPEN' | 'INVESTIGATING' | 'RESOLVED';

export interface Incident {
  id: string; // Ticket e.g. INC-88252
  title: string;
  severity: IncidentSeverity;
  environmentId: string;
  environmentName: string;
  assignee: string;
  status: IncidentStatus;
  openedAt: string; // ISO datetime string with HH:mm:ss
  description?: string;
  isVisible?: boolean;
  createdBy?: string;
  assigneeId?: string;
}

export interface Runbook {
  id: string;
  name: string;
  category: string;
  estimatedTimeMinutes: number;
  lastExecuted: string;
  targetEnvironmentId?: string;
  steps: string[];
}

export interface OverviewMetrics {
  totalEnvironments: number;
  healthyEnvironments: number;
  activeBookings: number;
  utilizationRate: number;
  openIncidents: number;
  downEnvironmentsCount: number;
  upcomingReleases: number;
  trackedReleasesCount: number;
  cpuAverage: number;
  memoryAverage: number;
  storageAverage: number;
}

export interface EmailNotification {
  id: string;
  bookingId: string;
  notificationType: string;
  stepOrder?: number;
  recipientTo: string;
  recipientCc?: string;
  subject: string;
  body: string;
  status: 'PENDING' | 'SENT' | 'FAILED';
  sentAt?: string;
  errorMessage?: string;
  retryCount: number;
  createdAt: string;
}
