export type ProvisioningStatus =
  | 'DRAFT'
  | 'VALIDATING'
  | 'VALIDATED'
  | 'PENDING_APPROVAL'
  | 'APPROVED'
  | 'QUEUED'
  | 'PROVISIONING'
  | 'CONFIGURING'
  | 'HEALTH_CHECK'
  | 'READY'
  | 'PARTIALLY_READY'
  | 'FAILED'
  | 'ROLLBACK'
  | 'DECOMMISSIONING'
  | 'DECOMMISSIONED'
  | 'CANCELLED';

export type StepStatus =
  | 'PENDING'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'FAILED'
  | 'SKIPPED'
  | 'ROLLED_BACK';

export type StepCategory =
  | 'INFRASTRUCTURE'
  | 'NETWORK'
  | 'STORAGE'
  | 'SOFTWARE'
  | 'CONFIGURATION'
  | 'DEPLOYMENT'
  | 'HEALTH_CHECK'
  | 'TEARDOWN';

export type ProvisioningMode = 'ON_DEMAND' | 'SCHEDULED' | 'TEMPLATE_BASED';

export type ComputeType = 'VM' | 'CONTAINER' | 'KUBERNETES' | 'BARE_METAL';

export interface SoftwareComponent {
  name: string;
  version: string;
  vendor?: string;
  required?: boolean;
  category?: string;
  configuration?: Record<string, any>;
}

export interface EnvironmentVariable {
  key: string;
  value: string;
  isSecret?: boolean;
  description?: string;
}

export interface SecretReference {
  key: string;
  reference: string;
  description?: string;
}

export interface DependencyItem {
  id?: string;
  name: string;
  type: 'DATABASE' | 'EXTERNAL_API' | 'MESSAGE_QUEUE' | 'SERVICE' | 'MIDDLEWARE';
  endpoint?: string;
  required: boolean;
  status?: 'RESOLVED' | 'PROVISIONED' | 'EXISTING' | 'UNREACHABLE';
  healthStatus?: 'HEALTHY' | 'DEGRADED' | 'DOWN' | 'UNKNOWN';
  details?: Record<string, any>;
}

export interface PreflightCheckItem {
  check: string;
  category: string;
  status: 'AVAILABLE' | 'VALID' | 'WARNING' | 'BLOCKING_ERROR';
  message: string;
  details?: Record<string, any>;
}

export interface PreflightValidationReport {
  overall_status: 'PASSED' | 'WARNING' | 'BLOCKED';
  has_blocking_errors: boolean;
  validation_timestamp: string;
  validations: PreflightCheckItem[];
}

export interface ProvisioningTemplate {
  id: string;
  name: string;
  description?: string;
  environment_type: string;
  business_unit?: string;
  project_name?: string;
  compute_type: ComputeType;
  cpu_cores: number;
  ram_gb: number;
  storage_gb: number;
  os_disk_gb: number;
  data_disk_gb: number;
  software_stack: SoftwareComponent[];
  network_config: {
    vlan?: string;
    subnet?: string;
    load_balancer?: boolean;
    firewall_profile?: string;
    [key: string]: any;
  };
  env_vars: EnvironmentVariable[];
  secrets_references: SecretReference[];
  health_check_config: {
    ping?: boolean;
    ports?: number[];
    endpoint?: string;
    [key: string]: any;
  };
  estimated_duration_min: number;
  is_active: boolean;
  tags: string[];
  created_at?: string;
  updated_at?: string;
}

export interface ProvisioningStepItem {
  id: string;
  request_id: string;
  step_order: number;
  step_key: string;
  step_name: string;
  category: StepCategory;
  provider_type: string;
  status: StepStatus;
  estimated_duration_sec: number;
  actual_duration_sec: number;
  started_at?: string | null;
  completed_at?: string | null;
  error_message?: string | null;
  retry_count: number;
  max_retries: number;
  parameters: Record<string, any>;
  execution_output: Record<string, any>;
  rollback_supported: boolean;
  rollback_status: string;
}

export interface ProvisioningResourceItem {
  id: string;
  request_id: string;
  resource_type: string;
  resource_name: string;
  resource_id: string;
  provider: string;
  status: string;
  configuration: Record<string, any>;
  allocated_at: string;
  released_at?: string | null;
}

export interface ProvisioningLogItem {
  id: string;
  request_id: string;
  step_id?: string | null;
  step_key?: string | null;
  log_level: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS' | 'DEBUG';
  message: string;
  source: string;
  details: Record<string, any>;
  timestamp: string;
}

export interface ProvisioningApprovalItem {
  id: string;
  request_id: string;
  approver_role: string;
  approver_user?: string | null;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'AUTO_APPROVED';
  comments?: string | null;
  auto_approved: boolean;
  decision_reason?: string | null;
  approved_at?: string | null;
}

export interface ProvisioningAuditItem {
  id: string;
  request_id: string;
  action: string;
  performed_by: string;
  old_status?: string | null;
  new_status?: string | null;
  details: Record<string, any>;
  ip_address?: string | null;
  timestamp: string;
}

export interface ProvisioningRequest {
  id: string;
  request_number: string;
  environment_name: string;
  environment_type: string;
  business_unit: string;
  project_name: string;
  application_name: string;
  component_name?: string | null;
  environment_owner: string;
  requested_by: string;
  description?: string | null;
  provisioning_mode: ProvisioningMode;
  template_id?: string | null;
  scheduled_start?: string | null;
  scheduled_end?: string | null;
  execution_started_at?: string | null;
  execution_completed_at?: string | null;
  status: ProvisioningStatus;
  progress_percentage: number;
  current_step_index: number;
  total_steps: number;
  health_status: string;
  failure_reason?: string | null;
  failure_step_id?: string | null;
  retry_count: number;
  environment_id?: string | null;
  booking_id?: string | null;
  incident_id?: string | null;
  resource_specs: {
    compute_type?: ComputeType;
    cpu_cores?: number;
    ram_gb?: number;
    storage_gb?: number;
    os_disk_gb?: number;
    data_disk_gb?: number;
    region?: string;
    network?: {
      vlan?: string;
      subnet?: string;
      load_balancer?: boolean;
      firewall_profile?: string;
    };
    [key: string]: any;
  };
  software_stack: SoftwareComponent[];
  configuration_payload: {
    env_vars?: EnvironmentVariable[];
    secrets_references?: SecretReference[];
    application_properties?: Record<string, any>;
    service_ports?: number[];
    urls?: Record<string, string>;
    feature_flags?: Record<string, boolean>;
    [key: string]: any;
  };
  dependency_graph: DependencyItem[];
  validation_results?: PreflightValidationReport;
  health_check_results?: any[];
  custom_tags?: Record<string, any>;
  steps?: ProvisioningStepItem[];
  resources?: ProvisioningResourceItem[];
  dependencies?: DependencyItem[];
  approvals?: ProvisioningApprovalItem[];
  audits?: ProvisioningAuditItem[];
  created_at: string;
  updated_at: string;
}

export interface ProvisioningDashboardKPIs {
  total_requests: number;
  in_progress: number;
  ready: number;
  failed: number;
  pending_approval: number;
  decommissioning: number;
}
