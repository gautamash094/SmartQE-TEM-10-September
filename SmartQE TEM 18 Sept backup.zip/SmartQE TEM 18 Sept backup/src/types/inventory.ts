export type AssetType = 
  | 'SERVER' 
  | 'DATABASE' 
  | 'CLOUD_RESOURCE' 
  | 'NETWORK_COMPONENT' 
  | 'STORAGE' 
  | 'SOFTWARE';

export type InfrastructureType = 'ON_PREMISES' | 'CLOUD' | 'HYBRID';

export type CloudProvider = 
  | 'AWS' 
  | 'Azure' 
  | 'GCP' 
  | 'OCI' 
  | 'Alibaba Cloud' 
  | 'On-Premises' 
  | 'Other';

export type AssetStatus = 
  | 'ACTIVE' 
  | 'INACTIVE' 
  | 'MAINTENANCE' 
  | 'PROVISIONING' 
  | 'RETIRED' 
  | 'DECOMMISSIONED';

export interface InstalledSoftwareItem {
  id?: string;
  name: string;
  version: string;
  port?: string;
  status?: string;
  path?: string;
}

export interface AssetAuditLog {
  id: string;
  assetId?: string;
  action: 'CREATE' | 'UPDATE' | 'STATUS_CHANGE' | 'LINK_ENV' | 'UNLINK_ENV' | 'RETIRE';
  changedBy: string;
  changedAt: string;
  fieldName?: string;
  oldValue?: string;
  newValue?: string;
  notes?: string;
}

export interface InventoryAsset {
  id: string;
  assetId: string; // e.g. AST-1001
  name: string;
  assetType: AssetType;
  infrastructureType: InfrastructureType;
  cloudProvider: CloudProvider;

  // Enterprise Hierarchy
  businessUnit: string;
  accountName: string; // or Project
  environmentId?: string;
  environmentName?: string;
  environmentType?: string;
  applicationName?: string;

  // Technical Specifications & Network
  ipAddress?: string;
  hostname?: string;
  operatingSystem?: string;
  osVersion?: string;
  runtimeStack?: string;
  cpuCores?: number;
  ramGb?: number;
  storageGb?: number;

  // Cloud & Datacenter Location
  region?: string;
  availabilityZone?: string;
  datacenter?: string;
  rackUnit?: string;
  instanceId?: string;
  instanceType?: string;
  vpcSubnet?: string;

  // Installed Software
  installedSoftware: InstalledSoftwareItem[];

  // Lifecycle & Ownership
  status: AssetStatus;
  ownerTeam: string;
  responsiblePerson?: string;
  costCenter?: string;
  endOfLifeDate?: string; // YYYY-MM-DD
  notes?: string;
  tags?: Record<string, any>;

  // Audit
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
  auditLogs?: AssetAuditLog[];
}

export interface InventoryMetrics {
  totalAssets: number;
  totalEnvironments: number;
  totalServers: number;
  totalDatabases: number;
  totalCloudResources: number;
  totalNetworkComponents: number;
  totalSoftware: number;
  cloudAssetsCount: number;
  onPremAssetsCount: number;
  hybridAssetsCount: number;
  activeAssetsCount: number;
  inactiveAssetsCount: number;
  maintenanceAssetsCount: number;
  retiredAssetsCount: number;
  approachingEolCount: number;
  assetsByBu: Record<string, number>;
  assetsByProvider: Record<string, number>;
  assetsByStatus: Record<string, number>;
  assetsByType: Record<string, number>;
  assetsByOs: Record<string, number>;
}

export interface InventoryFilterState {
  search: string;
  businessUnit: string;
  accountName: string;
  environment: string;
  environmentType: string;
  assetType: string;
  infrastructureType: string;
  cloudProvider: string;
  region: string;
  status: string;
  operatingSystem: string;
  ownerTeam: string;
}

export interface SavedFilterPreset {
  id: string;
  name: string;
  icon?: string;
  filters: Partial<InventoryFilterState>;
}
