export type IntegrationProvider = 'SERVICENOW' | 'AZURE_DEVOPS' | 'JENKINS';

export type IntegrationType = 'ITSM' | 'CICD';

export type IntegrationConnectionStatus = 'CONNECTED' | 'DISCONNECTED' | 'DEGRADED' | 'TESTING' | 'UNCONFIGURED';

export type SyncDirection = 'BI_DIRECTIONAL' | 'INBOUND_ONLY' | 'OUTBOUND_ONLY';

export type AuthType = 'OAUTH2' | 'API_TOKEN' | 'BASIC_AUTH' | 'WEBHOOK_SECRET';

export type ConflictPolicy = 'LAST_WRITE_WINS' | 'TEM_AUTHORITATIVE' | 'EXTERNAL_AUTHORITATIVE' | 'ALERT_ADMIN';

export interface FieldMappingRule {
  id: string;
  temField: string;
  externalField: string;
  direction: SyncDirection;
  isRequired?: boolean;
  defaultValue?: string;
}

export interface StatusMappingRule {
  id: string;
  temStatus: string;
  externalStatus: string;
}

export interface EnvironmentMappingRule {
  id: string;
  externalEnvIdentifier: string;
  temEnvironmentId: string;
  temEnvironmentName: string;
}

export interface IntegrationConfig {
  id: string;
  name: string;
  provider: IntegrationProvider;
  type: IntegrationType;
  enabled: boolean;
  connectionStatus: IntegrationConnectionStatus;
  syncDirection: SyncDirection;
  baseUrl: string;
  authType: AuthType;
  apiTokenOrSecret?: string;
  usernameOrClient?: string;
  webhookUrl: string;
  lastSuccessfulSync?: string;
  lastFailedSync?: string;
  syncIntervalMinutes: number;
  conflictPolicy: ConflictPolicy;
  eventsEnabled: {
    incidents?: boolean;
    changes?: boolean;
    pipelines?: boolean;
    deployments?: boolean;
    testExecutions?: boolean;
  };
  fieldMappings: FieldMappingRule[];
  statusMappings: StatusMappingRule[];
  environmentMappings: EnvironmentMappingRule[];
  retryAttemptsMax: number;
}

export type IntegrationLogStatus = 'SUCCESS' | 'FAILED' | 'PENDING_RETRY' | 'IGNORED';

export interface IntegrationLogEntry {
  id: string;
  timestamp: string;
  provider: IntegrationProvider;
  eventType: string; // e.g. 'INCIDENT_SYNC', 'PIPELINE_STARTED', 'DEPLOYMENT_SUCCESS'
  direction: 'TEM_TO_EXTERNAL' | 'EXTERNAL_TO_TEM' | 'BI_DIRECTIONAL';
  temEntityId?: string;
  externalEntityId?: string;
  status: IntegrationLogStatus;
  message: string;
  payloadSnippet?: string;
  retryCount: number;
  maxRetries: number;
  errorDetail?: string;
}

export interface CICDPipelineEventPayload {
  provider: 'AZURE_DEVOPS' | 'JENKINS';
  pipelineName: string;
  runId: string;
  buildNumber: string;
  eventType: 'PIPELINE_QUEUED' | 'PIPELINE_STARTED' | 'DEPLOYMENT_STARTED' | 'DEPLOYMENT_SUCCESS' | 'DEPLOYMENT_FAILED' | 'TEST_STARTED' | 'TEST_COMPLETED' | 'PIPELINE_COMPLETED' | 'PIPELINE_CANCELED';
  targetEnvironmentIdentifier: string;
  targetEnvironmentId?: string;
  version?: string;
  commitRef?: string;
  triggeredBy?: string;
  durationSeconds?: number;
  timestamp: string;
}

export interface ITSMTicketSyncPayload {
  provider: 'SERVICENOW';
  ticketType: 'INCIDENT' | 'CHANGE_REQUEST';
  externalId: string;
  externalKeyOrNumber: string;
  title: string;
  description?: string;
  priority: string;
  status: string;
  assignee?: string;
  environmentIdentifier?: string;
  temIncidentId?: string;
  comments?: string[];
  externalUrl: string;
  updatedAt: string;
}

export interface IntegrationHealthSummary {
  totalIntegrations: number;
  activeIntegrations: number;
  connectedCount: number;
  failedCount: number;
  events24hCount: number;
  successRate24h: number;
  lastGlobalSync: string;
}
