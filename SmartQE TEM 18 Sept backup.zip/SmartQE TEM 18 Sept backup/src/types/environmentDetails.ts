export type InfrastructureType = 'ON_PREMISES' | 'CLOUD';

export type CloudProvider = 'AWS' | 'Azure' | 'GCP' | 'OCI' | 'Alibaba Cloud' | 'DigitalOcean' | 'Other';

export type ServerType = 
  | 'Application Server'
  | 'Database Server'
  | 'Web Server'
  | 'Cache Server'
  | 'Load Balancer / Proxy'
  | 'Message Broker'
  | 'API Gateway';

export type ServerStatus = 'ONLINE' | 'MAINTENANCE' | 'OFFLINE' | 'PROVISIONING';

export type SoftwareStatus = 'ACTIVE' | 'INSTALLED' | 'UPGRADING' | 'DEPRECATED';

export type EnvironmentType = 
  | 'Development'
  | 'QA / Testing'
  | 'UAT / Staging'
  | 'Production'
  | 'Performance / Stress'
  | 'Disaster Recovery (DR)'
  | 'Sandbox';

export type EnvironmentStatus = 'HEALTHY' | 'DEGRADED' | 'MAINTENANCE' | 'DOWN';

export interface ServerDetail {
  id: string;
  name: string;
  hostIp: string;
  serverType: ServerType;
  operatingSystem: string;
  cpuCores: number;
  ramGb: number;
  storageGb: number;
  status: ServerStatus;
  isActive?: boolean;
  infrastructureType: InfrastructureType;
  
  // On-Premises Specific
  datacenter?: string;
  rackUnit?: string;

  // Cloud Specific
  cloudProvider?: CloudProvider;
  instanceId?: string;
  instanceType?: string;
  region?: string;
  availabilityZone?: string;
  publicIp?: string;
  privateIp?: string;
  vpcSubnet?: string;

  // Associations & Meta
  installedSoftwareIds?: string[];
  description?: string;
  environmentName?: string;
  createdAt?: string;
  createdBy?: string;
  ownerId?: string;
}

export interface SoftwareDetail {
  id: string;
  name: string;
  version: string;
  installPath: string;
  port: string;
  serviceName: string;
  runtimeStack: string;
  vendor?: string;
  status: SoftwareStatus;
  isActive?: boolean;
  description?: string;
  createdAt?: string;
  createdBy?: string;
  ownerId?: string;
}

export interface EnvironmentProfile {
  id: string;
  name: string;
  type: EnvironmentType;
  description: string;
  status: EnvironmentStatus;
  isActive?: boolean;
  ownerTeam: string;
  networkZone: string;
  serverIds: string[]; // Linked servers
  softwareIds: string[]; // Linked software
  updatedAt: string;
  createdBy?: string;
  ownerId?: string;
}
