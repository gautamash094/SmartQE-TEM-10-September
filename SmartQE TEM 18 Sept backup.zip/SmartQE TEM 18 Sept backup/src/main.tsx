import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import './index.css';

// Globally disable browser autocomplete/autofill popups on all inputs and forms across the application
document.addEventListener('focusin', (e) => {
  const target = e.target as HTMLElement;
  if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
    const input = target as HTMLInputElement;
    if (input.type !== 'checkbox' && input.type !== 'radio') {
      if (!input.getAttribute('autocomplete') || input.getAttribute('autocomplete') === 'on') {
        input.setAttribute('autocomplete', 'off');
      }
      input.setAttribute('data-lpignore', 'true');
      input.setAttribute('data-form-type', 'other');
    }
  }
}, true);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

