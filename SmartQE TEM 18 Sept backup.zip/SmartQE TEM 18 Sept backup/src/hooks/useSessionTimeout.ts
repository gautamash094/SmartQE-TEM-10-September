import { useState, useEffect, useRef, useCallback } from 'react';
import { authService } from '../services/authService';

const IDLE_TIMEOUT_SECONDS = 20 * 60; // 20 minutes (1200 seconds)
const WARNING_BEFORE_EXPIRY_SECONDS = 2 * 60; // 2 minutes (120 seconds)
const WARNING_TRIGGER_SECONDS = IDLE_TIMEOUT_SECONDS - WARNING_BEFORE_EXPIRY_SECONDS; // 18 minutes (1080 seconds)
const ACTIVITY_THROTTLE_MS = 15000; // 15 seconds throttle for user events

interface UseSessionTimeoutProps {
  isAuthenticated: boolean;
  onLogout: () => Promise<void>;
  onSessionExpired: () => void;
}

export const useSessionTimeout = ({
  isAuthenticated,
  onLogout,
  onSessionExpired,
}: UseSessionTimeoutProps) => {
  const [isWarningOpen, setIsWarningOpen] = useState<boolean>(false);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(WARNING_BEFORE_EXPIRY_SECONDS);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const lastActivityRef = useRef<number>(Date.now());
  const lastThrottleSyncRef = useRef<number>(0);
  const isExpiringRef = useRef<boolean>(false);

  // Record user interaction
  const recordUserActivity = useCallback(() => {
    // If warning is open, require explicit button click ("Continue Session")
    if (isWarningOpen || isExpiringRef.current) return;

    const now = Date.now();
    lastActivityRef.current = now;

    // Throttled background sync if needed
    if (now - lastThrottleSyncRef.current > ACTIVITY_THROTTLE_MS) {
      lastThrottleSyncRef.current = now;
    }
  }, [isWarningOpen]);

  // Handle explicit session extension from warning modal
  const handleContinueSession = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const refreshed = await authService.refreshSession();
      if (refreshed) {
        lastActivityRef.current = Date.now();
        setIsWarningOpen(false);
        setRemainingSeconds(WARNING_BEFORE_EXPIRY_SECONDS);
      } else {
        // If backend reported expired, force logout
        onSessionExpired();
      }
    } catch {
      onSessionExpired();
    } finally {
      setIsRefreshing(false);
    }
  }, [onSessionExpired]);

  // Handle explicit logout
  const handleExplicitLogout = useCallback(async () => {
    setIsWarningOpen(false);
    await onLogout();
  }, [onLogout]);

  // Global listeners for user interaction
  useEffect(() => {
    if (!isAuthenticated) return;

    lastActivityRef.current = Date.now();
    isExpiringRef.current = false;

    const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'click'];
    const handleEvent = () => recordUserActivity();

    events.forEach((evt) => window.addEventListener(evt, handleEvent, { passive: true }));

    // Global session_expired handler (triggered by 401s from apiClient)
    const handleGlobalSessionExpired = () => {
      if (!isExpiringRef.current) {
        isExpiringRef.current = true;
        setIsWarningOpen(false);
        onSessionExpired();
      }
    };
    window.addEventListener('session_expired', handleGlobalSessionExpired);

    return () => {
      events.forEach((evt) => window.removeEventListener(evt, handleEvent));
      window.removeEventListener('session_expired', handleGlobalSessionExpired);
    };
  }, [isAuthenticated, recordUserActivity, onSessionExpired]);

  // Inactivity Tick Interval
  useEffect(() => {
    if (!isAuthenticated) {
      setIsWarningOpen(false);
      return;
    }

    const interval = setInterval(() => {
      if (!isAuthenticated || isExpiringRef.current) return;

      const idleSeconds = Math.floor((Date.now() - lastActivityRef.current) / 1000);

      // Check 20-minute expiration
      if (idleSeconds >= IDLE_TIMEOUT_SECONDS) {
        isExpiringRef.current = true;
        setIsWarningOpen(false);
        onSessionExpired();
        return;
      }

      // Check 18-minute warning trigger
      if (idleSeconds >= WARNING_TRIGGER_SECONDS) {
        const remaining = Math.max(0, IDLE_TIMEOUT_SECONDS - idleSeconds);
        setRemainingSeconds(remaining);
        setIsWarningOpen(true);
      } else {
        setIsWarningOpen(false);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isAuthenticated, onSessionExpired]);

  return {
    isWarningOpen,
    remainingSeconds,
    isRefreshing,
    handleContinueSession,
    handleExplicitLogout,
  };
};
