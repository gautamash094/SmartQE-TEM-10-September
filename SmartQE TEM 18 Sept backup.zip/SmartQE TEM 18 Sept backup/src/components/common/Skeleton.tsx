﻿import React from 'react';

interface SkeletonProps {
  className?: string;
  variant?: 'rectangular' | 'circular' | 'rounded';
  animate?: boolean;
  style?: React.CSSProperties;
}

export const Skeleton: React.FC<SkeletonProps> = ({
  className = '',
  variant = 'rounded',
  animate = true,
  style,
}) => {
  const variantClass =
    variant === 'circular'
      ? 'rounded-full'
      : variant === 'rounded'
      ? 'rounded-md'
      : 'rounded-none';

  return (
    <div
      style={style}
      className={`bg-slate-200 dark:bg-slate-800/70 border border-slate-300/60 dark:border-slate-700/30 ${variantClass} ${
        animate ? 'animate-pulse' : ''
      } ${className}`}
    />
  );
};

export const TableSkeleton: React.FC<{
  rows?: number;
  columns?: number;
  className?: string;
}> = ({ rows = 5, columns = 5, className = '' }) => {
  return (
    <div className={`w-full overflow-hidden border border-slate-200 dark:border-slate-800/80 rounded-lg bg-white dark:bg-[#0c1322] ${className}`}>
      {/* Header Skeleton */}
      <div className="flex items-center gap-4 p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#121b2d]/80">
        {Array.from({ length: columns }).map((_, idx) => (
          <Skeleton
            key={`th-${idx}`}
            className={`h-4 ${idx === 0 ? 'w-1/4' : 'flex-1'}`}
          />
        ))}
      </div>

      {/* Rows Skeleton */}
      <div className="divide-y divide-slate-200 dark:divide-slate-800/60">
        {Array.from({ length: rows }).map((_, rIdx) => (
          <div
            key={`tr-${rIdx}`}
            className="flex items-center gap-4 p-4 hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-colors"
          >
            {Array.from({ length: columns }).map((_, cIdx) => (
              <Skeleton
                key={`td-${rIdx}-${cIdx}`}
                className={`h-4 ${
                  cIdx === 0 ? 'w-1/4 h-5' : cIdx === columns - 1 ? 'w-16 ml-auto' : 'flex-1'
                }`}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export const CardSkeleton: React.FC<{
  count?: number;
  className?: string;
}> = ({ count = 4, className = 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4' }) => {
  return (
    <div className={className}>
      {Array.from({ length: count }).map((_, idx) => (
        <div
          key={`card-skel-${idx}`}
          className="bg-white dark:bg-[#121b2d] border border-slate-200 dark:border-slate-800 rounded-lg p-5 space-y-3 shadow-sm dark:shadow-md"
        >
          <div className="flex justify-between items-center">
            <Skeleton className="h-3.5 w-24" />
            <Skeleton variant="circular" className="w-7 h-7" />
          </div>
          <Skeleton className="h-8 w-20" />
          <Skeleton className="h-3 w-32" />
        </div>
      ))}
    </div>
  );
};

export const ChartSkeleton: React.FC<{
  height?: string | number;
  className?: string;
}> = ({ height = 'h-64', className = '' }) => {
  const isCustomPixel = typeof height === 'number';
  const heightClass = typeof height === 'string' && height.startsWith('h-') ? height : '';
  const heightStyle = isCustomPixel ? { height: `${height}px` } : typeof height === 'string' && !height.startsWith('h-') ? { height } : undefined;

  return (
    <div
      className={`bg-white dark:bg-[#121b2d] border border-slate-200 dark:border-slate-800 rounded-lg p-5 space-y-4 shadow-sm dark:shadow-md ${className}`}
    >
      <div className="flex justify-between items-center">
        <Skeleton className="h-4 w-40" />
        <Skeleton className="h-4 w-24" />
      </div>
      <div className={`w-full ${heightClass} flex items-end gap-2 pt-6`} style={heightStyle}>
        {Array.from({ length: 12 }).map((_, idx) => {
          const hPercent = [40, 65, 30, 85, 55, 90, 45, 70, 60, 95, 50, 75][idx % 12];
          return (
            <div key={`bar-${idx}`} className="flex-1 h-full flex flex-col justify-end">
              <Skeleton className="w-full" style={{ height: `${hPercent}%` } as React.CSSProperties} />
            </div>
          );
        })}
      </div>
    </div>
  );
};