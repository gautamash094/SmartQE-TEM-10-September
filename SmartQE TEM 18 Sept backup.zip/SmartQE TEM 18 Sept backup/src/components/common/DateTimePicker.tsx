﻿import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { createPortal } from 'react-dom';
import {
  Calendar as CalendarIcon,
  Clock,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  Check,
  AlertCircle
} from 'lucide-react';

export interface DateTimePickerProps {
  value: string; // ISO or YYYY-MM-DDTHH:mm:ss or YYYY-MM-DD HH:mm:ss
  onChange: (value: string) => void;
  label?: string;
  subLabel?: string;
  required?: boolean;
  disabled?: boolean;
  error?: string;
  minDateTime?: string;
  maxDateTime?: string;
  placeholder?: string;
  showSeconds?: boolean;
  className?: string;
  id?: string;
  name?: string;
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const DAYS_OF_WEEK = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

const pad = (n: number) => n.toString().padStart(2, '0');

const parseDateTime = (val: string) => {
  if (!val) {
    const now = new Date();
    return {
      year: now.getFullYear(),
      month: now.getMonth(),
      day: now.getDate(),
      hours: 0,
      minutes: 0,
      seconds: 0,
      isValid: false
    };
  }

  const clean = val.replace('T', ' ');
  const parts = clean.split(' ');
  const datePart = parts[0];
  const timePart = parts[1] || '00:00:00';

  const [y, m, d] = datePart.split('-').map(Number);
  const [hh, mm, ss] = timePart.split(':').map(Number);

  const year = isNaN(y) ? new Date().getFullYear() : y;
  const month = isNaN(m) ? new Date().getMonth() : m - 1;
  const day = isNaN(d) ? new Date().getDate() : d;
  const hours = isNaN(hh) ? 0 : hh;
  const minutes = isNaN(mm) ? 0 : mm;
  const seconds = isNaN(ss) ? 0 : ss;

  return {
    year,
    month,
    day,
    hours,
    minutes,
    seconds,
    isValid: true
  };
};

const formatToStandard = (
  year: number,
  month: number,
  day: number,
  hours: number,
  minutes: number,
  seconds: number,
  showSeconds: boolean = true
) => {
  const yyyy = year;
  const MM = pad(month + 1);
  const dd = pad(day);
  const hh = pad(hours);
  const mm = pad(minutes);
  const ss = pad(seconds);
  return showSeconds
    ? `${yyyy}-${MM}-${dd}T${hh}:${mm}:${ss}`
    : `${yyyy}-${MM}-${dd}T${hh}:${mm}`;
};

const formatForDisplay = (val: string, showSeconds: boolean = true) => {
  if (!val) return '';
  const parsed = parseDateTime(val);
  if (!parsed.isValid) return val;
  const MM = pad(parsed.month + 1);
  const dd = pad(parsed.day);
  const hh = pad(parsed.hours);
  const mm = pad(parsed.minutes);
  const ss = pad(parsed.seconds);
  return showSeconds
    ? `${parsed.year}-${MM}-${dd} ${hh}:${mm}:${ss}`
    : `${parsed.year}-${MM}-${dd} ${hh}:${mm}`;
};

export const DateTimePicker: React.FC<DateTimePickerProps> = ({
  value,
  onChange,
  label,
  subLabel = 'HH:MM:SS',
  required = false,
  disabled = false,
  error,
  placeholder = 'Select date & time...',
  showSeconds = true,
  className = '',
  id,
  name
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLDivElement>(null);

  const [position, setPosition] = useState<{ top: number; left: number }>({ top: 0, left: 0 });

  const parsedValue = useMemo(() => parseDateTime(value), [value]);

  const [draftYear, setDraftYear] = useState<number>(parsedValue.year);
  const [draftMonth, setDraftMonth] = useState<number>(parsedValue.month);
  const [draftDay, setDraftDay] = useState<number>(parsedValue.day);
  const [draftHours, setDraftHours] = useState<number>(parsedValue.hours);
  const [draftMinutes, setDraftMinutes] = useState<number>(parsedValue.minutes);
  const [draftSeconds, setDraftSeconds] = useState<number>(parsedValue.seconds);

  useEffect(() => {
    const p = parseDateTime(value);
    setDraftYear(p.year);
    setDraftMonth(p.month);
    setDraftDay(p.day);
    setDraftHours(p.hours);
    setDraftMinutes(p.minutes);
    setDraftSeconds(p.seconds);
  }, [value, isOpen]);

  const updatePosition = useCallback(() => {
    if (!triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    const popoverWidth = 340;
    const popoverHeight = 420;

    let left = rect.left;
    if (left + popoverWidth > window.innerWidth - 16) {
      left = Math.max(16, window.innerWidth - popoverWidth - 16);
    }
    if (left < 16) left = 16;

    const spaceBelow = window.innerHeight - rect.bottom;
    const spaceAbove = rect.top;

    let top = rect.bottom + 6;

    if (spaceBelow < popoverHeight && spaceAbove > spaceBelow) {
      top = Math.max(16, rect.top - popoverHeight - 6);
    } else if (top + popoverHeight > window.innerHeight - 16) {
      top = Math.max(16, window.innerHeight - popoverHeight - 16);
    }

    setPosition({ top, left });
  }, []);

  useEffect(() => {
    if (isOpen) {
      updatePosition();
      window.addEventListener('resize', updatePosition);
      window.addEventListener('scroll', updatePosition, true);
    }
    return () => {
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', updatePosition, true);
    };
  }, [isOpen, updatePosition]);

  const calendarDays = useMemo(() => {
    const firstDayIndex = new Date(draftYear, draftMonth, 1).getDay();
    const daysInMonth = new Date(draftYear, draftMonth + 1, 0).getDate();
    const daysInPrevMonth = new Date(draftYear, draftMonth, 0).getDate();

    const days = [];

    for (let i = firstDayIndex - 1; i >= 0; i--) {
      days.push({
        day: daysInPrevMonth - i,
        month: draftMonth - 1,
        year: draftMonth === 0 ? draftYear - 1 : draftYear,
        isCurrentMonth: false
      });
    }

    for (let i = 1; i <= daysInMonth; i++) {
      days.push({
        day: i,
        month: draftMonth,
        year: draftYear,
        isCurrentMonth: true
      });
    }

    const remaining = (7 - (days.length % 7)) % 7;
    for (let i = 1; i <= remaining; i++) {
      days.push({
        day: i,
        month: draftMonth + 1,
        year: draftMonth === 11 ? draftYear + 1 : draftYear,
        isCurrentMonth: false
      });
    }

    return days;
  }, [draftYear, draftMonth]);

  const handlePrevMonth = () => {
    if (draftMonth === 0) {
      setDraftMonth(11);
      setDraftYear((y) => y - 1);
    } else {
      setDraftMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (draftMonth === 11) {
      setDraftMonth(0);
      setDraftYear((y) => y + 1);
    } else {
      setDraftMonth((m) => m + 1);
    }
  };

  const handleSelectDay = (dayObj: { day: number; month: number; year: number }) => {
    setDraftYear(dayObj.year);
    setDraftMonth(dayObj.month);
    setDraftDay(dayObj.day);
  };

  const handleApply = () => {
    const formatted = formatToStandard(
      draftYear,
      draftMonth,
      draftDay,
      draftHours,
      draftMinutes,
      draftSeconds,
      showSeconds
    );
    onChange(formatted);
    setIsOpen(false);
  };

  const handleCancel = () => {
    setIsOpen(false);
  };

  const isToday = (y: number, m: number, d: number) => {
    const today = new Date();
    return today.getFullYear() === y && today.getMonth() === m && today.getDate() === d;
  };

  const isSelected = (y: number, m: number, d: number) => {
    return draftYear === y && draftMonth === m && draftDay === d;
  };

  const displayDraftString = useMemo(() => {
    return `${draftYear}-${pad(draftMonth + 1)}-${pad(draftDay)} ${pad(draftHours)}:${pad(draftMinutes)}:${pad(draftSeconds)}`;
  }, [draftYear, draftMonth, draftDay, draftHours, draftMinutes, draftSeconds]);

  return (
    <div className={`relative ${className}`}>
      {/* Label */}
      {label && (
        <div className="flex items-center justify-between mb-1 font-mono">
          <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400">
            {label} {required && <span className="text-orange-500">*</span>}
          </label>
          {subLabel && (
            <span className="text-[9px] text-orange-500 dark:text-orange-400 font-bold">{subLabel}</span>
          )}
        </div>
      )}

      {/* Input Trigger */}
      <div
        ref={triggerRef}
        onClick={() => {
          if (!disabled) {
            updatePosition();
            setIsOpen(!isOpen);
          }
        }}
        className={`flex items-center justify-between w-full bg-white dark:bg-[#161f2e] border ${
          error
            ? 'border-red-500 focus-within:border-red-400 ring-1 ring-red-500/20'
            : isOpen
            ? 'border-orange-500 ring-2 ring-orange-500/20'
            : 'border-slate-300 dark:border-slate-700/90 hover:border-slate-400 dark:hover:border-slate-600'
        } rounded-lg px-3 py-2 text-xs font-mono text-slate-900 dark:text-white cursor-pointer transition-all shadow-sm ${
          disabled ? 'opacity-50 cursor-not-allowed bg-slate-100 dark:bg-slate-900' : ''
        }`}
      >
        <div className="flex items-center gap-2 overflow-hidden truncate">
          <CalendarIcon className="w-4 h-4 text-orange-500 dark:text-orange-400 shrink-0 drop-shadow-[0_0_8px_rgba(249,115,22,0.4)]" />
          <span className={value ? 'text-slate-900 dark:text-white font-bold' : 'text-slate-400 dark:text-slate-500'}>
            {value ? formatForDisplay(value, showSeconds) : placeholder}
          </span>
        </div>

        <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200 dark:border-slate-700/80 text-orange-500 dark:text-orange-400">
          <Clock className="w-3.5 h-3.5 hover:text-orange-600 dark:hover:text-orange-300 transition-colors" />
        </div>
      </div>

      <input autoComplete="off" data-lpignore="true"
        type="hidden"
        name={name}
        id={id}
        value={value || ''}
      />

      {error && (
        <div className="flex items-center gap-1 text-[11px] text-red-500 dark:text-red-400 mt-1 font-mono">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Popover */}
      {isOpen &&
        createPortal(
          <div className="fixed inset-0 z-[9999] pointer-events-none">
            <div
              className="fixed inset-0 pointer-events-auto bg-black/30 backdrop-blur-[1px]"
              onClick={() => setIsOpen(false)}
            />

            <div
              ref={popoverRef}
              style={{
                top: `${position.top}px`,
                left: `${position.left}px`
              }}
              className="fixed pointer-events-auto w-[340px] max-w-[95vw] bg-white dark:bg-[#0c121e] border-2 border-slate-200 dark:border-slate-700/90 rounded-2xl shadow-[0_25px_60px_rgba(0,0,0,0.25)] dark:shadow-[0_25px_60px_rgba(0,0,0,0.85)] p-4 font-mono text-slate-800 dark:text-slate-200 animate-in fade-in zoom-in-95 duration-150"
            >
              {/* Month/Year Header */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={handlePrevMonth}
                  className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
                  title="Previous Month"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    {MONTH_NAMES[draftMonth]} {draftYear}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleNextMonth}
                  className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
                  title="Next Month"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Days of Week */}
              <div className="grid grid-cols-7 gap-1 text-center mb-1">
                {DAYS_OF_WEEK.map((d) => (
                  <div key={d} className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase py-1">
                    {d}
                  </div>
                ))}
              </div>

              {/* Days Grid */}
              <div className="grid grid-cols-7 gap-1 text-center mb-3">
                {calendarDays.map((d, idx) => {
                  const selected = isSelected(d.year, d.month, d.day);
                  const today = isToday(d.year, d.month, d.day);

                  return (
                    <button
                      key={`${d.year}-${d.month}-${d.day}-${idx}`}
                      type="button"
                      onClick={() => handleSelectDay(d)}
                      className={`h-8 rounded-lg text-xs font-bold transition-all relative flex items-center justify-center ${
                        selected
                          ? 'bg-gradient-to-r from-orange-600 to-amber-500 text-white shadow-md shadow-orange-600/30 ring-2 ring-orange-400 scale-105 z-10'
                          : d.isCurrentMonth
                          ? 'text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-orange-600 dark:hover:text-orange-400'
                          : 'text-slate-400 dark:text-slate-600 hover:bg-slate-100/60 dark:hover:bg-slate-800/40 hover:text-slate-600 dark:hover:text-slate-400'
                      } ${today && !selected ? 'border border-cyan-500 text-cyan-600 dark:text-cyan-300 font-black' : ''}`}
                    >
                      <span>{d.day}</span>
                      {today && !selected && (
                        <span className="absolute bottom-1 w-1 h-1 rounded-full bg-cyan-500 dark:bg-cyan-400"></span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Time Section */}
              <div className="bg-slate-50 dark:bg-[#141c2c] border border-slate-200 dark:border-slate-800/90 rounded-xl p-3 mb-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
                    <Clock className="w-3.5 h-3.5 text-orange-500 dark:text-orange-400" />
                    <span className="text-[10px] font-bold uppercase tracking-wider">Time (HH:MM:SS)</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setDraftHours(0);
                      setDraftMinutes(0);
                      setDraftSeconds(0);
                    }}
                    className="text-[9px] text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300 font-bold hover:underline"
                    title="Set to 00:00:00"
                  >
                    Reset (00:00:00)
                  </button>
                </div>

                <div className="flex items-center justify-center gap-3 py-1">
                  {/* Hours */}
                  <div className="flex flex-col items-center">
                    <span className="text-[9px] text-slate-500 dark:text-slate-400 font-bold mb-1">HR (00-23)</span>
                    <button
                      type="button"
                      onClick={() => setDraftHours((h) => (h >= 23 ? 0 : h + 1))}
                      className="w-12 h-6 flex items-center justify-center rounded-t-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
                      title="Increase Hour"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      inputMode="numeric"
                      value={pad(draftHours)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value.replace(/\D/g, ''), 10);
                        if (isNaN(val)) setDraftHours(0);
                        else setDraftHours(Math.max(0, Math.min(23, val)));
                      }}
                      className="w-12 h-8 bg-white dark:bg-[#090d15] border-y border-slate-300 dark:border-slate-700/80 text-center text-sm font-bold text-slate-900 dark:text-white font-mono focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setDraftHours((h) => (h <= 0 ? 23 : h - 1))}
                      className="w-12 h-6 flex items-center justify-center rounded-b-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
                      title="Decrease Hour"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <span className="text-slate-400 dark:text-slate-500 font-bold text-lg pt-4">:</span>

                  {/* Minutes */}
                  <div className="flex flex-col items-center">
                    <span className="text-[9px] text-slate-500 dark:text-slate-400 font-bold mb-1">MIN (00-59)</span>
                    <button
                      type="button"
                      onClick={() => setDraftMinutes((m) => (m >= 59 ? 0 : m + 1))}
                      className="w-12 h-6 flex items-center justify-center rounded-t-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
                      title="Increase Minute"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      inputMode="numeric"
                      value={pad(draftMinutes)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value.replace(/\D/g, ''), 10);
                        if (isNaN(val)) setDraftMinutes(0);
                        else setDraftMinutes(Math.max(0, Math.min(59, val)));
                      }}
                      className="w-12 h-8 bg-white dark:bg-[#090d15] border-y border-slate-300 dark:border-slate-700/80 text-center text-sm font-bold text-slate-900 dark:text-white font-mono focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setDraftMinutes((m) => (m <= 0 ? 59 : m - 1))}
                      className="w-12 h-6 flex items-center justify-center rounded-b-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
                      title="Decrease Minute"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <span className="text-slate-400 dark:text-slate-500 font-bold text-lg pt-4">:</span>

                  {/* Seconds */}
                  <div className="flex flex-col items-center">
                    <span className="text-[9px] text-slate-500 dark:text-slate-400 font-bold mb-1">SEC (00-59)</span>
                    <button
                      type="button"
                      onClick={() => setDraftSeconds((s) => (s >= 59 ? 0 : s + 1))}
                      className="w-12 h-6 flex items-center justify-center rounded-t-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
                      title="Increase Second"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      inputMode="numeric"
                      value={pad(draftSeconds)}
                      onChange={(e) => {
                        const val = parseInt(e.target.value.replace(/\D/g, ''), 10);
                        if (isNaN(val)) setDraftSeconds(0);
                        else setDraftSeconds(Math.max(0, Math.min(59, val)));
                      }}
                      className="w-12 h-8 bg-white dark:bg-[#090d15] border-y border-slate-300 dark:border-slate-700/80 text-center text-sm font-bold text-slate-900 dark:text-white font-mono focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setDraftSeconds((s) => (s <= 0 ? 59 : s - 1))}
                      className="w-12 h-6 flex items-center justify-center rounded-b-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
                      title="Decrease Second"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between gap-2">
                <div className="text-[11px] truncate">
                  <span className="text-slate-400 dark:text-slate-500 text-[9px] block">TARGET:</span>
                  <span className="text-orange-600 dark:text-orange-400 font-bold font-mono">{displayDraftString}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition-colors"
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    onClick={handleApply}
                    className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white text-xs font-bold transition-all shadow-[0_0_12px_rgba(249,115,22,0.4)]"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Apply</span>
                  </button>
                </div>
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
};