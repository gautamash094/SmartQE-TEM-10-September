import React from 'react';

export type SpinnerSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type SpinnerVariant = 'primary' | 'accent' | 'slate' | 'white' | 'amber' | 'red';

interface LoadingSpinnerProps {
  size?: SpinnerSize;
  variant?: SpinnerVariant;
  label?: string;
  className?: string;
  inline?: boolean;
}

const sizeMap: Record<SpinnerSize, { svg: string; text: string }> = {
  xs: { svg: 'w-3 h-3', text: 'text-[10px]' },
  sm: { svg: 'w-3.5 h-3.5', text: 'text-xs' },
  md: { svg: 'w-5 h-5', text: 'text-xs' },
  lg: { svg: 'w-8 h-8', text: 'text-sm' },
  xl: { svg: 'w-12 h-12', text: 'text-base' },
};

const variantMap: Record<SpinnerVariant, { track: string; spinner: string; label: string }> = {
  primary: {
    track: 'text-orange-950/60 stroke-orange-950',
    spinner: 'text-orange-500',
    label: 'text-orange-400',
  },
  accent: {
    track: 'text-emerald-950/60 stroke-emerald-950',
    spinner: 'text-emerald-400',
    label: 'text-emerald-400',
  },
  slate: {
    track: 'text-slate-800 stroke-slate-800',
    spinner: 'text-slate-400',
    label: 'text-slate-400',
  },
  white: {
    track: 'text-white/20 stroke-white/20',
    spinner: 'text-white',
    label: 'text-white',
  },
  amber: {
    track: 'text-amber-950/60 stroke-amber-950',
    spinner: 'text-amber-400',
    label: 'text-amber-400',
  },
  red: {
    track: 'text-red-950/60 stroke-red-950',
    spinner: 'text-red-400',
    label: 'text-red-400',
  },
};

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({
  size = 'md',
  variant = 'primary',
  label,
  className = '',
  inline = false,
}) => {
  const sizeConfig = sizeMap[size];
  const colorConfig = variantMap[variant];

  return (
    <div
      className={`${inline ? 'inline-flex' : 'flex'} items-center justify-center gap-2 ${className}`}
      role="status"
      aria-label={label || 'Loading...'}
    >
      <svg
        className={`animate-spin ${sizeConfig.svg} ${colorConfig.spinner}`}
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
      >
        <circle
          className="opacity-25"
          cx="12"
          cy="12"
          r="10"
          stroke="currentColor"
          strokeWidth="4"
        />
        <path
          className="opacity-90"
          fill="currentColor"
          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
        />
      </svg>
      {label && (
        <span className={`font-mono font-bold tracking-wider ${sizeConfig.text} ${colorConfig.label}`}>
          {label}
        </span>
      )}
    </div>
  );
};