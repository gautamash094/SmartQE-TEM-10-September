import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTEM } from '../../context/TEMContext';
import { Lock, Eye, EyeOff, ShieldCheck, X, Check, AlertCircle } from 'lucide-react';
import { ButtonLoader } from './ButtonLoader';

interface ChangePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({ isOpen, onClose }) => {
  const { changePassword } = useAuth();
  const { showToast } = useTEM();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Real-time policy checklist
  const policyChecks = useMemo(() => {
    return {
      minLength: newPassword.length >= 8,
      hasUpper: /[A-Z]/.test(newPassword),
      hasLower: /[a-z]/.test(newPassword),
      hasNumber: /\d/.test(newPassword),
      hasSpecial: /[!@#$%^&*(),.?":{}|<>\-_+=[\]\\/`~]/.test(newPassword),
      matchesConfirm: newPassword.length > 0 && newPassword === confirmPassword,
    };
  }, [newPassword, confirmPassword]);

  const strengthScore = useMemo(() => {
    let score = 0;
    if (policyChecks.minLength) score += 1;
    if (policyChecks.hasUpper && policyChecks.hasLower) score += 1;
    if (policyChecks.hasNumber) score += 1;
    if (policyChecks.hasSpecial) score += 1;
    return score;
  }, [policyChecks]);

  const strengthLabel = useMemo(() => {
    if (strengthScore <= 1) return { text: 'Weak', color: 'bg-rose-500', textCol: 'text-rose-500' };
    if (strengthScore === 2) return { text: 'Fair', color: 'bg-amber-500', textCol: 'text-amber-500' };
    if (strengthScore === 3) return { text: 'Good', color: 'bg-blue-500', textCol: 'text-blue-500' };
    return { text: 'Strong', color: 'bg-emerald-500', textCol: 'text-emerald-500' };
  }, [strengthScore]);

  const isFormValid =
    currentPassword.length > 0 &&
    policyChecks.minLength &&
    policyChecks.hasUpper &&
    policyChecks.hasLower &&
    policyChecks.hasNumber &&
    policyChecks.hasSpecial &&
    policyChecks.matchesConfirm;

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!isFormValid) {
      if (!policyChecks.matchesConfirm) {
        setErrorMessage('New password and confirmation password do not match.');
      } else {
        setErrorMessage('Please ensure your new password satisfies all security policy requirements.');
      }
      return;
    }

    setIsLoading(true);
    try {
      await changePassword(currentPassword, newPassword);
      showToast('Password changed successfully!', 'success');
      onClose();
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to change password. Please check your current password.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-950/60 border border-orange-300 dark:border-orange-800/80 flex items-center justify-center text-orange-600 dark:text-orange-400">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase font-mono">Change Password</h3>
              <span className="text-[10px] text-slate-400 font-mono">Update your account credentials</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="p-6 space-y-4"
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          data-lpignore="true"
          data-form-type="other"
        >
          {errorMessage && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-300 dark:border-rose-900/60 rounded-xl flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Current Password */}
          <div>
            <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
              Current Password <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type={showCurrent ? 'text' : 'password'}
                required
                name="current_password_no_autofill"
                autoComplete="new-password"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                data-lpignore="true"
                data-form-type="other"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter current password"
                className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono pr-10"
              />
              <button
                type="button"
                onClick={() => setShowCurrent(!showCurrent)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* New Password */}
          <div>
            <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
              New Password <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type={showNew ? 'text' : 'password'}
                required
                name="new_password_no_autofill"
                autoComplete="new-password"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                data-lpignore="true"
                data-form-type="other"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new strong password"
                className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono pr-10"
              />
              <button
                type="button"
                onClick={() => setShowNew(!showNew)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {/* Password Strength Meter */}
            {newPassword.length > 0 && (
              <div className="mt-2 space-y-1">
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-400">STRENGTH:</span>
                  <span className={`font-bold ${strengthLabel.textCol}`}>{strengthLabel.text.toUpperCase()}</span>
                </div>
                <div className="grid grid-cols-4 gap-1.5 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  {[1, 2, 3, 4].map((step) => (
                    <div
                      key={step}
                      className={`h-full transition-all duration-300 ${
                        step <= strengthScore ? strengthLabel.color : 'bg-transparent'
                      }`}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
              Confirm New Password <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type={showConfirm ? 'text' : 'password'}
                required
                name="confirm_password_no_autofill"
                autoComplete="new-password"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                data-lpignore="true"
                data-form-type="other"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono pr-10"
              />
              <button
                type="button"
                onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Policy Checklist */}
          <div className="p-3 bg-slate-50 dark:bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded-xl space-y-1.5">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase block">SECURITY REQUIREMENTS</span>
            <div className="grid grid-cols-2 gap-1 text-[11px] font-mono">
              <div className={`flex items-center gap-1.5 ${policyChecks.minLength ? 'text-emerald-500' : 'text-slate-400'}`}>
                <Check className={`w-3 h-3 ${policyChecks.minLength ? 'opacity-100' : 'opacity-30'}`} />
                <span>8+ Characters</span>
              </div>
              <div className={`flex items-center gap-1.5 ${policyChecks.hasUpper ? 'text-emerald-500' : 'text-slate-400'}`}>
                <Check className={`w-3 h-3 ${policyChecks.hasUpper ? 'opacity-100' : 'opacity-30'}`} />
                <span>Uppercase (A-Z)</span>
              </div>
              <div className={`flex items-center gap-1.5 ${policyChecks.hasLower ? 'text-emerald-500' : 'text-slate-400'}`}>
                <Check className={`w-3 h-3 ${policyChecks.hasLower ? 'opacity-100' : 'opacity-30'}`} />
                <span>Lowercase (a-z)</span>
              </div>
              <div className={`flex items-center gap-1.5 ${policyChecks.hasNumber ? 'text-emerald-500' : 'text-slate-400'}`}>
                <Check className={`w-3 h-3 ${policyChecks.hasNumber ? 'opacity-100' : 'opacity-30'}`} />
                <span>Numeric Digit (0-9)</span>
              </div>
              <div className={`flex items-center gap-1.5 ${policyChecks.hasSpecial ? 'text-emerald-500' : 'text-slate-400'}`}>
                <Check className={`w-3 h-3 ${policyChecks.hasSpecial ? 'opacity-100' : 'opacity-30'}`} />
                <span>Special Character</span>
              </div>
              <div className={`flex items-center gap-1.5 ${policyChecks.matchesConfirm ? 'text-emerald-500' : 'text-slate-400'}`}>
                <Check className={`w-3 h-3 ${policyChecks.matchesConfirm ? 'opacity-100' : 'opacity-30'}`} />
                <span>Passwords Match</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-mono text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              CANCEL
            </button>
            <ButtonLoader
              type="submit"
              disabled={!isFormValid}
              isLoading={isLoading}
              loadingText="UPDATING..."
              icon={<ShieldCheck className="w-3.5 h-3.5" />}
              className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_12px_rgba(249,115,22,0.35)]"
            >
              CHANGE PASSWORD
            </ButtonLoader>
          </div>
        </form>
      </div>
    </div>
  );
};
