﻿import React from 'react';
import { EnvironmentStatus } from '../../types';

interface StatusBadgeProps {
  status: EnvironmentStatus | string;
  size?: 'sm' | 'md';
  showDot?: boolean;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md', showDot = true }) => {
  const getColors = () => {
    const s = String(status).toUpperCase();
    switch (s) {
      case 'HEALTHY':
      case 'AVAILABLE':
        return {
          bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800/60',
          text: 'text-emerald-700 dark:text-emerald-400 font-semibold',
          dot: 'bg-emerald-500 dark:bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]',
        };
      case 'BOOKED':
      case 'IN_USE':
      case 'RESERVED':
      case 'IN USE':
        return {
          bg: 'bg-orange-50 dark:bg-orange-950/40 border-orange-300 dark:border-orange-800/60',
          text: 'text-orange-700 dark:text-orange-400 font-semibold',
          dot: 'bg-orange-500 dark:bg-orange-400 shadow-[0_0_8px_rgba(249,115,22,0.8)]',
        };
      case 'CONFLICTING':
      case 'CONFLICT':
        return {
          bg: 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800/60',
          text: 'text-rose-700 dark:text-rose-400 font-bold',
          dot: 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.8)]',
        };
      case 'DOWN':
      case 'UNAVAILABLE':
        return {
          bg: 'bg-red-50 dark:bg-red-950/40 border-red-300 dark:border-red-800/60',
          text: 'text-red-700 dark:text-red-400 font-bold',
          dot: 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]',
        };
      case 'DEGRADED':
        return {
          bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800/60',
          text: 'text-amber-700 dark:text-amber-400 font-semibold',
          dot: 'bg-amber-500 dark:bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]',
        };
      case 'MAINTENANCE':
        return {
          bg: 'bg-blue-50 dark:bg-blue-950/40 border-blue-300 dark:border-blue-800/60',
          text: 'text-blue-700 dark:text-blue-400 font-semibold',
          dot: 'bg-blue-500 dark:bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.8)]',
        };
      default:
        return {
          bg: 'bg-slate-100 dark:bg-slate-900 border-slate-300 dark:border-slate-700',
          text: 'text-slate-700 dark:text-slate-400 font-semibold',
          dot: 'bg-slate-500 dark:bg-slate-400',
        };
    }
  };

  const colors = getColors();

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-mono uppercase tracking-wider rounded border px-2 py-0.5 ${
        size === 'sm' ? 'text-[10px]' : 'text-xs'
      } ${colors.bg} ${colors.text}`}
    >
      {showDot && <span className={`h-1.5 w-1.5 rounded-full ${colors.dot}`} />}
      {status}
    </span>
  );
};