import React from 'react';
import { Navigate, useLocation, NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { ShieldAlert, ArrowLeft } from 'lucide-react';

interface ProtectedRouteProps {
  screenRoute: string;
  children: React.ReactNode;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ screenRoute, children }) => {
  const { isAuthenticated, isLoading, hasPermission } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center">
        <div className="w-8 h-8 border-3 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // 1. Redirect unauthenticated users to login
  if (!isAuthenticated) {
    return <Navigate to={`/login?redirect=${encodeURIComponent(location.pathname)}`} replace />;
  }

  // 2. Check Role-Based Access permission
  const isAllowed = hasPermission(screenRoute);

  if (!isAllowed) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center p-6">
        <div className="max-w-md w-full text-center bg-white dark:bg-[#0f1724] border border-rose-300 dark:border-rose-900/80 rounded-2xl p-8 shadow-xl space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-rose-100 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800/80 mx-auto flex items-center justify-center text-rose-600 dark:text-rose-400 shadow-sm">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-rose-500 block">
              403 FORBIDDEN
            </span>
            <h2 className="text-xl font-black text-slate-900 dark:text-white mt-1">Access Restricted</h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
              Your assigned role does not currently have permission to access the module at{' '}
              <code className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-slate-800 dark:text-slate-200">
                {screenRoute}
              </code>
              . Contact your Super Admin to request module access.
            </p>
          </div>

          <div className="pt-2">
            <NavLink
              to="/tem-dashboard"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_12px_rgba(249,115,22,0.35)]"
            >
              <ArrowLeft className="w-4 h-4" /> Return to Dashboard
            </NavLink>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
