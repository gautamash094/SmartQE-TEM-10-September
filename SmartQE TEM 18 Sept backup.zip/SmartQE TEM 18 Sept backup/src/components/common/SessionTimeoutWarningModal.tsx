import React from 'react';
import { Clock, ShieldAlert, LogOut, ArrowRight, Activity } from 'lucide-react';
import { ButtonLoader } from './ButtonLoader';

interface SessionTimeoutWarningModalProps {
  isOpen: boolean;
  remainingSeconds: number;
  isRefreshing: boolean;
  onContinueSession: () => void;
  onLogout: () => void;
}

export const SessionTimeoutWarningModal: React.FC<SessionTimeoutWarningModalProps> = ({
  isOpen,
  remainingSeconds,
  isRefreshing,
  onContinueSession,
  onLogout,
}) => {
  if (!isOpen) return null;

  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const percentLeft = Math.max(0, Math.min(100, (remainingSeconds / 120) * 100));

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#0f1724] border border-amber-500/40 rounded-2xl shadow-[0_0_50px_rgba(245,158,11,0.25)] p-6 space-y-6">
        {/* Header Badge */}
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="w-12 h-12 rounded-xl bg-amber-950/70 border border-amber-500/50 flex items-center justify-center text-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)] shrink-0">
            <Clock className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-black uppercase tracking-widest text-amber-400 px-2 py-0.5 rounded bg-amber-950/80 border border-amber-800/80">
                INACTIVITY WARNING
              </span>
            </div>
            <h3 className="text-base font-bold text-white font-mono mt-1">
              Session Expiring Soon
            </h3>
          </div>
        </div>

        {/* Description & Countdown */}
        <div className="space-y-4">
          <p className="text-xs text-slate-300 leading-relaxed">
            You have been inactive for approximately <strong className="text-white">18 minutes</strong>. For enterprise security, your authenticated session will automatically terminate in:
          </p>

          <div className="bg-[#161f2e] border border-slate-800 rounded-xl p-4 text-center space-y-2">
            <div className="text-3xl font-black font-mono tracking-wider text-amber-400">
              {formattedTime}
            </div>
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wide block">
              Remaining until automatic logout
            </span>

            {/* Progress Bar */}
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-3">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-1000"
                style={{ width: `${percentLeft}%` }}
              />
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-lg bg-blue-950/30 border border-blue-800/50 text-[11px] text-blue-300">
            <Activity className="w-4 h-4 shrink-0 mt-0.5 text-blue-400" />
            <span>Click <strong>Continue Session</strong> to reset the 20-minute inactivity timer and keep working.</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onLogout}
            className="px-4 py-2.5 rounded-xl text-xs font-mono font-bold text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-700/60 transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            LOG OUT NOW
          </button>

          <ButtonLoader
            type="button"
            onClick={onContinueSession}
            isLoading={isRefreshing}
            loadingText="EXTENDING..."
            icon={<ArrowRight className="w-4 h-4" />}
            className="px-5 py-2.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.4)] transition-all"
          >
            CONTINUE SESSION
          </ButtonLoader>
        </div>
      </div>
    </div>
  );
};
