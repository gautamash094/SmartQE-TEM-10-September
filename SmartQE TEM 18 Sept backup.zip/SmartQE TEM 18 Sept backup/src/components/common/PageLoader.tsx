﻿import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';
import { Layers } from 'lucide-react';

interface PageLoaderProps {
  title?: string;
  subtitle?: string;
}

export const PageLoader: React.FC<PageLoaderProps> = ({
  title = 'SmartQE TEM Control',
  subtitle = 'Synchronizing environment telemetry & catalog state...',
}) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-900/60 dark:bg-[#070b13]/90 backdrop-blur-md">
      <div className="relative flex flex-col items-center max-w-sm text-center p-8 rounded-2xl bg-white dark:bg-[#0c1322] border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-fadeIn">
        {/* Glow effect */}
        <div className="absolute -inset-1 bg-gradient-to-r from-orange-500/20 via-emerald-500/20 to-blue-500/20 rounded-2xl blur-xl opacity-70 pointer-events-none" />

        {/* Icon & Spinner */}
        <div className="relative">
          <div className="p-4 rounded-xl bg-orange-100 dark:bg-orange-950/60 border border-orange-300 dark:border-orange-700/80 text-orange-600 dark:text-orange-400">
            <Layers className="w-8 h-8 animate-pulse" />
          </div>
          <div className="absolute -bottom-1 -right-1 p-1 bg-white dark:bg-[#0c1322] rounded-full border border-slate-200 dark:border-slate-700">
            <LoadingSpinner size="xs" variant="primary" />
          </div>
        </div>

        {/* Text */}
        <div className="space-y-1.5 z-10 font-mono">
          <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-wider">{title}</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-sans leading-relaxed">{subtitle}</p>
        </div>

        {/* Progress bar placeholder animation */}
        <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-orange-500 via-amber-400 to-emerald-400 animate-[shimmer_2s_infinite] w-full" />
        </div>
      </div>
    </div>
  );
};
