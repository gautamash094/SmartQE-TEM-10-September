﻿import React from 'react';
import { ReleaseRisk } from '../../types';

interface RiskBadgeProps {
  risk: ReleaseRisk;
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({ risk }) => {
  const getStyle = () => {
    switch (risk) {
      case 'LOW RISK':
        return 'text-emerald-600 dark:text-emerald-400 font-semibold';
      case 'MEDIUM RISK':
        return 'text-amber-600 dark:text-amber-400 font-semibold';
      case 'HIGH RISK':
        return 'text-red-600 dark:text-red-400 font-bold';
      default:
        return 'text-slate-500 dark:text-slate-400';
    }
  };

  return (
    <span className={`font-mono text-[11px] uppercase ${getStyle()}`}>
      {risk}
    </span>
  );
};