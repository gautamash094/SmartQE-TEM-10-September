import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Modal } from '../ui/Modal';
import { useTEM } from '../../context/TEMContext';
import { IncidentSeverity } from '../../types';
import { ButtonLoader } from '../common/ButtonLoader';

const incidentSchema = z.object({
  title: z.string().min(3, 'Title must be at least 3 characters'),
  severity: z.enum(['SEV1', 'SEV2', 'SEV3', 'SEV4']),
  environmentId: z.string().min(1, 'Environment is required'),
  assignee: z.string().min(1, 'Assignee is required'),
  description: z.string().optional(),
});

type IncidentFormData = z.infer<typeof incidentSchema>;

interface IncidentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const IncidentModal: React.FC<IncidentModalProps> = ({ isOpen, onClose }) => {
  // Environment Details is the single source of truth for environments
  const { environmentProfiles, addIncident, isLoading } = useTEM();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const activeProfiles = environmentProfiles.filter(env => env.isActive !== false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<IncidentFormData>({
    resolver: zodResolver(incidentSchema),
    defaultValues: {
      title: '',
      severity: 'SEV3',
      environmentId: activeProfiles[0]?.id || environmentProfiles[0]?.id || '',
      assignee: 'tester',
      description: '',
    },
  });

  const onSubmit = async (data: IncidentFormData) => {
    setIsSubmitting(true);
    try {
      // Resolve environmentName from Environment Details profiles
      const env = environmentProfiles.find((e) => e.id === data.environmentId);
      await addIncident({
        title: data.title,
        severity: data.severity as IncidentSeverity,
        environmentId: data.environmentId,
        environmentName: env ? env.name : 'Unknown Env',
        assignee: data.assignee,
        description: data.description,
      });
      reset();
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      categoryTag="ALERT"
      title="Raise Incident"
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors disabled:opacity-50"
          >
            CANCEL
          </button>
          <ButtonLoader
            type="submit"
            form="raise-incident-form"
            isLoading={isSubmitting || isLoading}
            loadingText="RAISING..."
            className="px-5 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)]"
          >
            RAISE
          </ButtonLoader>
        </>
      }
    >
      <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" id="raise-incident-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4 font-mono text-xs">
        {/* Title */}
        <div>
          <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
            TITLE
          </label>
          <input autoComplete="off" data-lpignore="true"
            type="text"
            placeholder="e.g. Memory leak in background worker"
            {...register('title')}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 font-sans"
          />
          {errors.title && <p className="text-xs text-red-400 mt-1 font-mono">{errors.title.message}</p>}
        </div>

        {/* Severity & Environment */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              SEVERITY
            </label>
            <select
              {...register('severity')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="SEV1">SEV1 - Critical</option>
              <option value="SEV2">SEV2 - Major</option>
              <option value="SEV3">SEV3 - Minor</option>
              <option value="SEV4">SEV4 - Low</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              ENVIRONMENT
            </label>
            <select
              {...register('environmentId')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="">Select environment</option>
              {activeProfiles.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.name} ({env.type} — {env.status})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Assignee */}
        <div>
          <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
            ASSIGNEE
          </label>
          <input autoComplete="off" data-lpignore="true"
            type="text"
            placeholder="e.g. Yuki T."
            {...register('assignee')}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 font-sans"
          />
          {errors.assignee && <p className="text-xs text-red-400 mt-1 font-mono">{errors.assignee.message}</p>}
        </div>

        {/* Description */}
        <div>
          <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
            DESCRIPTION
          </label>
          <textarea
            rows={3}
            placeholder="Provide detail on error logs, symptoms, or affected services..."
            {...register('description')}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 font-sans"
          />
        </div>
      </form>
    </Modal>
  );
};
