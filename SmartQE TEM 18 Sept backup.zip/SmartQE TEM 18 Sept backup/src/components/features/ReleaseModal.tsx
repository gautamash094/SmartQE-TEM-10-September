import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Modal } from '../ui/Modal';
import { useTEM } from '../../context/TEMContext';
import { ReleaseRisk } from '../../types';
import { DateTimePicker } from '../common/DateTimePicker';
import { ButtonLoader } from '../common/ButtonLoader';

const formatDateTimeLocal = (date: Date) => {
  const pad = (n: number) => n.toString().padStart(2, '0');
  const yyyy = date.getFullYear();
  const MM = pad(date.getMonth() + 1);
  const dd = pad(date.getDate());
  const hh = pad(date.getHours());
  const mm = pad(date.getMinutes());
  const ss = pad(date.getSeconds());
  return `${yyyy}-${MM}-${dd}T${hh}:${mm}:${ss}`;
};

const releaseSchema = z.object({
  name: z.string().min(2, 'Name is required'),
  version: z.string().min(1, 'Version is required'),
  environmentId: z.string().min(1, 'Environment is required'),
  lead: z.string().min(1, 'Lead is required'),
  changeRef: z.string().min(1, 'Change Ref is required'),
  scheduledDate: z.string().min(1, 'Scheduled Date & Time is required'),
  risk: z.enum(['LOW RISK', 'MEDIUM RISK', 'HIGH RISK']),
});

type ReleaseFormData = z.infer<typeof releaseSchema>;

interface ReleaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReleaseModal: React.FC<ReleaseModalProps> = ({ isOpen, onClose }) => {
  // Environment Details is the single source of truth for environments
  const { environmentProfiles, addRelease, isLoading } = useTEM();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const activeProfiles = environmentProfiles.filter(env => env.isActive !== false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<ReleaseFormData>({
    resolver: zodResolver(releaseSchema),
    defaultValues: {
      name: '',
      version: 'v1.0.0',
      environmentId: activeProfiles[0]?.id || environmentProfiles[0]?.id || '',
      lead: 'Ops Engineer',
      changeRef: 'CR-',
      scheduledDate: formatDateTimeLocal(new Date()),
      risk: 'LOW RISK',
    },
  });

  const onSubmit = async (data: ReleaseFormData) => {
    setIsSubmitting(true);
    try {
      // Resolve environmentName from Environment Details profiles
      const env = environmentProfiles.find((e) => e.id === data.environmentId);
      await addRelease({
        ...data,
        environmentName: env ? env.name : 'Unknown Env',
        risk: data.risk as ReleaseRisk,
      });
      reset();
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      categoryTag="DEPLOYMENT"
      title="Schedule Release"
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors disabled:opacity-50"
          >
            CANCEL
          </button>
          <ButtonLoader
            type="submit"
            form="schedule-release-form"
            isLoading={isSubmitting || isLoading}
            loadingText="SCHEDULING..."
            className="px-5 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)]"
          >
            SCHEDULE
          </ButtonLoader>
        </>
      }
    >
      <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" id="schedule-release-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4 font-mono text-xs">
        {/* Name */}
        <div>
          <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
            NAME
          </label>
          <input autoComplete="off" data-lpignore="true"
            type="text"
            placeholder="e.g. Fraud Model Refresh"
            {...register('name')}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 font-sans"
          />
          {errors.name && <p className="text-xs text-red-400 mt-1 font-mono">{errors.name.message}</p>}
        </div>

        {/* Version & Environment */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              VERSION
            </label>
            <input autoComplete="off" data-lpignore="true"
              type="text"
              placeholder="e.g. v1.0.0"
              {...register('version')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
            />
            {errors.version && <p className="text-xs text-red-400 mt-1 font-mono">{errors.version.message}</p>}
          </div>

          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              ENVIRONMENT
            </label>
            <select
              {...register('environmentId')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="">Select environment</option>
              {activeProfiles.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.name} ({env.type} — {env.status})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Lead & Change Ref */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              LEAD
            </label>
            <input autoComplete="off" data-lpignore="true"
              type="text"
              placeholder="e.g. Yuki T."
              {...register('lead')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 font-sans"
            />
            {errors.lead && <p className="text-xs text-red-400 mt-1 font-mono">{errors.lead.message}</p>}
          </div>

          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              CHANGE REF
            </label>
            <input autoComplete="off" data-lpignore="true"
              type="text"
              placeholder="CR-1234"
              {...register('changeRef')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
            />
            {errors.changeRef && <p className="text-xs text-red-400 mt-1 font-mono">{errors.changeRef.message}</p>}
          </div>
        </div>

        {/* Scheduled Date & Time (HH:MM:SS) & Risk */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <DateTimePicker
            label="SCHEDULED DATE & TIME"
            subLabel="HH:MM:SS"
            value={watch('scheduledDate')}
            onChange={(val) => setValue('scheduledDate', val, { shouldValidate: true })}
            error={errors.scheduledDate?.message}
          />

          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              RISK
            </label>
            <select
              {...register('risk')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="LOW RISK">Low</option>
              <option value="MEDIUM RISK">Medium</option>
              <option value="HIGH RISK">High</option>
            </select>
          </div>
        </div>
      </form>
    </Modal>
  );
};
