import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { useTEM } from '../../context/TEMContext';
import { Runbook } from '../../types';
import { Play, CheckCircle2, Loader2 } from 'lucide-react';

interface RunbookModalProps {
  runbook: Runbook | null;
  isOpen: boolean;
  onClose: () => void;
}

export const RunbookModal: React.FC<RunbookModalProps> = ({ runbook, isOpen, onClose }) => {
  const { environmentProfiles, executeRunbook, isLoading } = useTEM();
  const [selectedTargetEnv, setSelectedTargetEnv] = useState<string>('');
  const [running, setRunning] = useState<boolean>(false);
  const [completedStepIndex, setCompletedStepIndex] = useState<number>(-1);

  if (!runbook) return null;

  const handleRun = async () => {
    setRunning(true);
    setCompletedStepIndex(-1);

    // Simulate step by step execution
    for (let i = 0; i < runbook.steps.length; i++) {
      await new Promise((res) => setTimeout(res, 600));
      setCompletedStepIndex(i);
    }

    await executeRunbook(runbook.id, selectedTargetEnv || undefined);
    setRunning(false);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} categoryTag="RUNBOOK EXECUTION" title={runbook.name}>
      <div className="space-y-4">
        {/* Category & Est Time */}
        <div className="flex items-center justify-between text-xs font-mono text-slate-400 bg-slate-900/60 p-3 rounded border border-slate-200 dark:border-slate-800">
          <span>CATEGORY: <strong className="text-slate-200">{runbook.category}</strong></span>
          <span>EST. TIME: <strong className="text-amber-400">{runbook.estimatedTimeMinutes} min</strong></span>
        </div>

        {/* Target Environment Selector */}
        <div>
          <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
            TARGET ENVIRONMENT (OPTIONAL)
          </label>
          <select
            value={selectedTargetEnv}
            onChange={(e) => setSelectedTargetEnv(e.target.value)}
            disabled={running}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
          >
            <option value="">All / Global Cluster</option>
            {environmentProfiles.filter(e => e.isActive !== false).map((e) => (
              <option key={e.id} value={e.id}>
                {e.name} ({e.type})
              </option>
            ))}
          </select>
        </div>

        {/* Steps List */}
        <div>
          <h4 className="text-xs font-mono font-semibold uppercase tracking-wider text-slate-400 mb-2">
            EXECUTION STEPS ({runbook.steps.length})
          </h4>
          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {runbook.steps.map((step, idx) => {
              const isDone = completedStepIndex >= idx;
              const isCurrent = running && completedStepIndex === idx - 1;

              return (
                <div
                  key={idx}
                  className={`flex items-start gap-3 p-2.5 rounded border text-xs font-mono transition-colors ${
                    isDone
                      ? 'bg-emerald-950/30 border-emerald-800/60 text-emerald-300'
                      : isCurrent
                      ? 'bg-amber-950/30 border-amber-800/60 text-amber-300'
                      : 'bg-slate-900/40 border-slate-200 dark:border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : isCurrent ? (
                      <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />
                    ) : (
                      <span className="w-4 h-4 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] font-bold">
                        {idx + 1}
                      </span>
                    )}
                  </div>
                  <span className="flex-1">{step}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            disabled={running}
            className="px-4 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors disabled:opacity-50"
          >
            CLOSE
          </button>
          <button
            type="button"
            onClick={handleRun}
            disabled={running || isLoading}
            className="flex items-center gap-2 px-5 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)] disabled:opacity-50"
          >
            {running ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> EXECUTING...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" /> EXECUTE RUNBOOK
              </>
            )}
          </button>
        </div>
      </div>
    </Modal>
  );
};
