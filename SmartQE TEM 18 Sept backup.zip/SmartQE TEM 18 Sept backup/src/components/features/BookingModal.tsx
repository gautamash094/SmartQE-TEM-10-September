import React, { useState, useMemo, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Modal } from '../ui/Modal';
import { useTEM } from '../../context/TEMContext';
import { useAuth } from '../../context/AuthContext';
import { AlertTriangle, Clock, ShieldAlert, Users, Zap, CheckCircle2, Sparkles, BrainCircuit, ArrowRight, CheckCheck, Info } from 'lucide-react';
import { DateTimePicker } from '../common/DateTimePicker';
import { ButtonLoader } from '../common/ButtonLoader';
import { ReservationMode, Booking, AutoApprovalRule, ReservationPriority } from '../../types';
import { aiIntelligenceService } from '../../services/aiIntelligenceService';
import { workflowService, Workflow } from '../../services/workflowService';

const formatDateMidnight = (date: Date) => {
  const pad = (n: number) => n.toString().padStart(2, '0');
  const yyyy = date.getFullYear();
  const MM = pad(date.getMonth() + 1);
  const dd = pad(date.getDate());
  return `${yyyy}-${MM}-${dd}T00:00:00`;
};

const formatDisplayDateTime = (dtStr: string) => {
  if (!dtStr) return 'N/A';
  return dtStr.replace('T', ' ');
};

const resolveEditingEnvId = (booking?: Booking | null, defaultId?: string, profiles: any[] = []) => {
  if (!booking) return defaultId || '';
  const match = profiles.find(
    (e) =>
      (booking.environmentId && (e.id === booking.environmentId || e.name?.toLowerCase() === booking.environmentId.toLowerCase())) ||
      (booking.environmentName && (e.name?.toLowerCase() === booking.environmentName.toLowerCase() || e.id === booking.environmentName))
  );
  return match?.id || booking.environmentId || defaultId || '';
};

const resolveEditingBU = (booking?: Booking | null, bus: any[] = []) => {
  if (!booking?.businessUnit) return '';
  const match = bus.find(
    (b) =>
      b.name?.toLowerCase().trim() === booking.businessUnit.toLowerCase().trim() ||
      b.id === booking.businessUnit ||
      b.code?.toLowerCase().trim() === booking.businessUnit.toLowerCase().trim()
  );
  return match?.name || booking.businessUnit;
};

const bookingSchema = z
  .object({
    environmentId: z.string().min(1, 'Select environment.'),
    businessUnit: z.string().min(1, 'Select business unit.'),
    project: z.string().optional().default(''),
    application: z.string().optional().default(''),
    purpose: z.string().min(1, 'Purpose is required'),
    team: z.string().min(1, 'Team is required'),
    requestedBy: z.string().min(1, 'Requested By is required'),
    priority: z.enum(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']).default('MEDIUM'),
    autoApprovalEnabled: z.boolean().default(false),
    autoApprovalRule: z.enum(['ALL_REQUESTS', 'PRIORITY_REQUESTS', 'SHORT_REQUESTS']).nullable().optional(),
    startDate: z.string().min(1, 'Start Date & Time is required'),
    endDate: z.string().min(1, 'End Date & Time is required'),
    reservationMode: z.enum(['SHARED', 'DISRUPTIVE']).default('SHARED'),
  })
  .refine(
    (data) => {
      if (!data.startDate || !data.endDate) return true;
      const start = new Date(data.startDate).getTime();
      const end = new Date(data.endDate).getTime();
      return start < end;
    },
    {
      message: 'Start date and time cannot be greater than end date and time.',
      path: ['endDate'],
    }
  )
  .refine(
    (data) => {
      if (data.autoApprovalEnabled && !data.autoApprovalRule) {
        return false;
      }
      return true;
    },
    {
      message: 'Please select an Auto Approval rule when Auto Approval is enabled.',
      path: ['autoApprovalRule'],
    }
  );

type BookingFormData = z.infer<typeof bookingSchema>;

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultEnvId?: string;
  editingBooking?: Booking | null;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, defaultEnvId, editingBooking }) => {
  const { environmentProfiles, businessUnits, projects, applications, bookings, incidents, releases, addBooking, updateBooking, isLoading, showToast } = useTEM();
  const { currentUser } = useAuth();

  const loggedInUserName = currentUser?.fullName || currentUser?.username || 'System Admin';

  const now = new Date();
  const future = new Date(Date.now() + 3 * 86400000);

  const activeProfiles = useMemo(() => {
    const resolvedId = resolveEditingEnvId(editingBooking, defaultEnvId, environmentProfiles);
    return environmentProfiles.filter(
      env => env.isActive !== false || env.id === defaultEnvId || env.id === resolvedId || (editingBooking && (env.id === editingBooking.environmentId || env.name.toLowerCase() === (editingBooking.environmentName || '').toLowerCase()))
    );
  }, [environmentProfiles, defaultEnvId, editingBooking]);

  const activeBUs = useMemo(() => {
    return businessUnits.filter(bu => bu.isActive !== false && bu.status !== 'INACTIVE');
  }, [businessUnits]);

  const initialEnvId = resolveEditingEnvId(editingBooking, defaultEnvId, environmentProfiles);
  const initialBU = resolveEditingBU(editingBooking, businessUnits);
  const initialProj = editingBooking?.project || '';
  const initialApp = editingBooking?.application || '';

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      environmentId: initialEnvId,
      businessUnit: initialBU,
      project: initialProj,
      application: initialApp,
      purpose: editingBooking?.purpose || '',
      team: editingBooking?.team || 'QA Guild',
      requestedBy: editingBooking?.requestedBy || loggedInUserName,
      priority: (editingBooking?.priority as ReservationPriority) || 'MEDIUM',
      autoApprovalEnabled: Boolean(editingBooking?.autoApprovalEnabled),
      autoApprovalRule: editingBooking?.autoApprovalRule || null,
      startDate: editingBooking?.startDate || formatDateMidnight(now),
      endDate: editingBooking?.endDate || formatDateMidnight(future),
      reservationMode: (editingBooking?.reservationMode as 'SHARED' | 'DISRUPTIVE') || 'SHARED',
    },
  });

  // Keep form updated when modal opens or editingBooking/defaultEnvId changes
  useEffect(() => {
    if (isOpen) {
      if (editingBooking) {
        reset({
          environmentId: resolveEditingEnvId(editingBooking, defaultEnvId, environmentProfiles),
          businessUnit: resolveEditingBU(editingBooking, businessUnits),
          project: editingBooking.project || '',
          application: editingBooking.application || '',
          purpose: editingBooking.purpose || '',
          team: editingBooking.team || 'QA Guild',
          requestedBy: editingBooking.requestedBy || loggedInUserName,
          priority: (editingBooking.priority as ReservationPriority) || 'MEDIUM',
          autoApprovalEnabled: Boolean(editingBooking.autoApprovalEnabled),
          autoApprovalRule: editingBooking.autoApprovalRule || null,
          startDate: editingBooking.startDate || formatDateMidnight(now),
          endDate: editingBooking.endDate || formatDateMidnight(future),
          reservationMode: (editingBooking.reservationMode as 'SHARED' | 'DISRUPTIVE') || 'SHARED',
        });
      } else {
        reset({
          environmentId: defaultEnvId || '',
          businessUnit: '',
          project: '',
          application: '',
          purpose: '',
          team: 'QA Guild',
          requestedBy: loggedInUserName,
          priority: 'MEDIUM',
          autoApprovalEnabled: false,
          autoApprovalRule: null,
          startDate: formatDateMidnight(now),
          endDate: formatDateMidnight(future),
          reservationMode: 'SHARED',
        });
      }
    }
  }, [isOpen, editingBooking, defaultEnvId, reset, loggedInUserName, environmentProfiles, businessUnits]);

  const selectedEnvId = watch('environmentId');
  const selectedBU = watch('businessUnit');
  const watchStartDate = watch('startDate');
  const watchEndDate = watch('endDate');
  const selectedReservationMode = watch('reservationMode') || 'SHARED';
  const watchAutoApproval = watch('autoApprovalEnabled');
  const watchAutoApprovalRule = watch('autoApprovalRule');

  // Date Order Validation Rule: Start date/time must always be earlier than end date/time
  const isDateOrderInvalid = useMemo(() => {
    if (!watchStartDate || !watchEndDate) return false;
    const s = new Date(watchStartDate).getTime();
    const e = new Date(watchEndDate).getTime();
    return !isNaN(s) && !isNaN(e) && s >= e;
  }, [watchStartDate, watchEndDate]);

  // Filter projects by selected Business Unit (active preferred)
  const filteredProjects = useMemo(() => {
    if (!selectedBU) return [];
    const activeOnly = projects.filter(
      p => p.businessUnit.toLowerCase() === selectedBU.toLowerCase() && p.isActive !== false && p.status !== 'INACTIVE'
    );
    if (activeOnly.length > 0) return activeOnly;
    return projects.filter(p => p.businessUnit.toLowerCase() === selectedBU.toLowerCase());
  }, [projects, selectedBU]);

  // Filter applications by selected Business Unit (active preferred)
  const filteredApps = useMemo(() => {
    if (!selectedBU) return [];
    const activeOnly = applications.filter(
      a => a.businessUnit.toLowerCase() === selectedBU.toLowerCase() && a.isActive !== false && a.status !== 'INACTIVE'
    );
    if (activeOnly.length > 0) return activeOnly;
    return applications.filter(a => a.businessUnit.toLowerCase() === selectedBU.toLowerCase());
  }, [applications, selectedBU]);

  // Reset project and application when BU changes (no auto-selection)
  const handleBUChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newBU = e.target.value;
    setValue('businessUnit', newBU);
    setValue('project', '');
    setValue('application', '');
  };

  // --- LIVE CONFLICT DETECTION PREVIEW considering Reservation Mode Matrix ---
  const conflictingBookings = useMemo(() => {
    if (!selectedEnvId || !watchStartDate || !watchEndDate || isDateOrderInvalid) return [];
    const newStart = new Date(watchStartDate).getTime();
    const newEnd = new Date(watchEndDate).getTime();
    if (isNaN(newStart) || isNaN(newEnd) || newEnd <= newStart) return [];

    const selectedEnv = environmentProfiles.find(e => e.id === selectedEnvId);

    return bookings.filter(b => {
      // Exclude self if editing existing reservation
      if (editingBooking && b.id === editingBooking.id) return false;

      // Exclude inactive bookings (canceled, rejected, auto-rejected)
      if (b.status === 'CANCELLED' || b.status === 'REJECTED' || b.status === 'AUTO_REJECTED') {
        return false;
      }

      const sameEnv =
        (b.environmentId && b.environmentId === selectedEnvId) ||
        (selectedEnv && b.environmentName && b.environmentName.toLowerCase() === selectedEnv.name.toLowerCase());

      if (sameEnv && b.startDate && b.endDate) {
        const bStart = new Date(b.startDate).getTime();
        const bEnd = new Date(b.endDate).getTime();
        const isTimeOverlap = newStart < bEnd && newEnd > bStart;
        if (!isTimeOverlap) return false;

        const otherMode = b.reservationMode || 'SHARED';
        return selectedReservationMode === 'DISRUPTIVE' || otherMode === 'DISRUPTIVE';
      }
      return false;
    });
  }, [selectedEnvId, watchStartDate, watchEndDate, selectedReservationMode, isDateOrderInvalid, environmentProfiles, bookings, editingBooking]);

  // --- AI BOOKING INTELLIGENCE ENGINE FACADE ---
  const aiAssistResult = useMemo(() => {
    if (!selectedEnvId || !watchStartDate || !watchEndDate || isDateOrderInvalid) return null;
    return aiIntelligenceService.getBookingAIAssistance(
      selectedEnvId,
      watchStartDate,
      watchEndDate,
      selectedReservationMode,
      environmentProfiles,
      bookings,
      incidents || [],
      releases || [],
      editingBooking?.id
    );
  }, [selectedEnvId, watchStartDate, watchEndDate, selectedReservationMode, environmentProfiles, bookings, incidents, releases, isDateOrderInvalid, editingBooking]);

  // --- ACTIVE WORKFLOW DETECTION & RESOLUTION ---
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [isLoadingWorkflows, setIsLoadingWorkflows] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsLoadingWorkflows(true);
      workflowService
        .getWorkflows({ isActive: true })
        .then((wfs) => setWorkflows(wfs))
        .catch(() => setWorkflows([]))
        .finally(() => setIsLoadingWorkflows(false));
    }
  }, [isOpen]);

  const watchApplication = watch('application');

  const matchingWorkflow = useMemo(() => {
    if (!selectedBU || !selectedEnvId || !workflows.length) return null;
    const targetBU = selectedBU.toLowerCase().trim();
    const targetEnvId = selectedEnvId.toLowerCase().trim();
    const selectedEnv = environmentProfiles.find((e) => e.id === selectedEnvId);
    const targetEnvName = (selectedEnv?.name || '').toLowerCase().trim();
    const targetApp = (watchApplication || '').toLowerCase().trim();

    return (
      workflows.find((w) => {
        if (!w.isActive || !w.approvers || w.approvers.length === 0) return false;
        if (w.serviceCode && w.serviceCode !== 'ENVIRONMENT_RESERVATION') return false;

        const buMatch =
          (w.buId && w.buId.toLowerCase().trim() === targetBU) ||
          (w.buName && w.buName.toLowerCase().trim() === targetBU) ||
          (w.buCode && w.buCode.toLowerCase().trim() === targetBU);
        if (!buMatch) return false;

        const envMatch =
          (w.environmentId &&
            (w.environmentId.toLowerCase().trim() === targetEnvId ||
              w.environmentId.toLowerCase().trim() === targetEnvName)) ||
          (w.environmentName &&
            (w.environmentName.toLowerCase().trim() === targetEnvName ||
              w.environmentName.toLowerCase().trim() === targetEnvId));
        if (!envMatch) return false;

        if (targetApp && w.applicationName) {
          return (
            w.applicationName.toLowerCase().trim() === targetApp ||
            (w.applicationId && w.applicationId.toLowerCase().trim() === targetApp)
          );
        }
        return true;
      }) || null
    );
  }, [selectedBU, selectedEnvId, watchApplication, workflows, environmentProfiles]);

  const hasConflict = conflictingBookings.length > 0;

  // Auto Approval conflict reset effect: if conflict arises, uncheck Auto Approval and clear rule
  useEffect(() => {
    if (hasConflict && watchAutoApproval) {
      setValue('autoApprovalEnabled', false);
      setValue('autoApprovalRule', null);
    }
  }, [hasConflict, watchAutoApproval, setValue]);

  const handleToggleAutoApproval = () => {
    if (hasConflict) {
      showToast(
        'Auto Approval cannot be selected because this reservation has a conflict. Please resolve the conflict before enabling Auto Approval.',
        'error'
      );
      return;
    }
    const nextState = !watchAutoApproval;
    setValue('autoApprovalEnabled', nextState, { shouldValidate: true });
    if (!nextState) {
      setValue('autoApprovalRule', null, { shouldValidate: true });
    } else if (!watchAutoApprovalRule) {
      setValue('autoApprovalRule', 'ALL_REQUESTS', { shouldValidate: true });
    }
  };

  const handleSelectRule = (rule: AutoApprovalRule) => {
    if (hasConflict) {
      showToast(
        'Auto Approval cannot be selected because this reservation has a conflict. Please resolve the conflict before enabling Auto Approval.',
        'error'
      );
      return;
    }
    setValue('autoApprovalRule', rule, { shouldValidate: true });
  };

  const [isSubmitting, setIsSubmitting] = useState(false);

  const onSubmit = async (data: BookingFormData) => {
    const s = new Date(data.startDate).getTime();
    const e = new Date(data.endDate).getTime();
    if (isNaN(s) || isNaN(e) || s >= e) {
      showToast('Start date and time must be strictly earlier than end date and time.', 'error');
      return;
    }

    if (!data.environmentId) {
      showToast('Please select a target Environment Profile (*).', 'error');
      return;
    }

    const cleanPurpose = data.purpose ? data.purpose.trim() : '';
    if (!cleanPurpose) {
      showToast('Reservation Purpose is mandatory (*).', 'error');
      return;
    }

    if (!data.businessUnit?.trim()) {
      showToast('Please select a Business Unit (*).', 'error');
      return;
    }

    // MANDATORY WORKFLOW RULE: Block reservation creation if workflow is not defined
    if (!editingBooking) {
      if (!matchingWorkflow || !matchingWorkflow.approvers || matchingWorkflow.approvers.length === 0) {
        showToast('Define the workflow to make any reservation.', 'error');
        return;
      }
    }

    const selectedEnv = environmentProfiles.find((env) => env.id === data.environmentId);
    if (selectedEnv && selectedEnv.isActive === false) {
      showToast(`Environment "${selectedEnv.name}" is currently INACTIVE and cannot be reserved.`, 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const envName = selectedEnv ? selectedEnv.name : (editingBooking?.environmentName || 'Unknown Env');

      if (editingBooking) {
        const auditLogs = [...(editingBooking.auditHistory || [])];
        if (data.startDate !== editingBooking.startDate || data.endDate !== editingBooking.endDate) {
          auditLogs.push({
            id: `audit-${Date.now()}-1`,
            field: 'Time Window',
            oldValue: `${formatDisplayDateTime(editingBooking.startDate)} → ${formatDisplayDateTime(editingBooking.endDate)}`,
            newValue: `${formatDisplayDateTime(data.startDate)} → ${formatDisplayDateTime(data.endDate)}`,
            changedBy: data.requestedBy || 'Ops Engineer',
            changedAt: new Date().toISOString(),
          });
        }
        if (data.reservationMode !== editingBooking.reservationMode) {
          auditLogs.push({
            id: `audit-${Date.now()}-2`,
            field: 'Reservation Mode',
            oldValue: editingBooking.reservationMode || 'SHARED',
            newValue: data.reservationMode,
            changedBy: data.requestedBy || 'Ops Engineer',
            changedAt: new Date().toISOString(),
          });
        }
        if (data.environmentId !== editingBooking.environmentId) {
          auditLogs.push({
            id: `audit-${Date.now()}-3`,
            field: 'Target Environment',
            oldValue: editingBooking.environmentName || editingBooking.environmentId,
            newValue: envName,
            changedBy: data.requestedBy || 'Ops Engineer',
            changedAt: new Date().toISOString(),
          });
        }
        if (data.priority !== editingBooking.priority) {
          auditLogs.push({
            id: `audit-${Date.now()}-prio`,
            field: 'Priority',
            oldValue: editingBooking.priority || 'MEDIUM',
            newValue: data.priority,
            changedBy: data.requestedBy || 'Ops Engineer',
            changedAt: new Date().toISOString(),
          });
        }
        if (data.autoApprovalEnabled !== editingBooking.autoApprovalEnabled) {
          auditLogs.push({
            id: `audit-${Date.now()}-aa1`,
            field: 'Auto Approval',
            oldValue: editingBooking.autoApprovalEnabled ? `Enabled (${editingBooking.autoApprovalRule})` : 'Disabled',
            newValue: data.autoApprovalEnabled ? `Enabled (${data.autoApprovalRule})` : 'Disabled',
            changedBy: data.requestedBy || 'Ops Engineer',
            changedAt: new Date().toISOString(),
          });
        } else if (data.autoApprovalEnabled && data.autoApprovalRule !== editingBooking.autoApprovalRule) {
          auditLogs.push({
            id: `audit-${Date.now()}-aa2`,
            field: 'Auto Approval Rule',
            oldValue: String(editingBooking.autoApprovalRule),
            newValue: String(data.autoApprovalRule),
            changedBy: data.requestedBy || 'Ops Engineer',
            changedAt: new Date().toISOString(),
          });
        }

        await updateBooking(editingBooking.id, {
          environmentId: data.environmentId,
          environmentName: envName,
          businessUnit: data.businessUnit,
          project: data.project || '',
          application: data.application || '',
          purpose: data.purpose,
          team: data.team,
          requestedBy: data.requestedBy,
          priority: data.priority,
          autoApprovalEnabled: data.autoApprovalEnabled,
          autoApprovalRule: data.autoApprovalEnabled ? data.autoApprovalRule : null,
          startDate: data.startDate,
          endDate: data.endDate,
          reservationMode: data.reservationMode,
          status: editingBooking.status || 'CONFIRMED',
          auditHistory: auditLogs,
        });
        showToast('Reservation updated successfully.', 'success');
      } else {
        const created = await addBooking({
          environmentId: data.environmentId,
          environmentName: envName,
          businessUnit: data.businessUnit,
          project: data.project || '',
          application: data.application || '',
          purpose: data.purpose,
          team: data.team,
          requestedBy: data.requestedBy,
          priority: data.priority,
          autoApprovalEnabled: data.autoApprovalEnabled,
          autoApprovalRule: data.autoApprovalEnabled ? data.autoApprovalRule : null,
          startDate: data.startDate,
          endDate: data.endDate,
          reservationMode: data.reservationMode,
        });
        if (created && created.status === 'PENDING') {
          showToast('Reservation created successfully and is pending approval from the configured workflow.', 'success');
        } else {
          showToast('Reservation created successfully.', 'success');
        }
      }
      onClose();
    } catch (err: any) {
      showToast(err?.message || 'Failed to process reservation.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingBooking ? 'Edit Environment Reservation' : 'Create Environment Reservation'}
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 rounded text-xs font-mono font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <ButtonLoader
            type="submit"
            form="booking-form"
            isLoading={isSubmitting || isLoading}
            loadingText="SAVING..."
            disabled={isDateOrderInvalid}
            className="px-5 py-2 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 disabled:opacity-50 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)]"
          >
            {editingBooking ? 'Save Reservation Changes' : 'Confirm Reservation'}
          </ButtonLoader>
        </>
      }
    >
      <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" id="booking-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4 font-sans text-xs">
        {/* Real-time Conflict Alert Notification Banner */}
        {conflictingBookings.length > 0 && (
          <div className="bg-red-950/40 border border-red-800/80 rounded-lg p-3 text-red-300 font-mono text-xs animate-pulse space-y-1 shadow-lg">
            <div className="flex items-center gap-2 font-bold text-red-400">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
              <span>OVERLAP CONFLICT DETECTED ({conflictingBookings.length} EXISTING RESERVATION{conflictingBookings.length > 1 ? 'S' : ''})</span>
            </div>
            <p className="text-[11px] text-red-300/90 leading-relaxed pl-6">
              Reservation mode is <span className="font-bold underline uppercase">{selectedReservationMode}</span>. 
              {selectedReservationMode === 'DISRUPTIVE' 
                ? ' Disruptive mode requires 100% exclusive environment control.' 
                : ' An overlapping booking is in Disruptive mode.'}
            </p>
          </div>
        )}

        {/* Form Fields Grid */}
        <div className="space-y-3">
          {/* Environment (DROPDOWN) */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              ENVIRONMENT PROFILE <span className="text-orange-500">*</span>
            </label>
            <select
              {...register('environmentId')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="">-- Select Environment --</option>
              {activeProfiles.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.name} ({env.type})
                </option>
              ))}
              {!activeProfiles.some((p) => p.id === selectedEnvId) && selectedEnvId && (
                <option value={selectedEnvId}>
                  {editingBooking?.environmentName || selectedEnvId}
                </option>
              )}
            </select>
            {errors.environmentId && (
              <p className="text-xs text-red-400 mt-1 font-mono">{errors.environmentId.message}</p>
            )}
          </div>

          {/* Business Unit (DROPDOWN) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400">
                BUSINESS UNIT <span className="text-orange-500">*</span>
              </label>
              <span className="text-[9px] font-mono text-slate-500">DROPDOWN</span>
            </div>
            <select
              value={selectedBU || ''}
              onChange={handleBUChange}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="">-- Select Business Unit --</option>
              {activeBUs.map((bu) => (
                <option key={bu.id} value={bu.name}>
                  {bu.name} ({bu.code})
                </option>
              ))}
              {!activeBUs.some((b) => b.name.toLowerCase().trim() === (selectedBU || '').toLowerCase().trim()) && selectedBU && (
                <option value={selectedBU}>{selectedBU}</option>
              )}
            </select>
            {errors.businessUnit && (
              <p className="text-xs text-red-400 mt-1 font-mono">{errors.businessUnit.message}</p>
            )}
          </div>

          {/* Project & Application (DROPDOWNS) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400">
                  PROJECT
                </label>
                <span className="text-[9px] font-mono text-slate-500">DROPDOWN</span>
              </div>
              <select
                {...register('project')}
                className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              >
                <option value="">-- Select Project --</option>
                {filteredProjects.map((proj) => (
                  <option key={proj.id} value={proj.name}>
                    {proj.name} ({proj.code})
                  </option>
                ))}
              </select>
              {errors.project && (
                <p className="text-xs text-red-400 mt-1 font-mono">{errors.project.message}</p>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400">
                  APPLICATION
                </label>
                <span className="text-[9px] font-mono text-slate-500">DROPDOWN</span>
              </div>
              <select
                {...register('application')}
                className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              >
                <option value="">-- Select Application --</option>
                {filteredApps.map((app) => (
                  <option key={app.id} value={app.name}>
                    {app.name} ({app.code})
                  </option>
                ))}
              </select>
              {errors.application && (
                <p className="text-xs text-red-400 mt-1 font-mono">{errors.application.message}</p>
              )}
            </div>
          </div>

          {/* Sequential Approval Workflow Status / Requirement Banner */}
          {selectedEnvId && selectedBU && !matchingWorkflow && (
            <div className="bg-amber-950/40 border border-amber-600/70 rounded-lg p-3 text-amber-200 font-mono text-xs space-y-1 shadow-md">
              <div className="flex items-center gap-2 font-bold text-amber-400">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>APPROVAL WORKFLOW REQUIRED</span>
              </div>
              <p className="text-[11px] text-amber-300/90 leading-relaxed pl-6">
                Define the workflow to make any reservation. No active sequential approval workflow is configured for this Environment and Business Unit. Please navigate to <strong>Approval Workflows</strong> to configure it first.
              </p>
            </div>
          )}

          {selectedEnvId && selectedBU && matchingWorkflow && (
            <div className="bg-emerald-950/30 border border-emerald-600/60 rounded-lg p-3 text-emerald-300 font-mono text-xs space-y-1.5 shadow-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-emerald-400">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>ACTIVE APPROVAL WORKFLOW ATTACHED ({matchingWorkflow.approvers.length} STEP{matchingWorkflow.approvers.length > 1 ? 'S' : ''})</span>
                </div>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-900/50 px-2 py-0.5 rounded border border-emerald-700/50 uppercase tracking-wider">
                  Sequential Review
                </span>
              </div>
              <div className="text-[11px] text-emerald-200/90 pl-6 flex flex-wrap items-center gap-1.5">
                {matchingWorkflow.approvers
                  .slice()
                  .sort((a, b) => a.workflowOrder - b.workflowOrder)
                  .map((a, idx) => (
                    <React.Fragment key={a.id || idx}>
                      <span className="bg-slate-900/90 border border-emerald-700/50 px-2 py-0.5 rounded text-[10px] text-emerald-300 font-semibold">
                        Step {a.workflowOrder}: {a.fullName || a.username || a.userId}
                      </span>
                      {idx < matchingWorkflow.approvers.length - 1 && (
                        <ArrowRight className="w-3 h-3 text-emerald-500 shrink-0" />
                      )}
                    </React.Fragment>
                  ))}
              </div>
            </div>
          )}

          {/* Purpose */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
              PURPOSE <span className="text-orange-500">*</span>
            </label>
            <input autoComplete="off" data-lpignore="true"
              type="text"
              placeholder="e.g. UAT Regression Run, Performance Soak Test"
              {...register('purpose')}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
            />
            {errors.purpose && (
              <p className="text-xs text-red-400 mt-1 font-mono">{errors.purpose.message}</p>
            )}
          </div>

          {/* Team, Requested By & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                TEAM <span className="text-orange-500">*</span>
              </label>
              <input autoComplete="off" data-lpignore="true"
                type="text"
                placeholder="e.g. Onboarding Guild"
                {...register('team')}
                className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
              />
              {errors.team && (
                <p className="text-xs text-red-400 mt-1 font-mono">{errors.team.message}</p>
              )}
            </div>

            <div>
              <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                REQUESTED BY <span className="text-orange-500">*</span>
              </label>
              <input autoComplete="off" data-lpignore="true"
                type="text"
                placeholder="e.g. Priya N."
                {...register('requestedBy')}
                className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
              />
              {errors.requestedBy && (
                <p className="text-xs text-red-400 mt-1 font-mono">{errors.requestedBy.message}</p>
              )}
            </div>

            <div>
              <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                PRIORITY <span className="text-orange-500">*</span>
              </label>
              <select
                {...register('priority')}
                className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              >
                <option value="LOW">LOW</option>
                <option value="MEDIUM">MEDIUM</option>
                <option value="HIGH">HIGH</option>
                <option value="CRITICAL">CRITICAL</option>
              </select>
              {errors.priority && (
                <p className="text-xs text-red-400 mt-1 font-mono">{errors.priority.message}</p>
              )}
            </div>
          </div>

          {/* RESERVATION MODE CARDS (SHARED VS DISRUPTIVE) */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              RESERVATION MODE <span className="text-orange-500">*</span>
            </label>

            <div className="grid grid-cols-2 gap-3">
              {/* SHARED CARD */}
              <div
                onClick={() => setValue('reservationMode', 'SHARED')}
                className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col justify-between space-y-1.5 ${
                  selectedReservationMode === 'SHARED'
                    ? 'bg-cyan-950/80 border-cyan-500 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                    : 'bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 font-extrabold text-cyan-300 font-mono text-xs">
                    <Users className="w-3.5 h-3.5 text-cyan-400" /> SHARED
                  </span>
                  {selectedReservationMode === 'SHARED' && (
                    <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                  )}
                </div>
                <p className="text-[10px] text-slate-400 leading-tight">
                  Allows non-interfering co-existence with other shared reservations.
                </p>
              </div>

              {/* DISRUPTIVE CARD */}
              <div
                onClick={() => setValue('reservationMode', 'DISRUPTIVE')}
                className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col justify-between space-y-1.5 ${
                  selectedReservationMode === 'DISRUPTIVE'
                    ? 'bg-amber-950/90 border-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                    : 'bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 font-extrabold text-amber-300 font-mono text-xs">
                    <Zap className="w-3.5 h-3.5 text-amber-400" /> DISRUPTIVE
                  </span>
                  {selectedReservationMode === 'DISRUPTIVE' && (
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  )}
                </div>
                <p className="text-[10px] text-slate-400 leading-tight">
                  Requires exclusive control. Overlapping reservations will trigger a conflict.
                </p>
              </div>
            </div>
          </div>

          {/* Dates with Hour, Min, Sec Support via Enterprise DateTimePicker */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <DateTimePicker
              label="START DATE & TIME"
              subLabel="HH:MM:SS"
              required
              value={watchStartDate}
              onChange={(val) => setValue('startDate', val, { shouldValidate: true })}
              error={errors.startDate?.message}
            />

            <DateTimePicker
              label="END DATE & TIME"
              subLabel="HH:MM:SS"
              required
              value={watchEndDate}
              onChange={(val) => setValue('endDate', val, { shouldValidate: true })}
              error={errors.endDate?.message}
            />
          </div>

          {/* AUTO APPROVAL SECTION */}
          <div
            className={`p-3.5 rounded-xl border transition-all space-y-3 ${
              hasConflict
                ? 'bg-slate-900/40 border-slate-800 opacity-80'
                : watchAutoApproval
                ? 'bg-[#0b1622] border-emerald-500/80 shadow-[0_0_15px_rgba(16,185,129,0.15)]'
                : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <label
                  onClick={(e) => {
                    if (hasConflict) {
                      e.preventDefault();
                      handleToggleAutoApproval();
                    }
                  }}
                  className={`flex items-center gap-2.5 cursor-pointer select-none font-bold text-xs ${
                    hasConflict ? 'text-slate-500 cursor-not-allowed' : 'text-slate-200 hover:text-white'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={Boolean(watchAutoApproval && !hasConflict)}
                    onChange={handleToggleAutoApproval}
                    disabled={hasConflict}
                    className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-emerald-500 focus:ring-emerald-500 focus:ring-offset-0 cursor-pointer disabled:cursor-not-allowed"
                  />
                  <span className="flex items-center gap-1.5 font-mono">
                    <CheckCheck className="w-4 h-4 text-emerald-400" />
                    Auto Approval
                  </span>
                </label>
                {hasConflict && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-800">
                    DISABLED (CONFLICT)
                  </span>
                )}
              </div>
              {watchAutoApproval && !hasConflict && (
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded">
                  ACTIVE RULE: {watchAutoApprovalRule || 'NONE'}
                </span>
              )}
            </div>

            {/* Conflict Disabled Warning Message */}
            {hasConflict && (
              <div
                onClick={() =>
                  showToast(
                    'Auto Approval cannot be selected because this reservation has a conflict. Please resolve the conflict before enabling Auto Approval.',
                    'error'
                  )
                }
                className="text-[11px] text-amber-400/90 bg-amber-950/30 border border-amber-800/60 p-2.5 rounded flex items-start gap-2 cursor-pointer"
              >
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Auto Approval cannot be selected because this reservation has a conflict.</strong> Please resolve the conflict before enabling Auto Approval.
                </span>
              </div>
            )}

            {/* Auto Approval Rules (Rendered when Auto Approval is ON and No Conflict) */}
            {watchAutoApproval && !hasConflict && (
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-400">
                    SELECT AUTO APPROVAL RULE <span className="text-orange-500">*</span>
                  </label>
                  <span className="text-[9px] font-mono text-slate-400">SELECT EXACTLY ONE RULE</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {/* Rule 1: All Requests */}
                  <div
                    onClick={() => handleSelectRule('ALL_REQUESTS')}
                    className={`p-2.5 rounded-lg border cursor-pointer transition-all flex flex-col justify-between space-y-1 ${
                      watchAutoApprovalRule === 'ALL_REQUESTS'
                        ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                        : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 font-bold font-mono text-xs text-emerald-300">
                        <input
                          type="checkbox"
                          checked={watchAutoApprovalRule === 'ALL_REQUESTS'}
                          onChange={() => handleSelectRule('ALL_REQUESTS')}
                          className="w-3.5 h-3.5 rounded text-emerald-500"
                        />
                        All Requests
                      </span>
                      {watchAutoApprovalRule === 'ALL_REQUESTS' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight">
                      Automatically approves all eligible requests (subject to conflict check).
                    </p>
                  </div>

                  {/* Rule 2: Priority Requests */}
                  <div
                    onClick={() => handleSelectRule('PRIORITY_REQUESTS')}
                    className={`p-2.5 rounded-lg border cursor-pointer transition-all flex flex-col justify-between space-y-1 ${
                      watchAutoApprovalRule === 'PRIORITY_REQUESTS'
                        ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                        : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 font-bold font-mono text-xs text-emerald-300">
                        <input
                          type="checkbox"
                          checked={watchAutoApprovalRule === 'PRIORITY_REQUESTS'}
                          onChange={() => handleSelectRule('PRIORITY_REQUESTS')}
                          className="w-3.5 h-3.5 rounded text-emerald-500"
                        />
                        Priority Requests
                      </span>
                      {watchAutoApprovalRule === 'PRIORITY_REQUESTS' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight">
                      Only High & Critical priority bookings qualify for automatic approval.
                    </p>
                  </div>

                  {/* Rule 3: Short Requests (< 3 Hours) */}
                  <div
                    onClick={() => handleSelectRule('SHORT_REQUESTS')}
                    className={`p-2.5 rounded-lg border cursor-pointer transition-all flex flex-col justify-between space-y-1 ${
                      watchAutoApprovalRule === 'SHORT_REQUESTS'
                        ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                        : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 font-bold font-mono text-xs text-emerald-300">
                        <input
                          type="checkbox"
                          checked={watchAutoApprovalRule === 'SHORT_REQUESTS'}
                          onChange={() => handleSelectRule('SHORT_REQUESTS')}
                          className="w-3.5 h-3.5 rounded text-emerald-500"
                        />
                        Short Requests
                      </span>
                      {watchAutoApprovalRule === 'SHORT_REQUESTS' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight">
                      Only duration strictly less than 3 hours qualifies for auto approval.
                    </p>
                  </div>
                </div>

                {errors.autoApprovalRule && (
                  <p className="text-xs text-red-400 font-mono mt-1">{errors.autoApprovalRule.message}</p>
                )}
              </div>
            )}
          </div>

          {/* LIVE DATE ORDER ERROR BANNER */}
          {isDateOrderInvalid && (
            <div className="bg-red-950/90 border-2 border-red-600 rounded p-3 text-red-200 text-xs flex items-center gap-2.5 animate-pulse font-mono">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              <span className="font-bold">Start date time is greater than the end date time.</span>
            </div>
          )}

          {/* AI BOOKING INTELLIGENCE CARD */}
          {aiAssistResult && (
            <div className="bg-[#0b1320] border border-orange-500/50 rounded-lg p-3.5 space-y-2.5 text-xs font-mono shadow-[0_0_15px_rgba(249,115,22,0.15)]">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 font-bold text-orange-400">
                  <BrainCircuit className="w-4 h-4 text-orange-400" /> AI BOOKING INTELLIGENCE
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    aiAssistResult.prediction.riskLevel === 'VERY_HIGH'
                      ? 'bg-red-950 text-red-400 border border-red-800'
                      : aiAssistResult.prediction.riskLevel === 'HIGH'
                      ? 'bg-orange-950 text-orange-400 border border-orange-800'
                      : aiAssistResult.prediction.riskLevel === 'MEDIUM'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  }`}
                >
                  RISK: {aiAssistResult.prediction.riskLevel} ({aiAssistResult.prediction.conflictProbability}%)
                </span>
              </div>

              {/* Explanations */}
              <div className="space-y-1 bg-black/40 p-2 rounded border border-slate-200 dark:border-slate-800 text-[11px]">
                {aiAssistResult.prediction.explanations.map((exp) => (
                  <div key={exp.id} className="flex items-start gap-1.5 text-slate-300">
                    <span className="text-orange-400 shrink-0">•</span>
                    <span>
                      <strong className="text-white">{exp.title}:</strong> {exp.detail}
                    </span>
                  </div>
                ))}
              </div>

              {/* Recommended Alternatives */}
              {aiAssistResult.recommendations.length > 0 && (
                <div className="space-y-1.5 pt-1 border-t border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-emerald-400 font-bold uppercase flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-emerald-400" /> RECOMMENDED ALTERNATIVES (LOWER CONFLICT RISK)
                  </span>

                  <div className="space-y-1.5">
                    {aiAssistResult.recommendations.map((rec) => (
                      <div
                        key={rec.environmentId}
                        className="bg-slate-900/90 p-2 rounded border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 hover:border-slate-700 transition-colors"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <strong className="text-white text-xs truncate">{rec.environmentName}</strong>
                            <span className="text-[10px] text-emerald-400 font-bold">{rec.compatibilityScore}% MATCH</span>
                          </div>
                          <p className="text-[10px] text-slate-400 truncate">{rec.reasoning}</p>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setValue('environmentId', rec.environmentId);
                            showToast(`Switched to recommended environment: ${rec.environmentName}`, 'success');
                          }}
                          className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] shrink-0 flex items-center gap-1 transition-colors"
                        >
                          USE THIS <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* LIVE CONFLICT WARNING ALERT */}
          {conflictingBookings.length > 0 && (
            <div className="bg-[#240c0f] border-2 border-red-600/90 rounded-lg p-3.5 space-y-2 text-xs font-mono animate-fadeIn">
              <div className="flex items-center gap-2 text-red-400 font-bold">
                <ShieldAlert className="w-4 h-4 text-red-400 animate-pulse" />
                <span>TIME COLLISION DETECTED ({conflictingBookings.length} OVERLAP)</span>
              </div>
              <p className="text-[11px] text-red-300/90 font-sans font-semibold">
                This environment has a conflicting disruptive reservation during the selected date and time.
              </p>
              <div className="space-y-1.5 bg-black/50 p-2.5 rounded border border-red-900/60 max-h-36 overflow-y-auto">
                {conflictingBookings.map((c) => (
                  <div key={c.id} className="text-[11px] border-b border-red-950/80 pb-1.5 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between text-white font-bold">
                      <span>
                        #{c.id} {c.purpose} ({c.team})
                      </span>
                      <span className="text-amber-400 text-[10px] font-mono">[MODE: {c.reservationMode || 'SHARED'}]</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span>Owner: <strong className="text-slate-200">{c.requestedBy}</strong></span>
                      <span className="text-red-300 font-mono">
                        {formatDisplayDateTime(c.startDate)} → {formatDisplayDateTime(c.endDate)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </form>
    </Modal>
  );
};
