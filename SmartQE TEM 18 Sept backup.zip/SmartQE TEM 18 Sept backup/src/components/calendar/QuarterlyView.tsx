import React from 'react';
import { Booking } from '../../types';
import {
  Calendar as CalendarIcon,
  AlertTriangle,
  Clock,
  ChevronRight,
  Zap,
  Users,
  CheckCircle2,
  Ban
} from 'lucide-react';
import { getBookingColorStyle, getModeBadgeStyle } from './bookingColorHelper';

interface QuarterlyViewProps {
  currentDate: Date;
  bookings: Booking[];
  conflictMap: Map<string, string[]>;
  onSelectBooking: (booking: Booking) => void;
  onNavigateToMonth?: (date: Date) => void;
}

const safeParseDate = (dateVal: string | Date | undefined | null): Date | null => {
  if (!dateVal) return null;
  if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
  const isoStr = String(dateVal).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d;
  const dRaw = new Date(dateVal);
  return isNaN(dRaw.getTime()) ? null : dRaw;
};

export const QuarterlyView: React.FC<QuarterlyViewProps> = ({
  currentDate,
  bookings,
  conflictMap,
  onSelectBooking,
  onNavigateToMonth,
}) => {
  const year = currentDate.getFullYear();
  const currentMonthIdx = currentDate.getMonth();
  const quarterIdx = Math.floor(currentMonthIdx / 3);
  const startMonth = quarterIdx * 3;

  const monthsInQuarter = [0, 1, 2].map((offset) => {
    return new Date(year, startMonth + offset, 1);
  });

  const getBookingsForMonth = (mDate: Date) => {
    const mYear = mDate.getFullYear();
    const mMonth = mDate.getMonth();
    const monthStart = new Date(mYear, mMonth, 1, 0, 0, 0, 0).getTime();
    const monthEnd = new Date(mYear, mMonth + 1, 0, 23, 59, 59, 999).getTime();

    return bookings.filter((b) => {
      const bStart = safeParseDate(b.startDate);
      const bEnd = safeParseDate(b.endDate);
      if (!bStart || !bEnd) return false;
      return bStart.getTime() <= monthEnd && bEnd.getTime() >= monthStart;
    });
  };

  const formatShortDate = (dtStr: string) => {
    if (!dtStr) return '';
    try {
      const d = safeParseDate(dtStr);
      if (!d) return dtStr;
      return `${d.toLocaleString('default', { month: 'short' })} ${d.getDate()}`;
    } catch {
      return dtStr;
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {monthsInQuarter.map((mDate, idx) => {
          const monthBookings = getBookingsForMonth(mDate);
          const monthName = mDate.toLocaleString('default', { month: 'long' });
          const daysInMonth = new Date(mDate.getFullYear(), mDate.getMonth() + 1, 0).getDate();
          const firstDayOffset = (new Date(mDate.getFullYear(), mDate.getMonth(), 1).getDay() + 6) % 7;

          const conflictCount = monthBookings.filter(
            (b) => b.status !== 'CANCELLED' && b.status !== 'REJECTED' && b.status !== 'AUTO_REJECTED' && conflictMap.has(b.id)
          ).length;

          return (
            <div
              key={idx}
              className="bg-[#0b1019] border border-slate-800 rounded-xl p-5 flex flex-col justify-between shadow-2xl space-y-4"
            >
              <div className="space-y-4">
                {/* Month Card Header */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-[10px] text-orange-400 font-bold uppercase tracking-wider">
                      MONTH {idx + 1} OF Q{quarterIdx + 1}
                    </span>
                    <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                      <CalendarIcon className="w-5 h-5 text-orange-500" />
                      {monthName} {year}
                    </h3>
                  </div>

                  <div className="text-right">
                    <span className="text-lg font-extrabold text-white block">
                      {monthBookings.length}
                    </span>
                    <span className="text-[9px] text-slate-500 uppercase font-semibold">Bookings</span>
                  </div>
                </div>

                {/* Mini Heatmap Grid */}
                <div className="bg-[#080d14] border border-slate-800/80 p-3 rounded-xl">
                  <div className="grid grid-cols-7 text-center text-[9px] font-bold text-slate-500 mb-1">
                    <span>M</span>
                    <span>T</span>
                    <span>W</span>
                    <span>T</span>
                    <span>F</span>
                    <span>S</span>
                    <span>S</span>
                  </div>
                  <div className="grid grid-cols-7 gap-1 text-center">
                    {Array.from({ length: firstDayOffset }).map((_, pIdx) => (
                      <div key={`pad-${pIdx}`} className="h-6" />
                    ))}

                    {Array.from({ length: daysInMonth }).map((_, dIdx) => {
                      const dayNum = dIdx + 1;
                      const dayDate = new Date(mDate.getFullYear(), mDate.getMonth(), dayNum);
                      const dayStart = new Date(dayDate.setHours(0, 0, 0, 0)).getTime();
                      const dayEnd = new Date(dayDate.setHours(23, 59, 59, 999)).getTime();

                      const dayBookings = monthBookings.filter((b) => {
                        const bStart = new Date(b.startDate).getTime();
                        const bEnd = new Date(b.endDate).getTime();
                        return bStart <= dayEnd && bEnd >= dayStart;
                      });

                      const hasConflict = dayBookings.some(
                        (b) => b.status !== 'CANCELLED' && b.status !== 'REJECTED' && b.status !== 'AUTO_REJECTED' && conflictMap.has(b.id)
                      );

                      return (
                        <div
                          key={`day-${dayNum}`}
                          title={`${dayNum}: ${dayBookings.length} bookings`}
                          className={`h-6 rounded flex items-center justify-center text-[10px] font-bold transition-colors ${
                            hasConflict
                              ? 'bg-pink-500 text-white font-black animate-pulse shadow-[0_0_8px_rgba(236,72,153,0.8)]'
                              : dayBookings.length > 0
                              ? 'bg-orange-500 text-white font-bold'
                              : 'text-slate-600 hover:bg-slate-800'
                          }`}
                        >
                          {dayNum}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Overlap / Conflict Summary */}
                {conflictCount > 0 && (
                  <div className="bg-pink-950/40 border border-pink-800 text-pink-300 p-2.5 rounded-lg text-[11px] flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-pink-400 shrink-0" />
                    <span>
                      <strong>{conflictCount} conflicting booking(s)</strong> require resolution this month.
                    </span>
                  </div>
                )}

                {/* List of Bookings */}
                <div className="space-y-2">
                  <div className="text-[10px] uppercase font-bold text-slate-400 flex items-center justify-between">
                    <span>SCHEDULED ALLOCATIONS ({monthBookings.length})</span>
                  </div>

                  <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
                    {monthBookings.length === 0 ? (
                      <div className="text-center py-6 text-slate-600 text-[11px] italic">
                        No bookings scheduled in {monthName}.
                      </div>
                    ) : (
                      monthBookings.map((b) => {
                        const isCancelled = b.status === 'CANCELLED';
                        const isRejected = b.status === 'REJECTED';
                        const isAutoRejected = b.status === 'AUTO_REJECTED';
                        const isInactive = isCancelled || isRejected || isAutoRejected;
                        const isConflict = !isInactive && conflictMap.has(b.id);
                        const colorStyle = getBookingColorStyle(b, isConflict);

                        return (
                          <div
                            key={b.id}
                            onClick={() => onSelectBooking(b)}
                            className={`p-2.5 rounded-lg border transition-all cursor-pointer shadow-sm select-none hover:scale-[1.01] ${colorStyle.containerClass}`}
                          >
                            <div className="flex items-center justify-between gap-1">
                              <span className={`font-bold text-xs truncate max-w-[130px] ${colorStyle.titleClass}`}>
                                {b.purpose}
                              </span>
                              <div className="flex items-center gap-1 shrink-0">
                                <span className={`text-[8px] px-1 py-0.2 rounded border uppercase flex items-center gap-0.5 font-bold ${colorStyle.statusBadge.badgeClass}`}>
                                  <span className={`w-1 h-1 rounded-full ${colorStyle.statusBadge.dotClass}`} />
                                  {colorStyle.statusBadge.label}
                                </span>
                                <span
                                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${colorStyle.badgeClass}`}
                                >
                                  {b.environmentName}
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center justify-between text-[10px] mt-1.5 pt-1.5 border-t border-slate-800/60">
                              <span className={`flex items-center gap-1 font-mono ${colorStyle.textClass}`}>
                                {colorStyle.iconType === 'conflict' ? (
                                  <AlertTriangle className="w-3 h-3 text-pink-400 shrink-0" />
                                ) : colorStyle.iconType === 'cancelled' ? (
                                  <Ban className="w-3 h-3 text-slate-400 shrink-0" />
                                ) : colorStyle.iconType === 'rejected' ? (
                                  <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
                                ) : colorStyle.iconType === 'pending' ? (
                                  <Clock className="w-3 h-3 text-yellow-400 shrink-0" />
                                ) : colorStyle.iconType === 'disruptive' ? (
                                  <Zap className="w-3 h-3 text-orange-400 shrink-0" />
                                ) : colorStyle.iconType === 'approved' ? (
                                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                                ) : (
                                  <Users className="w-3 h-3 text-cyan-400 shrink-0" />
                                )}
                                {formatShortDate(b.startDate)} → {formatShortDate(b.endDate)}
                              </span>
                              <div className="flex items-center gap-1">
                                <span className={`text-[8px] px-1 py-0.2 rounded border uppercase font-mono font-bold ${getModeBadgeStyle(b.reservationMode).badgeClass}`}>
                                  {getModeBadgeStyle(b.reservationMode).label}
                                </span>
                                <span className={`text-[9px] ${colorStyle.subtextClass}`}>{b.businessUnit}</span>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>

              {onNavigateToMonth && (
                <button
                  onClick={() => onNavigateToMonth(mDate)}
                  className="w-full mt-2 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-orange-400 hover:text-orange-300 border border-slate-800 text-[11px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors"
                >
                  View Full Month <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
