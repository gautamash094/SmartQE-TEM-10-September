import { Booking } from '../../types';

export type BookingColorCategory = 'CONFLICT' | 'CANCELLED' | 'REJECTED' | 'PENDING' | 'DISRUPTIVE' | 'SHARED' | 'APPROVED';

export interface StatusBadgeConfig {
  label: string;
  badgeClass: string;
  dotClass: string;
  iconType: 'approved' | 'pending' | 'conflict' | 'rejected' | 'cancelled';
  iconColorClass: string;
}

export interface BookingColorConfig {
  category: BookingColorCategory;
  label: string;
  containerClass: string;
  titleClass: string;
  subtextClass: string;
  badgeClass: string;
  tagClass: string;
  iconType: 'conflict' | 'cancelled' | 'rejected' | 'pending' | 'disruptive' | 'shared' | 'approved';
  iconColorClass: string;
  dotClass: string;
  borderClass: string;
  textClass: string;
  statusBadge: StatusBadgeConfig;
}

export const BOOKING_LEGEND_ITEMS = [
  {
    key: 'APPROVED',
    label: 'Approved',
    dot: 'bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.8)]',
    border: 'border-emerald-500/80',
    bg: 'bg-emerald-950/50',
    textColor: 'text-emerald-300',
    description: 'Approved reservation (Green Bar & Badge)'
  },
  {
    key: 'PENDING',
    label: 'Pending Approval',
    dot: 'bg-yellow-400 shadow-[0_0_8px_rgba(250,204,21,0.8)]',
    border: 'border-yellow-500/80',
    bg: 'bg-yellow-950/50',
    textColor: 'text-yellow-300',
    description: 'Pending workflow approval (Yellow Bar & Badge)'
  },
  {
    key: 'SHARED',
    label: 'Shared Mode',
    dot: 'bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.8)]',
    border: 'border-cyan-500/80',
    bg: 'bg-cyan-950/50',
    textColor: 'text-cyan-300',
    description: 'Shared environment allocation (Cyan Pill)'
  },
  {
    key: 'DISRUPTIVE',
    label: 'Disruptive Mode',
    dot: 'bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]',
    border: 'border-orange-500/80',
    bg: 'bg-orange-950/50',
    textColor: 'text-orange-300',
    description: 'Exclusive lock allocation (Orange Pill)'
  },
  {
    key: 'CONFLICT',
    label: 'Conflict',
    dot: 'bg-pink-400 shadow-[0_0_10px_rgba(244,114,182,0.9)] animate-pulse',
    border: 'border-pink-500/90',
    bg: 'bg-pink-950/50',
    textColor: 'text-pink-300',
    description: 'Overlapping disruptive conflict (Neon Pink Bar & Badge)'
  }
];

export const getBookingStatusBadge = (booking: Booking, isConflict: boolean): StatusBadgeConfig => {
  if (isConflict) {
    return {
      label: 'CONFLICT',
      badgeClass: 'bg-pink-950/90 text-pink-300 border-pink-500/90 shadow-[0_0_8px_rgba(244,114,182,0.4)]',
      dotClass: 'bg-pink-400 animate-pulse',
      iconType: 'conflict',
      iconColorClass: 'text-pink-400',
    };
  }

  const status = String(booking.status || 'CONFIRMED').toUpperCase();

  if (status === 'CANCELLED') {
    return {
      label: 'CANCELLED',
      badgeClass: 'bg-slate-900/90 text-slate-400 border-slate-700',
      dotClass: 'bg-slate-400',
      iconType: 'cancelled',
      iconColorClass: 'text-slate-400',
    };
  }

  if (status === 'REJECTED' || status === 'AUTO_REJECTED') {
    return {
      label: 'REJECTED',
      badgeClass: 'bg-rose-950/90 text-rose-300 border-rose-600/90 shadow-[0_0_8px_rgba(244,63,94,0.4)]',
      dotClass: 'bg-rose-400',
      iconType: 'rejected',
      iconColorClass: 'text-rose-400',
    };
  }

  if (status === 'PENDING') {
    return {
      label: 'PENDING',
      badgeClass: 'bg-yellow-950/90 text-yellow-300 border-yellow-500/90 shadow-[0_0_8px_rgba(234,179,8,0.4)]',
      dotClass: 'bg-yellow-400 animate-pulse',
      iconType: 'pending',
      iconColorClass: 'text-yellow-400',
    };
  }

  // CONFIRMED / APPROVED
  return {
    label: 'APPROVED',
    badgeClass: 'bg-emerald-950/90 text-emerald-300 border-emerald-600/90 shadow-[0_0_8px_rgba(16,185,129,0.4)]',
    dotClass: 'bg-emerald-400',
    iconType: 'approved',
    iconColorClass: 'text-emerald-400',
  };
};

export const getModeBadgeStyle = (mode?: string | null) => {
  const isDisruptive = (mode || 'SHARED').toUpperCase() === 'DISRUPTIVE';
  if (isDisruptive) {
    return {
      label: '⚡ DISRUPTIVE',
      badgeClass: 'bg-orange-950/90 text-orange-300 border-orange-500/90 shadow-[0_0_8px_rgba(249,115,22,0.35)] font-bold',
    };
  }
  return {
    label: '👥 SHARED',
    badgeClass: 'bg-cyan-950/90 text-cyan-300 border-cyan-500/90 shadow-[0_0_8px_rgba(6,182,212,0.35)] font-bold',
  };
};

export const getBookingVisualCategory = (booking: Booking, isConflict: boolean): BookingColorCategory => {
  // Precedence rule:
  // 1. Conflict takes highest precedence
  if (isConflict) return 'CONFLICT';

  // 2. Cancelled
  const status = String(booking.status || 'CONFIRMED').toUpperCase();
  if (status === 'CANCELLED') return 'CANCELLED';

  // 3. Rejected
  if (status === 'REJECTED' || status === 'AUTO_REJECTED') return 'REJECTED';

  // 4. Pending Approval -> Distinct Yellow Visual Category
  if (status === 'PENDING') return 'PENDING';

  // 5. Approved / Confirmed reservations -> Full Green Bar
  if (status === 'CONFIRMED' || status === 'APPROVED') return 'APPROVED';

  // 6. If other / by mode:
  const mode = (booking.reservationMode || 'SHARED').toUpperCase();
  if (mode === 'DISRUPTIVE') return 'DISRUPTIVE';
  
  return 'SHARED';
};

export const getBookingColorStyle = (booking: Booking, isConflict: boolean): BookingColorConfig => {
  const category = getBookingVisualCategory(booking, isConflict);
  const statusBadge = getBookingStatusBadge(booking, isConflict);

  switch (category) {
    case 'CONFLICT':
      return {
        category,
        label: 'Conflict',
        containerClass: 'bg-gradient-to-r from-pink-950/95 via-[#500724] to-fuchsia-950/95 border-pink-500 hover:border-pink-400 text-pink-100 shadow-[0_0_14px_rgba(236,72,153,0.45)] animate-pulse',
        titleClass: 'text-pink-100 font-extrabold',
        subtextClass: 'text-pink-300/80',
        badgeClass: 'bg-pink-950/90 text-pink-300 border-pink-700',
        tagClass: 'text-pink-300 bg-pink-950/90 border-pink-700/80',
        iconType: 'conflict',
        iconColorClass: 'text-pink-400',
        dotClass: 'bg-pink-400',
        borderClass: 'border-pink-500',
        textClass: 'text-pink-300',
        statusBadge,
      };

    case 'CANCELLED':
      return {
        category,
        label: 'Cancelled',
        containerClass: 'bg-gradient-to-r from-slate-900/90 via-[#1e293b]/90 to-slate-900/90 border-slate-600 hover:border-slate-500 text-slate-300 opacity-60 shadow-sm',
        titleClass: 'text-slate-300 line-through',
        subtextClass: 'text-slate-400',
        badgeClass: 'bg-slate-900 text-slate-400 border-slate-700',
        tagClass: 'text-slate-400 bg-slate-900 border-slate-700',
        iconType: 'cancelled',
        iconColorClass: 'text-slate-400',
        dotClass: 'bg-slate-400',
        borderClass: 'border-slate-600',
        textClass: 'text-slate-300',
        statusBadge,
      };

    case 'REJECTED':
      return {
        category,
        label: 'Rejected',
        containerClass: 'bg-gradient-to-r from-rose-950/95 via-[#4c0519] to-rose-900/95 border-rose-500 hover:border-rose-400 text-rose-100 shadow-[0_0_12px_rgba(244,63,94,0.35)]',
        titleClass: 'text-rose-100 font-extrabold',
        subtextClass: 'text-rose-300/80',
        badgeClass: 'bg-rose-950/90 text-rose-300 border-rose-700',
        tagClass: 'text-rose-300 bg-rose-950/90 border-rose-700/80',
        iconType: 'rejected',
        iconColorClass: 'text-rose-400',
        dotClass: 'bg-rose-400',
        borderClass: 'border-rose-500',
        textClass: 'text-rose-300',
        statusBadge,
      };

    case 'PENDING':
      return {
        category,
        label: 'Pending Approval',
        containerClass: 'bg-gradient-to-r from-yellow-950/95 via-[#422006] to-yellow-900/95 border-yellow-500/90 hover:border-yellow-400 text-yellow-100 shadow-[0_0_12px_rgba(234,179,8,0.35)] hover:shadow-[0_0_16px_rgba(234,179,8,0.5)]',
        titleClass: 'text-yellow-100 font-extrabold',
        subtextClass: 'text-yellow-300/80',
        badgeClass: 'bg-yellow-950/90 text-yellow-300 border-yellow-600',
        tagClass: 'text-yellow-300 bg-yellow-950/90 border-yellow-600/80',
        iconType: 'pending',
        iconColorClass: 'text-yellow-400',
        dotClass: 'bg-yellow-400',
        borderClass: 'border-yellow-500',
        textClass: 'text-yellow-300',
        statusBadge,
      };

    case 'DISRUPTIVE':
      return {
        category,
        label: 'Disruptive Mode',
        containerClass: 'bg-gradient-to-r from-orange-950/95 via-[#431407] to-amber-950/95 border-orange-500/90 hover:border-orange-400 text-orange-100 shadow-[0_0_12px_rgba(249,115,22,0.35)] hover:shadow-[0_0_16px_rgba(249,115,22,0.5)]',
        titleClass: 'text-orange-100 font-extrabold',
        subtextClass: 'text-orange-300/80',
        badgeClass: 'bg-orange-950/90 text-orange-300 border-orange-700',
        tagClass: 'text-orange-300 bg-orange-950/90 border-orange-700/80',
        iconType: statusBadge.label === 'APPROVED' ? 'approved' : 'disruptive',
        iconColorClass: statusBadge.label === 'APPROVED' ? 'text-emerald-400' : 'text-orange-400',
        dotClass: 'bg-orange-500',
        borderClass: 'border-orange-500',
        textClass: 'text-orange-300',
        statusBadge,
      };

    case 'APPROVED':
      return {
        category,
        label: 'Approved',
        containerClass: 'bg-gradient-to-r from-emerald-950/95 via-[#064e3b] to-emerald-900/95 border-emerald-500/90 hover:border-emerald-400 text-emerald-100 shadow-[0_0_12px_rgba(16,185,129,0.35)]',
        titleClass: 'text-emerald-100 font-extrabold',
        subtextClass: 'text-emerald-300/80',
        badgeClass: 'bg-emerald-950/90 text-emerald-300 border-emerald-700',
        tagClass: 'text-emerald-300 bg-emerald-950/90 border-emerald-700/80',
        iconType: 'approved',
        iconColorClass: 'text-emerald-400',
        dotClass: 'bg-emerald-400',
        borderClass: 'border-emerald-500',
        textClass: 'text-emerald-300',
        statusBadge,
      };

    case 'SHARED':
    default:
      return {
        category: 'SHARED',
        label: 'Shared Mode',
        containerClass: 'bg-gradient-to-r from-cyan-950/95 via-[#083344] to-sky-950/95 border-cyan-500/90 hover:border-cyan-400 text-cyan-100 shadow-[0_0_12px_rgba(6,182,212,0.35)] hover:shadow-[0_0_16px_rgba(6,182,212,0.5)]',
        titleClass: 'text-cyan-100 font-extrabold',
        subtextClass: 'text-cyan-300/80',
        badgeClass: 'bg-cyan-950/90 text-cyan-300 border-cyan-700',
        tagClass: 'text-cyan-300 bg-cyan-950/90 border-cyan-700/80',
        iconType: statusBadge.label === 'APPROVED' ? 'approved' : 'shared',
        iconColorClass: statusBadge.label === 'APPROVED' ? 'text-emerald-400' : 'text-cyan-400',
        dotClass: 'bg-cyan-400',
        borderClass: 'border-cyan-500',
        textClass: 'text-cyan-300',
        statusBadge,
      };
  }
};
