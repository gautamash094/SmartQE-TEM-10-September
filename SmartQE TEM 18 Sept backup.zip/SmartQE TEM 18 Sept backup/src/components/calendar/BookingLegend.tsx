import React from 'react';
import { BOOKING_LEGEND_ITEMS } from './bookingColorHelper';

export const BookingLegend: React.FC = () => {
  return (
    <div className="bg-[#0c121e] border border-slate-800/90 rounded-xl p-3 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono text-xs select-none">
      <div className="flex items-center gap-2 shrink-0">
        <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/80">
          LEGEND
        </span>
        <span className="text-[11px] text-slate-400 hidden md:inline">
          Color-coded reservation mode and status mapping:
        </span>
      </div>

      <div className="flex flex-wrap items-center gap-2 sm:gap-3">
        {BOOKING_LEGEND_ITEMS.map((item) => (
          <div
            key={item.key}
            title={item.description}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border ${item.border} ${item.bg} transition-all hover:scale-105`}
          >
            <span className={`w-2.5 h-2.5 rounded-full ${item.dot} shrink-0`} />
            <span className={`font-bold text-[11px] ${item.textColor}`}>
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};