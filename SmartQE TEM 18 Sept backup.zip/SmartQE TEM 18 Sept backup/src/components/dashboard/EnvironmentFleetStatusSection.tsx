import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTEM } from '../../context/TEMContext';
import { StatusBadge } from '../common/StatusBadge';
import { CardSkeleton } from '../common/Skeleton';
import { EnvironmentProfile, ServerDetail, SoftwareDetail } from '../../types/environmentDetails';
import {
  Server,
  Cpu,
  Layers,
  Activity,
  Filter,
  RefreshCw,
  ArrowRight,
  ShieldAlert,
  Boxes,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Info,
  X,
  User,
  Building2,
  HardDrive,
  Globe,
  Tag
} from 'lucide-react';

export type FleetCurrentStatus = 'AVAILABLE' | 'RESERVED' | 'MAINTENANCE' | 'UNAVAILABLE' | 'DEGRADED' | 'CONFLICTING';

export interface FleetEnvironmentItem {
  id: string;
  name: string;
  type: string;
  description: string;
  initialStatus: string;
  businessUnit: string;
  account: string;
  owner: string;
  serverCount: number;
  softwareCount: number;
  servers: ServerDetail[];
  software: SoftwareDetail[];
  activeBooking?: {
    id: string;
    businessUnit: string;
    project?: string;
    application?: string;
    requestedBy: string;
    team: string;
    startDate: string;
    endDate: string;
    status: string;
  };
  activeIncidentsCount: number;
  currentStatus: FleetCurrentStatus;
  updatedAt: string;
}

export const EnvironmentFleetStatusSection: React.FC = () => {
  const navigate = useNavigate();
  const {
    // Environment Details is the single source of truth for environments
    environmentProfiles,
    servers,
    softwareList,
    bookings,
    incidents,
    businessUnits,
    projects,
    isLoading
  } = useTEM();

  // Selected Card for Modal Detail View
  const [selectedFleetItem, setSelectedFleetItem] = useState<FleetEnvironmentItem | null>(null);

  // Filters State
  const [buFilter, setBuFilter] = useState<string>('ALL');
  const [accountFilter, setAccountFilter] = useState<string>('ALL');
  const [tierFilter, setTierFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [ownerFilter, setOwnerFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // 1. Build Consolidated Fleet Items directly from Environment Details
  const allFleetItems = useMemo<FleetEnvironmentItem[]>(() => {
    const nowMs = Date.now();

    // Create env -> BU map from bookings
    const envToBuMap = new Map<string, string>();
    bookings?.forEach((b) => {
      if (b.businessUnit && b.environmentName) {
        envToBuMap.set(b.environmentName.toLowerCase(), b.businessUnit);
      }
      if (b.businessUnit && b.environmentId) {
        envToBuMap.set(b.environmentId.toLowerCase(), b.businessUnit);
      }
    });

    return (environmentProfiles || []).map((profile) => {
      // Find servers and software linked to this profile
      const linkedServers = (servers || []).filter(
        (s) => profile.serverIds?.includes(s.id) || s.environmentName === profile.name
      );
      const linkedSoftware = (softwareList || []).filter((s) => profile.softwareIds?.includes(s.id));

      // Check active booking right now
      const activeBooking = (bookings || []).find((b) => {
        if (
          b.status === 'CANCELLED' ||
          b.status === 'REJECTED' ||
          b.status === 'AUTO_REJECTED'
        )
          return false;

        const matchEnv =
          (b.environmentId && b.environmentId === profile.id) ||
          (b.environmentName && b.environmentName.toLowerCase() === profile.name.toLowerCase());
        if (!matchEnv) return false;

        const startMs = b.startDate ? new Date(b.startDate).getTime() : 0;
        const endMs = b.endDate ? new Date(b.endDate).getTime() : 0;

        // Check if currently within active booking window or confirmed
        return (startMs <= nowMs && endMs >= nowMs) || b.status === 'CONFIRMED' || b.status === 'CONFLICT';
      });

      // Count active incidents
      const activeIncs = (incidents || []).filter(
        (i) =>
          i.status !== 'RESOLVED' &&
          ((i.environmentId && i.environmentId === profile.id) ||
            (i.environmentName && i.environmentName.toLowerCase() === profile.name.toLowerCase()))
      ).length;

      // Determine dynamic Current Status
      let currentStatus: FleetCurrentStatus = 'AVAILABLE';
      if (activeBooking?.status === 'CONFLICT') {
        currentStatus = 'CONFLICTING';
      } else if (activeBooking) {
        currentStatus = 'RESERVED';
      } else if (profile.status === 'DOWN') {
        currentStatus = 'UNAVAILABLE';
      } else if (profile.status === 'MAINTENANCE') {
        currentStatus = 'MAINTENANCE';
      } else if (profile.status === 'DEGRADED') {
        currentStatus = 'DEGRADED';
      } else {
        currentStatus = 'AVAILABLE';
      }

      // Resolve Business Unit
      const bu =
        (activeBooking && activeBooking.businessUnit) ||
        envToBuMap.get(profile.name.toLowerCase()) ||
        envToBuMap.get(profile.id.toLowerCase()) ||
        profile.ownerTeam ||
        'General Banking';

      return {
        id: profile.id,
        name: profile.name,
        type: profile.type || 'Development',
        description: profile.description || 'Enterprise test environment instance',
        initialStatus: profile.status || 'HEALTHY',
        businessUnit: bu,
        account: profile.networkZone || 'Enterprise Core',
        owner: profile.ownerTeam || 'Platform QE',
        serverCount: linkedServers.length,
        softwareCount: linkedSoftware.length,
        servers: linkedServers,
        software: linkedSoftware,
        activeBooking: activeBooking
          ? {
              id: activeBooking.id,
              businessUnit: activeBooking.businessUnit,
              project: activeBooking.project,
              application: activeBooking.application,
              requestedBy: activeBooking.requestedBy,
              team: activeBooking.team,
              startDate: activeBooking.startDate,
              endDate: activeBooking.endDate,
              status: activeBooking.status
            }
          : undefined,
        activeIncidentsCount: activeIncs,
        currentStatus,
        updatedAt: profile.updatedAt || new Date().toISOString()
      };
    });
  }, [environmentProfiles, servers, softwareList, bookings, incidents]);

  // 2. Filter Options for Dropdowns
  const availableBUs = useMemo(() => {
    const set = new Set<string>();
    (businessUnits || []).forEach((b) => set.add(b.name));
    allFleetItems.forEach((f) => f.businessUnit && set.add(f.businessUnit));
    return Array.from(set);
  }, [businessUnits, allFleetItems]);

  const availableAccounts = useMemo(() => {
    const set = new Set<string>();
    (projects || []).forEach((p) => set.add(p.name));
    allFleetItems.forEach((f) => f.account && set.add(f.account));
    return Array.from(set);
  }, [projects, allFleetItems]);

  const availableTiers = useMemo(() => {
    const set = new Set<string>([
      'Development',
      'QA / Testing',
      'UAT / Staging',
      'Production',
      'Performance / Stress',
      'Disaster Recovery (DR)',
      'Sandbox'
    ]);
    allFleetItems.forEach((f) => f.type && set.add(f.type));
    return Array.from(set);
  }, [allFleetItems]);

  const availableOwners = useMemo(() => {
    const set = new Set<string>();
    allFleetItems.forEach((f) => f.owner && set.add(f.owner));
    return Array.from(set);
  }, [allFleetItems]);

  // 3a. Base Fleet Items (Filtered by Search, BU, Account, Tier, Owner - EXCLUDING statusFilter)
  const baseFleetItems = useMemo(() => {
    return allFleetItems.filter((item) => {
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchSearch =
          item.name.toLowerCase().includes(q) ||
          item.id.toLowerCase().includes(q) ||
          item.businessUnit.toLowerCase().includes(q) ||
          item.account.toLowerCase().includes(q) ||
          item.owner.toLowerCase().includes(q) ||
          item.type.toLowerCase().includes(q);
        if (!matchSearch) return false;
      }

      if (buFilter !== 'ALL' && item.businessUnit.toLowerCase() !== buFilter.toLowerCase()) {
        return false;
      }
      if (accountFilter !== 'ALL' && item.account.toLowerCase() !== accountFilter.toLowerCase()) {
        return false;
      }
      if (tierFilter !== 'ALL' && item.type.toLowerCase() !== tierFilter.toLowerCase()) {
        return false;
      }
      if (ownerFilter !== 'ALL' && item.owner.toLowerCase() !== ownerFilter.toLowerCase()) {
        return false;
      }
      return true;
    });
  }, [allFleetItems, searchQuery, buFilter, accountFilter, tierFilter, ownerFilter]);

  // 3b. Filtered Fleet Items for Grid Matrix (Includes statusFilter)
  const filteredFleetItems = useMemo(() => {
    return baseFleetItems.filter((item) => {
      if (statusFilter === 'ALL') return true;
      if (statusFilter === 'RESERVED') {
        return item.currentStatus === 'RESERVED' || item.currentStatus === 'CONFLICTING';
      }
      return item.currentStatus === statusFilter;
    });
  }, [baseFleetItems, statusFilter]);

  // 4. Dynamic Summary Counts (Derived from baseFleetItems for consistent KPI metrics)
  const statusSummary = useMemo(() => {
    const total = baseFleetItems.length;
    let available = 0;
    let reserved = 0;
    let maintenance = 0;
    let unavailable = 0;
    let degraded = 0;
    let conflicting = 0;

    baseFleetItems.forEach((item) => {
      if (item.currentStatus === 'AVAILABLE') available++;
      else if (item.currentStatus === 'RESERVED') reserved++;
      else if (item.currentStatus === 'MAINTENANCE') maintenance++;
      else if (item.currentStatus === 'UNAVAILABLE') unavailable++;
      else if (item.currentStatus === 'DEGRADED') degraded++;
      else if (item.currentStatus === 'CONFLICTING') conflicting++;
    });

    return { total, available, reserved, maintenance, unavailable, degraded, conflicting };
  }, [baseFleetItems]);

  // 5. Data for Tier Breakdown Chart (Derived from baseFleetItems)
  const tierBreakdown = useMemo(() => {
    const counts: Record<string, number> = {};
    baseFleetItems.forEach((item) => {
      const tier = item.type || 'Other';
      counts[tier] = (counts[tier] || 0) + 1;
    });
    const maxVal = Math.max(...Object.values(counts), 1);
    return Object.entries(counts).map(([tier, count]) => ({
      tier,
      count,
      pct: Math.round((count / (baseFleetItems.length || 1)) * 100),
      barWidth: Math.round((count / maxVal) * 100)
    }));
  }, [baseFleetItems]);

  // 6. Data for BU Breakdown Chart (Derived from baseFleetItems)
  const buBreakdown = useMemo(() => {
    const counts: Record<string, number> = {};
    baseFleetItems.forEach((item) => {
      const bu = item.businessUnit || 'General';
      counts[bu] = (counts[bu] || 0) + 1;
    });
    const maxVal = Math.max(...Object.values(counts), 1);
    return Object.entries(counts).map(([bu, count]) => ({
      bu,
      count,
      pct: Math.round((count / (baseFleetItems.length || 1)) * 100),
      barWidth: Math.round((count / maxVal) * 100)
    }));
  }, [baseFleetItems]);

  const hasActiveFilters =
    buFilter !== 'ALL' ||
    accountFilter !== 'ALL' ||
    tierFilter !== 'ALL' ||
    statusFilter !== 'ALL' ||
    ownerFilter !== 'ALL' ||
    searchQuery !== '';

  const handleResetFilters = () => {
    setBuFilter('ALL');
    setAccountFilter('ALL');
    setTierFilter('ALL');
    setStatusFilter('ALL');
    setOwnerFilter('ALL');
    setSearchQuery('');
  };

  return (
    <div className="space-y-6 w-full min-w-0">
      {/* Fleet Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              ENVIRONMENT DETAILS · SINGLE SOURCE OF TRUTH
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
              LIVE SYNC
            </span>
          </div>
          <h2 className="text-xl font-extrabold text-white tracking-tight mt-1 flex items-center gap-2">
            <Server className="w-5 h-5 text-orange-400" /> Environment Fleet Status
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time status, tier distributions, resource linkages, and reservation telemetry sourced directly from Environment Details.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono font-semibold text-slate-400 hover:text-white bg-slate-900 border border-slate-200 dark:border-slate-800 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" /> RESET FILTERS
            </button>
          )}
          <button
            onClick={() => navigate('/environment-details')}
            className="flex items-center gap-1.5 px-4 py-2 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.3)]"
          >
            <Cpu className="w-4 h-4" /> MANAGE DETAILS
          </button>
        </div>
      </div>

      {/* 1. Dashboard Filters Bar */}
      <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-4 space-y-3 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
            <Filter className="w-3.5 h-3.5 text-orange-400" /> FLEET DASHBOARD FILTERS
          </div>
          <span className="text-[11px] font-mono text-slate-500">
            Showing {filteredFleetItems.length} of {allFleetItems.length} environments
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Search */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-500 mb-1">
              SEARCH
            </label>
            <input autoComplete="off" data-lpignore="true"
              type="text"
              placeholder="Search env name, ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Business Unit */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-500 mb-1">
              BUSINESS UNIT
            </label>
            <select
              value={buFilter}
              onChange={(e) => setBuFilter(e.target.value)}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-2 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">ALL BUs</option>
              {availableBUs.map((bu) => (
                <option key={bu} value={bu}>
                  {bu}
                </option>
              ))}
            </select>
          </div>

          {/* Account / Zone */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-500 mb-1">
              ACCOUNT / ZONE
            </label>
            <select
              value={accountFilter}
              onChange={(e) => setAccountFilter(e.target.value)}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-2 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">ALL ACCOUNTS</option>
              {availableAccounts.map((acc) => (
                <option key={acc} value={acc}>
                  {acc}
                </option>
              ))}
            </select>
          </div>

          {/* Tier / Type */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-500 mb-1">
              TIER / TYPE
            </label>
            <select
              value={tierFilter}
              onChange={(e) => setTierFilter(e.target.value)}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-2 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">ALL TIERS</option>
              {availableTiers.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* Current Status */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-500 mb-1">
              CURRENT STATUS
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-2 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">ALL STATUSES</option>
              <option value="AVAILABLE">AVAILABLE</option>
              <option value="RESERVED">RESERVED / BOOKED</option>
              <option value="MAINTENANCE">MAINTENANCE</option>
              <option value="UNAVAILABLE">UNAVAILABLE / DOWN</option>
              <option value="DEGRADED">DEGRADED</option>
              <option value="CONFLICTING">CONFLICTING</option>
            </select>
          </div>

          {/* Owner */}
          <div>
            <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-500 mb-1">
              OWNER TEAM
            </label>
            <select
              value={ownerFilter}
              onChange={(e) => setOwnerFilter(e.target.value)}
              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-2 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">ALL OWNERS</option>
              {availableOwners.map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 2. Dynamic Environment Status Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 gap-3">
        {/* Total */}
        <div
          onClick={() => setStatusFilter('ALL')}
          className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
            statusFilter === 'ALL'
              ? 'bg-[#141e2e] border-orange-500/80 shadow-[0_0_12px_rgba(249,115,22,0.2)]'
              : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'
          }`}
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">TOTAL</span>
          <div className="text-2xl font-extrabold text-white font-mono mt-1">{statusSummary.total}</div>
          <p className="text-[10px] font-mono text-slate-500 mt-1">FLEET SIZE</p>
        </div>

        {/* Available */}
        <div
          onClick={() => setStatusFilter('AVAILABLE')}
          className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
            statusFilter === 'AVAILABLE'
              ? 'bg-emerald-950/40 border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
              : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'
          }`}
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-400">AVAILABLE</span>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">{statusSummary.available}</div>
          <p className="text-[10px] font-mono text-emerald-500/80 mt-1">READY TO BOOK</p>
        </div>

        {/* Reserved / Booked */}
        <div
          onClick={() => setStatusFilter('RESERVED')}
          className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
            statusFilter === 'RESERVED'
              ? 'bg-orange-950/40 border-orange-500 shadow-[0_0_12px_rgba(249,115,22,0.2)]'
              : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'
          }`}
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-orange-400">RESERVED</span>
          <div className="text-2xl font-extrabold text-orange-400 font-mono mt-1">{statusSummary.reserved}</div>
          <p className="text-[10px] font-mono text-orange-500/80 mt-1">ACTIVE BOOKING</p>
        </div>

        {/* Maintenance */}
        <div
          onClick={() => setStatusFilter('MAINTENANCE')}
          className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
            statusFilter === 'MAINTENANCE'
              ? 'bg-blue-950/40 border-blue-500 shadow-[0_0_12px_rgba(59,130,246,0.2)]'
              : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'
          }`}
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-400">MAINTENANCE</span>
          <div className="text-2xl font-extrabold text-blue-400 font-mono mt-1">{statusSummary.maintenance}</div>
          <p className="text-[10px] font-mono text-blue-500/80 mt-1">SCHEDULED OPS</p>
        </div>

        {/* Unavailable / Down */}
        <div
          onClick={() => setStatusFilter('UNAVAILABLE')}
          className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
            statusFilter === 'UNAVAILABLE'
              ? 'bg-red-950/40 border-red-500 shadow-[0_0_12px_rgba(239,68,68,0.2)]'
              : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'
          }`}
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-red-400">UNAVAILABLE</span>
          <div className="text-2xl font-extrabold text-red-400 font-mono mt-1">{statusSummary.unavailable}</div>
          <p className="text-[10px] font-mono text-red-500/80 mt-1">DOWN / OUTAGE</p>
        </div>

        {/* Degraded */}
        <div
          onClick={() => setStatusFilter('DEGRADED')}
          className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
            statusFilter === 'DEGRADED'
              ? 'bg-amber-950/40 border-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.2)]'
              : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'
          }`}
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400">DEGRADED</span>
          <div className="text-2xl font-extrabold text-amber-400 font-mono mt-1">{statusSummary.degraded}</div>
          <p className="text-[10px] font-mono text-amber-500/80 mt-1">IMPAIRED STATE</p>
        </div>

        {/* Conflicting */}
        <div
          onClick={() => setStatusFilter('CONFLICTING')}
          className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
            statusFilter === 'CONFLICTING'
              ? 'bg-rose-950/40 border-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.2)]'
              : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'
          }`}
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-rose-400">CONFLICTING</span>
          <div className="text-2xl font-extrabold text-rose-400 font-mono mt-1">{statusSummary.conflicting}</div>
          <p className="text-[10px] font-mono text-rose-500/80 mt-1">OVERLAP RISK</p>
        </div>
      </div>

      {/* 3. Interactive Graphical Data / Visualizations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Donut Chart: Status Distribution */}
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400" /> STATUS DISTRIBUTION
            </h3>
            <span className="text-[11px] font-mono text-slate-500">Interactive</span>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6 my-2">
            {/* SVG Donut */}
            <div className="relative w-36 h-36 shrink-0 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-900"
                  strokeWidth="3.8"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                {(() => {
                  const tot = statusSummary.total || 1;
                  const segments = [
                    { status: 'AVAILABLE', count: statusSummary.available, color: 'text-emerald-500' },
                    { status: 'RESERVED', count: statusSummary.reserved, color: 'text-orange-500' },
                    { status: 'MAINTENANCE', count: statusSummary.maintenance, color: 'text-blue-500' },
                    { status: 'UNAVAILABLE', count: statusSummary.unavailable, color: 'text-red-500' },
                    { status: 'DEGRADED', count: statusSummary.degraded, color: 'text-amber-500' },
                    { status: 'CONFLICTING', count: statusSummary.conflicting, color: 'text-rose-500' },
                  ];

                  let currentOffset = 0;
                  return segments.map((seg) => {
                    if (seg.count <= 0) return null;
                    const pct = (seg.count / tot) * 100;
                    const dashArray = `${pct} ${100 - pct}`;
                    const dashOffset = -currentOffset;
                    currentOffset += pct;

                    return (
                      <path
                        key={seg.status}
                        className={`${seg.color} hover:opacity-80 transition-opacity cursor-pointer`}
                        strokeDasharray={dashArray}
                        strokeDashoffset={dashOffset}
                        strokeWidth="3.8"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        onClick={() => setStatusFilter(seg.status as FleetCurrentStatus)}
                      />
                    );
                  });
                })()}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-2xl font-extrabold text-white font-mono">{statusSummary.total}</span>
                <span className="text-[9px] font-mono text-slate-400 uppercase tracking-wider">FLEET</span>
              </div>
            </div>

            {/* Segment Breakdown List */}
            <div className="space-y-1 flex-1 w-full font-mono text-xs">
              <div
                onClick={() => setStatusFilter('AVAILABLE')}
                className={`flex items-center justify-between p-1 rounded cursor-pointer transition-colors ${statusFilter === 'AVAILABLE' ? 'bg-emerald-950/60 font-bold' : 'hover:bg-slate-800/60'}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]" />
                  <span className="text-slate-300">Available</span>
                </div>
                <span className="font-bold text-emerald-400">{statusSummary.available}</span>
              </div>

              <div
                onClick={() => setStatusFilter('RESERVED')}
                className={`flex items-center justify-between p-1 rounded cursor-pointer transition-colors ${statusFilter === 'RESERVED' ? 'bg-orange-950/60 font-bold' : 'hover:bg-slate-800/60'}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-orange-400 shadow-[0_0_6px_rgba(249,115,22,0.8)]" />
                  <span className="text-slate-300">Reserved</span>
                </div>
                <span className="font-bold text-orange-400">{statusSummary.reserved}</span>
              </div>

              <div
                onClick={() => setStatusFilter('MAINTENANCE')}
                className={`flex items-center justify-between p-1 rounded cursor-pointer transition-colors ${statusFilter === 'MAINTENANCE' ? 'bg-blue-950/60 font-bold' : 'hover:bg-slate-800/60'}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-400 shadow-[0_0_6px_rgba(96,165,250,0.8)]" />
                  <span className="text-slate-300">Maintenance</span>
                </div>
                <span className="font-bold text-blue-400">{statusSummary.maintenance}</span>
              </div>

              <div
                onClick={() => setStatusFilter('UNAVAILABLE')}
                className={`flex items-center justify-between p-1 rounded cursor-pointer transition-colors ${statusFilter === 'UNAVAILABLE' ? 'bg-red-950/60 font-bold' : 'hover:bg-slate-800/60'}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.8)]" />
                  <span className="text-slate-300">Unavailable</span>
                </div>
                <span className="font-bold text-red-400">{statusSummary.unavailable}</span>
              </div>

              <div
                onClick={() => setStatusFilter('DEGRADED')}
                className={`flex items-center justify-between p-1 rounded cursor-pointer transition-colors ${statusFilter === 'DEGRADED' ? 'bg-amber-950/60 font-bold' : 'hover:bg-slate-800/60'}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_6px_rgba(245,158,11,0.8)]" />
                  <span className="text-slate-300">Degraded</span>
                </div>
                <span className="font-bold text-amber-400">{statusSummary.degraded}</span>
              </div>

              <div
                onClick={() => setStatusFilter('CONFLICTING')}
                className={`flex items-center justify-between p-1 rounded cursor-pointer transition-colors ${statusFilter === 'CONFLICTING' ? 'bg-rose-950/60 font-bold' : 'hover:bg-slate-800/60'}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-[0_0_6px_rgba(244,63,94,0.8)]" />
                  <span className="text-slate-300">Conflicting</span>
                </div>
                <span className="font-bold text-rose-400">{statusSummary.conflicting}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bar Chart 1: Environments by Tier */}
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Layers className="w-4 h-4 text-orange-400" /> ENVIRONMENTS BY TIER
            </h3>
            <span className="text-[11px] font-mono text-slate-500">Filter by Tier</span>
          </div>

          <div className="space-y-3 my-1 flex-1 flex flex-col justify-center">
            {tierBreakdown.map(({ tier, count, barWidth }) => (
              <div
                key={tier}
                onClick={() => setTierFilter(tier)}
                className="group cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300 truncate group-hover:text-orange-400 transition-colors">
                    {tier}
                  </span>
                  <span className="text-slate-400 font-bold ml-2">{count}</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-200 dark:border-slate-800">
                  <div
                    className="bg-gradient-to-r from-orange-600 to-amber-500 h-full rounded-full transition-all duration-500 group-hover:brightness-125"
                    style={{ width: `${barWidth}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bar Chart 2: Environments by Business Unit */}
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-blue-400" /> ENVIRONMENTS BY BUSINESS UNIT
            </h3>
            <span className="text-[11px] font-mono text-slate-500">Filter by BU</span>
          </div>

          <div className="space-y-3 my-1 flex-1 flex flex-col justify-center">
            {buBreakdown.map(({ bu, count, barWidth }) => (
              <div
                key={bu}
                onClick={() => setBuFilter(bu)}
                className="group cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300 truncate group-hover:text-blue-400 transition-colors">
                    {bu}
                  </span>
                  <span className="text-slate-400 font-bold ml-2">{count}</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-200 dark:border-slate-800">
                  <div
                    className="bg-gradient-to-r from-blue-600 to-indigo-500 h-full rounded-full transition-all duration-500 group-hover:brightness-125"
                    style={{ width: `${barWidth}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Environment Fleet Cards Grid (Environment Details as Source) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              FLEET GRID
            </span>
            <h3 className="text-base font-bold text-white">Environment Details Fleet Matrix</h3>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <span>Showing {filteredFleetItems.length} records</span>
          </div>
        </div>

        {isLoading ? (
          <CardSkeleton count={6} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4" />
        ) : filteredFleetItems.length === 0 ? (
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-12 text-center space-y-3">
            <Boxes className="w-10 h-10 text-slate-600 mx-auto" />
            <h4 className="text-base font-bold text-white">No Environments Found</h4>
            <p className="text-xs font-mono text-slate-400 max-w-md mx-auto">
              No environment profiles matched the active filters. Try clearing your filters or create a new environment in Environment Details.
            </p>
            <button
              onClick={handleResetFilters}
              className="px-4 py-2 rounded text-xs font-mono font-semibold uppercase text-orange-400 border border-orange-500/40 hover:bg-orange-500/10 transition-colors"
            >
              CLEAR FILTERS
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredFleetItems.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedFleetItem(item)}
                className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 hover:border-slate-700 p-4 rounded-lg transition-all cursor-pointer group shadow-lg flex flex-col justify-between space-y-3 hover:bg-[#141e2e]"
              >
                <div>
                  {/* Top Row: Current Status & Tier */}
                  <div className="flex items-center justify-between mb-2">
                    <StatusBadge status={item.currentStatus} size="sm" />
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-200 dark:border-slate-800 uppercase">
                      {item.type}
                    </span>
                  </div>

                  {/* Environment Name */}
                  <h4 className="text-sm font-bold text-white group-hover:text-orange-300 transition-colors truncate">
                    {item.name}
                  </h4>

                  {/* Business Unit & Account */}
                  <div className="mt-2.5 pt-2.5 border-t border-slate-200 dark:border-slate-800/80 grid grid-cols-2 gap-2 text-[11px] font-mono">
                    <div>
                      <span className="text-slate-500 uppercase text-[9px] block">BU</span>
                      <span className="text-slate-300 truncate block font-semibold">{item.businessUnit}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase text-[9px] block">ACCOUNT / ZONE</span>
                      <span className="text-slate-300 truncate block font-semibold">{item.account}</span>
                    </div>
                  </div>

                  {/* Resource Counts: Servers & Software */}
                  <div className="mt-2 flex items-center gap-4 text-xs font-mono text-slate-400">
                    <span className="flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5 text-emerald-400" /> {item.serverCount} SERVERS
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Boxes className="w-3.5 h-3.5 text-blue-400" /> {item.softwareCount} SOFTWARE
                    </span>
                  </div>

                  {/* Active Reservation Banner if Reserved */}
                  {item.activeBooking && (
                    <div className="mt-3 p-2 rounded bg-orange-950/30 border border-orange-800/40 text-[11px] font-mono text-orange-300 space-y-1">
                      <div className="flex items-center justify-between font-bold">
                        <span>RESERVED BY: {item.activeBooking.requestedBy}</span>
                        <span className="text-[9px] bg-orange-500/20 text-orange-400 px-1.5 py-0.2 rounded border border-orange-500/30">
                          {item.activeBooking.status}
                        </span>
                      </div>
                      <p className="text-[10px] text-orange-400/80 truncate">
                        App: {item.activeBooking.application} ({item.activeBooking.project})
                      </p>
                    </div>
                  )}

                  {/* Active Incident Warning Banner if any */}
                  {item.activeIncidentsCount > 0 && (
                    <div className="mt-2 p-2 rounded bg-red-950/30 border border-red-800/40 text-[11px] font-mono text-red-300 flex items-center gap-2">
                      <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                      <span>{item.activeIncidentsCount} active incident(s) raised</span>
                    </div>
                  )}
                </div>

                {/* Footer Row */}
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-500">
                  <span>Owner: {item.owner}</span>
                  <span className="text-orange-400 font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    DETAILS <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 5. Environment Details Dossier Modal */}
      {selectedFleetItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 space-y-6 shadow-2xl">
            {/* Header */}
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <StatusBadge status={selectedFleetItem.currentStatus} />
                  <span className="text-xs font-mono text-slate-400 font-semibold uppercase">
                    {selectedFleetItem.type}
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-white tracking-tight">{selectedFleetItem.name}</h3>
                <p className="text-xs font-mono text-slate-400 mt-1">
                  Environment ID: <strong className="text-white">{selectedFleetItem.id}</strong>
                </p>
              </div>
              <button
                onClick={() => setSelectedFleetItem(null)}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Description */}
            <div>
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-1">
                DESCRIPTION
              </h4>
              <p className="text-sm text-slate-300 font-sans">{selectedFleetItem.description}</p>
            </div>

            {/* Key Properties Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-900/60 rounded-lg border border-slate-200 dark:border-slate-800/80 text-xs font-mono">
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">BUSINESS UNIT</span>
                <span className="text-white font-bold truncate block">{selectedFleetItem.businessUnit}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">ACCOUNT / ZONE</span>
                <span className="text-white font-bold truncate block">{selectedFleetItem.account}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">OWNER TEAM</span>
                <span className="text-white font-bold truncate block">{selectedFleetItem.owner}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">INITIAL STATUS</span>
                <span className="text-white font-bold truncate block">{selectedFleetItem.initialStatus}</span>
              </div>
            </div>

            {/* Associated Servers */}
            <div className="space-y-3">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                <span>ASSOCIATED SERVERS ({selectedFleetItem.serverCount})</span>
                <Server className="w-4 h-4 text-emerald-400" />
              </h4>

              {selectedFleetItem.servers.length === 0 ? (
                <p className="text-xs font-mono text-slate-500 bg-slate-900/40 p-3 rounded border border-slate-200 dark:border-slate-800/60">
                  No servers explicitly assigned to this environment profile.
                </p>
              ) : (
                <div className="space-y-2">
                  {selectedFleetItem.servers.map((srv) => (
                    <div
                      key={srv.id}
                      className="p-3 rounded bg-slate-900/70 border border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs font-mono"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{srv.name}</span>
                          <span className="text-[10px] text-slate-400 px-1.5 py-0.2 rounded bg-slate-800">
                            {srv.serverType}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1">
                          IP: {srv.hostIp || '10.240.12.11'} · OS: {srv.operatingSystem} · Specs: {srv.cpuCores}vCPU / {srv.ramGb}GB RAM
                        </p>
                      </div>
                      <StatusBadge status={srv.status === 'ONLINE' ? 'HEALTHY' : 'DOWN'} size="sm" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Associated Software */}
            <div className="space-y-3">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                <span>ASSOCIATED SOFTWARE ({selectedFleetItem.softwareCount})</span>
                <Boxes className="w-4 h-4 text-blue-400" />
              </h4>

              {selectedFleetItem.software.length === 0 ? (
                <p className="text-xs font-mono text-slate-500 bg-slate-900/40 p-3 rounded border border-slate-200 dark:border-slate-800/60">
                  No software packages explicitly assigned to this environment profile.
                </p>
              ) : (
                <div className="space-y-2">
                  {selectedFleetItem.software.map((sw) => (
                    <div
                      key={sw.id}
                      className="p-3 rounded bg-slate-900/70 border border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs font-mono"
                    >
                      <div>
                        <span className="font-bold text-white">
                          {sw.name} {sw.version && `v${sw.version}`}
                        </span>
                        <p className="text-[11px] text-slate-400 mt-1">
                          Port: {sw.port || '8080'} · Stack: {sw.runtimeStack || 'Java / Spring'}
                        </p>
                      </div>
                      <StatusBadge status={sw.status === 'ACTIVE' || sw.status === 'INSTALLED' ? 'HEALTHY' : 'DOWN'} size="sm" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setSelectedFleetItem(null)}
                className="px-4 py-2 rounded text-xs font-mono font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors"
              >
                CLOSE
              </button>
              <button
                onClick={() => {
                  setSelectedFleetItem(null);
                  navigate('/environment-details');
                }}
                className="px-5 py-2 rounded text-xs font-mono font-bold uppercase text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.3)]"
              >
                OPEN FULL PROFILE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
