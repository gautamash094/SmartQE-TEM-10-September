import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { ToastContainer } from '../ui/ToastContainer';

interface MainLayoutProps {
  children: React.ReactNode;
}

const SIDEBAR_COLLAPSED_STORAGE_KEY = 'smartqe_tem_sidebar_collapsed_v1';

export const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState<boolean>(false);
  const [isCollapsed, setIsCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem(SIDEBAR_COLLAPSED_STORAGE_KEY) === 'true';
    } catch {
      return false;
    }
  });

  const [isHovered, setIsHovered] = useState<boolean>(false);
  const hoverTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);

  const handleMouseEnterSidebar = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
      hoverTimeoutRef.current = null;
    }
    if (isCollapsed) {
      setIsHovered(true);
    }
  };

  const handleMouseLeaveSidebar = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
    }
    hoverTimeoutRef.current = setTimeout(() => {
      setIsHovered(false);
    }, 250);
  };

  const toggleCollapse = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
      hoverTimeoutRef.current = null;
    }
    setIsHovered(false);
    setIsCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(SIDEBAR_COLLAPSED_STORAGE_KEY, String(next));
      } catch {}
      return next;
    });
  };

  const isSidebarVisible = !isCollapsed || isHovered;

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col relative">
      {/* 1. Left Edge Hover Trigger Strip for Collapsed State */}
      {isCollapsed && (
        <div
          onMouseEnter={handleMouseEnterSidebar}
          className="fixed top-0 left-0 bottom-0 w-6 z-40 pointer-events-auto cursor-pointer"
          title="Hover to open navigation menu"
          aria-hidden="true"
        />
      )}

      {/* 2. Permanent Brand Logo Header & Collapsible Sidebar Menu */}
      <Sidebar
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
        isCollapsed={isCollapsed}
        onToggleCollapse={toggleCollapse}
        isHovered={isHovered}
        onMouseEnter={handleMouseEnterSidebar}
        onMouseLeave={handleMouseLeaveSidebar}
      />

      {/* 3. Top Header Bar - Smoothly moves right (lg:pl-64) when sidebar is visible */}
      <div className={`w-full transition-all duration-300 ease-in-out ${isSidebarVisible ? 'pl-0 lg:pl-64' : 'pl-0'}`}>
        <Header
          onMobileMenuClick={() => setMobileOpen(!mobileOpen)}
          isSidebarCollapsed={!isSidebarVisible}
          onToggleSidebar={toggleCollapse}
          onMouseEnterSidebarArea={handleMouseEnterSidebar}
          onMouseLeaveSidebarArea={handleMouseLeaveSidebar}
        />
      </div>

      {/* 4. Main Content Area - Smoothly moves right (lg:pl-64) when sidebar is visible */}
      <div
        className={`flex-1 transition-all duration-300 ease-in-out ${
          isSidebarVisible ? 'lg:pl-64' : 'lg:pl-0'
        }`}
      >
        <main className="p-4 md:p-6 lg:p-8 max-w-[1700px] w-full mx-auto min-w-0">{children}</main>
      </div>

      {/* Toast Notification Container */}
      <ToastContainer />
    </div>
  );
};
