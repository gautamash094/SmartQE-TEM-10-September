import React, { useState, useEffect, useRef } from 'react';
import { useLocation, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTEM } from '../../context/TEMContext';
import {
  Menu,
  Zap,
  PanelLeftClose,
  User as UserIcon,
  LogOut,
  KeyRound,
  Shield,
  ChevronDown,
} from 'lucide-react';
import { ChangePasswordModal } from '../common/ChangePasswordModal';

interface HeaderProps {
  onMobileMenuClick?: () => void;
  isSidebarCollapsed?: boolean;
  onToggleSidebar?: () => void;
  onMouseEnterSidebarArea?: () => void;
  onMouseLeaveSidebarArea?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onMobileMenuClick,
  isSidebarCollapsed,
  onToggleSidebar,
  onMouseEnterSidebarArea,
  onMouseLeaveSidebarArea,
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();
  const { showToast } = useTEM();

  const [timeString, setTimeString] = useState<string>('');
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState<boolean>(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState<boolean>(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const parts = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Kolkata',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      }).formatToParts(now);

      const map: Record<string, string> = {};
      parts.forEach((p) => {
        map[p.type] = p.value;
      });
      const hour = map.hour === '24' ? '00' : map.hour;
      setTimeString(`${map.year}-${map.month}-${map.day} ${hour}:${map.minute}:${map.second} IST`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Close profile dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    setIsProfileMenuOpen(false);
    await logout();
    showToast('You have been logged out successfully.', 'info');
    navigate('/login');
  };

  const userInitials = (currentUser?.fullName || currentUser?.username || 'U')
    .split(' ')
    .map((n) => n[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();

  return (
    <>
      <header className="h-16 bg-[#090d14]/90 backdrop-blur border-b border-slate-800/80 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 transition-all duration-300">
        {/* Left: Mobile Menu Toggle / Collapsed Brand Icon & PATH Indicator */}
        <div className="flex items-center gap-3">
          {/* Mobile Toggle Button */}
          <button
            onClick={onMobileMenuClick}
            className="lg:hidden text-slate-400 hover:text-white p-1.5 rounded-md hover:bg-slate-800 transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Desktop Collapsed Sidebar Brand & Expand Button */}
          {isSidebarCollapsed && (
            <div
              onMouseEnter={onMouseEnterSidebarArea}
              onMouseLeave={onMouseLeaveSidebarArea}
              className="hidden lg:flex items-center gap-2.5 mr-2"
            >
              <NavLink
                to="/tem-dashboard"
                className="flex items-center gap-2 text-slate-100 hover:text-orange-400 transition-colors group cursor-pointer"
                title="SmartQE TEM Control (Hover to expand menu)"
              >
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white shadow-[0_0_8px_rgba(249,115,22,0.4)] shrink-0 group-hover:scale-105 transition-transform">
                  <Zap className="w-4 h-4 fill-current text-white" />
                </div>
                <span className="font-bold text-xs font-mono tracking-wider">SMARTQE</span>
              </NavLink>

              {onToggleSidebar && (
                <button
                  onClick={onToggleSidebar}
                  className="p-1.5 rounded-lg text-orange-400 bg-orange-950/60 border border-orange-800/80 hover:bg-orange-900/80 hover:text-white transition-colors cursor-pointer"
                  title="Expand and pin navigation menu"
                  aria-label="Expand and pin navigation menu"
                >
                  <PanelLeftClose className="w-4 h-4 rotate-180" />
                </button>
              )}
            </div>
          )}

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-slate-500 uppercase tracking-wider font-semibold">PATH</span>
            <span className="text-slate-300 font-medium px-2 py-0.5 bg-slate-800/60 rounded border border-slate-700/60">
              {location.pathname}
            </span>
          </div>
        </div>

        {/* Right: Live IST Clock & User Profile Menu */}
        <div className="flex items-center gap-3 sm:gap-5 text-xs font-mono">
          <span className="text-slate-400 hidden sm:inline-block font-medium">{timeString}</span>

          {/* User Profile Avatar & Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="flex items-center gap-2.5 p-1.5 rounded-xl hover:bg-slate-800/80 border border-transparent hover:border-slate-700/80 transition-all cursor-pointer"
              title="User Account Menu"
            >
              <div className="w-8 h-8 rounded-lg bg-orange-600/20 border border-orange-500/40 text-orange-400 font-bold text-xs flex items-center justify-center shadow-sm">
                {userInitials}
              </div>
              <div className="hidden md:flex flex-col text-left">
                <span className="text-xs font-bold text-slate-200 leading-none">
                  {currentUser?.fullName || currentUser?.username || 'User'}
                </span>
                <span className="text-[10px] text-orange-400 font-mono mt-0.5 leading-none">
                  {currentUser?.isSuperAdmin ? 'Super Admin' : (currentUser?.roles?.[0]?.name || 'Standard User')}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden md:inline" />
            </button>

            {/* Profile Dropdown Menu */}
            {isProfileMenuOpen && (
              <div className="absolute right-0 mt-2 w-64 bg-[#0f1724] border border-slate-800 rounded-xl shadow-2xl p-2 z-50 animate-fadeIn">
                {/* User Summary */}
                <div className="px-3 py-2.5 border-b border-slate-800 mb-1">
                  <span className="text-[10px] font-mono text-slate-400 uppercase block">AUTHENTICATED AS</span>
                  <div className="text-xs font-bold text-white mt-0.5 truncate">
                    {currentUser?.fullName || currentUser?.username || 'Super Admin'}
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 truncate">
                    {currentUser?.email || 'admin@testops.io'}
                  </div>
                  {currentUser?.roles && currentUser.roles.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {currentUser.roles.map((r) => (
                        <span
                          key={r.id}
                          className="text-[9px] font-mono font-semibold px-2 py-0.5 rounded bg-orange-950/60 text-orange-400 border border-orange-800/80"
                        >
                          {r.name}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Menu Items */}
                <button
                  onClick={() => {
                    setIsProfileMenuOpen(false);
                    setIsChangePasswordOpen(true);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-mono text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-lg transition-colors cursor-pointer text-left"
                >
                  <KeyRound className="w-4 h-4 text-orange-400" />
                  <span>Change Password</span>
                </button>

                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-mono text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer text-left mt-1"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Change Password Dialog */}
      <ChangePasswordModal
        isOpen={isChangePasswordOpen}
        onClose={() => setIsChangePasswordOpen(false)}
      />
    </>
  );
};