import React from 'react';
import {
  Server,
  PlayCircle,
  CheckCircle2,
  AlertOctagon,
  Clock,
  Archive,
  ArrowUpRight,
} from 'lucide-react';
import { ProvisioningDashboardKPIs } from '../../../types/provisioning';

interface Props {
  kpis: ProvisioningDashboardKPIs;
  onFilterStatus?: (status: string) => void;
  activeStatus?: string;
}

export const ProvisioningKpiCards: React.FC<Props> = ({
  kpis,
  onFilterStatus,
  activeStatus,
}) => {
  const cards = [
    {
      key: 'ALL',
      title: 'Total Requests',
      value: kpis.total_requests,
      icon: Server,
      color: 'from-blue-600 to-cyan-500',
      textColor: 'text-blue-400',
      bgColor: 'bg-blue-500/10',
      borderColor: 'border-blue-500/20',
      subtitle: 'All lifecycle requests',
    },
    {
      key: 'PROVISIONING',
      title: 'In Progress',
      value: kpis.in_progress,
      icon: PlayCircle,
      color: 'from-orange-600 to-amber-500',
      textColor: 'text-orange-400',
      bgColor: 'bg-orange-500/10',
      borderColor: 'border-orange-500/20',
      subtitle: 'Active orchestration pipelines',
      pulse: kpis.in_progress > 0,
    },
    {
      key: 'READY',
      title: 'Ready',
      value: kpis.ready,
      icon: CheckCircle2,
      color: 'from-emerald-600 to-teal-500',
      textColor: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10',
      borderColor: 'border-emerald-500/20',
      subtitle: 'Healthy operational targets',
    },
    {
      key: 'PENDING_APPROVAL',
      title: 'Pending Approval',
      value: kpis.pending_approval,
      icon: Clock,
      color: 'from-amber-600 to-yellow-500',
      textColor: 'text-amber-400',
      bgColor: 'bg-amber-500/10',
      borderColor: 'border-amber-500/20',
      subtitle: 'Awaiting manager sign-off',
    },
    {
      key: 'FAILED',
      title: 'Failed',
      value: kpis.failed,
      icon: AlertOctagon,
      color: 'from-rose-600 to-red-500',
      textColor: 'text-rose-400',
      bgColor: 'bg-rose-500/10',
      borderColor: 'border-rose-500/20',
      subtitle: 'Requires retry / diagnosis',
    },
    {
      key: 'DECOMMISSIONED',
      title: 'Decommissioned',
      value: kpis.decommissioning,
      icon: Archive,
      color: 'from-slate-600 to-slate-500',
      textColor: 'text-slate-400',
      bgColor: 'bg-slate-500/10',
      borderColor: 'border-slate-500/20',
      subtitle: 'Released & cleaned up',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {cards.map((card) => {
        const Icon = card.icon;
        const isSelected = activeStatus === card.key;

        return (
          <div
            key={card.key}
            onClick={() => onFilterStatus && onFilterStatus(card.key)}
            className={`group relative rounded-xl border p-4 transition-all duration-200 cursor-pointer overflow-hidden ${
              isSelected
                ? 'bg-slate-800/90 border-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.15)] ring-1 ring-orange-500/50'
                : 'bg-slate-900/80 hover:bg-slate-850 border-slate-800 hover:border-slate-700 shadow-sm'
            }`}
          >
            {/* Top row */}
            <div className="flex items-center justify-between">
              <div className={`p-2 rounded-lg ${card.bgColor} border ${card.borderColor}`}>
                <Icon className={`w-4 h-4 ${card.textColor} ${card.pulse ? 'animate-pulse' : ''}`} />
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>

            {/* Value & Title */}
            <div className="mt-3">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold font-mono text-white tracking-tight">
                  {card.value}
                </span>
                {card.pulse && (
                  <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
                )}
              </div>
              <p className="text-xs font-medium text-slate-300 mt-0.5">{card.title}</p>
              <p className="text-[11px] text-slate-500 truncate mt-0.5">{card.subtitle}</p>
            </div>

            {/* Accent bottom strip */}
            <div
              className={`absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r ${card.color} opacity-70 group-hover:opacity-100 transition-opacity`}
            />
          </div>
        );
      })}
    </div>
  );
};
