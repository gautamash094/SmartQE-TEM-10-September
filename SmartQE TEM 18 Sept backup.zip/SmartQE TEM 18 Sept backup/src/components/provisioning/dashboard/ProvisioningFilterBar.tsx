import React from 'react';
import { Search, RotateCcw, Filter, X } from 'lucide-react';
import { BusinessUnit, Project, ApplicationEntity } from '../../../services/portfolioService';

interface FilterState {
  search: string;
  businessUnit: string;
  projectName: string;
  applicationName: string;
  status: string;
  provisioningMode: string;
}

interface Props {
  filters: FilterState;
  onChange: (filters: FilterState) => void;
  onReset: () => void;
  onRefresh: () => void;
  businessUnits: BusinessUnit[];
  projects: Project[];
  applications: ApplicationEntity[];
  isLoading?: boolean;
}

export const ProvisioningFilterBar: React.FC<Props> = ({
  filters,
  onChange,
  onReset,
  onRefresh,
  businessUnits,
  projects,
  applications,
  isLoading,
}) => {
  const handleFieldChange = (field: keyof FilterState, value: string) => {
    onChange({
      ...filters,
      [field]: value,
    });
  };

  const hasActiveFilters =
    filters.search !== '' ||
    filters.businessUnit !== 'ALL' ||
    filters.projectName !== 'ALL' ||
    filters.applicationName !== 'ALL' ||
    filters.status !== 'ALL' ||
    filters.provisioningMode !== 'ALL';

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-3">
        {/* Search Bar */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={filters.search}
            onChange={(e) => handleFieldChange('search', e.target.value)}
            placeholder="Search by Request #, Environment, Owner, or Project..."
            className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-slate-700/80 rounded-lg text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 font-sans transition-all"
          />
          {filters.search && (
            <button
              onClick={() => handleFieldChange('search', '')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Business Unit Dropdown */}
        <div className="w-full sm:w-48">
          <select
            value={filters.businessUnit}
            onChange={(e) => handleFieldChange('businessUnit', e.target.value)}
            className="w-full px-3 py-2 bg-slate-950/60 border border-slate-700/80 rounded-lg text-xs font-medium text-slate-200 focus:outline-none focus:border-orange-500 transition-all cursor-pointer"
          >
            <option value="ALL">All Business Units</option>
            {businessUnits.map((bu) => (
              <option key={bu.id} value={bu.name}>
                {bu.name}
              </option>
            ))}
          </select>
        </div>

        {/* Project Dropdown */}
        <div className="w-full sm:w-48">
          <select
            value={filters.projectName}
            onChange={(e) => handleFieldChange('projectName', e.target.value)}
            className="w-full px-3 py-2 bg-slate-950/60 border border-slate-700/80 rounded-lg text-xs font-medium text-slate-200 focus:outline-none focus:border-orange-500 transition-all cursor-pointer"
          >
            <option value="ALL">All Projects</option>
            {projects
              .filter(
                (p) =>
                  filters.businessUnit === 'ALL' ||
                  p.businessUnit === filters.businessUnit
              )
              .map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
          </select>
        </div>

        {/* Status Dropdown */}
        <div className="w-full sm:w-44">
          <select
            value={filters.status}
            onChange={(e) => handleFieldChange('status', e.target.value)}
            className="w-full px-3 py-2 bg-slate-950/60 border border-slate-700/80 rounded-lg text-xs font-medium text-slate-200 focus:outline-none focus:border-orange-500 transition-all cursor-pointer"
          >
            <option value="ALL">All Statuses</option>
            <option value="DRAFT">Draft</option>
            <option value="PENDING_APPROVAL">Pending Approval</option>
            <option value="APPROVED">Approved</option>
            <option value="QUEUED">Queued</option>
            <option value="PROVISIONING">Provisioning</option>
            <option value="CONFIGURING">Configuring</option>
            <option value="HEALTH_CHECK">Health Check</option>
            <option value="READY">Ready</option>
            <option value="FAILED">Failed</option>
            <option value="DECOMMISSIONED">Decommissioned</option>
          </select>
        </div>

        {/* Mode Dropdown */}
        <div className="w-full sm:w-40">
          <select
            value={filters.provisioningMode}
            onChange={(e) => handleFieldChange('provisioningMode', e.target.value)}
            className="w-full px-3 py-2 bg-slate-950/60 border border-slate-700/80 rounded-lg text-xs font-medium text-slate-200 focus:outline-none focus:border-orange-500 transition-all cursor-pointer"
          >
            <option value="ALL">All Modes</option>
            <option value="ON_DEMAND">On Demand</option>
            <option value="SCHEDULED">Scheduled</option>
            <option value="TEMPLATE_BASED">Template Based</option>
          </select>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {hasActiveFilters && (
            <button
              onClick={onReset}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 transition-colors flex items-center gap-1.5"
              title="Reset Filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}

          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 transition-colors disabled:opacity-50"
            title="Refresh Data"
          >
            <RotateCcw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-400' : ''}`} />
          </button>
        </div>
      </div>
    </div>
  );
};
