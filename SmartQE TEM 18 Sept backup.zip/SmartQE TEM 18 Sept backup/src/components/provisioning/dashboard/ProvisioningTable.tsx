import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Eye,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Archive,
  Layers,
  Activity,
  Calendar,
  User,
  ExternalLink,
} from 'lucide-react';
import { ProvisioningRequest } from '../../../types/provisioning';
import { ProvisioningStatusBadge } from '../common/ProvisioningStatusBadge';

interface Props {
  requests: ProvisioningRequest[];
  onApprove?: (id: string) => void;
  onProvision?: (id: string) => void;
  onRetry?: (id: string) => void;
  onRollback?: (id: string) => void;
  onDecommission?: (id: string) => void;
  isLoading?: boolean;
}

export const ProvisioningTable: React.FC<Props> = ({
  requests,
  onApprove,
  onProvision,
  onRetry,
  onRollback,
  onDecommission,
  isLoading,
}) => {
  const navigate = useNavigate();

  if (requests.length === 0 && !isLoading) {
    return (
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-12 text-center">
        <div className="w-12 h-12 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 mx-auto mb-4">
          <Layers className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-white">No Provisioning Requests Found</h3>
        <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
          No environment provisioning requests match your active filters. Launch a new request using the guided wizard or deploy from a template.
        </p>
        <button
          onClick={() => navigate('/provisioning/new')}
          className="mt-4 px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white rounded-lg text-xs font-semibold shadow-lg shadow-orange-600/20 transition-all inline-flex items-center gap-2"
        >
          <span>Create New Request</span>
        </button>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800/80 bg-slate-950/60 text-[11px] font-mono uppercase tracking-wider text-slate-400 select-none">
              <th className="py-3 px-4">Request #</th>
              <th className="py-3 px-4">Environment</th>
              <th className="py-3 px-4">Project / App</th>
              <th className="py-3 px-4">Mode</th>
              <th className="py-3 px-4">Owner / Requester</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 min-w-[140px]">Progress</th>
              <th className="py-3 px-4">Health</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300 font-sans">
            {requests.map((req) => {
              const isRunning = ['PROVISIONING', 'CONFIGURING', 'HEALTH_CHECK', 'QUEUED'].includes(req.status);
              const isReady = req.status === 'READY' || req.status === 'PARTIALLY_READY';
              const isFailed = req.status === 'FAILED';
              const isPendingApproval = req.status === 'PENDING_APPROVAL';
              const isApproved = req.status === 'APPROVED' || req.status === 'VALIDATED';

              return (
                <tr
                  key={req.id}
                  className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                  onClick={() => navigate(`/provisioning/requests/${req.id}`)}
                >
                  {/* Request Number */}
                  <td className="py-3.5 px-4 font-mono font-bold text-orange-400 group-hover:text-orange-300">
                    <div className="flex items-center gap-1.5">
                      <span>{req.request_number}</span>
                      <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-slate-400" />
                    </div>
                  </td>

                  {/* Environment */}
                  <td className="py-3.5 px-4">
                    <div>
                      <span className="font-semibold text-white block">{req.environment_name}</span>
                      <span className="inline-block mt-0.5 px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                        {req.environment_type}
                      </span>
                    </div>
                  </td>

                  {/* Project / App */}
                  <td className="py-3.5 px-4">
                    <div>
                      <span className="text-slate-200 block truncate max-w-[180px]">{req.project_name}</span>
                      <span className="text-[11px] text-slate-400 block truncate max-w-[180px]">{req.application_name}</span>
                    </div>
                  </td>

                  {/* Mode */}
                  <td className="py-3.5 px-4">
                    <span className="text-[11px] font-mono text-slate-400">
                      {req.provisioning_mode?.replace('_', ' ')}
                    </span>
                  </td>

                  {/* Owner & Requester */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-1.5">
                      <div className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] text-slate-300 shrink-0">
                        <User className="w-3 h-3" />
                      </div>
                      <div className="truncate max-w-[130px]">
                        <span className="text-slate-200 block truncate">{req.environment_owner || req.requested_by}</span>
                        <span className="text-[10px] text-slate-500 block truncate">{req.business_unit}</span>
                      </div>
                    </div>
                  </td>

                  {/* Status Badge */}
                  <td className="py-3.5 px-4">
                    <ProvisioningStatusBadge status={req.status} size="sm" />
                  </td>

                  {/* Progress Bar */}
                  <td className="py-3.5 px-4">
                    <div className="w-full">
                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                        <span>{req.current_step_index}/{req.total_steps || 9} Steps</span>
                        <span className="font-bold text-slate-200">{Math.round(req.progress_percentage || 0)}%</span>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            isFailed
                              ? 'bg-rose-500'
                              : isReady
                              ? 'bg-emerald-500'
                              : isRunning
                              ? 'bg-gradient-to-r from-orange-500 to-amber-400 animate-pulse'
                              : 'bg-orange-500'
                          }`}
                          style={{ width: `${Math.min(100, Math.max(0, req.progress_percentage || 0))}%` }}
                        />
                      </div>
                    </div>
                  </td>

                  {/* Health Probe */}
                  <td className="py-3.5 px-4">
                    {req.health_status === 'HEALTHY' ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                        <CheckCircle2 className="w-3 h-3" /> HEALTHY
                      </span>
                    ) : req.health_status === 'FAILED' ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-mono text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                        <XCircle className="w-3 h-3" /> FAILED
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                        <Activity className="w-3 h-3" /> PENDING
                      </span>
                    )}
                  </td>

                  {/* Action Buttons */}
                  <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-1.5">
                      {/* Run Provisioning */}
                      {isApproved && onProvision && (
                        <button
                          onClick={() => onProvision(req.id)}
                          className="px-2.5 py-1 bg-orange-600/90 hover:bg-orange-500 text-white rounded text-[11px] font-medium flex items-center gap-1 shadow-sm transition-colors"
                          title="Execute Provisioning"
                        >
                          <Play className="w-3 h-3 fill-current" />
                          <span>Run</span>
                        </button>
                      )}

                      {/* Approve Button */}
                      {isPendingApproval && onApprove && (
                        <button
                          onClick={() => onApprove(req.id)}
                          className="px-2.5 py-1 bg-emerald-600/90 hover:bg-emerald-500 text-white rounded text-[11px] font-medium flex items-center gap-1 shadow-sm transition-colors"
                          title="Approve Request"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Approve</span>
                        </button>
                      )}

                      {/* Retry Button */}
                      {isFailed && onRetry && (
                        <button
                          onClick={() => onRetry(req.id)}
                          className="px-2.5 py-1 bg-amber-600/90 hover:bg-amber-500 text-white rounded text-[11px] font-medium flex items-center gap-1 shadow-sm transition-colors"
                          title="Retry Failed Step"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Retry</span>
                        </button>
                      )}

                      {/* Decommission Button */}
                      {isReady && onDecommission && (
                        <button
                          onClick={() => onDecommission(req.id)}
                          className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
                          title="Decommission Environment"
                        >
                          <Archive className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {/* View Console Button */}
                      <button
                        onClick={() => navigate(`/provisioning/requests/${req.id}`)}
                        className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
                        title="View Provisioning Console"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
