import React from 'react';
import { ProvisioningStatus, StepStatus } from '../../../types/provisioning';
import {
  Clock,
  PlayCircle,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RotateCcw,
  ShieldCheck,
  Activity,
  Layers,
  Archive,
  Ban,
  FileEdit,
} from 'lucide-react';

interface Props {
  status: ProvisioningStatus | StepStatus | string;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const ProvisioningStatusBadge: React.FC<Props> = ({
  status,
  size = 'md',
  showIcon = true,
}) => {
  const norm = (status || '').toUpperCase();

  let bgClass = 'bg-slate-800/80 text-slate-300 border-slate-700';
  let IconComponent = Clock;
  let label = norm.replace('_', ' ');

  switch (norm) {
    case 'DRAFT':
      bgClass = 'bg-slate-800/60 text-slate-300 border-slate-700/80';
      IconComponent = FileEdit;
      label = 'Draft';
      break;
    case 'VALIDATING':
      bgClass = 'bg-blue-500/10 text-blue-400 border-blue-500/30 animate-pulse';
      IconComponent = Activity;
      label = 'Validating';
      break;
    case 'VALIDATED':
      bgClass = 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
      IconComponent = ShieldCheck;
      label = 'Validated';
      break;
    case 'PENDING_APPROVAL':
    case 'PENDING':
      bgClass = 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      IconComponent = Clock;
      label = 'Pending Approval';
      break;
    case 'APPROVED':
    case 'AUTO_APPROVED':
      bgClass = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      IconComponent = CheckCircle2;
      label = 'Approved';
      break;
    case 'QUEUED':
      bgClass = 'bg-purple-500/10 text-purple-400 border-purple-500/30';
      IconComponent = Layers;
      label = 'Queued';
      break;
    case 'PROVISIONING':
    case 'IN_PROGRESS':
      bgClass = 'bg-orange-500/15 text-orange-400 border-orange-500/40 shadow-[0_0_12px_rgba(249,115,22,0.2)] animate-pulse';
      IconComponent = PlayCircle;
      label = 'Provisioning';
      break;
    case 'CONFIGURING':
      bgClass = 'bg-amber-500/15 text-amber-300 border-amber-500/40 animate-pulse';
      IconComponent = Activity;
      label = 'Configuring';
      break;
    case 'HEALTH_CHECK':
      bgClass = 'bg-teal-500/15 text-teal-400 border-teal-500/40 animate-pulse';
      IconComponent = Activity;
      label = 'Health Check';
      break;
    case 'READY':
    case 'COMPLETED':
      bgClass = 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.2)]';
      IconComponent = CheckCircle2;
      label = 'Ready';
      break;
    case 'PARTIALLY_READY':
      bgClass = 'bg-yellow-500/15 text-yellow-400 border-yellow-500/40';
      IconComponent = AlertTriangle;
      label = 'Partially Ready';
      break;
    case 'FAILED':
      bgClass = 'bg-rose-500/15 text-rose-400 border-rose-500/40 shadow-[0_0_12px_rgba(244,63,94,0.2)]';
      IconComponent = XCircle;
      label = 'Failed';
      break;
    case 'ROLLBACK':
    case 'ROLLED_BACK':
      bgClass = 'bg-pink-500/15 text-pink-400 border-pink-500/40';
      IconComponent = RotateCcw;
      label = 'Rollback';
      break;
    case 'DECOMMISSIONING':
      bgClass = 'bg-amber-600/15 text-amber-400 border-amber-600/40 animate-pulse';
      IconComponent = Archive;
      label = 'Decommissioning';
      break;
    case 'DECOMMISSIONED':
      bgClass = 'bg-slate-700/50 text-slate-400 border-slate-600/50';
      IconComponent = Archive;
      label = 'Decommissioned';
      break;
    case 'CANCELLED':
    case 'SKIPPED':
      bgClass = 'bg-slate-800 text-slate-400 border-slate-700';
      IconComponent = Ban;
      label = 'Cancelled';
      break;
  }

  const sizeClasses = {
    sm: 'text-[10px] px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3.5 py-1.5 gap-2',
  };

  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4 h-4',
  };

  return (
    <span
      className={`inline-flex items-center font-mono font-medium rounded-full border ${bgClass} ${sizeClasses[size]} select-none`}
    >
      {showIcon && <IconComponent className={`${iconSizes[size]} shrink-0`} />}
      <span className="tracking-wide uppercase">{label}</span>
    </span>
  );
};
