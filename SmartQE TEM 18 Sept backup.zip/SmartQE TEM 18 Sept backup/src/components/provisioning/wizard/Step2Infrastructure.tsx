import React from 'react';
import {
  Cpu,
  Server,
  HardDrive,
  Globe,
  Shield,
  Layers,
  Check,
  SplitSquareVertical,
} from 'lucide-react';
import { ComputeType } from '../../../types/provisioning';

export interface Step2FormData {
  computeType: ComputeType;
  cpuCores: number;
  ramGb: number;
  storageGb: number;
  osDiskGb: number;
  dataDiskGb: number;
  region: string;
  vlan: string;
  subnet: string;
  ipRequirement: 'STATIC' | 'DHCP';
  firewallProfile: string;
  loadBalancer: boolean;
}

interface Props {
  formData: Step2FormData;
  onChange: (data: Partial<Step2FormData>) => void;
}

const COMPUTE_TYPES: { type: ComputeType; label: string; desc: string; icon: any }[] = [
  { type: 'VM', label: 'Virtual Machine', desc: 'Enterprise KVM / VMware / AWS EC2 instance', icon: Server },
  { type: 'CONTAINER', label: 'Docker Container', desc: 'Lightweight isolated container runtime', icon: Layers },
  { type: 'KUBERNETES', label: 'Kubernetes Pod / Cluster', desc: 'Managed multi-node K8s namespace deployment', icon: SplitSquareVertical },
  { type: 'BARE_METAL', label: 'Bare Metal Server', desc: 'Dedicated physical hardware for ultra-low latency', icon: Cpu },
];

const CPU_PRESETS = [2, 4, 8, 16, 32, 64];
const RAM_PRESETS = [4, 8, 16, 32, 64, 128];

export const Step2Infrastructure: React.FC<Props> = ({ formData, onChange }) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Step 2: Infrastructure & Compute Sizing
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Select hypervisor compute architecture, CPU/RAM sizing, attached disk volumes, and network topology.
        </p>
      </div>

      {/* Compute Type Selector */}
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-2.5">
          Compute Platform & Virtualization Type *
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {COMPUTE_TYPES.map((c) => {
            const Icon = c.icon;
            const isSelected = formData.computeType === c.type;
            return (
              <button
                key={c.type}
                type="button"
                onClick={() => onChange({ computeType: c.type })}
                className={`p-4 rounded-xl border text-left transition-all relative ${
                  isSelected
                    ? 'bg-orange-500/15 border-orange-500 text-white shadow-sm ring-1 ring-orange-500/30'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-850 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      isSelected ? 'bg-orange-500 text-white' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-orange-400 stroke-[3]" />}
                </div>
                <h4 className="text-xs font-bold font-mono text-white">{c.label}</h4>
                <p className="text-[11px] text-slate-400 mt-1">{c.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sizing (CPU & RAM) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-4 rounded-xl bg-slate-950/50 border border-slate-800">
        {/* CPU Cores */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-orange-400" />
              <span>Compute Sizing (CPU Cores)</span>
            </label>
            <span className="text-xs font-mono font-bold text-orange-400 px-2 py-0.5 bg-orange-500/10 rounded border border-orange-500/20">
              {formData.cpuCores} vCPUs
            </span>
          </div>
          <div className="flex items-center gap-2 flex-wrap mb-3">
            {CPU_PRESETS.map((cores) => (
              <button
                key={cores}
                type="button"
                onClick={() => onChange({ cpuCores: cores })}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                  formData.cpuCores === cores
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'bg-slate-900 border border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                {cores} Cores
              </button>
            ))}
          </div>
          <input
            type="range"
            min={1}
            max={64}
            step={1}
            value={formData.cpuCores}
            onChange={(e) => onChange({ cpuCores: parseInt(e.target.value, 10) })}
            className="w-full accent-orange-500 cursor-pointer"
          />
        </div>

        {/* RAM GB */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-orange-400" />
              <span>Memory Sizing (RAM)</span>
            </label>
            <span className="text-xs font-mono font-bold text-orange-400 px-2 py-0.5 bg-orange-500/10 rounded border border-orange-500/20">
              {formData.ramGb} GB RAM
            </span>
          </div>
          <div className="flex items-center gap-2 flex-wrap mb-3">
            {RAM_PRESETS.map((ram) => (
              <button
                key={ram}
                type="button"
                onClick={() => onChange({ ramGb: ram })}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                  formData.ramGb === ram
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'bg-slate-900 border border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                {ram} GB
              </button>
            ))}
          </div>
          <input
            type="range"
            min={2}
            max={128}
            step={2}
            value={formData.ramGb}
            onChange={(e) => onChange({ ramGb: parseFloat(e.target.value) })}
            className="w-full accent-orange-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Storage Requirements */}
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-2 flex items-center gap-1.5">
          <HardDrive className="w-3.5 h-3.5 text-orange-400" />
          <span>Storage & Attached Volumes</span>
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">OS Disk (Root Volume)</label>
            <div className="relative">
              <input
                type="number"
                min={20}
                max={500}
                value={formData.osDiskGb}
                onChange={(e) => {
                  const val = parseFloat(e.target.value) || 20;
                  onChange({ osDiskGb: val, storageGb: val + formData.dataDiskGb });
                }}
                className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 focus:outline-none focus:border-orange-500"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500">GB</span>
            </div>
          </div>
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Data Disk (/data Mount)</label>
            <div className="relative">
              <input
                type="number"
                min={0}
                max={2000}
                value={formData.dataDiskGb}
                onChange={(e) => {
                  const val = parseFloat(e.target.value) || 0;
                  onChange({ dataDiskGb: val, storageGb: formData.osDiskGb + val });
                }}
                className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 focus:outline-none focus:border-orange-500"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500">GB</span>
            </div>
          </div>
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Total Storage Allocated</label>
            <div className="px-3 py-2 bg-slate-950/40 border border-slate-800 rounded-lg text-xs font-mono font-bold text-orange-400 flex items-center justify-between">
              <span>{formData.storageGb} GB</span>
              <span className="text-[10px] text-slate-500 font-sans font-normal">SSD (IOPS: 3,000)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Network & Security Configuration */}
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-2 flex items-center gap-1.5">
          <Globe className="w-3.5 h-3.5 text-orange-400" />
          <span>Network & Security Group Assignment</span>
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* VLAN */}
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Network / VLAN</label>
            <select
              value={formData.vlan}
              onChange={(e) => onChange({ vlan: e.target.value })}
              className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="VLAN-100-QA">VLAN-100 (Enterprise QA)</option>
              <option value="VLAN-200-SIT">VLAN-200 (SIT Integration)</option>
              <option value="VLAN-300-CORE">VLAN-300 (Core Banking)</option>
              <option value="VLAN-400-PERF">VLAN-400 (Performance)</option>
            </select>
          </div>

          {/* Subnet */}
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Subnet Pool</label>
            <input
              type="text"
              value={formData.subnet}
              onChange={(e) => onChange({ subnet: e.target.value })}
              placeholder="10.240.16.0/24"
              className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* IP Requirement */}
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">IP Assignment</label>
            <select
              value={formData.ipRequirement}
              onChange={(e) => onChange({ ipRequirement: e.target.value as 'STATIC' | 'DHCP' })}
              className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="STATIC">Static IP from Pool</option>
              <option value="DHCP">Dynamic DHCP Lease</option>
            </select>
          </div>

          {/* Firewall Profile */}
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Security Firewall Profile</label>
            <select
              value={formData.firewallProfile}
              onChange={(e) => onChange({ firewallProfile: e.target.value })}
              className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="qa-standard-strict">QA Standard Strict (Ports 22, 80, 443, 8080, 5432)</option>
              <option value="sit-mesh">SIT Mesh (Internal Any + Ingress)</option>
              <option value="core-isolated">Core Isolated Zero-Trust</option>
            </select>
          </div>
        </div>

        {/* Load Balancer Toggle */}
        <div className="mt-4 flex items-center justify-between p-3 rounded-lg bg-slate-950/50 border border-slate-800">
          <div className="flex items-center gap-2.5">
            <Shield className="w-4 h-4 text-orange-400" />
            <div>
              <span className="text-xs font-semibold text-slate-200">Attach Dedicated Load Balancer (Reverse Proxy)</span>
              <p className="text-[11px] text-slate-500">Automatically provisions Nginx/ALB entrypoint with SSL termination</p>
            </div>
          </div>
          <input
            type="checkbox"
            checked={formData.loadBalancer}
            onChange={(e) => onChange({ loadBalancer: e.target.checked })}
            className="w-4 h-4 accent-orange-500 rounded cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
