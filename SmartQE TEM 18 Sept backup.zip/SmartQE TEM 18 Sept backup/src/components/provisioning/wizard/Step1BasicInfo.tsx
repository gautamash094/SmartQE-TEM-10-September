import React from 'react';
import {
  Building2,
  Briefcase,
  Layers,
  Calendar,
  User,
  Clock,
  Sparkles,
  Info,
} from 'lucide-react';
import { BusinessUnit, Project, ApplicationEntity } from '../../../services/portfolioService';
import { ProvisioningTemplate, ProvisioningMode } from '../../../types/provisioning';

export interface Step1FormData {
  businessUnit: string;
  projectName: string;
  applicationName: string;
  componentName: string;
  environmentName: string;
  environmentType: string;
  environmentOwner: string;
  requestedBy: string;
  description: string;
  provisioningMode: ProvisioningMode;
  templateId: string;
  scheduledStart: string;
  scheduledEnd: string;
}

interface Props {
  formData: Step1FormData;
  onChange: (data: Partial<Step1FormData>) => void;
  businessUnits: BusinessUnit[];
  projects: Project[];
  applications: ApplicationEntity[];
  templates: ProvisioningTemplate[];
  onSelectTemplate?: (template: ProvisioningTemplate) => void;
}

const ENVIRONMENT_TYPES = [
  { value: 'DEV', label: 'DEV - Development Sandbox', color: 'border-blue-500/40 text-blue-400' },
  { value: 'QA', label: 'QA - Quality Assurance', color: 'border-emerald-500/40 text-emerald-400' },
  { value: 'SIT', label: 'SIT - System Integration Testing', color: 'border-teal-500/40 text-teal-400' },
  { value: 'UAT', label: 'UAT - User Acceptance Testing', color: 'border-purple-500/40 text-purple-400' },
  { value: 'PERFORMANCE', label: 'Performance - Load & Stress Test', color: 'border-amber-500/40 text-amber-400' },
  { value: 'REGRESSION', label: 'Regression - Automated Test Bed', color: 'border-cyan-500/40 text-cyan-400' },
  { value: 'PRE-PRODUCTION', label: 'Pre-Production - Staging Mirror', color: 'border-rose-500/40 text-rose-400' },
];

export const Step1BasicInfo: React.FC<Props> = ({
  formData,
  onChange,
  businessUnits,
  projects,
  applications,
  templates,
  onSelectTemplate,
}) => {
  const filteredProjects = projects.filter(
    (p) => !formData.businessUnit || p.businessUnit === formData.businessUnit
  );

  const filteredApps = applications.filter(
    (a) => !formData.projectName || a.projectName === formData.projectName
  );

  const handleTemplateChange = (templateId: string) => {
    onChange({ templateId });
    const selected = templates.find((t) => t.id === templateId);
    if (selected && onSelectTemplate) {
      onSelectTemplate(selected);
    }
  };

  return (
    <div className="space-y-6">
      {/* Template Quick Selection Banner */}
      <div className="bg-gradient-to-r from-orange-950/40 to-slate-900 border border-orange-500/30 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-orange-500/20 border border-orange-500/30 flex items-center justify-center text-orange-400 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-white">Start from a Pre-Configured Template</h4>
            <p className="text-xs text-slate-400">
              Accelerate provisioning with enterprise stack blueprints (QA Java, Microservices K8s, SIT Oracle, Performance).
            </p>
          </div>
        </div>
        <div className="w-full md:w-72">
          <select
            value={formData.templateId}
            onChange={(e) => handleTemplateChange(e.target.value)}
            className="w-full px-3 py-2 bg-slate-950 border border-orange-500/40 rounded-lg text-xs font-semibold text-orange-400 focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer shadow-sm"
          >
            <option value="">Select a Template Blueprint...</option>
            {templates.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.environment_type})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Form Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
        <div className="border-b border-slate-800 pb-4">
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
            Step 1: Basic Information & Ownership
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Identify the enterprise hierarchy, target environment tier, and provisioning mode.
          </p>
        </div>

        {/* 2-Column Grid for Hierarchy */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Business Unit */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-orange-400" />
              <span>Business Unit *</span>
            </label>
            <select
              value={formData.businessUnit}
              onChange={(e) => onChange({ businessUnit: e.target.value, projectName: '', applicationName: '' })}
              className="w-full px-3 py-2.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="">Select Business Unit...</option>
              {businessUnits.map((bu) => (
                <option key={bu.id} value={bu.name}>
                  {bu.name} ({bu.code})
                </option>
              ))}
            </select>
          </div>

          {/* Project */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-orange-400" />
              <span>Project *</span>
            </label>
            <select
              value={formData.projectName}
              onChange={(e) => onChange({ projectName: e.target.value, applicationName: '' })}
              className="w-full px-3 py-2.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="">Select Project...</option>
              {filteredProjects.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name} ({p.code})
                </option>
              ))}
            </select>
          </div>

          {/* Application / Component */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-orange-400" />
              <span>Application / Primary Service *</span>
            </label>
            <select
              value={formData.applicationName}
              onChange={(e) => {
                const app = applications.find((a) => a.name === e.target.value);
                onChange({
                  applicationName: e.target.value,
                  componentName: app?.componentName || '',
                });
              }}
              className="w-full px-3 py-2.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="">Select Application...</option>
              {filteredApps.map((a) => (
                <option key={a.id} value={a.name}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          {/* Environment Name */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-orange-400" />
              <span>Target Environment Name *</span>
            </label>
            <input
              type="text"
              value={formData.environmentName}
              onChange={(e) => onChange({ environmentName: e.target.value })}
              placeholder="e.g. QA-Retail-Core-01"
              className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 focus:outline-none focus:border-orange-500"
            />
          </div>
        </div>

        {/* Environment Tier Selector */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-2">
            Environment Tier / Type *
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
            {ENVIRONMENT_TYPES.map((tier) => {
              const isSelected = formData.environmentType === tier.value;
              return (
                <button
                  key={tier.value}
                  type="button"
                  onClick={() => onChange({ environmentType: tier.value })}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    isSelected
                      ? 'bg-orange-500/15 border-orange-500 text-white shadow-sm ring-1 ring-orange-500/30'
                      : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:bg-slate-850 hover:border-slate-700'
                  }`}
                >
                  <p className="text-xs font-bold font-mono">{tier.value}</p>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">{tier.label.split(' - ')[1]}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Ownership & Provisioning Mode */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Owner */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-orange-400" />
              <span>Environment Owner *</span>
            </label>
            <input
              type="text"
              value={formData.environmentOwner}
              onChange={(e) => onChange({ environmentOwner: e.target.value })}
              placeholder="e.g. john.doe@smartqe.io"
              className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Requested By */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-orange-400" />
              <span>Requested By *</span>
            </label>
            <input
              type="text"
              value={formData.requestedBy}
              onChange={(e) => onChange({ requestedBy: e.target.value })}
              placeholder="e.g. Lead QA Engineer"
              className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Provisioning Mode */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-orange-400" />
              <span>Provisioning Mode *</span>
            </label>
            <select
              value={formData.provisioningMode}
              onChange={(e) => onChange({ provisioningMode: e.target.value as ProvisioningMode })}
              className="w-full px-3 py-2.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="ON_DEMAND">On Demand (Execute Immediately)</option>
              <option value="SCHEDULED">Scheduled (Booked Slot)</option>
              <option value="TEMPLATE_BASED">Template Based Blueprint</option>
            </select>
          </div>
        </div>

        {/* Schedule Date Range (If Scheduled or On Demand) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 p-4 rounded-lg bg-slate-950/50 border border-slate-800">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-orange-400" />
              <span>Required Start Date / Time</span>
            </label>
            <input
              type="datetime-local"
              value={formData.scheduledStart}
              onChange={(e) => onChange({ scheduledStart: e.target.value })}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 focus:outline-none focus:border-orange-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-orange-400" />
              <span>Expected End Date / Time</span>
            </label>
            <input
              type="datetime-local"
              value={formData.scheduledEnd}
              onChange={(e) => onChange({ scheduledEnd: e.target.value })}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 focus:outline-none focus:border-orange-500"
            />
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1.5">
            Provisioning Objective & Release Notes
          </label>
          <textarea
            rows={2}
            value={formData.description}
            onChange={(e) => onChange({ description: e.target.value })}
            placeholder="Provide context on test suites, expected duration, and team usage..."
            className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500"
          />
        </div>
      </div>
    </div>
  );
};
