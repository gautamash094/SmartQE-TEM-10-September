import React from 'react';
import {
  FileText,
  Cpu,
  Boxes,
  Sliders,
  GitFork,
  ShieldCheck,
  CheckSquare,
  Check,
} from 'lucide-react';

export interface WizardStepDef {
  number: number;
  title: string;
  shortDesc: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const WIZARD_STEPS: WizardStepDef[] = [
  { number: 1, title: 'Basic Info', shortDesc: 'Project & Tier', icon: FileText },
  { number: 2, title: 'Infrastructure', shortDesc: 'Compute & Network', icon: Cpu },
  { number: 3, title: 'Software Stack', shortDesc: 'OS & Runtimes', icon: Boxes },
  { number: 4, title: 'Configuration', shortDesc: 'Env & Secrets', icon: Sliders },
  { number: 5, title: 'Dependencies', shortDesc: 'Architecture Graph', icon: GitFork },
  { number: 6, title: 'Validation', shortDesc: 'Pre-Flight Checks', icon: ShieldCheck },
  { number: 7, title: 'Provisioning Plan', shortDesc: 'Review & Submit', icon: CheckSquare },
];

interface Props {
  currentStep: number;
  onSelectStep: (stepNumber: number) => void;
  maxAccessibleStep: number;
}

export const WizardStepper: React.FC<Props> = ({
  currentStep,
  onSelectStep,
  maxAccessibleStep,
}) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {WIZARD_STEPS.map((step) => {
          const Icon = step.icon;
          const isCurrent = currentStep === step.number;
          const isCompleted = currentStep > step.number;
          const isAccessible = step.number <= maxAccessibleStep;

          return (
            <button
              key={step.number}
              type="button"
              disabled={!isAccessible}
              onClick={() => isAccessible && onSelectStep(step.number)}
              className={`flex items-center gap-2.5 p-2.5 rounded-lg border text-left transition-all ${
                isCurrent
                  ? 'bg-orange-500/15 border-orange-500 text-white shadow-[0_0_15px_rgba(249,115,22,0.15)] ring-1 ring-orange-500/30'
                  : isCompleted
                  ? 'bg-slate-850/80 border-slate-700 text-slate-200 hover:bg-slate-800 cursor-pointer'
                  : isAccessible
                  ? 'bg-slate-950/40 border-slate-800 text-slate-400 hover:bg-slate-900 cursor-pointer'
                  : 'bg-slate-950/20 border-slate-850 text-slate-600 opacity-50 cursor-not-allowed'
              }`}
            >
              {/* Step Icon / Number Indicator */}
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs font-mono font-bold transition-colors ${
                  isCurrent
                    ? 'bg-orange-500 text-white shadow-sm'
                    : isCompleted
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {isCompleted ? <Check className="w-3.5 h-3.5 stroke-[2.5]" /> : step.number}
              </div>

              {/* Title & Short Desc */}
              <div className="min-w-0 flex-1 truncate">
                <p
                  className={`text-xs font-semibold truncate ${
                    isCurrent ? 'text-orange-400' : isCompleted ? 'text-slate-200' : 'text-slate-400'
                  }`}
                >
                  {step.title}
                </p>
                <p className="text-[10px] text-slate-500 truncate">{step.shortDesc}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
