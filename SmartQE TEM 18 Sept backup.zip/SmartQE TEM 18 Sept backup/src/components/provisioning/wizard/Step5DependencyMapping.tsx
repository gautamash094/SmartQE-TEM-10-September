import React, { useState } from 'react';
import {
  GitFork,
  Database,
  Globe,
  Radio,
  Server,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Plus,
  Trash2,
  ArrowDown,
  ArrowRight,
} from 'lucide-react';
import { DependencyItem } from '../../../types/provisioning';

interface Props {
  dependencies: DependencyItem[];
  onChange: (dependencies: DependencyItem[]) => void;
  appName?: string;
}

export const Step5DependencyMapping: React.FC<Props> = ({
  dependencies,
  onChange,
  appName = 'Application Service',
}) => {
  const [depName, setDepName] = useState('');
  const [depType, setDepType] = useState<DependencyItem['type']>('DATABASE');
  const [depEndpoint, setDepEndpoint] = useState('');
  const [depRequired, setDepRequired] = useState(true);

  const handleAddDependency = () => {
    if (!depName) return;
    const newDep: DependencyItem = {
      name: depName.trim(),
      type: depType,
      endpoint: depEndpoint.trim() || undefined,
      required: depRequired,
      status: 'RESOLVED',
      healthStatus: 'HEALTHY',
    };
    onChange([...dependencies, newDep]);
    setDepName('');
    setDepEndpoint('');
    setDepRequired(true);
  };

  const handleRemove = (idx: number) => {
    onChange(dependencies.filter((_, i) => i !== idx));
  };

  const getTypeIcon = (type: DependencyItem['type']) => {
    switch (type) {
      case 'DATABASE':
        return Database;
      case 'EXTERNAL_API':
        return Globe;
      case 'MESSAGE_QUEUE':
        return Radio;
      case 'MIDDLEWARE':
        return Layers;
      default:
        return Server;
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Step 5: Architectural Dependency Mapping
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Map upstream databases, messaging brokers, and external APIs required for end-to-end testing readiness.
        </p>
      </div>

      {/* Visual Flow Topology Graph */}
      <div className="p-6 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col items-center">
        {/* Level 1: Primary Application */}
        <div className="w-full max-w-md p-4 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-[0_0_25px_rgba(249,115,22,0.25)] text-center relative">
          <div className="flex items-center justify-center gap-2 mb-1">
            <Server className="w-4 h-4" />
            <h4 className="text-sm font-bold tracking-wide">{appName}</h4>
          </div>
          <p className="text-[11px] text-orange-100 font-mono">Target Deployment Core Service</p>
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-slate-900 border border-orange-500 flex items-center justify-center text-orange-400">
            <ArrowDown className="w-3 h-3" />
          </div>
        </div>

        {/* Level 2: Downstream Dependencies Grid */}
        <div className="w-full mt-6 pt-4 border-t border-slate-800/80">
          <div className="text-center mb-4">
            <span className="text-[11px] font-mono uppercase tracking-widest text-slate-400 bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
              Downstream Dependent Services ({dependencies.length})
            </span>
          </div>

          {dependencies.length === 0 ? (
            <div className="text-center py-6 text-xs text-slate-500">
              No downstream dependencies added yet. Add databases, queues, or mock endpoints below.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {dependencies.map((dep, idx) => {
                const Icon = getTypeIcon(dep.type);
                return (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-lg bg-slate-800 text-orange-400 border border-slate-700">
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <span className="text-xs font-bold text-white truncate max-w-[140px]">
                            {dep.name}
                          </span>
                        </div>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-mono border ${
                            dep.required
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {dep.required ? 'MANDATORY' : 'OPTIONAL'}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-400 space-y-0.5 mb-3 font-mono">
                        <p className="truncate">Type: {dep.type}</p>
                        {dep.endpoint && (
                          <p className="text-slate-500 truncate" title={dep.endpoint}>
                            URI: {dep.endpoint}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                      <div className="flex items-center gap-1.5 text-[11px] font-mono text-emerald-400">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{dep.healthStatus || 'HEALTHY'}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemove(idx)}
                        className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Add Dependency Row */}
      <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
        <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5 font-mono">
          <Plus className="w-3.5 h-3.5 text-orange-400" />
          <span>Add Upstream / Downstream Dependency</span>
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <input
            type="text"
            placeholder="Dependency Name (e.g. Payments DB)"
            value={depName}
            onChange={(e) => setDepName(e.target.value)}
            className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white"
          />
          <select
            value={depType}
            onChange={(e) => setDepType(e.target.value as any)}
            className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white cursor-pointer"
          >
            <option value="DATABASE">Database (PostgreSQL/Oracle/MySQL)</option>
            <option value="EXTERNAL_API">External Third-Party API</option>
            <option value="MESSAGE_QUEUE">Message Broker (Kafka/RabbitMQ)</option>
            <option value="SERVICE">Internal Microservice</option>
            <option value="MIDDLEWARE">Middleware / ESB</option>
          </select>
          <input
            type="text"
            placeholder="Target Endpoint URL / Hostname"
            value={depEndpoint}
            onChange={(e) => setDepEndpoint(e.target.value)}
            className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white"
          />
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={depRequired}
                onChange={(e) => setDepRequired(e.target.checked)}
                className="w-3.5 h-3.5 accent-orange-500 rounded"
              />
              <span>Required</span>
            </label>
            <button
              type="button"
              onClick={handleAddDependency}
              disabled={!depName}
              className="flex-1 px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded text-xs font-semibold disabled:opacity-50"
            >
              Add Node
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
