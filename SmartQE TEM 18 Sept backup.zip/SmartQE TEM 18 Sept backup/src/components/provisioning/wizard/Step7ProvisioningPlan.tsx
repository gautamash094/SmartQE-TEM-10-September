import React from 'react';
import {
  CheckSquare,
  Clock,
  Server,
  Layers,
  ArrowRight,
  ShieldCheck,
  Play,
  Cpu,
  Globe,
  HardDrive,
  Boxes,
} from 'lucide-react';
import { Step1FormData } from './Step1BasicInfo';
import { Step2FormData } from './Step2Infrastructure';
import { SoftwareComponent, DependencyItem } from '../../../types/provisioning';

interface Props {
  step1: Step1FormData;
  step2: Step2FormData;
  softwareStack: SoftwareComponent[];
  dependencies: DependencyItem[];
  onSubmit: () => void;
  isSubmitting: boolean;
  hasBlockingErrors: boolean;
}

export const Step7ProvisioningPlan: React.FC<Props> = ({
  step1,
  step2,
  softwareStack,
  dependencies,
  onSubmit,
  isSubmitting,
  hasBlockingErrors,
}) => {
  // Generate visual steps
  const planSteps = [
    { order: 1, title: `Allocate Compute (${step2.computeType})`, cat: 'INFRASTRUCTURE', est: '30s', provider: 'Mock Cloud Engine' },
    { order: 2, title: `Allocate Static IP on ${step2.vlan}`, cat: 'NETWORK', est: '20s', provider: 'Mock Network Provider' },
    { order: 3, title: `Create Storage (${step2.osDiskGb}GB OS + ${step2.dataDiskGb}GB Data)`, cat: 'STORAGE', est: '25s', provider: 'Mock Storage Provider' },
    { order: 4, title: `Configure Security Group & Ingress Rules`, cat: 'NETWORK', est: '20s', provider: 'Mock Network Provider' },
    { order: 5, title: `Deploy Base OS & CIS Security Baseline`, cat: 'SOFTWARE', est: '45s', provider: 'Mock Software Provider' },
    ...softwareStack.map((sw, i) => ({
      order: 6 + i,
      title: `Install ${sw.name} (v${sw.version})`,
      cat: 'SOFTWARE',
      est: '35s',
      provider: 'Mock Package Manager',
    })),
    { order: 6 + softwareStack.length, title: 'Configure Environment Variables & Vault Secret References', cat: 'CONFIGURATION', est: '25s', provider: 'Configuration Manager' },
    { order: 7 + softwareStack.length, title: `Deploy ${step1.applicationName || 'Application'} & Start System Services`, cat: 'DEPLOYMENT', est: '40s', provider: 'Deployment Engine' },
    { order: 8 + softwareStack.length, title: 'Execute Post-Provisioning Automated Health Probes (Ping, Ports, DB, HTTP)', cat: 'HEALTH_CHECK', est: '30s', provider: 'Health Probe Suite' },
  ];

  const totalEstSec = planSteps.reduce((acc, s) => acc + parseInt(s.est, 10), 0);
  const totalMin = Math.ceil(totalEstSec / 60);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
            Step 7: Provisioning DAG Plan & Execution Review
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Review the generated sequential orchestration pipeline and configuration summary before submission.
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-400 font-mono text-xs font-bold">
          <Clock className="w-4 h-4" />
          <span>Estimated Duration: ~{totalMin} Minutes</span>
        </div>
      </div>

      {/* Summary Matrix Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
          <span className="text-[10px] font-mono text-slate-500 uppercase">Target Environment</span>
          <p className="text-sm font-bold text-white font-mono mt-0.5 truncate">{step1.environmentName || 'Untitled'}</p>
          <span className="inline-block mt-1 px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-orange-400 border border-slate-700">
            {step1.environmentType}
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
          <span className="text-[10px] font-mono text-slate-500 uppercase">Compute & RAM</span>
          <p className="text-sm font-bold text-white font-mono mt-0.5">
            {step2.cpuCores} Cores / {step2.ramGb} GB
          </p>
          <span className="text-[11px] text-slate-400 font-sans block mt-1">{step2.computeType}</span>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
          <span className="text-[10px] font-mono text-slate-500 uppercase">Storage Sizing</span>
          <p className="text-sm font-bold text-white font-mono mt-0.5">{step2.storageGb} GB Total</p>
          <span className="text-[11px] text-slate-400 font-sans block mt-1">
            {step2.osDiskGb}GB OS + {step2.dataDiskGb}GB Data
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
          <span className="text-[10px] font-mono text-slate-500 uppercase">Software Stack</span>
          <p className="text-sm font-bold text-white font-mono mt-0.5">{softwareStack.length} Packages</p>
          <span className="text-[11px] text-slate-400 font-sans block mt-1">
            {dependencies.length} Linked Dependencies
          </span>
        </div>
      </div>

      {/* Sequential DAG Plan */}
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-3 flex items-center gap-1.5">
          <CheckSquare className="w-3.5 h-3.5 text-orange-400" />
          <span>Sequential Step Execution Plan ({planSteps.length} Orchestration Tasks)</span>
        </label>

        <div className="space-y-2">
          {planSteps.map((step) => (
            <div
              key={step.order}
              className="p-3 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="w-6 h-6 rounded-md bg-slate-900 border border-slate-700 flex items-center justify-center text-xs font-mono font-bold text-orange-400 shrink-0">
                  {step.order}
                </span>
                <div className="min-w-0">
                  <span className="text-xs font-semibold text-slate-200 block truncate">{step.title}</span>
                  <p className="text-[10px] text-slate-500 font-mono">
                    Provider: {step.provider} • Category: {step.cat}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-[11px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  ~{step.est}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Submission Action Card */}
      <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="text-xs font-bold text-white font-mono uppercase">Ready to Orchestrate?</h4>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Submitting will initiate the asynchronous provisioning worker pipeline and stream logs to the live console.
          </p>
        </div>

        <button
          type="button"
          onClick={onSubmit}
          disabled={isSubmitting || hasBlockingErrors || !step1.environmentName}
          className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>{isSubmitting ? 'Submitting Request...' : 'Submit & Execute Provisioning'}</span>
        </button>
      </div>
    </div>
  );
};
