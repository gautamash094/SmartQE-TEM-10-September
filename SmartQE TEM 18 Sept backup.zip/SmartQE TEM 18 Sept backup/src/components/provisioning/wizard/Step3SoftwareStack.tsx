import React, { useState } from 'react';
import {
  Boxes,
  Plus,
  Trash2,
  CheckCircle2,
  Layers,
  Sparkles,
  Info,
} from 'lucide-react';
import { SoftwareComponent } from '../../../types/provisioning';

interface Props {
  softwareStack: SoftwareComponent[];
  onChange: (stack: SoftwareComponent[]) => void;
}

const CATALOG_ITEMS: SoftwareComponent[] = [
  { name: 'Red Hat Enterprise Linux', version: '9.3', vendor: 'Red Hat', required: true, category: 'Operating System' },
  { name: 'Ubuntu Enterprise Server', version: '22.04 LTS', vendor: 'Canonical', required: true, category: 'Operating System' },
  { name: 'Oracle Linux', version: '9.3', vendor: 'Oracle', required: true, category: 'Operating System' },
  { name: 'OpenJDK', version: '21.0.2', vendor: 'Eclipse Temurin', required: true, category: 'JDK / Runtime' },
  { name: 'OpenJDK', version: '17.0.10', vendor: 'Eclipse Temurin', required: false, category: 'JDK / Runtime' },
  { name: 'Apache Tomcat', version: '10.1.18', vendor: 'Apache Foundation', required: true, category: 'Application Server' },
  { name: 'PostgreSQL', version: '16.1', vendor: 'PostgreSQL Global Group', required: true, category: 'Database' },
  { name: 'Oracle Database Enterprise', version: '19.3.0', vendor: 'Oracle', required: true, category: 'Database' },
  { name: 'Redis Cache', version: '7.2.4', vendor: 'Redis Ltd', required: false, category: 'Cache' },
  { name: 'Apache Kafka', version: '3.6.1', vendor: 'Apache Foundation', required: false, category: 'Middleware' },
  { name: 'Node.js', version: '20.11.0', vendor: 'OpenJS Foundation', required: false, category: 'JDK / Runtime' },
  { name: 'Python FastAPI', version: '3.11.7', vendor: 'PSF', required: false, category: 'JDK / Runtime' },
  { name: 'Nginx', version: '1.24.0', vendor: 'F5 / Nginx', required: false, category: 'Web Server' },
];

const STACK_PRESETS = [
  {
    name: 'QA Java Stack',
    desc: 'RHEL 9 + Java 21 + Tomcat 10 + PostgreSQL 16 + Nginx',
    items: [
      { name: 'Red Hat Enterprise Linux', version: '9.3', vendor: 'Red Hat', required: true, category: 'Operating System' },
      { name: 'OpenJDK', version: '21.0.2', vendor: 'Eclipse Temurin', required: true, category: 'JDK / Runtime' },
      { name: 'Apache Tomcat', version: '10.1.18', vendor: 'Apache Foundation', required: true, category: 'Application Server' },
      { name: 'PostgreSQL', version: '16.1', vendor: 'PostgreSQL Global Group', required: true, category: 'Database' },
      { name: 'Nginx', version: '1.24.0', vendor: 'F5 / Nginx', required: false, category: 'Web Server' },
    ],
  },
  {
    name: 'Modern Microservices Stack',
    desc: 'Ubuntu 22 + Node.js 20 + Python 3.11 + Redis 7 + Kafka 3.6',
    items: [
      { name: 'Ubuntu Enterprise Server', version: '22.04 LTS', vendor: 'Canonical', required: true, category: 'Operating System' },
      { name: 'Node.js', version: '20.11.0', vendor: 'OpenJS Foundation', required: true, category: 'JDK / Runtime' },
      { name: 'Python FastAPI', version: '3.11.7', vendor: 'PSF', required: true, category: 'JDK / Runtime' },
      { name: 'Redis Cache', version: '7.2.4', vendor: 'Redis Ltd', required: true, category: 'Cache' },
      { name: 'Apache Kafka', version: '3.6.1', vendor: 'Apache Foundation', required: true, category: 'Middleware' },
    ],
  },
  {
    name: 'Core Banking Stack',
    desc: 'Oracle Linux 9 + WebLogic 14c + Oracle DB 19c Enterprise',
    items: [
      { name: 'Oracle Linux', version: '9.3', vendor: 'Oracle', required: true, category: 'Operating System' },
      { name: 'Oracle WebLogic Server', version: '14.1.1', vendor: 'Oracle', required: true, category: 'Application Server' },
      { name: 'Oracle Database Enterprise', version: '19.3.0', vendor: 'Oracle', required: true, category: 'Database' },
    ],
  },
];

export const Step3SoftwareStack: React.FC<Props> = ({ softwareStack, onChange }) => {
  const [customName, setCustomName] = useState('');
  const [customVersion, setCustomVersion] = useState('');
  const [customVendor, setCustomVendor] = useState('');
  const [customCategory, setCustomCategory] = useState('Middleware');
  const [showAddForm, setShowAddForm] = useState(false);

  const handleAddCustom = () => {
    if (!customName || !customVersion) return;
    const newItem: SoftwareComponent = {
      name: customName.trim(),
      version: customVersion.trim(),
      vendor: customVendor.trim() || 'Custom',
      category: customCategory,
      required: true,
    };
    onChange([...softwareStack, newItem]);
    setCustomName('');
    setCustomVersion('');
    setCustomVendor('');
    setShowAddForm(false);
  };

  const handleRemove = (index: number) => {
    const updated = softwareStack.filter((_, i) => i !== index);
    onChange(updated);
  };

  const handleToggleRequired = (index: number) => {
    const updated = [...softwareStack];
    updated[index] = {
      ...updated[index],
      required: !updated[index].required,
    };
    onChange(updated);
  };

  const handleApplyPreset = (items: SoftwareComponent[]) => {
    onChange(items);
  };

  const handleAddFromCatalog = (item: SoftwareComponent) => {
    const exists = softwareStack.some((s) => s.name === item.name);
    if (!exists) {
      onChange([...softwareStack, item]);
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Step 3: Software Stack & Runtime Configuration
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Select operating systems, language runtimes, application servers, middleware, and databases.
        </p>
      </div>

      {/* Preset Stack Buttons */}
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-2 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-orange-400" />
          <span>Reusable Software Stack Templates</span>
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {STACK_PRESETS.map((preset) => (
            <button
              key={preset.name}
              type="button"
              onClick={() => handleApplyPreset(preset.items)}
              className="p-3.5 rounded-xl border border-slate-800 bg-slate-950/60 hover:bg-slate-850 hover:border-orange-500/40 text-left transition-all group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-white group-hover:text-orange-400 transition-colors">
                  {preset.name}
                </span>
                <span className="text-[10px] font-mono text-orange-400 bg-orange-500/10 px-1.5 py-0.5 rounded">
                  Apply
                </span>
              </div>
              <p className="text-[11px] text-slate-400">{preset.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Active Software Stack List */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
            <Boxes className="w-3.5 h-3.5 text-orange-400" />
            <span>Configured Software Components ({softwareStack.length})</span>
          </label>
          <button
            type="button"
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-2.5 py-1 bg-orange-600/90 hover:bg-orange-500 text-white rounded text-xs font-medium flex items-center gap-1 shadow-sm transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Custom Package</span>
          </button>
        </div>

        {/* Custom Add Form */}
        {showAddForm && (
          <div className="p-4 rounded-xl bg-slate-950/80 border border-orange-500/30 mb-4 space-y-3">
            <h4 className="text-xs font-bold text-orange-400 font-mono">Add Custom Software Package</h4>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <input
                type="text"
                placeholder="Software Name (e.g. RabbitMQ)"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white"
              />
              <input
                type="text"
                placeholder="Version (e.g. 3.12.0)"
                value={customVersion}
                onChange={(e) => setCustomVersion(e.target.value)}
                className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white"
              />
              <input
                type="text"
                placeholder="Vendor (e.g. VMware)"
                value={customVendor}
                onChange={(e) => setCustomVendor(e.target.value)}
                className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white"
              />
              <select
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white cursor-pointer"
              >
                <option value="Operating System">Operating System</option>
                <option value="JDK / Runtime">JDK / Runtime</option>
                <option value="Application Server">Application Server</option>
                <option value="Database">Database</option>
                <option value="Middleware">Middleware</option>
                <option value="Cache">Cache</option>
                <option value="Web Server">Web Server</option>
                <option value="Performance Tool">Performance Tool</option>
              </select>
            </div>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAddCustom}
                disabled={!customName || !customVersion}
                className="px-3 py-1 bg-orange-600 hover:bg-orange-500 text-white rounded text-xs font-semibold disabled:opacity-50"
              >
                Save Component
              </button>
            </div>
          </div>
        )}

        {/* Stack Table */}
        {softwareStack.length === 0 ? (
          <div className="p-8 rounded-xl bg-slate-950/40 border border-slate-800 text-center text-slate-400 text-xs">
            No software components selected. Select a preset template or add items from the catalogue below.
          </div>
        ) : (
          <div className="space-y-2">
            {softwareStack.map((item, idx) => (
              <div
                key={`${item.name}-${idx}`}
                className="p-3 rounded-lg bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-7 h-7 rounded bg-slate-800 border border-slate-700 flex items-center justify-center text-orange-400 shrink-0">
                    <Layers className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">{item.name}</span>
                      <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-800 text-orange-400 border border-slate-700">
                        v{item.version}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate">
                      {item.vendor || 'Standard'} • {item.category || 'Runtime'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleToggleRequired(idx)}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono border transition-colors ${
                      item.required
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}
                  >
                    {item.required ? 'REQUIRED' : 'OPTIONAL'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRemove(idx)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                    title="Remove Component"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Catalogue Quick Add Grid */}
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-2">
          Enterprise Software Catalogue (Click to Add)
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {CATALOG_ITEMS.map((item) => {
            const isAdded = softwareStack.some((s) => s.name === item.name);
            return (
              <button
                key={`${item.name}-${item.version}`}
                type="button"
                disabled={isAdded}
                onClick={() => handleAddFromCatalog(item)}
                className={`p-2.5 rounded-lg border text-left text-xs transition-all flex items-center justify-between ${
                  isAdded
                    ? 'bg-slate-950/30 border-slate-800/60 text-slate-500 opacity-60 cursor-default'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-orange-500/40 hover:bg-slate-850 cursor-pointer'
                }`}
              >
                <div className="min-w-0 truncate">
                  <span className="block font-semibold truncate text-white">{item.name}</span>
                  <span className="text-[10px] text-slate-400 font-mono">v{item.version}</span>
                </div>
                {isAdded ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 ml-1" />
                ) : (
                  <Plus className="w-3.5 h-3.5 text-orange-400 shrink-0 ml-1" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
