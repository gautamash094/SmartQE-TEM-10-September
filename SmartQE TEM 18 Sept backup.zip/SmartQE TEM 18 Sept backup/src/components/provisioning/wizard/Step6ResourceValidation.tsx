import React from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RotateCcw,
  Sparkles,
  Layers,
  AlertOctagon,
} from 'lucide-react';
import { PreflightValidationReport, PreflightCheckItem } from '../../../types/provisioning';

interface Props {
  validationReport: PreflightValidationReport | null;
  isValidating: boolean;
  onRunValidation: () => void;
}

export const Step6ResourceValidation: React.FC<Props> = ({
  validationReport,
  isValidating,
  onRunValidation,
}) => {
  const getStatusBadge = (status: PreflightCheckItem['status']) => {
    switch (status) {
      case 'AVAILABLE':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" /> ✓ AVAILABLE
          </span>
        );
      case 'VALID':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20 font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" /> ✓ VALID
          </span>
        );
      case 'WARNING':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-bold">
            <AlertTriangle className="w-3.5 h-3.5" /> ⚠ WARNING
          </span>
        );
      case 'BLOCKING_ERROR':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-mono text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20 font-bold">
            <XCircle className="w-3.5 h-3.5" /> ✕ BLOCKING ERROR
          </span>
        );
    }
  };

  const hasBlocking = validationReport?.has_blocking_errors || false;
  const overallStatus = validationReport?.overall_status || 'PASSED';

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
            Step 6: Pre-Flight Resource & Conflict Validation
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated verification across compute quotas, IP pools, TEM Bookings schedule conflicts, and security policies.
          </p>
        </div>
        <button
          type="button"
          onClick={onRunValidation}
          disabled={isValidating}
          className="px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white rounded-lg text-xs font-semibold flex items-center gap-2 shadow-lg shadow-orange-600/20 transition-all disabled:opacity-50"
        >
          <RotateCcw className={`w-3.5 h-3.5 ${isValidating ? 'animate-spin' : ''}`} />
          <span>{isValidating ? 'Running Validation...' : 'Re-Run Pre-Flight'}</span>
        </button>
      </div>

      {/* Summary Status Header Banner */}
      {validationReport && (
        <div
          className={`p-4 rounded-xl border flex items-center justify-between gap-4 ${
            hasBlocking
              ? 'bg-rose-950/40 border-rose-500/40 text-rose-200'
              : overallStatus === 'WARNING'
              ? 'bg-amber-950/40 border-amber-500/40 text-amber-200'
              : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
          }`}
        >
          <div className="flex items-center gap-3">
            {hasBlocking ? (
              <AlertOctagon className="w-6 h-6 text-rose-400 shrink-0" />
            ) : overallStatus === 'WARNING' ? (
              <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0" />
            ) : (
              <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0" />
            )}
            <div>
              <h4 className="text-xs font-bold uppercase font-mono tracking-wider">
                {hasBlocking
                  ? 'Pre-Flight Failed: Blocking Conflicts Detected'
                  : overallStatus === 'WARNING'
                  ? 'Pre-Flight Passed with Advisories (Manager Review Recommended)'
                  : 'Pre-Flight Succeeded: All Resource Gates Clear'}
              </h4>
              <p className="text-[11px] opacity-80 mt-0.5">
                {hasBlocking
                  ? 'Resolve highlighted errors before proceeding to plan execution.'
                  : 'All hardware quotas, IP pools, and TEM booking reservation schedules validated.'}
              </p>
            </div>
          </div>
          <div className="text-right hidden sm:block">
            <span className="text-[10px] font-mono opacity-60">Timestamp</span>
            <p className="text-xs font-mono font-semibold">
              {new Date(validationReport.validation_timestamp).toLocaleTimeString()}
            </p>
          </div>
        </div>
      )}

      {/* Validation Checklist Items */}
      <div className="space-y-3">
        {validationReport?.validations.map((item, idx) => (
          <div
            key={idx}
            className={`p-4 rounded-xl border transition-all ${
              item.status === 'BLOCKING_ERROR'
                ? 'bg-rose-950/20 border-rose-500/30'
                : item.status === 'WARNING'
                ? 'bg-amber-950/20 border-amber-500/30'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-white tracking-wide">
                  {item.check}
                </span>
                <span className="text-[10px] text-slate-500 font-sans">
                  ({item.category})
                </span>
              </div>
              {getStatusBadge(item.status)}
            </div>
            <p className="text-xs text-slate-300">{item.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
