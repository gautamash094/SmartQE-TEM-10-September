import React, { useState } from 'react';
import {
  Sliders,
  Plus,
  Trash2,
  Lock,
  KeyRound,
  ShieldCheck,
  Code,
  ToggleLeft,
  ToggleRight,
  Info,
} from 'lucide-react';
import { EnvironmentVariable, SecretReference } from '../../../types/provisioning';

export interface Step4FormData {
  envVars: EnvironmentVariable[];
  secretsReferences: SecretReference[];
  applicationProperties: { key: string; value: string }[];
  servicePorts: number[];
  featureFlags: { key: string; enabled: boolean }[];
}

interface Props {
  formData: Step4FormData;
  onChange: (data: Partial<Step4FormData>) => void;
}

export const Step4Configuration: React.FC<Props> = ({ formData, onChange }) => {
  const [newEnvKey, setNewEnvKey] = useState('');
  const [newEnvVal, setNewEnvVal] = useState('');
  const [newEnvSecret, setNewEnvSecret] = useState(false);

  const [newSecretKey, setNewSecretKey] = useState('');
  const [newSecretRef, setNewSecretRef] = useState('');

  const [newPropKey, setNewPropKey] = useState('');
  const [newPropVal, setNewPropVal] = useState('');

  const [newPort, setNewPort] = useState('');
  const [newFlagKey, setNewFlagKey] = useState('');

  // Env Vars
  const handleAddEnvVar = () => {
    if (!newEnvKey) return;
    onChange({
      envVars: [
        ...formData.envVars,
        { key: newEnvKey.trim(), value: newEnvVal.trim(), isSecret: newEnvSecret },
      ],
    });
    setNewEnvKey('');
    setNewEnvVal('');
    setNewEnvSecret(false);
  };

  const handleRemoveEnvVar = (idx: number) => {
    onChange({ envVars: formData.envVars.filter((_, i) => i !== idx) });
  };

  // Secrets Reference
  const handleAddSecretRef = () => {
    if (!newSecretKey || !newSecretRef) return;
    onChange({
      secretsReferences: [
        ...formData.secretsReferences,
        { key: newSecretKey.trim(), reference: newSecretRef.trim() },
      ],
    });
    setNewSecretKey('');
    setNewSecretRef('');
  };

  const handleRemoveSecretRef = (idx: number) => {
    onChange({
      secretsReferences: formData.secretsReferences.filter((_, i) => i !== idx),
    });
  };

  // App Properties
  const handleAddProp = () => {
    if (!newPropKey) return;
    onChange({
      applicationProperties: [
        ...formData.applicationProperties,
        { key: newPropKey.trim(), value: newPropVal.trim() },
      ],
    });
    setNewPropKey('');
    setNewPropVal('');
  };

  const handleRemoveProp = (idx: number) => {
    onChange({
      applicationProperties: formData.applicationProperties.filter((_, i) => i !== idx),
    });
  };

  // Service Ports
  const handleAddPort = () => {
    const p = parseInt(newPort, 10);
    if (p > 0 && !formData.servicePorts.includes(p)) {
      onChange({ servicePorts: [...formData.servicePorts, p] });
      setNewPort('');
    }
  };

  const handleRemovePort = (p: number) => {
    onChange({ servicePorts: formData.servicePorts.filter((port) => port !== p) });
  };

  // Feature Flags
  const handleAddFlag = () => {
    if (!newFlagKey) return;
    onChange({
      featureFlags: [...formData.featureFlags, { key: newFlagKey.trim(), enabled: true }],
    });
    setNewFlagKey('');
  };

  const handleToggleFlag = (idx: number) => {
    const updated = [...formData.featureFlags];
    updated[idx] = { ...updated[idx], enabled: !updated[idx].enabled };
    onChange({ featureFlags: updated });
  };

  const handleRemoveFlag = (idx: number) => {
    onChange({ featureFlags: formData.featureFlags.filter((_, i) => i !== idx) });
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Step 4: Environment Configuration & Secrets Management
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Specify runtime parameters, application properties, service ports, and enterprise secret vault references.
        </p>
      </div>

      {/* Security Best Practice Notice */}
      <div className="p-3.5 rounded-xl bg-slate-950/60 border border-orange-500/30 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300">
          <span className="font-semibold text-white">Enterprise Zero-Trust Security Standard: </span>
          Sensitive credentials (passwords, tokens, private keys) must NEVER be entered as raw plaintext values.
          Use external secret references (e.g., <code className="font-mono text-orange-300">vault://tem/qa/app_db/password</code> or <code className="font-mono text-orange-300">aws-sm://tem-qa-secrets</code>).
        </div>
      </div>

      {/* 1. Secrets References */}
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-2 flex items-center gap-1.5">
          <KeyRound className="w-3.5 h-3.5 text-orange-400" />
          <span>Secret Vault References ({formData.secretsReferences.length})</span>
        </label>

        {/* Add Secret Row */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 mb-3">
          <input
            type="text"
            placeholder="Secret Variable Key (e.g. DB_PASS)"
            value={newSecretKey}
            onChange={(e) => setNewSecretKey(e.target.value)}
            className="sm:col-span-2 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-xs font-mono text-white"
          />
          <input
            type="text"
            placeholder="Vault URI (vault://path/to/secret)"
            value={newSecretRef}
            onChange={(e) => setNewSecretRef(e.target.value)}
            className="sm:col-span-2 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-xs font-mono text-orange-300"
          />
          <button
            type="button"
            onClick={handleAddSecretRef}
            disabled={!newSecretKey || !newSecretRef}
            className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded text-xs font-semibold flex items-center justify-center gap-1 disabled:opacity-50"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Secret</span>
          </button>
        </div>

        {/* List of Secrets */}
        <div className="space-y-1.5">
          {formData.secretsReferences.map((sec, idx) => (
            <div
              key={idx}
              className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-4 font-mono text-xs"
            >
              <div className="flex items-center gap-2 min-w-0">
                <Lock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-bold text-slate-200">{sec.key}:</span>
                <span className="text-orange-400 truncate">{sec.reference}</span>
                <span className="text-[10px] text-slate-500 font-sans">(Encrypted via Vault)</span>
              </div>
              <button
                type="button"
                onClick={() => handleRemoveSecretRef(idx)}
                className="p-1 text-slate-500 hover:text-rose-400"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Environment Variables */}
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-2 flex items-center gap-1.5">
          <Code className="w-3.5 h-3.5 text-orange-400" />
          <span>Environment Variables ({formData.envVars.length})</span>
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 mb-3">
          <input
            type="text"
            placeholder="ENV_VARIABLE_NAME"
            value={newEnvKey}
            onChange={(e) => setNewEnvKey(e.target.value)}
            className="sm:col-span-2 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-xs font-mono text-white"
          />
          <input
            type="text"
            placeholder="Value (e.g. production / 8080)"
            value={newEnvVal}
            onChange={(e) => setNewEnvVal(e.target.value)}
            className="sm:col-span-2 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-xs font-mono text-white"
          />
          <button
            type="button"
            onClick={handleAddEnvVar}
            disabled={!newEnvKey}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-semibold flex items-center justify-center gap-1 border border-slate-700 disabled:opacity-50"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Variable</span>
          </button>
        </div>

        <div className="space-y-1.5">
          {formData.envVars.map((ev, idx) => (
            <div
              key={idx}
              className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-4 font-mono text-xs"
            >
              <div className="flex items-center gap-2 min-w-0">
                <span className="font-bold text-slate-200">{ev.key}=</span>
                <span className="text-slate-400 truncate">{ev.value}</span>
              </div>
              <button
                type="button"
                onClick={() => handleRemoveEnvVar(idx)}
                className="p-1 text-slate-500 hover:text-rose-400"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Service Ports & Feature Flags (2 Column Grid) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 pt-2 border-t border-slate-800">
        {/* Service Ports */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-2 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-orange-400" />
            <span>Service Ports (Ingress Listeners)</span>
          </label>
          <div className="flex items-center gap-2 mb-2">
            <input
              type="number"
              placeholder="Port # (e.g. 8080)"
              value={newPort}
              onChange={(e) => setNewPort(e.target.value)}
              className="w-36 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-xs font-mono text-white"
            />
            <button
              type="button"
              onClick={handleAddPort}
              disabled={!newPort}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs border border-slate-700"
            >
              Add Port
            </button>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {formData.servicePorts.map((p) => (
              <span
                key={p}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-orange-400"
              >
                <span>:{p}</span>
                <button
                  type="button"
                  onClick={() => handleRemovePort(p)}
                  className="text-slate-500 hover:text-rose-400"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Feature Flags */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-2 flex items-center gap-1.5">
            <ToggleRight className="w-3.5 h-3.5 text-orange-400" />
            <span>Application Feature Flags</span>
          </label>
          <div className="flex items-center gap-2 mb-2">
            <input
              type="text"
              placeholder="FLAG_KEY (e.g. ENABLE_OAUTH2)"
              value={newFlagKey}
              onChange={(e) => setNewFlagKey(e.target.value)}
              className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-xs font-mono text-white"
            />
            <button
              type="button"
              onClick={handleAddFlag}
              disabled={!newFlagKey}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs border border-slate-700"
            >
              Add Flag
            </button>
          </div>
          <div className="space-y-1.5">
            {formData.featureFlags.map((flag, idx) => (
              <div
                key={flag.key}
                className="p-2 rounded bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs font-mono"
              >
                <span className="text-slate-300">{flag.key}</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleToggleFlag(idx)}
                    className={`px-2 py-0.5 rounded text-[10px] border font-bold ${
                      flag.enabled
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-slate-800 text-slate-500 border-slate-700'
                    }`}
                  >
                    {flag.enabled ? 'ENABLED' : 'DISABLED'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRemoveFlag(idx)}
                    className="text-slate-500 hover:text-rose-400"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
