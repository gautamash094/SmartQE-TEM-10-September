import React from 'react';
import { Boxes, CheckCircle2, Layers } from 'lucide-react';
import { SoftwareComponent } from '../../../types/provisioning';

interface Props {
  softwareStack: SoftwareComponent[];
}

export const SoftwareTab: React.FC<Props> = ({ softwareStack }) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Installed Software & Middleware Stack
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Detailed list of runtime components, operating system packages, and databases deployed to the environment.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {softwareStack.map((item, idx) => (
          <div
            key={idx}
            className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-orange-400 shrink-0">
                <Boxes className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">{item.name}</span>
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-800 text-orange-400 border border-slate-700">
                    v{item.version}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Vendor: {item.vendor || 'Open Source'} • {item.category || 'Runtime'}
                </p>
              </div>
            </div>

            <span
              className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                item.required
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 font-bold'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {item.required ? 'REQUIRED' : 'OPTIONAL'}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
