import React from 'react';
import {
  Server,
  Cpu,
  HardDrive,
  Globe,
  Clock,
  User,
  Building2,
  Calendar,
  Layers,
  Activity,
  CheckCircle2,
} from 'lucide-react';
import { ProvisioningRequest } from '../../../types/provisioning';

interface Props {
  request: ProvisioningRequest;
}

export const OverviewTab: React.FC<Props> = ({ request }) => {
  const specs = request.resource_specs || {};
  const swStack = request.software_stack || [];
  const resources = request.resources || [];

  return (
    <div className="space-y-6">
      {/* 4 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-mono">Compute & Cores</span>
            <Cpu className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-lg font-bold text-white font-mono">{specs.cpu_cores || 4} vCPUs</p>
          <p className="text-xs text-slate-400 mt-0.5">{specs.compute_type || 'VM'} Architecture</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-mono">RAM Memory</span>
            <Server className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-lg font-bold text-white font-mono">{specs.ram_gb || 16} GB RAM</p>
          <p className="text-xs text-slate-400 mt-0.5">ECC Enterprise Memory</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-mono">Storage Volumes</span>
            <HardDrive className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-lg font-bold text-white font-mono">{specs.storage_gb || 100} GB SSD</p>
          <p className="text-xs text-slate-400 mt-0.5">{specs.os_disk_gb || 50}GB OS + {specs.dataDiskGb || specs.data_disk_gb || 50}GB Data</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-mono">Allocated IP</span>
            <Globe className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-lg font-bold text-white font-mono">
            {resources.find((r) => r.resource_type === 'IP')?.resource_id || '-'}
          </p>
          <p className="text-xs text-slate-400 mt-0.5">{specs.network?.vlan || specs.vlan || '-'}</p>
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hierarchy & Metadata */}
        <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-4">
          <h4 className="text-xs font-bold text-white uppercase font-mono tracking-wider border-b border-slate-800 pb-2">
            Enterprise Hierarchy & Ownership
          </h4>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-slate-500 block">Business Unit</span>
              <span className="text-slate-200 font-semibold">{request.business_unit}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Project</span>
              <span className="text-slate-200 font-semibold">{request.project_name}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Application</span>
              <span className="text-slate-200 font-semibold">{request.application_name}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Environment Owner</span>
              <span className="text-slate-200 font-semibold">{request.environment_owner || request.requested_by}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Provisioning Mode</span>
              <span className="text-slate-200 font-mono">{request.provisioning_mode}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Requested On</span>
              <span className="text-slate-200 font-mono">{new Date(request.created_at).toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Software Stack Summary */}
        <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-4">
          <h4 className="text-xs font-bold text-white uppercase font-mono tracking-wider border-b border-slate-800 pb-2">
            Installed Software Stack ({swStack.length} Components)
          </h4>
          <div className="space-y-2">
            {swStack.map((sw, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white">{sw.name}</span>
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-800 text-orange-400 border border-slate-700">
                    v{sw.version}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400">{sw.category || 'Package'}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
