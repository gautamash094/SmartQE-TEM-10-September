import React from 'react';
import { History, User, ShieldCheck, Clock } from 'lucide-react';
import { ProvisioningAuditItem } from '../../../types/provisioning';

interface Props {
  audits: ProvisioningAuditItem[];
}

export const AuditHistoryTab: React.FC<Props> = ({ audits }) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-4">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Immutable Lifecycle Audit Trail
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Chronological security audit log recording every transition, approval decision, retry, and administrative action.
        </p>
      </div>

      <div className="space-y-3">
        {audits.map((audit) => (
          <div
            key={audit.id}
            className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-orange-400 shrink-0 mt-0.5">
                <History className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-mono font-bold text-white uppercase">
                    {audit.action}
                  </span>
                  {audit.old_status && audit.new_status && (
                    <span className="text-[10px] font-mono text-slate-400">
                      ({audit.old_status} → <strong className="text-orange-400">{audit.new_status}</strong>)
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                  <User className="w-3.5 h-3.5 text-slate-500" />
                  <span>Performed by: <strong className="text-slate-200">{audit.performed_by}</strong></span>
                  <span>•</span>
                  <span>IP: <code className="font-mono text-slate-400">{audit.ip_address || '127.0.0.1'}</code></span>
                </p>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="text-xs font-mono text-slate-400">
                {new Date(audit.timestamp).toLocaleDateString()} {new Date(audit.timestamp).toLocaleTimeString()}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
