import React from 'react';
import {
  CheckCircle2,
  Clock,
  PlayCircle,
  XCircle,
  RotateCcw,
  CheckSquare,
  AlertTriangle,
  Layers,
} from 'lucide-react';
import { ProvisioningStepItem } from '../../../types/provisioning';
import { ProvisioningStatusBadge } from '../common/ProvisioningStatusBadge';

interface Props {
  steps: ProvisioningStepItem[];
  onRetryStep?: (stepId: string) => void;
  isActionLoading?: boolean;
}

export const ProvisioningPlanTab: React.FC<Props> = ({ steps, onRetryStep, isActionLoading }) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-4">
      <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
            Provisioning Step-by-Step Execution Plan
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time step telemetry, execution duration, and isolated step-level retry actions.
          </p>
        </div>
        <span className="text-xs font-mono text-slate-400">
          {steps.filter((s) => s.status === 'COMPLETED').length} / {steps.length} Steps Completed
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-950/60 text-[11px] font-mono uppercase tracking-wider text-slate-400">
              <th className="py-2.5 px-3">#</th>
              <th className="py-2.5 px-3">Step Name</th>
              <th className="py-2.5 px-3">Category</th>
              <th className="py-2.5 px-3">Status</th>
              <th className="py-2.5 px-3">Duration</th>
              <th className="py-2.5 px-3">Timeline</th>
              <th className="py-2.5 px-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-xs">
            {steps.map((step) => {
              const isCompleted = step.status === 'COMPLETED';
              const isInProgress = step.status === 'IN_PROGRESS';
              const isFailed = step.status === 'FAILED';

              return (
                <tr
                  key={step.id}
                  className={`hover:bg-slate-800/30 transition-colors ${
                    isFailed ? 'bg-rose-950/10' : isInProgress ? 'bg-orange-950/10' : ''
                  }`}
                >
                  <td className="py-3 px-3 font-mono font-bold text-orange-400">
                    {step.step_order}
                  </td>
                  <td className="py-3 px-3">
                    <div>
                      <span className="font-semibold text-white block">{step.step_name}</span>
                      <span className="text-[10px] font-mono text-slate-500">{step.step_key}</span>
                      {step.error_message && (
                        <p className="text-[11px] text-rose-400 mt-1 font-mono">{step.error_message}</p>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                      {step.category}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <ProvisioningStatusBadge status={step.status} size="sm" />
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-300">
                    {isCompleted
                      ? `${step.actual_duration_sec}s`
                      : isInProgress
                      ? 'Running...'
                      : `~${step.estimated_duration_sec}s`}
                  </td>
                  <td className="py-3 px-3 text-[11px] font-mono text-slate-400">
                    {step.started_at ? (
                      <div>
                        <span>Start: {new Date(step.started_at).toLocaleTimeString()}</span>
                        {step.completed_at && (
                          <span className="block text-slate-500">
                            Done: {new Date(step.completed_at).toLocaleTimeString()}
                          </span>
                        )}
                      </div>
                    ) : (
                      <span className="text-slate-600">Pending</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-right">
                    {isFailed && onRetryStep && (
                      <button
                        type="button"
                        disabled={isActionLoading}
                        onClick={() => onRetryStep(step.id)}
                        className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded text-[11px] font-medium flex items-center gap-1 ml-auto shadow-sm"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Retry</span>
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
