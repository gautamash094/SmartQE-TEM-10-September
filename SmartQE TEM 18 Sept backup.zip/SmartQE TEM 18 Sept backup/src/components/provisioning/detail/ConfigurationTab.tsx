import React from 'react';
import { Lock, Code, Sliders, ToggleRight, KeyRound } from 'lucide-react';

interface Props {
  configurationPayload: Record<string, any>;
}

export const ConfigurationTab: React.FC<Props> = ({ configurationPayload }) => {
  const envVars = configurationPayload.env_vars || [];
  const secrets = configurationPayload.secrets_references || [];
  const ports = configurationPayload.service_ports || [];
  const flags = configurationPayload.feature_flags || {};

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Environment Configuration & Masked Secrets
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Runtime properties, environment variables, listening ports, and secure secret vault references.
        </p>
      </div>

      {/* Secrets References */}
      <div>
        <h4 className="text-xs font-bold text-white font-mono uppercase mb-3 flex items-center gap-1.5">
          <KeyRound className="w-3.5 h-3.5 text-orange-400" />
          <span>Secret Vault URIs ({secrets.length})</span>
        </h4>
        {secrets.length === 0 ? (
          <p className="text-xs text-slate-500">No secret references attached.</p>
        ) : (
          <div className="space-y-2">
            {secrets.map((sec: any, idx: number) => (
              <div
                key={idx}
                className="p-3 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between font-mono text-xs"
              >
                <div className="flex items-center gap-2">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-bold text-slate-200">{sec.key}:</span>
                  <span className="text-orange-400">{sec.reference}</span>
                </div>
                <span className="text-[10px] text-slate-500 font-sans">Vault Protected</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Environment Variables */}
      <div className="pt-4 border-t border-slate-800">
        <h4 className="text-xs font-bold text-white font-mono uppercase mb-3 flex items-center gap-1.5">
          <Code className="w-3.5 h-3.5 text-orange-400" />
          <span>Injected Environment Variables ({envVars.length})</span>
        </h4>
        <div className="space-y-2">
          {envVars.map((ev: any, idx: number) => (
            <div
              key={idx}
              className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between font-mono text-xs"
            >
              <span className="font-bold text-slate-200">{ev.key}=</span>
              <span className="text-slate-400">{ev.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Service Ports */}
      <div className="pt-4 border-t border-slate-800">
        <h4 className="text-xs font-bold text-white font-mono uppercase mb-2 flex items-center gap-1.5">
          <Sliders className="w-3.5 h-3.5 text-orange-400" />
          <span>Open Ingress Ports</span>
        </h4>
        <div className="flex items-center gap-2 flex-wrap">
          {ports.map((p: number) => (
            <span
              key={p}
              className="px-3 py-1 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-orange-400 font-bold"
            >
              Port :{p}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
