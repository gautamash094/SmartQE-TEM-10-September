import React from 'react';
import {
  FileText,
  ShieldCheck,
  CheckCircle2,
  Cpu,
  Layers,
  Boxes,
  Sliders,
  Play,
  Activity,
  Award,
  Check,
  Clock,
  X,
} from 'lucide-react';
import { ProvisioningRequest, StepStatus } from '../../../types/provisioning';

interface Props {
  request: ProvisioningRequest;
}

interface LifecycleStage {
  key: string;
  name: string;
  icon: any;
  category: string;
}

const LIFECYCLE_STAGES: LifecycleStage[] = [
  { key: 'REQUEST', name: 'Request', icon: FileText, category: 'INIT' },
  { key: 'VALIDATION', name: 'Validation', icon: ShieldCheck, category: 'GATE' },
  { key: 'APPROVAL', name: 'Approval', icon: CheckCircle2, category: 'GOVERNANCE' },
  { key: 'RESOURCE_ALLOCATION', name: 'Resource Allocation', icon: Cpu, category: 'INFRA' },
  { key: 'INFRASTRUCTURE', name: 'Infrastructure', icon: Layers, category: 'COMPUTE' },
  { key: 'SOFTWARE', name: 'Software Stack', icon: Boxes, category: 'RUNTIME' },
  { key: 'CONFIGURATION', name: 'Configuration', icon: Sliders, category: 'CONFIG' },
  { key: 'DEPLOYMENT', name: 'Deployment', icon: Play, category: 'APP' },
  { key: 'HEALTH_CHECK', name: 'Health Check', icon: Activity, category: 'PROBES' },
  { key: 'READY', name: 'Ready', icon: Award, category: 'FINAL' },
];

export const LifecycleTimeline: React.FC<Props> = ({ request }) => {
  const getStageStatus = (stageKey: string): 'COMPLETED' | 'IN_PROGRESS' | 'PENDING' | 'FAILED' => {
    const s = request.status;

    if (s === 'FAILED') {
      // Find where it failed
      if (stageKey === 'HEALTH_CHECK') return 'FAILED';
      if (['READY'].includes(stageKey)) return 'PENDING';
      return 'COMPLETED';
    }

    if (s === 'READY' || s === 'DECOMMISSIONED') return 'COMPLETED';

    const stageOrder: Record<string, number> = {
      REQUEST: 1,
      VALIDATION: 2,
      APPROVAL: 3,
      RESOURCE_ALLOCATION: 4,
      INFRASTRUCTURE: 5,
      SOFTWARE: 6,
      CONFIGURATION: 7,
      DEPLOYMENT: 8,
      HEALTH_CHECK: 9,
      READY: 10,
    };

    let currentOrder = 1;
    if (s === 'VALIDATING') currentOrder = 2;
    else if (s === 'VALIDATED') currentOrder = 2;
    else if (s === 'PENDING_APPROVAL') currentOrder = 3;
    else if (s === 'APPROVED' || s === 'QUEUED') currentOrder = 3;
    else if (s === 'PROVISIONING') {
      currentOrder = request.current_step_index <= 3 ? 4 : 5;
    } else if (s === 'CONFIGURING') {
      currentOrder = 7;
    } else if (s === 'HEALTH_CHECK') {
      currentOrder = 9;
    }

    const order = stageOrder[stageKey] || 1;
    if (order < currentOrder) return 'COMPLETED';
    if (order === currentOrder) return 'IN_PROGRESS';
    return 'PENDING';
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm overflow-x-auto">
      <div className="flex items-center justify-between min-w-[850px] relative">
        {/* Continuous background connecting line */}
        <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-slate-800 -translate-y-1/2 z-0" />

        {LIFECYCLE_STAGES.map((stage, idx) => {
          const Icon = stage.icon;
          const status = getStageStatus(stage.key);

          const isDone = status === 'COMPLETED';
          const isCurrent = status === 'IN_PROGRESS';
          const isFailed = status === 'FAILED';

          return (
            <div key={stage.key} className="flex flex-col items-center relative z-10 group">
              {/* Circle Icon Badge */}
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-300 ${
                  isDone
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                    : isCurrent
                    ? 'bg-orange-500 text-white border-2 border-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.5)] scale-110 animate-pulse'
                    : isFailed
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-[0_0_12px_rgba(244,63,94,0.3)]'
                    : 'bg-slate-950 border border-slate-800 text-slate-500'
                }`}
              >
                {isDone ? (
                  <Check className="w-4 h-4 stroke-[3]" />
                ) : isFailed ? (
                  <X className="w-4 h-4 stroke-[3]" />
                ) : isCurrent ? (
                  <Icon className="w-4 h-4" />
                ) : (
                  <Icon className="w-4 h-4 opacity-50" />
                )}
              </div>

              {/* Title */}
              <span
                className={`text-[11px] font-mono mt-2 font-bold tracking-tight text-center max-w-[80px] leading-tight ${
                  isCurrent
                    ? 'text-orange-400'
                    : isDone
                    ? 'text-slate-200'
                    : isFailed
                    ? 'text-rose-400'
                    : 'text-slate-500'
                }`}
              >
                {stage.name}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
