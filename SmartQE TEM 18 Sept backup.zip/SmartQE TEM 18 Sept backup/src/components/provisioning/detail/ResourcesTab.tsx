import React from 'react';
import { Server, Globe, HardDrive, Cpu, Layers, ShieldCheck } from 'lucide-react';
import { ProvisioningResourceItem } from '../../../types/provisioning';

interface Props {
  resources: ProvisioningResourceItem[];
}

export const ResourcesTab: React.FC<Props> = ({ resources }) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'COMPUTE':
        return Cpu;
      case 'IP':
        return Globe;
      case 'STORAGE':
        return HardDrive;
      default:
        return Server;
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Allocated Cloud & Infrastructure Resources
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Live inventory assets and cloud resources provisioned by the orchestrator engine.
        </p>
      </div>

      {resources.length === 0 ? (
        <div className="text-center py-12 bg-slate-950/40 rounded-xl border border-slate-800 text-slate-400 text-xs">
          Resources will be allocated as orchestration steps execute.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resources.map((res) => {
            const Icon = getIcon(res.resource_type);
            const isAllocated = res.status === 'ALLOCATED' || res.status === 'ATTACHED';

            return (
              <div
                key={res.id}
                className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3 hover:border-slate-700 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-slate-800 text-orange-400 border border-slate-700">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block truncate max-w-[160px]">
                        {res.resource_name}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500">{res.resource_type}</span>
                    </div>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                      isAllocated
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 font-bold'
                        : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}
                  >
                    {res.status}
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800/80 font-mono text-[11px] text-slate-300 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Resource ID:</span>
                    <span className="text-orange-400 font-bold">{res.resource_id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Provider:</span>
                    <span className="text-slate-300">{res.provider}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Allocated At:</span>
                    <span className="text-slate-400">
                      {new Date(res.allocated_at).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
