import React, { useState, useEffect, useRef } from 'react';
import {
  Terminal,
  Copy,
  Check,
  Search,
  RotateCcw,
  ArrowDownCircle,
  Filter,
} from 'lucide-react';
import { ProvisioningLogItem } from '../../../types/provisioning';

interface Props {
  logs: ProvisioningLogItem[];
  isLoading?: boolean;
  onRefresh?: () => void;
}

export const ExecutionLogsTab: React.FC<Props> = ({ logs, isLoading, onRefresh }) => {
  const [copied, setCopied] = useState(false);
  const [levelFilter, setLevelFilter] = useState('ALL');
  const [search, setSearch] = useState('');
  const [autoScroll, setAutoScroll] = useState(true);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoScroll && terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, autoScroll]);

  const handleCopyLogs = () => {
    const raw = logs
      .map(
        (l) =>
          `[${new Date(l.timestamp).toISOString()}] [${l.log_level}] [${l.source}] ${l.message}`
      )
      .join('\n');
    navigator.clipboard.writeText(raw);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredLogs = logs.filter((log) => {
    const matchesLevel = levelFilter === 'ALL' || log.log_level === levelFilter;
    const matchesSearch =
      !search ||
      log.message.toLowerCase().includes(search.toLowerCase()) ||
      log.source.toLowerCase().includes(search.toLowerCase());
    return matchesLevel && matchesSearch;
  });

  const getLogColor = (level: string) => {
    switch (level) {
      case 'SUCCESS':
        return 'text-emerald-400';
      case 'ERROR':
        return 'text-rose-400 font-bold';
      case 'WARN':
        return 'text-amber-400';
      case 'DEBUG':
        return 'text-slate-500';
      default:
        return 'text-slate-300';
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm flex flex-col h-[550px]">
      {/* Terminal Toolbar */}
      <div className="bg-slate-950/90 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 mr-2">
            <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
          </div>
          <Terminal className="w-4 h-4 text-orange-400" />
          <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
            Live Execution Stdout Console
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-400 border border-slate-700">
            {logs.length} Lines
          </span>
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Filter logs..."
              className="pl-8 pr-3 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 w-36 sm:w-44"
            />
          </div>

          {/* Level Filter */}
          <select
            value={levelFilter}
            onChange={(e) => setLevelFilter(e.target.value)}
            className="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-slate-300 focus:outline-none focus:border-orange-500 cursor-pointer"
          >
            <option value="ALL">All Levels</option>
            <option value="INFO">INFO</option>
            <option value="SUCCESS">SUCCESS</option>
            <option value="WARN">WARN</option>
            <option value="ERROR">ERROR</option>
          </select>

          {/* Auto Scroll Toggle */}
          <button
            type="button"
            onClick={() => setAutoScroll(!autoScroll)}
            className={`px-2.5 py-1 rounded text-xs font-mono border flex items-center gap-1 transition-colors ${
              autoScroll
                ? 'bg-orange-500/10 text-orange-400 border-orange-500/30'
                : 'bg-slate-900 text-slate-400 border-slate-700'
            }`}
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>Auto-Scroll</span>
          </button>

          {/* Copy Logs */}
          <button
            type="button"
            onClick={handleCopyLogs}
            className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-700 transition-colors"
            title="Copy Output"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          {/* Refresh */}
          {onRefresh && (
            <button
              type="button"
              onClick={onRefresh}
              className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-700 transition-colors"
              title="Refresh Logs"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-orange-400' : ''}`} />
            </button>
          )}
        </div>
      </div>

      {/* Terminal View Body */}
      <div className="flex-1 overflow-y-auto p-4 bg-[#05080e] font-mono text-xs leading-relaxed space-y-1 select-text">
        {filteredLogs.length === 0 ? (
          <div className="text-center py-12 text-slate-600 font-sans">
            No stdout logs recorded yet. Execution events will appear in real-time as steps progress.
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div key={log.id} className="flex items-start gap-3 hover:bg-slate-900/40 px-1 py-0.5 rounded">
              <span className="text-slate-600 shrink-0 select-none">
                {new Date(log.timestamp).toLocaleTimeString()}
              </span>
              <span
                className={`px-1.5 py-0.2 rounded text-[10px] font-bold shrink-0 uppercase border ${
                  log.log_level === 'SUCCESS'
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    : log.log_level === 'ERROR'
                    ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                    : log.log_level === 'WARN'
                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                    : 'bg-slate-800 text-cyan-400 border-slate-700'
                }`}
              >
                {log.log_level}
              </span>
              <span className="text-slate-500 shrink-0">[{log.source}]</span>
              <span className={`flex-1 break-all ${getLogColor(log.log_level)}`}>
                {log.message}
              </span>
            </div>
          ))
        )}
        <div ref={terminalEndRef} />
      </div>
    </div>
  );
};
