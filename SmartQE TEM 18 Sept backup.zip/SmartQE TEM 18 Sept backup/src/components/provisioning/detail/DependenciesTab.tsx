import React from 'react';
import { Database, Globe, Radio, Server, Layers, CheckCircle2 } from 'lucide-react';
import { DependencyItem } from '../../../types/provisioning';

interface Props {
  dependencies: DependencyItem[];
}

export const DependenciesTab: React.FC<Props> = ({ dependencies }) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'DATABASE':
        return Database;
      case 'EXTERNAL_API':
        return Globe;
      case 'MESSAGE_QUEUE':
        return Radio;
      case 'MIDDLEWARE':
        return Layers;
      default:
        return Server;
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
          Upstream & Downstream System Dependencies
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Connected external endpoints, shared databases, and service communication status.
        </p>
      </div>

      {dependencies.length === 0 ? (
        <div className="text-center py-12 bg-slate-950/40 rounded-xl border border-slate-800 text-slate-400 text-xs">
          No external dependencies mapped for this environment.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {dependencies.map((dep, idx) => {
            const Icon = getIcon(dep.type);
            return (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-slate-800 text-orange-400 border border-slate-700">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">{dep.name}</span>
                      <span className="text-[10px] font-mono text-slate-500">{dep.type}</span>
                    </div>
                  </div>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[9px] font-mono border ${
                      dep.required
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}
                  >
                    {dep.required ? 'REQUIRED' : 'OPTIONAL'}
                  </span>
                </div>

                {dep.endpoint && (
                  <p className="text-xs font-mono text-slate-400 truncate bg-slate-900 px-2 py-1 rounded border border-slate-800">
                    {dep.endpoint}
                  </p>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] font-mono text-emerald-400">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{dep.healthStatus || 'HEALTHY'}</span>
                  </span>
                  <span className="text-slate-500">Status: {dep.status || 'RESOLVED'}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
