import React from 'react';
import {
  Activity,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Globe,
  Database,
  Radio,
  Clock,
  ShieldCheck,
} from 'lucide-react';

interface Props {
  healthStatus: string;
  probes: any[];
}

export const HealthChecksTab: React.FC<Props> = ({ healthStatus, probes }) => {
  const isHealthy = healthStatus === 'HEALTHY';
  const isFailed = healthStatus === 'FAILED';

  const activeProbes = probes && probes.length > 0 ? probes : [];

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">
            Post-Provisioning Automated Health Checks
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated verification suite probing ICMP connectivity, listening ports, database handshakes, and HTTP actuator endpoints.
          </p>
        </div>
        <span
          className={`px-3 py-1 rounded-full text-xs font-mono font-bold border ${
            isHealthy
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
              : isFailed
              ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
              : 'bg-slate-800 text-slate-400 border-slate-700'
          }`}
        >
          Overall Health: {healthStatus}
        </span>
      </div>

      {/* Probes List */}
      {activeProbes.length === 0 ? (
        <div className="text-center py-12 bg-slate-950/40 rounded-xl border border-slate-800 text-slate-400 text-xs">
          Health probes will automatically execute once provisioning completes.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activeProbes.map((probe, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2 hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-white">{probe.check}</span>
                <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  <CheckCircle2 className="w-3.5 h-3.5" /> PASSED
                </span>
              </div>
              <p className="text-xs text-slate-300">{probe.message}</p>
              <div className="flex items-center gap-4 text-[11px] font-mono text-slate-500 pt-2 border-t border-slate-800/60">
                {probe.latency_ms && <span>Latency: {probe.latency_ms}ms</span>}
                {probe.response_time_ms && <span>Response Time: {probe.response_time_ms}ms</span>}
                {probe.query_latency_ms && <span>Query: {probe.query_latency_ms}ms</span>}
                {probe.http_status && <span>HTTP Status: {probe.http_status}</span>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
