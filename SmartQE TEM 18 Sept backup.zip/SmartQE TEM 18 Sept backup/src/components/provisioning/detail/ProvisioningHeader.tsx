import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Archive,
  ArrowLeft,
  Calendar,
  User,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';
import { ProvisioningRequest } from '../../../types/provisioning';
import { ProvisioningStatusBadge } from '../common/ProvisioningStatusBadge';

interface Props {
  request: ProvisioningRequest;
  onApprove?: () => void;
  onReject?: () => void;
  onProvision?: () => void;
  onRetry?: (stepId?: string) => void;
  onRollback?: () => void;
  onDecommission?: () => void;
  isActionLoading?: boolean;
}

export const ProvisioningHeader: React.FC<Props> = ({
  request,
  onApprove,
  onReject,
  onProvision,
  onRetry,
  onRollback,
  onDecommission,
  isActionLoading,
}) => {
  const navigate = useNavigate();

  const isPendingApproval = request.status === 'PENDING_APPROVAL';
  const isApproved = request.status === 'APPROVED' || request.status === 'VALIDATED';
  const isRunning = ['QUEUED', 'PROVISIONING', 'CONFIGURING', 'HEALTH_CHECK'].includes(request.status);
  const isReady = request.status === 'READY' || request.status === 'PARTIALLY_READY';
  const isFailed = request.status === 'FAILED';
  const isDecommissioned = request.status === 'DECOMMISSIONED';

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
      {/* Top Breadcrumb & Action Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Left: Back button & Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/provisioning/requests')}
            className="p-2 rounded-lg bg-slate-950/60 border border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Back to Requests"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-mono font-bold text-orange-400">
                {request.request_number}
              </span>
              <span className="text-slate-600">•</span>
              <h1 className="text-lg font-bold text-white tracking-wide">
                {request.environment_name}
              </h1>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                {request.environment_type}
              </span>
              <ProvisioningStatusBadge status={request.status} size="md" />
            </div>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
              <span>Project: <strong className="text-slate-200">{request.project_name}</strong></span>
              <span>•</span>
              <span>App: <strong className="text-slate-200">{request.application_name}</strong></span>
              <span>•</span>
              <span>Owner: <strong className="text-slate-200">{request.environment_owner || request.requested_by}</strong></span>
            </p>
          </div>
        </div>

        {/* Right: Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Approve / Reject */}
          {isPendingApproval && (
            <>
              {onReject && (
                <button
                  onClick={onReject}
                  disabled={isActionLoading}
                  className="px-3.5 py-2 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  <XCircle className="w-4 h-4 text-rose-400" />
                  <span>Reject</span>
                </button>
              )}
              {onApprove && (
                <button
                  onClick={onApprove}
                  disabled={isActionLoading}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-emerald-600/20 flex items-center gap-1.5 transition-all disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Approve Request</span>
                </button>
              )}
            </>
          )}

          {/* Trigger Provisioning */}
          {isApproved && onProvision && (
            <button
              onClick={onProvision}
              disabled={isActionLoading}
              className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-orange-600/20 flex items-center gap-1.5 transition-all disabled:opacity-50"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Start Provisioning</span>
            </button>
          )}

          {/* Retry on Failure */}
          {isFailed && onRetry && (
            <button
              onClick={() => onRetry()}
              disabled={isActionLoading}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-amber-600/20 flex items-center gap-1.5 transition-all disabled:opacity-50"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry Execution</span>
            </button>
          )}

          {/* Rollback */}
          {(isFailed || isRunning) && onRollback && (
            <button
              onClick={onRollback}
              disabled={isActionLoading}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <RotateCcw className="w-3.5 h-3.5 text-pink-400" />
              <span>Rollback</span>
            </button>
          )}

          {/* Decommission */}
          {isReady && onDecommission && (
            <button
              onClick={onDecommission}
              disabled={isActionLoading}
              className="px-3.5 py-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <Archive className="w-4 h-4 text-rose-400" />
              <span>Decommission</span>
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar & Real-Time Status Banner */}
      <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Execution Phase:</span>
            <span className="text-white font-bold">{request.status}</span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400">Step {request.current_step_index} of {request.total_steps || 9}</span>
          </div>
          <span className="text-orange-400 font-bold text-sm">
            {Math.round(request.progress_percentage || 0)}%
          </span>
        </div>

        <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
          <div
            className={`h-full transition-all duration-500 ${
              isFailed
                ? 'bg-rose-500'
                : isReady
                ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]'
                : 'bg-gradient-to-r from-orange-500 via-amber-500 to-orange-400 animate-pulse shadow-[0_0_10px_rgba(249,115,22,0.5)]'
            }`}
            style={{ width: `${Math.min(100, Math.max(0, request.progress_percentage || 0))}%` }}
          />
        </div>
      </div>
    </div>
  );
};
