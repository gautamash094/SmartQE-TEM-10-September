import React from 'react';
import { InventoryMetrics } from '../../types/inventory';
import {
  Boxes,
  Server,
  Database,
  Cloud,
  Network,
  Cpu,
  Layers,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldAlert,
  Building2,
  Globe,
  HardDrive,
  BarChart3,
  TrendingUp,
  RefreshCw
} from 'lucide-react';

interface InventoryDashboardProps {
  metrics: InventoryMetrics;
  onFilterByStatus?: (status: string) => void;
  onFilterByProvider?: (provider: string) => void;
  onFilterByType?: (type: string) => void;
  onRefresh?: () => void;
}

export const InventoryDashboard: React.FC<InventoryDashboardProps> = ({
  metrics,
  onFilterByStatus,
  onFilterByProvider,
  onFilterByType,
  onRefresh
}) => {
  const cloudPercent = metrics.totalAssets > 0 
    ? Math.round((metrics.cloudAssetsCount / metrics.totalAssets) * 100) 
    : 0;
  const onPremPercent = metrics.totalAssets > 0 
    ? Math.round((metrics.onPremAssetsCount / metrics.totalAssets) * 100) 
    : 0;
  const activePercent = metrics.totalAssets > 0 
    ? Math.round((metrics.activeAssetsCount / metrics.totalAssets) * 100) 
    : 0;

  return (
    <div className="space-y-6 font-mono">
      {/* Top Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#090d14] p-4 rounded-xl border border-slate-200 dark:border-slate-800/80 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white shadow-[0_0_12px_rgba(249,115,22,0.3)]">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">Executive Inventory Command Dashboard</h2>
            <p className="text-[11px] text-slate-400 font-sans">
              Consolidated infrastructure, cloud, database, network, and application asset intelligence.
            </p>
          </div>
        </div>

        {onRefresh && (
          <button
            onClick={onRefresh}
            className="flex items-center gap-2 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all border border-slate-700"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Telemetry</span>
          </button>
        )}
      </div>

      {/* Top 6 Executive KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* Total Assets */}
        <div className="bg-[#0b1019] border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-lg hover:border-orange-500/50 transition-all group">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">TOTAL ASSETS</span>
            <div className="w-7 h-7 rounded bg-orange-950/60 border border-orange-800/60 flex items-center justify-center text-orange-400 group-hover:scale-110 transition-transform">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{metrics.totalAssets}</span>
            <span className="text-[10px] text-emerald-400 font-sans font-bold flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> 100% Tracked
            </span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Across all TEM environments</p>
        </div>

        {/* Environments Linked */}
        <div className="bg-[#0b1019] border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-lg hover:border-blue-500/50 transition-all group">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">ENVIRONMENTS</span>
            <div className="w-7 h-7 rounded bg-blue-950/60 border border-blue-800/60 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{metrics.totalEnvironments}</span>
            <span className="text-[10px] text-blue-400 font-sans">Active Profiles</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Dedicated target clusters</p>
        </div>

        {/* Compute Servers */}
        <div 
          onClick={() => onFilterByType && onFilterByType('SERVER')}
          className="bg-[#0b1019] border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-lg hover:border-emerald-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">SERVERS</span>
            <div className="w-7 h-7 rounded bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
              <Server className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{metrics.totalServers}</span>
            <span className="text-[10px] text-slate-400 font-sans">Compute/VMs</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">App, Web & Proxy nodes</p>
        </div>

        {/* Databases */}
        <div 
          onClick={() => onFilterByType && onFilterByType('DATABASE')}
          className="bg-[#0b1019] border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-lg hover:border-purple-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">DATABASES</span>
            <div className="w-7 h-7 rounded bg-purple-950/60 border border-purple-800/60 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
              <Database className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{metrics.totalDatabases}</span>
            <span className="text-[10px] text-purple-400 font-sans">RDBMS & NoSQL</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Managed & On-Prem DBs</p>
        </div>

        {/* Cloud vs On-Prem */}
        <div className="bg-[#0b1019] border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-lg hover:border-cyan-500/50 transition-all group">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">CLOUD VS ON-PREM</span>
            <div className="w-7 h-7 rounded bg-cyan-950/60 border border-cyan-800/60 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
              <Cloud className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{cloudPercent}%</span>
            <span className="text-[10px] text-slate-400 font-sans">{metrics.cloudAssetsCount}C / {metrics.onPremAssetsCount}OP</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden flex">
            <div className="bg-cyan-500 h-full" style={{ width: `${cloudPercent}%` }} />
            <div className="bg-amber-500 h-full" style={{ width: `${onPremPercent}%` }} />
          </div>
        </div>

        {/* EOL / Attention Alerts */}
        <div 
          onClick={() => onFilterByStatus && onFilterByStatus('MAINTENANCE')}
          className="bg-[#0b1019] border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-lg hover:border-rose-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">EOL & ATTENTION</span>
            <div className="w-7 h-7 rounded bg-rose-950/60 border border-rose-800/60 flex items-center justify-center text-rose-400 group-hover:scale-110 transition-transform">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-rose-400">{metrics.approachingEolCount + metrics.maintenanceAssetsCount}</span>
            <span className="text-[10px] text-amber-400 font-sans font-bold">Action Needed</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">{metrics.approachingEolCount} near EOL, {metrics.maintenanceAssetsCount} in maint</p>
        </div>
      </div>

      {/* Visual Distribution & Analytic Breakdowns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Assets by Business Unit */}
        <div className="bg-[#090d14] border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-orange-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Assets by Business Unit</h3>
            </div>
            <span className="text-[10px] text-slate-500 bg-slate-800 px-2 py-0.5 rounded font-mono">
              {Object.keys(metrics.assetsByBu).length} BUs
            </span>
          </div>

          <div className="space-y-3">
            {Object.entries(metrics.assetsByBu).map(([bu, count]) => {
              const pct = metrics.totalAssets > 0 ? Math.round((count / metrics.totalAssets) * 100) : 0;
              return (
                <div key={bu} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-sans truncate">{bu}</span>
                    <span className="text-slate-400 font-mono font-bold">{count} ({pct}%)</span>
                  </div>
                  <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-orange-600 to-amber-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
            {Object.keys(metrics.assetsByBu).length === 0 && (
              <p className="text-xs text-slate-500 text-center py-4">No business unit data available</p>
            )}
          </div>
        </div>

        {/* Chart 2: Cloud Provider & Infrastructure Split */}
        <div className="bg-[#090d14] border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Cloud Provider Distribution</h3>
            </div>
            <span className="text-[10px] text-slate-500 bg-slate-800 px-2 py-0.5 rounded font-mono">
              Hybrid Multi-Cloud
            </span>
          </div>

          <div className="space-y-3">
            {Object.entries(metrics.assetsByProvider).map(([provider, count]) => {
              const pct = metrics.totalAssets > 0 ? Math.round((count / metrics.totalAssets) * 100) : 0;
              const isAws = provider.toLowerCase().includes('aws');
              const isAzure = provider.toLowerCase().includes('azure');
              const isGcp = provider.toLowerCase().includes('gcp');
              const isOnPrem = provider.toLowerCase().includes('on-prem');

              const barColor = isAws 
                ? 'from-amber-500 to-orange-600' 
                : isAzure 
                ? 'from-blue-600 to-cyan-500' 
                : isGcp 
                ? 'from-emerald-500 to-teal-400' 
                : isOnPrem 
                ? 'from-purple-600 to-indigo-500' 
                : 'from-slate-600 to-slate-500';

              return (
                <div 
                  key={provider} 
                  onClick={() => onFilterByProvider && onFilterByProvider(provider)}
                  className="space-y-1 cursor-pointer group"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-sans group-hover:text-cyan-300 transition-colors">{provider}</span>
                    <span className="text-slate-400 font-mono font-bold">{count} ({pct}%)</span>
                  </div>
                  <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden">
                    <div
                      className={`bg-gradient-to-r ${barColor} h-full rounded-full transition-all duration-500`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 3: Infrastructure Type & Lifecycle Status */}
        <div className="bg-[#090d14] border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Asset Category Breakdown</h3>
            </div>
            <span className="text-[10px] text-slate-500 bg-slate-800 px-2 py-0.5 rounded font-mono">
              6 Categories
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#121a28] p-3 rounded-lg border border-slate-200 dark:border-slate-800/80">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Server className="w-3.5 h-3.5 text-emerald-400" />
                <span>Compute Servers</span>
              </div>
              <p className="text-lg font-bold text-white mt-1">{metrics.totalServers}</p>
            </div>

            <div className="bg-[#121a28] p-3 rounded-lg border border-slate-200 dark:border-slate-800/80">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Database className="w-3.5 h-3.5 text-purple-400" />
                <span>Databases</span>
              </div>
              <p className="text-lg font-bold text-white mt-1">{metrics.totalDatabases}</p>
            </div>

            <div className="bg-[#121a28] p-3 rounded-lg border border-slate-200 dark:border-slate-800/80">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Network className="w-3.5 h-3.5 text-cyan-400" />
                <span>Network / Gateway</span>
              </div>
              <p className="text-lg font-bold text-white mt-1">{metrics.totalNetworkComponents}</p>
            </div>

            <div className="bg-[#121a28] p-3 rounded-lg border border-slate-200 dark:border-slate-800/80">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Cpu className="w-3.5 h-3.5 text-orange-400" />
                <span>Software / Apps</span>
              </div>
              <p className="text-lg font-bold text-white mt-1">{metrics.totalSoftware}</p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-400">Status Health:</span>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-[10px] font-bold">
                {metrics.activeAssetsCount} Active ({activePercent}%)
              </span>
              <span className="px-2 py-0.5 rounded bg-amber-950/60 border border-amber-800 text-amber-300 text-[10px] font-bold">
                {metrics.maintenanceAssetsCount} Maint
              </span>
              <span className="px-2 py-0.5 rounded bg-rose-950/60 border border-rose-800 text-rose-300 text-[10px] font-bold">
                {metrics.retiredAssetsCount} Retired
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
