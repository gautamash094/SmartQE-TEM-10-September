import React, { useState, useMemo, useCallback } from 'react';
import { useTEM } from '../../../context/TEMContext';
import {
  buildInventoryGraph,
  InventoryVisualFilterState,
  InventoryGraphNode
} from './inventoryGraphBuilder';
import { InventoryVisualKPIBar } from './InventoryVisualKPIBar';
import { InventoryVisualFilterBar } from './InventoryVisualFilterBar';
import { InventoryVisualCanvas } from './InventoryVisualCanvas';
import { InventoryNodeDetailsDrawer } from './InventoryNodeDetailsDrawer';
import { InventoryAsset } from '../../../types/inventory';

const INITIAL_VISUAL_FILTERS: InventoryVisualFilterState = {
  search: '',
  mode: 'hierarchy',
  businessUnit: 'ALL',
  project: 'ALL',
  application: 'ALL',
  component: 'ALL',
  environment: 'ALL',
  tier: 'ALL',
  resourceType: 'ALL',
  infraType: 'ALL',
  status: 'ALL',
  health: 'ALL'
};

interface InventoryVisualViewProps {
  consolidatedAssets: InventoryAsset[];
}

export const InventoryVisualView: React.FC<InventoryVisualViewProps> = ({
  consolidatedAssets
}) => {
  const {
    environmentProfiles,
    businessUnits,
    projects,
    components,
    applications,
    servers,
    softwareList,
    incidents,
    bookings,
    showToast
  } = useTEM();

  const [filters, setFilters] = useState<InventoryVisualFilterState>(INITIAL_VISUAL_FILTERS);
  const [collapsedNodeIds, setCollapsedNodeIds] = useState<Set<string>>(new Set());
  const [selectedNode, setSelectedNode] = useState<InventoryGraphNode | null>(null);

  // Quick filter tracking from KPI card clicks
  const [quickFilterType, setQuickFilterType] = useState<string>('');
  const [quickFilterValue, setQuickFilterValue] = useState<string>('');

  // Build graph reactively from real data
  const graphData = useMemo(() => {
    return buildInventoryGraph(
      environmentProfiles || [],
      businessUnits || [],
      projects || [],
      components || [],
      applications || [],
      servers || [],
      softwareList || [],
      consolidatedAssets || [],
      incidents || [],
      bookings || [],
      filters,
      collapsedNodeIds
    );
  }, [
    environmentProfiles,
    businessUnits,
    projects,
    components,
    applications,
    servers,
    softwareList,
    consolidatedAssets,
    incidents,
    bookings,
    filters,
    collapsedNodeIds
  ]);

  // Handlers
  const handleFilterChange = (key: keyof InventoryVisualFilterState, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setQuickFilterType('');
    setQuickFilterValue('');
  };

  const handleResetFilters = () => {
    setFilters(INITIAL_VISUAL_FILTERS);
    setCollapsedNodeIds(new Set());
    setSelectedNode(null);
    setQuickFilterType('');
    setQuickFilterValue('');
    showToast('Filters reset to default view', 'info');
  };

  const handleQuickFilter = (filterType: string, value: string) => {
    setQuickFilterType(filterType);
    setQuickFilterValue(value);

    if (filterType === 'resourceType') {
      setFilters(prev => ({ ...prev, resourceType: value }));
    } else if (filterType === 'infraType') {
      setFilters(prev => ({ ...prev, infraType: value }));
    } else if (filterType === 'status') {
      setFilters(prev => ({ ...prev, status: value }));
    } else if (filterType === 'health') {
      setFilters(prev => ({ ...prev, health: value }));
    }
  };

  const handleToggleCollapse = (nodeId: string) => {
    setCollapsedNodeIds(prev => {
      const next = new Set(prev);
      if (next.has(nodeId)) next.delete(nodeId);
      else next.add(nodeId);
      return next;
    });
  };

  const handleFilterToSubtree = (node: InventoryGraphNode) => {
    if (node.businessUnit) setFilters(prev => ({ ...prev, businessUnit: node.businessUnit! }));
    if (node.projectName) setFilters(prev => ({ ...prev, project: node.projectName! }));
    if (node.environmentName) setFilters(prev => ({ ...prev, environment: node.environmentName! }));
    showToast(`Filtered graph to ${node.label} hierarchy branch`, 'success');
  };

  // Export handlers
  const handleExport = (format: 'png' | 'svg' | 'json') => {
    if (format === 'json') {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(graphData, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `inventory_graph_${Date.now()}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      showToast('Exported inventory graph schema as JSON', 'success');
    } else if (format === 'svg') {
      // Generate standalone SVG
      const maxX = Math.max(...graphData.nodes.map(n => n.x + n.width), 1200) + 100;
      const maxY = Math.max(...graphData.nodes.map(n => n.y + n.height), 800) + 100;

      let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="${maxX}" height="${maxY}" viewBox="0 0 ${maxX} ${maxY}" style="background-color: #070b13; font-family: monospace;">`;
      
      // Render edges
      graphData.edges.forEach(e => {
        const s = graphData.nodes.find(n => n.id === e.source);
        const t = graphData.nodes.find(n => n.id === e.target);
        if (s && t) {
          const sx = s.x + s.width;
          const sy = s.y + s.height / 2;
          const tx = t.x;
          const ty = t.y + t.height / 2;
          svgContent += `<path d="M ${sx} ${sy} C ${sx + 60} ${sy}, ${tx - 60} ${ty}, ${tx} ${ty}" fill="none" stroke="#334155" stroke-width="1.5" />`;
        }
      });

      // Render nodes
      graphData.nodes.forEach(n => {
        svgContent += `
          <g transform="translate(${n.x}, ${n.y})">
            <rect width="${n.width}" height="${n.height}" rx="10" fill="#0f172a" stroke="#334155" stroke-width="1.5" />
            <text x="12" y="24" fill="#f97316" font-size="10" font-weight="bold">${n.category}</text>
            <text x="12" y="44" fill="#ffffff" font-size="12" font-weight="bold">${n.label}</text>
            <text x="12" y="62" fill="#94a3b8" font-size="10">${n.subLabel || ''}</text>
          </g>
        `;
      });

      svgContent += `</svg>`;

      const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `inventory_graph_${Date.now()}.svg`;
      link.click();
      URL.revokeObjectURL(url);
      showToast('Exported inventory visual graph as SVG vector', 'success');
    } else {
      // Export as PNG fallback
      showToast('Graph schema generated. For raster export, use browser print or SVG export.', 'info');
    }
  };

  return (
    <div className="space-y-4 font-mono w-full min-w-0">
      {/* 1. Summary KPI Bar */}
      <InventoryVisualKPIBar
        kpis={graphData.kpis}
        onQuickFilter={handleQuickFilter}
        activeFilterType={quickFilterType}
        activeFilterValue={quickFilterValue}
      />

      {/* 2. Filter & Visual Paradigm Mode Bar */}
      <InventoryVisualFilterBar
        filters={filters}
        onChangeFilter={handleFilterChange}
        onResetFilters={handleResetFilters}
        businessUnits={businessUnits || []}
        projects={projects || []}
        components={components || []}
        applications={applications || []}
        environmentProfiles={environmentProfiles || []}
        onExport={handleExport}
      />

      {/* 3. Interactive Visual Canvas */}
      <InventoryVisualCanvas
        nodes={graphData.nodes}
        edges={graphData.edges}
        selectedNodeId={selectedNode?.id || null}
        onSelectNode={node => setSelectedNode(node)}
        collapsedNodeIds={collapsedNodeIds}
        onToggleCollapse={handleToggleCollapse}
        searchQuery={filters.search}
      />

      {/* 4. Slide-Out Details Drawer */}
      <InventoryNodeDetailsDrawer
        node={selectedNode}
        isOpen={Boolean(selectedNode)}
        onClose={() => setSelectedNode(null)}
        allNodes={graphData.nodes}
        onSelectNode={node => setSelectedNode(node)}
        onFilterToSubtree={handleFilterToSubtree}
      />
    </div>
  );
};
