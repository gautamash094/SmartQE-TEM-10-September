import React from 'react';
import {
  Globe,
  Server,
  Cpu,
  Layers,
  HardDrive,
  Cloud,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  AlertTriangle,
  Component as ComponentIcon
} from 'lucide-react';

interface InventoryVisualKPIBarProps {
  kpis: {
    totalEnvironments: number;
    totalServers: number;
    totalSoftware: number;
    totalApplications: number;
    totalComponents: number;
    onPremCount: number;
    cloudCount: number;
    activeCount: number;
    inactiveCount: number;
    healthyCount: number;
    attentionCount: number;
  };
  onQuickFilter?: (filterType: string, value: string) => void;
  activeFilterType?: string;
  activeFilterValue?: string;
}

export const InventoryVisualKPIBar: React.FC<InventoryVisualKPIBarProps> = ({
  kpis,
  onQuickFilter,
  activeFilterType,
  activeFilterValue
}) => {
  const cards = [
    {
      id: 'env',
      label: 'Environments',
      value: kpis.totalEnvironments,
      icon: Globe,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10 border-cyan-500/30 hover:border-cyan-400/60',
      filterType: 'resourceType',
      filterValue: 'ENVIRONMENT'
    },
    {
      id: 'servers',
      label: 'Servers',
      value: kpis.totalServers,
      icon: Server,
      color: 'text-blue-400',
      bg: 'bg-blue-500/10 border-blue-500/30 hover:border-blue-400/60',
      filterType: 'resourceType',
      filterValue: 'SERVER'
    },
    {
      id: 'software',
      label: 'Software Runtimes',
      value: kpis.totalSoftware,
      icon: Cpu,
      color: 'text-orange-400',
      bg: 'bg-orange-500/10 border-orange-500/30 hover:border-orange-400/60',
      filterType: 'resourceType',
      filterValue: 'SOFTWARE'
    },
    {
      id: 'apps',
      label: 'Applications',
      value: kpis.totalApplications,
      icon: Layers,
      color: 'text-purple-400',
      bg: 'bg-purple-500/10 border-purple-500/30 hover:border-purple-400/60',
      filterType: 'resourceType',
      filterValue: 'APPLICATION'
    },
    {
      id: 'components',
      label: 'Components',
      value: kpis.totalComponents,
      icon: ComponentIcon,
      color: 'text-indigo-400',
      bg: 'bg-indigo-500/10 border-indigo-500/30 hover:border-indigo-400/60',
      filterType: 'resourceType',
      filterValue: 'COMPONENT'
    },
    {
      id: 'onprem',
      label: 'On-Premises',
      value: kpis.onPremCount,
      icon: HardDrive,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10 border-emerald-500/30 hover:border-emerald-400/60',
      filterType: 'infraType',
      filterValue: 'ON_PREMISES'
    },
    {
      id: 'cloud',
      label: 'Cloud Infrastructure',
      value: kpis.cloudCount,
      icon: Cloud,
      color: 'text-sky-400',
      bg: 'bg-sky-500/10 border-sky-500/30 hover:border-sky-400/60',
      filterType: 'infraType',
      filterValue: 'CLOUD'
    },
    {
      id: 'active',
      label: 'Active Resources',
      value: kpis.activeCount,
      icon: CheckCircle2,
      color: 'text-teal-400',
      bg: 'bg-teal-500/10 border-teal-500/30 hover:border-teal-400/60',
      filterType: 'status',
      filterValue: 'ACTIVE'
    },
    {
      id: 'healthy',
      label: 'Healthy Status',
      value: kpis.healthyCount,
      icon: ShieldCheck,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10 border-emerald-500/30 hover:border-emerald-400/60',
      filterType: 'health',
      filterValue: 'HEALTHY'
    },
    {
      id: 'attention',
      label: 'Needs Attention',
      value: kpis.attentionCount,
      icon: AlertTriangle,
      color: 'text-rose-400',
      bg: 'bg-rose-500/10 border-rose-500/30 hover:border-rose-400/60',
      filterType: 'health',
      filterValue: 'WARNING'
    }
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-10 gap-2.5 font-mono">
      {cards.map(c => {
        const Icon = c.icon;
        const isSelected =
          activeFilterType === c.filterType && activeFilterValue === c.filterValue;

        return (
          <button
            key={c.id}
            type="button"
            onClick={() => {
              if (onQuickFilter) {
                if (isSelected) onQuickFilter(c.filterType, 'ALL');
                else onQuickFilter(c.filterType, c.filterValue);
              }
            }}
            className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden group ${
              c.bg
            } ${
              isSelected
                ? 'ring-2 ring-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.4)] scale-[1.02]'
                : 'shadow-md hover:scale-[1.01]'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <Icon className={`w-4 h-4 ${c.color} shrink-0`} />
              <span className="text-[10px] font-bold text-slate-400 group-hover:text-white uppercase tracking-wider">
                KPI
              </span>
            </div>
            <div className="text-lg font-black text-white leading-none tracking-tight">
              {c.value}
            </div>
            <div className="text-[11px] text-slate-400 font-sans truncate mt-1">
              {c.label}
            </div>
          </button>
        );
      })}
    </div>
  );
};
