import { Incident, Booking } from '../../../types';
import { EnvironmentProfile, ServerDetail, SoftwareDetail } from '../../../types/environmentDetails';
import {
  BusinessUnit,
  Project,
  ApplicationEntity,
  ComponentEntity
} from '../../../services/portfolioService';
import { InventoryAsset, AssetType, InfrastructureType, CloudProvider, AssetStatus } from '../../../types/inventory';

export type InventoryVisualMode = 'hierarchy' | 'environment' | 'infra' | 'component';

export type NodeCategory =
  | 'BU'
  | 'PROJECT'
  | 'COMPONENT'
  | 'APPLICATION'
  | 'ENVIRONMENT'
  | 'SERVER'
  | 'DATABASE'
  | 'SOFTWARE'
  | 'CLOUD_RESOURCE'
  | 'NETWORK';

export type NodeHealth = 'HEALTHY' | 'WARNING' | 'CRITICAL';

export interface InventoryGraphNode {
  id: string;
  key: string;
  label: string;
  subLabel?: string;
  category: NodeCategory;
  assetType?: AssetType;
  infrastructureType: InfrastructureType;
  cloudProvider?: CloudProvider;
  status: AssetStatus | 'ACTIVE' | 'INACTIVE' | 'MAINTENANCE' | 'DEGRADED';
  health: NodeHealth;
  tier?: string;
  environmentName?: string;
  applicationName?: string;
  componentName?: string;
  projectName?: string;
  businessUnit?: string;
  endpointUrl?: string;
  ipAddress?: string;
  hostname?: string;
  specs?: {
    cpu?: number;
    ram?: number;
    storage?: number;
    os?: string;
    version?: string;
    runtimeStack?: string;
  };
  metrics?: {
    serversCount?: number;
    softwareCount?: number;
    appsCount?: number;
    componentsCount?: number;
  };
  owner?: string;
  costCenter?: string;
  tags?: Record<string, string>;
  rawEntity?: any;
  // Position & Layout
  x: number;
  y: number;
  width: number;
  height: number;
  depth: number;
  collapsed?: boolean;
  hasChildren?: boolean;
  childIds?: string[];
  parentIds?: string[];
}

export interface InventoryGraphEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  relationship: 'CONTAINS' | 'HOSTS' | 'RUNS_ON' | 'DEPENDS_ON' | 'CONNECTS_TO' | 'BELONGS_TO';
  animated?: boolean;
  style?: 'solid' | 'dashed';
}

export interface InventoryVisualFilterState {
  search: string;
  mode: InventoryVisualMode;
  businessUnit: string;
  project: string;
  application: string;
  component: string;
  environment: string;
  tier: string;
  resourceType: string;
  infraType: string;
  status: string;
  health: string;
}

export interface InventoryGraphData {
  nodes: InventoryGraphNode[];
  edges: InventoryGraphEdge[];
  kpis: {
    totalEnvironments: number;
    totalServers: number;
    totalSoftware: number;
    totalApplications: number;
    totalComponents: number;
    onPremCount: number;
    cloudCount: number;
    activeCount: number;
    inactiveCount: number;
    healthyCount: number;
    attentionCount: number;
  };
}

const NODE_WIDTH = 220;
const NODE_HEIGHT = 82;
const LEVEL_GAP_X = 290;
const NODE_GAP_Y = 100;

export const buildInventoryGraph = (
  environmentProfiles: EnvironmentProfile[] = [],
  businessUnits: BusinessUnit[] = [],
  projects: Project[] = [],
  components: ComponentEntity[] = [],
  applications: ApplicationEntity[] = [],
  servers: ServerDetail[] = [],
  softwareList: SoftwareDetail[] = [],
  consolidatedAssets: InventoryAsset[] = [],
  incidents: Incident[] = [],
  bookings: Booking[] = [],
  filters: InventoryVisualFilterState,
  collapsedNodeIds: Set<string> = new Set()
): InventoryGraphData => {
  const nodeMap = new Map<string, InventoryGraphNode>();
  const edges: InventoryGraphEdge[] = [];

  const activeIncidents = incidents.filter(i => i.status === 'OPEN' || i.status === 'INVESTIGATING');
  const incidentEnvIds = new Set(activeIncidents.map(i => i.environmentId).filter(Boolean));

  const calculateHealth = (status?: string, envId?: string, isDown?: boolean): NodeHealth => {
    const st = (status || '').toUpperCase();
    if (isDown || st === 'OFFLINE' || st === 'DOWN' || st === 'DEGRADED' || st === 'CRITICAL' || (envId && incidentEnvIds.has(envId))) {
      return 'CRITICAL';
    }
    if (st === 'MAINTENANCE' || st === 'WARNING' || st === 'PARTIAL' || st === 'UPGRADING') {
      return 'WARNING';
    }
    return 'HEALTHY';
  };

  // Environment to BU lookup map from Bookings & Portfolio
  const envToBuMap = new Map<string, string>();
  bookings.forEach(b => {
    if (b.environmentName && b.businessUnit) envToBuMap.set(b.environmentName.toLowerCase(), b.businessUnit);
    if (b.environmentId && b.businessUnit) envToBuMap.set(b.environmentId.toLowerCase(), b.businessUnit);
  });
  applications.forEach(a => {
    if (a.businessUnit) envToBuMap.set(a.name.toLowerCase(), a.businessUnit);
  });

  // Track counts
  const totalEnvironments = environmentProfiles.length;
  const totalServers = servers.length;
  const totalSoftware = softwareList.length;
  const totalApplications = applications.length;
  const totalComponents = components.length;
  let onPremCount = 0;
  let cloudCount = 0;
  let activeCount = 0;
  let inactiveCount = 0;
  let healthyCount = 0;
  let attentionCount = 0;

  // ═════════════════════════════════════════════════════════════════════════════
  // PARADIGM 1: TRACEABILITY HIERARCHY (BU -> Project -> Component -> App -> Env -> Server -> Software)
  // ═════════════════════════════════════════════════════════════════════════════
  if (filters.mode === 'hierarchy') {
    // 1. Business Units
    const effectiveBUs = businessUnits.length > 0 ? businessUnits : [
      { id: 'bu-default', name: 'Enterprise Operations', code: 'ENT-OPS', lead: 'Head of Infrastructure', status: 'ACTIVE' }
    ];

    effectiveBUs.forEach(bu => {
      const buId = `bu-${bu.id || bu.name}`;
      nodeMap.set(buId, {
        id: buId,
        key: buId,
        label: bu.name,
        subLabel: `BU Code: ${bu.code || 'BU'}`,
        category: 'BU',
        infrastructureType: 'HYBRID',
        status: (bu.status as any) || 'ACTIVE',
        health: calculateHealth(bu.status),
        businessUnit: bu.name,
        owner: bu.lead,
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 0,
        childIds: [],
        parentIds: []
      });
    });

    // 2. Projects
    const defaultBUId = `bu-${effectiveBUs[0].id || effectiveBUs[0].name}`;
    projects.forEach(proj => {
      const projId = `proj-${proj.id || proj.name}`;
      const parentBU = businessUnits.find(b => b.name.toLowerCase() === proj.businessUnit?.toLowerCase());
      const parentBUId = parentBU ? `bu-${parentBU.id || parentBU.name}` : defaultBUId;

      nodeMap.set(projId, {
        id: projId,
        key: projId,
        label: proj.name,
        subLabel: `Project Code: ${proj.code || 'PROJ'}`,
        category: 'PROJECT',
        infrastructureType: 'HYBRID',
        status: (proj.status as any) || 'ACTIVE',
        health: calculateHealth(proj.status),
        businessUnit: proj.businessUnit || effectiveBUs[0].name,
        projectName: proj.name,
        owner: proj.lead,
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 1,
        childIds: [],
        parentIds: [parentBUId]
      });

      edges.push({
        id: `edge-${parentBUId}-${projId}`,
        source: parentBUId,
        target: projId,
        relationship: 'CONTAINS'
      });

      const pNode = nodeMap.get(parentBUId);
      if (pNode && !pNode.childIds?.includes(projId)) {
        pNode.childIds = [...(pNode.childIds || []), projId];
        pNode.hasChildren = true;
      }
    });

    // 3. Components
    components.forEach(comp => {
      const compId = `comp-${comp.id || comp.name}`;
      const parentProj = projects.find(p => p.name.toLowerCase() === comp.projectName?.toLowerCase());
      const parentProjId = parentProj ? `proj-${parentProj.id || parentProj.name}` : null;
      const parentBU = businessUnits.find(b => b.name.toLowerCase() === comp.businessUnit?.toLowerCase());
      const fallbackParentId = parentProjId || (parentBU ? `bu-${parentBU.id || parentBU.name}` : defaultBUId);

      nodeMap.set(compId, {
        id: compId,
        key: compId,
        label: comp.name,
        subLabel: comp.endpointUrl ? `API: ${comp.endpointUrl}` : `Code: ${comp.code}`,
        category: 'COMPONENT',
        infrastructureType: 'HYBRID',
        status: (comp.status as any) || 'ACTIVE',
        health: calculateHealth(comp.status),
        businessUnit: comp.businessUnit,
        projectName: comp.projectName,
        componentName: comp.name,
        endpointUrl: comp.endpointUrl,
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 2,
        childIds: [],
        parentIds: [fallbackParentId]
      });

      edges.push({
        id: `edge-${fallbackParentId}-${compId}`,
        source: fallbackParentId,
        target: compId,
        relationship: 'CONTAINS'
      });

      const pNode = nodeMap.get(fallbackParentId);
      if (pNode && !pNode.childIds?.includes(compId)) {
        pNode.childIds = [...(pNode.childIds || []), compId];
        pNode.hasChildren = true;
      }
    });

    // 4. Applications
    applications.forEach(app => {
      const appId = `app-${app.id || app.name}`;
      const parentComp = components.find(c => c.name.toLowerCase() === app.componentName?.toLowerCase());
      const parentCompId = parentComp ? `comp-${parentComp.id || parentComp.name}` : null;
      const parentProj = projects.find(p => p.name.toLowerCase() === app.projectName?.toLowerCase());
      const parentProjId = parentProj ? `proj-${parentProj.id || parentProj.name}` : null;
      const parentBU = businessUnits.find(b => b.name.toLowerCase() === app.businessUnit?.toLowerCase());
      const fallbackParentId = parentCompId || parentProjId || (parentBU ? `bu-${parentBU.id || parentBU.name}` : defaultBUId);

      nodeMap.set(appId, {
        id: appId,
        key: appId,
        label: app.name,
        subLabel: `App Code: ${app.code}`,
        category: 'APPLICATION',
        infrastructureType: 'HYBRID',
        status: (app.status as any) || 'ACTIVE',
        health: calculateHealth(app.status),
        businessUnit: app.businessUnit,
        projectName: app.projectName,
        componentName: app.componentName,
        applicationName: app.name,
        owner: app.owner,
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 3,
        childIds: [],
        parentIds: [fallbackParentId]
      });

      edges.push({
        id: `edge-${fallbackParentId}-${appId}`,
        source: fallbackParentId,
        target: appId,
        relationship: 'DEPENDS_ON',
        animated: true
      });

      const pNode = nodeMap.get(fallbackParentId);
      if (pNode && !pNode.childIds?.includes(appId)) {
        pNode.childIds = [...(pNode.childIds || []), appId];
        pNode.hasChildren = true;
      }
    });

    // 5. Environments
    const allAppNodes = Array.from(nodeMap.values()).filter(n => n.category === 'APPLICATION');
    environmentProfiles.forEach((env, idx) => {
      const envId = `env-${env.id}`;
      const envServers = servers.filter(s => (env.serverIds && env.serverIds.includes(s.id)) || s.environmentName === env.name);
      const isCloud = envServers.some(s => s.infrastructureType === 'CLOUD' || !!s.cloudProvider);
      const envCloudProvider = isCloud ? (envServers.find(s => s.cloudProvider)?.cloudProvider as CloudProvider || 'AWS') : 'On-Premises';
      const envHealth = calculateHealth(env.status, env.id);

      // Find parent application or BU
      const matchedApp = allAppNodes.find(a => a.label.toLowerCase().includes(env.name.toLowerCase()) || env.name.toLowerCase().includes(a.label.toLowerCase()));
      const parentAppId = matchedApp ? matchedApp.id : (allAppNodes[idx % Math.max(allAppNodes.length, 1)]?.id || defaultBUId);

      nodeMap.set(envId, {
        id: envId,
        key: envId,
        label: env.name,
        subLabel: `${env.type} Tier | ${isCloud ? envCloudProvider : 'On-Prem'}`,
        category: 'ENVIRONMENT',
        infrastructureType: isCloud ? 'CLOUD' : 'ON_PREMISES',
        cloudProvider: envCloudProvider,
        status: (env.status as any) || 'ACTIVE',
        health: envHealth,
        tier: env.type,
        environmentName: env.name,
        businessUnit: envToBuMap.get(env.name.toLowerCase()) || effectiveBUs[0].name,
        owner: env.ownerTeam,
        metrics: {
          serversCount: envServers.length,
          softwareCount: env.softwareIds?.length || 0
        },
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 4,
        childIds: [],
        parentIds: [parentAppId]
      });

      edges.push({
        id: `edge-${parentAppId}-${envId}`,
        source: parentAppId,
        target: envId,
        relationship: 'RUNS_ON',
        animated: true
      });

      const pNode = nodeMap.get(parentAppId);
      if (pNode && !pNode.childIds?.includes(envId)) {
        pNode.childIds = [...(pNode.childIds || []), envId];
        pNode.hasChildren = true;
      }
    });

    // 6. Servers
    const allEnvNodes = Array.from(nodeMap.values()).filter(n => n.category === 'ENVIRONMENT');
    servers.forEach((srv, idx) => {
      const srvId = `srv-${srv.id}`;
      const srvIsCloud = srv.infrastructureType === 'CLOUD' || !!srv.cloudProvider;
      const srvHealth = calculateHealth(srv.status, undefined, srv.status === 'OFFLINE');

      const matchedEnv = allEnvNodes.find(e => e.label === srv.environmentName || srv.environmentName?.toLowerCase() === e.label.toLowerCase());
      const parentEnvId = matchedEnv ? matchedEnv.id : (allEnvNodes[idx % Math.max(allEnvNodes.length, 1)]?.id || defaultBUId);

      nodeMap.set(srvId, {
        id: srvId,
        key: srvId,
        label: srv.name,
        subLabel: srv.hostIp || srv.privateIp || '10.0.3.14',
        category: 'SERVER',
        assetType: 'SERVER',
        infrastructureType: srvIsCloud ? 'CLOUD' : 'ON_PREMISES',
        cloudProvider: srvIsCloud ? ((srv.cloudProvider || 'AWS') as CloudProvider) : 'On-Premises',
        status: srv.status === 'ONLINE' ? 'ACTIVE' : srv.status === 'OFFLINE' ? 'INACTIVE' : 'MAINTENANCE',
        health: srvHealth,
        ipAddress: srv.hostIp || srv.privateIp || srv.publicIp,
        hostname: srv.name,
        specs: {
          cpu: srv.cpuCores || 4,
          ram: srv.ramGb || 16,
          storage: srv.storageGb || 250,
          os: srv.operatingSystem || 'Ubuntu 22.04 LTS'
        },
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 5,
        childIds: [],
        parentIds: [parentEnvId]
      });

      edges.push({
        id: `edge-${parentEnvId}-${srvId}`,
        source: parentEnvId,
        target: srvId,
        relationship: 'HOSTS',
        animated: false
      });

      const pNode = nodeMap.get(parentEnvId);
      if (pNode && !pNode.childIds?.includes(srvId)) {
        pNode.childIds = [...(pNode.childIds || []), srvId];
        pNode.hasChildren = true;
      }
    });

    // 7. Software Runtimes
    const allServerNodes = Array.from(nodeMap.values()).filter(n => n.category === 'SERVER');
    softwareList.forEach((sw, idx) => {
      const swId = `sw-${sw.id}`;
      const swHealth = calculateHealth(sw.status);
      const parentSrvId = allServerNodes[idx % Math.max(allServerNodes.length, 1)]?.id || defaultBUId;

      nodeMap.set(swId, {
        id: swId,
        key: swId,
        label: sw.name,
        subLabel: sw.version ? `v${sw.version}` : (sw.runtimeStack || 'Runtime Service'),
        category: 'SOFTWARE',
        assetType: 'SOFTWARE',
        infrastructureType: 'ON_PREMISES',
        status: sw.status === 'ACTIVE' || sw.status === 'INSTALLED' ? 'ACTIVE' : 'INACTIVE',
        health: swHealth,
        specs: {
          version: sw.version,
          runtimeStack: sw.runtimeStack
        },
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 6,
        parentIds: [parentSrvId]
      });

      edges.push({
        id: `edge-${parentSrvId}-${swId}`,
        source: parentSrvId,
        target: swId,
        relationship: 'CONTAINS',
        animated: false
      });

      const pNode = nodeMap.get(parentSrvId);
      if (pNode && !pNode.childIds?.includes(swId)) {
        pNode.childIds = [...(pNode.childIds || []), swId];
        pNode.hasChildren = true;
      }
    });
  }

  // ═════════════════════════════════════════════════════════════════════════════
  // PARADIGM 2: ENVIRONMENT TIERS (DEV / QA / UAT / STAGING / PROD / PERF)
  // ═════════════════════════════════════════════════════════════════════════════
  else if (filters.mode === 'environment') {
    const tierGroups: Record<string, EnvironmentProfile[]> = {};
    const defaultTiers = ['Development', 'QA / Testing', 'UAT / Staging', 'Production', 'Performance / Stress', 'Sandbox'];
    defaultTiers.forEach(t => { tierGroups[t] = []; });

    environmentProfiles.forEach(env => {
      const t = env.type || 'Development';
      if (!tierGroups[t]) tierGroups[t] = [];
      tierGroups[t].push(env);
    });

    Object.entries(tierGroups).forEach(([tierName, envs]) => {
      if (envs.length === 0 && environmentProfiles.length > 0) return;
      const tierId = `tier-${tierName.replace(/[^a-zA-Z0-9]/g, '-')}`;

      nodeMap.set(tierId, {
        id: tierId,
        key: tierId,
        label: `${tierName} Tier`,
        subLabel: `${envs.length} Environments Registered`,
        category: 'ENVIRONMENT',
        infrastructureType: 'HYBRID',
        status: 'ACTIVE',
        health: 'HEALTHY',
        tier: tierName,
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 0,
        childIds: envs.map(e => `env-${e.id}`)
      });

      envs.forEach(env => {
        const envId = `env-${env.id}`;
        const envServers = servers.filter(s => (env.serverIds && env.serverIds.includes(s.id)) || s.environmentName === env.name);
        const isCloud = envServers.some(s => s.infrastructureType === 'CLOUD' || !!s.cloudProvider);
        const envCloudProvider = isCloud ? (envServers.find(s => s.cloudProvider)?.cloudProvider as CloudProvider || 'AWS') : 'On-Premises';
        const envSoftware = softwareList.filter(sw => env.softwareIds?.includes(sw.id));

        nodeMap.set(envId, {
          id: envId,
          key: envId,
          label: env.name,
          subLabel: `${env.type} | ${isCloud ? envCloudProvider : 'On-Prem'}`,
          category: 'ENVIRONMENT',
          infrastructureType: isCloud ? 'CLOUD' : 'ON_PREMISES',
          cloudProvider: envCloudProvider,
          status: (env.status as any) || 'ACTIVE',
          health: calculateHealth(env.status, env.id),
          tier: env.type,
          environmentName: env.name,
          owner: env.ownerTeam,
          metrics: {
            serversCount: envServers.length,
            softwareCount: envSoftware.length
          },
          x: 0,
          y: 0,
          width: NODE_WIDTH,
          height: NODE_HEIGHT,
          depth: 1,
          childIds: [...envServers.map(s => `srv-${s.id}`), ...envSoftware.map(sw => `sw-${sw.id}`)],
          parentIds: [tierId]
        });

        edges.push({
          id: `edge-${tierId}-${envId}`,
          source: tierId,
          target: envId,
          relationship: 'CONTAINS'
        });

        envServers.forEach(srv => {
          const srvId = `srv-${srv.id}`;
          const srvIsCloud = srv.infrastructureType === 'CLOUD' || !!srv.cloudProvider;
          nodeMap.set(srvId, {
            id: srvId,
            key: srvId,
            label: srv.name,
            subLabel: srv.hostIp || '10.0.2.15',
            category: 'SERVER',
            assetType: 'SERVER',
            infrastructureType: srvIsCloud ? 'CLOUD' : 'ON_PREMISES',
            cloudProvider: srvIsCloud ? ((srv.cloudProvider || 'AWS') as CloudProvider) : 'On-Premises',
            status: srv.status === 'ONLINE' ? 'ACTIVE' : 'INACTIVE',
            health: calculateHealth(srv.status, env.id, srv.status === 'OFFLINE'),
            tier: env.type,
            environmentName: env.name,
            ipAddress: srv.hostIp || srv.privateIp,
            hostname: srv.name,
            specs: {
              cpu: srv.cpuCores || 4,
              ram: srv.ramGb || 16,
              storage: srv.storageGb || 250,
              os: srv.operatingSystem || 'Ubuntu'
            },
            x: 0,
            y: 0,
            width: NODE_WIDTH,
            height: NODE_HEIGHT,
            depth: 2,
            parentIds: [envId]
          });

          edges.push({
            id: `edge-${envId}-${srvId}`,
            source: envId,
            target: srvId,
            relationship: 'HOSTS'
          });
        });

        envSoftware.forEach(sw => {
          const swId = `sw-${sw.id}`;
          nodeMap.set(swId, {
            id: swId,
            key: swId,
            label: sw.name,
            subLabel: sw.version ? `v${sw.version}` : (sw.runtimeStack || 'Runtime Package'),
            category: 'SOFTWARE',
            assetType: 'SOFTWARE',
            infrastructureType: 'ON_PREMISES',
            status: sw.status === 'ACTIVE' || sw.status === 'INSTALLED' ? 'ACTIVE' : 'INACTIVE',
            health: calculateHealth(sw.status),
            tier: env.type,
            environmentName: env.name,
            specs: {
              version: sw.version,
              runtimeStack: sw.runtimeStack
            },
            x: 0,
            y: 0,
            width: NODE_WIDTH,
            height: NODE_HEIGHT,
            depth: 2,
            parentIds: [envId]
          });

          edges.push({
            id: `edge-${envId}-${swId}`,
            source: envId,
            target: swId,
            relationship: 'RUNS_ON'
          });
        });
      });
    });
  }

  // ═════════════════════════════════════════════════════════════════════════════
  // PARADIGM 3: CLOUD VS ON-PREMISES INFRASTRUCTURE
  // ═════════════════════════════════════════════════════════════════════════════
  else if (filters.mode === 'infra') {
    const cloudRootId = 'infra-cloud-root';
    const onPremRootId = 'infra-onprem-root';

    nodeMap.set(cloudRootId, {
      id: cloudRootId,
      key: cloudRootId,
      label: 'Cloud Infrastructure',
      subLabel: 'AWS, Azure, GCP & Multi-Cloud',
      category: 'CLOUD_RESOURCE',
      infrastructureType: 'CLOUD',
      status: 'ACTIVE',
      health: 'HEALTHY',
      x: 0,
      y: 0,
      width: NODE_WIDTH,
      height: NODE_HEIGHT,
      depth: 0,
      childIds: []
    });

    nodeMap.set(onPremRootId, {
      id: onPremRootId,
      key: onPremRootId,
      label: 'On-Premises Infrastructure',
      subLabel: 'Enterprise Datacenters & Racks',
      category: 'SERVER',
      infrastructureType: 'ON_PREMISES',
      status: 'ACTIVE',
      health: 'HEALTHY',
      x: 0,
      y: 0,
      width: NODE_WIDTH,
      height: NODE_HEIGHT,
      depth: 0,
      childIds: []
    });

    // Cloud Providers
    const cloudProviders: CloudProvider[] = ['AWS', 'Azure', 'GCP', 'OCI', 'Alibaba Cloud', 'Other'];
    cloudProviders.forEach(prov => {
      const provId = `cloud-prov-${prov}`;
      const provServers = servers.filter(s => s.cloudProvider === prov || (s.infrastructureType === 'CLOUD' && prov === 'AWS'));

      nodeMap.set(provId, {
        id: provId,
        key: provId,
        label: `${prov} Cloud`,
        subLabel: `${provServers.length} Virtual Instances`,
        category: 'CLOUD_RESOURCE',
        infrastructureType: 'CLOUD',
        cloudProvider: prov,
        status: 'ACTIVE',
        health: 'HEALTHY',
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 1,
        childIds: provServers.map(s => `srv-${s.id}`),
        parentIds: [cloudRootId]
      });

      edges.push({
        id: `edge-${cloudRootId}-${provId}`,
        source: cloudRootId,
        target: provId,
        relationship: 'CONTAINS'
      });

      provServers.forEach(srv => {
        const srvId = `srv-${srv.id}`;
        nodeMap.set(srvId, {
          id: srvId,
          key: srvId,
          label: srv.name,
          subLabel: srv.hostIp || 'EC2 Instance',
          category: 'SERVER',
          assetType: 'SERVER',
          infrastructureType: 'CLOUD',
          cloudProvider: prov,
          status: srv.status === 'ONLINE' ? 'ACTIVE' : 'INACTIVE',
          health: calculateHealth(srv.status, undefined, srv.status === 'OFFLINE'),
          ipAddress: srv.hostIp || srv.privateIp,
          hostname: srv.name,
          specs: {
            cpu: srv.cpuCores || 4,
            ram: srv.ramGb || 16,
            storage: srv.storageGb || 250
          },
          x: 0,
          y: 0,
          width: NODE_WIDTH,
          height: NODE_HEIGHT,
          depth: 2,
          parentIds: [provId]
        });

        edges.push({
          id: `edge-${provId}-${srvId}`,
          source: provId,
          target: srvId,
          relationship: 'HOSTS'
        });
      });
    });

    // On-Premises Servers
    const onPremServers = servers.filter(s => s.infrastructureType === 'ON_PREMISES' || !s.cloudProvider);
    onPremServers.forEach(srv => {
      const srvId = `srv-${srv.id}`;
      nodeMap.set(srvId, {
        id: srvId,
        key: srvId,
        label: srv.name,
        subLabel: srv.hostIp || 'Datacenter Node',
        category: 'SERVER',
        assetType: 'SERVER',
        infrastructureType: 'ON_PREMISES',
        cloudProvider: 'On-Premises',
        status: srv.status === 'ONLINE' ? 'ACTIVE' : 'INACTIVE',
        health: calculateHealth(srv.status, undefined, srv.status === 'OFFLINE'),
        ipAddress: srv.hostIp || srv.privateIp,
        hostname: srv.name,
        specs: {
          cpu: srv.cpuCores || 8,
          ram: srv.ramGb || 32,
          storage: srv.storageGb || 500,
          os: srv.operatingSystem || 'RHEL 9'
        },
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 1,
        parentIds: [onPremRootId]
      });

      edges.push({
        id: `edge-${onPremRootId}-${srvId}`,
        source: onPremRootId,
        target: srvId,
        relationship: 'HOSTS'
      });
    });
  }

  // ═════════════════════════════════════════════════════════════════════════════
  // PARADIGM 4: COMPONENT ARCHITECTURE (Components -> Applications -> Environments -> Servers)
  // ═════════════════════════════════════════════════════════════════════════════
  else if (filters.mode === 'component') {
    const effectiveComps = components.length > 0 ? components : [
      { id: 'comp-default', name: 'Core Microservices & APIs', code: 'CORE-API', businessUnit: 'Digital Banking', projectName: 'Core Banking', endpointUrl: 'https://api.enterprise.com/v1' }
    ];

    effectiveComps.forEach(comp => {
      const compId = `comp-${comp.id || comp.name}`;
      const compApps = applications.filter(a => a.componentName?.toLowerCase() === comp.name.toLowerCase());

      nodeMap.set(compId, {
        id: compId,
        key: compId,
        label: comp.name,
        subLabel: comp.endpointUrl ? `API: ${comp.endpointUrl}` : `Code: ${comp.code}`,
        category: 'COMPONENT',
        infrastructureType: 'HYBRID',
        status: (comp.status as any) || 'ACTIVE',
        health: calculateHealth(comp.status),
        businessUnit: comp.businessUnit,
        projectName: comp.projectName,
        componentName: comp.name,
        endpointUrl: comp.endpointUrl,
        x: 0,
        y: 0,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
        depth: 0,
        childIds: compApps.map(a => `app-${a.id || a.name}`)
      });

      compApps.forEach(app => {
        const appId = `app-${app.id || app.name}`;
        nodeMap.set(appId, {
          id: appId,
          key: appId,
          label: app.name,
          subLabel: `Owner: ${app.owner || 'QE Lead'}`,
          category: 'APPLICATION',
          infrastructureType: 'HYBRID',
          status: (app.status as any) || 'ACTIVE',
          health: calculateHealth(app.status),
          businessUnit: app.businessUnit,
          projectName: app.projectName,
          componentName: comp.name,
          applicationName: app.name,
          owner: app.owner,
          x: 0,
          y: 0,
          width: NODE_WIDTH,
          height: NODE_HEIGHT,
          depth: 1,
          parentIds: [compId]
        });

        edges.push({
          id: `edge-${compId}-${appId}`,
          source: compId,
          target: appId,
          relationship: 'DEPENDS_ON',
          animated: true
        });
      });
    });
  }

  // ═════════════════════════════════════════════════════════════════════════════
  // MULTI-DIMENSIONAL FILTERING & CALCULATION
  // ═════════════════════════════════════════════════════════════════════════════
  const searchLower = filters.search.trim().toLowerCase();
  const allNodesList = Array.from(nodeMap.values());

  allNodesList.forEach(n => {
    if (n.infrastructureType === 'CLOUD' || (n.cloudProvider && n.cloudProvider !== 'On-Premises')) cloudCount++;
    else onPremCount++;

    if (n.status === 'ACTIVE') activeCount++;
    else inactiveCount++;

    if (n.health === 'HEALTHY') healthyCount++;
    else attentionCount++;
  });

  const isAnyFilterActive =
    Boolean(searchLower) ||
    filters.businessUnit !== 'ALL' ||
    filters.project !== 'ALL' ||
    filters.application !== 'ALL' ||
    filters.component !== 'ALL' ||
    filters.environment !== 'ALL' ||
    filters.tier !== 'ALL' ||
    filters.resourceType !== 'ALL' ||
    filters.infraType !== 'ALL' ||
    filters.status !== 'ALL' ||
    filters.health !== 'ALL';

  const visibleNodeIds = new Set<string>();

  if (!isAnyFilterActive) {
    // Show all nodes by default
    allNodesList.forEach(n => visibleNodeIds.add(n.id));
  } else {
    // Filter matching nodes
    const matchingNodeIds = new Set<string>();
    allNodesList.forEach(n => {
      let match = true;

      if (searchLower) {
        const matchName = n.label.toLowerCase().includes(searchLower);
        const matchSub = n.subLabel?.toLowerCase().includes(searchLower);
        const matchIp = n.ipAddress?.toLowerCase().includes(searchLower);
        const matchEndpoint = n.endpointUrl?.toLowerCase().includes(searchLower);
        const matchHost = n.hostname?.toLowerCase().includes(searchLower);
        const matchBu = n.businessUnit?.toLowerCase().includes(searchLower);
        const matchProj = n.projectName?.toLowerCase().includes(searchLower);
        if (!matchName && !matchSub && !matchIp && !matchEndpoint && !matchHost && !matchBu && !matchProj) {
          match = false;
        }
      }

      if (filters.businessUnit !== 'ALL' && n.businessUnit && n.businessUnit.toLowerCase() !== filters.businessUnit.toLowerCase()) {
        match = false;
      }
      if (filters.project !== 'ALL' && n.projectName && n.projectName.toLowerCase() !== filters.project.toLowerCase()) {
        match = false;
      }
      if (filters.application !== 'ALL' && n.applicationName && n.applicationName.toLowerCase() !== filters.application.toLowerCase()) {
        match = false;
      }
      if (filters.component !== 'ALL' && n.componentName && n.componentName.toLowerCase() !== filters.component.toLowerCase()) {
        match = false;
      }
      if (filters.environment !== 'ALL' && n.environmentName && n.environmentName.toLowerCase() !== filters.environment.toLowerCase()) {
        match = false;
      }
      if (filters.tier !== 'ALL' && n.tier && !n.tier.toLowerCase().includes(filters.tier.toLowerCase())) {
        match = false;
      }
      if (filters.resourceType !== 'ALL' && n.category !== filters.resourceType) {
        match = false;
      }
      if (filters.infraType !== 'ALL' && n.infrastructureType !== filters.infraType) {
        match = false;
      }
      if (filters.status !== 'ALL' && n.status !== filters.status) {
        match = false;
      }
      if (filters.health !== 'ALL' && n.health !== filters.health) {
        match = false;
      }

      if (match) matchingNodeIds.add(n.id);
    });

    const addWithAncestorsAndDescendants = (nodeId: string) => {
      if (visibleNodeIds.has(nodeId)) return;
      visibleNodeIds.add(nodeId);
      const node = nodeMap.get(nodeId);
      if (node?.parentIds) {
        node.parentIds.forEach(pId => addWithAncestorsAndDescendants(pId));
      }
      if (node?.childIds && !collapsedNodeIds.has(nodeId)) {
        node.childIds.forEach(cId => addWithAncestorsAndDescendants(cId));
      }
    };

    matchingNodeIds.forEach(id => addWithAncestorsAndDescendants(id));
  }

  // ═════════════════════════════════════════════════════════════════════════════
  // COORDINATE CALCULATION & LAYER SPACING
  // ═════════════════════════════════════════════════════════════════════════════
  const finalNodes: InventoryGraphNode[] = [];
  const nodesByDepth = new Map<number, InventoryGraphNode[]>();

  visibleNodeIds.forEach(id => {
    const node = nodeMap.get(id);
    if (!node) return;
    const depth = node.depth || 0;
    if (!nodesByDepth.has(depth)) nodesByDepth.set(depth, []);
    nodesByDepth.get(depth)!.push(node);
  });

  const maxDepth = Math.max(...Array.from(nodesByDepth.keys()), 0);
  for (let d = 0; d <= maxDepth; d++) {
    const layerNodes = nodesByDepth.get(d) || [];
    layerNodes.forEach((node, idx) => {
      node.x = 40 + d * LEVEL_GAP_X;
      node.y = 40 + idx * NODE_GAP_Y;
      node.collapsed = collapsedNodeIds.has(node.id);
      finalNodes.push(node);
    });
  }

  const finalEdges = edges.filter(
    e => visibleNodeIds.has(e.source) && visibleNodeIds.has(e.target)
  );

  return {
    nodes: finalNodes,
    edges: finalEdges,
    kpis: {
      totalEnvironments,
      totalServers,
      totalSoftware,
      totalApplications,
      totalComponents,
      onPremCount,
      cloudCount,
      activeCount,
      inactiveCount,
      healthyCount,
      attentionCount
    }
  };
};
