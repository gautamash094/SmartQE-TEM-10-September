import React from 'react';
import {
  X,
  Globe,
  Server,
  Cpu,
  Layers,
  HardDrive,
  Cloud,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Copy,
  Activity,
  ArrowRight,
  ShieldAlert,
  Component as ComponentIcon
} from 'lucide-react';
import { InventoryGraphNode } from './inventoryGraphBuilder';

interface InventoryNodeDetailsDrawerProps {
  node: InventoryGraphNode | null;
  isOpen: boolean;
  onClose: () => void;
  allNodes: InventoryGraphNode[];
  onSelectNode: (node: InventoryGraphNode) => void;
  onFilterToSubtree?: (node: InventoryGraphNode) => void;
}

export const InventoryNodeDetailsDrawer: React.FC<InventoryNodeDetailsDrawerProps> = ({
  node,
  isOpen,
  onClose,
  allNodes,
  onSelectNode,
  onFilterToSubtree
}) => {
  if (!isOpen || !node) return null;

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'ENVIRONMENT':
        return <Globe className="w-5 h-5 text-cyan-400" />;
      case 'APPLICATION':
        return <Layers className="w-5 h-5 text-purple-400" />;
      case 'COMPONENT':
        return <ComponentIcon className="w-5 h-5 text-indigo-400" />;
      case 'SERVER':
        return <Server className="w-5 h-5 text-blue-400" />;
      case 'SOFTWARE':
        return <Cpu className="w-5 h-5 text-orange-400" />;
      case 'CLOUD_RESOURCE':
        return <Cloud className="w-5 h-5 text-sky-400" />;
      default:
        return <HardDrive className="w-5 h-5 text-emerald-400" />;
    }
  };

  const getHealthBadge = (health: string) => {
    switch (health) {
      case 'HEALTHY':
        return (
          <span className="px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-[11px] font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" /> Healthy
          </span>
        );
      case 'WARNING':
        return (
          <span className="px-2.5 py-1 rounded-lg bg-amber-950/80 border border-amber-700 text-amber-300 text-[11px] font-bold flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" /> Maintenance / Warning
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="px-2.5 py-1 rounded-lg bg-red-950/80 border border-red-700 text-red-300 text-[11px] font-bold flex items-center gap-1.5 animate-pulse">
            <ShieldAlert className="w-3.5 h-3.5" /> Critical / Degraded
          </span>
        );
      default:
        return null;
    }
  };

  // Find related parents and children
  const parentNodes = allNodes.filter(n => node.parentIds?.includes(n.id));
  const childNodes = allNodes.filter(n => node.childIds?.includes(n.id));

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[420px] bg-[#0c121e]/98 backdrop-blur-md border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col font-mono animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="p-5 border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between gap-3 bg-gradient-to-r from-slate-900 via-[#0e1626] to-slate-900">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-black/40 border border-slate-700/80 flex items-center justify-center shrink-0">
            {getCategoryIcon(node.category)}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider">
                {node.category}
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-[10px] text-slate-400 uppercase">
                {node.infrastructureType}
              </span>
            </div>
            <h3 className="text-sm font-bold text-white truncate">{node.label}</h3>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
        {/* Status & Health Summary Box */}
        <div className="bg-black/40 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 uppercase block mb-1 font-bold">OPERATIONAL STATE</span>
            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 text-xs font-bold">
              {node.status}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 uppercase block mb-1 font-bold">TELEMETRY HEALTH</span>
            {getHealthBadge(node.health)}
          </div>
        </div>

        {/* Core Attributes */}
        <div className="space-y-2 bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block border-b border-slate-200 dark:border-slate-800 pb-1">
            CORE SPECIFICATIONS
          </span>

          <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
            {node.businessUnit && (
              <div>
                <span className="text-slate-500 block text-[10px]">Business Unit</span>
                <span className="text-white font-bold">{node.businessUnit}</span>
              </div>
            )}
            {node.projectName && (
              <div>
                <span className="text-slate-500 block text-[10px]">Project</span>
                <span className="text-white font-bold">{node.projectName}</span>
              </div>
            )}
            {node.environmentName && (
              <div>
                <span className="text-slate-500 block text-[10px]">Environment</span>
                <span className="text-cyan-400 font-bold">{node.environmentName}</span>
              </div>
            )}
            {node.tier && (
              <div>
                <span className="text-slate-500 block text-[10px]">Tier</span>
                <span className="text-amber-400 font-bold">{node.tier}</span>
              </div>
            )}
            {node.cloudProvider && (
              <div>
                <span className="text-slate-500 block text-[10px]">Cloud Provider</span>
                <span className="text-sky-400 font-bold">{node.cloudProvider}</span>
              </div>
            )}
            {node.owner && (
              <div>
                <span className="text-slate-500 block text-[10px]">Owner Team</span>
                <span className="text-white font-bold">{node.owner}</span>
              </div>
            )}
            {node.ipAddress && (
              <div className="col-span-2">
                <span className="text-slate-500 block text-[10px]">Host / IP Address</span>
                <span className="text-emerald-400 font-bold">{node.ipAddress}</span>
              </div>
            )}
            {node.endpointUrl && (
              <div className="col-span-2">
                <span className="text-slate-500 block text-[10px]">Dynamic Endpoint URL</span>
                <a
                  href={node.endpointUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-cyan-400 hover:text-cyan-300 font-bold break-all flex items-center gap-1 mt-0.5"
                >
                  <span>{node.endpointUrl}</span>
                  <ExternalLink className="w-3 h-3 shrink-0" />
                </a>
              </div>
            )}
          </div>

          {node.specs && (
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-200 dark:border-slate-800/80 text-[10px]">
              {node.specs.cpu && (
                <div className="bg-black/30 p-2 rounded border border-slate-200 dark:border-slate-800 text-center">
                  <span className="text-slate-400 block">CPU</span>
                  <span className="text-white font-bold text-xs">{node.specs.cpu} Cores</span>
                </div>
              )}
              {node.specs.ram && (
                <div className="bg-black/30 p-2 rounded border border-slate-200 dark:border-slate-800 text-center">
                  <span className="text-slate-400 block">RAM</span>
                  <span className="text-white font-bold text-xs">{node.specs.ram} GB</span>
                </div>
              )}
              {node.specs.storage && (
                <div className="bg-black/30 p-2 rounded border border-slate-200 dark:border-slate-800 text-center">
                  <span className="text-slate-400 block">Storage</span>
                  <span className="text-white font-bold text-xs">{node.specs.storage} GB</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Upstream Parents */}
        {parentNodes.length > 0 && (
          <div className="space-y-2 bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block border-b border-slate-200 dark:border-slate-800 pb-1">
              UPSTREAM DEPENDENCIES ({parentNodes.length})
            </span>
            <div className="space-y-1.5 pt-1">
              {parentNodes.map(p => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onSelectNode(p)}
                  className="w-full bg-black/40 hover:bg-slate-800/80 p-2 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between text-left transition-colors group"
                >
                  <div className="flex items-center gap-2 truncate">
                    {getCategoryIcon(p.category)}
                    <div>
                      <strong className="text-white text-xs group-hover:text-orange-400 truncate block">
                        {p.label}
                      </strong>
                      <span className="text-[10px] text-slate-400">{p.category}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Downstream Children */}
        {childNodes.length > 0 && (
          <div className="space-y-2 bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block border-b border-slate-200 dark:border-slate-800 pb-1">
              DOWNSTREAM CHILDREN ({childNodes.length})
            </span>
            <div className="space-y-1.5 pt-1 max-h-48 overflow-y-auto">
              {childNodes.map(c => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => onSelectNode(c)}
                  className="w-full bg-black/40 hover:bg-slate-800/80 p-2 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between text-left transition-colors group"
                >
                  <div className="flex items-center gap-2 truncate">
                    {getCategoryIcon(c.category)}
                    <div>
                      <strong className="text-white text-xs group-hover:text-orange-400 truncate block">
                        {c.label}
                      </strong>
                      <span className="text-[10px] text-slate-400">{c.subLabel || c.category}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer Quick Actions */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-900/90 flex items-center justify-between gap-2">
        {onFilterToSubtree && (
          <button
            type="button"
            onClick={() => onFilterToSubtree(node)}
            className="px-3.5 py-2 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold transition-all shadow-[0_0_12px_rgba(249,115,22,0.4)]"
          >
            Focus Subtree
          </button>
        )}

        <button
          type="button"
          onClick={() => {
            navigator.clipboard.writeText(JSON.stringify(node, null, 2));
          }}
          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-700 flex items-center gap-1.5"
        >
          <Copy className="w-3.5 h-3.5 text-slate-400" />
          <span>Copy Specs</span>
        </button>

        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all"
        >
          Close
        </button>
      </div>
    </div>
  );
};
