import React from 'react';
import {
  Search,
  RotateCcw,
  Download,
  Filter,
  Layers,
  Globe,
  Cloud,
  Component as ComponentIcon,
  X
} from 'lucide-react';
import { InventoryVisualFilterState, InventoryVisualMode } from './inventoryGraphBuilder';
import { EnvironmentProfile } from '../../../types/environmentDetails';
import {
  BusinessUnit,
  Project,
  ApplicationEntity,
  ComponentEntity
} from '../../../services/portfolioService';

interface InventoryVisualFilterBarProps {
  filters: InventoryVisualFilterState;
  onChangeFilter: (key: keyof InventoryVisualFilterState, value: string) => void;
  onResetFilters: () => void;
  businessUnits: BusinessUnit[];
  projects: Project[];
  components: ComponentEntity[];
  applications: ApplicationEntity[];
  environmentProfiles: EnvironmentProfile[];
  onExport: (format: 'png' | 'svg' | 'json') => void;
}

export const InventoryVisualFilterBar: React.FC<InventoryVisualFilterBarProps> = ({
  filters,
  onChangeFilter,
  onResetFilters,
  businessUnits,
  projects,
  components,
  applications,
  environmentProfiles,
  onExport
}) => {
  const modes: { id: InventoryVisualMode; label: string; icon: any; description: string }[] = [
    {
      id: 'hierarchy',
      label: 'Traceability Hierarchy',
      icon: Layers,
      description: 'BU → Project → Component → App → Env → Server → Software'
    },
    {
      id: 'environment',
      label: 'Environment Tiers',
      icon: Globe,
      description: 'DEV / QA / UAT / PROD clusters & hosted infrastructure'
    },
    {
      id: 'infra',
      label: 'Cloud vs On-Prem',
      icon: Cloud,
      description: 'AWS / Azure / GCP vs Datacenter Bare-Metal'
    },
    {
      id: 'component',
      label: 'Component Architecture',
      icon: ComponentIcon,
      description: 'Service Endpoints & application dependencies'
    }
  ];

  // Check if any non-default filter is active
  const hasActiveFilters =
    Boolean(filters.search) ||
    filters.businessUnit !== 'ALL' ||
    filters.project !== 'ALL' ||
    filters.application !== 'ALL' ||
    filters.component !== 'ALL' ||
    filters.environment !== 'ALL' ||
    filters.tier !== 'ALL' ||
    filters.resourceType !== 'ALL' ||
    filters.infraType !== 'ALL' ||
    filters.status !== 'ALL' ||
    filters.health !== 'ALL';

  return (
    <div className="space-y-3 font-mono bg-[#0c121e] border border-slate-200 dark:border-slate-800/90 rounded-2xl p-4 shadow-xl">
      {/* Top Row: View Paradigm Mode Switcher & Export */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800/80 pb-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1 hidden sm:inline">
            VISUAL PARADIGM:
          </span>
          <div className="flex flex-wrap items-center gap-1.5 bg-black/40 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
            {modes.map(m => {
              const Icon = m.icon;
              const isSelected = filters.mode === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onChangeFilter('mode', m.id)}
                  title={m.description}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-gradient-to-r from-orange-600 to-amber-500 text-white shadow-[0_0_12px_rgba(249,115,22,0.4)]'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Export Triggers */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onExport('png')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-700"
            title="Export as PNG image"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>PNG</span>
          </button>

          <button
            type="button"
            onClick={() => onExport('svg')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-700"
            title="Export as SVG vector"
          >
            <Download className="w-3.5 h-3.5 text-orange-400" />
            <span>SVG</span>
          </button>

          <button
            type="button"
            onClick={() => onExport('json')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-700"
            title="Export graph schema as JSON"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>JSON</span>
          </button>
        </div>
      </div>

      {/* Second Row: Search & Multi-Dimensional Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
        {/* Instant Search Bar */}
        <div className="relative sm:col-span-2">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input autoComplete="off" data-lpignore="true"
            type="text"
            value={filters.search}
            onChange={e => onChangeFilter('search', e.target.value)}
            placeholder="Search resources, hostname, IP, endpoints..."
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl pl-9 pr-8 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 transition-colors"
          />
          {filters.search && (
            <button
              type="button"
              onClick={() => onChangeFilter('search', '')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Business Unit Filter */}
        <div>
          <select
            value={filters.businessUnit}
            onChange={e => onChangeFilter('businessUnit', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Business Units</option>
            {businessUnits.map(b => (
              <option key={b.id} value={b.name}>
                {b.name}
              </option>
            ))}
          </select>
        </div>

        {/* Project Filter */}
        <div>
          <select
            value={filters.project}
            onChange={e => onChangeFilter('project', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Projects</option>
            {projects
              .filter(p => filters.businessUnit === 'ALL' || p.businessUnit.toLowerCase() === filters.businessUnit.toLowerCase())
              .map(p => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
          </select>
        </div>

        {/* Application Filter */}
        <div>
          <select
            value={filters.application}
            onChange={e => onChangeFilter('application', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Applications</option>
            {applications.map(a => (
              <option key={a.id} value={a.name}>
                {a.name}
              </option>
            ))}
          </select>
        </div>

        {/* Component Filter */}
        <div>
          <select
            value={filters.component}
            onChange={e => onChangeFilter('component', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Components</option>
            {components.map(c => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Third Row: Environment, Tier, Resource Type, Infra, Status, Health & Reset */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5 pt-1">
        {/* Environment Filter */}
        <div>
          <select
            value={filters.environment}
            onChange={e => onChangeFilter('environment', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Environments</option>
            {environmentProfiles.map(e => (
              <option key={e.id} value={e.name}>
                {e.name}
              </option>
            ))}
          </select>
        </div>

        {/* Environment Tier Filter */}
        <div>
          <select
            value={filters.tier}
            onChange={e => onChangeFilter('tier', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Tiers</option>
            <option value="DEV">DEV</option>
            <option value="QA">QA</option>
            <option value="UAT">UAT</option>
            <option value="STAGING">STAGING</option>
            <option value="PROD">PROD</option>
            <option value="PERF">PERF</option>
          </select>
        </div>

        {/* Resource Type Filter */}
        <div>
          <select
            value={filters.resourceType}
            onChange={e => onChangeFilter('resourceType', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Resource Types</option>
            <option value="ENVIRONMENT">Environments</option>
            <option value="APPLICATION">Applications</option>
            <option value="COMPONENT">Components</option>
            <option value="SERVER">Servers</option>
            <option value="SOFTWARE">Software Packages</option>
            <option value="CLOUD_RESOURCE">Cloud Resources</option>
          </select>
        </div>

        {/* Infrastructure Type Filter */}
        <div>
          <select
            value={filters.infraType}
            onChange={e => onChangeFilter('infraType', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Infra Types</option>
            <option value="CLOUD">Cloud (AWS/Azure/GCP)</option>
            <option value="ON_PREMISES">On-Premises</option>
            <option value="HYBRID">Hybrid</option>
          </select>
        </div>

        {/* Health Status Filter */}
        <div>
          <select
            value={filters.health}
            onChange={e => onChangeFilter('health', e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
          >
            <option value="ALL">All Health States</option>
            <option value="HEALTHY">Healthy (Optimal)</option>
            <option value="WARNING">Warning (Maintenance)</option>
            <option value="CRITICAL">Critical (Degraded / Down)</option>
          </select>
        </div>

        {/* Reset Filters Action */}
        <div>
          <button
            type="button"
            onClick={onResetFilters}
            disabled={!hasActiveFilters}
            className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-700"
          >
            <RotateCcw className="w-3.5 h-3.5 text-orange-400" />
            <span>Reset Filters</span>
          </button>
        </div>
      </div>
    </div>
  );
};
