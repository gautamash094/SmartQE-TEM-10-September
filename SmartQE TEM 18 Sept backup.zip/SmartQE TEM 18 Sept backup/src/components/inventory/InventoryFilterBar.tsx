import React, { useState } from 'react';
import { InventoryFilterState, SavedFilterPreset } from '../../types/inventory';
import {
  Search,
  Filter,
  X,
  RotateCcw,
  SlidersHorizontal,
  Bookmark,
  ChevronDown,
  Download,
  Eye,
  Check
} from 'lucide-react';

interface InventoryFilterBarProps {
  filters: InventoryFilterState;
  onFilterChange: (key: keyof InventoryFilterState, value: string) => void;
  onResetFilters: () => void;
  onApplyPreset: (preset: SavedFilterPreset) => void;
  businessUnits: string[];
  accounts: string[];
  environments: string[];
  environmentTypes: string[];
  cloudProviders: string[];
  operatingSystems: string[];
  totalResults: number;
  onExportCsv?: () => void;
  visibleColumns: Record<string, boolean>;
  onToggleColumn: (colKey: string) => void;
}

export const PRESET_FILTERS: SavedFilterPreset[] = [
  {
    id: 'all',
    name: 'All Assets',
    filters: {
      search: '',
      businessUnit: 'ALL',
      accountName: 'ALL',
      environment: 'ALL',
      environmentType: 'ALL',
      assetType: 'ALL',
      infrastructureType: 'ALL',
      cloudProvider: 'ALL',
      region: 'ALL',
      status: 'ALL',
      operatingSystem: 'ALL',
      ownerTeam: 'ALL'
    }
  },
  {
    id: 'aws-cloud',
    name: 'AWS Cloud Assets',
    filters: {
      cloudProvider: 'AWS',
      infrastructureType: 'CLOUD',
      status: 'ALL'
    }
  },
  {
    id: 'on-prem',
    name: 'On-Premises Hardware',
    filters: {
      infrastructureType: 'ON_PREMISES',
      status: 'ALL'
    }
  },
  {
    id: 'databases',
    name: 'Critical Databases',
    filters: {
      assetType: 'DATABASE',
      status: 'ACTIVE'
    }
  },
  {
    id: 'maintenance-eol',
    name: 'Attention & Maint',
    filters: {
      status: 'MAINTENANCE'
    }
  },
  {
    id: 'active-compute',
    name: 'Active Compute Servers',
    filters: {
      assetType: 'SERVER',
      status: 'ACTIVE'
    }
  }
];

export const COLUMN_DEFINITIONS = [
  { key: 'assetId', label: 'Asset ID' },
  { key: 'name', label: 'Asset Name' },
  { key: 'assetType', label: 'Asset Type' },
  { key: 'environment', label: 'Environment' },
  { key: 'hierarchy', label: 'BU / Account' },
  { key: 'infrastructure', label: 'Infra / Provider' },
  { key: 'ipHostname', label: 'IP / Hostname' },
  { key: 'specs', label: 'Hardware Specs' },
  { key: 'software', label: 'Software Stack' },
  { key: 'status', label: 'Status' },
  { key: 'owner', label: 'Owner Team' },
  { key: 'actions', label: 'Actions' },
];

export const InventoryFilterBar: React.FC<InventoryFilterBarProps> = ({
  filters,
  onFilterChange,
  onResetFilters,
  onApplyPreset,
  businessUnits,
  accounts,
  environments,
  environmentTypes,
  cloudProviders,
  operatingSystems,
  totalResults,
  onExportCsv,
  visibleColumns,
  onToggleColumn
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [columnMenuOpen, setColumnMenuOpen] = useState(false);

  const isFiltered = Object.entries(filters).some(([k, v]) => {
    if (k === 'search') return Boolean(v);
    return v !== 'ALL' && v !== '';
  });

  return (
    <div className="bg-[#0b1019] border border-slate-200 dark:border-slate-800/90 rounded-xl p-4 shadow-xl space-y-4 font-mono">
      {/* Top Search Bar, Presets & Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[280px]">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input autoComplete="off" data-lpignore="true"
            type="text"
            value={filters.search}
            onChange={(e) => onFilterChange('search', e.target.value)}
            placeholder="Search by Asset ID, Hostname, IP, BU, App, or Specs..."
            className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg pl-10 pr-9 py-2.5 outline-none transition-all placeholder:text-slate-500"
          />
          {filters.search && (
            <button
              onClick={() => onFilterChange('search', '')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Right Tools */}
        <div className="flex items-center gap-2">
          {/* Advanced Filter Toggle */}
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all border ${
              showAdvanced || isFiltered
                ? 'bg-orange-500/10 border-orange-500/50 text-orange-400'
                : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filters</span>
            {isFiltered && (
              <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
            )}
          </button>

          {/* Column Visibility Selector */}
          <div className="relative">
            <button
              onClick={() => setColumnMenuOpen(!columnMenuOpen)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800/80 border border-slate-700/80 text-slate-300 hover:bg-slate-700 text-xs font-bold transition-all"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Columns</span>
              <ChevronDown className="w-3 h-3 ml-0.5" />
            </button>

            {columnMenuOpen && (
              <div className="absolute right-0 top-full mt-2 w-56 bg-[#101725] border border-slate-700 rounded-xl shadow-2xl z-30 p-2 space-y-1">
                <div className="px-2 py-1 text-[10px] text-slate-400 font-bold uppercase border-b border-slate-200 dark:border-slate-800">
                  Toggle Columns
                </div>
                {COLUMN_DEFINITIONS.map((col) => (
                  <button
                    key={col.key}
                    onClick={() => onToggleColumn(col.key)}
                    className="w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs text-slate-200 hover:bg-slate-800 transition-colors text-left"
                  >
                    <span>{col.label}</span>
                    {visibleColumns[col.key] && (
                      <Check className="w-3.5 h-3.5 text-orange-400" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Export CSV */}
          {onExportCsv && (
            <button
              onClick={onExportCsv}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800/80 border border-slate-700/80 text-slate-300 hover:bg-slate-700 text-xs font-bold transition-all"
              title="Export filtered records to CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export</span>
            </button>
          )}

          {/* Reset Filters */}
          {isFiltered && (
            <button
              onClick={onResetFilters}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-rose-950/40 border border-rose-800/50 text-rose-300 hover:bg-rose-900/50 text-xs font-bold transition-all"
              title="Clear all active filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          )}
        </div>
      </div>

      {/* Quick Filter Presets Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-[10px] text-slate-500 uppercase font-bold flex items-center gap-1 shrink-0">
          <Bookmark className="w-3 h-3 text-orange-500" /> Presets:
        </span>
        {PRESET_FILTERS.map((preset) => (
          <button
            key={preset.id}
            onClick={() => onApplyPreset(preset)}
            className="px-2.5 py-1 rounded-md bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-slate-600 text-slate-300 hover:text-white text-[11px] font-sans transition-all shrink-0"
          >
            {preset.name}
          </button>
        ))}
      </div>

      {/* Primary Combinable Filter Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-2 border-t border-slate-200 dark:border-slate-800/80">
        {/* Business Unit */}
        <div>
          <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Business Unit</label>
          <select
            value={filters.businessUnit}
            onChange={(e) => onFilterChange('businessUnit', e.target.value)}
            className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
          >
            <option value="ALL">All Business Units</option>
            {businessUnits.map((bu) => (
              <option key={bu} value={bu}>{bu}</option>
            ))}
          </select>
        </div>

        {/* Account / Project */}
        <div>
          <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Account / Project</label>
          <select
            value={filters.accountName}
            onChange={(e) => onFilterChange('accountName', e.target.value)}
            className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
          >
            <option value="ALL">All Accounts/Projects</option>
            {accounts.map((acc) => (
              <option key={acc} value={acc}>{acc}</option>
            ))}
          </select>
        </div>

        {/* Environment */}
        <div>
          <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Environment</label>
          <select
            value={filters.environment}
            onChange={(e) => onFilterChange('environment', e.target.value)}
            className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
          >
            <option value="ALL">All Environments</option>
            {environments.map((env) => (
              <option key={env} value={env}>{env}</option>
            ))}
          </select>
        </div>

        {/* Asset Type */}
        <div>
          <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Asset Category</label>
          <select
            value={filters.assetType}
            onChange={(e) => onFilterChange('assetType', e.target.value)}
            className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
          >
            <option value="ALL">All Categories</option>
            <option value="SERVER">Compute Server / VM</option>
            <option value="DATABASE">Database (RDBMS/NoSQL)</option>
            <option value="CLOUD_RESOURCE">Cloud Resource / Cluster</option>
            <option value="NETWORK_COMPONENT">Network / Gateway</option>
            <option value="STORAGE">Storage (SAN/EBS)</option>
            <option value="SOFTWARE">Software / App</option>
          </select>
        </div>

        {/* Infrastructure Type */}
        <div>
          <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Hosting Type</label>
          <select
            value={filters.infrastructureType}
            onChange={(e) => onFilterChange('infrastructureType', e.target.value)}
            className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
          >
            <option value="ALL">All Hosting</option>
            <option value="CLOUD">Cloud Hosted</option>
            <option value="ON_PREMISES">On-Premises Datacenter</option>
            <option value="HYBRID">Hybrid</option>
          </select>
        </div>

        {/* Status */}
        <div>
          <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Lifecycle Status</label>
          <select
            value={filters.status}
            onChange={(e) => onFilterChange('status', e.target.value)}
            className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">ACTIVE (Operational)</option>
            <option value="MAINTENANCE">MAINTENANCE</option>
            <option value="INACTIVE">INACTIVE</option>
            <option value="PROVISIONING">PROVISIONING</option>
            <option value="RETIRED">RETIRED</option>
          </select>
        </div>
      </div>

      {/* Expanded Advanced Filters */}
      {showAdvanced && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2 border-t border-slate-200 dark:border-slate-800/80 bg-slate-950/40 p-3 rounded-lg">
          {/* Cloud Provider */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Cloud Provider</label>
            <select
              value={filters.cloudProvider}
              onChange={(e) => onFilterChange('cloudProvider', e.target.value)}
              className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
            >
              <option value="ALL">All Providers</option>
              {cloudProviders.map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>

          {/* Environment Type */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Environment Type</label>
            <select
              value={filters.environmentType}
              onChange={(e) => onFilterChange('environmentType', e.target.value)}
              className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
            >
              <option value="ALL">All Env Types</option>
              {environmentTypes.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          {/* Operating System */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Operating System</label>
            <select
              value={filters.operatingSystem}
              onChange={(e) => onFilterChange('operatingSystem', e.target.value)}
              className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
            >
              <option value="ALL">All OS Platforms</option>
              {operatingSystems.map((os) => (
                <option key={os} value={os}>{os}</option>
              ))}
            </select>
          </div>

          {/* Region */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Region / Zone</label>
            <input autoComplete="off" data-lpignore="true"
              type="text"
              value={filters.region === 'ALL' ? '' : filters.region}
              onChange={(e) => onFilterChange('region', e.target.value || 'ALL')}
              placeholder="e.g. us-east-1, eastus2"
              className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 outline-none font-sans"
            />
          </div>
        </div>
      )}

      {/* Results Counter Bar */}
      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
        <div>
          Showing <span className="text-white font-bold">{totalResults}</span> matching assets
          {isFiltered && <span className="text-orange-400 ml-1.5 font-bold">(Filtered)</span>}
        </div>
        <div className="text-slate-500">
          Click any asset row to open its detailed dossier and relationship graph.
        </div>
      </div>
    </div>
  );
};
