import React, { useState } from 'react';
import {
  InventoryAsset,
  AssetStatus,
  AssetAuditLog
} from '../../types/inventory';
import {
  X,
  Boxes,
  Server,
  Cloud,
  Layers,
  Cpu,
  Edit2,
  HardDrive,
  Globe,
  Shield,
  Activity,
  Clock,
  User,
  Building2,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Calendar,
  Tag,
  ArrowRight,
  Terminal,
  ExternalLink,
  ShieldAlert,
  Archive,
  RefreshCw,
  Download
} from 'lucide-react';

interface InventoryAssetDossierModalProps {
  asset: InventoryAsset | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (asset: InventoryAsset) => void;
  onStatusChange: (id: string, newStatus: AssetStatus, reason?: string) => Promise<void>;
}

export const InventoryAssetDossierModal: React.FC<InventoryAssetDossierModalProps> = ({
  asset,
  isOpen,
  onClose,
  onEdit,
  onStatusChange
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'software' | 'lifecycle' | 'audit'>('overview');
  const [statusReason, setStatusReason] = useState('');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  if (!isOpen || !asset) return null;

  const handleStatusTransition = async (targetStatus: AssetStatus) => {
    try {
      setIsUpdatingStatus(true);
      await onStatusChange(asset.id, targetStatus, statusReason || `Status transitioned to ${targetStatus} via Asset Dossier`);
      setStatusReason('');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(asset, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `asset-dossier-${asset.assetId}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getStatusColor = (st: AssetStatus) => {
    switch (st) {
      case 'ACTIVE':
        return 'bg-emerald-950/80 border-emerald-700 text-emerald-300';
      case 'MAINTENANCE':
        return 'bg-amber-950/80 border-amber-700 text-amber-300';
      case 'INACTIVE':
      case 'PROVISIONING':
        return 'bg-blue-950/80 border-blue-700 text-blue-300';
      case 'RETIRED':
      case 'DECOMMISSIONED':
        return 'bg-rose-950/80 border-rose-700 text-rose-300';
      default:
        return 'bg-slate-800 border-slate-700 text-slate-300';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 dark:bg-black/80 backdrop-blur-sm font-mono animate-fadeIn">
      <div className="bg-[#0b1019] border border-slate-700/80 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Top Header Card */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-[#0d1420] to-[#121c2e] flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white shadow-lg">
              <Boxes className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-base font-extrabold text-white uppercase tracking-wider">{asset.name}</h2>
                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-xs font-bold border border-slate-700">
                  {asset.assetId}
                </span>
                <span className={`px-2.5 py-0.5 rounded text-[11px] font-bold border ${getStatusColor(asset.status)}`}>
                  ● {asset.status}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-sans mt-0.5">
                {asset.assetType} • {asset.infrastructureType} • {asset.cloudProvider} ({asset.region || asset.datacenter || 'Global'})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportJson}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-700"
              title="Download asset profile JSON"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Dossier</span>
            </button>

            <button
              onClick={() => onEdit(asset)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold transition-all shadow"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>Edit Asset</span>
            </button>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Enterprise Hierarchy Visual Tree Breadcrumb */}
        <div className="px-6 py-3 bg-[#080c13] border-b border-slate-200 dark:border-slate-800/80 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-[10px] text-slate-500 font-bold uppercase shrink-0">Hierarchy Path:</span>
          
          <div className="flex items-center gap-1.5 shrink-0 px-2.5 py-1 rounded bg-[#131b28] border border-slate-200 dark:border-slate-800 text-slate-300">
            <Building2 className="w-3 h-3 text-orange-400" />
            <span className="text-slate-400">BU:</span>
            <span className="text-white font-bold">{asset.businessUnit}</span>
          </div>

          <ArrowRight className="w-3 h-3 text-slate-600 shrink-0" />

          <div className="flex items-center gap-1.5 shrink-0 px-2.5 py-1 rounded bg-[#131b28] border border-slate-200 dark:border-slate-800 text-slate-300">
            <Layers className="w-3 h-3 text-cyan-400" />
            <span className="text-slate-400">Account:</span>
            <span className="text-white font-bold">{asset.accountName || 'Core Account'}</span>
          </div>

          <ArrowRight className="w-3 h-3 text-slate-600 shrink-0" />

          <div className="flex items-center gap-1.5 shrink-0 px-2.5 py-1 rounded bg-[#131b28] border border-slate-200 dark:border-slate-800 text-slate-300">
            <Globe className="w-3 h-3 text-emerald-400" />
            <span className="text-slate-400">Environment:</span>
            <span className="text-white font-bold">{asset.environmentName || 'Standalone'}</span>
          </div>

          <ArrowRight className="w-3 h-3 text-slate-600 shrink-0" />

          <div className="flex items-center gap-1.5 shrink-0 px-2.5 py-1 rounded bg-orange-950/40 border border-orange-800/60 text-orange-300">
            <Server className="w-3 h-3 text-orange-400" />
            <span className="text-orange-400 font-bold">Asset: {asset.name}</span>
          </div>

          <ArrowRight className="w-3 h-3 text-slate-600 shrink-0" />

          <div className="flex items-center gap-1.5 shrink-0 px-2.5 py-1 rounded bg-purple-950/40 border border-purple-800/60 text-purple-300">
            <Cpu className="w-3 h-3 text-purple-400" />
            <span>{asset.installedSoftware.length} Linked Services</span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 pt-2 border-b border-slate-200 dark:border-slate-800 bg-[#090d14]">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'overview'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Specifications & Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('software')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'software'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Installed Software ({asset.installedSoftware.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('lifecycle')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'lifecycle'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Lifecycle Management</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'audit'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Audit History & Traceability ({asset.auditLogs?.length || 1})</span>
          </button>
        </div>

        {/* Dossier Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: Specification Overview */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Technical Specifications Matrix */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Hardware Spec Card */}
                <div className="bg-[#101725] border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800/80 pb-2">
                    <HardDrive className="w-4 h-4" />
                    <span>Hardware Specifications</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">CPU Compute:</span>
                      <span className="text-white font-bold">{asset.cpuCores || 4} vCPUs</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">RAM Memory:</span>
                      <span className="text-white font-bold">{asset.ramGb || 16} GB</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Storage Capacity:</span>
                      <span className="text-white font-bold">{asset.storageGb || 250} GB SSD</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Operating System:</span>
                      <span className="text-white font-bold">{asset.operatingSystem || 'Linux'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">OS Version / Kernel:</span>
                      <span className="text-white">{asset.osVersion || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Runtime Stack:</span>
                      <span className="text-white">{asset.runtimeStack || 'Standard Enterprise Runtime'}</span>
                    </div>
                  </div>
                </div>

                {/* Cloud & Network Card */}
                <div className="bg-[#101725] border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800/80 pb-2">
                    <Globe className="w-4 h-4" />
                    <span>Network & Cloud Hosting</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">IP Address:</span>
                      <span className="text-cyan-300 font-bold font-mono">{asset.ipAddress || '10.0.0.1'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">FQDN / Hostname:</span>
                      <span className="text-white truncate max-w-[170px]" title={asset.hostname}>
                        {asset.hostname || 'internal.smartqe.io'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Cloud Provider:</span>
                      <span className="text-white font-bold">{asset.cloudProvider}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Region / AZ:</span>
                      <span className="text-white">{asset.region || asset.datacenter || 'us-east-1'} ({asset.availabilityZone || asset.rackUnit || 'Zone A'})</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Instance SKU / ID:</span>
                      <span className="text-white font-mono">{asset.instanceType || 'm6i.2xlarge'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Subnet / VPC:</span>
                      <span className="text-white font-mono truncate max-w-[170px]">{asset.vpcSubnet || 'vpc-default-sub1'}</span>
                    </div>
                  </div>
                </div>

                {/* Ownership & Maintenance Card */}
                <div className="bg-[#101725] border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-orange-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800/80 pb-2">
                    <Shield className="w-4 h-4" />
                    <span>Governance & Ownership</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Owner Team:</span>
                      <span className="text-white font-bold">{asset.ownerTeam}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Lead Engineer:</span>
                      <span className="text-white">{asset.responsiblePerson || 'Ops Engineer'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Cost Center:</span>
                      <span className="text-white font-mono">{asset.costCenter || 'CC-ENG-402'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">End of Life (EOL):</span>
                      <span className={`font-bold ${asset.endOfLifeDate && asset.endOfLifeDate <= '2027-01-01' ? 'text-rose-400' : 'text-slate-300'}`}>
                        {asset.endOfLifeDate || '2029-12-31'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Provisioned On:</span>
                      <span className="text-slate-300">{asset.createdAt.slice(0, 10)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Last Telemetry:</span>
                      <span className="text-slate-300">{asset.updatedAt.slice(0, 19)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Notes & Operational Comments */}
              {asset.notes && (
                <div className="bg-[#101725] border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5 text-orange-400" />
                    <span>Operational Context & Notes</span>
                  </span>
                  <p className="text-xs text-slate-400 font-sans leading-relaxed">{asset.notes}</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Installed Software */}
          {activeTab === 'software' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">Installed Software Packages & Services</h3>
                  <p className="text-[11px] text-slate-400 font-sans">
                    Software running on this infrastructure asset linked to application test suites.
                  </p>
                </div>
              </div>

              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-[#0c121e]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#121a28] text-slate-400 uppercase text-[10px] border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="px-4 py-3">Software / Service Name</th>
                      <th className="px-4 py-3">Version</th>
                      <th className="px-4 py-3">Port</th>
                      <th className="px-4 py-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/80">
                    {asset.installedSoftware.map((sw, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-4 py-3 text-white font-bold flex items-center gap-2">
                          <Cpu className="w-3.5 h-3.5 text-orange-400" />
                          <span>{sw.name}</span>
                        </td>
                        <td className="px-4 py-3 text-slate-300 font-mono">{sw.version}</td>
                        <td className="px-4 py-3 text-cyan-300 font-mono">{sw.port || 'N/A'}</td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-[10px] font-bold">
                            {sw.status || 'ACTIVE'}
                          </span>
                        </td>
                      </tr>
                    ))}
                    {asset.installedSoftware.length === 0 && (
                      <tr>
                        <td colSpan={4} className="px-4 py-6 text-center text-slate-500">
                          No software components recorded on this asset.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: Lifecycle Management */}
          {activeTab === 'lifecycle' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">Asset Lifecycle State Controller</h3>
                <p className="text-[11px] text-slate-400 font-sans">
                  Manage the formal operational state of this infrastructure asset across its lifecycle.
                </p>
              </div>

              {/* Current Status Box */}
              <div className="p-4 rounded-xl bg-[#121a28] border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block">CURRENT ASSET STATUS</span>
                  <span className={`inline-block mt-1 px-3 py-1 rounded text-xs font-bold border ${getStatusColor(asset.status)}`}>
                    ● {asset.status}
                  </span>
                </div>

                <div className="text-right text-xs text-slate-400 font-sans">
                  <p>Created by: <span className="text-white font-bold">{asset.createdBy}</span></p>
                  <p>Last modified by: <span className="text-white font-bold">{asset.updatedBy}</span></p>
                </div>
              </div>

              {/* Transition Reason */}
              <div>
                <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">
                  Reason for Status Transition (Audit Trail Requirement)
                </label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={statusReason}
                  onChange={(e) => setStatusReason(e.target.value)}
                  placeholder="e.g. Scheduled quarterly patch update, Environment tear-down, EOL decommissioning..."
                  className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                />
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <button
                  type="button"
                  disabled={asset.status === 'ACTIVE' || isUpdatingStatus}
                  onClick={() => handleStatusTransition('ACTIVE')}
                  className="p-3 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/80 text-emerald-300 text-xs font-bold transition-all disabled:opacity-30 flex flex-col items-center gap-1.5"
                >
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>Set to ACTIVE</span>
                </button>

                <button
                  type="button"
                  disabled={asset.status === 'MAINTENANCE' || isUpdatingStatus}
                  onClick={() => handleStatusTransition('MAINTENANCE')}
                  className="p-3 rounded-xl bg-amber-950/40 hover:bg-amber-900/60 border border-amber-800/80 text-amber-300 text-xs font-bold transition-all disabled:opacity-30 flex flex-col items-center gap-1.5"
                >
                  <Activity className="w-5 h-5 text-amber-400" />
                  <span>Set to MAINTENANCE</span>
                </button>

                <button
                  type="button"
                  disabled={asset.status === 'INACTIVE' || isUpdatingStatus}
                  onClick={() => handleStatusTransition('INACTIVE')}
                  className="p-3 rounded-xl bg-blue-950/40 hover:bg-blue-900/60 border border-blue-800/80 text-blue-300 text-xs font-bold transition-all disabled:opacity-30 flex flex-col items-center gap-1.5"
                >
                  <Clock className="w-5 h-5 text-blue-400" />
                  <span>Set to INACTIVE</span>
                </button>

                <button
                  type="button"
                  disabled={asset.status === 'RETIRED' || isUpdatingStatus}
                  onClick={() => handleStatusTransition('RETIRED')}
                  className="p-3 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/80 text-rose-300 text-xs font-bold transition-all disabled:opacity-30 flex flex-col items-center gap-1.5"
                >
                  <Archive className="w-5 h-5 text-rose-400" />
                  <span>RETIRE ASSET</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: Audit & Traceability Timeline */}
          {activeTab === 'audit' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">Audit Trail & Traceability History</h3>
                <p className="text-[11px] text-slate-400 font-sans">
                  Immutable historical event log tracking asset creation, configuration updates, and lifecycle changes.
                </p>
              </div>

              <div className="space-y-3 relative before:absolute before:top-3 before:bottom-3 before:left-[17px] before:w-0.5 before:bg-slate-800">
                {(asset.auditLogs && asset.auditLogs.length > 0 ? asset.auditLogs : [
                  {
                    id: 'log-default',
                    action: 'CREATE',
                    changedBy: asset.createdBy || 'System Admin',
                    changedAt: asset.createdAt || new Date().toISOString(),
                    notes: 'Asset provisioned and registered in TEM inventory'
                  }
                ]).map((log, idx) => (
                  <div key={log.id || idx} className="flex items-start gap-3 relative z-10">
                    <div className="w-9 h-9 rounded-full bg-[#162030] border border-slate-700 flex items-center justify-center text-orange-400 shrink-0 shadow">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div className="flex-1 bg-[#101725] border border-slate-200 dark:border-slate-800/80 rounded-xl p-3.5 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white uppercase">{log.action}</span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {new Date(log.changedAt).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 font-sans">
                        Performed by: <span className="text-orange-400 font-bold">{log.changedBy}</span>
                      </p>
                      {log.notes && (
                        <p className="text-[11px] text-slate-400 font-sans pt-1 border-t border-slate-200 dark:border-slate-800/60 mt-1">
                          {log.notes}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
