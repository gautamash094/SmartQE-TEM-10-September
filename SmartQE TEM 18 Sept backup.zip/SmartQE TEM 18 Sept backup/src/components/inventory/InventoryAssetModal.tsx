import React, { useState, useEffect } from 'react';
import {
  InventoryAsset,
  AssetType,
  InfrastructureType,
  CloudProvider,
  AssetStatus,
  InstalledSoftwareItem
} from '../../types/inventory';
import {
  X,
  Boxes,
  Server,
  Cloud,
  Layers,
  Cpu,
  Save,
  Plus,
  Trash2,
  HardDrive,
  Globe,
  Shield,
  Tag,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { ButtonLoader } from '../common/ButtonLoader';
import { isValidIp, isValidPort, isPositiveNumber } from '../../utils/validationUtils';

interface InventoryAssetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (assetData: Partial<InventoryAsset>) => Promise<void>;
  editingAsset?: InventoryAsset | null;
  businessUnits: string[];
  projects: string[];
  environments: { id: string; name: string }[];
  softwareOptions: { id: string; name: string; version: string; port?: string }[];
}

export const InventoryAssetModal: React.FC<InventoryAssetModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingAsset,
  businessUnits,
  projects,
  environments,
  softwareOptions
}) => {
  const [activeTab, setActiveTab] = useState<'hierarchy' | 'infra' | 'specs' | 'software' | 'lifecycle'>('hierarchy');
  const [isSaving, setIsSaving] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [assetId, setAssetId] = useState('');
  const [assetType, setAssetType] = useState<AssetType>('SERVER');
  const [infrastructureType, setInfrastructureType] = useState<InfrastructureType>('CLOUD');
  const [cloudProvider, setCloudProvider] = useState<CloudProvider>('AWS');

  const [businessUnit, setBusinessUnit] = useState('');
  const [accountName, setAccountName] = useState('');
  const [environmentId, setEnvironmentId] = useState('');
  const [environmentName, setEnvironmentName] = useState('');
  const [environmentType, setEnvironmentType] = useState('UAT / Staging');
  const [applicationName, setApplicationName] = useState('');

  const [ipAddress, setIpAddress] = useState('');
  const [hostname, setHostname] = useState('');
  const [operatingSystem, setOperatingSystem] = useState('Red Hat Enterprise Linux');
  const [osVersion, setOsVersion] = useState('9.2');
  const [runtimeStack, setRuntimeStack] = useState('');
  const [cpuCores, setCpuCores] = useState<number>(8);
  const [ramGb, setRamGb] = useState<number>(32);
  const [storageGb, setStorageGb] = useState<number>(500);

  const [region, setRegion] = useState('us-east-1');
  const [availabilityZone, setAvailabilityZone] = useState('us-east-1a');
  const [datacenter, setDatacenter] = useState('');
  const [rackUnit, setRackUnit] = useState('');
  const [instanceId, setInstanceId] = useState('');
  const [instanceType, setInstanceType] = useState('m6i.2xlarge');
  const [vpcSubnet, setVpcSubnet] = useState('');

  const [installedSoftware, setInstalledSoftware] = useState<InstalledSoftwareItem[]>([]);
  const [status, setStatus] = useState<AssetStatus>('ACTIVE');
  const [ownerTeam, setOwnerTeam] = useState('Platform QE');
  const [responsiblePerson, setResponsiblePerson] = useState('Ops Engineer');
  const [costCenter, setCostCenter] = useState('CC-ENG-402');
  const [endOfLifeDate, setEndOfLifeDate] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (editingAsset) {
      setName(editingAsset.name);
      setAssetId(editingAsset.assetId);
      setAssetType(editingAsset.assetType);
      setInfrastructureType(editingAsset.infrastructureType);
      setCloudProvider(editingAsset.cloudProvider);
      setBusinessUnit(editingAsset.businessUnit);
      setAccountName(editingAsset.accountName);
      setEnvironmentId(editingAsset.environmentId || '');
      setEnvironmentName(editingAsset.environmentName || '');
      setEnvironmentType(editingAsset.environmentType || 'UAT / Staging');
      setApplicationName(editingAsset.applicationName || '');
      setIpAddress(editingAsset.ipAddress || '');
      setHostname(editingAsset.hostname || '');
      setOperatingSystem(editingAsset.operatingSystem || 'Red Hat Enterprise Linux');
      setOsVersion(editingAsset.osVersion || '9.2');
      setRuntimeStack(editingAsset.runtimeStack || '');
      setCpuCores(editingAsset.cpuCores || 8);
      setRamGb(editingAsset.ramGb || 32);
      setStorageGb(editingAsset.storageGb || 500);
      setRegion(editingAsset.region || 'us-east-1');
      setAvailabilityZone(editingAsset.availabilityZone || 'us-east-1a');
      setDatacenter(editingAsset.datacenter || '');
      setRackUnit(editingAsset.rackUnit || '');
      setInstanceId(editingAsset.instanceId || '');
      setInstanceType(editingAsset.instanceType || 'm6i.2xlarge');
      setVpcSubnet(editingAsset.vpcSubnet || '');
      setInstalledSoftware(editingAsset.installedSoftware || []);
      setStatus(editingAsset.status || 'ACTIVE');
      setOwnerTeam(editingAsset.ownerTeam || 'Platform QE');
      setResponsiblePerson(editingAsset.responsiblePerson || 'Ops Engineer');
      setCostCenter(editingAsset.costCenter || 'CC-ENG-402');
      setEndOfLifeDate(editingAsset.endOfLifeDate || '');
      setNotes(editingAsset.notes || '');
    } else {
      // Defaults for new asset
      setName('');
      setAssetId(`AST-${Math.floor(1000 + Math.random() * 9000)}`);
      setAssetType('SERVER');
      setInfrastructureType('CLOUD');
      setCloudProvider('AWS');
      setBusinessUnit(businessUnits[0] || 'Retail Banking');
      setAccountName(projects[0] || 'Core Project');
      setEnvironmentId(environments[0]?.id || '');
      setEnvironmentName(environments[0]?.name || '');
      setEnvironmentType('UAT / Staging');
      setApplicationName('');
      setIpAddress('10.142.10.25');
      setHostname('');
      setOperatingSystem('Red Hat Enterprise Linux');
      setOsVersion('9.2');
      setRuntimeStack('Java OpenJDK 21 / Spring Boot');
      setCpuCores(8);
      setRamGb(32);
      setStorageGb(500);
      setRegion('us-east-1');
      setAvailabilityZone('us-east-1a');
      setDatacenter('');
      setRackUnit('');
      setInstanceId('i-08a9f24b89');
      setInstanceType('m6i.2xlarge');
      setVpcSubnet('subnet-09a823');
      setInstalledSoftware([]);
      setStatus('ACTIVE');
      setOwnerTeam('Platform QE');
      setResponsiblePerson('Ops Engineer');
      setCostCenter('CC-ENG-402');
      setEndOfLifeDate('2028-12-31');
      setNotes('');
    }
    setActiveTab('hierarchy');
    setValidationError(null);
  }, [editingAsset, isOpen]);

  if (!isOpen) return null;

  const handleAddSoftwareItem = () => {
    setInstalledSoftware([
      ...installedSoftware,
      { name: 'New Component', version: '1.0.0', port: '8080', status: 'ACTIVE' }
    ]);
  };

  const handleRemoveSoftwareItem = (index: number) => {
    setInstalledSoftware(installedSoftware.filter((_, i) => i !== index));
  };

  const handleUpdateSoftwareItem = (index: number, field: keyof InstalledSoftwareItem, val: string) => {
    const updated = [...installedSoftware];
    updated[index] = { ...updated[index], [field]: val };
    setInstalledSoftware(updated);
  };

  const handleEnvSelect = (envNameOrId: string) => {
    const matched = environments.find((e) => e.id === envNameOrId || e.name.toLowerCase() === envNameOrId.toLowerCase());
    if (matched) {
      setEnvironmentId(matched.id);
      setEnvironmentName(matched.name);
    } else {
      setEnvironmentId(envNameOrId);
      setEnvironmentName(envNameOrId);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    const cleanBU = businessUnit.trim();
    const cleanAccount = accountName.trim();
    const cleanIp = ipAddress ? ipAddress.trim() : '';

    if (!cleanName) {
      setValidationError('Asset name is required and cannot be empty whitespace.');
      setActiveTab('hierarchy');
      return;
    }
    if (!cleanBU) {
      setValidationError('Business Unit is required to maintain enterprise hierarchy.');
      setActiveTab('hierarchy');
      return;
    }
    if (!cleanAccount) {
      setValidationError('Account / Project Name is required.');
      setActiveTab('hierarchy');
      return;
    }
    if (cleanIp && !isValidIp(cleanIp)) {
      setValidationError('Invalid IP Address format. Please enter a valid IPv4 or IPv6 address.');
      setActiveTab('specs');
      return;
    }
    if (!isPositiveNumber(cpuCores) || Number(cpuCores) < 1) {
      setValidationError('CPU Cores must be at least 1.');
      setActiveTab('specs');
      return;
    }
    if (!isPositiveNumber(ramGb) || Number(ramGb) <= 0) {
      setValidationError('RAM (GB) must be greater than 0.');
      setActiveTab('specs');
      return;
    }
    if (!isPositiveNumber(storageGb) || Number(storageGb) <= 0) {
      setValidationError('Storage (GB) must be greater than 0.');
      setActiveTab('specs');
      return;
    }

    // Validate installed software child item ports
    for (let i = 0; i < installedSoftware.length; i++) {
      const sw = installedSoftware[i];
      if (sw.port && sw.port.trim() && !isValidPort(sw.port.trim())) {
        setValidationError(`Invalid port "${sw.port}" on software item #${i + 1}. Port must be between 1 and 65535.`);
        setActiveTab('specs');
        return;
      }
    }

    try {
      setIsSaving(true);
      setValidationError(null);

      await onSave({
        name: cleanName,
        assetId,
        assetType,
        infrastructureType,
        cloudProvider,
        businessUnit: cleanBU,
        accountName: cleanAccount,
        environmentId,
        environmentName,
        environmentType,
        applicationName,
        ipAddress: cleanIp || undefined,
        hostname: hostname || `${name.toLowerCase().replace(/[^a-z0-9]/g, '-')}.smartqe.internal`,
        operatingSystem,
        osVersion,
        runtimeStack,
        cpuCores: Number(cpuCores),
        ramGb: Number(ramGb),
        storageGb: Number(storageGb),
        region,
        availabilityZone,
        datacenter,
        rackUnit,
        instanceId,
        instanceType,
        vpcSubnet,
        installedSoftware,
        status,
        ownerTeam,
        responsiblePerson,
        costCenter,
        endOfLifeDate,
        notes
      });
      onClose();
    } catch (err: any) {
      setValidationError(err.message || 'Failed to save asset record');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 dark:bg-black/80 backdrop-blur-sm font-mono animate-fadeIn">
      <div className="bg-[#0b1019] border border-slate-700/80 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#0e1522] to-[#121c2e]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white shadow-md">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white uppercase tracking-wider">
                {editingAsset ? `Edit Asset: ${editingAsset.name}` : 'Create New Inventory Asset'}
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                Enterprise infrastructure, hardware specifications, and application associations.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-200 dark:border-slate-800/80 bg-[#090d14]">
          <button
            type="button"
            onClick={() => setActiveTab('hierarchy')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'hierarchy'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>1. Identity & Hierarchy</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('infra')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'infra'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cloud className="w-3.5 h-3.5" />
            <span>2. Cloud & Hosting</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('specs')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'specs'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>3. Hardware Specs</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('software')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'software'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>4. Installed Software ({installedSoftware.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('lifecycle')}
            className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'lifecycle'
                ? 'border-orange-500 text-white bg-slate-800/60 font-extrabold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>5. Lifecycle & Meta</span>
          </button>
        </div>

        {/* Form Body */}
        <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {validationError && (
            <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{validationError}</span>
            </div>
          )}

          {/* TAB 1: Identity & Enterprise Hierarchy */}
          {activeTab === 'hierarchy' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">
                    Asset Name <span className="text-rose-500">*</span>
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. AWS-EC2-OmniPay-App01"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Asset Tag ID</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={assetId}
                    onChange={(e) => setAssetId(e.target.value)}
                    placeholder="e.g. AST-1001"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-slate-300 text-xs rounded-lg px-3 py-2.5 outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Asset Category</label>
                  <select
                    value={assetType}
                    onChange={(e) => setAssetType(e.target.value as AssetType)}
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                  >
                    <option value="SERVER">Compute Server / VM / Baremetal</option>
                    <option value="DATABASE">Database Instance / Cluster</option>
                    <option value="CLOUD_RESOURCE">Cloud Resource / PaaS / Cluster</option>
                    <option value="NETWORK_COMPONENT">Network Device / Load Balancer</option>
                    <option value="STORAGE">Storage Array / SAN / EBS</option>
                    <option value="SOFTWARE">Application / Microservice</option>
                  </select>
                </div>
              </div>

              {/* Enterprise Hierarchy Card */}
              <div className="bg-[#121a28] p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="text-xs font-bold text-orange-400 uppercase tracking-wider flex items-center gap-2">
                  <Layers className="w-3.5 h-3.5" />
                  <span>Enterprise Hierarchy Drilldown (BU → Account → Environment)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                      Business Unit <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={businessUnit}
                      onChange={(e) => setBusinessUnit(e.target.value)}
                      className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-sans"
                    >
                      {businessUnits.map((bu) => (
                        <option key={bu} value={bu}>{bu}</option>
                      ))}
                      <option value="General Banking">General Banking</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Account / Project</label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={accountName}
                      onChange={(e) => setAccountName(e.target.value)}
                      placeholder="e.g. Retail Core, OmniPay Core"
                      className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-sans"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Target Environment</label>
                    <select
                      value={environmentName || environmentId}
                      onChange={(e) => handleEnvSelect(e.target.value)}
                      className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-sans"
                    >
                      <option value="">-- Unassigned / Standalone --</option>
                      {environments.map((e) => (
                        <option key={e.id} value={e.name}>{e.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Environment Tier / Type</label>
                    <select
                      value={environmentType}
                      onChange={(e) => setEnvironmentType(e.target.value)}
                      className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-sans"
                    >
                      <option value="Development">Development (DEV)</option>
                      <option value="QA / Testing">QA / System Integration (SIT)</option>
                      <option value="UAT / Staging">UAT / Staging</option>
                      <option value="Performance / Stress">Performance / Stress (PERF)</option>
                      <option value="Disaster Recovery (DR)">Disaster Recovery (DR)</option>
                      <option value="Production">Production</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Associated Application</label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={applicationName}
                      onChange={(e) => setApplicationName(e.target.value)}
                      placeholder="e.g. Core Banking Ledger, Payment Hub"
                      className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-sans"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Cloud & Hosting */}
          {activeTab === 'infra' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Infrastructure Hosting</label>
                  <select
                    value={infrastructureType}
                    onChange={(e) => setInfrastructureType(e.target.value as InfrastructureType)}
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                  >
                    <option value="CLOUD">Public / Private Cloud</option>
                    <option value="ON_PREMISES">On-Premises Baremetal / VM</option>
                    <option value="HYBRID">Hybrid Multi-Zone</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Cloud Provider</label>
                  <select
                    value={cloudProvider}
                    onChange={(e) => setCloudProvider(e.target.value as CloudProvider)}
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                  >
                    <option value="AWS">Amazon Web Services (AWS)</option>
                    <option value="Azure">Microsoft Azure</option>
                    <option value="GCP">Google Cloud Platform (GCP)</option>
                    <option value="OCI">Oracle Cloud Infrastructure (OCI)</option>
                    <option value="Alibaba Cloud">Alibaba Cloud</option>
                    <option value="On-Premises">On-Premises Datacenter</option>
                    <option value="Other">Other Custom Provider</option>
                  </select>
                </div>
              </div>

              {infrastructureType === 'ON_PREMISES' || cloudProvider === 'On-Premises' ? (
                <div className="bg-[#121a28] p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                    <Globe className="w-3.5 h-3.5" />
                    <span>On-Premises Datacenter Information</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Datacenter / Facility</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={datacenter}
                        onChange={(e) => setDatacenter(e.target.value)}
                        placeholder="e.g. NJ-DC1 (Piscataway DataCenter)"
                        className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-sans"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Rack / Unit Placement</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={rackUnit}
                        onChange={(e) => setRackUnit(e.target.value)}
                        placeholder="e.g. Rack-04-U18"
                        className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-sans"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-[#121a28] p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                    <Cloud className="w-3.5 h-3.5" />
                    <span>Cloud Region & Instance Metadata</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Region</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={region}
                        onChange={(e) => setRegion(e.target.value)}
                        placeholder="e.g. us-east-1, eastus2"
                        className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Availability Zone</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={availabilityZone}
                        onChange={(e) => setAvailabilityZone(e.target.value)}
                        placeholder="e.g. us-east-1a, Multi-AZ"
                        className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Instance Type / SKU</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={instanceType}
                        onChange={(e) => setInstanceType(e.target.value)}
                        placeholder="e.g. m6i.2xlarge, Standard_D32s_v5"
                        className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Instance / VM ID</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={instanceId}
                        onChange={(e) => setInstanceId(e.target.value)}
                        placeholder="e.g. i-09ab42fc8198de21"
                        className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">VPC Subnet / VNet</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={vpcSubnet}
                        onChange={(e) => setVpcSubnet(e.target.value)}
                        placeholder="e.g. subnet-09f429188a"
                        className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: Hardware Specs & Network */}
          {activeTab === 'specs' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">IP Address</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={ipAddress}
                    onChange={(e) => setIpAddress(e.target.value)}
                    placeholder="e.g. 10.142.18.44"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Hostname / FQDN</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={hostname}
                    onChange={(e) => setHostname(e.target.value)}
                    placeholder="e.g. aws-ec2-payapp-01.internal.smartqe.io"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Operating System</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={operatingSystem}
                    onChange={(e) => setOperatingSystem(e.target.value)}
                    placeholder="e.g. Red Hat Enterprise Linux, Ubuntu, Windows Server"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">OS Version / Kernel</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={osVersion}
                    onChange={(e) => setOsVersion(e.target.value)}
                    placeholder="e.g. 9.2, 22.04 LTS"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Runtime Tech Stack</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={runtimeStack}
                    onChange={(e) => setRuntimeStack(e.target.value)}
                    placeholder="e.g. Java 21 / Spring Boot, Python 3.11"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                  />
                </div>
              </div>

              {/* Hardware Sliders / Inputs */}
              <div className="bg-[#121a28] p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                  <HardDrive className="w-3.5 h-3.5" />
                  <span>Hardware Capacity & Resource Allocations</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                      CPU Cores: <span className="text-white font-bold">{cpuCores} vCPUs</span>
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="number"
                      min={1}
                      max={256}
                      value={cpuCores}
                      onChange={(e) => setCpuCores(Number(e.target.value))}
                      className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                      RAM (Memory): <span className="text-white font-bold">{ramGb} GB</span>
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="number"
                      min={1}
                      max={2048}
                      value={ramGb}
                      onChange={(e) => setRamGb(Number(e.target.value))}
                      className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                      Storage (Disk): <span className="text-white font-bold">{storageGb} GB</span>
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="number"
                      min={10}
                      max={100000}
                      value={storageGb}
                      onChange={(e) => setStorageGb(Number(e.target.value))}
                      className="w-full bg-[#182232] border border-slate-700 text-white text-xs rounded px-2.5 py-2 outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Software & Services Association */}
          {activeTab === 'software' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">Installed Software & Application Services</h3>
                  <p className="text-[11px] text-slate-400 font-sans">
                    Link microservices, middleware, database engines, or gateways running on this asset.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleAddSoftwareItem}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold transition-all shadow"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Software Item</span>
                </button>
              </div>

              <div className="space-y-2.5">
                {installedSoftware.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex flex-wrap items-center gap-2 p-3 rounded-lg bg-[#141b27] border border-slate-200 dark:border-slate-800"
                  >
                    <div className="flex-1 min-w-[140px]">
                      <label className="text-[9px] text-slate-500 font-bold uppercase block mb-0.5">Software / Service</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={item.name}
                        onChange={(e) => handleUpdateSoftwareItem(idx, 'name', e.target.value)}
                        placeholder="e.g. OmniPay Engine"
                        className="w-full bg-[#1a2332] border border-slate-700 text-white text-xs rounded px-2 py-1 outline-none font-sans"
                      />
                    </div>

                    <div className="w-24">
                      <label className="text-[9px] text-slate-500 font-bold uppercase block mb-0.5">Version</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={item.version}
                        onChange={(e) => handleUpdateSoftwareItem(idx, 'version', e.target.value)}
                        placeholder="v1.0"
                        className="w-full bg-[#1a2332] border border-slate-700 text-white text-xs rounded px-2 py-1 outline-none font-mono"
                      />
                    </div>

                    <div className="w-20">
                      <label className="text-[9px] text-slate-500 font-bold uppercase block mb-0.5">Port</label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={item.port || ''}
                        onChange={(e) => handleUpdateSoftwareItem(idx, 'port', e.target.value)}
                        placeholder="8080"
                        className="w-full bg-[#1a2332] border border-slate-700 text-white text-xs rounded px-2 py-1 outline-none font-mono"
                      />
                    </div>

                    <div className="w-28">
                      <label className="text-[9px] text-slate-500 font-bold uppercase block mb-0.5">Status</label>
                      <select
                        value={item.status || 'ACTIVE'}
                        onChange={(e) => handleUpdateSoftwareItem(idx, 'status', e.target.value)}
                        className="w-full bg-[#1a2332] border border-slate-700 text-white text-xs rounded px-2 py-1 outline-none font-sans"
                      >
                        <option value="ACTIVE">ACTIVE</option>
                        <option value="INSTALLED">INSTALLED</option>
                        <option value="UPGRADING">UPGRADING</option>
                        <option value="DEPRECATED">DEPRECATED</option>
                      </select>
                    </div>

                    <div className="pt-3">
                      <button
                        type="button"
                        onClick={() => handleRemoveSoftwareItem(idx)}
                        className="p-1.5 rounded text-rose-400 hover:text-white hover:bg-rose-900/50 transition-colors"
                        title="Remove software"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}

                {installedSoftware.length === 0 && (
                  <div className="p-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-xl bg-slate-950/30">
                    <p className="text-xs text-slate-500">No software items currently attached to this asset.</p>
                    <button
                      type="button"
                      onClick={handleAddSoftwareItem}
                      className="mt-2 text-xs text-orange-400 hover:text-orange-300 font-bold underline"
                    >
                      + Attach first software package
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: Lifecycle & Metadata */}
          {activeTab === 'lifecycle' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Lifecycle Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as AssetStatus)}
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans font-bold"
                  >
                    <option value="ACTIVE">ACTIVE (Operational)</option>
                    <option value="MAINTENANCE">MAINTENANCE (Patching / Upgrade)</option>
                    <option value="INACTIVE">INACTIVE (Standby / Powered Off)</option>
                    <option value="PROVISIONING">PROVISIONING (Under Setup)</option>
                    <option value="RETIRED">RETIRED (Soft Deleted / Historical)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Responsible Owner Team</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={ownerTeam}
                    onChange={(e) => setOwnerTeam(e.target.value)}
                    placeholder="e.g. Platform QE, Payments Squad"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Responsible Lead Engineer</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={responsiblePerson}
                    onChange={(e) => setResponsiblePerson(e.target.value)}
                    placeholder="e.g. Ops Engineer"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-sans"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Cost Center</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={costCenter}
                    onChange={(e) => setCostCenter(e.target.value)}
                    placeholder="e.g. CC-ENG-402"
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">End of Life (EOL) Date</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="date"
                    value={endOfLifeDate}
                    onChange={(e) => setEndOfLifeDate(e.target.value)}
                    className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg px-3 py-2.5 outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 font-bold uppercase block mb-1">Notes & Operational Context</label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Additional context, backup schedule, maintenance windows, or compliance notes..."
                  className="w-full bg-[#141b27] border border-slate-200 dark:border-slate-800 focus:border-orange-500 text-white text-xs rounded-lg p-3 outline-none font-sans"
                />
              </div>
            </div>
          )}

          {/* Modal Footer Controls */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all"
            >
              Cancel
            </button>

            <div className="flex items-center gap-2">
              <ButtonLoader
                type="submit"
                isLoading={isSaving}
                loadingText={editingAsset ? 'Updating Asset...' : 'Creating Asset...'}
                icon={<Save className="w-4 h-4" />}
                className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white text-xs font-bold transition-all shadow-[0_0_12px_rgba(249,115,22,0.4)] disabled:opacity-50"
              >
                {editingAsset ? 'Update Asset' : 'Create Asset'}
              </ButtonLoader>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
