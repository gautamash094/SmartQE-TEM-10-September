import React, { useState, useMemo } from 'react';
import {
  X,
  Download,
  FileText,
  FileSpreadsheet,
  FileType,
  FileCode,
  CheckSquare,
  Square,
  Filter,
  Globe,
  Loader2,
  Check,
  Search
} from 'lucide-react';
import { ExportScope, ExportFormat } from '../../services/topologyExportService';

interface EnvironmentOption {
  id: string;
  name: string;
  type?: string;
  status?: string;
}

interface TopologyExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  environments: EnvironmentOption[];
  hasActiveFilters: boolean;
  onConfirmExport: (options: {
    scope: ExportScope;
    format: ExportFormat;
    selectedEnvironmentIds: string[];
  }) => Promise<void>;
}

export const TopologyExportModal: React.FC<TopologyExportModalProps> = ({
  isOpen,
  onClose,
  environments,
  hasActiveFilters,
  onConfirmExport
}) => {
  const [scope, setScope] = useState<ExportScope>('ALL');
  const [format, setFormat] = useState<ExportFormat>('XLSX');
  const [selectedEnvIds, setSelectedEnvIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isExporting, setIsExporting] = useState<boolean>(false);

  // Filtered environment list for selection
  const filteredEnvironments = useMemo(() => {
    if (!searchQuery.trim()) return environments;
    const q = searchQuery.toLowerCase();
    return environments.filter(
      (e) => e.name.toLowerCase().includes(q) || e.id.toLowerCase().includes(q) || (e.type && e.type.toLowerCase().includes(q))
    );
  }, [environments, searchQuery]);

  if (!isOpen) return null;

  const handleToggleEnv = (envId: string) => {
    setSelectedEnvIds((prev) =>
      prev.includes(envId) ? prev.filter((id) => id !== envId) : [...prev, envId]
    );
  };

  const handleSelectAll = () => {
    setSelectedEnvIds(environments.map((e) => e.id));
  };

  const handleClearSelection = () => {
    setSelectedEnvIds([]);
  };

  const handleDownload = async () => {
    if (scope === 'SELECTED' && selectedEnvIds.length === 0) {
      return;
    }
    try {
      setIsExporting(true);
      await onConfirmExport({
        scope,
        format,
        selectedEnvironmentIds: selectedEnvIds
      });
      onClose();
    } catch (e) {
      // Handled in page toast
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 font-mono">
      <div className="bg-[#0b101d] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800/80 bg-[#070b14]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-orange-500/10 border border-orange-500/30 text-orange-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white uppercase tracking-wider">
                Export Environment Topology
              </h2>
              <p className="text-xs text-slate-400">
                Single Source of Truth: Environment Details module
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isExporting}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Section 1: Scope Selection */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              1. Select Export Scope
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* All Environments */}
              <button
                type="button"
                onClick={() => setScope('ALL')}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                  scope === 'ALL'
                    ? 'bg-orange-500/10 border-orange-500 text-white shadow-[0_0_15px_rgba(249,115,22,0.2)]'
                    : 'bg-[#0f172a]/60 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <Globe className="w-4 h-4 text-cyan-400" />
                  {scope === 'ALL' && <Check className="w-4 h-4 text-orange-400" />}
                </div>
                <span className="text-xs font-bold block text-white">All Environments</span>
                <span className="text-[10px] text-slate-400 mt-0.5">
                  Complete fleet ({environments.length} Envs)
                </span>
              </button>

              {/* Filtered Scope */}
              <button
                type="button"
                onClick={() => setScope('FILTERED')}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                  scope === 'FILTERED'
                    ? 'bg-orange-500/10 border-orange-500 text-white shadow-[0_0_15px_rgba(249,115,22,0.2)]'
                    : 'bg-[#0f172a]/60 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <Filter className="w-4 h-4 text-amber-400" />
                  {scope === 'FILTERED' && <Check className="w-4 h-4 text-orange-400" />}
                </div>
                <span className="text-xs font-bold block text-white">Filtered View</span>
                <span className="text-[10px] text-slate-400 mt-0.5">
                  {hasActiveFilters ? 'Active filters applied' : 'Current filter subset'}
                </span>
              </button>

              {/* Selected Environments */}
              <button
                type="button"
                onClick={() => setScope('SELECTED')}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                  scope === 'SELECTED'
                    ? 'bg-orange-500/10 border-orange-500 text-white shadow-[0_0_15px_rgba(249,115,22,0.2)]'
                    : 'bg-[#0f172a]/60 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <CheckSquare className="w-4 h-4 text-emerald-400" />
                  {scope === 'SELECTED' && <Check className="w-4 h-4 text-orange-400" />}
                </div>
                <span className="text-xs font-bold block text-white">Selected Environments</span>
                <span className="text-[10px] text-slate-400 mt-0.5">
                  {selectedEnvIds.length} of {environments.length} selected
                </span>
              </button>
            </div>
          </div>

          {/* Section 2: Environment Selector List (When Selected Scope is Active or Expandable) */}
          {scope === 'SELECTED' && (
            <div className="bg-[#080d1a] border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3 animate-in fade-in duration-200">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-300">
                  Select Environments ({selectedEnvIds.length} selected)
                </span>
                <div className="flex items-center gap-2 text-[11px]">
                  <button
                    type="button"
                    onClick={handleSelectAll}
                    className="text-orange-400 hover:text-orange-300 hover:underline font-bold"
                  >
                    Select All
                  </button>
                  <span className="text-slate-600">|</span>
                  <button
                    type="button"
                    onClick={handleClearSelection}
                    className="text-slate-400 hover:text-slate-200 hover:underline"
                  >
                    Clear Selection
                  </button>
                </div>
              </div>

              {/* Search Bar inside selector */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  placeholder="Search environments by name or tier..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#0f172a] border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500/50"
                />
              </div>

              {/* Checkboxes grid */}
              <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
                {filteredEnvironments.map((env) => {
                  const isChecked = selectedEnvIds.includes(env.id);
                  return (
                    <div
                      key={env.id}
                      onClick={() => handleToggleEnv(env.id)}
                      className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition-colors ${
                        isChecked
                          ? 'bg-orange-500/10 border border-orange-500/40 text-white'
                          : 'bg-[#0f172a]/50 border border-slate-200 dark:border-slate-800/60 text-slate-300 hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-orange-400 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-500 shrink-0" />
                        )}
                        <span className="text-xs font-bold">{env.name}</span>
                        {env.type && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                            {env.type}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">{env.id}</span>
                    </div>
                  );
                })}
                {filteredEnvironments.length === 0 && (
                  <div className="text-center py-4 text-xs text-slate-500">
                    No environments match "{searchQuery}"
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Section 3: Export Format Selection */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              2. Select File Format
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {/* CSV */}
              <button
                type="button"
                onClick={() => setFormat('CSV')}
                className={`p-3 rounded-xl border text-center flex flex-col items-center gap-1.5 transition-all ${
                  format === 'CSV'
                    ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                    : 'bg-[#0f172a]/60 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <FileCode className="w-5 h-5" />
                <span className="text-xs font-bold">CSV</span>
                <span className="text-[9px] text-slate-500">Plain text data</span>
              </button>

              {/* XLSX */}
              <button
                type="button"
                onClick={() => setFormat('XLSX')}
                className={`p-3 rounded-xl border text-center flex flex-col items-center gap-1.5 transition-all ${
                  format === 'XLSX'
                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.25)]'
                    : 'bg-[#0f172a]/60 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <FileSpreadsheet className="w-5 h-5" />
                <span className="text-xs font-bold">XLSX</span>
                <span className="text-[9px] text-slate-500">Multi-sheet Excel</span>
              </button>

              {/* PDF */}
              <button
                type="button"
                onClick={() => setFormat('PDF')}
                className={`p-3 rounded-xl border text-center flex flex-col items-center gap-1.5 transition-all ${
                  format === 'PDF'
                    ? 'bg-red-500/10 border-red-500 text-red-400 shadow-[0_0_12px_rgba(239,68,68,0.25)]'
                    : 'bg-[#0f172a]/60 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <FileText className="w-5 h-5" />
                <span className="text-xs font-bold">PDF</span>
                <span className="text-[9px] text-slate-500">Visual report</span>
              </button>

              {/* DOCX */}
              <button
                type="button"
                onClick={() => setFormat('DOCX')}
                className={`p-3 rounded-xl border text-center flex flex-col items-center gap-1.5 transition-all ${
                  format === 'DOCX'
                    ? 'bg-blue-500/10 border-blue-500 text-blue-400 shadow-[0_0_12px_rgba(59,130,246,0.25)]'
                    : 'bg-[#0f172a]/60 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <FileType className="w-5 h-5" />
                <span className="text-xs font-bold">DOCX</span>
                <span className="text-[9px] text-slate-500">Word document</span>
              </button>
            </div>
          </div>

          {/* Loading Banner */}
          {isExporting && (
            <div className="p-3.5 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center gap-3 text-orange-400 animate-pulse">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-xs font-bold">Preparing Environment Topology export...</span>
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-slate-800/80 bg-[#070b14]">
          <button
            type="button"
            onClick={onClose}
            disabled={isExporting}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleDownload}
            disabled={isExporting || (scope === 'SELECTED' && selectedEnvIds.length === 0)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white transition-all ${
              scope === 'SELECTED' && selectedEnvIds.length === 0
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 shadow-[0_0_15px_rgba(249,115,22,0.4)]'
            }`}
          >
            {isExporting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Exporting...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download Export</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
