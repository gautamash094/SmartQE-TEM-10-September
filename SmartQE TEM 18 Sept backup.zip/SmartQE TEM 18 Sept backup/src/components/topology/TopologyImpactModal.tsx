import React from 'react';
import {
  X,
  AlertOctagon,
  Activity,
  Server,
  Layers,
  Database,
  Globe,
  CheckCircle2,
  FileDown,
  Sparkles
} from 'lucide-react';
import { ImpactAnalysisResult, TopologyNode } from '../../types/topology';

interface TopologyImpactModalProps {
  isOpen: boolean;
  onClose: () => void;
  impactResult: ImpactAnalysisResult | null;
  onFocusImpactOnCanvas?: (impactResult: ImpactAnalysisResult) => void;
}

export const TopologyImpactModal: React.FC<TopologyImpactModalProps> = ({
  isOpen,
  onClose,
  impactResult,
  onFocusImpactOnCanvas
}) => {
  if (!isOpen || !impactResult) return null;

  const target = impactResult.target_node;

  const getScoreColor = (level: string) => {
    switch (level) {
      case 'CRITICAL':
        return 'text-red-500 bg-red-500/10 border-red-500/40 ring-red-500/20';
      case 'HIGH':
        return 'text-orange-500 bg-orange-500/10 border-orange-500/40 ring-orange-500/20';
      case 'MEDIUM':
        return 'text-amber-500 bg-amber-500/10 border-amber-500/40 ring-amber-500/20';
      default:
        return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/40 ring-emerald-500/20';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Modal Card */}
      <div className="relative w-full max-w-2xl bg-[#090e18] border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 font-mono text-slate-200 z-10 animate-in zoom-in-95 duration-150">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white bg-slate-800 p-1.5 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
            <AlertOctagon className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-red-400 font-bold uppercase tracking-widest block">
              BLAST RADIUS SIMULATION
            </span>
            <h2 className="text-base font-bold text-white">Impact Analysis: {target.name}</h2>
          </div>
        </div>

        {/* Blast Radius Score & Level Card */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
          <div
            className={`p-3.5 rounded-xl border ring-1 flex flex-col justify-between ${getScoreColor(
              impactResult.impact_level
            )}`}
          >
            <span className="text-[10px] uppercase font-bold tracking-wider opacity-80">
              IMPACT RATING
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-black">{impactResult.impact_score}</span>
              <span className="text-xs font-bold">/ 100 ({impactResult.impact_level})</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
              AFFECTED ENVS
            </span>
            <div className="flex items-center gap-2 mt-1">
              <Globe className="w-4 h-4 text-cyan-400" />
              <span className="text-2xl font-bold text-white">
                {impactResult.affected_environments.length}
              </span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
              AFFECTED APPS & SVCS
            </span>
            <div className="flex items-center gap-2 mt-1">
              <Layers className="w-4 h-4 text-orange-400" />
              <span className="text-2xl font-bold text-white">
                {impactResult.affected_applications.length + impactResult.affected_services.length}
              </span>
            </div>
          </div>
        </div>

        {/* Affected Entities Lists */}
        <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
          {/* Environments */}
          {impactResult.affected_environments.length > 0 && (
            <div className="p-3 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1.5">
                Impacted Environments:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {impactResult.affected_environments.map((env) => (
                  <span
                    key={env}
                    className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-[11px]"
                  >
                    {env}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Applications */}
          {impactResult.affected_applications.length > 0 && (
            <div className="p-3 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1.5">
                Impacted Applications / Services:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {impactResult.affected_applications.map((app) => (
                  <span
                    key={app}
                    className="px-2 py-0.5 rounded bg-orange-500/10 text-orange-300 border border-orange-500/30 text-[11px]"
                  >
                    {app}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Upstream & Downstream Components */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-lg bg-[#0c121e] border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block font-bold mb-1">
                UPSTREAM CALLERS: {impactResult.upstream_nodes.length}
              </span>
              <p className="text-[11px] text-slate-300">
                {impactResult.upstream_nodes.map((n) => n.name).join(', ') || 'None'}
              </p>
            </div>

            <div className="p-2.5 rounded-lg bg-[#0c121e] border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block font-bold mb-1">
                DOWNSTREAM TARGETS: {impactResult.downstream_nodes.length}
              </span>
              <p className="text-[11px] text-slate-300">
                {impactResult.downstream_nodes.map((n) => n.name).join(', ') || 'None'}
              </p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between gap-3 pt-4 mt-4 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors"
          >
            Close
          </button>

          <button
            type="button"
            onClick={() => {
              if (onFocusImpactOnCanvas) onFocusImpactOnCanvas(impactResult);
              onClose();
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white text-xs font-bold transition-all shadow-[0_0_12px_rgba(249,115,22,0.4)]"
          >
            <Sparkles className="w-4 h-4" />
            <span>Highlight Affected Nodes on Canvas</span>
          </button>
        </div>
      </div>
    </div>
  );
};
