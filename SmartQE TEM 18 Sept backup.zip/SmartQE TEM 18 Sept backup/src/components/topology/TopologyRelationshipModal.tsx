import React, { useState, useEffect } from 'react';
import { X, GitFork, Check, AlertCircle } from 'lucide-react';
import {
  TopologyNode,
  TopologyRelationshipType
} from '../../types/topology';
import { CustomRelationshipPayload } from '../../services/topologyService';
import { isValidPort } from '../../utils/validationUtils';

interface TopologyRelationshipModalProps {
  isOpen: boolean;
  onClose: () => void;
  nodes: TopologyNode[];
  initialSourceNode?: TopologyNode | null;
  onSaveRelationship: (payload: CustomRelationshipPayload) => Promise<void>;
}

const RELATIONSHIP_TYPES: { type: TopologyRelationshipType; label: string; desc: string }[] = [
  { type: 'CALLS', label: 'Calls API / Service', desc: 'Direct synchronous or asynchronous API invocation' },
  { type: 'USES_DATABASE', label: 'Uses Database', desc: 'Direct database read/write queries' },
  { type: 'DEPENDS_ON', label: 'Depends On', desc: 'Strict functional dependency' },
  { type: 'CONNECTS_TO', label: 'Connects To', desc: 'Network / gateway connectivity' },
  { type: 'HOSTED_ON', label: 'Hosted On', desc: 'Hosted on physical or virtual compute' },
  { type: 'DEPLOYED_ON', label: 'Deployed On', desc: 'Application runtime container/cluster deployment' },
  { type: 'SENDS_DATA_TO', label: 'Sends Data To', desc: 'Message queue, event stream or ETL pipeline' },
  { type: 'PART_OF', label: 'Part Of', desc: 'Subsystem or environment membership' },
];

export const TopologyRelationshipModal: React.FC<TopologyRelationshipModalProps> = ({
  isOpen,
  onClose,
  nodes,
  initialSourceNode,
  onSaveRelationship
}) => {
  const [sourceId, setSourceId] = useState<string>('');
  const [targetId, setTargetId] = useState<string>('');
  const [relType, setRelType] = useState<TopologyRelationshipType>('CALLS');
  const [port, setPort] = useState<string>('443');
  const [protocol, setProtocol] = useState<string>('HTTPS');
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      setError('');
      if (initialSourceNode) {
        setSourceId(initialSourceNode.id);
      } else if (nodes.length > 0) {
        setSourceId(nodes[0].id);
      }
      if (nodes.length > 1) {
        setTargetId(nodes.find((n) => n.id !== (initialSourceNode?.id || nodes[0].id))?.id || nodes[1].id);
      }
    }
  }, [isOpen, initialSourceNode, nodes]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceId || !targetId) {
      setError('Both source and target components must be selected.');
      return;
    }
    if (sourceId === targetId) {
      setError('Source and target cannot be the same component.');
      return;
    }

    if (port && port.trim() && !isValidPort(port.trim())) {
      setError('Port must be a valid number between 1 and 65535.');
      return;
    }

    const sourceNode = nodes.find((n) => n.id === sourceId);
    const targetNode = nodes.find((n) => n.id === targetId);

    if (!sourceNode || !targetNode) {
      setError('Invalid components selected.');
      return;
    }

    try {
      setIsSubmitting(true);
      setError('');
      await onSaveRelationship({
        source_id: sourceNode.id,
        source_type: sourceNode.type,
        source_name: sourceNode.name,
        target_id: targetNode.id,
        target_type: targetNode.type,
        target_name: targetNode.name,
        relationship_type: relType,
        environment_id: sourceNode.environment_id || targetNode.environment_id,
        environment_name: sourceNode.environment_name || targetNode.environment_name,
        port: port || undefined,
        protocol: protocol || undefined,
        notes: notes || undefined
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save relationship');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Modal Card */}
      <div className="relative w-full max-w-lg bg-[#0c121e] border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 font-mono text-slate-200 z-10 animate-in zoom-in-95 duration-150">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white bg-slate-800 p-1.5 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="w-9 h-9 rounded-xl bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-400">
            <GitFork className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-orange-400 font-bold uppercase tracking-widest block">
              RELATIONSHIP GOVERNANCE
            </span>
            <h2 className="text-sm font-bold text-white">Create Topology Relationship</h2>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mt-3 p-2.5 rounded-lg bg-red-950/40 border border-red-500/50 flex items-center gap-2 text-xs text-red-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Form Body */}
        <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          {/* Source Node */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
              SOURCE COMPONENT *
            </label>
            <select
              value={sourceId}
              onChange={(e) => setSourceId(e.target.value)}
              className="w-full bg-[#141c2c] border border-slate-700/80 rounded-lg px-3 py-2 text-white font-bold focus:outline-none focus:border-orange-500"
            >
              {nodes.map((n) => (
                <option key={n.id} value={n.id} className="bg-[#0f172a]">
                  [{n.type}] {n.name}
                </option>
              ))}
            </select>
          </div>

          {/* Relationship Type */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
              RELATIONSHIP TYPE *
            </label>
            <select
              value={relType}
              onChange={(e) => setRelType(e.target.value as TopologyRelationshipType)}
              className="w-full bg-[#141c2c] border border-slate-700/80 rounded-lg px-3 py-2 text-orange-400 font-bold focus:outline-none focus:border-orange-500"
            >
              {RELATIONSHIP_TYPES.map((rt) => (
                <option key={rt.type} value={rt.type} className="bg-[#0f172a] text-white">
                  {rt.label} ({rt.type})
                </option>
              ))}
            </select>
          </div>

          {/* Target Node */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
              TARGET COMPONENT *
            </label>
            <select
              value={targetId}
              onChange={(e) => setTargetId(e.target.value)}
              className="w-full bg-[#141c2c] border border-slate-700/80 rounded-lg px-3 py-2 text-white font-bold focus:outline-none focus:border-orange-500"
            >
              {nodes.map((n) => (
                <option key={n.id} value={n.id} className="bg-[#0f172a]">
                  [{n.type}] {n.name}
                </option>
              ))}
            </select>
          </div>

          {/* Port & Protocol */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">PORT</label>
              <input autoComplete="off" data-lpignore="true"
                type="text"
                placeholder="e.g. 443, 5432, 8080"
                value={port}
                onChange={(e) => setPort(e.target.value)}
                className="w-full bg-[#141c2c] border border-slate-700/80 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                PROTOCOL
              </label>
              <input autoComplete="off" data-lpignore="true"
                type="text"
                placeholder="e.g. HTTPS, gRPC, JDBC"
                value={protocol}
                onChange={(e) => setProtocol(e.target.value)}
                className="w-full bg-[#141c2c] border border-slate-700/80 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
              DOCUMENTATION / NOTES
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Ingress gateway route with SSL termination"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#141c2c] border border-slate-700/80 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white text-xs font-bold transition-all shadow-[0_0_12px_rgba(249,115,22,0.4)] disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving...' : 'Save Relationship'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
