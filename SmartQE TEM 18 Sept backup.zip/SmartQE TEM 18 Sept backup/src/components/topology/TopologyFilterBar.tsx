import React from 'react';
import { Search, X, AlertTriangle, Check, RefreshCw } from 'lucide-react';
import { TopologyFilterState } from '../../types/topology';

interface TopologyFilterBarProps {
  filters: TopologyFilterState;
  onFilterChange: (filters: TopologyFilterState) => void;
  onResetFilters: () => void;
  businessUnits: string[];
  cloudProviders: string[];
}

const ALL_NODE_TYPES = [
  { label: 'Environments', value: 'ENVIRONMENT' },
  { label: 'Applications', value: 'APPLICATION' },
  { label: 'Servers', value: 'SERVER' },
  { label: 'Software/Services', value: 'SOFTWARE' },
  { label: 'Databases', value: 'DATABASE' },
];

export const TopologyFilterBar: React.FC<TopologyFilterBarProps> = ({
  filters,
  onFilterChange,
  onResetFilters,
  businessUnits,
  cloudProviders
}) => {
  const toggleNodeType = (typeVal: string) => {
    const current = new Set(filters.nodeTypes);
    if (current.has(typeVal)) {
      current.delete(typeVal);
    } else {
      current.add(typeVal);
    }
    onFilterChange({
      ...filters,
      nodeTypes: Array.from(current)
    });
  };

  return (
    <div className="bg-[#0b101b] border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 space-y-3 font-mono text-xs animate-in fade-in duration-150">
      {/* Top Row: Search input + Business Unit + Status + Cloud */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Search Bar */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
          <input autoComplete="off" data-lpignore="true"
            type="text"
            placeholder="Search component, IP, host..."
            value={filters.searchQuery}
            onChange={(e) => onFilterChange({ ...filters, searchQuery: e.target.value })}
            className="w-full bg-[#121a2a] border border-slate-700/80 rounded-lg pl-8 pr-7 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500"
          />
          {filters.searchQuery && (
            <button
              onClick={() => onFilterChange({ ...filters, searchQuery: '' })}
              className="absolute right-2.5 top-2.5 text-slate-500 hover:text-white"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Business Unit Selector */}
        <div>
          <select
            value={filters.businessUnit}
            onChange={(e) => onFilterChange({ ...filters, businessUnit: e.target.value })}
            className="w-full bg-[#121a2a] border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 font-bold focus:outline-none focus:border-orange-500 cursor-pointer"
          >
            <option value="ALL">All Business Units</option>
            {businessUnits.map((bu) => (
              <option key={bu} value={bu}>
                {bu}
              </option>
            ))}
          </select>
        </div>

        {/* Health / Status Filter */}
        <div>
          <select
            value={filters.status}
            onChange={(e) => onFilterChange({ ...filters, status: e.target.value })}
            className="w-full bg-[#121a2a] border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 font-bold focus:outline-none focus:border-orange-500 cursor-pointer"
          >
            <option value="ALL">All Health Statuses</option>
            <option value="HEALTHY">Healthy / Available Only</option>
            <option value="WARNING">Warning / Degraded</option>
            <option value="CRITICAL">Critical / Unavailable</option>
            <option value="MAINTENANCE">Maintenance</option>
          </select>
        </div>

        {/* Cloud Provider Filter */}
        <div>
          <select
            value={filters.cloudProvider}
            onChange={(e) => onFilterChange({ ...filters, cloudProvider: e.target.value })}
            className="w-full bg-[#121a2a] border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 font-bold focus:outline-none focus:border-orange-500 cursor-pointer"
          >
            <option value="ALL">All Cloud / On-Prem</option>
            {cloudProviders.map((cp) => (
              <option key={cp} value={cp}>
                {cp}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Bottom Row: Node Type Chips + Active Incidents Toggle + Clear Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200 dark:border-slate-800/80">
        {/* Node Type Multi-select Chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] text-slate-500 font-bold uppercase mr-1">Types:</span>
          {ALL_NODE_TYPES.map((nt) => {
            const isSelected = filters.nodeTypes.includes(nt.value);
            return (
              <button
                key={nt.value}
                type="button"
                onClick={() => toggleNodeType(nt.value)}
                className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border transition-all ${
                  isSelected
                    ? 'bg-orange-500/20 text-orange-400 border-orange-500/60 shadow-sm'
                    : 'bg-[#121a2a] text-slate-400 border-slate-200 dark:border-slate-800 hover:text-slate-200'
                }`}
              >
                {isSelected && <Check className="w-2.5 h-2.5" />}
                <span>{nt.label}</span>
              </button>
            );
          })}
        </div>

        {/* Incidents Toggle & Clear Button */}
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer text-[10px] text-slate-300 select-none">
            <input
              type="checkbox"
              checked={filters.hasActiveIncidentsOnly}
              onChange={(e) =>
                onFilterChange({ ...filters, hasActiveIncidentsOnly: e.target.checked })
              }
              className="rounded border-slate-700 text-orange-500 focus:ring-0 bg-[#121a2a]"
            />
            <span className="flex items-center gap-1 text-red-400 font-bold">
              <AlertTriangle className="w-3 h-3" />
              <span>Active Incidents Only</span>
            </span>
          </label>

          <button
            type="button"
            onClick={onResetFilters}
            className="flex items-center gap-1 text-[10px] text-slate-400 hover:text-orange-400 font-bold hover:underline ml-2"
          >
            <RefreshCw className="w-2.5 h-2.5" />
            <span>Reset Filters</span>
          </button>
        </div>
      </div>
    </div>
  );
};
