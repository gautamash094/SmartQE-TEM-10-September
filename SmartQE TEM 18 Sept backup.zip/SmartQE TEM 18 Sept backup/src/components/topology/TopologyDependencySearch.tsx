import React, { useState, useMemo } from 'react';
import { Search, GitFork, ArrowRight, ArrowLeft, ArrowUpRight, ArrowDownRight, Layers } from 'lucide-react';
import { TopologyNode, TopologyEdge } from '../../types/topology';

interface TopologyDependencySearchProps {
  nodes: TopologyNode[];
  edges: TopologyEdge[];
  onSelectNode: (node: TopologyNode) => void;
}

export const TopologyDependencySearch: React.FC<TopologyDependencySearchProps> = ({
  nodes,
  edges,
  onSelectNode
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('');

  const nodeMap = useMemo(() => new Map<string, TopologyNode>(nodes.map((n) => [n.id, n])), [nodes]);

  const dependencyInfo = useMemo(() => {
    if (!selectedNodeId) return null;
    const target = nodeMap.get(selectedNodeId);
    if (!target) return null;

    // Upstream (who calls / uses target)
    const incomingEdges = edges.filter((e) => e.target === selectedNodeId);
    const upstreamNodes = incomingEdges.map((e) => ({
      node: nodeMap.get(e.source) || { id: e.source, name: e.source, type: 'UNKNOWN', status: 'HEALTHY' },
      edge: e
    }));

    // Downstream (who target calls / uses)
    const outgoingEdges = edges.filter((e) => e.source === selectedNodeId);
    const downstreamNodes = outgoingEdges.map((e) => ({
      node: nodeMap.get(e.target) || { id: e.target, name: e.target, type: 'UNKNOWN', status: 'HEALTHY' },
      edge: e
    }));

    return {
      target,
      upstreamNodes,
      downstreamNodes
    };
  }, [selectedNodeId, nodeMap, edges]);

  return (
    <div className="bg-[#0b101b] border border-slate-200 dark:border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-200 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <GitFork className="w-4 h-4 text-orange-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            Dependency Traversal Explorer
          </h3>
        </div>
        <span className="text-[10px] text-slate-500">
          Where it is used → What it depends on → What depends on it
        </span>
      </div>

      {/* Component Selector */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
          <select
            value={selectedNodeId}
            onChange={(e) => setSelectedNodeId(e.target.value)}
            className="w-full bg-[#121a2a] border border-slate-700/80 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white font-bold focus:outline-none focus:border-orange-500 cursor-pointer"
          >
            <option value="">Select a component to trace dependencies...</option>
            {nodes.map((n) => (
              <option key={n.id} value={n.id} className="bg-[#0f172a]">
                [{n.type}] {n.name} ({n.environment_name || 'Global'})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Traversal Results Visual Card */}
      {dependencyInfo && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
          {/* 1. What depends on it / Where it is used */}
          <div className="p-3 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800 space-y-2">
            <span className="text-[10px] text-cyan-400 font-bold uppercase flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" />
              <span>Used By / Callers ({dependencyInfo.upstreamNodes.length})</span>
            </span>

            {dependencyInfo.upstreamNodes.length === 0 ? (
              <p className="text-[11px] text-slate-500 italic">No incoming callers found.</p>
            ) : (
              <div className="space-y-1">
                {dependencyInfo.upstreamNodes.map(({ node, edge }) => (
                  <div
                    key={edge.id}
                    onClick={() => onSelectNode(node as TopologyNode)}
                    className="p-1.5 rounded bg-[#090d14] border border-slate-200 dark:border-slate-800 hover:border-cyan-500/50 cursor-pointer text-[11px] flex items-center justify-between"
                  >
                    <span className="text-white font-bold truncate max-w-[130px]">{node.name}</span>
                    <span className="text-[9px] text-cyan-400">{edge.relationship_type}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 2. Target Component */}
          <div className="p-3 rounded-xl bg-orange-500/10 border border-orange-500/40 space-y-2 text-center flex flex-col justify-center items-center">
            <span className="text-[10px] text-orange-400 font-bold uppercase">TARGET COMPONENT</span>
            <h4 className="text-sm font-bold text-white">{dependencyInfo.target.name}</h4>
            <span className="text-[10px] px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 font-bold">
              {dependencyInfo.target.type}
            </span>
          </div>

          {/* 3. What it depends on */}
          <div className="p-3 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800 space-y-2">
            <span className="text-[10px] text-orange-400 font-bold uppercase flex items-center gap-1">
              <ArrowDownRight className="w-3 h-3" />
              <span>Depends On / Calls ({dependencyInfo.downstreamNodes.length})</span>
            </span>

            {dependencyInfo.downstreamNodes.length === 0 ? (
              <p className="text-[11px] text-slate-500 italic">No outgoing dependencies found.</p>
            ) : (
              <div className="space-y-1">
                {dependencyInfo.downstreamNodes.map(({ node, edge }) => (
                  <div
                    key={edge.id}
                    onClick={() => onSelectNode(node as TopologyNode)}
                    className="p-1.5 rounded bg-[#090d14] border border-slate-200 dark:border-slate-800 hover:border-orange-500/50 cursor-pointer text-[11px] flex items-center justify-between"
                  >
                    <span className="text-white font-bold truncate max-w-[130px]">{node.name}</span>
                    <span className="text-[9px] text-orange-400">{edge.relationship_type}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
