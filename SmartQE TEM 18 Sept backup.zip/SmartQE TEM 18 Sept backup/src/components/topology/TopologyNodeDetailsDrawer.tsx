import React from 'react';
import {
  X,
  Server,
  Layers,
  Cpu,
  Database,
  Code2,
  Cloud,
  Network,
  HardDrive,
  Globe,
  AlertTriangle,
  Activity,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  ExternalLink,
  ShieldAlert,
  Info
} from 'lucide-react';
import { TopologyNode, TopologyEdge } from '../../types/topology';

interface TopologyNodeDetailsDrawerProps {
  node: TopologyNode | null;
  edges: TopologyEdge[];
  nodesMap: Map<string, TopologyNode>;
  onClose: () => void;
  onSimulateImpact: (node: TopologyNode) => void;
  onAddRelationship: (node: TopologyNode) => void;
}

const getNodeIcon = (type: string) => {
  switch (type.toUpperCase()) {
    case 'ENVIRONMENT':
      return Globe;
    case 'APPLICATION':
    case 'MICROSERVICE':
      return Layers;
    case 'SERVER':
      return Server;
    case 'DATABASE':
      return Database;
    case 'SOFTWARE':
    case 'SERVICE':
      return Code2;
    case 'CLOUD_RESOURCE':
      return Cloud;
    case 'NETWORK_COMPONENT':
    case 'GATEWAY':
      return Network;
    case 'STORAGE':
      return HardDrive;
    default:
      return Cpu;
  }
};

export const TopologyNodeDetailsDrawer: React.FC<TopologyNodeDetailsDrawerProps> = ({
  node,
  edges,
  nodesMap,
  onClose,
  onSimulateImpact,
  onAddRelationship
}) => {
  if (!node) return null;

  const Icon = getNodeIcon(node.type);

  // Incoming (Upstream) Callers
  const incomingEdges = edges.filter((e) => e.target === node.id);
  // Outgoing (Downstream) Callees / Dependencies
  const outgoingEdges = edges.filter((e) => e.source === node.id);

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-96 max-w-full bg-[#0a0f18] border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col font-mono text-slate-200 animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-[#0f1728]">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="w-8 h-8 rounded-lg bg-orange-500/20 border border-orange-500/40 text-orange-400 flex items-center justify-center shrink-0">
            <Icon className="w-4 h-4" />
          </div>
          <div className="overflow-hidden">
            <h3 className="text-sm font-bold text-white truncate" title={node.name}>
              {node.name}
            </h3>
            <span className="text-[10px] text-orange-400 uppercase tracking-widest block font-semibold">
              {node.sub_type || node.type}
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          aria-label="Close panel"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Content Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        {/* Active Incident Warning Alert (if present) */}
        {(node.active_incidents_count || 0) > 0 && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/50 flex items-start gap-2.5 text-red-300">
            <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-xs text-red-400">
                {node.active_incidents_count} Active Incident(s) Logged
              </p>
              <p className="text-[11px] text-red-300/80 mt-0.5">
                Severities: {node.active_incident_severities?.join(', ') || 'CRITICAL'}
              </p>
            </div>
          </div>
        )}

        {/* Primary Metadata Table */}
        <div className="bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-3 space-y-2">
          <h4 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Info className="w-3 h-3 text-orange-400" />
            <span>Specifications & Context</span>
          </h4>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div>
              <span className="text-slate-500 text-[10px] block">HEALTH STATUS:</span>
              <span
                className={`font-bold ${
                  node.status === 'HEALTHY'
                    ? 'text-emerald-400'
                    : node.status === 'WARNING'
                    ? 'text-amber-400'
                    : 'text-red-400'
                }`}
              >
                {node.status}
              </span>
            </div>

            <div>
              <span className="text-slate-500 text-[10px] block">ENVIRONMENT:</span>
              <span className="text-white font-bold truncate block">
                {node.environment_name || 'Global'}
              </span>
            </div>

            <div>
              <span className="text-slate-500 text-[10px] block">BUSINESS UNIT:</span>
              <span className="text-white truncate block">{node.business_unit || 'Enterprise'}</span>
            </div>

            <div>
              <span className="text-slate-500 text-[10px] block">CLOUD / REGION:</span>
              <span className="text-white truncate block">
                {node.cloud_provider ? `${node.cloud_provider} (${node.region || 'local'})` : 'On-Premises'}
              </span>
            </div>

            {node.ip_address && (
              <div>
                <span className="text-slate-500 text-[10px] block">IP ADDRESS:</span>
                <span className="text-cyan-400 font-mono font-bold">{node.ip_address}</span>
              </div>
            )}

            {node.hostname && (
              <div>
                <span className="text-slate-500 text-[10px] block">HOSTNAME:</span>
                <span className="text-slate-300 truncate block">{node.hostname}</span>
              </div>
            )}

            {node.specs && (
              <div className="col-span-2">
                <span className="text-slate-500 text-[10px] block">HARDWARE SPECS:</span>
                <span className="text-orange-300 font-bold">{node.specs}</span>
              </div>
            )}
          </div>
        </div>

        {/* Upstream Dependencies (Callers) */}
        <div className="bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3 text-cyan-400" />
              <span>Upstream Callers ({incomingEdges.length})</span>
            </h4>
          </div>

          {incomingEdges.length === 0 ? (
            <p className="text-[11px] text-slate-500 italic">No incoming callers connected.</p>
          ) : (
            <div className="space-y-1.5">
              {incomingEdges.map((edge) => {
                const srcNode = nodesMap.get(edge.source);
                return (
                  <div
                    key={edge.id}
                    className="p-2 rounded bg-[#090d14] border border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px]"
                  >
                    <span className="text-white font-bold truncate max-w-[160px]">
                      {srcNode?.name || edge.source}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 font-mono">
                      {edge.relationship_type}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Downstream Dependencies (Callees / Databases) */}
        <div className="bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
              <ArrowDownRight className="w-3 h-3 text-orange-400" />
              <span>Downstream Dependencies ({outgoingEdges.length})</span>
            </h4>
          </div>

          {outgoingEdges.length === 0 ? (
            <p className="text-[11px] text-slate-500 italic">No downstream dependencies.</p>
          ) : (
            <div className="space-y-1.5">
              {outgoingEdges.map((edge) => {
                const tgtNode = nodesMap.get(edge.target);
                return (
                  <div
                    key={edge.id}
                    className="p-2 rounded bg-[#090d14] border border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px]"
                  >
                    <span className="text-white font-bold truncate max-w-[160px]">
                      {tgtNode?.name || edge.target}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-orange-500/10 text-orange-400 border border-orange-500/30 font-mono">
                      {edge.relationship_type}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Footer Action Buttons */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-[#0f1728] space-y-2">
        <button
          type="button"
          onClick={() => onSimulateImpact(node)}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-bold text-xs shadow-lg shadow-red-600/30 transition-all"
        >
          <Activity className="w-4 h-4" />
          <span>Simulate Impact / Outage</span>
        </button>

        <button
          type="button"
          onClick={() => onAddRelationship(node)}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs transition-colors"
        >
          <Plus className="w-4 h-4 text-orange-400" />
          <span>Add Dependency From Here</span>
        </button>
      </div>
    </div>
  );
};
