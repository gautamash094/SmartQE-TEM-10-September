import React, { useState, useRef, useEffect } from 'react';
import {
  Globe,
  Layers,
  Server,
  GitFork,
  Activity,
  ZoomIn,
  ZoomOut,
  Maximize2,
  RotateCcw,
  Plus,
  Compass,
  Filter,
  Download,
  ChevronDown,
  FileCode,
  FileSpreadsheet,
  FileText,
  FileType
} from 'lucide-react';
import {
  TopologyViewMode,
  TopologyLayoutType,
  TopologyNode
} from '../../types/topology';
import { ExportFormat } from '../../services/topologyExportService';

interface TopologyToolbarProps {
  environments: { id: string; name: string }[];
  selectedEnvironmentId: string;
  onSelectEnvironment: (envId: string) => void;
  viewMode: TopologyViewMode;
  onChangeViewMode: (mode: TopologyViewMode) => void;
  layoutType: TopologyLayoutType;
  onChangeLayoutType: (layout: TopologyLayoutType) => void;
  zoomLevel: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetZoom: () => void;
  onOpenAddRelationshipModal: () => void;
  onExportFormat?: (format: ExportFormat) => void;
  showFilters: boolean;
  onToggleFilters: () => void;
}

export const TopologyToolbar: React.FC<TopologyToolbarProps> = ({
  environments,
  selectedEnvironmentId,
  onSelectEnvironment,
  viewMode,
  onChangeViewMode,
  layoutType,
  onChangeLayoutType,
  zoomLevel,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  onOpenAddRelationshipModal,
  onExportFormat,
  showFilters,
  onToggleFilters
}) => {
  const [isExportDropdownOpen, setIsExportDropdownOpen] = useState<boolean>(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsExportDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="bg-[#0b101b] border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 font-mono">
      {/* Left: Environment Selector & View Mode Switcher */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Environment Picker */}
        <div className="flex items-center gap-2 bg-[#121a2a] border border-slate-700/80 rounded-lg px-3 py-1.5">
          <Globe className="w-4 h-4 text-orange-400 shrink-0" />
          <span className="text-[10px] text-slate-400 font-bold uppercase">ENV:</span>
          <select
            value={selectedEnvironmentId}
            onChange={(e) => onSelectEnvironment(e.target.value)}
            className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-[#0f172a] text-white">
              All Environments (Enterprise View)
            </option>
            {environments.map((env) => (
              <option key={env.id} value={env.id} className="bg-[#0f172a] text-white">
                {env.name}
              </option>
            ))}
          </select>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center bg-[#121a2a] border border-slate-200 dark:border-slate-800 p-1 rounded-lg">
          {[
            { mode: 'ENVIRONMENT' as TopologyViewMode, label: 'Environment', icon: Globe },
            { mode: 'APPLICATION' as TopologyViewMode, label: 'App Flow', icon: Layers },
            { mode: 'INFRASTRUCTURE' as TopologyViewMode, label: 'Infra', icon: Server },
            { mode: 'DEPENDENCY' as TopologyViewMode, label: 'Dependencies', icon: GitFork },
            { mode: 'IMPACT' as TopologyViewMode, label: 'Impact Sim', icon: Activity },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = viewMode === item.mode;
            return (
              <button
                key={item.mode}
                type="button"
                onClick={() => onChangeViewMode(item.mode)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-orange-600 to-amber-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Right: Layout Switcher, Zoom Controls, Filter Toggle & Add Relationship */}
      <div className="flex flex-wrap items-center gap-2">
        {/* Layout Mode Selector */}
        <div className="flex items-center gap-1.5 bg-[#121a2a] border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs">
          <Compass className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={layoutType}
            onChange={(e) => onChangeLayoutType(e.target.value as TopologyLayoutType)}
            className="bg-transparent text-slate-300 font-bold focus:outline-none cursor-pointer"
          >
            <option value="HIERARCHICAL" className="bg-[#0f172a]">
              Hierarchical Layout
            </option>
            <option value="FLOW" className="bg-[#0f172a]">
              Horizontal Pipeline Flow
            </option>
            <option value="GROUPED_ENV" className="bg-[#0f172a]">
              Grouped by Environment
            </option>
          </select>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center bg-[#121a2a] border border-slate-200 dark:border-slate-800 rounded-lg p-1">
          <button
            type="button"
            onClick={onZoomOut}
            className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="text-[10px] px-1.5 font-bold text-slate-400">
            {Math.round(zoomLevel * 100)}%
          </span>
          <button
            type="button"
            onClick={onZoomIn}
            className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onResetZoom}
            className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white ml-0.5 border-l border-slate-700/60"
            title="Reset Zoom & Pan"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>

        {/* Toggle Filters Button */}
        <button
          type="button"
          onClick={onToggleFilters}
          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg border text-xs font-bold transition-all ${
            showFilters
              ? 'bg-orange-500/20 text-orange-400 border-orange-500/50 shadow-[0_0_10px_rgba(249,115,22,0.3)]'
              : 'bg-[#121a2a] text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-800'
          }`}
        >
          <Filter className="w-3.5 h-3.5" />
          <span>Filters</span>
        </button>

        {/* Export Topology Direct Dropdown Menu */}
        {onExportFormat && (
          <div className="relative" ref={dropdownRef}>
            <button
              type="button"
              onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#121a2a] hover:bg-slate-800 border border-slate-700 text-cyan-400 hover:text-cyan-300 text-xs font-bold transition-all shadow-sm"
              title="Export Environment Topology"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export</span>
              <ChevronDown className="w-3 h-3 text-slate-400 ml-0.5" />
            </button>

            {isExportDropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-40 bg-[#0c121e] border border-slate-700 rounded-xl shadow-2xl z-50 py-1.5 font-mono text-xs animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-1 text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-800/80 mb-1">
                  Export Format
                </div>
                {[
                  { format: 'CSV' as ExportFormat, label: 'CSV', icon: FileCode, desc: 'Plain Text' },
                  { format: 'XLSX' as ExportFormat, label: 'XLSX', icon: FileSpreadsheet, desc: 'Excel Book' },
                  { format: 'PDF' as ExportFormat, label: 'PDF', icon: FileText, desc: 'PDF Report' },
                  { format: 'DOCX' as ExportFormat, label: 'DOCX', icon: FileType, desc: 'Word Doc' },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.format}
                      type="button"
                      onClick={() => {
                        setIsExportDropdownOpen(false);
                        onExportFormat(item.format);
                      }}
                      className="w-full px-3 py-1.5 text-left text-slate-200 hover:text-white hover:bg-slate-800/80 flex items-center justify-between transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <Icon className="w-3.5 h-3.5 text-orange-400" />
                        <span className="font-bold">{item.label}</span>
                      </div>
                      <span className="text-[9px] text-slate-500">{item.desc}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Add Relationship CTA */}
        <button
          type="button"
          onClick={onOpenAddRelationshipModal}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white text-xs font-bold transition-all shadow-[0_0_12px_rgba(249,115,22,0.4)]"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Relationship</span>
        </button>
      </div>
    </div>
  );
};

