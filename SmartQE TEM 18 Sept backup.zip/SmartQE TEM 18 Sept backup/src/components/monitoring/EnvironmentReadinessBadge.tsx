import React, { useState } from 'react';
import { TestReadinessStatus, ReadinessCheckResult } from '../../types/monitoring';
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle, ShieldCheck } from 'lucide-react';

interface EnvironmentReadinessBadgeProps {
  status: TestReadinessStatus;
  result?: ReadinessCheckResult;
  size?: 'sm' | 'md' | 'lg';
  showDetails?: boolean;
}

export const EnvironmentReadinessBadge: React.FC<EnvironmentReadinessBadgeProps> = ({
  status,
  result,
  size = 'md',
  showDetails = true,
}) => {
  const [showTooltip, setShowTooltip] = useState(false);

  let bgClass = 'bg-slate-800 text-slate-300 border-slate-700';
  let icon = <HelpCircle className="w-3.5 h-3.5 text-slate-400" />;
  let label = 'UNKNOWN';

  switch (status) {
    case 'READY_FOR_TESTING':
      bgClass = 'bg-emerald-950/80 text-emerald-300 border-emerald-800 shadow-[0_0_8px_rgba(52,211,153,0.3)]';
      icon = <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
      label = 'Ready for Testing';
      break;
    case 'PARTIALLY_READY':
      bgClass = 'bg-amber-950/80 text-amber-300 border-amber-800 shadow-[0_0_8px_rgba(251,191,36,0.3)]';
      icon = <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      label = 'Partially Ready';
      break;
    case 'NOT_READY':
      bgClass = 'bg-rose-950/90 text-rose-300 border-rose-800 shadow-[0_0_8px_rgba(244,63,94,0.3)]';
      icon = <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />;
      label = 'Not Ready';
      break;
    case 'UNKNOWN':
    default:
      bgClass = 'bg-slate-900 text-slate-400 border-slate-200 dark:border-slate-800';
      icon = <HelpCircle className="w-3.5 h-3.5 text-slate-500 shrink-0" />;
      label = 'Unknown Readiness';
      break;
  }

  const paddingClass =
    size === 'sm'
      ? 'px-2 py-0.5 text-[10px]'
      : size === 'lg'
      ? 'px-3 py-1.5 text-xs font-extrabold'
      : 'px-2.5 py-1 text-[11px] font-bold';

  return (
    <div className="relative inline-block" onMouseEnter={() => setShowTooltip(true)} onMouseLeave={() => setShowTooltip(false)}>
      <div className={`inline-flex items-center gap-1.5 rounded-md border font-mono tracking-tight transition-all ${bgClass} ${paddingClass}`}>
        {icon}
        <span>{label}</span>
      </div>

      {/* Hover Tooltip Breakdown */}
      {showDetails && showTooltip && result && (
        <div className="absolute left-0 top-full mt-2 z-50 w-72 p-3 rounded-lg bg-[#0d1522] border border-slate-700 text-xs font-mono shadow-2xl space-y-2 pointer-events-none animate-in fade-in duration-150">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
            <span className="font-bold text-white flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-orange-400" /> Test Readiness Evaluation
            </span>
            <span className="text-[10px] text-orange-400 font-extrabold">{result.score}%</span>
          </div>

          <div className="space-y-1 text-[11px]">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Environment Available</span>
              <span>{result.checks.environmentAvailable ? '✅' : '❌'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">All Servers Online</span>
              <span>{result.checks.serversOnline ? '✅' : '❌'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">App Services Healthy</span>
              <span>{result.checks.servicesHealthy ? '✅' : '❌'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">No Critical Incidents</span>
              <span>{result.checks.noBlockingIncidents ? '✅' : '❌'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">No Maintenance Window</span>
              <span>{result.checks.noMaintenanceBlock ? '✅' : '❌'}</span>
            </div>
          </div>

          {result.reasons.length > 0 && (
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800/80 text-[10px] text-slate-300 leading-tight space-y-1">
              {result.reasons.map((r, idx) => (
                <p key={idx} className="text-amber-300">
                  • {r}
                </p>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
