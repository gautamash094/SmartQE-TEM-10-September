import React from 'react';
import { EnvironmentProfile, ServerDetail, SoftwareDetail } from '../../types/environmentDetails';
import { Booking } from '../../types';
import { environmentDetailsService } from '../../services/environmentDetailsService';
import {
  X,
  AlertTriangle,
  Server,
  Cpu,
  Layers,
  Calendar,
  ArrowRight,
  ShieldAlert,
  Boxes,
} from 'lucide-react';

interface ImpactAnalysisDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  targetNode: {
    type: 'SERVER' | 'SOFTWARE' | 'ENVIRONMENT';
    name: string;
    id: string;
    environmentName?: string;
  } | null;
  environments: EnvironmentProfile[];
  bookings: Booking[];
}

export const ImpactAnalysisDrawer: React.FC<ImpactAnalysisDrawerProps> = ({
  isOpen,
  onClose,
  targetNode,
  environments,
  bookings,
}) => {
  if (!isOpen || !targetNode) return null;

  const affectedEnv = environments.find(
    (e) => e.name.toLowerCase() === (targetNode.environmentName || targetNode.name).toLowerCase()
  ) || environments[0];

  const allSoftware = environmentDetailsService.getSoftware();
  const envSoftwareList = allSoftware.filter((sw) => affectedEnv?.softwareIds?.includes(sw.id));

  const affectedBookings = bookings.filter(
    (b) =>
      b.status !== 'CANCELLED' &&
      b.status !== 'REJECTED' &&
      b.status !== 'AUTO_REJECTED' &&
      ((affectedEnv && b.environmentId === affectedEnv.id) ||
        (affectedEnv && b.environmentName?.toLowerCase() === affectedEnv.name?.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-xl bg-[#090d14] border-l border-slate-200 dark:border-slate-800 h-full overflow-y-auto p-6 space-y-6 shadow-2xl font-mono text-xs text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-red-950/80 border border-red-800 text-red-400">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] text-red-400 font-bold uppercase tracking-widest">
                OBSERVABILITY BLAST RADIUS
              </span>
              <h2 className="text-xl font-extrabold text-white">Dependency Impact Analysis</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Target Node Focus Box */}
        <div className="bg-red-950/40 border border-red-800/80 rounded-xl p-4 space-y-2">
          <span className="text-[10px] text-red-300 font-bold uppercase tracking-wider block">
            TRIGGERING COMPONENT
          </span>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 font-bold text-white">
              {targetNode.type === 'SERVER' ? (
                <Server className="w-4 h-4 text-emerald-400" />
              ) : (
                <Cpu className="w-4 h-4 text-rose-400" />
              )}
              <span>{targetNode.name}</span>
            </div>
            <span className="bg-red-900/80 text-red-200 px-2 py-0.5 rounded text-[10px] border border-red-700">
              STATE: UNHEALTHY
            </span>
          </div>
          <p className="text-[11px] text-slate-300">
            Node ID: <code className="text-orange-400">{targetNode.id}</code> · Environment Target:{' '}
            <strong className="text-white">{targetNode.environmentName || affectedEnv?.name}</strong>
          </p>
        </div>

        {/* Dependency Cascade Flow Graph */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <Layers className="w-4 h-4 text-orange-400" /> CASCADING IMPACT CHAIN
          </h3>

          <div className="space-y-3 relative before:absolute before:left-4 before:top-4 before:bottom-4 before:w-0.5 before:bg-slate-800">
            {/* Step 1: Failed Component */}
            <div className="flex items-start gap-4 relative z-10">
              <div className="w-8 h-8 rounded-full bg-red-950 border border-red-800 flex items-center justify-center text-red-400 shrink-0 font-bold">
                1
              </div>
              <div className="flex-1 bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold uppercase block">1. INFRASTRUCTURE FAILURE</span>
                <p className="text-xs font-bold text-white">{targetNode.name}</p>
                <p className="text-[11px] text-slate-400">High CPU Saturation & Process Disconnection detected.</p>
              </div>
            </div>

            {/* Step 2: Impacted Application Services */}
            <div className="flex items-start gap-4 relative z-10">
              <div className="w-8 h-8 rounded-full bg-amber-950 border border-amber-800 flex items-center justify-center text-amber-400 shrink-0 font-bold">
                2
              </div>
              <div className="flex-1 bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold uppercase block">2. IMPACTED SERVICES ({envSoftwareList.length || 2})</span>
                <div className="space-y-1 pt-1">
                  {envSoftwareList.slice(0, 3).map((sw) => (
                    <div key={sw.id} className="flex items-center justify-between text-[11px] bg-slate-950/60 p-2 rounded border border-slate-200 dark:border-slate-800/80">
                      <span className="text-slate-200 font-bold">{sw.name}</span>
                      <span className="text-amber-400 text-[10px]">DEGRADED API LATENCY</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Step 3: Impacted Environment Profile */}
            <div className="flex items-start gap-4 relative z-10">
              <div className="w-8 h-8 rounded-full bg-orange-950 border border-orange-800 flex items-center justify-center text-orange-400 shrink-0 font-bold">
                3
              </div>
              <div className="flex-1 bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold uppercase block">3. ENVIRONMENT DEGRADATION</span>
                <p className="text-xs font-bold text-orange-300">{affectedEnv?.name}</p>
                <p className="text-[11px] text-slate-400">Overall Health Score dropped to 45%. Test Readiness marked NOT READY.</p>
              </div>
            </div>

            {/* Step 4: Affected Active Bookings */}
            <div className="flex items-start gap-4 relative z-10">
              <div className="w-8 h-8 rounded-full bg-blue-950 border border-blue-800 flex items-center justify-center text-blue-400 shrink-0 font-bold">
                4
              </div>
              <div className="flex-1 bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-2">
                <span className="text-[10px] text-slate-500 font-bold uppercase block flex items-center justify-between">
                  <span>4. AFFECTED RESERVATIONS ({affectedBookings.length})</span>
                  <Calendar className="w-3.5 h-3.5 text-blue-400" />
                </span>

                {affectedBookings.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic">No active test reservations scheduled for this environment.</p>
                ) : (
                  <div className="space-y-1.5">
                    {affectedBookings.map((b) => (
                      <div key={b.id} className="p-2.5 rounded bg-blue-950/30 border border-blue-800/50 space-y-1">
                        <div className="flex items-center justify-between font-bold text-white">
                          <span>{b.purpose}</span>
                          <span className="text-blue-300 text-[10px]">{b.businessUnit}</span>
                        </div>
                        <p className="text-[10px] text-slate-400">
                          App: {b.application} · Requested By: <span className="text-orange-300">{b.requestedBy}</span>
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
