import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Compass,
  Activity,
  Layers,
  Server,
  Database,
  Globe,
  AlertTriangle,
  RefreshCw,
  GitFork,
  CheckCircle2,
  Sparkles,
  Maximize2
} from 'lucide-react';
import { useTEM } from '../context/TEMContext';
import {
  TopologyNode,
  TopologyEdge,
  TopologyGraphResponse,
  TopologyFilterState,
  TopologyViewMode,
  TopologyLayoutType,
  ImpactAnalysisResult
} from '../types/topology';
import { topologyService, CustomRelationshipPayload } from '../services/topologyService';
import { TopologyCanvas } from '../components/topology/TopologyCanvas';
import { TopologyToolbar } from '../components/topology/TopologyToolbar';
import { TopologyFilterBar } from '../components/topology/TopologyFilterBar';
import { TopologyNodeDetailsDrawer } from '../components/topology/TopologyNodeDetailsDrawer';
import { TopologyImpactModal } from '../components/topology/TopologyImpactModal';
import { TopologyRelationshipModal } from '../components/topology/TopologyRelationshipModal';
import { TopologyExportModal } from '../components/topology/TopologyExportModal';
import { TopologyDependencySearch } from '../components/topology/TopologyDependencySearch';
import { ChartSkeleton } from '../components/common/Skeleton';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { ImpactAnalysisDrawer } from '../components/monitoring/ImpactAnalysisDrawer';
import { topologyExportService, ExportScope, ExportFormat } from '../services/topologyExportService';
import { Booking } from '../types';

export const EnvironmentTopologyPage: React.FC = () => {
  // Environment Details is the single source of truth for environments
  const { environmentProfiles, servers, softwareList, applications, businessUnits, bookings, showToast } = useTEM();


  // Topology Graph State
  const [graphData, setGraphData] = useState<TopologyGraphResponse>({
    nodes: [],
    edges: [],
    metrics: {
      total_nodes: 0,
      total_edges: 0,
      environments_count: 0,
      applications_count: 0,
      servers_count: 0,
      software_count: 0,
      databases_count: 0,
      active_incidents_count: 0,
      unhealthy_nodes_count: 0
    }
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters State
  const [filters, setFilters] = useState<TopologyFilterState>({
    searchQuery: '',
    environmentId: 'ALL',
    businessUnit: 'ALL',
    account: 'ALL',
    nodeTypes: [],
    status: 'ALL',
    cloudProvider: 'ALL',
    region: 'ALL',
    hasActiveIncidentsOnly: false
  });

  const [showFilters, setShowFilters] = useState<boolean>(false);

  // View & Layout State
  const [viewMode, setViewMode] = useState<TopologyViewMode>('ENVIRONMENT');
  const [layoutType, setLayoutType] = useState<TopologyLayoutType>('HIERARCHICAL');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Selection & Modal States
  const [selectedNode, setSelectedNode] = useState<TopologyNode | null>(null);
  const [impactResult, setImpactResult] = useState<ImpactAnalysisResult | null>(null);
  const [isImpactModalOpen, setIsImpactModalOpen] = useState<boolean>(false);
  const [isAddRelModalOpen, setIsAddRelModalOpen] = useState<boolean>(false);
  const [addRelSourceNode, setAddRelSourceNode] = useState<TopologyNode | null>(null);

  const handleDirectExportFormat = async (format: ExportFormat) => {
    try {
      showToast('Preparing Environment Topology export...', 'info');
      const isSingleEnvSelected = filters.environmentId && filters.environmentId !== 'ALL';
      const scope: ExportScope = isSingleEnvSelected
        ? 'SELECTED'
        : (filters.businessUnit !== 'ALL' || filters.status !== 'ALL' || (filters.nodeTypes && filters.nodeTypes.length > 0) || filters.hasActiveIncidentsOnly)
        ? 'FILTERED'
        : 'ALL';

      const selectedEnvIds = isSingleEnvSelected ? [filters.environmentId] : [];

      await topologyExportService.exportTopology({
        scope,
        format,
        selectedEnvironmentIds: selectedEnvIds,
        filters,
        graphData,
        environmentProfiles,
        servers,
        softwareList,
        applications
      });
      showToast('Environment Topology exported successfully.', 'success');
    } catch (err) {
      showToast('Unable to generate the export. Please try again.', 'error');
    }
  };



  // Canvas Highlighting
  const [highlightedNodeIds, setHighlightedNodeIds] = useState<Set<string> | undefined>(undefined);
  const [highlightedEdgeIds, setHighlightedEdgeIds] = useState<Set<string> | undefined>(undefined);

  // Load Topology Data
  const loadTopology = useCallback(async () => {
    try {
      setIsLoading(true);
      const data = await topologyService.getTopologyGraph(filters);
      setGraphData(data);
    } catch (err: any) {
      showToast('Failed to fetch topology graph data', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [filters, showToast]);

  useEffect(() => {
    loadTopology();
  }, [loadTopology]);

  // Nodes Map lookup
  const nodesMap = useMemo(() => {
    return new Map<string, TopologyNode>(graphData.nodes.map((n) => [n.id, n]));
  }, [graphData.nodes]);

  // Environment options sourced exclusively from Environment Details module
  const envOptions = useMemo(() => {
    return environmentProfiles.map((p) => ({ id: p.id, name: p.name }));
  }, [environmentProfiles]);

  const buOptions = useMemo(() => {
    return businessUnits.map((b) => b.name);
  }, [businessUnits]);

  const cloudOptions = ['AWS', 'Azure', 'GCP', 'On-Premises'];

  // Handle Zoom
  const handleZoomIn = () => setZoomLevel((z) => Math.min(2, Math.round((z + 0.15) * 100) / 100));
  const handleZoomOut = () => setZoomLevel((z) => Math.max(0.4, Math.round((z - 0.15) * 100) / 100));
  const handleResetZoom = () => setZoomLevel(1);

  // Handle Node Selection
  const handleSelectNode = (node: TopologyNode) => {
    setSelectedNode(node);
  };

  // Run Impact Analysis Simulation
  const handleSimulateImpact = async (node: TopologyNode) => {
    try {
      const res = await topologyService.getImpactAnalysis(node.id, graphData);
      setImpactResult(res);
      setIsImpactModalOpen(true);
    } catch (err: any) {
      showToast('Failed to run impact simulation', 'error');
    }
  };

  // Focus Affected Impact Nodes on Canvas
  const handleFocusImpactOnCanvas = (result: ImpactAnalysisResult) => {
    const nodeIds = new Set<string>([
      result.target_node.id,
      ...result.upstream_nodes.map((n) => n.id),
      ...result.downstream_nodes.map((n) => n.id)
    ]);
    setHighlightedNodeIds(nodeIds);

    const edgeIds = new Set<string>();
    graphData.edges.forEach((e) => {
      if (nodeIds.has(e.source) && nodeIds.has(e.target)) {
        edgeIds.add(e.id);
      }
    });
    setHighlightedEdgeIds(edgeIds);
    setSelectedNode(result.target_node);
  };

  // Open Add Relationship Modal
  const handleOpenAddRelationship = (sourceNode?: TopologyNode) => {
    setAddRelSourceNode(sourceNode || null);
    setIsAddRelModalOpen(true);
  };

  // Save Relationship
  const handleSaveRelationship = async (payload: CustomRelationshipPayload) => {
    await topologyService.createRelationship(payload);
    showToast('Topology relationship created successfully', 'success');
    loadTopology();
  };

  // Reset Filters
  const handleResetFilters = () => {
    setFilters({
      searchQuery: '',
      environmentId: 'ALL',
      businessUnit: 'ALL',
      account: 'ALL',
      nodeTypes: [],
      status: 'ALL',
      cloudProvider: 'ALL',
      region: 'ALL',
      hasActiveIncidentsOnly: false
    });
    setHighlightedNodeIds(undefined);
    setHighlightedEdgeIds(undefined);
  };

  return (
    <div className="space-y-4 pb-12 font-mono text-slate-200">
      {/* Header Banner & KPI Metric Cards */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0e17] border border-slate-200 dark:border-slate-800/80 p-5 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-orange-600 to-amber-500 flex items-center justify-center text-white shadow-[0_0_20px_rgba(249,115,22,0.4)]">
            <Compass className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white uppercase">
                Environment Topology
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-500/20 text-orange-400 border border-orange-500/40">
                LIVE CMDB BLUEPRINT
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Composition, connectivity, upstream/downstream dependencies & blast radius analysis
            </p>
          </div>
        </div>

        {/* Live Metrics Summary Strip */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="px-3 py-1.5 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800 flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400 text-[10px]">ENVS:</span>
            <span className="text-white font-bold">{graphData.metrics.environments_count}</span>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800 flex items-center gap-2">
            <Layers className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-slate-400 text-[10px]">APPS:</span>
            <span className="text-white font-bold">{graphData.metrics.applications_count}</span>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800 flex items-center gap-2">
            <Server className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-slate-400 text-[10px]">SERVERS:</span>
            <span className="text-white font-bold">{graphData.metrics.servers_count}</span>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-[#111827] border border-slate-200 dark:border-slate-800 flex items-center gap-2">
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-400 text-[10px]">DBS:</span>
            <span className="text-white font-bold">{graphData.metrics.databases_count}</span>
          </div>

          {graphData.metrics.active_incidents_count > 0 && (
            <div className="px-3 py-1.5 rounded-xl bg-red-950/40 border border-red-500/50 flex items-center gap-2 animate-pulse text-red-400 font-bold">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{graphData.metrics.active_incidents_count} INCIDENTS</span>
            </div>
          )}

          <button
            onClick={loadTopology}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Refresh Topology"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <TopologyToolbar
        environments={envOptions}
        selectedEnvironmentId={filters.environmentId}
        onSelectEnvironment={(envId) => setFilters({ ...filters, environmentId: envId })}
        viewMode={viewMode}
        onChangeViewMode={(mode) => setViewMode(mode)}
        layoutType={layoutType}
        onChangeLayoutType={(layout) => setLayoutType(layout)}
        zoomLevel={zoomLevel}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onResetZoom={handleResetZoom}
        onOpenAddRelationshipModal={() => handleOpenAddRelationship()}
        onExportFormat={handleDirectExportFormat}
        showFilters={showFilters}
        onToggleFilters={() => setShowFilters(!showFilters)}
      />

      {/* Filter Bar (Collapsible) */}
      {showFilters && (
        <TopologyFilterBar
          filters={filters}
          onFilterChange={(newFilters) => setFilters(newFilters)}
          onResetFilters={handleResetFilters}
          businessUnits={buOptions}
          cloudProviders={cloudOptions}
        />
      )}

      {/* Dependency Traversal Search Explorer */}
      {(viewMode === 'DEPENDENCY' || viewMode === 'IMPACT') && (
        <TopologyDependencySearch
          nodes={graphData.nodes}
          edges={graphData.edges}
          onSelectNode={(node) => {
            setSelectedNode(node);
            handleSimulateImpact(node);
          }}
        />
      )}

      {/* Interactive Topology Graph Canvas */}
      {isLoading ? (
        <div className="space-y-4">
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 flex items-center justify-center shadow-xl">
            <LoadingSpinner size="md" variant="primary" />
          </div>
          <ChartSkeleton height={600} className="w-full rounded-2xl" />
        </div>
      ) : (
        <TopologyCanvas
          nodes={graphData.nodes}
          edges={graphData.edges}
          selectedNodeId={selectedNode?.id || null}
          highlightedNodeIds={highlightedNodeIds}
          highlightedEdgeIds={highlightedEdgeIds}
          layoutType={layoutType}
          viewMode={viewMode}
          searchQuery={filters.searchQuery}
          zoomLevel={zoomLevel}
          onSelectNode={handleSelectNode}
          onOpenImpactModal={handleSimulateImpact}
          onAddRelationshipFromNode={handleOpenAddRelationship}
        />
      )}

      {/* Right-Side Node Details Drawer */}
      <TopologyNodeDetailsDrawer
        node={selectedNode}
        edges={graphData.edges}
        nodesMap={nodesMap}
        onClose={() => setSelectedNode(null)}
        onSimulateImpact={handleSimulateImpact}
        onAddRelationship={handleOpenAddRelationship}
      />

      {/* Blast Radius Impact Analysis Modal */}
      <TopologyImpactModal
        isOpen={isImpactModalOpen}
        onClose={() => setIsImpactModalOpen(false)}
        impactResult={impactResult}
        onFocusImpactOnCanvas={handleFocusImpactOnCanvas}
      />

      {/* Manual Relationship Management Modal */}
      <TopologyRelationshipModal
        isOpen={isAddRelModalOpen}
        onClose={() => setIsAddRelModalOpen(false)}
        nodes={graphData.nodes}
        initialSourceNode={addRelSourceNode}
        onSaveRelationship={handleSaveRelationship}
      />
    </div>
  );
};


