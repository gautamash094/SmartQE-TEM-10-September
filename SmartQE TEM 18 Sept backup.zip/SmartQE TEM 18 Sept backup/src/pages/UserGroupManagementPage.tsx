import React, { useState, useEffect, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import { userGroupService, UserGroup, UserGroupCreatePayload, UserGroupUpdatePayload } from '../services/userGroupService';
import { userService, User } from '../services/userService';
import { portfolioService, BusinessUnit } from '../services/portfolioService';
import { useAuth } from '../context/AuthContext';
import {
  Users,
  UserPlus,
  Briefcase,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Edit2,
  Trash2,
  Plus,
  X,
  ChevronDown,
  Info,
  Calendar,
  Sparkles,
  RefreshCw,
  AlertTriangle,
  Layers,
  CheckSquare,
  Square,
  Building2,
  ShieldAlert,
} from 'lucide-react';
import { ButtonLoader } from '../components/common/ButtonLoader';
import { TableSkeleton } from '../components/common/Skeleton';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { Pagination } from '../components/common/Pagination';

export const UserGroupManagementPage: React.FC = () => {
  const { showToast } = useTEM();
  const { currentUser } = useAuth();

  const isSuperAdmin = useMemo(() => {
    if (!currentUser) return false;
    return (
      Boolean(currentUser.isSuperAdmin) ||
      currentUser.username.toLowerCase() === 'admin' ||
      currentUser.email?.toLowerCase() === 'admin@tem.com' ||
      (currentUser.roles || []).some((r) => r.name.toLowerCase().trim() === 'super admin')
    );
  }, [currentUser]);

  const [groups, setGroups] = useState<UserGroup[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedBUFilter, setSelectedBUFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [page, setPage] = useState<number>(1);
  const pageSize = 10;

  // Add / Edit Modal State
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingGroup, setEditingGroup] = useState<UserGroup | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');

  // Form State
  const [groupName, setGroupName] = useState<string>('');
  const [groupDescription, setGroupDescription] = useState<string>('');
  const [selectedBUId, setSelectedBUId] = useState<string>('');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [isActive, setIsActive] = useState<boolean>(true);
  const [userSearchQuery, setUserSearchQuery] = useState<string>('');

  // Delete Modal State
  const [deleteConfirmGroup, setDeleteConfirmGroup] = useState<UserGroup | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Load Data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [fetchedGroups, fetchedUsers, fetchedBUs] = await Promise.all([
        userGroupService.getUserGroups(),
        userService.getUsers(),
        portfolioService.getBusinessUnits(),
      ]);

      setGroups(fetchedGroups);
      setUsers(fetchedUsers);
      setBusinessUnits(fetchedBUs.filter((bu) => bu.isActive !== false && bu.status !== 'INACTIVE'));
    } catch (err: any) {
      showToast(err.message || 'Failed to load user group management data', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Active BUs for Dropdown
  const activeBUs = useMemo(() => {
    return businessUnits.filter((b) => b.isActive !== false && b.status !== 'INACTIVE');
  }, [businessUnits]);

  // Selected BU object in Modal
  const currentSelectedBU = useMemo(() => {
    return activeBUs.find((b) => b.id === selectedBUId || b.name.toLowerCase() === selectedBUId.toLowerCase());
  }, [activeBUs, selectedBUId]);

  // Available Users Filtered by Selected BU
  // CRITICAL RULE: Only active users tagged to the selected BU in User Management are available
  const availableUsersForBU = useMemo(() => {
    if (!selectedBUId) return [];

    const targetBU = currentSelectedBU;
    const targetBUId = targetBU?.id || selectedBUId;
    const targetBUName = targetBU?.name?.toLowerCase().trim() || '';

    return users.filter((u) => {
      // Must be active
      if (u.isActive === false || u.status === 'INACTIVE') return false;

      // Must belong to target BU by ID or Name
      if (u.businessUnitId && u.businessUnitId === targetBUId) return true;
      if (u.businessUnit?.id && u.businessUnit.id === targetBUId) return true;
      if (u.businessUnit?.name && targetBUName && u.businessUnit.name.toLowerCase().trim() === targetBUName) return true;

      return false;
    });
  }, [users, selectedBUId, currentSelectedBU]);

  // Filtered available users by modal search box
  const filteredAvailableUsers = useMemo(() => {
    const q = userSearchQuery.toLowerCase().trim();
    if (!q) return availableUsersForBU;
    return availableUsersForBU.filter(
      (u) =>
        u.username.toLowerCase().includes(q) ||
        u.fullName?.toLowerCase().includes(q) ||
        u.email?.toLowerCase().includes(q)
    );
  }, [availableUsersForBU, userSearchQuery]);

  // Accurate count of selected users belonging to the currently selected BU
  const selectedCountInCurrentBU = useMemo(() => {
    const availableSet = new Set(availableUsersForBU.map((u) => u.id));
    return selectedUserIds.filter((id) => availableSet.has(id)).length;
  }, [selectedUserIds, availableUsersForBU]);

  // Reset / Open Create Modal
  const handleOpenCreateModal = () => {
    setEditingGroup(null);
    setGroupName('');
    setGroupDescription('');
    setSelectedBUId(activeBUs.length > 0 ? activeBUs[0].id : '');
    setSelectedUserIds([]);
    setIsActive(true);
    setFormError('');
    setUserSearchQuery('');
    setModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (group: UserGroup) => {
    setEditingGroup(group);
    setGroupName(group.name);
    setGroupDescription(group.description || '');
    setSelectedBUId(group.buId);

    const targetBU = activeBUs.find((b) => b.id === group.buId || b.name.toLowerCase() === group.buId.toLowerCase());
    const targetBUId = targetBU?.id || group.buId;
    const targetBUName = targetBU?.name?.toLowerCase().trim() || '';

    const validUsersForBU = users.filter((u) => {
      if (u.isActive === false || u.status === 'INACTIVE') return false;
      if (u.businessUnitId && u.businessUnitId === targetBUId) return true;
      if (u.businessUnit?.id && u.businessUnit.id === targetBUId) return true;
      if (u.businessUnit?.name && targetBUName && u.businessUnit.name.toLowerCase().trim() === targetBUName) return true;
      return false;
    });
    const validUserIdsSet = new Set(validUsersForBU.map((u) => u.id));

    setSelectedUserIds((group.members || []).map((m) => m.userId).filter((id) => validUserIdsSet.has(id)));
    setIsActive(group.isActive);
    setFormError('');
    setUserSearchQuery('');
    setModalOpen(true);
  };

  // When BU changes in Modal, revalidate & reset selected users that don't belong to the new BU
  const handleBUChange = (newBuId: string) => {
    setSelectedBUId(newBuId);
    const newBU = activeBUs.find((b) => b.id === newBuId || b.name.toLowerCase() === newBuId.toLowerCase());
    const newBUId = newBU?.id || newBuId;
    const newBUName = newBU?.name?.toLowerCase().trim() || '';

    // Keep only users who belong to the new BU
    const validUsersForNewBU = users.filter((u) => {
      if (u.isActive === false || u.status === 'INACTIVE') return false;
      if (u.businessUnitId && u.businessUnitId === newBUId) return true;
      if (u.businessUnit?.id && u.businessUnit.id === newBUId) return true;
      if (u.businessUnit?.name && newBUName && u.businessUnit.name.toLowerCase().trim() === newBUName) return true;
      return false;
    });

    const validUserIdsSet = new Set(validUsersForNewBU.map((u) => u.id));
    setSelectedUserIds((prev) => prev.filter((id) => validUserIdsSet.has(id)));
  };

  // Toggle single user selection in modal
  const handleToggleUser = (userId: string) => {
    setSelectedUserIds((prev) => {
      if (prev.includes(userId)) {
        return prev.filter((id) => id !== userId);
      } else {
        return [...prev, userId];
      }
    });
  };

  // Select all users in current BU
  const handleSelectAllUsers = () => {
    setSelectedUserIds(availableUsersForBU.map((u) => u.id));
  };

  // Deselect all users
  const handleDeselectAllUsers = () => {
    setSelectedUserIds([]);
  };

  // Save User Group
  const handleSaveGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // Validations
    if (!groupName.trim()) {
      setFormError('Group Name is required.');
      return;
    }
    if (!selectedBUId) {
      setFormError('Please select a Business Unit.');
      return;
    }
    if (selectedUserIds.length === 0) {
      setFormError('Please select at least one active user from the selected Business Unit.');
      return;
    }

    // Check duplicate group name locally
    const duplicate = groups.find(
      (g) =>
        g.name.toLowerCase().trim() === groupName.toLowerCase().trim() &&
        (!editingGroup || g.id !== editingGroup.id)
    );
    if (duplicate) {
      setFormError(`A User Group with name "${groupName.trim()}" already exists.`);
      return;
    }

    setIsSaving(true);
    try {
      if (editingGroup) {
        const payload: UserGroupUpdatePayload = {
          name: groupName.trim(),
          description: groupDescription.trim(),
          buId: selectedBUId,
          userIds: selectedUserIds,
          isActive,
          status: isActive ? 'ACTIVE' : 'INACTIVE',
        };
        const updated = await userGroupService.updateUserGroup(editingGroup.id, payload);
        setGroups((prev) => prev.map((g) => (g.id === updated.id ? updated : g)));
        showToast(`User Group "${updated.name}" updated successfully!`, 'success');
      } else {
        const payload: UserGroupCreatePayload = {
          name: groupName.trim(),
          description: groupDescription.trim(),
          buId: selectedBUId,
          userIds: selectedUserIds,
          isActive,
        };
        const created = await userGroupService.createUserGroup(payload);
        setGroups((prev) => [created, ...prev]);
        showToast(`User Group "${created.name}" created successfully!`, 'success');
      }
      setModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to save User Group.');
    } finally {
      setIsSaving(false);
    }
  };

  // Toggle status
  const handleToggleStatus = async (group: UserGroup) => {
    try {
      const updated = await userGroupService.toggleUserGroupStatus(group.id);
      setGroups((prev) => prev.map((g) => (g.id === updated.id ? updated : g)));
      showToast(
        `User Group "${updated.name}" is now ${updated.isActive ? 'Active' : 'Inactive'}.`,
        'success'
      );
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle group status', 'error');
    }
  };

  // Delete / Soft-deactivate group
  const handleConfirmDelete = async () => {
    if (!deleteConfirmGroup) return;
    setIsDeleting(true);
    try {
      await userGroupService.deleteUserGroup(deleteConfirmGroup.id);
      setGroups((prev) =>
        prev.map((g) => (g.id === deleteConfirmGroup.id ? { ...g, isActive: false, status: 'INACTIVE' } : g))
      );
      showToast(`User Group "${deleteConfirmGroup.name}" deactivated successfully!`, 'success');
      setDeleteConfirmGroup(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to deactivate user group', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Dynamically sanitize groups to ensure member counts and lists only include active users assigned to the group's BU
  const sanitizedGroups = useMemo(() => {
    return groups.map((g) => {
      const targetBU = activeBUs.find((b) => b.id === g.buId || b.name.toLowerCase() === g.buId.toLowerCase());
      const targetBUId = targetBU?.id || g.buId;
      const targetBUName = targetBU?.name?.toLowerCase().trim() || '';

      const validMembers = g.members.filter((m) => {
        const u = users.find((usr) => usr.id === m.userId || usr.username.toLowerCase() === (m.username || '').toLowerCase());
        if (!u || u.isActive === false || u.status === 'INACTIVE') return false;
        if (u.businessUnitId && u.businessUnitId === targetBUId) return true;
        if (u.businessUnit?.id && u.businessUnit.id === targetBUId) return true;
        if (u.businessUnit?.name && targetBUName && u.businessUnit.name.toLowerCase().trim() === targetBUName) return true;
        return false;
      });

      return {
        ...g,
        members: validMembers,
        memberCount: validMembers.length,
      };
    });
  }, [groups, users, activeBUs]);

  // Scoped User Groups: Super Admin sees all groups; non-super-admin users only see groups where they are a member or creator
  const scopedGroups = useMemo(() => {
    if (isSuperAdmin) return sanitizedGroups;
    if (!currentUser) return [];

    const userId = (currentUser.id || '').toLowerCase().trim();
    const username = (currentUser.username || '').toLowerCase().trim();
    const fullName = (currentUser.fullName || '').toLowerCase().trim();
    const email = (currentUser.email || '').toLowerCase().trim();

    return sanitizedGroups.filter((g) => {
      // Check if current user is in the group members
      const isMember = (g.members || []).some((m) => {
        const mUserId = (m.userId || '').toLowerCase().trim();
        const mUsername = (m.username || '').toLowerCase().trim();
        const mFullName = (m.fullName || '').toLowerCase().trim();
        const mEmail = (m.email || '').toLowerCase().trim();

        return (
          (mUserId && (mUserId === userId || mUserId === username)) ||
          (mUsername && (mUsername === username || mUsername === userId)) ||
          (mFullName && (mFullName === fullName || (fullName && mFullName.includes(fullName)))) ||
          (mEmail && mEmail === email)
        );
      });

      // Check if created by current user
      const isCreator = Boolean(
        g.createdBy &&
        (g.createdBy.toLowerCase().trim() === username ||
          g.createdBy.toLowerCase().trim() === fullName ||
          g.createdBy.toLowerCase().trim() === email)
      );

      return isMember || isCreator;
    });
  }, [sanitizedGroups, isSuperAdmin, currentUser]);

  // Filtered groups table
  const filteredGroups = useMemo(() => {
    return scopedGroups.filter((g) => {
      // Search
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        g.name.toLowerCase().includes(q) ||
        (g.description && g.description.toLowerCase().includes(q)) ||
        (g.buName && g.buName.toLowerCase().includes(q)) ||
        g.members.some((m) => m.fullName?.toLowerCase().includes(q) || m.username?.toLowerCase().includes(q));

      // BU Filter
      const matchBU =
        selectedBUFilter === 'ALL' ||
        g.buId === selectedBUFilter ||
        (g.buName && g.buName.toLowerCase() === selectedBUFilter.toLowerCase());

      // Status Filter
      const matchStatus =
        selectedStatusFilter === 'ALL' ||
        (selectedStatusFilter === 'ACTIVE' && g.isActive) ||
        (selectedStatusFilter === 'INACTIVE' && !g.isActive);

      return matchSearch && matchBU && matchStatus;
    });
  }, [scopedGroups, searchQuery, selectedBUFilter, selectedStatusFilter]);

  // Paginated groups
  const paginatedGroups = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredGroups.slice(start, start + pageSize);
  }, [filteredGroups, page, pageSize]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12 font-sans">
      {/* 1. HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            SETTINGS &bull; IDENTITY & ACCESS
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1 flex items-center gap-3">
            <Users className="w-7 h-7 text-orange-500" />
            <span>User Group Management</span>
            <span className="text-xs font-mono font-normal bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 border border-orange-300 dark:border-orange-800/80 px-2.5 py-0.5 rounded-full">
              {scopedGroups.length} {scopedGroups.length === 1 ? 'Group' : 'Groups'}
            </span>
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
            Create and organize business unit (BU) user groups for approval hierarchies and resource governance. Groups strictly enforce BU-based user tagging.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadData}
            className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f1724] text-slate-600 dark:text-slate-400 hover:text-orange-500 transition-colors shadow-sm cursor-pointer"
            title="Reload User Groups"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-500' : ''}`} />
          </button>
          <button
            onClick={handleOpenCreateModal}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_16px_rgba(249,115,22,0.4)] cursor-pointer"
          >
            <Plus className="w-4 h-4" /> CREATE USER GROUP
          </button>
        </div>
      </div>

      {/* 2. KPI SUMMARY METRIC CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400">TOTAL USER GROUPS</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-3xl font-extrabold text-slate-900 dark:text-white mt-2">{scopedGroups.length}</p>
          <p className="text-xs text-slate-500 mt-1 font-sans">Registered functional groups</p>
        </div>

        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-emerald-500">ACTIVE GROUPS</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-2">
            {scopedGroups.filter((g) => g.isActive).length}
          </p>
          <p className="text-xs text-slate-500 mt-1 font-sans">Eligible for workflow assignment</p>
        </div>

        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400">BUSINESS UNITS ENGAGED</span>
            <Building2 className="w-4 h-4 text-orange-500" />
          </div>
          <p className="text-3xl font-extrabold text-slate-900 dark:text-white mt-2">
            {new Set(scopedGroups.map((g) => g.buId)).size}
          </p>
          <p className="text-xs text-slate-500 mt-1 font-sans">Distinct BUs with configured groups</p>
        </div>

        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400">TOTAL GROUP MEMBERS</span>
            <Layers className="w-4 h-4 text-cyan-500" />
          </div>
          <p className="text-3xl font-extrabold text-cyan-600 dark:text-cyan-400 mt-2">
            {scopedGroups.reduce((acc, g) => acc + g.memberCount, 0)}
          </p>
          <p className="text-xs text-slate-500 mt-1 font-sans">Assigned user memberships</p>
        </div>
      </div>

      {/* 3. FILTER & SEARCH TOOLBAR */}
      <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 p-4 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-xs shadow-sm">
        {/* Search */}
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input autoComplete="off" data-lpignore="true"
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setPage(1);
            }}
            placeholder="Search by group name, BU, or member username..."
            className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500"
          />
        </div>

        {/* Dropdown Filters */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* BU Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">BU:</span>
            <select
              value={selectedBUFilter}
              onChange={(e) => {
                setSelectedBUFilter(e.target.value);
                setPage(1);
              }}
              className="bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-2.5 py-1.5 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="ALL">All Business Units</option>
              {activeBUs.map((bu) => (
                <option key={bu.id} value={bu.id}>
                  {bu.name} ({bu.code})
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">STATUS:</span>
            <select
              value={selectedStatusFilter}
              onChange={(e) => {
                setSelectedStatusFilter(e.target.value);
                setPage(1);
              }}
              className="bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-2.5 py-1.5 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="ALL">All Status</option>
              <option value="ACTIVE">Active Only</option>
              <option value="INACTIVE">Inactive Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* 4. USER GROUPS TABLE */}
      {isLoading ? (
        <div className="space-y-4">
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 flex items-center justify-center shadow-xl">
            <LoadingSpinner size="md" variant="primary" />
          </div>
          <TableSkeleton rows={6} columns={6} />
        </div>
      ) : (
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl overflow-hidden shadow-sm">
          {filteredGroups.length === 0 ? (
            <div className="p-12 text-center text-slate-400 space-y-3 font-mono">
              <Users className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">No User Groups Found</p>
              <p className="text-xs text-slate-500 max-w-md mx-auto font-sans">
                {groups.length === 0
                  ? 'No user groups have been defined yet. Click "+ CREATE USER GROUP" above to configure your first BU user group.'
                  : 'No user groups matched your active filter criteria. Try clearing search or filters.'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse font-sans text-xs">
                <thead className="bg-slate-50 dark:bg-slate-900/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-mono font-bold tracking-wider">
                  <tr>
                    <th className="p-4">GROUP NAME & DESCRIPTION</th>
                    <th className="p-4">BUSINESS UNIT</th>
                    <th className="p-4">MEMBERS (USERS)</th>
                    <th className="p-4">STATUS</th>
                    <th className="p-4">AUDIT (CREATED / MODIFIED)</th>
                    <th className="p-4 text-right">ACTIONS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800/80">
                  {paginatedGroups.map((group) => {
                    return (
                      <tr
                        key={group.id}
                        className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                      >
                        {/* Group Name & Description */}
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-orange-100 dark:bg-orange-950/60 border border-orange-200 dark:border-orange-800/60 flex items-center justify-center text-orange-600 dark:text-orange-400 font-bold shrink-0">
                              <Users className="w-4 h-4" />
                            </div>
                            <div className="min-w-0">
                              <span className="font-bold text-slate-900 dark:text-white block text-sm">
                                {group.name}
                              </span>
                              {group.description && (
                                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                                  {group.description}
                                </p>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* Business Unit */}
                        <td className="p-4">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700/80">
                            <Building2 className="w-3.5 h-3.5 text-orange-500" />
                            <span>{group.buName || group.buId}</span>
                            {group.buCode && (
                              <span className="text-[10px] text-slate-400">({group.buCode})</span>
                            )}
                          </span>
                        </td>

                        {/* Members */}
                        <td className="p-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-slate-900 dark:text-white text-xs">
                                {group.memberCount} User{group.memberCount !== 1 ? 's' : ''}
                              </span>
                            </div>
                            <div className="flex flex-wrap gap-1 max-w-xs">
                              {group.members.slice(0, 3).map((m) => (
                                <span
                                  key={m.id}
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono bg-orange-50 dark:bg-orange-950/40 text-orange-700 dark:text-orange-300 border border-orange-200 dark:border-orange-800/40"
                                >
                                  {m.fullName || m.username}
                                </span>
                              ))}
                              {group.members.length > 3 && (
                                <span className="text-[10px] font-mono font-bold text-slate-400 self-center">
                                  +{group.members.length - 3} more
                                </span>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* Status */}
                        <td className="p-4">
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(group)}
                            className="inline-flex items-center gap-1.5 cursor-pointer group"
                            title="Click to toggle active status"
                          >
                            <span
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold transition-colors ${
                                group.isActive
                                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800/80 group-hover:bg-emerald-200'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 group-hover:bg-slate-200'
                              }`}
                            >
                              {group.isActive ? (
                                <>
                                  <CheckCircle2 className="w-3.5 h-3.5" /> ACTIVE
                                </>
                              ) : (
                                <>
                                  <XCircle className="w-3.5 h-3.5" /> INACTIVE
                                </>
                              )}
                            </span>
                          </button>
                        </td>

                        {/* Audit Info */}
                        <td className="p-4 font-mono text-[11px] text-slate-500 space-y-1">
                          <div>
                            <span className="text-[10px] text-slate-400 uppercase">Created:</span>{' '}
                            <span className="text-slate-700 dark:text-slate-300 font-semibold">{group.createdBy}</span>
                            <span className="text-slate-400 text-[10px] block">
                              {new Date(group.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          {group.modifiedBy && group.modifiedBy !== group.createdBy && (
                            <div className="text-[10px] text-slate-400">
                              Mod: {group.modifiedBy} ({new Date(group.updatedAt).toLocaleDateString()})
                            </div>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="p-4 text-right space-x-2">
                          <button
                            onClick={() => handleOpenEditModal(group)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-orange-50 dark:hover:bg-orange-950/40 text-slate-600 dark:text-slate-300 hover:text-orange-600 transition-colors cursor-pointer"
                            title="Edit User Group"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmGroup(group)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-600 dark:text-slate-300 hover:text-rose-600 transition-colors cursor-pointer"
                            title="Deactivate User Group"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {filteredGroups.length > pageSize && (
            <div className="p-4 border-t border-slate-200 dark:border-slate-800">
              <Pagination
                currentPage={page}
                totalItems={filteredGroups.length}
                pageSize={pageSize}
                onPageChange={setPage}
              />
            </div>
          )}
        </div>
      )}

      {/* 5. CREATE / EDIT USER GROUP MODAL */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5 relative my-8">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-orange-100 dark:bg-orange-950/60 border border-orange-300 dark:border-orange-800/80 flex items-center justify-center text-orange-600 dark:text-orange-400">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    {editingGroup ? 'Edit User Group' : 'Create New User Group'}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono">
                    Configure BU and group members with strict BU-level restriction.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form Error Banner */}
            {formError && (
              <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 rounded-xl flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300 font-mono">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
                <span>{formError}</span>
              </div>
            )}

            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveGroup} className="space-y-4 font-sans text-xs">
              {/* Group Name & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                    Group Name <span className="text-rose-500">*</span>
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    required
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                    placeholder="e.g. Finance Approval Guild"
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                    Status
                  </label>
                  <select
                    value={isActive ? 'ACTIVE' : 'INACTIVE'}
                    onChange={(e) => setIsActive(e.target.value === 'ACTIVE')}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-2 text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
                  >
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={groupDescription}
                  onChange={(e) => setGroupDescription(e.target.value)}
                  placeholder="Purpose of this user group in TEM approvals..."
                  className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              {/* Business Unit Selection */}
              <div>
                <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  Business Unit (BU) <span className="text-rose-500">*</span>
                </label>
                <select
                  required
                  value={selectedBUId}
                  onChange={(e) => handleBUChange(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer font-bold"
                >
                  <option value="">-- Select Target Business Unit --</option>
                  {activeBUs.map((bu) => (
                    <option key={bu.id} value={bu.id}>
                      {bu.name} ({bu.code})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] font-mono text-slate-500 mt-1">
                  Selecting a BU dynamically filters available users to only those tagged to this BU.
                </p>
              </div>

              {/* BU-RESTRICTED USER SELECTION SECTION */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-950/40 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-2.5">
                  <div>
                    <label className="text-xs font-mono font-bold text-slate-900 dark:text-white uppercase flex items-center gap-1.5">
                      <span>Users from Selected BU</span>
                      <span className="text-orange-500">({selectedCountInCurrentBU} Selected)</span>
                    </label>
                    <span className="text-[11px] text-slate-500">
                      {currentSelectedBU
                        ? `Available users tagged to "${currentSelectedBU.name}":`
                        : 'Select a BU above to view available users.'}
                    </span>
                  </div>

                  {availableUsersForBU.length > 0 && (
                    <div className="flex items-center gap-2 font-mono text-[11px]">
                      <button
                        type="button"
                        onClick={handleSelectAllUsers}
                        className="text-orange-600 dark:text-orange-400 hover:underline cursor-pointer"
                      >
                        Select All
                      </button>
                      <span className="text-slate-400">&bull;</span>
                      <button
                        type="button"
                        onClick={handleDeselectAllUsers}
                        className="text-slate-500 hover:underline cursor-pointer"
                      >
                        Deselect All
                      </button>
                    </div>
                  )}
                </div>

                {/* Search within available users */}
                {availableUsersForBU.length > 5 && (
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={userSearchQuery}
                      onChange={(e) => setUserSearchQuery(e.target.value)}
                      placeholder="Search users by name or username..."
                      className="w-full bg-white dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-orange-500"
                    />
                  </div>
                )}

                {/* User List */}
                <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                  {!selectedBUId ? (
                    <p className="text-xs text-slate-400 text-center py-6 font-mono">
                      Please select a Business Unit first.
                    </p>
                  ) : availableUsersForBU.length === 0 ? (
                    <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800/80 rounded-lg text-amber-800 dark:text-amber-300 text-xs font-mono space-y-1">
                      <div className="flex items-center gap-1.5 font-bold">
                        <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                        <span>No Active Users Tagged to this BU</span>
                      </div>
                      <p className="text-[11px] font-sans">
                        No active users are currently assigned to "{currentSelectedBU?.name}" in User Management. Please tag users to this BU first in User Management before creating a group.
                      </p>
                    </div>
                  ) : (
                    filteredAvailableUsers.map((u) => {
                      const isChecked = selectedUserIds.includes(u.id);
                      return (
                        <div
                          key={u.id}
                          onClick={() => handleToggleUser(u.id)}
                          className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                            isChecked
                              ? 'bg-orange-50 dark:bg-orange-950/30 border-orange-300 dark:border-orange-800/80'
                              : 'bg-white dark:bg-[#161f2e] border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => handleToggleUser(u.id)}
                              onClick={(e) => e.stopPropagation()}
                              className="w-4 h-4 accent-orange-500 rounded cursor-pointer shrink-0"
                            />
                            <div className="min-w-0">
                              <span className="font-bold text-slate-900 dark:text-white block truncate">
                                {u.fullName || u.username}
                              </span>
                              <span className="text-[11px] font-mono text-slate-400 block truncate">
                                @{u.username} &bull; {u.email}
                              </span>
                            </div>
                          </div>

                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0 ml-2">
                            {u.roles && u.roles.length > 0 ? u.roles[0].name : 'User'}
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Modal Footer Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-mono font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  CANCEL
                </button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSaving}
                  loadingText="SAVING..."
                  className="px-6 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_12px_rgba(249,115,22,0.35)] cursor-pointer"
                >
                  {editingGroup ? 'UPDATE GROUP' : 'CREATE GROUP'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. DELETE / DEACTIVATE CONFIRMATION MODAL */}
      {deleteConfirmGroup && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#0f1724] border border-rose-300 dark:border-rose-900/80 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-950/80 border border-rose-300 dark:border-rose-800 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white font-mono">
                  Deactivate User Group?
                </h4>
                <p className="text-xs text-slate-500 font-mono">Soft-deactivation preservation</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-sans">
              Are you sure you want to deactivate <strong className="text-slate-900 dark:text-white">"{deleteConfirmGroup.name}"</strong>? Group membership and audit logs will be preserved in the database.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmGroup(null)}
                className="px-4 py-2 rounded-lg text-xs font-mono font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                CANCEL
              </button>
              <ButtonLoader
                onClick={handleConfirmDelete}
                isLoading={isDeleting}
                loadingText="DEACTIVATING..."
                className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-rose-600 hover:bg-rose-500 transition-all shadow-[0_0_12px_rgba(225,29,72,0.4)] cursor-pointer"
              >
                CONFIRM DEACTIVATE
              </ButtonLoader>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
