import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Server,
  Layers,
  Boxes,
  GitFork,
  CheckSquare,
  Terminal,
  Activity,
  Sliders,
  History,
  Info,
} from 'lucide-react';
import { useTEM } from '../context/TEMContext';
import { provisioningService } from '../services/provisioningService';
import { ProvisioningRequest, ProvisioningLogItem } from '../types/provisioning';
import { ProvisioningHeader } from '../components/provisioning/detail/ProvisioningHeader';
import { LifecycleTimeline } from '../components/provisioning/detail/LifecycleTimeline';
import { OverviewTab } from '../components/provisioning/detail/OverviewTab';
import { ResourcesTab } from '../components/provisioning/detail/ResourcesTab';
import { SoftwareTab } from '../components/provisioning/detail/SoftwareTab';
import { DependenciesTab } from '../components/provisioning/detail/DependenciesTab';
import { ProvisioningPlanTab } from '../components/provisioning/detail/ProvisioningPlanTab';
import { ExecutionLogsTab } from '../components/provisioning/detail/ExecutionLogsTab';
import { HealthChecksTab } from '../components/provisioning/detail/HealthChecksTab';
import { ConfigurationTab } from '../components/provisioning/detail/ConfigurationTab';
import { AuditHistoryTab } from '../components/provisioning/detail/AuditHistoryTab';

type TabKey =
  | 'overview'
  | 'resources'
  | 'software'
  | 'dependencies'
  | 'plan'
  | 'logs'
  | 'health'
  | 'config'
  | 'audit';

export const ProvisioningDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useTEM();

  const [request, setRequest] = useState<ProvisioningRequest | null>(null);
  const [logs, setLogs] = useState<ProvisioningLogItem[]>([]);
  const [activeTab, setActiveTab] = useState<TabKey>('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [isActionLoading, setIsActionLoading] = useState(false);

  const loadDetail = async (silent = false) => {
    if (!id) return;
    if (!silent) setIsLoading(true);
    try {
      const [reqData, logData] = await Promise.all([
        provisioningService.getRequestById(id),
        provisioningService.getLogs(id),
      ]);
      if (reqData) {
        setRequest(reqData);
      }
      setLogs(logData);
    } catch (err: any) {
      if (!silent) {
        showToast?.(`Failed to load request details: ${err.message}`, 'error');
      }
    } finally {
      if (!silent) setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDetail();
  }, [id]);

  // Real-time SSE or Polling
  useEffect(() => {
    if (!id) return;

    // Subscribe to SSE events
    const unsubscribe = provisioningService.subscribeToEvents(id, (eventPayload) => {
      // Refresh on status or step change
      loadDetail(true);
    });

    // Fallback periodic poll if active
    const isRunning =
      request &&
      ['QUEUED', 'PROVISIONING', 'CONFIGURING', 'HEALTH_CHECK'].includes(request.status);

    let pollTimer: any = null;
    if (isRunning) {
      pollTimer = setInterval(() => {
        loadDetail(true);
      }, 2500);
    }

    return () => {
      unsubscribe();
      if (pollTimer) clearInterval(pollTimer);
    };
  }, [id, request?.status]);

  // Actions
  const handleApprove = async () => {
    if (!id) return;
    setIsActionLoading(true);
    try {
      await provisioningService.approveRequest(id, 'APPROVE', 'Manager Approval');
      showToast?.('Request approved. Ready for execution.', 'success');
      loadDetail();
    } catch (err: any) {
      showToast?.(`Approval failed: ${err.message}`, 'error');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleReject = async () => {
    if (!id) return;
    const comments = window.prompt('Please enter a rejection reason:');
    if (comments === null) return;
    setIsActionLoading(true);
    try {
      await provisioningService.approveRequest(id, 'REJECT', comments || 'Rejected by user');
      showToast?.('Request rejected.', 'info');
      loadDetail();
    } catch (err: any) {
      showToast?.(`Rejection failed: ${err.message}`, 'error');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleProvision = async () => {
    if (!id) return;
    setIsActionLoading(true);
    try {
      await provisioningService.triggerProvisioning(id);
      showToast?.('Provisioning started! Streaming logs...', 'success');
      setActiveTab('logs');
      loadDetail();
    } catch (err: any) {
      showToast?.(`Execution failed: ${err.message}`, 'error');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleRetry = async (stepId?: string) => {
    if (!id) return;
    setIsActionLoading(true);
    try {
      await provisioningService.retryRequest(id, stepId);
      showToast?.('Retrying step execution...', 'info');
      setActiveTab('logs');
      loadDetail();
    } catch (err: any) {
      showToast?.(`Retry failed: ${err.message}`, 'error');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleRollback = async () => {
    if (!id) return;
    if (!window.confirm('Are you sure you want to rollback this provisioning request? All partially allocated resources will be terminated.')) {
      return;
    }
    setIsActionLoading(true);
    try {
      await provisioningService.rollbackRequest(id);
      showToast?.('Rollback initiated.', 'info');
      loadDetail();
    } catch (err: any) {
      showToast?.(`Rollback failed: ${err.message}`, 'error');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleDecommission = async () => {
    if (!id) return;
    if (!window.confirm('Are you sure you want to decommission this environment? All allocated VM, storage, and IP assets will be released.')) {
      return;
    }
    setIsActionLoading(true);
    try {
      await provisioningService.decommissionRequest(id);
      showToast?.('Environment decommissioning in progress.', 'success');
      loadDetail();
    } catch (err: any) {
      showToast?.(`Decommission failed: ${err.message}`, 'error');
    } finally {
      setIsActionLoading(false);
    }
  };

  if (isLoading || !request) {
    return (
      <div className="p-12 text-center text-slate-400">
        <Activity className="w-8 h-8 animate-spin text-orange-500 mx-auto mb-3" />
        <p className="text-sm font-mono">Loading Provisioning Console...</p>
      </div>
    );
  }

  const TABS = [
    { key: 'overview', label: 'Overview', icon: Info },
    { key: 'resources', label: `Resources (${request.resources?.length || 0})`, icon: Server },
    { key: 'software', label: `Software (${request.software_stack?.length || 0})`, icon: Boxes },
    { key: 'dependencies', label: `Dependencies (${request.dependencies?.length || 0})`, icon: GitFork },
    { key: 'plan', label: `Provisioning Plan (${request.steps?.length || 0})`, icon: CheckSquare },
    { key: 'logs', label: `Execution Logs (${logs.length})`, icon: Terminal, pulse: ['PROVISIONING', 'CONFIGURING', 'HEALTH_CHECK'].includes(request.status) },
    { key: 'health', label: 'Health Checks', icon: Activity },
    { key: 'config', label: 'Configuration', icon: Sliders },
    { key: 'audit', label: `Audit History (${request.audits?.length || 0})`, icon: History },
  ];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Header & Toolbar */}
      <ProvisioningHeader
        request={request}
        onApprove={handleApprove}
        onReject={handleReject}
        onProvision={handleProvision}
        onRetry={handleRetry}
        onRollback={handleRollback}
        onDecommission={handleDecommission}
        isActionLoading={isActionLoading}
      />

      {/* Visual Lifecycle Timeline */}
      <LifecycleTimeline request={request} />

      {/* Navigation Tabs */}
      <div className="border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
        {TABS.map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.key;
          return (
            <button
              key={t.key}
              type="button"
              onClick={() => setActiveTab(t.key as TabKey)}
              className={`px-4 py-3 text-xs font-semibold flex items-center gap-2 border-b-2 transition-all shrink-0 select-none ${
                isActive
                  ? 'border-orange-500 text-orange-400 bg-orange-500/5 font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-850/50'
              }`}
            >
              <Icon className={`w-4 h-4 ${t.pulse ? 'text-orange-400 animate-pulse' : ''}`} />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      <div>
        {activeTab === 'overview' && <OverviewTab request={request} />}

        {activeTab === 'resources' && (
          <ResourcesTab resources={request.resources || []} />
        )}

        {activeTab === 'software' && (
          <SoftwareTab softwareStack={request.software_stack || []} />
        )}

        {activeTab === 'dependencies' && (
          <DependenciesTab dependencies={request.dependencies || []} />
        )}

        {activeTab === 'plan' && (
          <ProvisioningPlanTab
            steps={request.steps || []}
            onRetryStep={handleRetry}
            isActionLoading={isActionLoading}
          />
        )}

        {activeTab === 'logs' && (
          <ExecutionLogsTab
            logs={logs}
            isLoading={isLoading}
            onRefresh={() => loadDetail(true)}
          />
        )}

        {activeTab === 'health' && (
          <HealthChecksTab
            healthStatus={request.health_status}
            probes={request.health_check_results || []}
          />
        )}

        {activeTab === 'config' && (
          <ConfigurationTab configurationPayload={request.configuration_payload || {}} />
        )}

        {activeTab === 'audit' && (
          <AuditHistoryTab audits={request.audits || []} />
        )}
      </div>
    </div>
  );
};
