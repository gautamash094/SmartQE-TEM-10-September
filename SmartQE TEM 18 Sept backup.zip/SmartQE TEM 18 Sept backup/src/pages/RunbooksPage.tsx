import React, { useState } from 'react';
import { useTEM } from '../context/TEMContext';
import { RunbookModal } from '../components/features/RunbookModal';
import { Pagination } from '../components/common/Pagination';
import { CardSkeleton } from '../components/common/Skeleton';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { BookOpen, Play, Clock } from 'lucide-react';
import { Runbook } from '../types';

export const RunbooksPage: React.FC = () => {
  const { runbooks, isLoading } = useTEM();
  const [selectedRunbook, setSelectedRunbook] = useState<Runbook | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  const paginatedRunbooks = runbooks.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleLaunch = (rb: Runbook) => {
    setSelectedRunbook(rb);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
          AUTOMATION ENGINE
        </span>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">Runbooks</h1>
        <p className="text-sm text-slate-400 mt-1">
          Automated operational runbooks for environment drain, cache flushes, and diagnostics.
        </p>
      </div>

      {/* Grid of Runbooks */}
      {isLoading ? (
        <div className="space-y-4">
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 flex items-center justify-center shadow-xl">
            <LoadingSpinner size="md" variant="primary" />
          </div>
          <CardSkeleton count={4} className="grid grid-cols-1 md:grid-cols-2 gap-6" />
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {paginatedRunbooks.map((rb) => (
            <div
              key={rb.id}
              className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 hover:border-slate-700 p-6 rounded-lg transition-all shadow-xl flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-200 dark:border-slate-800 uppercase">
                    {rb.category}
                  </span>
                  <span className="text-xs font-mono text-amber-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> ~{rb.estimatedTimeMinutes} min
                  </span>
                </div>

                <h2 className="text-lg font-bold text-white mb-2">{rb.name}</h2>

                {/* Steps overview */}
                <div className="space-y-1.5 mt-3">
                  <p className="text-[10px] font-mono font-semibold text-slate-500 uppercase">
                    STEPS ({rb.steps.length}):
                  </p>
                  <ul className="text-xs font-mono text-slate-400 list-disc list-inside space-y-1">
                    {rb.steps.slice(0, 3).map((step, i) => (
                      <li key={i} className="truncate">
                        {step}
                      </li>
                    ))}
                    {rb.steps.length > 3 && (
                      <li className="text-[11px] text-slate-500 font-sans">
                        + {rb.steps.length - 3} more steps
                      </li>
                    )}
                  </ul>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800/80">
                <span className="text-[11px] font-mono text-slate-500">
                  Last executed: {rb.lastExecuted}
                </span>
                <button
                  onClick={() => handleLaunch(rb)}
                  className="flex items-center gap-2 px-4 py-2 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)]"
                >
                  <Play className="w-3.5 h-3.5 fill-current" /> EXECUTE
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
          <Pagination
            currentPage={currentPage}
            totalItems={runbooks.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(size) => {
              setPageSize(size);
              setCurrentPage(1);
            }}
            pageSizeOptions={[10, 20, 50]}
          />
        </div>
      </div>
    )}

      <RunbookModal
        runbook={selectedRunbook}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
};
