import React, { useState } from 'react';
import { useTEM } from '../context/TEMContext';
import { Sliders, Database, Bell, Save, RefreshCw } from 'lucide-react';

export const SystemPreferencesPage: React.FC = () => {
  const { showToast } = useTEM();

  const [fastApiEndpoint, setFastApiEndpoint] = useState<string>('http://localhost:8000/api/v1');
  const [syncInterval, setSyncInterval] = useState<number>(30);
  const [enableAlerts, setEnableAlerts] = useState<boolean>(true);
  const [defaultRegion, setDefaultRegion] = useState<string>('us-west-2');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const handleSaveSystemConfig = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      showToast('System preferences and FastAPI endpoint configuration saved successfully!', 'success');
    }, 400);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      <div>
        <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
          SETTINGS &bull; CONFIGURATION
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1 flex items-center gap-3">
          <Sliders className="w-7 h-7 text-orange-500" />
          <span>System & API Preferences</span>
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Configure FastAPI backend integration endpoints, background synchronization frequency, and real-time incident alerting triggers.
        </p>
      </div>

      <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveSystemConfig} className="space-y-6">
        {/* Backend API Integration */}
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-6 space-y-4 shadow-sm">
          <div className="flex items-center gap-3 border-b border-slate-200 dark:border-slate-800/80 pb-3">
            <Database className="w-5 h-5 text-orange-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">FastAPI Backend Integration</h2>
          </div>

          <div>
            <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1.5 uppercase">
              FASTAPI BASE URL ENDPOINT
            </label>
            <input autoComplete="off" data-lpignore="true"
              type="text"
              value={fastApiEndpoint}
              onChange={(e) => setFastApiEndpoint(e.target.value)}
              className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
            <p className="text-[11px] font-mono text-slate-500 mt-1">
              Default: http://localhost:8000/api/v1 (with automatic local state failover fallback).
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div>
              <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1.5 uppercase">
                SYNC REFRESH INTERVAL (SECONDS)
              </label>
              <input autoComplete="off" data-lpignore="true"
                type="number"
                value={syncInterval}
                onChange={(e) => setSyncInterval(parseInt(e.target.value, 10))}
                className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1.5 uppercase">
                DEFAULT ENVIRONMENT REGION
              </label>
              <select
                value={defaultRegion}
                onChange={(e) => setDefaultRegion(e.target.value)}
                className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                <option value="us-west-2">us-west-2 (Oregon)</option>
                <option value="us-east-1">us-east-1 (N. Virginia)</option>
                <option value="eu-west-2">eu-west-2 (London)</option>
                <option value="ap-south-1">ap-south-1 (Mumbai)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Notifications & Alerting */}
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-6 space-y-4 shadow-sm">
          <div className="flex items-center gap-3 border-b border-slate-200 dark:border-slate-800/80 pb-3">
            <Bell className="w-5 h-5 text-orange-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Alerts & Notifications</h2>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Enable Real-Time SEV1/SEV2 Alerts</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Receive instant toast banners when high severity environment incidents are raised.
              </p>
            </div>
            <input
              type="checkbox"
              checked={enableAlerts}
              onChange={(e) => setEnableAlerts(e.target.checked)}
              className="w-5 h-5 accent-orange-500 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-2 px-6 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_16px_rgba(249,115,22,0.35)] cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4" /> {isSaving ? 'SAVING...' : 'SAVE PREFERENCES'}
          </button>
        </div>
      </form>
    </div>
  );
};
