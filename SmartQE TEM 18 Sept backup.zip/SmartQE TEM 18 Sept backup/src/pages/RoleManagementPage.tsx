import React, { useState, useEffect, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import {
  Shield,
  Plus,
  Search,
  ArrowUp,
  ArrowDown,
  Edit2,
  Trash2,
  Check,
  AlertCircle,
  Building2,
  UserCheck,
  Crown,
  Layers,
  Save,
  RefreshCw,
  Info,
  Lock
} from 'lucide-react';
import { roleService, Role, AppConfig } from '../services/roleService';
import { BusinessUnit, portfolioService } from '../services/portfolioService';
import { Pagination } from '../components/common/Pagination';
import { TableSkeleton } from '../components/common/Skeleton';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { ButtonLoader } from '../components/common/ButtonLoader';

export const RoleManagementPage: React.FC = () => {
  const { showToast } = useTEM();

  // State
  const [roles, setRoles] = useState<Role[]>([]);
  const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>([]);
  const [appConfig, setAppConfig] = useState<AppConfig>({});
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSavingConfig, setIsSavingConfig] = useState<boolean>(false);
  const [isSavingRole, setIsSavingRole] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Pagination
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Config Form
  const [selectedDefaultRoleId, setSelectedDefaultRoleId] = useState<string>('');
  const [selectedDefaultBUId, setSelectedDefaultBUId] = useState<string>('');

  // Role Modal
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [roleForm, setRoleForm] = useState({
    name: '',
    description: '',
    isActive: true
  });
  const [formError, setFormError] = useState<string>('');

  // Delete Confirmation Modal
  const [deleteConfirmRole, setDeleteConfirmRole] = useState<Role | null>(null);

  // Load initial data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [fetchedRoles, fetchedBUs, fetchedConfig] = await Promise.all([
        roleService.getRoles(),
        portfolioService.getBusinessUnits(),
        roleService.getAppConfig()
      ]);

      setRoles(fetchedRoles);
      setBusinessUnits(fetchedBUs);
      setAppConfig(fetchedConfig);

      if (fetchedConfig.defaultRoleId) {
        setSelectedDefaultRoleId(fetchedConfig.defaultRoleId);
      } else if (fetchedRoles.length > 0) {
        setSelectedDefaultRoleId(fetchedRoles[0].id);
      }

      if (fetchedConfig.defaultBusinessUnitId) {
        setSelectedDefaultBUId(fetchedConfig.defaultBusinessUnitId);
      }
    } catch (err: any) {
      showToast('Error loading role configuration: ' + err.message, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filter only active roles for selection
  const activeRoles = useMemo(() => {
    return roles.filter(r => r.isActive);
  }, [roles]);

  // Filter only active Business Units from Entity Management
  const activeBusinessUnits = useMemo(() => {
    return businessUnits.filter(b => b.isActive !== false && b.status !== 'INACTIVE');
  }, [businessUnits]);

  // Filtered roles for search
  const filteredRoles = useMemo(() => {
    if (!searchQuery.trim()) return roles;
    const q = searchQuery.toLowerCase().trim();
    return roles.filter(
      r =>
        r.name.toLowerCase().includes(q) ||
        (r.description && r.description.toLowerCase().includes(q))
    );
  }, [roles, searchQuery]);

  // Paginated roles
  const paginatedRoles = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredRoles.slice(start, start + pageSize);
  }, [filteredRoles, page, pageSize]);

  // Save Application Defaults
  const handleSaveAppConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingConfig(true);
    try {
      const targetRole = roles.find(r => r.id === selectedDefaultRoleId);
      const targetBU = businessUnits.find(b => b.id === selectedDefaultBUId);

      const updated = await roleService.updateAppConfig({
        defaultRoleId: selectedDefaultRoleId || undefined,
        defaultRoleName: targetRole?.name || undefined,
        defaultBusinessUnitId: selectedDefaultBUId || undefined,
        defaultBusinessUnitName: targetBU?.name || undefined
      });

      setAppConfig(updated);
      showToast('Application Default Role & Business Unit configuration saved successfully!', 'success');
    } catch (err: any) {
      showToast('Failed to save configuration: ' + err.message, 'error');
    } finally {
      setIsSavingConfig(false);
    }
  };

  // Open Create Role Modal
  const handleOpenCreate = () => {
    setEditingRole(null);
    setRoleForm({ name: '', description: '', isActive: true });
    setFormError('');
    setModalOpen(true);
  };

  // Open Edit Role Modal
  const handleOpenEdit = (role: Role) => {
    setEditingRole(role);
    setRoleForm({
      name: role.name,
      description: role.description || '',
      isActive: role.isActive
    });
    setFormError('');
    setModalOpen(true);
  };

  // Save Role (Create or Edit)
  const handleSaveRole = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const cleanName = roleForm.name.trim();
    if (!cleanName) {
      setFormError('Role Name is mandatory and cannot be empty or contain only spaces.');
      return;
    }

    // Duplicate check
    const duplicate = roles.some(
      r => (!editingRole || r.id !== editingRole.id) && r.name.toLowerCase() === cleanName.toLowerCase()
    );
    if (duplicate) {
      setFormError('A role with this name already exists.');
      return;
    }

    setIsSavingRole(true);
    try {
      if (editingRole) {
        const updated = await roleService.updateRole(editingRole.id, {
          name: cleanName,
          description: roleForm.description.trim(),
          isActive: roleForm.isActive
        });
        setRoles(prev =>
          prev.map(r => (r.id === editingRole.id ? updated : r)).sort((a, b) => a.roleOrder - b.roleOrder)
        );
        showToast(`Role '${updated.name}' updated successfully!`, 'success');
      } else {
        const created = await roleService.createRole({
          name: cleanName,
          description: roleForm.description.trim(),
          isActive: roleForm.isActive
        });
        setRoles(prev => [...prev, created].sort((a, b) => a.roleOrder - b.roleOrder));
        showToast(`Role '${created.name}' created and added to hierarchy!`, 'success');
      }
      setModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to save role.');
    } finally {
      setIsSavingRole(false);
    }
  };

  // Toggle Role Status
  const handleToggleStatus = async (role: Role) => {
    if (role.isSystem) {
      showToast('The default system role (Super Admin) cannot be deactivated.', 'error');
      return;
    }

    try {
      const updatedList = await roleService.toggleRole(role.id);
      setRoles(updatedList);
      const newActive = updatedList.find(r => r.id === role.id)?.isActive;
      showToast(`Role '${role.name}' ${newActive ? 'activated' : 'deactivated'}.`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle role status.', 'error');
    }
  };

  // Delete Role
  const handleDeleteRole = async () => {
    if (!deleteConfirmRole) return;
    if (deleteConfirmRole.isSystem) {
      showToast('The default system role (Super Admin) cannot be deleted.', 'error');
      setDeleteConfirmRole(null);
      return;
    }

    try {
      const updatedList = await roleService.deleteRole(deleteConfirmRole.id);
      setRoles(updatedList);
      showToast(`Role '${deleteConfirmRole.name}' removed from system.`, 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to delete role.', 'error');
    } finally {
      setDeleteConfirmRole(null);
    }
  };

  // Move Role Up in Order
  const handleMoveUp = async (index: number) => {
    if (index <= 0) return;
    const currentList = [...roles];
    const prevItem = currentList[index - 1];
    const currItem = currentList[index];

    // Swap roleOrder
    const prevOrder = prevItem.roleOrder;
    const currOrder = currItem.roleOrder;

    prevItem.roleOrder = currOrder;
    currItem.roleOrder = prevOrder;

    currentList[index - 1] = currItem;
    currentList[index] = prevItem;

    setRoles([...currentList]);

    try {
      await roleService.reorderRoles([
        { id: currItem.id, roleOrder: currItem.roleOrder },
        { id: prevItem.id, roleOrder: prevItem.roleOrder }
      ]);
      showToast(`Role hierarchy updated: '${currItem.name}' is now #${currItem.roleOrder}`, 'info');
    } catch (err: any) {
      showToast('Failed to save order: ' + err.message, 'error');
      loadData();
    }
  };

  // Move Role Down in Order
  const handleMoveDown = async (index: number) => {
    if (index >= roles.length - 1) return;
    const currentList = [...roles];
    const currItem = currentList[index];
    const nextItem = currentList[index + 1];

    // Swap roleOrder
    const currOrder = currItem.roleOrder;
    const nextOrder = nextItem.roleOrder;

    currItem.roleOrder = nextOrder;
    nextItem.roleOrder = currOrder;

    currentList[index] = nextItem;
    currentList[index + 1] = currItem;

    setRoles([...currentList]);

    try {
      await roleService.reorderRoles([
        { id: currItem.id, roleOrder: currItem.roleOrder },
        { id: nextItem.id, roleOrder: nextItem.roleOrder }
      ]);
      showToast(`Role hierarchy updated: '${currItem.name}' is now #${currItem.roleOrder}`, 'info');
    } catch (err: any) {
      showToast('Failed to save order: ' + err.message, 'error');
      loadData();
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/60 px-2 py-0.5 rounded border border-orange-200 dark:border-orange-800/80">
              SETTINGS &bull; ROLE MANAGEMENT
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Role Management
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Define, prioritize, and manage access roles, role hierarchy, and default system assignments.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadData}
            disabled={isLoading}
            className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors shadow-sm"
            title="Refresh Roles"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-500' : ''}`} />
          </button>
          <button
            onClick={handleOpenCreate}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 transition-all shadow-[0_0_16px_rgba(249,115,22,0.35)]"
          >
            <Plus className="w-4 h-4" /> CREATE ROLE
          </button>
        </div>
      </div>

      {/* 2. KPI METRICS CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Roles */}
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-600 dark:text-orange-400 shrink-0">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-mono text-slate-500 dark:text-slate-400">TOTAL ROLES</p>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white font-mono mt-0.5">
              {roles.length}
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {activeRoles.length} Active in hierarchy
            </p>
          </div>
        </div>

        {/* Card 2: Default System Role */}
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0">
            <Crown className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-mono text-slate-500 dark:text-slate-400">DEFAULT SYSTEM ROLE</p>
            <h3 className="text-base font-bold text-slate-900 dark:text-white truncate mt-0.5">
              Super Admin
            </h3>
            <span className="inline-flex items-center gap-1 text-[10px] font-mono text-amber-600 dark:text-amber-400 font-semibold">
              <Lock className="w-2.5 h-2.5" /> Order #1 (Highest)
            </span>
          </div>
        </div>

        {/* Card 3: Configured Default Role */}
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
            <UserCheck className="w-6 h-6" />
          </div>
          <div className="truncate">
            <p className="text-xs font-mono text-slate-500 dark:text-slate-400">CONFIGURED DEFAULT ROLE</p>
            <h3 className="text-base font-bold text-slate-900 dark:text-white truncate mt-0.5">
              {appConfig.defaultRoleName || roles.find(r => r.id === selectedDefaultRoleId)?.name || 'Not Configured'}
            </h3>
            <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">Auto-assigned role</p>
          </div>
        </div>

        {/* Card 4: Configured Default BU */}
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
            <Building2 className="w-6 h-6" />
          </div>
          <div className="truncate">
            <p className="text-xs font-mono text-slate-500 dark:text-slate-400">CONFIGURED DEFAULT BU</p>
            <h3 className="text-base font-bold text-slate-900 dark:text-white truncate mt-0.5">
              {appConfig.defaultBusinessUnitName || businessUnits.find(b => b.id === selectedDefaultBUId)?.name || 'Not Configured'}
            </h3>
            <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">Entity Management</p>
          </div>
        </div>
      </div>

      {/* 3. APPLICATION DEFAULTS CONFIGURATION (SUPER ADMIN / GLOBAL) */}
      <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800/80 pb-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-orange-500/10 text-orange-600 dark:text-orange-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Configure Application Defaults
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Super Admin configuration for default role assignment and business unit scoping.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono bg-slate-100 dark:bg-slate-800/60 px-2.5 py-1 rounded-md">
            <Info className="w-3.5 h-3.5 text-orange-500 shrink-0" />
            Only active roles and business units are selectable
          </div>
        </div>

        <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveAppConfig} className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
          {/* Default Role Dropdown */}
          <div className="space-y-1.5">
            <label className="block text-xs font-mono font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Default Role <span className="text-orange-500">*</span>
            </label>
            <select
              value={selectedDefaultRoleId}
              onChange={(e) => setSelectedDefaultRoleId(e.target.value)}
              className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2.5 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all shadow-inner"
            >
              <option value="">-- Select Default Role --</option>
              {activeRoles.map((role) => (
                <option key={role.id} value={role.id}>
                  {role.name} {role.isSystem ? '(System Default)' : `(Order #${role.roleOrder})`}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
              Selected Default Role is retrieved dynamically and stored in the database.
            </p>
          </div>

          {/* Default Business Unit Dropdown */}
          <div className="space-y-1.5">
            <label className="block text-xs font-mono font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Default Business Unit (BU)
            </label>
            <select
              value={selectedDefaultBUId}
              onChange={(e) => setSelectedDefaultBUId(e.target.value)}
              className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2.5 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all shadow-inner"
            >
              <option value="">-- Select Business Unit --</option>
              {activeBusinessUnits.map((bu) => (
                <option key={bu.id} value={bu.id}>
                  {bu.name} ({bu.code})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
              Dynamic records from Entity Management. No duplicate records created.
            </p>
          </div>

          <div className="md:col-span-2 flex justify-end pt-2">
            <ButtonLoader
              type="submit"
              isLoading={isSavingConfig}
              loadingText="SAVING CONFIGURATION..."
              icon={<Save className="w-4 h-4" />}
              className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 disabled:opacity-50 transition-all shadow-[0_0_12px_rgba(249,115,22,0.3)]"
            >
              SAVE CONFIGURATION
            </ButtonLoader>
          </div>
        </form>
      </div>

      {/* 4. ROLE HIERARCHY & MANAGEMENT TABLE */}
      <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl shadow-sm overflow-hidden">
        {/* Table Header Controls */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Roles & Hierarchy Priority</span>
              <span className="text-xs font-mono bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full text-slate-600 dark:text-slate-400">
                {roles.length} total
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Order represents role priority in TEM. Use the arrow controls to define hierarchy.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input autoComplete="off" data-lpignore="true"
                type="text"
                placeholder="Search roles..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setPage(1);
                }}
                className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
          </div>
        </div>

        {/* Roles Table */}
        {isLoading ? (
          <div className="p-5 space-y-4">
            <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 flex items-center justify-center shadow-xl">
              <LoadingSpinner size="md" variant="primary" />
            </div>
            <TableSkeleton rows={4} columns={6} />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800/80 text-[10px] font-mono uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  <th className="py-3.5 px-4 font-semibold w-24">Order</th>
                  <th className="py-3.5 px-4 font-semibold">Role Name</th>
                  <th className="py-3.5 px-4 font-semibold">Description</th>
                  <th className="py-3.5 px-4 font-semibold">Classification</th>
                  <th className="py-3.5 px-4 font-semibold">Status</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 font-sans">
                {paginatedRoles.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400 dark:text-slate-500">
                      <Shield className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                      <p className="font-mono text-sm font-semibold">No roles found matching your criteria</p>
                      <p className="text-xs mt-1">Create a new role to get started.</p>
                    </td>
                  </tr>
                ) : (
                paginatedRoles.map((role) => {
                  const globalIndex = roles.findIndex(r => r.id === role.id);
                  const isTop = globalIndex === 0;
                  const isBottom = globalIndex === roles.length - 1;

                  return (
                    <tr
                      key={role.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors group"
                    >
                      {/* 1. ORDER & MOVE BUTTONS */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                              role.roleOrder === 1
                                ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/40 shadow-sm'
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            #{role.roleOrder}
                          </span>

                          <div className="flex flex-col gap-0.5">
                            <button
                              type="button"
                              onClick={() => handleMoveUp(globalIndex)}
                              disabled={isTop}
                              className="p-0.5 rounded text-slate-400 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-20 disabled:hover:bg-transparent disabled:hover:text-slate-400 transition-colors"
                              title="Increase Priority (Move Up)"
                            >
                              <ArrowUp className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleMoveDown(globalIndex)}
                              disabled={isBottom}
                              className="p-0.5 rounded text-slate-400 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-20 disabled:hover:bg-transparent disabled:hover:text-slate-400 transition-colors"
                              title="Decrease Priority (Move Down)"
                            >
                              <ArrowDown className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </td>

                      {/* 2. ROLE NAME */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 ${
                              role.isSystem
                                ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                                : 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20'
                            }`}
                          >
                            {role.isSystem ? <Crown className="w-3.5 h-3.5" /> : <Shield className="w-3.5 h-3.5" />}
                          </div>
                          <div>
                            <span className="font-semibold text-slate-900 dark:text-white text-sm">
                              {role.name}
                            </span>
                            {selectedDefaultRoleId === role.id && (
                              <span className="ml-2 inline-flex items-center gap-0.5 text-[9px] font-mono px-1.5 py-0.2 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
                                <Check className="w-2.5 h-2.5" /> App Default
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* 3. DESCRIPTION */}
                      <td className="py-3.5 px-4 max-w-xs text-slate-600 dark:text-slate-300 truncate">
                        {role.description || <span className="text-slate-400 italic">No description</span>}
                      </td>

                      {/* 4. CLASSIFICATION */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {role.isSystem ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                            <Lock className="w-2.5 h-2.5" /> System Default
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                            Custom Role
                          </span>
                        )}
                      </td>

                      {/* 5. STATUS & TOGGLE */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(role)}
                          disabled={role.isSystem}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-semibold transition-all ${
                            role.isActive
                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20'
                              : 'bg-slate-500/10 text-slate-500 dark:text-slate-400 border border-slate-500/30 hover:bg-slate-500/20'
                          } ${role.isSystem ? 'cursor-not-allowed opacity-90' : 'cursor-pointer'}`}
                          title={role.isSystem ? 'Super Admin cannot be deactivated' : 'Click to toggle active/inactive'}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              role.isActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                            }`}
                          />
                          {role.isActive ? 'ACTIVE' : 'INACTIVE'}
                        </button>
                      </td>

                      {/* 6. ACTIONS */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleOpenEdit(role)}
                            className="p-1.5 rounded-md text-slate-500 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            title="Edit Role"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {role.isSystem ? (
                            <span
                              className="p-1.5 text-slate-300 dark:text-slate-700 cursor-not-allowed"
                              title="System default role cannot be deleted"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </span>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirmRole(role)}
                              className="p-1.5 rounded-md text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                              title="Delete Role"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/30 flex items-center justify-between">
          <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
            Showing {paginatedRoles.length} of {filteredRoles.length} roles
          </span>
          <Pagination
            currentPage={page}
            totalItems={filteredRoles.length}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setPage(1);
            }}
            pageSizeOptions={[10, 20, 50]}
          />
        </div>
      </div>

      {/* 5. CREATE / EDIT ROLE MODAL */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between p-5 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-orange-500/10 text-orange-600 dark:text-orange-400">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {editingRole ? 'Edit Role' : 'Create New Role'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {editingRole ? 'Update role properties' : 'Define a new access role'}
                  </p>
                </div>
              </div>
            </div>

            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveRole} className="p-5 space-y-4">
              {formError && (
                <div className="flex items-start gap-2.5 p-3 rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Role Name */}
              <div>
                <label className="block text-xs font-mono font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Role Name <span className="text-orange-500">*</span>
                </label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  required
                  placeholder="e.g. Environment Manager, QA Lead"
                  value={roleForm.name}
                  onChange={(e) => {
                    setRoleForm(prev => ({ ...prev, name: e.target.value }));
                    if (formError) setFormError('');
                  }}
                  className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent font-medium"
                />
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono mt-1">
                  Must be unique across the application. Empty strings or spaces only are not allowed.
                </p>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-mono font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Description <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <textarea
                  rows={3}
                  placeholder="Responsible for managing test environments, reservations, and deployments..."
                  value={roleForm.description}
                  onChange={(e) => setRoleForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700 rounded-lg px-3.5 py-2 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                />
              </div>

              {/* Active Status */}
              <div className="flex items-center justify-between pt-1">
                <div>
                  <h4 className="text-xs font-semibold text-slate-900 dark:text-white">Active Status</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                    Only active roles appear in role selection dropdowns.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={roleForm.isActive}
                  disabled={editingRole?.isSystem}
                  onChange={(e) => setRoleForm(prev => ({ ...prev, isActive: e.target.checked }))}
                  className="w-4 h-4 accent-orange-500 rounded cursor-pointer"
                />
              </div>

              {/* Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-mono font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  CANCEL
                </button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingRole}
                  loadingText={editingRole ? 'UPDATING ROLE...' : 'SAVING ROLE...'}
                  icon={<Save className="w-3.5 h-3.5" />}
                  className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 disabled:opacity-50 transition-all shadow-[0_0_12px_rgba(249,115,22,0.3)]"
                >
                  {editingRole ? 'UPDATE ROLE' : 'SAVE ROLE'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. DELETE CONFIRMATION MODAL */}
      {deleteConfirmRole && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl max-w-md w-full p-5 space-y-4">
            <div className="flex items-center gap-3 text-red-600 dark:text-red-400">
              <div className="p-2 rounded-lg bg-red-500/10 border border-red-500/20">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Delete Role</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">This action cannot be undone.</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              Are you sure you want to permanently delete the role{' '}
              <strong className="text-slate-900 dark:text-white font-mono font-bold">
                "{deleteConfirmRole.name}"
              </strong>
              ?
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmRole(null)}
                className="px-4 py-2 rounded-lg text-xs font-mono font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                CANCEL
              </button>
              <button
                type="button"
                onClick={handleDeleteRole}
                className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-red-600 hover:bg-red-500 transition-colors shadow-sm"
              >
                CONFIRM DELETE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
