import React, { useState, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import { aiIntelligenceService } from '../services/aiIntelligenceService';
import {
  ForecastHorizon,
  WhatIfScenarioInput,
  ConflictRiskLevel,
  PredictiveHeatmapCell,
} from '../types/aiIntelligence';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { CardSkeleton } from '../components/common/Skeleton';
import {
  BrainCircuit,
  Sparkles,
  TrendingUp,
  AlertTriangle,
  Calendar,
  Layers,
  Building2,
  Sliders,
  CheckCircle2,
  HelpCircle,
  BarChart3,
  Flame,
  ShieldAlert,
  ArrowRight,
  RefreshCw,
  Zap,
  Server,
  Activity,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';

export const AIPredictiveDemandPage: React.FC = () => {
  const { environmentProfiles, bookings, businessUnits, incidents, releases, showToast, isLoading } = useTEM();

  // Active Tab: 'FORECAST' | 'HEATMAP' | 'WHAT_IF' | 'RECOMMENDATIONS'
  const [activeTab, setActiveTab] = useState<'FORECAST' | 'HEATMAP' | 'WHAT_IF' | 'RECOMMENDATIONS'>('FORECAST');

  // Forecast Horizon Toggle
  const [horizon, setHorizon] = useState<ForecastHorizon>('30d');

  // Dimension Filter: 'BU' | 'ACCOUNT' | 'TIER' | 'ENV_TYPE'
  const [dimensionFilter, setDimensionFilter] = useState<'BU' | 'ACCOUNT' | 'TIER' | 'ENV_TYPE'>('BU');

  // What-If Scenario State
  const [scenarioInput, setScenarioInput] = useState<WhatIfScenarioInput>({
    demandGrowthPercentage: 20,
    offlineEnvironmentIds: [],
    additionalReleaseCount: 1,
    convertAllToDisruptive: false,
    maintenanceWindowHours: 0,
  });

  // Selected Heatmap Cell Modal state
  const [selectedCell, setSelectedCell] = useState<PredictiveHeatmapCell | null>(null);

  // Compute Demand Forecast
  const demandForecast = useMemo(() => {
    return aiIntelligenceService.generateDemandForecast(horizon, environmentProfiles, bookings, businessUnits, releases);
  }, [horizon, environmentProfiles, bookings, businessUnits, releases]);

  // Compute Predictive Heatmap
  const heatmapCells = useMemo(() => {
    return aiIntelligenceService.generatePredictiveHeatmap(environmentProfiles, bookings, releases, incidents);
  }, [environmentProfiles, bookings, releases, incidents]);

  // Compute What-If Scenario Result
  const scenarioResult = useMemo(() => {
    return aiIntelligenceService.runWhatIfScenario(scenarioInput, environmentProfiles, bookings, releases, businessUnits);
  }, [scenarioInput, environmentProfiles, bookings, releases, businessUnits]);

  // Compute Proactive Alerts & Capacity Recommendations
  const proactiveAlerts = useMemo(() => {
    return aiIntelligenceService.getProactiveAlerts(environmentProfiles, bookings, incidents, releases);
  }, [environmentProfiles, bookings, incidents, releases]);

  const capacityRecommendations = useMemo(() => {
    return aiIntelligenceService.getCapacityRecommendations(demandForecast);
  }, [demandForecast]);

  // Count high risk cells in heatmap
  const highRiskEnvCount = useMemo(() => {
    const highRiskIds = new Set<string>();
    heatmapCells.forEach((c) => {
      if (c.riskLevel === 'HIGH' || c.riskLevel === 'VERY_HIGH') {
        highRiskIds.add(c.environmentId);
      }
    });
    return highRiskIds.size;
  }, [heatmapCells]);

  const toggleOfflineEnvInScenario = (envId: string) => {
    setScenarioInput((prev) => {
      const exists = prev.offlineEnvironmentIds.includes(envId);
      return {
        ...prev,
        offlineEnvironmentIds: exists
          ? prev.offlineEnvironmentIds.filter((id) => id !== envId)
          : [...prev.offlineEnvironmentIds, envId],
      };
    });
  };

  const submitFeedback = (recommendationId: string, isPositive: boolean) => {
    aiIntelligenceService.logAIFeedback({
      id: `fb-${Date.now()}`,
      timestamp: new Date().toISOString(),
      predictionId: recommendationId,
      userDecision: isPositive ? 'ACCEPTED' : 'REJECTED',
      targetEnvironmentId: 'general',
      chosenEnvironmentId: 'general',
    });
    showToast(isPositive ? 'Thank you! AI model feedback recorded.' : 'Feedback recorded. AI recommendation models will adjust.', isPositive ? 'success' : 'info');
  };

  // Render Risk Badge
  const renderRiskBadge = (riskLevel: ConflictRiskLevel) => {
    switch (riskLevel) {
      case 'VERY_HIGH':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-950 text-red-400 border border-red-800 animate-pulse">VERY HIGH</span>;
      case 'HIGH':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-orange-950 text-orange-400 border border-orange-800">HIGH RISK</span>;
      case 'MEDIUM':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950 text-amber-300 border border-amber-800">MEDIUM</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">LOW RISK</span>;
    }
  };

  return (
    <div className="space-y-8 w-full min-w-0 font-sans">
      {/* 1. Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              PREDICTIVE INTELLIGENCE LAYER
            </span>
            <span className="px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/40 text-[10px] font-mono font-bold flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> AI MODEL: ONLINE
            </span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <BrainCircuit className="w-8 h-8 text-orange-400" /> AI Conflict Intelligence & Demand
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Predict schedule collisions, forecast capacity bottlenecks, and optimize environment allocation.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-900 border border-slate-200 dark:border-slate-800 rounded px-3 py-1.5 text-xs font-mono text-slate-300 flex items-center gap-2">
            <span className="text-slate-500">CONFIDENCE:</span>
            <span className="font-bold text-emerald-400">HIGH (94.2%)</span>
          </div>
          <button
            onClick={() => showToast('AI Predictive Model Refreshed!', 'info')}
            className="px-3.5 py-1.5 rounded bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-800 text-xs font-mono font-bold text-white transition-colors flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5 text-orange-400" /> RE-RUN MODELS
          </button>
        </div>
      </div>

      {/* 2. Top Summary KPI Cards */}
      {isLoading ? (
        <div className="space-y-4">
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 flex items-center justify-center shadow-xl">
            <LoadingSpinner size="md" variant="primary" />
          </div>
          <CardSkeleton count={4} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Total Predicted Demand */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg shadow-lg">
            <div className="flex items-center justify-between text-slate-400 mb-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider">PREDICTED DEMAND ({horizon})</span>
              <TrendingUp className="w-5 h-5 text-blue-400" />
            </div>
            <div className="text-3xl font-extrabold text-white font-mono">{demandForecast.totalPredictedDemand}</div>
            <p className="text-xs font-mono text-blue-400 mt-2 flex items-center gap-1">
              <span>+24.5% vs previous window</span>
            </p>
          </div>

        {/* Card 2: Total Available Capacity */}
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider">AVAILABLE CAPACITY</span>
            <Server className="w-5 h-5 text-emerald-400" />
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">{demandForecast.totalAvailableCapacity}</div>
          <p className="text-xs font-mono text-emerald-400 mt-2">
            {environmentProfiles.length} ACTIVE PROFILES
          </p>
        </div>

        {/* Card 3: Predicted Capacity Shortage */}
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider">PREDICTED SHORTAGE</span>
            <AlertTriangle className="w-5 h-5 text-red-400" />
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">{demandForecast.totalCapacityShortage}</div>
          <p className="text-xs font-mono text-red-400 mt-2">
            PEAK: {demandForecast.peakPeriodLabel}
          </p>
        </div>

        {/* Card 4: High-Risk Environments */}
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider">HIGH CONFLICT ENVS</span>
            <Flame className="w-5 h-5 text-orange-400" />
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">{highRiskEnvCount}</div>
          <p className="text-xs font-mono text-orange-400 mt-2">
            REQUIRES RE-BALANCING
          </p>
        </div>
      </div>
      )}

      {/* 3. Sub-Tab Navigation Bar */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 font-mono text-xs">
        <button
          onClick={() => setActiveTab('FORECAST')}
          className={`flex items-center gap-2 px-4 py-2 rounded.md font-bold transition-all ${
            activeTab === 'FORECAST'
              ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <BarChart3 className="w-4 h-4" /> DEMAND VS CAPACITY FORECAST
        </button>

        <button
          onClick={() => setActiveTab('HEATMAP')}
          className={`flex items-center gap-2 px-4 py-2 rounded.md font-bold transition-all ${
            activeTab === 'HEATMAP'
              ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Calendar className="w-4 h-4" /> PREDICTIVE CONFLICT HEATMAP
        </button>

        <button
          onClick={() => setActiveTab('WHAT_IF')}
          className={`flex items-center gap-2 px-4 py-2 rounded.md font-bold transition-all ${
            activeTab === 'WHAT_IF'
              ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Sliders className="w-4 h-4" /> WHAT-IF SCENARIO SIMULATOR
        </button>

        <button
          onClick={() => setActiveTab('RECOMMENDATIONS')}
          className={`flex items-center gap-2 px-4 py-2 rounded.md font-bold transition-all ${
            activeTab === 'RECOMMENDATIONS'
              ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Zap className="w-4 h-4" /> PROACTIVE ALERTS & RECOMMENDATIONS
        </button>
      </div>

      {/* 4. TAB CONTENT 1: DEMAND VS CAPACITY FORECAST */}
      {activeTab === 'FORECAST' && (
        <div className="space-y-6">
          {/* Controls: Horizon & Dimension selection */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-lg">
            <div className="flex items-center gap-2 font-mono text-xs">
              <span className="text-slate-400 uppercase font-bold">FORECAST HORIZON:</span>
              {(['7d', '14d', '30d', '90d'] as ForecastHorizon[]).map((h) => (
                <button
                  key={h}
                  onClick={() => setHorizon(h)}
                  className={`px-3 py-1 rounded font-bold transition-all ${
                    horizon === h
                      ? 'bg-orange-600 text-white shadow-sm'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {h.toUpperCase()}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 font-mono text-xs">
              <span className="text-slate-400 uppercase font-bold">BREAKDOWN BY:</span>
              <button
                onClick={() => setDimensionFilter('BU')}
                className={`px-3 py-1 rounded font-bold ${
                  dimensionFilter === 'BU' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                BUSINESS UNIT
              </button>
              <button
                onClick={() => setDimensionFilter('ACCOUNT')}
                className={`px-3 py-1 rounded font-bold ${
                  dimensionFilter === 'ACCOUNT' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                ACCOUNT
              </button>
              <button
                onClick={() => setDimensionFilter('TIER')}
                className={`px-3 py-1 rounded font-bold ${
                  dimensionFilter === 'TIER' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                TIER
              </button>
              <button
                onClick={() => setDimensionFilter('ENV_TYPE')}
                className={`px-3 py-1 rounded font-bold ${
                  dimensionFilter === 'ENV_TYPE' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                ENV TYPE
              </button>
            </div>
          </div>

          {/* Time Series Graph Component */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-lg space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-orange-400" /> Time-Series Demand vs Available Capacity ({horizon})
              </h3>
              <div className="flex items-center gap-4 text-xs font-mono">
                <span className="flex items-center gap-1.5 text-blue-400">
                  <span className="w-3 h-3 rounded bg-blue-500 inline-block" /> Predicted Demand
                </span>
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="w-3 h-3 rounded bg-emerald-500 inline-block" /> Available Capacity
                </span>
                <span className="flex items-center gap-1.5 text-red-400">
                  <span className="w-3 h-3 rounded bg-red-500 inline-block" /> Capacity Shortage Risk
                </span>
              </div>
            </div>

            {/* Custom SVG Bar Chart */}
            <div className="w-full overflow-x-auto pt-14 pb-2">
              <div className="min-w-[700px] h-72 flex items-end justify-between gap-2 px-4 pb-6 border-b border-l border-slate-700 relative">
                {/* Horizontal grid lines */}
                <div className="absolute left-0 right-0 top-12 border-b border-slate-200 dark:border-slate-800/80 text-[10px] font-mono text-slate-600 pl-1">High</div>
                <div className="absolute left-0 right-0 top-[56%] border-b border-slate-200 dark:border-slate-800/80 text-[10px] font-mono text-slate-600 pl-1">Mid</div>

                {demandForecast.timeSeries.slice(0, 15).map((pt, idx) => {
                  const maxVal = Math.max(1, Math.max(...demandForecast.timeSeries.map((t) => t.predictedDemand)));
                  const demandHeightPct = Math.round((pt.predictedDemand / maxVal) * 80);
                  const capHeightPct = Math.round((pt.availableCapacity / maxVal) * 80);

                  const getTooltipPositionClass = (index: number, total: number) => {
                    if (index <= 1) return 'left-0';
                    if (index >= total - 2) return 'right-0';
                    return 'left-1/2 -translate-x-1/2';
                  };

                  return (
                    <div key={pt.date} className="flex-1 h-full flex flex-col justify-end items-center gap-1 group relative">
                      {/* Tooltip on hover */}
                      <div className={`absolute top-0 hidden group-hover:block bg-slate-900/95 border border-slate-700 text-white p-2.5 rounded-md text-[10px] font-mono z-30 whitespace-nowrap shadow-2xl pointer-events-none ${getTooltipPositionClass(idx, Math.min(15, demandForecast.timeSeries.length))}`}>
                        <p className="font-bold text-orange-400">{pt.dayLabel} ({pt.date})</p>
                        <p>Demand: {pt.predictedDemand} bookings</p>
                        <p>Capacity: {pt.availableCapacity} slots</p>
                        {pt.shortage > 0 && <p className="text-red-400 font-bold">Shortage: +{pt.shortage} envs</p>}
                      </div>

                      <div className="w-full flex items-end justify-center gap-1 h-48">
                        {/* Demand Bar */}
                        <div
                          style={{ height: `${demandHeightPct}%` }}
                          className={`w-3.5 rounded-t transition-all ${
                            pt.isCapacityRisk
                              ? 'bg-gradient-to-t from-red-600 to-orange-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]'
                              : 'bg-gradient-to-t from-blue-600 to-cyan-400'
                          }`}
                        />
                        {/* Capacity Line/Bar */}
                        <div
                          style={{ height: `${capHeightPct}%` }}
                          className="w-2 bg-emerald-500/70 rounded-t"
                        />
                      </div>
                      <span className="text-[9px] font-mono text-slate-400 truncate max-w-[45px] text-center">
                        {pt.dayLabel.split(' ')[0]} {pt.dayLabel.split(' ')[1]}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Breakdown Cards Grid */}
          <div className="space-y-4">
            <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
              <Layers className="w-4 h-4 text-orange-400" /> Dimension Breakdown: {dimensionFilter.replace('_', ' ')}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {(dimensionFilter === 'BU'
                ? demandForecast.byBusinessUnit
                : dimensionFilter === 'ACCOUNT'
                ? demandForecast.byAccount
                : dimensionFilter === 'TIER'
                ? demandForecast.byTier
                : demandForecast.byEnvType
              ).map((item) => (
                <div key={item.dimensionName} className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white font-mono truncate">{item.dimensionName}</span>
                    {renderRiskBadge(item.capacityRiskLevel)}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-900/60 p-2.5 rounded border border-slate-200 dark:border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-400 block">CURRENT</span>
                      <strong className="text-slate-200">{item.currentDemand}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">PREDICTED</span>
                      <strong className="text-orange-400">{item.predictedDemand} (+{item.growthPercentage}%)</strong>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1">
                      <span>Predicted Utilization</span>
                      <span className="font-bold text-white">{item.predictedUtilization}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${item.predictedUtilization}%` }}
                        className={`h-full transition-all ${
                          item.predictedUtilization > 85 ? 'bg-red-500' : item.predictedUtilization > 65 ? 'bg-orange-500' : 'bg-emerald-500'
                        }`}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. TAB CONTENT 2: PREDICTIVE CONFLICT HEATMAP */}
      {activeTab === 'HEATMAP' && (
        <div className="space-y-6">
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-lg space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-orange-400" /> Weekly Predictive Conflict Heatmap
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Conflict risk matrix across Environment Profiles and peak weekdays. Click any cell to inspect details.
                </p>
              </div>

              <div className="flex items-center gap-3 text-xs font-mono">
                <span className="flex items-center gap-1 text-emerald-400"><span className="w-2.5 h-2.5 rounded bg-emerald-500" /> Low (0-30%)</span>
                <span className="flex items-center gap-1 text-amber-300"><span className="w-2.5 h-2.5 rounded bg-amber-500" /> Med (31-60%)</span>
                <span className="flex items-center gap-1 text-orange-400"><span className="w-2.5 h-2.5 rounded bg-orange-500" /> High (61-80%)</span>
                <span className="flex items-center gap-1 text-red-400"><span className="w-2.5 h-2.5 rounded bg-red-500" /> V.High (81-100%)</span>
              </div>
            </div>

            {/* Grid Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                    <th className="p-3 uppercase text-[10px]">Environment</th>
                    <th className="p-3 uppercase text-[10px]">Tier</th>
                    <th className="p-3 text-center uppercase text-[10px]">Mon</th>
                    <th className="p-3 text-center uppercase text-[10px]">Tue</th>
                    <th className="p-3 text-center uppercase text-[10px]">Wed</th>
                    <th className="p-3 text-center uppercase text-[10px]">Thu</th>
                    <th className="p-3 text-center uppercase text-[10px]">Fri</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                  {environmentProfiles.map((env) => {
                    const envCells = heatmapCells.filter((c) => c.environmentId === env.id);

                    return (
                      <tr key={env.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="p-3 font-bold text-white truncate">{env.name}</td>
                        <td className="p-3 text-slate-400 text-[10px]">{env.type}</td>

                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((day) => {
                          const cell = envCells.find((c) => c.dayOfWeek === day);
                          if (!cell) return <td key={day} className="p-3 text-center text-slate-600">-</td>;

                          const bgClass =
                            cell.riskLevel === 'VERY_HIGH'
                              ? 'bg-red-950/80 text-red-300 border-red-800 hover:bg-red-900'
                              : cell.riskLevel === 'HIGH'
                              ? 'bg-orange-950/80 text-orange-300 border-orange-800 hover:bg-orange-900'
                              : cell.riskLevel === 'MEDIUM'
                              ? 'bg-amber-950/80 text-amber-200 border-amber-800 hover:bg-amber-900'
                              : 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60 hover:bg-emerald-900';

                          return (
                            <td key={day} className="p-2 text-center">
                              <button
                                onClick={() => setSelectedCell(cell)}
                                className={`w-full py-2 px-1 rounded border text-center transition-all cursor-pointer ${bgClass}`}
                              >
                                <span className="font-extrabold text-xs block">{cell.conflictProbability}%</span>
                                <div className="flex items-center justify-center gap-1 text-[9px] opacity-80 mt-0.5">
                                  {cell.hasActiveRelease && <span title="Pipeline Release Scheduled">🚀</span>}
                                  {cell.hasIncident && <span title="Active Incident">⚠️</span>}
                                </div>
                              </button>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 6. TAB CONTENT 3: WHAT-IF SCENARIO SIMULATOR */}
      {activeTab === 'WHAT_IF' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Inputs Sandbox Panel */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-lg space-y-5">
            <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <Sliders className="w-4 h-4 text-orange-400" /> Scenario Parameters
            </h3>

            {/* Demand Surge Slider */}
            <div>
              <div className="flex justify-between text-xs font-mono text-slate-300 mb-1">
                <span>DEMAND GROWTH SURGE:</span>
                <span className="font-bold text-orange-400">+{scenarioInput.demandGrowthPercentage}%</span>
              </div>
              <input autoComplete="off" data-lpignore="true"
                type="range"
                min="0"
                max="100"
                step="5"
                value={scenarioInput.demandGrowthPercentage}
                onChange={(e) =>
                  setScenarioInput({ ...scenarioInput, demandGrowthPercentage: parseInt(e.target.value) || 0 })
                }
                className="w-full accent-orange-500 cursor-pointer"
              />
            </div>

            {/* Additional Pipeline Releases Slider */}
            <div>
              <div className="flex justify-between text-xs font-mono text-slate-300 mb-1">
                <span>ADDITIONAL RELEASES:</span>
                <span className="font-bold text-blue-400">+{scenarioInput.additionalReleaseCount} Releases</span>
              </div>
              <input autoComplete="off" data-lpignore="true"
                type="range"
                min="0"
                max="5"
                step="1"
                value={scenarioInput.additionalReleaseCount}
                onChange={(e) =>
                  setScenarioInput({ ...scenarioInput, additionalReleaseCount: parseInt(e.target.value) || 0 })
                }
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            {/* Toggle Convert to Disruptive */}
            <div className="flex items-center justify-between bg-slate-900/80 p-3 rounded border border-slate-200 dark:border-slate-800">
              <div>
                <span className="text-xs font-mono font-bold text-white block">DISRUPTIVE MODE SURGE</span>
                <span className="text-[10px] text-slate-400 block">Simulate all bookings requiring exclusive control</span>
              </div>
              <input
                type="checkbox"
                checked={scenarioInput.convertAllToDisruptive}
                onChange={(e) =>
                  setScenarioInput({ ...scenarioInput, convertAllToDisruptive: e.target.checked })
                }
                className="w-4 h-4 accent-orange-500 cursor-pointer"
              />
            </div>

            {/* Offline Node Selector */}
            <div>
              <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1.5">
                SIMULATE OFFLINE / MAINTENANCE NODES ({scenarioInput.offlineEnvironmentIds.length} SELECTED):
              </label>
              <div className="space-y-1.5 max-h-36 overflow-y-auto bg-slate-900/60 p-2 rounded border border-slate-200 dark:border-slate-800">
                {environmentProfiles.map((p) => {
                  const isOffline = scenarioInput.offlineEnvironmentIds.includes(p.id);
                  return (
                    <div
                      key={p.id}
                      onClick={() => toggleOfflineEnvInScenario(p.id)}
                      className={`flex items-center justify-between p-1.5 rounded cursor-pointer text-xs font-mono transition-colors ${
                        isOffline ? 'bg-red-950 text-red-300 border border-red-800 font-bold' : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span>{p.name} ({p.type})</span>
                      {isOffline ? <span className="text-[10px] text-red-400 font-bold">OFFLINE</span> : <span className="text-[10px] text-slate-500">ONLINE</span>}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Results Output Panel */}
          <div className="lg:col-span-2 bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-lg space-y-6">
            <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <Sparkles className="w-4 h-4 text-orange-400" /> Simulated Capacity Impact Results
            </h3>

            {/* Comparison Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-slate-900/80 p-4 rounded border border-slate-200 dark:border-slate-800">
                <span className="text-[10px] font-mono text-slate-400 block">SIMULATED DEMAND</span>
                <span className="text-2xl font-bold text-white font-mono">{scenarioResult.simulatedDemand} bookings</span>
                <span className="text-[10px] font-mono text-orange-400 block mt-1">Baseline: {scenarioResult.baselineDemand}</span>
              </div>

              <div className="bg-slate-900/80 p-4 rounded border border-slate-200 dark:border-slate-800">
                <span className="text-[10px] font-mono text-slate-400 block">PREDICTED SHORTAGE</span>
                <span className="text-2xl font-bold text-red-400 font-mono">+{scenarioResult.simulatedShortage} envs</span>
                <span className="text-[10px] font-mono text-slate-400 block mt-1">Baseline: {scenarioResult.baselineShortage}</span>
              </div>

              <div className="bg-slate-900/80 p-4 rounded border border-slate-200 dark:border-slate-800">
                <span className="text-[10px] font-mono text-slate-400 block">AVG UTILIZATION</span>
                <span className="text-2xl font-bold text-amber-400 font-mono">{scenarioResult.averageUtilizationPercentage}%</span>
                <span className="text-[10px] font-mono text-amber-400 block mt-1">Contention Rate: HIGH</span>
              </div>
            </div>

            {/* AI Generated Mitigations */}
            <div className="bg-slate-900/90 p-4 rounded border border-slate-200 dark:border-slate-800 space-y-3">
              <span className="text-xs font-mono font-bold text-orange-400 uppercase flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-orange-400" /> Recommended AI Mitigation Actions
              </span>
              <div className="space-y-2">
                {scenarioResult.recommendations.map((rec, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs font-mono text-slate-300 bg-black/40 p-2.5 rounded border border-slate-200 dark:border-slate-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. TAB CONTENT 4: PROACTIVE ALERTS & RECOMMENDATIONS */}
      {activeTab === 'RECOMMENDATIONS' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Proactive Risk Alerts */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-lg space-y-4">
            <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <ShieldAlert className="w-4 h-4 text-red-400" /> Proactive Conflict Alerts ({proactiveAlerts.length})
            </h3>

            <div className="space-y-3">
              {proactiveAlerts.map((alert) => (
                <div key={alert.id} className="bg-slate-900/90 p-4 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white font-mono flex items-center gap-2">
                      <AlertTriangle className={`w-4 h-4 ${alert.severity === 'CRITICAL' ? 'text-red-400' : 'text-orange-400'}`} />
                      {alert.title}
                    </span>
                    {renderRiskBadge(alert.severity === 'CRITICAL' ? 'VERY_HIGH' : 'HIGH')}
                  </div>
                  <p className="text-xs text-slate-300">{alert.message}</p>
                  <div className="text-[11px] font-mono text-orange-300 bg-black/50 p-2 rounded border border-slate-200 dark:border-slate-800">
                    <strong>AI Recommendation:</strong> {alert.actionableRecommendation}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Capacity Recommendations */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-lg space-y-4">
            <h3 className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <Zap className="w-4 h-4 text-orange-400" /> Capacity & Mode Optimization Suggestions
            </h3>

            <div className="space-y-3">
              {capacityRecommendations.map((rec) => (
                <div key={rec.id} className="bg-slate-900/90 p-4 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white font-mono">{rec.title}</span>
                    <span className="text-[10px] font-mono font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800">
                      {rec.impactScore}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">{rec.reasoning}</p>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800/80 text-xs font-mono">
                    <span className="text-slate-400">Timeframe: <strong className="text-white">{rec.timeframe}</strong></span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => submitFeedback(rec.id, true)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-emerald-900 hover:text-emerald-300 text-slate-300 text-[11px] flex items-center gap-1 transition-colors"
                      >
                        <ThumbsUp className="w-3 h-3" /> Accept
                      </button>
                      <button
                        onClick={() => submitFeedback(rec.id, false)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-red-900 hover:text-red-300 text-slate-300 text-[11px] flex items-center gap-1 transition-colors"
                      >
                        <ThumbsDown className="w-3 h-3" /> Reject
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Selected Cell Modal */}
      {selectedCell && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 dark:bg-black/80 backdrop-blur-sm">
          <div className="bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-lg p-6 max-w-md w-full space-y-4 shadow-2xl font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <BrainCircuit className="w-4 h-4 text-orange-400" /> Heatmap Cell Risk Inspection
              </h3>
              <button onClick={() => setSelectedCell(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-2">
              <p><strong className="text-slate-400">ENVIRONMENT:</strong> <span className="text-white font-bold">{selectedCell.environmentName}</span> ({selectedCell.tier})</p>
              <p><strong className="text-slate-400">DAY:</strong> <span className="text-orange-400 font-bold">{selectedCell.dayOfWeek} ({selectedCell.dateStr})</span></p>
              <p><strong className="text-slate-400">CONFLICT PROBABILITY:</strong> <span className="text-red-400 font-bold">{selectedCell.conflictProbability}%</span></p>
              <p><strong className="text-slate-400">RISK RATING:</strong> {renderRiskBadge(selectedCell.riskLevel)}</p>
              <p><strong className="text-slate-400">BOOKINGS:</strong> <span className="text-slate-200">{selectedCell.bookingCount} active</span></p>
              <p><strong className="text-slate-400">RELEASES SCHEDULED:</strong> <span className="text-slate-200">{selectedCell.hasActiveRelease ? 'Yes' : 'None'}</span></p>
              <p><strong className="text-slate-400">HEALTH INCIDENTS:</strong> <span className="text-slate-200">{selectedCell.hasIncident ? 'Active Incidents' : 'Healthy'}</span></p>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button onClick={() => setSelectedCell(null)} className="px-4 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
