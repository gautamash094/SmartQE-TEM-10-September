import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sparkles,
  Plus,
  Server,
  Boxes,
  Cpu,
  HardDrive,
  Globe,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { useTEM } from '../context/TEMContext';
import { provisioningService } from '../services/provisioningService';
import { ProvisioningTemplate } from '../types/provisioning';

export const ProvisioningTemplatesPage: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useTEM();

  const [templates, setTemplates] = useState<ProvisioningTemplate[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadTemplates = async () => {
    setIsLoading(true);
    try {
      const data = await provisioningService.getTemplates();
      setTemplates(data);
    } catch (err: any) {
      showToast?.(`Failed to load templates: ${err.message}`, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTemplates();
  }, []);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-wide">
                Reusable Provisioning Templates
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Standardized environment stacks, infrastructure blueprints, and automated testing runtimes.
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => navigate('/provisioning/new')}
          className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-orange-600/30 flex items-center gap-2 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Deploy Custom Template</span>
        </button>
      </div>

      {/* Template Cards Grid */}
      {templates.length === 0 && !isLoading ? (
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-12 text-center">
          <div className="w-12 h-12 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 mx-auto mb-4">
            <Boxes className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-white">No Provisioning Templates Found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Create reusable infrastructure stacks and stack blueprints to accelerate environment provisioning.
          </p>
          <button
            onClick={() => navigate('/provisioning/new')}
            className="mt-4 px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white rounded-lg text-xs font-semibold shadow-lg shadow-orange-600/20 transition-all inline-flex items-center gap-2"
          >
            <span>Create Custom Stack</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {templates.map((tpl) => (
          <div
            key={tpl.id}
            className="p-6 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-orange-500/50 transition-all duration-200 shadow-sm flex flex-col justify-between group"
          >
            <div className="space-y-4">
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white group-hover:text-orange-400 transition-colors">
                      {tpl.name}
                    </h3>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-orange-500/10 text-orange-400 border border-orange-500/20">
                      {tpl.environment_type}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{tpl.description}</p>
                </div>
              </div>

              {/* Hardware Specs Matrix */}
              <div className="grid grid-cols-3 gap-2.5 p-3 rounded-lg bg-slate-950/60 border border-slate-800 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-slate-500 block">COMPUTE</span>
                  <span className="text-slate-200 font-bold">{tpl.cpu_cores} vCPUs ({tpl.compute_type})</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">MEMORY</span>
                  <span className="text-slate-200 font-bold">{tpl.ram_gb} GB RAM</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">STORAGE</span>
                  <span className="text-slate-200 font-bold">{tpl.storage_gb} GB SSD</span>
                </div>
              </div>

              {/* Software Stack Pills */}
              <div>
                <span className="text-[11px] font-mono text-slate-400 block mb-1.5 uppercase">
                  Software Stack ({tpl.software_stack?.length || 0})
                </span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {tpl.software_stack?.map((sw, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded text-[11px] bg-slate-800 text-slate-300 border border-slate-700"
                    >
                      {sw.name} {sw.version && <strong className="text-orange-400 font-mono">v{sw.version}</strong>}
                    </span>
                  ))}
                </div>
              </div>

              {/* Tags */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {tpl.tags?.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-mono text-slate-500 bg-slate-950 px-2 py-0.5 rounded border border-slate-800"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Bottom Action */}
            <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400">
                Estimated Duration: ~{tpl.estimated_duration_min} min
              </span>
              <button
                type="button"
                onClick={() => navigate('/provisioning/new')}
                className="px-3.5 py-1.5 bg-orange-600/90 hover:bg-orange-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
              >
                <span>Provision from Template</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
      )}
    </div>
  );
};
