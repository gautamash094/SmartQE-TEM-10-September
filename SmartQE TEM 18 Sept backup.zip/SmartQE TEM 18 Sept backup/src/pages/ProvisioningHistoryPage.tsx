import React, { useState, useEffect } from 'react';
import { History, Search, RotateCcw, User, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { provisioningService } from '../services/provisioningService';
import { ProvisioningRequest } from '../types/provisioning';
import { ProvisioningStatusBadge } from '../components/provisioning/common/ProvisioningStatusBadge';

export const ProvisioningHistoryPage: React.FC = () => {
  const navigate = useNavigate();
  const [requests, setRequests] = useState<ProvisioningRequest[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [search, setSearch] = useState('');

  const loadData = async () => {
    setIsLoading(true);
    try {
      const res = await provisioningService.getRequests({ search, pageSize: 50 });
      setRequests(res.items);
    } catch {}
    finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [search]);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-wide">
                Provisioning Execution History & Audits
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Complete traceability and audit logging of all environment provisioning requests and lifecycle state changes.
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={loadData}
          disabled={isLoading}
          className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-700 transition-colors"
        >
          <RotateCcw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-400' : ''}`} />
        </button>
      </div>

      {/* Search */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search history by request number, environment name, requester..."
            className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500"
          />
        </div>
      </div>

      {/* History List */}
      {requests.length === 0 && !isLoading ? (
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-12 text-center">
          <div className="w-12 h-12 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 mx-auto mb-4">
            <History className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-white">No Execution History Found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Provisioning audit trails and execution records will be recorded here as requests are created and executed.
          </p>
        </div>
      ) : (
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-[11px] font-mono uppercase text-slate-400">
                <th className="py-3 px-4">Request #</th>
                <th className="py-3 px-4">Environment</th>
                <th className="py-3 px-4">Hierarchy</th>
                <th className="py-3 px-4">Owner / Requester</th>
                <th className="py-3 px-4">Final Status</th>
                <th className="py-3 px-4">Created At</th>
                <th className="py-3 px-4 text-right">Console</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {requests.map((req) => (
                <tr
                  key={req.id}
                  onClick={() => navigate(`/provisioning/requests/${req.id}`)}
                  className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                >
                  <td className="py-3.5 px-4 font-mono font-bold text-orange-400">
                    {req.request_number}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-semibold text-white block">{req.environment_name}</span>
                    <span className="text-[10px] font-mono text-slate-400">{req.environment_type}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="text-slate-200 block">{req.business_unit}</span>
                    <span className="text-[11px] text-slate-400">{req.project_name}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="text-slate-200 block">{req.environment_owner || req.requested_by}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <ProvisioningStatusBadge status={req.status} size="sm" />
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-400 text-[11px]">
                    {new Date(req.created_at).toLocaleString()}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/provisioning/requests/${req.id}`);
                      }}
                      className="p-1.5 text-slate-400 hover:text-orange-400 transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      )}
    </div>
  );
};
