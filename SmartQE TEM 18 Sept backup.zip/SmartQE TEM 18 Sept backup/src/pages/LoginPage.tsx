import React, { useState, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTEM } from '../context/TEMContext';
import { authService } from '../services/authService';
import {
  Shield,
  Lock,
  User,
  Eye,
  EyeOff,
  LogIn,
  KeyRound,
  AlertCircle,
  CheckCircle2,
  X,
  Check,
  Zap,
  Clock,
} from 'lucide-react';

import { ButtonLoader } from '../components/common/ButtonLoader';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const { showToast } = useTEM();

  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Forgot password modal state
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotStep, setForgotStep] = useState<1 | 2>(1);
  const [forgotIdentifier, setForgotIdentifier] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [isForgotLoading, setIsForgotLoading] = useState(false);
  const [forgotError, setForgotError] = useState('');
  const [forgotSuccessMessage, setForgotSuccessMessage] = useState('');

  // Query parameter redirect support
  const searchParams = new URLSearchParams(location.search);
  const isExpired = searchParams.get('expired') === 'true';
  const redirectParam = searchParams.get('redirect');
  // When session has expired or no deep redirect is present, destination is strictly TEM Dashboard
  const redirectTarget = (!isExpired && redirectParam && redirectParam !== '/login') ? redirectParam : '/tem-dashboard';

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!usernameOrEmail.trim()) {
      setErrorMessage('Please enter your username or email address.');
      return;
    }

    if (!password) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsLoading(true);
    try {
      const user = await login(usernameOrEmail.trim(), password);
      showToast(`Welcome back, ${user.fullName}!`, 'success');

      // After automatic timeout or standard login, control goes to TEM Dashboard
      if (user.isSuperAdmin || (user.allowedScreens && user.allowedScreens.includes('*'))) {
        navigate(redirectTarget);
      } else if (user.allowedScreens && user.allowedScreens.length > 0) {
        if (redirectTarget === '/tem-dashboard' && user.allowedScreens.includes('/tem-dashboard')) {
          navigate('/tem-dashboard');
        } else {
          const isAllowed = user.allowedScreens.some(
            (r) => r === redirectTarget || redirectTarget.startsWith(r + '/')
          );
          if (isAllowed) {
            navigate(redirectTarget);
          } else if (user.allowedScreens.includes('/tem-dashboard')) {
            navigate('/tem-dashboard');
          } else {
            navigate(user.allowedScreens[0]);
          }
        }
      } else {
        navigate('/tem-dashboard');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  // Forgot Password Step 1: Request Reset Token
  const handleRequestReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');

    if (!forgotIdentifier.trim()) {
      setForgotError('Please enter your username or registered email.');
      return;
    }

    setIsForgotLoading(true);
    try {
      const generatedToken = await authService.requestForgotPassword(forgotIdentifier.trim());
      if (generatedToken) {
        setResetToken(generatedToken);
        setForgotStep(2);
      } else {
        setForgotSuccessMessage('Password reset instructions have been generated. Please check your token below.');
        setForgotStep(2);
      }
    } catch (err: any) {
      setForgotError(err.message || 'Failed to generate reset request.');
    } finally {
      setIsForgotLoading(false);
    }
  };

  // Forgot Password Step 2: Reset Password with Token
  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');

    if (!resetToken.trim()) {
      setForgotError('Please provide the password reset token.');
      return;
    }

    if (newPassword.length < 8) {
      setForgotError('Password must be at least 8 characters in length.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setForgotError('New password and confirmation password do not match.');
      return;
    }

    setIsForgotLoading(true);
    try {
      await authService.resetPasswordWithToken(resetToken.trim(), newPassword);
      showToast('Password reset successfully! Please log in with your new password.', 'success');
      setIsForgotModalOpen(false);
      setForgotStep(1);
      setUsernameOrEmail(forgotIdentifier);
      setPassword('');
    } catch (err: any) {
      setForgotError(err.message || 'Failed to reset password. The token may be expired or invalid.');
    } finally {
      setIsForgotLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#070d18] text-slate-100 p-4 relative overflow-hidden">
      {/* Background Glows */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-orange-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative w-full max-w-md bg-[#0f1724]/90 backdrop-blur-xl border border-slate-800/90 rounded-2xl shadow-2xl p-8 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-orange-500/10 border border-orange-500/30 text-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.25)] mb-2">
            <Zap className="w-8 h-8 fill-orange-500/20" />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            <span>SMARTQE</span>
            <span className="text-orange-500">TEM</span>
          </h1>
          <p className="text-xs font-mono text-slate-400">
            TEST ENVIRONMENT MANAGEMENT &bull; ENTERPRISE LOGIN
          </p>
        </div>

        {/* Session Expired Notice */}
        {searchParams.get('expired') === 'true' && !errorMessage && (
          <div className="p-3.5 bg-amber-950/50 border border-amber-500/80 rounded-xl flex items-start gap-3 text-xs text-amber-200 shadow-[0_0_15px_rgba(245,158,11,0.2)]">
            <Clock className="w-4 h-4 shrink-0 mt-0.5 text-amber-400 animate-pulse" />
            <span className="leading-relaxed">
              <strong>Session Expired:</strong> Your session has automatically expired after 20 minutes of inactivity. Please sign in again.
            </span>
          </div>
        )}

        {/* Login Error Alert */}
        {errorMessage && (
          <div className="p-3.5 bg-rose-950/40 border border-rose-800/80 rounded-xl flex items-start gap-3 text-xs text-rose-300">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
            <span className="leading-relaxed">{errorMessage}</span>
          </div>
        )}


        {/* Form */}
        <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleLoginSubmit} className="space-y-4">
          {/* Username / Email */}
          <div className="space-y-1.5">
            <label className="block text-xs font-mono font-semibold text-slate-300 uppercase tracking-wider">
              Username or Email
            </label>
            <div className="relative">
              <input autoComplete="off" data-lpignore="true"
                type="text"
                required
                autoFocus
                value={usernameOrEmail}
                onChange={(e) => setUsernameOrEmail(e.target.value)}
                placeholder="e.g. admin or admin@testops.io"
                className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono transition-all pr-10"
              />
              <div className="absolute right-3.5 top-3.5 text-slate-500 pointer-events-none">
                <User className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-mono font-semibold text-slate-300 uppercase tracking-wider">
                Password
              </label>
              <button
                type="button"
                onClick={() => {
                  setForgotIdentifier(usernameOrEmail);
                  setForgotStep(1);
                  setForgotError('');
                  setIsForgotModalOpen(true);
                }}
                className="text-xs font-mono text-orange-400 hover:text-orange-300 transition-colors"
              >
                Forgot Password?
              </button>
            </div>
            <div className="relative">
              <input autoComplete="off" data-lpignore="true"
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full bg-[#161f2e] border border-slate-700/80 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono transition-all pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-200"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <ButtonLoader
            type="submit"
            isLoading={isLoading}
            loadingText="AUTHENTICATING..."
            icon={<LogIn className="w-4 h-4" />}
            className="w-full py-3.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_20px_rgba(249,115,22,0.4)] cursor-pointer mt-2"
          >
            SIGN IN TO TEM
          </ButtonLoader>
        </form>

        {/* Footer info */}
        <div className="pt-2 text-center text-[11px] font-mono text-slate-500">
          <span>Protected by Enterprise RBAC &bull; SmartQE TEM Control</span>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#0f1724] border border-slate-800 rounded-2xl shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-orange-950/60 border border-orange-800/80 flex items-center justify-center text-orange-400">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white font-mono uppercase">Password Recovery</h3>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {forgotStep === 1 ? 'Step 1: Verify Account' : 'Step 2: Set New Password'}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setIsForgotModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {forgotError && (
              <div className="p-3 bg-rose-950/40 border border-rose-800/80 rounded-xl text-xs text-rose-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{forgotError}</span>
              </div>
            )}

            {forgotStep === 1 ? (
              <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleRequestReset} className="space-y-4">
                <p className="text-xs text-slate-400 leading-relaxed">
                  Enter your username or registered email address. We will generate a secure time-limited verification token to reset your password.
                </p>
                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-300 mb-1 uppercase">
                    Username or Email
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    required
                    value={forgotIdentifier}
                    onChange={(e) => setForgotIdentifier(e.target.value)}
                    placeholder="e.g. admin or admin@testops.io"
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                  />
                </div>
                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsForgotModalOpen(false)}
                    className="px-4 py-2 rounded-lg text-xs font-mono text-slate-400 hover:bg-slate-800"
                  >
                    CANCEL
                  </button>
                  <ButtonLoader
                    type="submit"
                    isLoading={isForgotLoading}
                    loadingText="GENERATING TOKEN..."
                    className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500"
                  >
                    CONTINUE
                  </ButtonLoader>
                </div>
              </form>
            ) : (
              <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleResetSubmit} className="space-y-4">
                <div className="p-3 bg-emerald-950/30 border border-emerald-800/80 rounded-xl text-xs text-emerald-300">
                  <span className="font-bold font-mono block">Reset Token Active:</span>
                  <code className="text-[11px] font-mono break-all text-emerald-200">{resetToken}</code>
                </div>

                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-300 mb-1 uppercase">
                    New Password
                  </label>
                  <div className="relative">
                    <input autoComplete="off" data-lpignore="true"
                      type={showNewPassword ? 'text' : 'password'}
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new password (8+ chars)"
                      className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-3 text-slate-400 hover:text-white"
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-300 mb-1 uppercase">
                    Confirm New Password
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotStep(1)}
                    className="px-4 py-2 rounded-lg text-xs font-mono text-slate-400 hover:bg-slate-800"
                  >
                    BACK
                  </button>
                  <ButtonLoader
                    type="submit"
                    isLoading={isForgotLoading}
                    loadingText="RESETTING..."
                    className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500"
                  >
                    RESET PASSWORD
                  </ButtonLoader>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
