import React from 'react';
import { ProvisioningDashboardPage } from './ProvisioningDashboardPage';

export const ProvisioningRequestsPage: React.FC = () => {
  return <ProvisioningDashboardPage />;
};
