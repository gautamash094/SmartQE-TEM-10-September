import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Server,
  Plus,
  Sparkles,
  Layers,
  RotateCcw,
  Activity,
  CheckCircle2,
} from 'lucide-react';
import { useTEM } from '../context/TEMContext';
import { provisioningService } from '../services/provisioningService';
import {
  ProvisioningRequest,
  ProvisioningDashboardKPIs,
} from '../types/provisioning';
import { ProvisioningKpiCards } from '../components/provisioning/dashboard/ProvisioningKpiCards';
import { ProvisioningFilterBar } from '../components/provisioning/dashboard/ProvisioningFilterBar';
import { ProvisioningTable } from '../components/provisioning/dashboard/ProvisioningTable';
import { Pagination } from '../components/common/Pagination';

export const ProvisioningDashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { businessUnits, projects, applications, showToast } = useTEM();

  const [kpis, setKpis] = useState<ProvisioningDashboardKPIs>({
    total_requests: 0,
    in_progress: 0,
    ready: 0,
    failed: 0,
    pending_approval: 0,
    decommissioning: 0,
  });

  const [requests, setRequests] = useState<ProvisioningRequest[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [isLoading, setIsLoading] = useState(false);

  const [filters, setFilters] = useState({
    search: '',
    businessUnit: 'ALL',
    projectName: 'ALL',
    applicationName: 'ALL',
    status: 'ALL',
    provisioningMode: 'ALL',
  });

  const loadData = async (silent = false) => {
    if (!silent) setIsLoading(true);
    try {
      const [kpiRes, reqRes] = await Promise.all([
        provisioningService.getDashboardKPIs(),
        provisioningService.getRequests({
          ...filters,
          page,
          pageSize,
        }),
      ]);

      setKpis(kpiRes);
      setRequests(reqRes.items);
      setTotal(reqRes.total);
    } catch (err: any) {
      if (!silent) {
        showToast?.(`Failed to fetch provisioning data: ${err.message}`, 'error');
      }
    } finally {
      if (!silent) setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [page, pageSize, filters]);

  // Periodic polling for real-time progress update if any request is in-progress
  useEffect(() => {
    const hasActiveJobs = requests.some((r) =>
      ['PROVISIONING', 'CONFIGURING', 'HEALTH_CHECK', 'QUEUED'].includes(r.status)
    );

    if (hasActiveJobs) {
      const interval = setInterval(() => {
        loadData(true);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [requests]);

  const handleFilterStatus = (status: string) => {
    setFilters((prev) => ({ ...prev, status }));
    setPage(1);
  };

  const handleResetFilters = () => {
    setFilters({
      search: '',
      businessUnit: 'ALL',
      projectName: 'ALL',
      applicationName: 'ALL',
      status: 'ALL',
      provisioningMode: 'ALL',
    });
    setPage(1);
  };

  const handleApprove = async (id: string) => {
    try {
      await provisioningService.approveRequest(id, 'APPROVE', 'Auto approved from dashboard');
      showToast?.('Provisioning request approved successfully.', 'success');
      loadData();
    } catch (err: any) {
      showToast?.(`Approval failed: ${err.message}`, 'error');
    }
  };

  const handleProvision = async (id: string) => {
    try {
      await provisioningService.triggerProvisioning(id);
      showToast?.('Provisioning execution started in background.', 'success');
      loadData();
    } catch (err: any) {
      showToast?.(`Execution failed: ${err.message}`, 'error');
    }
  };

  const handleRetry = async (id: string) => {
    try {
      await provisioningService.retryRequest(id);
      showToast?.('Retrying failed provisioning steps...', 'info');
      loadData();
    } catch (err: any) {
      showToast?.(`Retry failed: ${err.message}`, 'error');
    }
  };

  const handleDecommission = async (id: string) => {
    if (!window.confirm('Are you sure you want to decommission this environment? All allocated VM, storage, and IP assets will be released.')) {
      return;
    }
    try {
      await provisioningService.decommissionRequest(id);
      showToast?.('Environment decommission initiated.', 'success');
      loadData();
    } catch (err: any) {
      showToast?.(`Decommission failed: ${err.message}`, 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-400">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-wide flex items-center gap-2">
                <span>Environment Provisioning Orchestrator</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase">
                  ACTIVE
                </span>
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Automated multi-tier environment lifecycle: Request → Validate → Approve → Plan → Provision → Health Check → Ready.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => navigate('/provisioning/templates')}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-4 h-4 text-orange-400" />
            <span>Templates</span>
          </button>
          <button
            onClick={() => navigate('/provisioning/new')}
            className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-orange-600/30 flex items-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Provisioning Request</span>
          </button>
        </div>
      </div>

      {/* Top KPI Cards */}
      <ProvisioningKpiCards
        kpis={kpis}
        onFilterStatus={handleFilterStatus}
        activeStatus={filters.status}
      />

      {/* Filter Bar */}
      <ProvisioningFilterBar
        filters={filters}
        onChange={setFilters}
        onReset={handleResetFilters}
        onRefresh={() => loadData()}
        businessUnits={businessUnits}
        projects={projects}
        applications={applications}
        isLoading={isLoading}
      />

      {/* Requests Table */}
      <ProvisioningTable
        requests={requests}
        onApprove={handleApprove}
        onProvision={handleProvision}
        onRetry={handleRetry}
        onDecommission={handleDecommission}
        isLoading={isLoading}
      />

      {/* Pagination */}
      {total > pageSize && (
        <Pagination
          currentPage={page}
          totalItems={total}
          pageSize={pageSize}
          onPageChange={setPage}
        />
      )}
    </div>
  );
};
