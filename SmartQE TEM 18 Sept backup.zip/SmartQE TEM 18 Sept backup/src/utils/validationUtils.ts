/**
 * SmartQE TEM Unified Field Validation Utilities
 * Provides standardized validators, regex format checks, and error helpers across all modules.
 */

// URL regex supporting http:// and https:// with valid hostname/IP and optional port/path
const URL_REGEX = /^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}(?:\.[a-zA-Z0-9()]{1,6})?\b(?:[-a-zA-Z0-9()@:%_+.~#?&//=]*)$/i;

// IPv4 and IPv6 regex
const IPV4_REGEX = /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;
const IPV6_REGEX = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;

// Standard Email regex
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Standard Code regex: uppercase alphanumeric with dashes/underscores (e.g. COMP-001, BU_FIN)
const CODE_REGEX = /^[A-Z0-9_-]{2,30}$/i;

/**
 * Trims string and returns clean value. Returns empty string if null/undefined.
 */
export const cleanTrim = (val?: string | null): string => {
  if (!val) return '';
  return val.trim();
};

/**
 * Validates that a string is a valid HTTP or HTTPS URL.
 */
export const isValidUrl = (url: string): boolean => {
  if (!url || typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (!trimmed) return false;
  return URL_REGEX.test(trimmed);
};

/**
 * Validates that an IP address is a valid IPv4 or IPv6 address.
 */
export const isValidIp = (ip: string): boolean => {
  if (!ip || typeof ip !== 'string') return false;
  const trimmed = ip.trim();
  if (!trimmed) return false;
  return IPV4_REGEX.test(trimmed) || IPV6_REGEX.test(trimmed);
};

/**
 * Validates that a network port is an integer in the valid range (1 - 65535).
 */
export const isValidPort = (port: string | number): boolean => {
  if (port === undefined || port === null || port === '') return false;
  const num = typeof port === 'number' ? port : Number(port.toString().trim());
  if (isNaN(num)) return false;
  return Number.isInteger(num) && num >= 1 && num <= 65535;
};

/**
 * Validates that a string is a valid email address format.
 */
export const isValidEmail = (email: string): boolean => {
  if (!email || typeof email !== 'string') return false;
  const trimmed = email.trim();
  if (!trimmed) return false;
  return EMAIL_REGEX.test(trimmed);
};

/**
 * Validates entity code format (alphanumeric, dash, underscore, 2-30 characters).
 */
export const isValidCode = (code: string): boolean => {
  if (!code || typeof code !== 'string') return false;
  const trimmed = code.trim();
  if (!trimmed) return false;
  return CODE_REGEX.test(trimmed);
};

/**
 * Validates that a value is a positive number.
 * @param val The value to check
 * @param allowZero If true, 0 is allowed. Otherwise must be > 0.
 */
export const isPositiveNumber = (val: number | string | undefined | null, allowZero: boolean = false): boolean => {
  if (val === undefined || val === null || val === '') return false;
  const num = typeof val === 'number' ? val : Number(val.toString().trim());
  if (isNaN(num)) return false;
  return allowZero ? num >= 0 : num > 0;
};

/**
 * Validates that start date/time is strictly earlier than end date/time.
 */
export const isDateOrderValid = (startDate: string, endDate: string): boolean => {
  if (!startDate || !endDate) return false;
  const s = new Date(startDate).getTime();
  const e = new Date(endDate).getTime();
  if (isNaN(s) || isNaN(e)) return false;
  return s < e;
};

/**
 * Validates that a date is in the future.
 */
export const isFutureDate = (dateStr: string): boolean => {
  if (!dateStr) return false;
  const target = new Date(dateStr).getTime();
  if (isNaN(target)) return false;
  return target > Date.now();
};
