import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { MainLayout } from '../components/layout/MainLayout';
import { ProtectedRoute } from '../components/common/ProtectedRoute';
import { LoginPage } from '../pages/LoginPage';
import { CommandCenterPage } from '../pages/CommandCenterPage';
import { PortfolioPage } from '../pages/PortfolioPage';
import { EnvironmentDetailsManagementPage } from '../pages/EnvironmentDetailsManagementPage';
import { WorklistPage } from '../pages/WorklistPage';
import { BookingsPage } from '../pages/BookingsPage';
import { ReleasesPage } from '../pages/ReleasesPage';
import { IncidentsPage } from '../pages/IncidentsPage';
import { UserManagementPage } from '../pages/UserManagementPage';
import { RoleManagementPage } from '../pages/RoleManagementPage';
import { AccessManagementPage } from '../pages/AccessManagementPage';
import { UserGroupManagementPage } from '../pages/UserGroupManagementPage';
import { DefineWorkflowPage } from '../pages/DefineWorkflowPage';
import { RunbooksPage } from '../pages/RunbooksPage';
import { InventoryPage } from '../pages/InventoryPage';
import { EnvironmentTopologyPage } from '../pages/EnvironmentTopologyPage';
import { EnvironmentMonitoringPage } from '../pages/EnvironmentMonitoringPage';
import { AIPredictiveDemandPage } from '../pages/AIPredictiveDemandPage';
import { ExternalIntegrationsPage } from '../pages/ExternalIntegrationsPage';
import { ProvisioningDashboardPage } from '../pages/ProvisioningDashboardPage';
import { ProvisioningWizardPage } from '../pages/ProvisioningWizardPage';
import { ProvisioningDetailPage } from '../pages/ProvisioningDetailPage';
import { ProvisioningTemplatesPage } from '../pages/ProvisioningTemplatesPage';
import { ProvisioningHistoryPage } from '../pages/ProvisioningHistoryPage';

export const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Public Login Route (renders without MainLayout) */}
      <Route path="/login" element={<LoginPage />} />

      {/* Protected Application Routes (nested within MainLayout) */}
      <Route
        path="/*"
        element={
          <MainLayout>
            <Routes>
              <Route path="/" element={<Navigate to="/tem-dashboard" replace />} />
              <Route
                path="/tem-dashboard"
                element={
                  <ProtectedRoute screenRoute="/tem-dashboard">
                    <CommandCenterPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/dashboard" element={<Navigate to="/tem-dashboard" replace />} />
              <Route path="/command-center" element={<Navigate to="/tem-dashboard" replace />} />

              <Route
                path="/entity-management"
                element={
                  <ProtectedRoute screenRoute="/entity-management">
                    <PortfolioPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/portfolio" element={<Navigate to="/entity-management" replace />} />

              <Route
                path="/environment-details"
                element={
                  <ProtectedRoute screenRoute="/environment-details">
                    <EnvironmentDetailsManagementPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/environments" element={<Navigate to="/environment-details" replace />} />
              <Route path="/environments/*" element={<Navigate to="/environment-details" replace />} />

              <Route
                path="/worklist"
                element={
                  <ProtectedRoute screenRoute="/worklist">
                    <WorklistPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/bookings"
                element={
                  <ProtectedRoute screenRoute="/bookings">
                    <BookingsPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/releases"
                element={
                  <ProtectedRoute screenRoute="/releases">
                    <ReleasesPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/incidents"
                element={
                  <ProtectedRoute screenRoute="/incidents">
                    <IncidentsPage />
                  </ProtectedRoute>
                }
              />

              {/* Environment Provisioning & Children */}
              <Route path="/provisioning" element={<Navigate to="/provisioning/dashboard" replace />} />
              <Route
                path="/provisioning/dashboard"
                element={
                  <ProtectedRoute screenRoute="/provisioning">
                    <ProvisioningDashboardPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provisioning/requests"
                element={
                  <ProtectedRoute screenRoute="/provisioning/requests">
                    <ProvisioningDashboardPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provisioning/new"
                element={
                  <ProtectedRoute screenRoute="/provisioning/new">
                    <ProvisioningWizardPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provisioning/requests/:id"
                element={
                  <ProtectedRoute screenRoute="/provisioning/requests">
                    <ProvisioningDetailPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provisioning/templates"
                element={
                  <ProtectedRoute screenRoute="/provisioning/templates">
                    <ProvisioningTemplatesPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provisioning/history"
                element={
                  <ProtectedRoute screenRoute="/provisioning/history">
                    <ProvisioningHistoryPage />
                  </ProtectedRoute>
                }
              />

              {/* Resource Management & Children */}
              <Route
                path="/inventory"
                element={
                  <ProtectedRoute screenRoute="/inventory">
                    <InventoryPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/environment-topology"
                element={
                  <ProtectedRoute screenRoute="/environment-topology">
                    <EnvironmentTopologyPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/topology" element={<Navigate to="/environment-topology" replace />} />
              <Route path="/inventory/topology" element={<Navigate to="/environment-topology" replace />} />

              <Route
                path="/environment-monitoring"
                element={
                  <ProtectedRoute screenRoute="/environment-monitoring">
                    <EnvironmentMonitoringPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/environment-monitoring/:id"
                element={
                  <ProtectedRoute screenRoute="/environment-monitoring">
                    <EnvironmentMonitoringPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/monitoring" element={<Navigate to="/environment-monitoring" replace />} />

              <Route
                path="/ai-predictive-demand"
                element={
                  <ProtectedRoute screenRoute="/ai-predictive-demand">
                    <AIPredictiveDemandPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/predictive-demand" element={<Navigate to="/ai-predictive-demand" replace />} />

              {/* Settings & Children */}
              <Route path="/settings" element={<Navigate to="/settings/users" replace />} />
              <Route
                path="/settings/users"
                element={
                  <ProtectedRoute screenRoute="/settings/users">
                    <UserManagementPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/settings/roles"
                element={
                  <ProtectedRoute screenRoute="/settings/roles">
                    <RoleManagementPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/settings/access"
                element={
                  <ProtectedRoute screenRoute="/settings/access">
                    <AccessManagementPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/settings/user-groups"
                element={
                  <ProtectedRoute screenRoute="/settings/user-groups">
                    <UserGroupManagementPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/settings/define-workflow"
                element={
                  <ProtectedRoute screenRoute="/settings/define-workflow">
                    <DefineWorkflowPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/settings/user-group" element={<Navigate to="/settings/user-groups" replace />} />
              <Route path="/settings/workflows" element={<Navigate to="/settings/define-workflow" replace />} />
              <Route path="/settings/*" element={<Navigate to="/settings/users" replace />} />

              {/* Advanced Modules */}
              <Route
                path="/external-integrations"
                element={
                  <ProtectedRoute screenRoute="/external-integrations">
                    <ExternalIntegrationsPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/integrations" element={<Navigate to="/external-integrations" replace />} />

              <Route
                path="/runbooks"
                element={
                  <ProtectedRoute screenRoute="/runbooks">
                    <RunbooksPage />
                  </ProtectedRoute>
                }
              />

              {/* Fallback route */}
              <Route path="*" element={<Navigate to="/tem-dashboard" replace />} />
            </Routes>
          </MainLayout>
        }
      />
    </Routes>
  );
};
