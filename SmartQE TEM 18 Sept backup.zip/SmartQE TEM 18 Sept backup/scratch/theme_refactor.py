# -*- coding: utf-8 -*-
import os, re

def update_file(path, transformer):
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    new_content = transformer(content)
    if new_content != content:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f'Updated: {path}')
    else:
        print(f'No changes needed: {path}')

def generic_card_table_replace(s):
    # Backgrounds
    s = re.sub(r'bg-\[#080c14\]', 'bg-slate-50 dark:bg-[#080c14]', s)
    s = re.sub(r'bg-\[#0b1019\]', 'bg-white dark:bg-[#0b1019]', s)
    s = re.sub(r'bg-\[#0f1724\]', 'bg-white dark:bg-[#0f1724]', s)
    s = re.sub(r'bg-\[#0c1322\]', 'bg-white dark:bg-[#0c1322]', s)
    s = re.sub(r'bg-\[#0c121e\]', 'bg-white dark:bg-[#0c121e]', s)
    s = re.sub(r'bg-\[#121b2d\]', 'bg-slate-50 dark:bg-[#121b2d]', s)
    s = re.sub(r'bg-\[#121c2c\]', 'bg-slate-50 dark:bg-[#121c2c]', s)
    s = re.sub(r'bg-\[#161f2e\]', 'bg-white dark:bg-[#161f2e]', s)
    s = re.sub(r'bg-\[#070a10\]', 'bg-white dark:bg-[#070a10]', s)
    s = re.sub(r'bg-\[#070b12\]', 'bg-slate-50 dark:bg-[#070b12]', s)
    s = re.sub(r'bg-\[#090d14\]', 'bg-slate-50 dark:bg-[#090d14]', s)
    s = re.sub(r'bg-\[#090d15\]', 'bg-white dark:bg-[#090d15]', s)
    s = re.sub(r'bg-\[#0e1625\]', 'bg-slate-50 dark:bg-[#0e1625]', s)
    s = re.sub(r'bg-\[#141c2c\]', 'bg-slate-50 dark:bg-[#141c2c]', s)
    s = re.sub(r'bg-\[#121a28\]', 'bg-slate-50 dark:bg-[#121a28]', s)
    s = re.sub(r'bg-\[#111827\]', 'bg-white dark:bg-[#111827]', s)
    
    # Borders
    s = re.sub(r'border-slate-800(/\d+)?', r'border-slate-200 dark:border-slate-800', s)
    s = re.sub(r'divide-slate-800(/\d+)?', r'divide-slate-200 dark:divide-slate-800', s)
    return s

# Test on a file
print('Helper defined.')
