import os
import sys

# Define target paths
base_dir = r"c:\Users\GenAILUCKAWPUSR5\Desktop\SmartQE TEM"
md_path = os.path.join(base_dir, "TEM_Architecture_and_Reference_Guide.md")

print(f"Target Markdown File: {md_path}")
