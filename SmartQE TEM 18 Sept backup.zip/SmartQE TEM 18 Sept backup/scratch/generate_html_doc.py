import os
import sys
import re

base_dir = r"c:\Users\GenAILUCKAWPUSR5\Desktop\SmartQE TEM"
md_path = os.path.join(base_dir, "TEM_Architecture_and_Reference_Guide.md")
html_path = os.path.join(base_dir, "TEM_Architecture_and_Reference_Guide.html")

with open(md_path, "r", encoding="utf-8") as f:
    md_content = f.read()

# Convert markdown syntax to HTML
html_body = md_content

# Code blocks
def replace_code_blocks(match):
    code = match.group(1).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f"<pre><code>{code}</code></pre>"

html_body = re.sub(r'```(?:[a-z]*)\n(.*?)```', replace_code_blocks, html_body, flags=re.DOTALL)

# Tables conversion
def convert_tables(text):
    lines = text.split('\n')
    new_lines = []
    in_table = False
    table_lines = []
    
    for line in lines:
        if line.strip().startswith('|'):
            in_table = True
            table_lines.append(line)
        else:
            if in_table:
                # Process table
                if len(table_lines) >= 2:
                    rows = [l.strip().split('|')[1:-1] for l in table_lines]
                    # Filter out separator
                    rows = [r for r in rows if not all(re.match(r'^:?-+:?$', c.strip()) for c in r)]
                    
                    table_html = "<div class='table-container'><table>\n"
                    for idx, row in enumerate(rows):
                        table_html += "<tr>\n"
                        tag = "th" if idx == 0 else "td"
                        for cell in row:
                            table_html += f"<{tag}>{cell.strip()}</{tag}>\n"
                        table_html += "</tr>\n"
                    table_html += "</table></div>\n"
                    new_lines.append(table_html)
                table_lines = []
                in_table = False
            new_lines.append(line)
            
    if in_table and len(table_lines) >= 2:
        rows = [l.strip().split('|')[1:-1] for l in table_lines]
        rows = [r for r in rows if not all(re.match(r'^:?-+:?$', c.strip()) for c in r)]
        table_html = "<div class='table-container'><table>\n"
        for idx, row in enumerate(rows):
            table_html += "<tr>\n"
            tag = "th" if idx == 0 else "td"
            for cell in row:
                table_html += f"<{tag}>{cell.strip()}</{tag}>\n"
            table_html += "</tr>\n"
        table_html += "</table></div>\n"
        new_lines.append(table_html)
        
    return '\n'.join(new_lines)

html_body = convert_tables(html_body)

# Formatting
html_body = re.sub(r'^# (.*$)', r'<h1>\1</h1>', html_body, flags=re.M)
html_body = re.sub(r'^## (.*$)', r'<h2>\1</h2>', html_body, flags=re.M)
html_body = re.sub(r'^### (.*$)', r'<h3>\1</h3>', html_body, flags=re.M)
html_body = re.sub(r'^#### (.*$)', r'<h4>\1</h4>', html_body, flags=re.M)
html_body = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', html_body)
html_body = re.sub(r'\*(.*?)\*', r'<em>\1</em>', html_body)
html_body = re.sub(r'`(.*?)`', r'<code>\1</code>', html_body)
html_body = re.sub(r'^\* (.*$)', r'<li>\1</li>', html_body, flags=re.M)
html_body = re.sub(r'^- (.*$)', r'<li>\1</li>', html_body, flags=re.M)

full_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartQE TEM - Senior TEM Architect Application & Industry Blueprint</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            line-height: 1.6;
            color: #1e293b;
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
            background-color: #f8fafc;
        }}
        .container {{
            background: #ffffff;
            padding: 50px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }}
        h1 {{
            color: #1e3a8a;
            font-size: 2.2rem;
            border-bottom: 3px solid #2563eb;
            padding-bottom: 12px;
            margin-top: 0;
        }}
        h2 {{
            color: #0f172a;
            font-size: 1.6rem;
            margin-top: 35px;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 8px;
        }}
        h3 {{
            color: #2563eb;
            font-size: 1.25rem;
            margin-top: 25px;
        }}
        p, li {{
            font-size: 1rem;
            color: #334155;
        }}
        code {{
            background-color: #f1f5f9;
            color: #0f172a;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: "Courier New", Courier, monospace;
            font-size: 0.9em;
        }}
        pre {{
            background-color: #0f172a;
            color: #f8fafc;
            padding: 18px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: "Courier New", Courier, monospace;
            font-size: 0.85em;
            line-height: 1.45;
        }}
        pre code {{
            background: none;
            color: inherit;
            padding: 0;
        }}
        .table-container {{
            overflow-x: auto;
            margin: 20px 0;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }}
        th, td {{
            padding: 10px 14px;
            text-align: left;
            border: 1px solid #cbd5e1;
        }}
        th {{
            background-color: #1e3a8a;
            color: #ffffff;
            font-weight: 600;
        }}
        tr:nth-child(even) {{
            background-color: #f8fafc;
        }}
        hr {{
            border: none;
            border-top: 1px solid #e2e8f0;
            margin: 30px 0;
        }}
        .badge {{
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 0.75rem;
        }}
    </style>
</head>
<body>
    <div class="container">
        {html_body}
    </div>
</body>
</html>
"""

with open(html_path, "w", encoding="utf-8") as f:
    f.write(full_html)

print(f"Successfully generated HTML file at: {html_path}")
