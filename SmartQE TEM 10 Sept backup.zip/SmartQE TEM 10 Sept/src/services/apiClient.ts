/**
 * Unified API Client for TESTOPS TEM CONTROL
 * Connects the React 19 Frontend with the FastAPI Microservice Backend.
 * Features:
 * - Sends and receives secure HttpOnly session cookies (credentials: 'include')
 * - Dual transport: Authorization Bearer header + Cookies
 * - Background request tagging (X-Background-Request: true) to prevent background polling from resetting idle timeouts
 * - Global 401 Unauthorized interception and session expiration event broadcasting
 */

const API_BASE_URL = (import.meta as any).env?.VITE_API_BASE_URL || 'http://localhost:8000/api/v1';
const AUTH_TOKEN_KEY = 'smartqe_tem_auth_token_v2';
const AUTH_USER_KEY = 'smartqe_tem_auth_user_v2';

export interface ApiRequestOptions extends RequestInit {
  isBackground?: boolean;
  timeoutMs?: number;
}

function handleUnauthorizedResponse(): void {
  try {
    const hasUser = localStorage.getItem(AUTH_USER_KEY);
    if (hasUser) {
      localStorage.removeItem(AUTH_USER_KEY);
      localStorage.removeItem(AUTH_TOKEN_KEY);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('session_expired', {
          detail: { message: 'Your session has expired due to inactivity. Please log in again.' }
        }));
      }
    }
  } catch {}
}

export async function fetchApi<T>(
  endpoint: string,
  options: ApiRequestOptions = {}
): Promise<T | null> {
  const token = localStorage.getItem(AUTH_TOKEN_KEY) || localStorage.getItem('access_token');
  const { isBackground, timeoutMs, ...fetchOptions } = options;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(fetchOptions.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  if (isBackground) {
    headers['X-Background-Request'] = 'true';
  }

  const effectiveTimeout = timeoutMs ?? (isBackground ? 6000 : 3000);
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), effectiveTimeout);

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      credentials: 'include',
      ...fetchOptions,
      headers,
      signal: controller.signal,
    });

    if (response.status === 401 && !endpoint.includes('/auth/login') && !endpoint.includes('/auth/json-login')) {
      handleUnauthorizedResponse();
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || errorData.message || 'Session expired. Please log in again.');
    }

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || errorData.message || `API error: ${response.status}`);
    }

    const json = await response.json();
    return json.data ?? (json as T);
  } catch (error) {
    console.warn(`[FastAPI Backend Connection Note] ${endpoint} request error:`, (error as Error).message);
    return null;
  } finally {
    clearTimeout(timeoutId);
  }
}

export async function fetchApiStrict<T>(
  endpoint: string,
  options: ApiRequestOptions = {}
): Promise<T> {
  const token = localStorage.getItem(AUTH_TOKEN_KEY) || localStorage.getItem('access_token');
  const { isBackground, timeoutMs, ...fetchOptions } = options;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(fetchOptions.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  if (isBackground) {
    headers['X-Background-Request'] = 'true';
  }

  const effectiveTimeout = timeoutMs ?? 3000;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), effectiveTimeout);

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      credentials: 'include',
      ...fetchOptions,
      headers,
      signal: controller.signal,
    });

    if (response.status === 401 && !endpoint.includes('/auth/login') && !endpoint.includes('/auth/json-login')) {
      handleUnauthorizedResponse();
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || errorData.message || 'Session expired. Please log in again.');
    }

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || errorData.message || `API error: ${response.status}`);
    }

    const json = await response.json();
    return json.data ?? (json as T);
  } finally {
    clearTimeout(timeoutId);
  }
}
