import { ServerDetail, SoftwareDetail, EnvironmentProfile } from '../types/environmentDetails';
import { fetchApi, fetchApiStrict } from './apiClient';
import { authService } from './authService';

const SERVERS_STORAGE_KEY = 'smartqe_tem_servers_v3';
const SOFTWARE_STORAGE_KEY = 'smartqe_tem_software_v3';
const PROFILES_STORAGE_KEY = 'smartqe_tem_env_profiles_v3';

export const INITIAL_SERVERS: ServerDetail[] = [
  {
    id: 'srv-26aug',
    name: 'Server_26Aug',
    hostIp: '120.1.23.12',
    serverType: 'Database Server',
    infrastructureType: 'ON_PREMISES',
    status: 'OFFLINE',
    operatingSystem: 'Windows',
    datacenter: 'US-East (Virginia DC-1)',
    rackUnit: 'Unit 4',
    cpuCores: 10,
    ramGb: 39,
    storageGb: 1000,
    environmentName: 'Performance / Stress',
    installedSoftwareIds: ['soft-26aug'],
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'srv-20aug-app',
    name: 'Servewr_20Aug',
    hostIp: '10.12.12.12',
    serverType: 'Application Server',
    infrastructureType: 'ON_PREMISES',
    status: 'ONLINE',
    operatingSystem: 'Ubuntu 22.04 LTS (Jammy)',
    datacenter: 'US-East (Virginia DC-1)',
    rackUnit: 'Rack A-04',
    cpuCores: 8,
    ramGb: 32,
    storageGb: 500,
    environmentName: 'Development',
    installedSoftwareIds: ['soft-20aug'],
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'srv-6681',
    name: 'Server_20Aug',
    hostIp: '10.12.1.12',
    serverType: 'Application Server',
    infrastructureType: 'ON_PREMISES',
    status: 'PROVISIONING',
    operatingSystem: 'windows',
    datacenter: 'Lucknow',
    rackUnit: 'Unit 2',
    cpuCores: 8,
    ramGb: 32,
    storageGb: 500,
    environmentName: 'QA / Testing',
    installedSoftwareIds: ['soft-20aug-s', 'soft-4837'],
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'srv-7416',
    name: 'Test_14_Aug',
    hostIp: '10.10.10.10',
    serverType: 'Database Server',
    infrastructureType: 'ON_PREMISES',
    status: 'ONLINE',
    operatingSystem: 'windows',
    datacenter: 'India',
    rackUnit: 'Unit-1',
    cpuCores: 16,
    ramGb: 70,
    storageGb: 5000,
    environmentName: 'UAT / Staging',
    installedSoftwareIds: ['soft-7434'],
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'srv-ashtest',
    name: 'AshTestServer',
    hostIp: '10.12.12.12',
    serverType: 'Web Server',
    infrastructureType: 'ON_PREMISES',
    status: 'MAINTENANCE',
    operatingSystem: 'Ubuntu 22.04 LTS (Jammy)',
    datacenter: 'US-East (Virginia DC-1)',
    cpuCores: 8,
    ramGb: 32,
    storageGb: 500,
    environmentName: 'Development',
    installedSoftwareIds: ['soft-ashtest'],
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'srv-4567',
    name: 'NewUser_Server',
    hostIp: '10.12.12.12',
    serverType: 'Application Server',
    infrastructureType: 'ON_PREMISES',
    status: 'ONLINE',
    operatingSystem: 'Ubuntu 22.04 LTS (Jammy)',
    datacenter: 'US-East (Virginia DC-1)',
    rackUnit: 'Rack A-04',
    cpuCores: 5,
    ramGb: 54,
    storageGb: 1100,
    environmentName: 'Development',
    installedSoftwareIds: ['soft-2296'],
    createdBy: 'Ashish Gautam',
    isActive: true,
  } as any
];

export const INITIAL_SOFTWARE: SoftwareDetail[] = [
  {
    id: 'soft-26aug',
    name: 'Software_26Aug',
    vendor: 'Addeco',
    version: 'v6.1',
    category: 'Application',
    port: '8080',
    status: 'ACTIVE',
    serverId: 'srv-26aug',
    environmentName: 'Performance / Stress',
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'soft-20aug-s',
    name: 'Softwares_20Aug',
    version: 'v3.0',
    category: 'Application',
    port: '',
    status: 'ACTIVE',
    serverId: 'srv-6681',
    environmentName: 'QA / Testing',
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'soft-20aug',
    name: 'Software_20Aug',
    vendor: 'SQE Team',
    version: 'v2.0',
    category: 'Application',
    port: '2000',
    status: 'ACTIVE',
    serverId: 'srv-20aug-app',
    environmentName: 'Development',
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'soft-7434',
    name: 'Test_14Aug_Software',
    vendor: 'SQE',
    version: 'v1.0',
    category: 'Application',
    port: '3000',
    status: 'ACTIVE',
    serverId: 'srv-7416',
    environmentName: 'UAT / Staging',
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'soft-4837',
    name: 'Software_12Aug',
    vendor: 'SQE Team',
    version: 'v1.0',
    category: 'Application',
    port: '8000',
    status: 'ACTIVE',
    serverId: 'srv-6681',
    environmentName: 'QA / Testing',
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'soft-ashtest',
    name: 'AshTest_software',
    version: 'v1.0',
    category: 'Application',
    port: '',
    status: 'ACTIVE',
    serverId: 'srv-ashtest',
    environmentName: 'Development',
    createdBy: 'Super Admin',
    isActive: true,
  } as any,
  {
    id: 'soft-2296',
    name: 'NewUser_Ash_software',
    version: 'v1.0',
    category: 'Application',
    port: '',
    status: 'ACTIVE',
    serverId: 'srv-4567',
    environmentName: 'Development',
    createdBy: 'Ashish Gautam',
    isActive: true,
  } as any
];

export const INITIAL_ENVIRONMENT_PROFILES: EnvironmentProfile[] = [
  { id: '5a9a8432-3f6d-4528-965a-c4f634261fa0', name: 'AshEnv_12Aug', type: 'Production', description: '', status: 'MAINTENANCE', isActive: true, ownerTeam: 'Shweta P', networkZone: '', serverIds: ['srv-6681'], softwareIds: ['soft-4837'], ownerId: 'user-1788328', createdBy: 'ashish', updatedAt: '2026-08-12 10:00:00' },
  { id: '92eeff4b-5a51-44a8-8fd9-381e9b898a84', name: 'NewUser_AshEnv', type: 'Development', description: '', status: 'HEALTHY', isActive: true, ownerTeam: 'Platform Operations', networkZone: '', serverIds: ['srv-4567'], softwareIds: ['soft-2296'], ownerId: 'user-1788328', createdBy: 'ashish', updatedAt: '2026-08-12 11:00:00' },
  { id: '0dfaa9d2-322b-48ed-b051-a844507372b2', name: 'Akn_Env_12_aug', type: 'Development', description: '', status: 'HEALTHY', isActive: true, ownerTeam: '', networkZone: '', serverIds: ['srv-6681'], softwareIds: ['soft-4837'], ownerId: 'user-1788331', createdBy: 'akash', updatedAt: '2026-08-12 12:00:00' },
  { id: '2c2726a3-e358-4537-9862-e5ab41059d6e', name: 'Akash Env', type: 'UAT / Staging', description: '', status: 'DEGRADED', isActive: true, ownerTeam: 'Ashish', networkZone: '', serverIds: ['srv-6681'], softwareIds: ['soft-4837'], ownerId: 'user-1788331', createdBy: 'akash', updatedAt: '2026-08-12 13:00:00' },
  { id: 'b7e13739-59a5-4105-a424-17730ae2b0dd', name: 'TenvirEnv_14Aug', type: 'Sandbox', description: '', status: 'MAINTENANCE', isActive: true, ownerTeam: 'SQE', networkZone: 'UP-east', serverIds: ['srv-7416'], softwareIds: ['soft-7434'], ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd', createdBy: 'admin', updatedAt: '2026-08-14 14:00:00' },
  { id: '87c76b6f-f953-41d3-b1c6-2e0f2d8c283b', name: 'Maintence_Test', type: 'Performance / Stress', description: '', status: 'MAINTENANCE', isActive: true, ownerTeam: 'Main_Team', networkZone: '', serverIds: ['srv-6681', 'srv-7416'], softwareIds: ['soft-7434', 'soft-4837'], ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd', createdBy: 'admin', updatedAt: '2026-08-15 15:00:00' },
  { id: 'fa320621-17de-4d37-9f18-69d9ca3a2b41', name: 'Test_20Aug', type: 'QA / Testing', description: '', status: 'HEALTHY', isActive: true, ownerTeam: 'test', networkZone: '', serverIds: ['srv-7416'], softwareIds: ['soft-7434'], ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd', createdBy: 'admin', updatedAt: '2026-08-20 16:00:00' },
  { id: '1bf9155d-95fc-44e9-8562-20ae1c9800ee', name: 'TestEnv-1787565393', type: 'QA / Testing', description: '', status: 'HEALTHY', isActive: true, ownerTeam: '', networkZone: '', serverIds: [], softwareIds: [], ownerId: 'bb4ae28d-f49e-4305-addd-6cb7835ca9bd', createdBy: 'admin', updatedAt: '2026-08-21 17:00:00' },
];

export const environmentDetailsService = {
  getServers(): ServerDetail[] {
    const sessionUser = authService.getCurrentSessionUser();
    const isSuperAdmin = sessionUser?.isSuperAdmin || sessionUser?.username?.toLowerCase() === 'admin';
    const keys = [SERVERS_STORAGE_KEY, 'smartqe_tem_servers_v2', 'smartqe_tem_servers_v1'];
    const serverMap = new Map<string, ServerDetail>();

    // 1. Seed baseline servers ONLY for Super Admin or matching creator
    if (isSuperAdmin) {
      INITIAL_SERVERS.forEach((s) => serverMap.set(s.id, { ...s, isActive: s.isActive !== false }));
    } else if (sessionUser) {
      INITIAL_SERVERS.forEach((s) => {
        if (
          s.createdBy?.toLowerCase() === sessionUser.username.toLowerCase() ||
          s.createdBy?.toLowerCase() === sessionUser.fullName?.toLowerCase()
        ) {
          serverMap.set(s.id, { ...s, isActive: s.isActive !== false });
        }
      });
    }

    // 2. Load from storage versions
    for (const key of keys) {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            parsed.forEach((s: ServerDetail) => {
              if (s && s.id) {
                if (isSuperAdmin) {
                  serverMap.set(s.id, { ...s, isActive: s.isActive !== false });
                } else if (sessionUser) {
                  const sOwner = (s as any).ownerId || '';
                  const sCreatedBy = (s.createdBy || '').toLowerCase();
                  if (
                    sOwner === sessionUser.id ||
                    sCreatedBy === sessionUser.username.toLowerCase() ||
                    sCreatedBy === sessionUser.fullName?.toLowerCase()
                  ) {
                    serverMap.set(s.id, { ...s, isActive: s.isActive !== false });
                  }
                }
              }
            });
          }
        } catch (e) {}
      }
    }

    return Array.from(serverMap.values());
  },

  async fetchServers(): Promise<ServerDetail[]> {
    return this.getServers();
  },

  async createServer(serverData: Omit<ServerDetail, 'id'>): Promise<ServerDetail> {
    const sessionUser = authService.getCurrentSessionUser();
    const newServer: ServerDetail = {
      ...serverData,
      isActive: serverData.isActive !== false,
      id: `srv-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      createdBy: sessionUser?.fullName || sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id,
    } as any;
    const current = this.getServers();
    const updated = [newServer, ...current.filter(s => s.id !== newServer.id)];
    this.saveServers(updated);
    return newServer;
  },

  async updateServer(id: string, serverData: Partial<ServerDetail>): Promise<void> {
    const current = this.getServers();
    const updated = current.map((s) =>
      s.id === id
        ? {
            ...s,
            ...serverData,
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          }
        : s
    );
    this.saveServers(updated);
  },

  async toggleServer(id: string): Promise<ServerDetail[]> {
    const current = this.getServers();
    const updated = current.map((s) =>
      s.id === id
        ? { ...s, isActive: !(s.isActive !== false), updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) }
        : s
    );
    this.saveServers(updated);
    return updated;
  },

  async deleteServer(id: string): Promise<void> {
    const current = this.getServers();
    const updated = current.map((s) => (s.id === id ? { ...s, isActive: false } : s));
    this.saveServers(updated);
  },

  saveServers(servers: ServerDetail[]): void {
    const sanitized = servers.map((s) => ({
      ...s,
      isActive: s.isActive !== false,
    }));
    try {
      localStorage.setItem(SERVERS_STORAGE_KEY, JSON.stringify(sanitized));
    } catch {}
  },

  // SOFTWARE
  getSoftware(): SoftwareDetail[] {
    const sessionUser = authService.getCurrentSessionUser();
    const isSuperAdmin = sessionUser?.isSuperAdmin || sessionUser?.username?.toLowerCase() === 'admin';
    const keys = [SOFTWARE_STORAGE_KEY, 'smartqe_tem_software_v2', 'smartqe_tem_software_v1'];
    const softMap = new Map<string, SoftwareDetail>();

    // 1. Seed baseline software ONLY for Super Admin or matching creator
    if (isSuperAdmin) {
      INITIAL_SOFTWARE.forEach((s) => softMap.set(s.id, { ...s, isActive: s.isActive !== false }));
    } else if (sessionUser) {
      INITIAL_SOFTWARE.forEach((s) => {
        if (
          s.createdBy?.toLowerCase() === sessionUser.username.toLowerCase() ||
          s.createdBy?.toLowerCase() === sessionUser.fullName?.toLowerCase()
        ) {
          softMap.set(s.id, { ...s, isActive: s.isActive !== false });
        }
      });
    }

    // 2. Load from storage versions
    for (const key of keys) {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            parsed.forEach((s: SoftwareDetail) => {
              if (s && s.id) {
                if (isSuperAdmin) {
                  softMap.set(s.id, { ...s, isActive: s.isActive !== false });
                } else if (sessionUser) {
                  const sOwner = (s as any).ownerId || '';
                  const sCreatedBy = (s.createdBy || '').toLowerCase();
                  if (
                    sOwner === sessionUser.id ||
                    sCreatedBy === sessionUser.username.toLowerCase() ||
                    sCreatedBy === sessionUser.fullName?.toLowerCase()
                  ) {
                    softMap.set(s.id, { ...s, isActive: s.isActive !== false });
                  }
                }
              }
            });
          }
        } catch (e) {}
      }
    }

    return Array.from(softMap.values());
  },

  async fetchSoftware(): Promise<SoftwareDetail[]> {
    return this.getSoftware();
  },

  async createSoftware(softwareData: Omit<SoftwareDetail, 'id'>): Promise<SoftwareDetail> {
    const sessionUser = authService.getCurrentSessionUser();
    const newSoftware: SoftwareDetail = {
      ...softwareData,
      isActive: softwareData.isActive !== false,
      id: `soft-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      createdBy: sessionUser?.fullName || sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id,
    } as any;
    const current = this.getSoftware();
    const updated = [newSoftware, ...current.filter(s => s.id !== newSoftware.id)];
    this.saveSoftware(updated);
    return newSoftware;
  },

  async updateSoftware(id: string, softwareData: Partial<SoftwareDetail>): Promise<void> {
    const current = this.getSoftware();
    const updated = current.map((s) =>
      s.id === id
        ? {
            ...s,
            ...softwareData,
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          }
        : s
    );
    this.saveSoftware(updated);
  },

  async toggleSoftware(id: string): Promise<SoftwareDetail[]> {
    const current = this.getSoftware();
    const updated = current.map((s) =>
      s.id === id
        ? { ...s, isActive: !(s.isActive !== false), updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) }
        : s
    );
    this.saveSoftware(updated);
    return updated;
  },

  async deleteSoftware(id: string): Promise<void> {
    const current = this.getSoftware();
    const updated = current.map((s) => (s.id === id ? { ...s, isActive: false } : s));
    this.saveSoftware(updated);
  },

  saveSoftware(software: SoftwareDetail[]): void {
    const sanitized = software.map((s) => ({
      ...s,
      isActive: s.isActive !== false,
    }));
    try {
      localStorage.setItem(SOFTWARE_STORAGE_KEY, JSON.stringify(sanitized));
    } catch {}
  },

  // ENVIRONMENT PROFILES
  getProfiles(): EnvironmentProfile[] {
    const sessionUser = authService.getCurrentSessionUser();
    const isSuperAdmin =
      !sessionUser ||
      sessionUser.isSuperAdmin ||
      sessionUser.username?.toLowerCase() === 'admin' ||
      (sessionUser.roles || []).some((r: any) =>
        ['super admin', 'superadmin', 'admin'].includes(r.name?.toLowerCase()?.trim()) && sessionUser.username?.toLowerCase() === 'admin'
      );

    const keys = [PROFILES_STORAGE_KEY, 'smartqe_tem_env_profiles_v2', 'smartqe_tem_env_profiles_v1'];
    const profileMap = new Map<string, EnvironmentProfile>();

    // Seed baseline profiles
    INITIAL_ENVIRONMENT_PROFILES.forEach((p) => profileMap.set(p.id, { ...p, isActive: p.isActive !== false }));

    for (const key of keys) {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            parsed.forEach((p: EnvironmentProfile) => {
              if (p && p.id) {
                profileMap.set(p.id, { ...p, isActive: p.isActive !== false });
              }
            });
          }
        } catch (e) {}
      }
    }

    const allProfiles = Array.from(profileMap.values());
    if (isSuperAdmin) {
      return allProfiles;
    }

    const userId = sessionUser?.id;
    const username = (sessionUser?.username || '').toLowerCase().trim();
    const fullName = (sessionUser?.fullName || '').toLowerCase().trim();

    return allProfiles.filter((p) => {
      const ownerId = p.ownerId || '';
      const createdBy = (p.createdBy || '').toLowerCase().trim();
      return (
        (ownerId && ownerId === userId) ||
        (createdBy && (createdBy === username || createdBy === fullName))
      );
    });
  },

  async fetchProfiles(): Promise<EnvironmentProfile[]> {
    const apiData = await fetchApi<any[]>('/environment-profiles');
    if (apiData && Array.isArray(apiData)) {
      const profiles: EnvironmentProfile[] = apiData.map((p) => ({
        id: p.id,
        name: p.name,
        type: p.type,
        description: p.description || '',
        status: p.status,
        isActive: p.isActive !== undefined ? p.isActive : (p.is_active !== undefined ? p.is_active : true),
        ownerTeam: p.ownerTeam || p.owner_team || '',
        networkZone: p.networkZone || p.network_zone || '',
        serverIds: p.serverIds || p.server_ids || [],
        softwareIds: p.softwareIds || p.software_ids || [],
        createdBy: p.createdBy || p.created_by,
        ownerId: p.ownerId || p.owner_id,
        updatedAt: p.updatedAt || p.updated_at
          ? new Date(p.updatedAt || p.updated_at).toISOString().replace('T', ' ').substring(0, 19)
          : new Date().toISOString().replace('T', ' ').substring(0, 19),
      }));
      this.saveProfiles(profiles);
      return profiles;
    }
    return this.getProfiles();
  },

  async createProfile(profileData: Omit<EnvironmentProfile, 'id' | 'updatedAt'>): Promise<EnvironmentProfile> {
    const sessionUser = authService.getCurrentSessionUser();
    const apiData = await fetchApi<any>('/environment-profiles', {
      method: 'POST',
      body: JSON.stringify({
        name: profileData.name,
        type: profileData.type,
        description: profileData.description,
        status: profileData.status,
        isActive: profileData.isActive !== false,
        ownerTeam: profileData.ownerTeam,
        networkZone: profileData.networkZone,
        serverIds: profileData.serverIds,
        softwareIds: profileData.softwareIds,
      }),
    });

    if (apiData) {
      const created: EnvironmentProfile = {
        id: apiData.id,
        name: apiData.name,
        type: apiData.type,
        description: apiData.description || '',
        status: apiData.status,
        isActive: apiData.isActive !== undefined ? apiData.isActive : (apiData.is_active !== undefined ? apiData.is_active : true),
        ownerTeam: apiData.ownerTeam || apiData.owner_team || '',
        networkZone: apiData.networkZone || apiData.network_zone || '',
        serverIds: apiData.serverIds || apiData.server_ids || [],
        softwareIds: apiData.softwareIds || apiData.software_ids || [],
        createdBy: apiData.createdBy || apiData.created_by || sessionUser?.username || 'Super Admin',
        ownerId: apiData.ownerId || apiData.owner_id || sessionUser?.id,
        updatedAt: apiData.updatedAt || apiData.updated_at
          ? new Date(apiData.updatedAt || apiData.updated_at).toISOString().replace('T', ' ').substring(0, 19)
          : new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
      this.saveProfiles([created]);
      return created;
    }

    const newProfile: EnvironmentProfile = {
      ...profileData,
      isActive: profileData.isActive !== false,
      id: `env-prof-${Date.now().toString().slice(-4)}`,
      createdBy: sessionUser?.username || 'Super Admin',
      ownerId: sessionUser?.id,
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    } as any;
    this.saveProfiles([newProfile]);
    return newProfile;
  },

  async updateProfile(id: string, profileData: Partial<EnvironmentProfile>): Promise<void> {
    await fetchApi(`/environment-profiles/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: profileData.name,
        type: profileData.type,
        description: profileData.description,
        status: profileData.status,
        isActive: profileData.isActive,
        ownerTeam: profileData.ownerTeam,
        networkZone: profileData.networkZone,
        serverIds: profileData.serverIds,
        softwareIds: profileData.softwareIds,
      }),
    });
  },

  async toggleProfile(id: string): Promise<EnvironmentProfile[]> {
    const current = this.getProfiles();
    const target = current.find((p) => p.id === id);
    if (!target) return current;

    const newActive = !(target.isActive !== false);
    try {
      await fetchApiStrict(`/environment-profiles/${id}/toggle-status`, {
        method: 'PATCH',
      });
    } catch (err: any) {
      if (err.message && !err.message.includes('Failed to fetch') && !err.message.includes('NetworkError')) {
        throw err;
      }
    }

    const updated = current.map((p) =>
      p.id === id
        ? { ...p, isActive: newActive, updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) }
        : p
    );
    this.saveProfiles(updated);
    return updated;
  },

  async deleteProfile(id: string): Promise<void> {
    try {
      await fetchApi(`/environment-profiles/${id}`, {
        method: 'DELETE',
      });
    } catch {}
    const current = this.getProfiles();
    const updated = current.map((p) => (p.id === id ? { ...p, isActive: false } : p));
    this.saveProfiles(updated);
  },

  saveProfiles(profiles: EnvironmentProfile[]): void {
    const keys = [PROFILES_STORAGE_KEY, 'smartqe_tem_env_profiles_v2', 'smartqe_tem_env_profiles_v1'];
    const profileMap = new Map<string, EnvironmentProfile>();
    INITIAL_ENVIRONMENT_PROFILES.forEach((p) => profileMap.set(p.id, { ...p, isActive: p.isActive !== false }));
    for (const key of keys) {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            parsed.forEach((p: EnvironmentProfile) => {
              if (p && p.id) profileMap.set(p.id, { ...p, isActive: p.isActive !== false });
            });
          }
        } catch (e) {}
      }
    }
    profiles.forEach((p) => {
      if (p && p.id) profileMap.set(p.id, { ...p, isActive: p.isActive !== false });
    });

    try {
      localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(Array.from(profileMap.values())));
    } catch {}
  }
};
