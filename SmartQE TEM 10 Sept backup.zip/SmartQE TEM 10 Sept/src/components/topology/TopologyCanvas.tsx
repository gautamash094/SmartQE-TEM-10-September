import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  Server,
  Layers,
  Cpu,
  Database,
  Code2,
  Cloud,
  Network,
  HardDrive,
  Globe,
  AlertTriangle,
  Radio,
  ExternalLink,
  Zap,
  Activity
} from 'lucide-react';
import {
  TopologyNode,
  TopologyEdge,
  TopologyLayoutType,
  TopologyViewMode
} from '../../types/topology';

interface TopologyCanvasProps {
  nodes: TopologyNode[];
  edges: TopologyEdge[];
  selectedNodeId: string | null;
  highlightedNodeIds?: Set<string>;
  highlightedEdgeIds?: Set<string>;
  layoutType: TopologyLayoutType;
  viewMode: TopologyViewMode;
  searchQuery: string;
  zoomLevel: number;
  onSelectNode: (node: TopologyNode) => void;
  onOpenImpactModal: (node: TopologyNode) => void;
  onAddRelationshipFromNode?: (node: TopologyNode) => void;
}

const NODE_WIDTH = 220;
const NODE_HEIGHT = 76;

const getNodeIcon = (type: string) => {
  switch (type.toUpperCase()) {
    case 'ENVIRONMENT':
      return Globe;
    case 'APPLICATION':
    case 'MICROSERVICE':
      return Layers;
    case 'SERVER':
      return Server;
    case 'DATABASE':
      return Database;
    case 'SOFTWARE':
    case 'SERVICE':
      return Code2;
    case 'CLOUD_RESOURCE':
      return Cloud;
    case 'NETWORK_COMPONENT':
    case 'GATEWAY':
      return Network;
    case 'STORAGE':
      return HardDrive;
    default:
      return Cpu;
  }
};

const getNodeTypeColor = (type: string) => {
  switch (type.toUpperCase()) {
    case 'ENVIRONMENT':
      return {
        border: 'border-cyan-500/80',
        bg: 'bg-cyan-50 dark:bg-[#091522]',
        iconBg: 'bg-cyan-500/20 text-cyan-400',
        tagBg: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
      };
    case 'APPLICATION':
    case 'MICROSERVICE':
      return {
        border: 'border-orange-500/80',
        bg: 'bg-orange-50 dark:bg-[#1a1209]',
        iconBg: 'bg-orange-500/20 text-orange-400',
        tagBg: 'bg-orange-500/10 text-orange-400 border-orange-500/30'
      };
    case 'SERVER':
      return {
        border: 'border-blue-500/80',
        bg: 'bg-blue-50 dark:bg-[#0c1424]',
        iconBg: 'bg-blue-500/20 text-blue-400',
        tagBg: 'bg-blue-500/10 text-blue-400 border-blue-500/30'
      };
    case 'DATABASE':
      return {
        border: 'border-emerald-500/80',
        bg: 'bg-emerald-50 dark:bg-[#0a1812]',
        iconBg: 'bg-emerald-500/20 text-emerald-400',
        tagBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
      };
    case 'SOFTWARE':
    case 'SERVICE':
      return {
        border: 'border-purple-500/80',
        bg: 'bg-purple-50 dark:bg-[#150d22]',
        iconBg: 'bg-purple-500/20 text-purple-400',
        tagBg: 'bg-purple-500/10 text-purple-400 border-purple-500/30'
      };
    default:
      return {
        border: 'border-slate-600',
        bg: 'bg-[#111827]',
        iconBg: 'bg-slate-700 text-slate-300',
        tagBg: 'bg-slate-800 text-slate-400 border-slate-700'
      };
  }
};

const getStatusBadge = (status: string) => {
  switch (status?.toUpperCase()) {
    case 'HEALTHY':
    case 'ACTIVE':
    case 'AVAILABLE':
      return { color: 'bg-emerald-500', text: 'HEALTHY', border: 'border-emerald-500/40' };
    case 'WARNING':
    case 'DEGRADED':
      return { color: 'bg-amber-500', text: 'WARNING', border: 'border-amber-500/40' };
    case 'CRITICAL':
    case 'UNAVAILABLE':
    case 'DOWN':
      return { color: 'bg-red-500', text: 'DOWN', border: 'border-red-500/40' };
    case 'MAINTENANCE':
      return { color: 'bg-purple-500', text: 'MAINT', border: 'border-purple-500/40' };
    default:
      return { color: 'bg-slate-500', text: 'UNKNOWN', border: 'border-slate-500/40' };
  }
};

export const TopologyCanvas: React.FC<TopologyCanvasProps> = ({
  nodes,
  edges,
  selectedNodeId,
  highlightedNodeIds,
  highlightedEdgeIds,
  layoutType,
  viewMode,
  searchQuery,
  zoomLevel,
  onSelectNode,
  onOpenImpactModal
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Pan Offset
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 80, y: 60 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Custom dragged node positions
  const [nodePositions, setNodePositions] = useState<Record<string, { x: number; y: number }>>({});
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [nodeDragOffset, setNodeDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Hovered Node for instant path highlighting
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);

  // Calculate Layout Positions
  useEffect(() => {
    const newPositions: Record<string, { x: number; y: number }> = {};

    if (layoutType === 'GROUPED_ENV') {
      // Group by Environment
      const envGroups: Record<string, TopologyNode[]> = {};
      nodes.forEach(n => {
        const envKey = n.environment_name || n.environment_id || 'Global / Unassigned';
        if (!envGroups[envKey]) envGroups[envKey] = [];
        envGroups[envKey].push(n);
      });

      let currentX = 60;
      Object.entries(envGroups).forEach(([_, groupNodes]) => {
        let currentY = 80;
        groupNodes.forEach((node) => {
          newPositions[node.id] = { x: currentX, y: currentY };
          currentY += NODE_HEIGHT + 40;
        });
        currentX += NODE_WIDTH + 140;
      });
    } else if (layoutType === 'FLOW') {
      // Horizontal flow pipeline
      const typeCols: Record<string, number> = {
        ENVIRONMENT: 0,
        APPLICATION: 1,
        MICROSERVICE: 1,
        SERVER: 2,
        SOFTWARE: 3,
        SERVICE: 3,
        DATABASE: 4,
        CLOUD_RESOURCE: 4,
        STORAGE: 4,
      };

      const colCounters: Record<number, number> = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0 };
      nodes.forEach(node => {
        const col = typeCols[node.type.toUpperCase()] ?? 2;
        const row = colCounters[col] || 0;
        colCounters[col] = row + 1;

        newPositions[node.id] = {
          x: 60 + col * (NODE_WIDTH + 120),
          y: 80 + row * (NODE_HEIGHT + 50)
        };
      });
    } else {
      // Standard Hierarchical Layered Layout
      const layers: Record<string, TopologyNode[]> = {
        ENVIRONMENT: [],
        APPLICATION: [],
        SERVER: [],
        SOFTWARE: [],
        DATABASE: []
      };

      nodes.forEach(node => {
        const t = node.type.toUpperCase();
        if (t === 'ENVIRONMENT') layers.ENVIRONMENT.push(node);
        else if (t === 'APPLICATION' || t === 'MICROSERVICE') layers.APPLICATION.push(node);
        else if (t === 'SERVER') layers.SERVER.push(node);
        else if (t === 'SOFTWARE' || t === 'SERVICE') layers.SOFTWARE.push(node);
        else layers.DATABASE.push(node);
      });

      let layerY = 60;
      Object.values(layers).forEach(layerNodes => {
        if (layerNodes.length > 0) {
          const totalWidth = layerNodes.length * (NODE_WIDTH + 40);
          const startX = Math.max(60, 600 - totalWidth / 2);

          layerNodes.forEach((node, idx) => {
            newPositions[node.id] = {
              x: startX + idx * (NODE_WIDTH + 40),
              y: layerY
            };
          });

          layerY += NODE_HEIGHT + 90;
        }
      });
    }

    setNodePositions(newPositions);
  }, [nodes, layoutType]);

  // Compute connected nodes for hovered/selected node
  const activeConnectedInfo = useMemo(() => {
    const focusId = hoveredNodeId || selectedNodeId;
    if (!focusId) return null;

    const connectedNodes = new Set<string>([focusId]);
    const connectedEdges = new Set<string>();

    edges.forEach(e => {
      if (e.source === focusId || e.target === focusId) {
        connectedNodes.add(e.source);
        connectedNodes.add(e.target);
        connectedEdges.add(e.id);
      }
    });

    return { connectedNodes, connectedEdges };
  }, [hoveredNodeId, selectedNodeId, edges]);

  // Canvas Mouse Drag for Pan
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.topology-node')) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    } else if (draggingNodeId) {
      setNodePositions(prev => ({
        ...prev,
        [draggingNodeId]: {
          x: (e.clientX - pan.x) / zoomLevel - nodeDragOffset.x,
          y: (e.clientY - pan.y) / zoomLevel - nodeDragOffset.y
        }
      }));
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDraggingNodeId(null);
  };

  const handleNodeMouseDown = (e: React.MouseEvent, nodeId: string) => {
    e.stopPropagation();
    const pos = nodePositions[nodeId] || { x: 0, y: 0 };
    setDraggingNodeId(nodeId);
    setNodeDragOffset({
      x: (e.clientX - pan.x) / zoomLevel - pos.x,
      y: (e.clientY - pan.y) / zoomLevel - pos.y
    });
  };

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="relative w-full h-[640px] bg-slate-100 dark:bg-[#070b12] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden cursor-grab active:cursor-grabbing select-none"
      style={{
        backgroundImage: `
          radial-gradient(circle at 50% 50%, rgba(249, 115, 22, 0.03) 0%, transparent 60%),
          linear-gradient(to right, rgba(255, 255, 255, 0.03) 1px, transparent 1px),
          linear-gradient(to bottom, rgba(255, 255, 255, 0.03) 1px, transparent 1px)
        `,
        backgroundSize: '100% 100%, 28px 28px, 28px 28px'
      }}
    >
      {/* SVG Container for directional relationship edges */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoomLevel})`,
          transformOrigin: '0 0'
        }}
      >
        <defs>
          {/* Default Edge Arrowhead */}
          <marker
            id="arrow-default"
            viewBox="0 0 10 10"
            refX="9"
            refY="5"
            markerWidth="6"
            markerHeight="6"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#64748b" />
          </marker>
          {/* Active / Highlighted Edge Arrowhead */}
          <marker
            id="arrow-active"
            viewBox="0 0 10 10"
            refX="9"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#f97316" />
          </marker>
          {/* Animated Glow Filter */}
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Draw Edges */}
        {edges.map((edge) => {
          const sourcePos = nodePositions[edge.source];
          const targetPos = nodePositions[edge.target];
          if (!sourcePos || !targetPos) return null;

          const sx = sourcePos.x + NODE_WIDTH / 2;
          const sy = sourcePos.y + NODE_HEIGHT;
          const tx = targetPos.x + NODE_WIDTH / 2;
          const ty = targetPos.y;

          const isHighlighted =
            (activeConnectedInfo && activeConnectedInfo.connectedEdges.has(edge.id)) ||
            (highlightedEdgeIds && highlightedEdgeIds.has(edge.id));

          const isDimmed = activeConnectedInfo && !isHighlighted;

          // Bezier control points for smooth enterprise curvature
          const dy = Math.max(40, Math.abs(ty - sy) * 0.5);
          const pathD = `M ${sx} ${sy} C ${sx} ${sy + dy}, ${tx} ${ty - dy}, ${tx} ${ty}`;
          const midX = (sx + tx) / 2;
          const midY = (sy + ty) / 2;

          return (
            <g key={edge.id} className="transition-opacity duration-200" style={{ opacity: isDimmed ? 0.2 : 1 }}>
              {/* Edge line */}
              <path
                d={pathD}
                fill="none"
                stroke={isHighlighted ? '#f97316' : '#334155'}
                strokeWidth={isHighlighted ? 2.5 : 1.5}
                strokeDasharray={edge.is_custom ? '4 3' : undefined}
                markerEnd={isHighlighted ? 'url(#arrow-active)' : 'url(#arrow-default)'}
                filter={isHighlighted ? 'url(#glow)' : undefined}
              />

              {/* Edge Label / Protocol badge */}
              <g transform={`translate(${midX}, ${midY})`}>
                <rect
                  x="-38"
                  y="-10"
                  width="76"
                  height="18"
                  rx="4"
                  fill="#0c121e"
                  stroke={isHighlighted ? '#f97316' : '#334155'}
                  strokeWidth="1"
                />
                <text
                  x="0"
                  y="2"
                  textAnchor="middle"
                  fill={isHighlighted ? '#fdba74' : '#94a3b8'}
                  fontSize="8.5"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  {edge.label || edge.relationship_type.replace('_', ' ')}
                </text>
              </g>

              {/* Animated particle pulse on active edge */}
              {isHighlighted && (
                <circle r="3.5" fill="#f97316">
                  <animateMotion dur="2.5s" repeatCount="indefinite" path={pathD} />
                </circle>
              )}
            </g>
          );
        })}
      </svg>

      {/* Nodes Container */}
      <div
        className="absolute inset-0"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoomLevel})`,
          transformOrigin: '0 0'
        }}
      >
        {nodes.map((node) => {
          const pos = nodePositions[node.id] || { x: 60, y: 60 };
          const Icon = getNodeIcon(node.type);
          const style = getNodeTypeColor(node.type);
          const statusBadge = getStatusBadge(node.status);
          const isSelected = selectedNodeId === node.id;

          const isConnected = activeConnectedInfo ? activeConnectedInfo.connectedNodes.has(node.id) : true;
          const matchesSearch = searchQuery
            ? node.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              node.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
              (node.ip_address && node.ip_address.includes(searchQuery))
            : true;

          const isDimmed = (activeConnectedInfo && !isConnected) || (!matchesSearch && searchQuery);

          return (
            <div
              key={node.id}
              style={{
                left: `${pos.x}px`,
                top: `${pos.y}px`,
                width: `${NODE_WIDTH}px`,
                height: `${NODE_HEIGHT}px`,
                opacity: isDimmed ? 0.25 : 1
              }}
              onMouseDown={(e) => handleNodeMouseDown(e, node.id)}
              onMouseEnter={() => setHoveredNodeId(node.id)}
              onMouseLeave={() => setHoveredNodeId(null)}
              onClick={() => onSelectNode(node)}
              className={`topology-node absolute p-2.5 rounded-xl border ${style.border} ${style.bg} transition-all duration-150 cursor-pointer shadow-lg hover:shadow-2xl hover:scale-[1.02] flex flex-col justify-between ${
                isSelected
                  ? 'ring-2 ring-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.4)] scale-105 z-30'
                  : 'hover:border-orange-500/80 z-10'
              }`}
            >
              {/* Header: Icon + Name + Health Status */}
              <div className="flex items-center justify-between gap-2 overflow-hidden">
                <div className="flex items-center gap-2 overflow-hidden">
                  <div className={`w-7 h-7 rounded-lg ${style.iconBg} flex items-center justify-center shrink-0`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="overflow-hidden truncate">
                    <h4 className="text-xs font-bold text-white truncate font-mono" title={node.name}>
                      {node.name}
                    </h4>
                    <span className="text-[9px] font-mono text-slate-400 tracking-wider uppercase block truncate">
                      {node.sub_type || node.type}
                    </span>
                  </div>
                </div>

                {/* Health Dot Status */}
                <div className="flex items-center gap-1 shrink-0">
                  <span className={`w-2 h-2 rounded-full ${statusBadge.color} shadow-sm animate-pulse`} />
                </div>
              </div>

              {/* Sub-Footer: Info badge & Active Incident indicator */}
              <div className="flex items-center justify-between text-[9px] font-mono pt-1 border-t border-slate-200 dark:border-slate-800/80">
                <span className="text-slate-400 truncate max-w-[120px]">
                  {node.ip_address || node.environment_name || node.business_unit || 'Active'}
                </span>

                {/* Active Incident Warning Flag */}
                {(node.active_incidents_count || 0) > 0 ? (
                  <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40 font-bold animate-bounce">
                    <AlertTriangle className="w-2.5 h-2.5" />
                    <span>{node.active_incidents_count} INC</span>
                  </span>
                ) : (
                  <span className="text-slate-500">{node.cloud_provider || 'Local'}</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating Canvas Watermark Overlay */}
      <div className="absolute bottom-3 left-4 pointer-events-none font-mono text-[10px] text-slate-500 flex items-center gap-4">
        <span>Nodes: {nodes.length}</span>
        <span>Edges: {edges.length}</span>
        <span>Layout: {layoutType}</span>
        <span>Zoom: {Math.round(zoomLevel * 100)}%</span>
      </div>
    </div>
  );
};
