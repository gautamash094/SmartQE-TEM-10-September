import React from 'react';
import { LoadingSpinner, SpinnerSize, SpinnerVariant } from './LoadingSpinner';

interface ButtonLoaderProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  loadingText?: string;
  spinnerSize?: SpinnerSize;
  spinnerVariant?: SpinnerVariant;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

export const ButtonLoader: React.FC<ButtonLoaderProps> = ({
  isLoading = false,
  loadingText,
  spinnerSize = 'sm',
  spinnerVariant = 'white',
  icon,
  children,
  disabled,
  className = '',
  ...props
}) => {
  return (
    <button
      {...props}
      disabled={disabled || isLoading}
      className={`relative inline-flex items-center justify-center gap-2 transition-all font-mono font-bold select-none ${
        isLoading ? 'cursor-not-allowed opacity-80' : ''
      } ${className}`}
    >
      {isLoading ? (
        <>
          <LoadingSpinner size={spinnerSize} variant={spinnerVariant} inline />
          <span>{loadingText || children}</span>
        </>
      ) : (
        <>
          {icon && <span className="shrink-0">{icon}</span>}
          <span>{children}</span>
        </>
      )}
    </button>
  );
};
