﻿import React from 'react';
import { LoadingSpinner, SpinnerSize, SpinnerVariant } from './LoadingSpinner';

interface SectionLoaderProps {
  label?: string;
  size?: SpinnerSize;
  variant?: SpinnerVariant;
  className?: string;
  isOverlay?: boolean;
  minHeight?: string;
}

export const SectionLoader: React.FC<SectionLoaderProps> = ({
  label = 'Loading data...',
  size = 'md',
  variant = 'primary',
  className = '',
  isOverlay = false,
  minHeight = 'min-h-[200px]',
}) => {
  if (isOverlay) {
    return (
      <div
        className={`absolute inset-0 z-20 flex flex-col items-center justify-center bg-white/70 dark:bg-[#070b13]/70 backdrop-blur-[2px] rounded-lg transition-all ${className}`}
      >
        <LoadingSpinner size={size} variant={variant} label={label} />
      </div>
    );
  }

  return (
    <div
      className={`w-full flex flex-col items-center justify-center p-8 bg-slate-50 dark:bg-[#0c1322]/50 border border-slate-200 dark:border-slate-800/80 rounded-lg ${minHeight} ${className}`}
    >
      <LoadingSpinner size={size} variant={variant} label={label} />
    </div>
  );
};