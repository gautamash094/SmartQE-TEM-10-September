import React from 'react';
import { Booking } from '../../types';
import {
  Clock,
  AlertTriangle,
} from 'lucide-react';

interface WeeklyViewProps {
  currentDate: Date;
  bookings: Booking[];
  conflictMap: Map<string, string[]>;
  onSelectBooking: (booking: Booking) => void;
}

const safeParseDate = (dateVal: string | Date | undefined | null): Date | null => {
  if (!dateVal) return null;
  if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
  const isoStr = String(dateVal).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d;
  const dRaw = new Date(dateVal);
  return isNaN(dRaw.getTime()) ? null : dRaw;
};

export const WeeklyView: React.FC<WeeklyViewProps> = ({
  currentDate,
  bookings,
  conflictMap,
  onSelectBooking,
}) => {
  const getWeekDays = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(d.setDate(diff));
    monday.setHours(0, 0, 0, 0);

    const weekDays: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const nextDay = new Date(monday);
      nextDay.setDate(monday.getDate() + i);
      weekDays.push(nextDay);
    }
    return weekDays;
  };

  const weekDays = getWeekDays(currentDate);

  const isSameDay = (d1: Date, d2: Date) => {
    return (
      d1.getFullYear() === d2.getFullYear() &&
      d1.getMonth() === d2.getMonth() &&
      d1.getDate() === d2.getDate()
    );
  };

  const isToday = (d: Date) => isSameDay(d, new Date());

  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const weekStartMs = new Date(weekDays[0]).setHours(0, 0, 0, 0);
  const weekEndMs = new Date(weekDays[6]).setHours(23, 59, 59, 999);

  const weekBookings = (bookings || []).filter((b) => {
    const sDate = safeParseDate(b.startDate);
    const eDate = safeParseDate(b.endDate);
    if (!sDate || !eDate) return false;
    return sDate.getTime() <= weekEndMs && eDate.getTime() >= weekStartMs;
  });

  const formatShortRange = (sStr: string, eStr: string) => {
    try {
      const s = safeParseDate(sStr);
      const e = safeParseDate(eStr);
      if (!s || !e) return '';
      const sM = s.toLocaleString('default', { month: 'short' });
      const eM = e.toLocaleString('default', { month: 'short' });
      if (sM === eM && s.getDate() === e.getDate()) {
        return `${sM} ${s.getDate()}`;
      }
      if (sM === eM) return `${sM} ${s.getDate()}–${e.getDate()}`;
      return `${sM} ${s.getDate()} – ${eM} ${e.getDate()}`;
    } catch {
      return '';
    }
  };

  return (
    <div className="bg-[#0b1019] border border-slate-800 rounded-xl overflow-hidden shadow-2xl font-mono text-xs w-full">
      {/* 7-Day Header Grid */}
      <div className="grid grid-cols-7 border-b border-slate-800 bg-[#090d14] divide-x divide-slate-800/80">
        {weekDays.map((day, idx) => {
          const today = isToday(day);

          return (
            <div
              key={day.toISOString()}
              className={`p-3 text-center flex flex-col items-center justify-center relative ${
                today ? 'bg-orange-950/30' : ''
              }`}
            >
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                {dayNames[idx]}
              </span>
              <div className="flex items-center gap-1.5 mt-1">
                <span
                  className={`text-lg font-black ${
                    today ? 'text-orange-400 font-extrabold' : 'text-white'
                  }`}
                >
                  {day.getDate()}
                </span>
                {today && (
                  <span className="text-[8px] uppercase tracking-wider font-extrabold text-orange-400 bg-orange-950 px-1 py-0.5 rounded border border-orange-800">
                    TODAY
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Grid Body */}
      <div className="relative p-4 min-h-[360px] bg-[#070b12]">
        <div className="absolute inset-0 grid grid-cols-7 pointer-events-none divide-x divide-slate-800/40">
          {weekDays.map((_, i) => (
            <div key={i} className="h-full" />
          ))}
        </div>

        <div className="relative z-10 space-y-2.5">
          {weekBookings.length === 0 ? (
            <div className="text-slate-700 text-xs italic text-center py-20">
              No allocations scheduled for this week window
            </div>
          ) : (
            weekBookings.map((b) => {
              const bStart = safeParseDate(b.startDate) || new Date();
              const bEnd = safeParseDate(b.endDate) || bStart;

              let startIndex = weekDays.findIndex((d) => isSameDay(d, bStart));
              if (startIndex === -1) {
                startIndex = bStart.getTime() < weekStartMs ? 0 : 6;
              }

              let endIndex = weekDays.findIndex((d) => isSameDay(d, bEnd));
              if (endIndex === -1) {
                endIndex = bEnd.getTime() > weekEndMs ? 6 : startIndex;
              }

              const colStart = Math.max(1, Math.min(7, startIndex + 1));
              const rawSpan = Math.max(1, endIndex - startIndex + 1);
              const maxAllowedSpan = 7 - colStart + 1;
              const colSpan = Math.max(1, Math.min(maxAllowedSpan, rawSpan));
              const isConflict = conflictMap.has(b.id);

              return (
                <div key={b.id} className="grid grid-cols-7">
                  <div
                    style={{
                      gridColumn: `${colStart} / span ${colSpan}`,
                    }}
                    onClick={() => onSelectBooking(b)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between gap-2 group hover:scale-[1.005] hover:brightness-110 ${
                      isConflict
                        ? 'bg-red-950/90 border-red-500 text-red-100 shadow-[0_0_12px_rgba(239,68,68,0.5)] animate-pulse'
                        : 'bg-gradient-to-r from-orange-950/90 via-[#2f1406] to-orange-900/90 border-orange-600/90 hover:border-orange-400 text-orange-200 shadow-[0_0_10px_rgba(249,115,22,0.25)] hover:shadow-[0_0_14px_rgba(249,115,22,0.4)]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 truncate">
                        {isConflict ? (
                          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                        ) : (
                          <Clock className="w-4 h-4 text-orange-400 shrink-0" />
                        )}
                        <span className="font-extrabold text-orange-100 group-hover:text-white text-sm truncate">
                          {b.purpose}
                        </span>
                      </div>

                      <span className={`text-[9px] px-2 py-0.5 rounded border uppercase font-bold shrink-0 ${
                        (b.reservationMode || 'SHARED') === 'DISRUPTIVE'
                          ? 'bg-amber-950/90 text-amber-300 border-amber-800'
                          : 'bg-cyan-950/90 text-cyan-300 border-cyan-800'
                      }`}>
                        {(b.reservationMode || 'SHARED') === 'DISRUPTIVE' ? '⚡ DISRUPTIVE' : '👥 SHARED'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-orange-300/80 font-mono">
                      <span>{b.environmentName || b.application}</span>
                      <span className="text-orange-300 bg-orange-950/80 px-2 py-0.5 rounded border border-orange-800/80 font-bold">
                        {formatShortRange(b.startDate, b.endDate)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
