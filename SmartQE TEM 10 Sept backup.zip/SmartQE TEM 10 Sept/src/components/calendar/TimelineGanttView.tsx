import React, { useRef, useEffect, useMemo } from 'react';
import { Booking, Environment } from '../../types';
import {
  AlertTriangle,
  Server,
  Clock,
  User,
  Building2,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  Sparkles,
  Info
} from 'lucide-react';

export type GanttScope = 'month' | '2weeks' | 'quarter' | '6months';

interface TimelineGanttViewProps {
  currentDate: Date;
  environments: Environment[];
  bookings: Booking[];
  conflictMap: Map<string, string[]>;
  ganttScope?: GanttScope;
  onChangeScope?: (scope: GanttScope) => void;
  onSelectBooking: (booking: Booking) => void;
  onNavigateMonth?: (date: Date) => void;
}

export const TimelineGanttView: React.FC<TimelineGanttViewProps> = ({
  currentDate,
  environments,
  bookings,
  conflictMap,
  ganttScope = 'month',
  onChangeScope,
  onSelectBooking,
  onNavigateMonth,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const todayColumnRef = useRef<HTMLDivElement>(null);

  const today = useMemo(() => new Date(), []);

  // Helper to test if a date is today
  const isSameDay = (d1: Date, d2: Date) => {
    return (
      d1.getFullYear() === d2.getFullYear() &&
      d1.getMonth() === d2.getMonth() &&
      d1.getDate() === d2.getDate()
    );
  };

  const isToday = (d: Date) => isSameDay(d, today);

  const parseSafeDate = (dt: string | Date | undefined): Date | null => {
    if (!dt) return null;
    if (dt instanceof Date) return isNaN(dt.getTime()) ? null : dt;
    const clean = typeof dt === 'string' ? dt.trim().replace(' ', 'T') : String(dt);
    const d = new Date(clean);
    if (!isNaN(d.getTime())) return d;
    const fallback = new Date(dt);
    return isNaN(fallback.getTime()) ? null : fallback;
  };

  // Helper: Format display date time
  const formatDisplayDateTime = (dtStr: string) => {
    if (!dtStr) return '';
    try {
      const d = parseSafeDate(dtStr);
      if (!d) return dtStr;
      return d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dtStr;
    }
  };

  // Compute the list of dates for the timeline based on scope and currentDate
  const timelineDates = useMemo(() => {
    const dates: Date[] = [];
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    if (ganttScope === '2weeks') {
      // 14 days centered or starting 3 days before today / currentDate
      const start = new Date(currentDate);
      start.setDate(start.getDate() - 3);
      start.setHours(0, 0, 0, 0);

      for (let i = 0; i < 14; i++) {
        const d = new Date(start);
        d.setDate(start.getDate() + i);
        dates.push(d);
      }
    } else if (ganttScope === 'quarter') {
      // 3 full months starting from current month
      const start = new Date(year, month, 1, 0, 0, 0, 0);
      const endMonth = new Date(year, month + 3, 0, 23, 59, 59, 999);
      const totalDays = Math.round((endMonth.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));

      for (let i = 0; i < totalDays; i++) {
        const d = new Date(start);
        d.setDate(start.getDate() + i);
        dates.push(d);
      }
    } else if (ganttScope === '6months') {
      // 6 full months
      const start = new Date(year, month, 1, 0, 0, 0, 0);
      const endMonth = new Date(year, month + 6, 0, 23, 59, 59, 999);
      const totalDays = Math.round((endMonth.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));

      for (let i = 0; i < totalDays; i++) {
        const d = new Date(start);
        d.setDate(start.getDate() + i);
        dates.push(d);
      }
    } else {
      // Default: 'month' - All days in current month
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      for (let day = 1; day <= daysInMonth; day++) {
        dates.push(new Date(year, month, day, 0, 0, 0, 0));
      }
    }

    return dates;
  }, [currentDate, ganttScope]);

  const timelineStart = useMemo(() => {
    if (timelineDates.length === 0) return new Date();
    const d = new Date(timelineDates[0]);
    d.setHours(0, 0, 0, 0);
    return d;
  }, [timelineDates]);

  const timelineEnd = useMemo(() => {
    if (timelineDates.length === 0) return new Date();
    const d = new Date(timelineDates[timelineDates.length - 1]);
    d.setHours(23, 59, 59, 999);
    return d;
  }, [timelineDates]);

  // Today index if today is within the visible timeline
  const todayIndex = useMemo(() => {
    return timelineDates.findIndex((d) => isToday(d));
  }, [timelineDates, today]);

  // Auto-scroll to today column on scope change or mount
  const scrollToToday = () => {
    if (scrollContainerRef.current && todayIndex >= 0) {
      const cellWidth = 52; // width of each day column in px
      const targetScroll = Math.max(0, todayIndex * cellWidth - 180);
      scrollContainerRef.current.scrollTo({ left: targetScroll, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    // Smooth scroll to today after a short render delay
    const timer = setTimeout(() => {
      scrollToToday();
    }, 150);
    return () => clearTimeout(timer);
  }, [timelineStart, todayIndex]);

  // Total column count for CSS grid
  const totalDayColumns = timelineDates.length;
  const dayColWidthPx = 52; // Width of each day cell
  const totalTimelineWidthPx = totalDayColumns * dayColWidthPx;

  return (
    <div className="bg-[#0b1019] border border-slate-800 rounded-xl overflow-hidden shadow-2xl space-y-3 font-mono">
      {/* Top Gantt Toolbar: Scope Switcher & Quick Navigation */}
      <div className="bg-[#090d14] px-4 py-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          {onNavigateMonth && (
            <div className="flex items-center gap-1 bg-[#121a28] p-0.5 rounded border border-slate-800">
              <button
                onClick={() => {
                  const prev = new Date(currentDate);
                  prev.setMonth(prev.getMonth() - 1);
                  onNavigateMonth(prev);
                }}
                className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Previous Month"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  const next = new Date(currentDate);
                  next.setMonth(next.getMonth() + 1);
                  onNavigateMonth(next);
                }}
                className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Next Month"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <div className="flex items-center gap-1.5 text-slate-300 font-bold">
            <CalendarIcon className="w-4 h-4 text-orange-400" />
            <span className="text-white">
              {timelineDates[0]?.toLocaleString('default', { month: 'short', year: 'numeric' })}
              {ganttScope !== 'month' &&
                ` – ${timelineDates[timelineDates.length - 1]?.toLocaleString('default', {
                  month: 'short',
                  year: 'numeric',
                })}`}
            </span>
          </div>

          <span className="text-[10px] text-slate-500 bg-slate-800 px-2 py-0.5 rounded font-mono">
            {totalDayColumns} DAYS
          </span>

          {todayIndex >= 0 && (
            <button
              onClick={scrollToToday}
              className="flex items-center gap-1 text-[10px] text-orange-400 hover:text-orange-300 bg-orange-950/60 border border-orange-800/80 px-2 py-0.5 rounded font-bold transition-colors"
            >
              <Sparkles className="w-3 h-3 text-orange-400" /> Jump to Today ({today.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })})
            </button>
          )}
        </div>

        {/* Scope selector */}
        {onChangeScope && (
          <div className="flex items-center gap-1 bg-[#121a28] p-1 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-500 font-bold uppercase px-2 hidden md:inline">SCOPE:</span>
            <button
              onClick={() => onChangeScope('2weeks')}
              className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all ${
                ganttScope === '2weeks' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              2 Weeks
            </button>
            <button
              onClick={() => onChangeScope('month')}
              className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all ${
                ganttScope === 'month' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              1 Month
            </button>
            <button
              onClick={() => onChangeScope('quarter')}
              className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all ${
                ganttScope === 'quarter' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Quarter (3M)
            </button>
            <button
              onClick={() => onChangeScope('6months')}
              className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all ${
                ganttScope === '6months' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              6 Months
            </button>
          </div>
        )}
      </div>

      {/* Main Gantt Canvas with Sticky Environment Column & Horizontally Scrollable Timeline */}
      <div className="overflow-x-auto relative" ref={scrollContainerRef}>
        <div style={{ minWidth: `${200 + totalTimelineWidthPx}px` }}>
          {/* Header Row */}
          <div className="flex border-b border-slate-800 bg-[#070a10] text-[10px] uppercase font-bold sticky top-0 z-20">
            {/* Sticky Environment Header */}
            <div className="w-[200px] shrink-0 p-3 bg-[#070a10] border-r border-slate-800 text-slate-400 flex items-center justify-between sticky left-0 z-30 shadow-[4px_0_12px_rgba(0,0,0,0.5)]">
              <span>ENVIRONMENT</span>
              <Server className="w-3.5 h-3.5 text-slate-500" />
            </div>

            {/* Date Columns Header */}
            <div
              className="grid"
              style={{
                gridTemplateColumns: `repeat(${totalDayColumns}, ${dayColWidthPx}px)`,
                width: `${totalTimelineWidthPx}px`,
              }}
            >
              {timelineDates.map((date, idx) => {
                const dayNum = date.getDate();
                const dayName = date.toLocaleString('default', { weekday: 'narrow' });
                const monthShort = date.toLocaleString('default', { month: 'short' });
                const isWknd = date.getDay() === 0 || date.getDay() === 6;
                const isCurrent = isToday(date);
                const isFirstOfMonth = dayNum === 1 || idx === 0;

                return (
                  <div
                    key={date.toISOString()}
                    ref={isCurrent ? todayColumnRef : undefined}
                    className={`py-2 px-1 text-center border-r border-slate-800/80 flex flex-col items-center justify-center select-none transition-colors relative ${
                      isCurrent
                        ? 'bg-gradient-to-b from-orange-600/30 to-amber-600/10 text-orange-300 font-extrabold border-orange-500/80 shadow-[0_0_12px_rgba(249,115,22,0.3)]'
                        : isWknd
                        ? 'bg-[#0a0f18] text-slate-500'
                        : 'bg-[#070a10] text-slate-400'
                    }`}
                  >
                    {isCurrent && (
                      <span className="absolute -top-1 px-1 py-0.2 rounded bg-orange-600 text-white font-mono text-[8px] uppercase tracking-wider font-extrabold shadow-sm">
                        TODAY
                      </span>
                    )}

                    {isFirstOfMonth && (
                      <span className="text-[8px] font-bold text-orange-400 block uppercase">
                        {monthShort}
                      </span>
                    )}

                    <span className={`text-[9px] block ${isCurrent ? 'text-orange-300 font-bold' : 'text-slate-500'}`}>
                      {dayName}
                    </span>

                    <span
                      className={`text-xs block mt-0.5 ${
                        isCurrent
                          ? 'text-white font-extrabold underline decoration-orange-400 decoration-2'
                          : 'font-semibold text-slate-300'
                      }`}
                    >
                      {dayNum}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Environment Rows */}
          <div className="divide-y divide-slate-800/60">
            {environments.map((env) => {
              // Filter bookings allocated to this environment
              const envBookings = bookings.filter(
                (b) =>
                  (b.environmentId && env.id && b.environmentId === env.id) ||
                  (b.environmentName && env.name && b.environmentName.toLowerCase() === env.name.toLowerCase())
              );

              // Filter only bookings that overlap with this timeline window
              const visibleBookings = envBookings.filter((b) => {
                const bStart = parseSafeDate(b.startDate);
                const bEnd = parseSafeDate(b.endDate);
                if (!bStart || !bEnd) return false;
                return bEnd.getTime() >= timelineStart.getTime() && bStart.getTime() <= timelineEnd.getTime();
              });

              return (
                <div key={env.id} className="flex hover:bg-[#0f1724]/40 transition-colors group relative">
                  {/* Sticky Left Environment Card */}
                  <div className="w-[200px] shrink-0 p-3 bg-[#090d14] group-hover:bg-[#0d1420] border-r border-slate-800 flex flex-col justify-center sticky left-0 z-10 shadow-[4px_0_12px_rgba(0,0,0,0.5)] transition-colors">
                    <div className="flex items-center gap-2">
                      <span
                        className={`h-2 w-2 rounded-full shrink-0 ${
                          env.status === 'HEALTHY'
                            ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]'
                            : env.status === 'DOWN'
                            ? 'bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.8)]'
                            : env.status === 'MAINTENANCE'
                            ? 'bg-blue-400 shadow-[0_0_6px_rgba(96,165,250,0.8)]'
                            : 'bg-amber-400 shadow-[0_0_6px_rgba(251,191,36,0.8)]'
                        }`}
                      />
                      <span className="font-bold text-white text-xs truncate" title={env.name}>
                        {env.name}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1 pl-4">
                      <span className="uppercase">{env.tier}</span>
                      {envBookings.length > 0 && (
                        <span
                          className={`font-bold px-1.5 py-0.2 rounded border ${
                            visibleBookings.length > 0
                              ? 'text-orange-400 bg-orange-950/60 border-orange-900'
                              : 'text-slate-400 bg-slate-900 border-slate-800'
                          }`}
                          title={
                            visibleBookings.length > 0
                              ? `${visibleBookings.length} booking(s) in current timeline window`
                              : `${envBookings.length} booking(s) on other dates`
                          }
                        >
                          {visibleBookings.length > 0
                            ? `${visibleBookings.length} ${visibleBookings.length === 1 ? 'Booking' : 'Bookings'}`
                            : `${envBookings.length} other dates`}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Day Columns Grid with Placed Booking Blocks */}
                  <div
                    className="grid relative py-2"
                    style={{
                      gridTemplateColumns: `repeat(${totalDayColumns}, ${dayColWidthPx}px)`,
                      width: `${totalTimelineWidthPx}px`,
                      minHeight: visibleBookings.length > 1 ? `${visibleBookings.length * 36 + 12}px` : '54px',
                    }}
                  >
                    {/* Background Day Cells & Weekend/Today Highlighting */}
                    {timelineDates.map((date) => {
                      const isWknd = date.getDay() === 0 || date.getDay() === 6;
                      const isCurrent = isToday(date);

                      return (
                        <div
                          key={date.toISOString()}
                          className={`border-r border-slate-800/40 h-full ${
                            isCurrent
                              ? 'bg-orange-600/10 border-r-orange-500/30'
                              : isWknd
                              ? 'bg-[#0a0f18]/60'
                              : ''
                          }`}
                        />
                      );
                    })}

                    {/* Render Booking Bars positioned on exact start & end days */}
                    {visibleBookings.map((b, bIdx) => {
                      const bStart = parseSafeDate(b.startDate);
                      const bEnd = parseSafeDate(b.endDate);
                      if (!bStart || !bEnd) return null;

                      // Normalize to midnight dates for day column calculations
                      const startMidnight = new Date(bStart.getFullYear(), bStart.getMonth(), bStart.getDate(), 0, 0, 0, 0);
                      const endMidnight = new Date(bEnd.getFullYear(), bEnd.getMonth(), bEnd.getDate(), 0, 0, 0, 0);

                      // Find index directly in timelineDates for 100% exact alignment with columns
                      let dayOffsetStart = timelineDates.findIndex((d) => isSameDay(d, startMidnight));
                      let dayOffsetEnd = timelineDates.findIndex((d) => isSameDay(d, endMidnight));

                      // If start is before timelineStart, clamp to first column (0)
                      if (dayOffsetStart === -1) {
                        if (startMidnight.getTime() < timelineStart.getTime()) {
                          dayOffsetStart = 0;
                        } else {
                          return null;
                        }
                      }

                      // If end is after timelineEnd, clamp to last column
                      if (dayOffsetEnd === -1) {
                        if (endMidnight.getTime() > timelineEnd.getTime()) {
                          dayOffsetEnd = totalDayColumns - 1;
                        } else {
                          dayOffsetEnd = dayOffsetStart;
                        }
                      }

                      const colStart = Math.max(1, dayOffsetStart + 1);
                      const colSpan = Math.max(1, dayOffsetEnd - dayOffsetStart + 1);

                      // Determine left offset & width in pixels inside grid
                      const leftPx = (colStart - 1) * dayColWidthPx + 4;
                      const widthPx = Math.max(44, colSpan * dayColWidthPx - 8);
                      const isConf = conflictMap.has(b.id);

                      const formatGanttRange = (s: Date, e: Date) => {
                        const sM = s.toLocaleString('default', { month: 'short' });
                        const eM = e.toLocaleString('default', { month: 'short' });
                        if (sM === eM && s.getDate() === e.getDate()) {
                          return `${s.getDate()} ${sM}`;
                        }
                        if (sM === eM) {
                          return `${s.getDate()}–${e.getDate()} ${sM}`;
                        }
                        return `${s.getDate()} ${sM} – ${e.getDate()} ${eM}`;
                      };

                      return (
                        <div
                          key={b.id}
                          onClick={() => onSelectBooking(b)}
                          title={`${b.purpose}\nID: ${b.id}\nStatus: ${b.status}\nTeam: ${b.requestedBy} (${b.businessUnit})\nStart: ${formatDisplayDateTime(b.startDate)}\nEnd: ${formatDisplayDateTime(b.endDate)}`}
                          style={{
                            left: `${leftPx}px`,
                            width: `${widthPx}px`,
                            top: `${bIdx * 34 + 8}px`,
                          }}
                          className={`absolute h-7 rounded px-2 text-[11px] font-mono flex items-center justify-between truncate cursor-pointer transition-all shadow-lg border z-10 ${
                            isConf
                              ? 'bg-red-950/90 border-red-500 text-red-100 hover:bg-red-600 hover:text-white shadow-[0_0_12px_rgba(239,68,68,0.5)] animate-pulse'
                              : 'bg-gradient-to-r from-orange-950/90 via-[#2f1406] to-orange-900/90 border-orange-600/90 hover:border-orange-400 text-orange-200 hover:bg-orange-600 hover:text-white shadow-[0_0_10px_rgba(249,115,22,0.2)]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 truncate">
                            {isConf ? (
                              <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                            ) : (
                              <Clock className="w-3 h-3 text-orange-400 shrink-0" />
                            )}
                            <span className="font-bold truncate">{b.purpose}</span>
                            <span className="text-[9px] text-slate-400 font-sans truncate hidden sm:inline">
                              ({b.application})
                            </span>
                          </div>

                          <div className="flex items-center gap-1 text-[9px] shrink-0 font-mono font-bold text-orange-300 ml-1">
                            <span className={`text-[8px] px-1 py-0.2 rounded border uppercase font-mono ${
                              (b.reservationMode || 'SHARED') === 'DISRUPTIVE'
                                ? 'bg-amber-950/80 text-amber-300 border-amber-800'
                                : 'bg-cyan-950/80 text-cyan-300 border-cyan-800'
                            }`}>
                              {(b.reservationMode || 'SHARED') === 'DISRUPTIVE' ? '⚡ DISRUPTIVE' : '👥 SHARED'}
                            </span>
                            <span>{formatGanttRange(bStart, bEnd)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer Info & Legend */}
      <div className="bg-[#090d14] px-4 py-2.5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-400">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded bg-orange-600 border border-orange-400" />
            <span>Confirmed Allocation</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded bg-red-600 border border-red-400 animate-pulse" />
            <span className="text-red-400 font-semibold">Overlapping Conflict</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded bg-rose-700 border border-rose-500" />
            <span className="text-rose-300">Rejected</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded bg-purple-700 border border-purple-500" />
            <span className="text-purple-300">Auto Rejected</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded bg-slate-800 border border-slate-700" />
            <span className="text-slate-500">Canceled</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded bg-orange-600/30 border border-orange-500" />
            <span className="text-orange-400">Current Day Highlight</span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-slate-500 text-[10px]">
          <Info className="w-3.5 h-3.5" />
          <span>Scroll horizontally to view past and future dates. Click any booking to inspect reservation dossier.</span>
        </div>
      </div>
    </div>
  );
};
