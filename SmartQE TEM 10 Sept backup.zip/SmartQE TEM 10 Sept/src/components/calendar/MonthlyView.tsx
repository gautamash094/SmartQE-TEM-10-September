import React from 'react';
import { Booking } from '../../types';
import {
  Clock,
  AlertTriangle,
} from 'lucide-react';

interface MonthlyViewProps {
  currentDate: Date;
  bookings: Booking[];
  conflictMap: Map<string, string[]>;
  onSelectBooking: (booking: Booking) => void;
}

const safeParseDate = (dateVal: string | Date | undefined | null): Date | null => {
  if (!dateVal) return null;
  if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
  const isoStr = String(dateVal).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d;
  const dRaw = new Date(dateVal);
  return isNaN(dRaw.getTime()) ? null : dRaw;
};

export const MonthlyView: React.FC<MonthlyViewProps> = ({
  currentDate,
  bookings,
  conflictMap,
  onSelectBooking,
}) => {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const startDayOfWeek = (firstDayOfMonth.getDay() + 6) % 7;
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const calendarCells: { date: Date; isCurrentMonth: boolean; key: string }[] = [];

  for (let i = startDayOfWeek - 1; i >= 0; i--) {
    const d = new Date(year, month - 1, daysInPrevMonth - i);
    calendarCells.push({
      date: d,
      isCurrentMonth: false,
      key: `prev-${i}`,
    });
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const curr = new Date(year, month, d);
    calendarCells.push({
      date: curr,
      isCurrentMonth: true,
      key: `curr-${d}`,
    });
  }

  const totalCellsNeeded = calendarCells.length > 35 ? 42 : 35;
  const remainingCells = totalCellsNeeded - calendarCells.length;
  for (let d = 1; d <= remainingCells; d++) {
    const next = new Date(year, month + 1, d);
    calendarCells.push({
      date: next,
      isCurrentMonth: false,
      key: `next-${d}`,
    });
  }

  const isSameDay = (d1: Date, d2: Date) => {
    return (
      d1.getFullYear() === d2.getFullYear() &&
      d1.getMonth() === d2.getMonth() &&
      d1.getDate() === d2.getDate()
    );
  };

  const isToday = (d: Date) => isSameDay(d, new Date());

  const dayHeaders = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const weeks: { date: Date; isCurrentMonth: boolean; key: string }[][] = [];
  for (let i = 0; i < calendarCells.length; i += 7) {
    weeks.push(calendarCells.slice(i, i + 7));
  }

  const formatShortRange = (sStr: string, eStr: string) => {
    try {
      const s = safeParseDate(sStr);
      const e = safeParseDate(eStr);
      if (!s || !e) return '';
      const sM = s.toLocaleString('default', { month: 'short' });
      const eM = e.toLocaleString('default', { month: 'short' });
      if (sM === eM && s.getDate() === e.getDate()) {
        return `${sM} ${s.getDate()}`;
      }
      if (sM === eM) return `${sM} ${s.getDate()}–${e.getDate()}`;
      return `${sM} ${s.getDate()} – ${eM} ${e.getDate()}`;
    } catch {
      return '';
    }
  };

  return (
    <div className="bg-[#0b1019] border border-slate-800 rounded-xl overflow-hidden shadow-2xl font-mono text-xs w-full">
      {/* 7-Day Header Grid */}
      <div className="grid grid-cols-7 border-b border-slate-800 bg-[#090d14] text-center font-bold text-slate-400 py-3 text-[11px] uppercase tracking-wider divide-x divide-slate-800/80">
        {dayHeaders.map((dayName, idx) => (
          <div key={idx} className="px-2">
            <span className="hidden sm:inline">{dayName}</span>
            <span className="sm:hidden">{dayName.slice(0, 3)}</span>
          </div>
        ))}
      </div>

      {/* Monthly Grid */}
      <div className="bg-[#080d14] p-3 space-y-3">
        {weeks.map((weekCells, wIdx) => {
          const weekStartMs = new Date(weekCells[0].date).setHours(0, 0, 0, 0);
          const weekEndMs = new Date(weekCells[6].date).setHours(23, 59, 59, 999);

          const weekBookings = (bookings || []).filter((b) => {
            const sDate = safeParseDate(b.startDate);
            const eDate = safeParseDate(b.endDate);
            if (!sDate || !eDate) return false;
            return sDate.getTime() <= weekEndMs && eDate.getTime() >= weekStartMs;
          });

          return (
            <div key={wIdx} className="border border-slate-800/80 rounded-xl bg-[#070a10] overflow-hidden shadow-sm">
              {/* Date Header Row across 7 columns */}
              <div className="grid grid-cols-7 divide-x divide-slate-800/50 bg-[#090d14]/80 py-2 border-b border-slate-800/60">
                {weekCells.map((cell) => {
                  const today = isToday(cell.date);

                  return (
                    <div
                      key={cell.key}
                      className={`px-2 text-center flex flex-col items-center justify-center relative ${
                        !cell.isCurrentMonth
                          ? 'opacity-30 bg-slate-900/30'
                          : today
                          ? 'bg-orange-950/30'
                          : ''
                      }`}
                    >
                      {today && (
                        <span className="text-[8px] uppercase tracking-wider font-black text-orange-400 bg-orange-950/80 px-1 py-0.2 rounded border border-orange-800/80">
                          TODAY
                        </span>
                      )}
                      <span
                        className={`text-sm font-extrabold mt-0.5 ${
                          today
                            ? 'text-orange-400 font-black'
                            : cell.isCurrentMonth
                            ? 'text-slate-200'
                            : 'text-slate-600'
                        }`}
                      >
                        {cell.date.getDate()}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Grid Body */}
              <div className="relative p-2 min-h-[110px] bg-[#070b12]">
                <div className="absolute inset-0 grid grid-cols-7 pointer-events-none divide-x divide-slate-800/40">
                  {weekCells.map((_, i) => (
                    <div key={i} className="h-full" />
                  ))}
                </div>

                <div className="relative z-10 space-y-1.5">
                  {weekBookings.length === 0 ? (
                    <div className="text-slate-700 text-[10px] italic text-center py-6">
                      No scheduled allocations for this week
                    </div>
                  ) : (
                    weekBookings.map((b) => {
                      const bStart = safeParseDate(b.startDate) || new Date();
                      const bEnd = safeParseDate(b.endDate) || bStart;

                      let startIndex = weekCells.findIndex((c) => isSameDay(c.date, bStart));
                      if (startIndex === -1) {
                        startIndex = bStart.getTime() < weekStartMs ? 0 : 6;
                      }

                      let endIndex = weekCells.findIndex((c) => isSameDay(c.date, bEnd));
                      if (endIndex === -1) {
                        endIndex = bEnd.getTime() > weekEndMs ? 6 : startIndex;
                      }

                      const colStart = Math.max(1, Math.min(7, startIndex + 1));
                      const rawSpan = Math.max(1, endIndex - startIndex + 1);
                      const maxAllowedSpan = 7 - colStart + 1;
                      const colSpan = Math.max(1, Math.min(maxAllowedSpan, rawSpan));
                      const isConflict = conflictMap.has(b.id);

                      return (
                        <div key={b.id} className="grid grid-cols-7">
                          <div
                            style={{
                              gridColumn: `${colStart} / span ${colSpan}`,
                            }}
                            onClick={() => onSelectBooking(b)}
                            className={`h-9 px-3 rounded-lg border transition-all cursor-pointer flex items-center justify-between gap-2 group hover:scale-[1.005] hover:brightness-110 ${
                              isConflict
                                ? 'bg-red-950/90 border-red-500 text-red-100 shadow-[0_0_12px_rgba(239,68,68,0.5)] animate-pulse'
                                : 'bg-gradient-to-r from-orange-950/90 via-[#2f1406] to-orange-900/90 border-orange-600/90 hover:border-orange-400 text-orange-200 shadow-[0_0_10px_rgba(249,115,22,0.25)] hover:shadow-[0_0_14px_rgba(249,115,22,0.4)]'
                            }`}
                          >
                            <div className="flex items-center gap-2 truncate">
                              {isConflict ? (
                                <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                              ) : (
                                <Clock className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              )}
                              <span className="font-extrabold text-orange-100 group-hover:text-white text-xs truncate">
                                {b.purpose}
                              </span>
                              <span className="text-[10px] text-orange-300/70 font-sans truncate">
                                ({b.application || b.environmentName})
                              </span>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-mono font-bold">
                              <span className={`text-[8px] px-1.5 py-0.5 rounded border uppercase ${
                                (b.reservationMode || 'SHARED') === 'DISRUPTIVE'
                                  ? 'bg-amber-950/90 text-amber-300 border-amber-800'
                                  : 'bg-cyan-950/90 text-cyan-300 border-cyan-800'
                              }`}>
                                {(b.reservationMode || 'SHARED') === 'DISRUPTIVE' ? '⚡ DISRUPTIVE' : '👥 SHARED'}
                              </span>
                              <span className="text-orange-300 bg-orange-950/80 px-2 py-0.5 rounded border border-orange-800/80">
                                {formatShortRange(b.startDate, b.endDate)}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
