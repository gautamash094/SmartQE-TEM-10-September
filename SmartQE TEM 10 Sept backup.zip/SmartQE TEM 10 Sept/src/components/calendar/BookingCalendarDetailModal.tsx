import React, { useState, useMemo } from 'react';
import { Booking, ReservationMode, BookingAuditEntry } from '../../types';
import { useTEM } from '../../context/TEMContext';
import { DateTimePicker } from '../common/DateTimePicker';
import { EnvironmentReadinessBadge } from '../monitoring/EnvironmentReadinessBadge';
import { monitoringService } from '../../services/monitoringService';
import { bookingService, AvailableSlotOption } from '../../services/bookingService';
import { aiIntelligenceService } from '../../services/aiIntelligenceService';
import {
  Calendar,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Ban,
  Building2,
  AppWindow,
  Server,
  User,
  Users,
  X,
  Edit3,
  Trash2,
  AlertCircle,
  XCircle,
  Zap,
  History,
  Sparkles,
  Search,
  BrainCircuit,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

interface BookingCalendarDetailModalProps {
  booking: Booking | null;
  isOpen: boolean;
  onClose: () => void;
  conflictMap: Map<string, string[]>;
}

const formatDisplayDateTime = (dtStr: string) => {
  if (!dtStr) return '-';
  try {
    const d = new Date(dtStr);
    if (isNaN(d.getTime())) return dtStr;
    const pad = (n: number) => n.toString().padStart(2, '0');
    const year = d.getFullYear();
    const month = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const hours = pad(d.getHours());
    const minutes = pad(d.getMinutes());
    const seconds = pad(d.getSeconds());
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  } catch (e) {
    return dtStr;
  }
};

const toInputDateTime = (dtStr: string) => {
  if (!dtStr) return '';
  try {
    const d = new Date(dtStr);
    if (isNaN(d.getTime())) return '';
    const pad = (n: number) => n.toString().padStart(2, '0');
    const year = d.getFullYear();
    const month = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const hours = pad(d.getHours());
    const minutes = pad(d.getMinutes());
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  } catch (e) {
    return '';
  }
};

export const BookingCalendarDetailModal: React.FC<BookingCalendarDetailModalProps> = ({
  booking,
  isOpen,
  onClose,
  conflictMap,
}) => {
  const { bookings, environmentProfiles, incidents, releases, cancelBooking, rejectBooking, updateBooking, showToast } = useTEM();

  const [isConfirmingCancel, setIsConfirmingCancel] = useState(false);
  const [isConfirmingReject, setIsConfirmingReject] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  // Check Availability Separate State
  const [isCheckingAvailability, setIsCheckingAvailability] = useState(false);
  const [availableSlots, setAvailableSlots] = useState<AvailableSlotOption[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<AvailableSlotOption | null>(null);

  // Direct Edit Reservation State
  const [isEditing, setIsEditing] = useState(false);
  const [editEnvId, setEditEnvId] = useState('');
  const [editStart, setEditStart] = useState('');
  const [editEnd, setEditEnd] = useState('');
  const [editMode, setEditMode] = useState<ReservationMode>('SHARED');

  // Resolve Conflict Separate State
  const [isResolving, setIsResolving] = useState(false);
  const [resolutionOption, setResolutionOption] = useState<'DATE_TIME' | 'MODE_CHANGE'>('DATE_TIME');
  const [resolveStart, setResolveStart] = useState('');
  const [resolveEnd, setResolveEnd] = useState('');
  const [resolveMode, setResolveMode] = useState<ReservationMode>('SHARED');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const isEditDateOrderInvalid = useMemo(() => {
    if (!editStart || !editEnd) return false;
    const s = new Date(editStart).getTime();
    const e = new Date(editEnd).getTime();
    return !isNaN(s) && !isNaN(e) && s >= e;
  }, [editStart, editEnd]);

  // Live Conflict Detection for Edit
  const editConflictingBookings = useMemo(() => {
    if (!isEditing || !editEnvId || !editStart || !editEnd || isEditDateOrderInvalid || !booking) return [];
    const s = new Date(editStart).getTime();
    const e = new Date(editEnd).getTime();
    if (isNaN(s) || isNaN(e) || e <= s) return [];

    const selectedEnv = environmentProfiles.find(p => p.id === editEnvId);

    return bookings.filter(b => {
      if (b.id === booking.id) return false;
      if (b.status === 'CANCELLED' || b.status === 'REJECTED' || b.status === 'AUTO_REJECTED') return false;
      const sameEnv =
        (b.environmentId && b.environmentId === editEnvId) ||
        (selectedEnv && b.environmentName && b.environmentName.toLowerCase() === selectedEnv.name.toLowerCase());
      if (!sameEnv || !b.startDate || !b.endDate) return false;
      const bStart = new Date(b.startDate).getTime();
      const bEnd = new Date(b.endDate).getTime();
      const isOverlap = s < bEnd && e > bStart;
      if (!isOverlap) return false;
      const otherMode = b.reservationMode || 'SHARED';
      return editMode === 'DISRUPTIVE' || otherMode === 'DISRUPTIVE';
    });
  }, [isEditing, editEnvId, editStart, editEnd, editMode, isEditDateOrderInvalid, bookings, booking, environmentProfiles]);

  // AI Booking Intelligence for Edit
  const editAiAssistResult = useMemo(() => {
    if (!isEditing || !editEnvId || !editStart || !editEnd || isEditDateOrderInvalid || !booking) return null;
    return aiIntelligenceService.getBookingAIAssistance(
      editEnvId,
      editStart,
      editEnd,
      editMode,
      environmentProfiles,
      bookings,
      incidents || [],
      releases || [],
      booking.id
    );
  }, [isEditing, editEnvId, editStart, editEnd, editMode, environmentProfiles, bookings, incidents, releases, isEditDateOrderInvalid, booking]);

  if (!isOpen || !booking) return null;

  const isCancelled = booking.status === 'CANCELLED';
  const isRejected = booking.status === 'REJECTED';
  const isAutoRejected = booking.status === 'AUTO_REJECTED';
  const isInactive = isCancelled || isRejected || isAutoRejected;
  const isConflict = !isInactive && (conflictMap.has(booking.id) || booking.status === 'CONFLICT');

  // Find all other active bookings on the same environment that overlap
  const conflictingBookings = bookings.filter((other) => {
    if (
      other.id === booking.id ||
      other.status === 'CANCELLED' ||
      other.status === 'REJECTED' ||
      other.status === 'AUTO_REJECTED'
    ) {
      return false;
    }
    const sameEnv =
      (other.environmentId && booking.environmentId && other.environmentId === booking.environmentId) ||
      (other.environmentName && booking.environmentName && other.environmentName.toLowerCase() === booking.environmentName.toLowerCase());
    if (!sameEnv || !other.startDate || !other.endDate || !booking.startDate || !booking.endDate) return false;

    const bStart = new Date(booking.startDate).getTime();
    const bEnd = new Date(booking.endDate).getTime();
    const oStart = new Date(other.startDate).getTime();
    const oEnd = new Date(other.endDate).getTime();
    const isOverlap = bStart < oEnd && bEnd > oStart;
    if (!isOverlap) return false;

    const bMode = booking.reservationMode || 'SHARED';
    const oMode = other.reservationMode || 'SHARED';
    return bMode === 'DISRUPTIVE' || oMode === 'DISRUPTIVE';
  });

  // Action 1: Check Availability (DOES NOT AUTO-RESOLVE OR UPDATE BOOKING)
  const handleCheckAvailability = () => {
    const slots = bookingService.findAvailableAlternativeSlots(booking, bookings);
    setAvailableSlots(slots);
    setIsCheckingAvailability(true);
    setErrorMsg(null);
    showToast('Available slots discovered. Select a slot and click "Resolve Conflict" to apply.', 'info');
  };

  // Select candidate slot from Check Availability list
  const handleSelectSlot = (slot: AvailableSlotOption) => {
    setSelectedSlot(slot);
    setResolveStart(toInputDateTime(slot.startDate));
    setResolveEnd(toInputDateTime(slot.endDate));
    showToast(`Selected slot (${slot.displayDate} ${slot.displayStartTime}). Click 'Resolve Conflict' to apply.`, 'info');
  };

  // Action 2: Open Direct Edit Reservation Flow (DOES NOT OPEN CONFLICT RESOLUTION)
  const handleOpenEditReservation = () => {
    setEditEnvId(booking.environmentId || '');
    setEditStart(toInputDateTime(booking.startDate));
    setEditEnd(toInputDateTime(booking.endDate));
    setEditMode(booking.reservationMode || 'SHARED');
    setErrorMsg(null);
    setIsEditing(true);
    setIsResolving(false);
    setIsCheckingAvailability(false);
  };

  // Direct Edit Reservation Form Submit & Validation Handler
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!editStart || !editEnd) {
      setErrorMsg('Both Start and End Date & Time are required.');
      return;
    }

    const s = new Date(editStart).getTime();
    const end = new Date(editEnd).getTime();

    if (isNaN(s) || isNaN(end) || s >= end) {
      setErrorMsg('Start date and time cannot be greater than end date and time.');
      return;
    }

    const targetEnvProfile = environmentProfiles.find(p => p.id === editEnvId);
    const targetEnvName = targetEnvProfile ? targetEnvProfile.name : (booking.environmentName || 'Target Environment');

    // Validate slot availability against all existing active bookings
    const validation = bookingService.validateSlotAvailability(
      booking.id,
      editEnvId || booking.environmentId,
      targetEnvName,
      editStart,
      editEnd,
      editMode,
      bookings
    );

    if (!validation.isAvailable) {
      setErrorMsg(validation.conflictReason || 'The selected date/time window or reservation mode conflicts with another reservation.');
      return;
    }

    // Save changes against the SAME booking record without creating duplicates
    const oldMode = booking.reservationMode || 'SHARED';
    const auditLogs: BookingAuditEntry[] = [...(booking.auditHistory || [])];

    if (editStart !== booking.startDate || editEnd !== booking.endDate) {
      auditLogs.push({
        id: `audit-${Date.now()}-1`,
        field: 'Time Window',
        oldValue: `${formatDisplayDateTime(booking.startDate)} → ${formatDisplayDateTime(booking.endDate)}`,
        newValue: `${formatDisplayDateTime(editStart)} → ${formatDisplayDateTime(editEnd)}`,
        changedBy: booking.requestedBy || 'Ops Engineer',
        changedAt: new Date().toISOString(),
      });
    }

    if (editMode !== oldMode) {
      auditLogs.push({
        id: `audit-${Date.now()}-2`,
        field: 'Reservation Mode',
        oldValue: oldMode,
        newValue: editMode,
        changedBy: booking.requestedBy || 'Ops Engineer',
        changedAt: new Date().toISOString(),
      });
    }

    if (editEnvId && editEnvId !== booking.environmentId) {
      auditLogs.push({
        id: `audit-${Date.now()}-3`,
        field: 'Target Environment',
        oldValue: booking.environmentName || booking.environmentId,
        newValue: targetEnvName,
        changedBy: booking.requestedBy || 'Ops Engineer',
        changedAt: new Date().toISOString(),
      });
    }

    const rawAudit = booking.auditHistory;
    const auditList: BookingAuditEntry[] = Array.isArray(rawAudit)
      ? rawAudit
      : typeof rawAudit === 'string'
      ? JSON.parse(rawAudit || '[]')
      : [];
    const isAlreadyFullyApproved = auditList.some(
      (a: any) =>
        a.status === 'APPROVED' &&
        a.newValue &&
        a.newValue.toLowerCase().includes('all workflow approvers have approved')
    );
    const targetStatus = isAlreadyFullyApproved ? 'APPROVED' : (booking.status === 'PENDING' ? 'PENDING' : 'CONFIRMED');

    updateBooking(booking.id, {
      environmentId: editEnvId || booking.environmentId,
      environmentName: targetEnvName,
      startDate: editStart,
      endDate: editEnd,
      reservationMode: editMode,
      status: targetStatus,
      auditHistory: auditLogs,
    });

    showToast(`Reservation #${booking.id} updated successfully.`, 'success');
    setIsEditing(false);
  };

  // Action 3: Open Resolve Conflict Dialog
  const handleOpenResolveConflict = () => {
    if (selectedSlot) {
      setResolveStart(toInputDateTime(selectedSlot.startDate));
      setResolveEnd(toInputDateTime(selectedSlot.endDate));
    } else {
      setResolveStart(toInputDateTime(booking.startDate));
      setResolveEnd(toInputDateTime(booking.endDate));
    }
    setResolveMode(booking.reservationMode || 'SHARED');
    setResolutionOption(selectedSlot ? 'DATE_TIME' : 'DATE_TIME');
    setErrorMsg(null);
    setIsResolving(true);
  };

  // Final Validation & Execution of Conflict Resolution
  const handleSaveResolution = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Option B: Change Reservation Mode (Disruptive -> Shared)
    if (resolutionOption === 'MODE_CHANGE') {
      const modeCheck = bookingService.validateSlotAvailability(
        booking.id,
        booking.environmentId,
        booking.environmentName,
        booking.startDate,
        booking.endDate,
        'SHARED',
        bookings
      );

      if (!modeCheck.isAvailable) {
        setErrorMsg(modeCheck.conflictReason || 'Cannot resolve conflict by mode change alone: Overlapping bookings also require exclusive control.');
        return;
      }

      const auditLogs: BookingAuditEntry[] = [...(booking.auditHistory || [])];
      auditLogs.push({
        id: `audit-${Date.now()}`,
        field: 'Reservation Mode',
        oldValue: booking.reservationMode || 'SHARED',
        newValue: 'SHARED',
        changedBy: booking.requestedBy || 'Ops Engineer',
        changedAt: new Date().toISOString(),
      });

      const rawAudit = booking.auditHistory;
      const auditList: BookingAuditEntry[] = Array.isArray(rawAudit)
        ? rawAudit
        : typeof rawAudit === 'string'
        ? JSON.parse(rawAudit || '[]')
        : [];
      const isAlreadyFullyApproved = auditList.some(
        (a: any) =>
          a.status === 'APPROVED' &&
          a.newValue &&
          a.newValue.toLowerCase().includes('all workflow approvers have approved')
      );
      const targetStatus = isAlreadyFullyApproved ? 'APPROVED' : (booking.status === 'PENDING' ? 'PENDING' : 'CONFIRMED');

      updateBooking(booking.id, {
        reservationMode: 'SHARED',
        status: targetStatus,
        auditHistory: auditLogs,
      });

      showToast('Conflict resolved by changing the reservation mode to Shared.', 'success');
      setIsResolving(false);
      setIsCheckingAvailability(false);
      return;
    }

    // Option A: Change Date & Time
    if (!resolveStart || !resolveEnd) {
      setErrorMsg('Both Start and End Date & Time are required.');
      return;
    }

    const s = new Date(resolveStart).getTime();
    const end = new Date(resolveEnd).getTime();

    if (s >= end) {
      setErrorMsg('Start date time is greater than the end date time.');
      return;
    }

    // Final Race Condition Validation right before saving
    const finalValidation = bookingService.validateSlotAvailability(
      booking.id,
      booking.environmentId,
      booking.environmentName,
      resolveStart,
      resolveEnd,
      resolveMode,
      bookings
    );

    if (!finalValidation.isAvailable) {
      setErrorMsg('The selected slot is no longer available. Please check availability again.');
      return;
    }

    const oldMode = booking.reservationMode || 'SHARED';
    const auditLogs: BookingAuditEntry[] = [...(booking.auditHistory || [])];

    if (resolveMode !== oldMode) {
      auditLogs.push({
        id: `audit-${Date.now()}`,
        field: 'Reservation Mode',
        oldValue: oldMode,
        newValue: resolveMode,
        changedBy: booking.requestedBy || 'Ops Engineer',
        changedAt: new Date().toISOString(),
      });
    }

    const rawAudit = booking.auditHistory;
    const auditList: BookingAuditEntry[] = Array.isArray(rawAudit)
      ? rawAudit
      : typeof rawAudit === 'string'
      ? JSON.parse(rawAudit || '[]')
      : [];
    const isAlreadyFullyApproved = auditList.some(
      (a: any) =>
        a.status === 'APPROVED' &&
        a.newValue &&
        a.newValue.toLowerCase().includes('all workflow approvers have approved')
    );
    const targetStatus = isAlreadyFullyApproved ? 'APPROVED' : (booking.status === 'PENDING' ? 'PENDING' : 'CONFIRMED');

    updateBooking(booking.id, {
      startDate: resolveStart,
      endDate: resolveEnd,
      reservationMode: resolveMode,
      auditHistory: auditLogs,
      status: targetStatus,
    });

    showToast('Conflict resolved. The reservation has been updated to the selected date and time.', 'success');
    setIsResolving(false);
    setIsCheckingAvailability(false);
  };

  const handleConfirmCancellation = () => {
    cancelBooking(booking.id);
    showToast(`Reservation #${booking.id} (${booking.purpose}) was canceled.`);
    setIsConfirmingCancel(false);
    onClose();
  };

  const handleConfirmRejection = () => {
    const reason = rejectReason.trim() || 'Manually rejected by user';
    rejectBooking(booking.id, reason);
    showToast(`Reservation #${booking.id} (${booking.purpose}) was rejected.`);
    setIsConfirmingReject(false);
    setRejectReason('');
    onClose();
  };

  const currentMode = booking.reservationMode || 'SHARED';

  return (
    <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
      <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-xl max-w-2xl w-full font-mono text-xs relative shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* STICKY HEADER */}
        <div className="shrink-0 p-6 pb-4 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] uppercase font-bold text-orange-400">
                RESERVATION DOSSIER
              </span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border flex items-center gap-1 ${
                  isCancelled
                    ? 'bg-slate-900 text-slate-400 border-slate-700'
                    : isRejected
                    ? 'bg-rose-950 text-rose-300 border-rose-800'
                    : isAutoRejected
                    ? 'bg-purple-950 text-purple-300 border-purple-800'
                    : booking.status === 'PENDING'
                    ? 'bg-amber-950 text-amber-300 border-amber-800'
                    : isConflict
                    ? 'bg-red-950 text-red-400 border-red-800 animate-pulse'
                    : 'bg-emerald-950 text-emerald-400 border-emerald-800'
                }`}
              >
                {isCancelled ? (
                  <>
                    <Ban className="w-3 h-3" /> Canceled
                  </>
                ) : isRejected ? (
                  <>
                    <XCircle className="w-3 h-3 text-rose-400" /> Rejected
                  </>
                ) : isAutoRejected ? (
                  <>
                    <Clock className="w-3 h-3 text-purple-400" /> Auto Rejected
                  </>
                ) : booking.status === 'PENDING' ? (
                  <>
                    <Clock className="w-3 h-3 text-amber-400" /> Pending Approval (Step {booking.currentWorkflowOrder || 1})
                  </>
                ) : isConflict ? (
                  <>
                    <AlertTriangle className="w-3 h-3" /> Collision / Conflict
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-3 h-3" /> {booking.status === 'APPROVED' ? 'Approved' : (booking.status || 'Confirmed')}
                  </>
                )}
              </span>

              {/* PRIORITY BADGE */}
              <span
                className={`px-2.5 py-0.5 rounded text-[10px] font-bold border ${
                  booking.priority === 'CRITICAL'
                    ? 'bg-red-950/80 text-red-400 border-red-800'
                    : booking.priority === 'HIGH'
                    ? 'bg-orange-950/80 text-orange-400 border-orange-800'
                    : booking.priority === 'LOW'
                    ? 'bg-slate-900 text-slate-400 border-slate-700'
                    : 'bg-blue-950/80 text-blue-300 border-blue-800'
                }`}
              >
                PRIORITY: {booking.priority || 'MEDIUM'}
              </span>

              {/* AUTO APPROVAL BADGE */}
              {booking.autoApprovalEnabled && (
                <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                  ✓ AUTO APPROVAL: {booking.autoApprovalRule || 'ENABLED'}
                </span>
              )}

              {/* RESERVATION MODE BADGE */}
              <span
                className={`px-2.5 py-0.5 rounded text-[10px] font-bold border flex items-center gap-1 font-mono ${
                  currentMode === 'DISRUPTIVE'
                    ? 'bg-amber-950/80 text-amber-300 border-amber-800 shadow-[0_0_8px_rgba(245,158,11,0.2)]'
                    : 'bg-cyan-950/80 text-cyan-300 border-cyan-800'
                }`}
              >
                {currentMode === 'DISRUPTIVE' ? (
                  <>
                    <Zap className="w-3 h-3 text-amber-400" /> DISRUPTIVE
                  </>
                ) : (
                  <>
                    <Users className="w-3 h-3 text-cyan-400" /> SHARED
                  </>
                )}
              </span>

              {(() => {
                const bookedEnvProfile = (environmentProfiles || []).find(
                  (e) => (booking.environmentId && e.id === booking.environmentId) || e.name.toLowerCase() === booking.environmentName?.toLowerCase()
                );
                const readinessResult = bookedEnvProfile ? monitoringService.evaluateTestReadiness(bookedEnvProfile, incidents, bookings) : null;
                return readinessResult ? (
                  <EnvironmentReadinessBadge status={readinessResult.status} result={readinessResult} size="sm" />
                ) : null;
              })()}
            </div>

            <h2 className="text-xl font-bold text-white font-sans">{booking.purpose}</h2>
          </div>
        </div>

        {/* SCROLLABLE MODAL BODY */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">

        {/* Conflict Warning Banner if active */}
        {isConflict && conflictingBookings.length > 0 && (
          <div className="bg-red-950/60 border border-red-800/80 p-4 rounded-lg space-y-3 text-red-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-red-400 text-sm">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>Disruptive Reservation Conflict Detected</span>
              </div>
              <span className="text-[10px] font-mono text-red-300 bg-red-950 px-2 py-0.5 rounded border border-red-800 font-bold">
                ACTION REQUIRED
              </span>
            </div>

            <p className="text-[11px] leading-relaxed font-sans text-slate-300">
              This reservation collides on <strong className="text-white">{booking.environmentName}</strong> with {conflictingBookings.length} active booking(s):
            </p>

            <div className="space-y-1.5 bg-black/40 p-2.5 rounded border border-red-900/60 text-[11px]">
              {conflictingBookings.map((c) => (
                <div key={c.id} className="flex items-center justify-between">
                  <span className="text-white font-semibold">
                    {c.purpose} ({c.team})
                  </span>
                  <span className="text-amber-400 text-[10px] font-mono">[MODE: {c.reservationMode || 'SHARED'}]</span>
                  <span className="text-red-300 font-mono">
                    {formatDisplayDateTime(c.startDate)} → {formatDisplayDateTime(c.endDate)}
                  </span>
                </div>
              ))}
            </div>

            {/* TWO SEPARATE ACTION BUTTONS */}
            <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-red-900/60">
              <button
                type="button"
                onClick={handleCheckAvailability}
                className="flex-1 px-4 py-2 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-700 font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Search className="w-3.5 h-3.5 text-cyan-400" /> Check Availability
              </button>
              <button
                type="button"
                onClick={handleOpenResolveConflict}
                className="flex-1 px-4 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(249,115,22,0.4)]"
              >
                <Sparkles className="w-3.5 h-3.5 text-white" /> Resolve Conflict
              </button>
            </div>
          </div>
        )}

        {/* CHECK AVAILABILITY RESULTS DISPLAY (DOES NOT AUTO-RESOLVE OR UPDATE BOOKING) */}
        {isCheckingAvailability && availableSlots.length > 0 && (
          <div className="bg-[#0b1424] border border-cyan-500/50 p-4 rounded-lg space-y-3 font-mono text-xs shadow-lg animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
              <span className="text-[11px] font-bold text-cyan-400 uppercase flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5 text-cyan-400" /> Discovered Available Slots ({availableSlots.length})
              </span>
              <button
                type="button"
                onClick={() => setIsCheckingAvailability(false)}
                className="text-[10px] text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>

            <p className="text-[11px] font-sans text-slate-300">
              Select an available slot below. <strong className="text-white">No changes will be saved until you click 'Resolve Conflict'.</strong>
            </p>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {availableSlots.map((slot) => {
                const isSelected = selectedSlot?.id === slot.id;
                const isAvailable = slot.status === 'AVAILABLE';

                return (
                  <div
                    key={slot.id}
                    className={`p-3 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all ${
                      isSelected
                        ? 'bg-cyan-950/90 border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                        : isAvailable
                        ? 'bg-slate-900/80 border-slate-200 dark:border-slate-800 hover:border-slate-700'
                        : 'bg-slate-950/50 border-slate-900 opacity-60'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <strong className="text-white text-xs">{slot.displayDate}</strong>
                        <span className="text-orange-400 text-[11px] font-bold">
                          {slot.displayStartTime} → {slot.displayEndTime}
                        </span>
                        <span className="text-[10px] text-slate-400">({slot.durationHours} hrs)</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px]">
                        <span
                          className={`px-1.5 py-0.5 rounded font-bold ${
                            isAvailable ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800'
                          }`}
                        >
                          {isAvailable ? 'AVAILABLE' : 'ALREADY BOOKED'}
                        </span>
                        <span className="text-slate-400">{slot.reservationModeCompatibility}</span>
                      </div>
                    </div>

                    {isAvailable && (
                      <button
                        type="button"
                        onClick={() => handleSelectSlot(slot)}
                        className={`px-3 py-1.5 rounded text-xs font-bold transition-all shrink-0 ${
                          isSelected
                            ? 'bg-cyan-500 text-black font-extrabold shadow-sm'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                        }`}
                      >
                        {isSelected ? '✓ SLOT SELECTED' : 'SELECT SLOT'}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {selectedSlot && (
              <div className="bg-cyan-950/60 border border-cyan-800 p-2.5 rounded text-cyan-200 flex items-center justify-between text-xs">
                <span>
                  Selected: <strong>{selectedSlot.displayDate} ({selectedSlot.displayStartTime} → {selectedSlot.displayEndTime})</strong>
                </span>
                <button
                  type="button"
                  onClick={handleOpenResolveConflict}
                  className="px-3 py-1 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs transition-colors"
                >
                  Proceed to Resolve Conflict →
                </button>
              </div>
            )}
          </div>
        )}

        {/* DIRECT EDIT RESERVATION & MODE FORM */}
        {isEditing && (
          <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveEdit} className="bg-slate-900/95 border border-orange-500/80 p-5 rounded-lg space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2.5">
              <span className="text-xs font-bold text-orange-400 uppercase flex items-center gap-1.5 font-mono">
                <Edit3 className="w-4 h-4 text-orange-400" /> Edit Reservation &amp; Mode
              </span>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                ✕ Close
              </button>
            </div>

            {errorMsg && (
              <div className="bg-red-950/90 border border-red-700 text-red-200 p-3 rounded text-xs flex items-center gap-2 font-mono">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* LIVE DATE ORDER ERROR BANNER */}
            {isEditDateOrderInvalid && (
              <div className="bg-red-950/90 border-2 border-red-600 rounded p-3 text-red-200 text-xs flex items-center gap-2.5 animate-pulse font-mono">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span className="font-bold">Start date time is greater than the end date time.</span>
              </div>
            )}

            {/* TARGET ENVIRONMENT PROFILE DROPDOWN */}
            <div className="space-y-1 bg-black/40 p-3.5 rounded border border-slate-200 dark:border-slate-800 font-mono">
              <label className="text-[10px] font-bold uppercase text-slate-400 block">
                TARGET ENVIRONMENT PROFILE:
              </label>
              <select
                value={editEnvId}
                onChange={(e) => setEditEnvId(e.target.value)}
                className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
              >
                {environmentProfiles.map((env) => (
                  <option key={env.id} value={env.id}>
                    {env.name} ({env.type})
                  </option>
                ))}
              </select>
            </div>

            {/* TIME WINDOW EDITORS */}
            <div className="space-y-3 bg-black/40 p-3.5 rounded border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] font-mono font-bold uppercase text-slate-400 block">
                MODIFY TIME WINDOW:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <DateTimePicker
                  label="START DATE & TIME"
                  subLabel="HH:MM:SS"
                  required
                  value={editStart}
                  onChange={(val) => {
                    setEditStart(val);
                    setErrorMsg(null);
                  }}
                />

                <DateTimePicker
                  label="END DATE & TIME"
                  subLabel="HH:MM:SS"
                  required
                  value={editEnd}
                  onChange={(val) => {
                    setEditEnd(val);
                    setErrorMsg(null);
                  }}
                />
              </div>
            </div>

            {/* RESERVATION MODE TOGGLE (Disruptive ↔ Shared) */}
            <div className="space-y-2 bg-black/40 p-3.5 rounded border border-slate-200 dark:border-slate-800 font-mono text-xs">
              <label className="text-[10px] font-bold uppercase text-slate-400 block">
                RESERVATION MODE:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  onClick={() => setEditMode('SHARED')}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    editMode === 'SHARED'
                      ? 'bg-cyan-950/90 border-cyan-400 text-white shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                      : 'bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-cyan-400" /> Shared Mode
                    </span>
                    {editMode === 'SHARED' && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                  </div>
                  <p className="text-[10px] text-slate-400 font-sans leading-tight">
                    Allows non-interfering concurrent execution with other shared reservations.
                  </p>
                </div>

                <div
                  onClick={() => setEditMode('DISRUPTIVE')}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    editMode === 'DISRUPTIVE'
                      ? 'bg-amber-950/90 border-amber-500 text-white shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                      : 'bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-amber-400" /> Disruptive Mode
                    </span>
                    {editMode === 'DISRUPTIVE' && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                  </div>
                  <p className="text-[10px] text-slate-400 font-sans leading-tight">
                    Requires exclusive environment control. Prevents any overlapping reservations.
                  </p>
                </div>
              </div>
            </div>

            {/* AI BOOKING INTELLIGENCE CARD */}
            {editAiAssistResult && (
              <div className="bg-[#0b1320] border border-orange-500/50 rounded-lg p-3.5 space-y-2.5 text-xs font-mono shadow-[0_0_15px_rgba(249,115,22,0.15)]">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 font-bold text-orange-400">
                    <BrainCircuit className="w-4 h-4 text-orange-400" /> AI BOOKING INTELLIGENCE
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      editAiAssistResult.prediction.riskLevel === 'VERY_HIGH'
                        ? 'bg-red-950 text-red-400 border border-red-800'
                        : editAiAssistResult.prediction.riskLevel === 'HIGH'
                        ? 'bg-orange-950 text-orange-400 border border-orange-800'
                        : editAiAssistResult.prediction.riskLevel === 'MEDIUM'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}
                  >
                    RISK: {editAiAssistResult.prediction.riskLevel} ({editAiAssistResult.prediction.conflictProbability}%)
                  </span>
                </div>

                {/* Explanations */}
                <div className="space-y-1 bg-black/40 p-2 rounded border border-slate-200 dark:border-slate-800 text-[11px]">
                  {editAiAssistResult.prediction.explanations.map((exp) => (
                    <div key={exp.id} className="flex items-start gap-1.5 text-slate-300">
                      <span className="text-orange-400 shrink-0">•</span>
                      <span>
                        <strong className="text-white">{exp.title}:</strong> {exp.detail}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Recommended Alternatives */}
                {editAiAssistResult.recommendations.length > 0 && (
                  <div className="space-y-1.5 pt-1 border-t border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-emerald-400 font-bold uppercase flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-emerald-400" /> RECOMMENDED ALTERNATIVES (LOWER CONFLICT RISK)
                    </span>

                    <div className="space-y-1.5">
                      {editAiAssistResult.recommendations.map((rec) => (
                        <div
                          key={rec.environmentId}
                          className="bg-slate-900/90 p-2 rounded border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 hover:border-slate-700 transition-colors"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <strong className="text-white text-xs truncate">{rec.environmentName}</strong>
                              <span className="text-[10px] text-emerald-400 font-bold">{rec.compatibilityScore}% MATCH</span>
                            </div>
                            <p className="text-[10px] text-slate-400 truncate">{rec.reasoning}</p>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              setEditEnvId(rec.environmentId);
                              showToast(`Switched to recommended environment: ${rec.environmentName}`, 'success');
                            }}
                            className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] shrink-0 flex items-center gap-1 transition-colors"
                          >
                            USE THIS <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* LIVE CONFLICT WARNING ALERT */}
            {editConflictingBookings.length > 0 && (
              <div className="bg-[#240c0f] border-2 border-red-600/90 rounded-lg p-3.5 space-y-2 text-xs font-mono animate-fadeIn">
                <div className="flex items-center gap-2 text-red-400 font-bold">
                  <ShieldAlert className="w-4 h-4 text-red-400 animate-pulse" />
                  <span>TIME COLLISION DETECTED ({editConflictingBookings.length} OVERLAP)</span>
                </div>
                <p className="text-[11px] text-red-300/90 font-sans font-semibold">
                  This environment has a conflicting disruptive reservation during the selected date and time.
                </p>
                <div className="space-y-1.5 bg-black/50 p-2.5 rounded border border-red-900/60 max-h-36 overflow-y-auto">
                  {editConflictingBookings.map((c) => (
                    <div key={c.id} className="text-[11px] border-b border-red-950/80 pb-1.5 last:border-0 last:pb-0">
                      <div className="flex items-center justify-between text-white font-bold">
                        <span>
                          #{c.id} {c.purpose} ({c.team})
                        </span>
                        <span className="text-amber-400 text-[10px] font-mono">[MODE: {c.reservationMode || 'SHARED'}]</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>Owner: <strong className="text-slate-200">{c.requestedBy}</strong></span>
                        <span className="text-red-300 font-mono">
                          {formatDisplayDateTime(c.startDate)} → {formatDisplayDateTime(c.endDate)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ACTION BUTTONS */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isEditDateOrderInvalid}
                className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white text-xs font-mono font-bold uppercase tracking-wider shadow-[0_0_12px_rgba(249,115,22,0.4)]"
              >
                Save Reservation Changes
              </button>
            </div>
          </form>
        )}

        {/* RESOLVE CONFLICT MODAL / OPTIONS DRAWER */}
        {isResolving && (
          <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveResolution} className="bg-slate-900/95 border border-orange-500/80 p-5 rounded-lg space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2.5">
              <span className="text-xs font-bold text-orange-400 uppercase flex items-center gap-1.5 font-mono">
                <Sparkles className="w-4 h-4 text-orange-400" /> Resolve Reservation Conflict
              </span>
              <button
                type="button"
                onClick={() => setIsResolving(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                ✕ Close
              </button>
            </div>

            {errorMsg && (
              <div className="bg-red-950/90 border border-red-700 text-red-200 p-3 rounded text-xs flex items-center gap-2 font-mono">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* RESOLUTION OPTIONS TOGGLE (Option A vs Option B) */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono font-bold uppercase text-slate-400 block">
                CHOOSE RESOLUTION METHOD:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  onClick={() => setResolutionOption('DATE_TIME')}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    resolutionOption === 'DATE_TIME'
                      ? 'bg-orange-950/80 border-orange-500 text-white shadow-[0_0_12px_rgba(249,115,22,0.3)]'
                      : 'bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs font-mono flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-orange-400" /> Option A – Change Date/Time
                    </span>
                    {resolutionOption === 'DATE_TIME' && <CheckCircle2 className="w-4 h-4 text-orange-400" />}
                  </div>
                  <p className="text-[10px] text-slate-400 font-sans leading-tight">
                    Shift start/end date and time to a non-conflicting available slot.
                  </p>
                </div>

                <div
                  onClick={() => setResolutionOption('MODE_CHANGE')}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    resolutionOption === 'MODE_CHANGE'
                      ? 'bg-cyan-950/80 border-cyan-500 text-white shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                      : 'bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs font-mono flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-cyan-400" /> Option B – Disruptive → Shared
                    </span>
                    {resolutionOption === 'MODE_CHANGE' && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                  </div>
                  <p className="text-[10px] text-slate-400 font-sans leading-tight">
                    Convert reservation mode to Shared to allow non-interfering co-existence.
                  </p>
                </div>
              </div>
            </div>

            {/* OPTION A DETAILS: DATE & TIME */}
            {resolutionOption === 'DATE_TIME' && (
              <div className="space-y-3 bg-black/40 p-3 rounded border border-slate-200 dark:border-slate-800">
                {selectedSlot && (
                  <div className="bg-cyan-950/60 border border-cyan-800 p-2.5 rounded text-xs text-cyan-200 font-mono">
                    <strong className="block text-white mb-0.5">Using Discovered Available Slot:</strong>
                    <span>{selectedSlot.displayDate} ({selectedSlot.displayStartTime} → {selectedSlot.displayEndTime})</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <DateTimePicker
                    label="NEW START DATE & TIME"
                    subLabel="HH:MM:SS"
                    required
                    value={resolveStart}
                    onChange={(val) => {
                      setResolveStart(val);
                      setErrorMsg(null);
                    }}
                  />

                  <DateTimePicker
                    label="NEW END DATE & TIME"
                    subLabel="HH:MM:SS"
                    required
                    value={resolveEnd}
                    onChange={(val) => {
                      setResolveEnd(val);
                      setErrorMsg(null);
                    }}
                  />
                </div>
              </div>
            )}

            {/* OPTION B DETAILS: DISRUPTIVE TO SHARED */}
            {resolutionOption === 'MODE_CHANGE' && (
              <div className="bg-cyan-950/40 border border-cyan-800/80 p-3.5 rounded text-xs text-cyan-200 space-y-2 font-mono">
                <span className="font-bold block text-white">Convert Reservation Mode to SHARED</span>
                <p className="text-[11px] text-slate-300 font-sans">
                  Changing mode from <strong className="text-amber-400">DISRUPTIVE</strong> to <strong className="text-cyan-300">SHARED</strong> removes exclusive control requirements and permits co-existence with other shared reservations during this window.
                </p>
              </div>
            )}

            {/* Final Action Bar */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsResolving(false)}
                className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white text-xs font-mono font-bold uppercase tracking-wider shadow-[0_0_12px_rgba(249,115,22,0.4)]"
              >
                Confirm Resolution & Save
              </button>
            </div>
          </form>
        )}

        {/* Rejection Confirmation Inline Dialog */}
        {isConfirmingReject && (
          <div className="bg-rose-950/70 border border-rose-700 p-4 rounded-lg space-y-3 animate-fadeIn">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
              <XCircle className="w-4 h-4" />
              <span>Confirm Reservation Rejection</span>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed font-sans">
              Are you sure you want to reject booking <strong className="text-white">"{booking.purpose}"</strong> on <strong className="text-orange-400">{booking.environmentName}</strong>?
            </p>
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 block">
                Rejection Reason
              </label>
              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Specify reason for rejection (optional)..."
                rows={2}
                className="w-full bg-[#162032] border border-slate-700 rounded p-2 text-xs text-white placeholder:text-slate-500 font-mono focus:outline-none focus:border-rose-500"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsConfirmingReject(false)}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
              >
                No, Keep Booking
              </button>
              <button
                type="button"
                onClick={handleConfirmRejection}
                className="px-4 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-[0_0_12px_rgba(225,29,72,0.5)] flex items-center gap-1"
              >
                <XCircle className="w-3.5 h-3.5" /> Yes, Reject Reservation
              </button>
            </div>
          </div>
        )}

        {/* Cancellation Confirmation Inline Dialog */}
        {isConfirmingCancel && (
          <div className="bg-red-950/70 border border-red-700 p-4 rounded-lg space-y-3 animate-fadeIn">
            <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
              <Ban className="w-4 h-4" />
              <span>Confirm Reservation Cancellation</span>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed font-sans">
              Are you sure you want to cancel booking <strong className="text-white">"{booking.purpose}"</strong> on <strong className="text-orange-400">{booking.environmentName}</strong>?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsConfirmingCancel(false)}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
              >
                No, Keep Booking
              </button>
              <button
                type="button"
                onClick={handleConfirmCancellation}
                className="px-4 py-1.5 rounded bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow-[0_0_12px_rgba(239,68,68,0.5)]"
              >
                Yes, Cancel Reservation
              </button>
            </div>
          </div>
        )}

        {/* Booking Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 bg-[#090d14] p-4 rounded-lg border border-slate-200 dark:border-slate-800/80">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
              <Server className="w-3 h-3 text-orange-400" /> Target Environment
            </span>
            <span className="text-white font-bold text-sm block">{booking.environmentName}</span>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
              <Building2 className="w-3 h-3 text-orange-400" /> Business Unit
            </span>
            <span className="text-orange-400 font-bold text-sm block">{booking.businessUnit}</span>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
              <AppWindow className="w-3 h-3 text-blue-400" /> Project & Application
            </span>
            <span className="text-white font-bold block">
              {booking.project} / {booking.application}
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
              <Users className="w-3 h-3 text-slate-400" /> Team & Requester
            </span>
            <span className="text-slate-300 block font-sans">
              {booking.team} (by {booking.requestedBy})
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
              Priority
            </span>
            <span className="text-white font-bold block">
              {booking.priority || 'MEDIUM'}
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
              Auto Approval
            </span>
            <span className="text-white font-bold block">
              {booking.autoApprovalEnabled ? `Enabled (${booking.autoApprovalRule})` : 'Disabled'}
            </span>
          </div>

          <div className="md:col-span-2 pt-2 border-t border-slate-200 dark:border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 uppercase flex items-center gap-1 font-bold">
              <Clock className="w-3.5 h-3.5 text-orange-400" /> Time Window (Exact Range)
            </span>
            <div className="bg-[#121c2d] p-2.5 rounded border border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-white">
              <div>
                <span className="text-slate-400 text-[10px] block">START TIME</span>
                <span className="font-bold text-orange-300">{formatDisplayDateTime(booking.startDate)}</span>
              </div>
              <span className="text-slate-500 my-1 sm:my-0">→</span>
              <div>
                <span className="text-slate-400 text-[10px] block">END TIME</span>
                <span className="font-bold text-orange-300">{formatDisplayDateTime(booking.endDate)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* AUDIT TRAIL HISTORY SECTION */}
        {booking.auditHistory && booking.auditHistory.length > 0 && (
          <div className="bg-[#090d14] p-4 rounded-lg border border-slate-200 dark:border-slate-800/80 space-y-2">
            <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2">
              <History className="w-3.5 h-3.5 text-orange-400" /> AUDIT TRAIL HISTORY
            </span>

            <div className="space-y-1.5 pt-1">
              {booking.auditHistory.map((audit) => (
                <div key={audit.id} className="flex items-center justify-between text-[11px] bg-slate-900/60 p-2 rounded border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-300">
                    <strong className="text-white">{audit.field}</strong>: <span className="line-through text-slate-500">{audit.oldValue}</span> → <strong className="text-orange-400">{audit.newValue}</strong>
                  </span>
                  <span className="text-slate-500 text-[10px]">
                    {audit.changedBy} · {formatDisplayDateTime(audit.changedAt)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        </div>

        {/* Fixed Sticky Footer Actions */}
        <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 z-10">
          <div className="flex items-center gap-2">
            {!isInactive && !isResolving && !isEditing && !isConfirmingCancel && !isConfirmingReject && (
              <>
                <button
                  onClick={() => setIsConfirmingReject(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded bg-slate-800 hover:bg-rose-700 text-rose-300 hover:text-white border border-slate-700 transition-colors text-xs font-bold"
                >
                  <XCircle className="w-3.5 h-3.5" /> Reject Reservation
                </button>
                <button
                  onClick={() => setIsConfirmingCancel(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded bg-slate-800 hover:bg-red-600 text-slate-300 hover:text-white border border-slate-700 transition-colors text-xs font-bold"
                >
                  <Ban className="w-3.5 h-3.5" /> Cancel Reservation
                </button>
              </>
            )}

            {!isInactive && !isResolving && !isEditing && !isCheckingAvailability && !isConfirmingCancel && !isConfirmingReject && (
              isConflict ? (
                <>
                  <button
                    onClick={handleCheckAvailability}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-700 transition-colors text-xs font-bold"
                  >
                    <Search className="w-3.5 h-3.5 text-cyan-400" /> Check Availability
                  </button>
                  <button
                    onClick={handleOpenResolveConflict}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs shadow-[0_0_12px_rgba(249,115,22,0.4)]"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-white" /> Resolve Conflict
                  </button>
                </>
              ) : (
                <button
                  onClick={handleOpenEditReservation}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs shadow-[0_0_12px_rgba(249,115,22,0.4)]"
                >
                  <Edit3 className="w-3.5 h-3.5" /> Edit Reservation / Mode
                </button>
              )
            )}
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold ml-auto"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
