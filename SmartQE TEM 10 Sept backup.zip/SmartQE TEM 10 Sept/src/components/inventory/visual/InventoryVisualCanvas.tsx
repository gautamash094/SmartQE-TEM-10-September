import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  RotateCcw,
  Globe,
  Server,
  Cpu,
  Layers,
  HardDrive,
  Cloud,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  ChevronDown,
  Plus,
  Minus,
  Sparkles,
  Search,
  Focus,
  Component as ComponentIcon
} from 'lucide-react';
import { InventoryGraphNode, InventoryGraphEdge } from './inventoryGraphBuilder';

interface InventoryVisualCanvasProps {
  nodes: InventoryGraphNode[];
  edges: InventoryGraphEdge[];
  selectedNodeId: string | null;
  onSelectNode: (node: InventoryGraphNode) => void;
  collapsedNodeIds: Set<string>;
  onToggleCollapse: (nodeId: string) => void;
  searchQuery: string;
}

export const InventoryVisualCanvas: React.FC<InventoryVisualCanvasProps> = ({
  nodes,
  edges,
  selectedNodeId,
  onSelectNode,
  collapsedNodeIds,
  onToggleCollapse,
  searchQuery
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState<number>(0.95);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 40, y: 40 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Compute active highlight path (ancestors + descendants) for hovered or selected node
  const activeHighlightNodeIds = useMemo(() => {
    const targetId = hoveredNodeId || selectedNodeId;
    if (!targetId) return null;

    const set = new Set<string>();
    set.add(targetId);

    const nodeMap = new Map(nodes.map(n => [n.id, n]));

    // Upstream
    const addAncestors = (id: string) => {
      const n = nodeMap.get(id);
      if (n?.parentIds) {
        n.parentIds.forEach(pId => {
          if (!set.has(pId)) {
            set.add(pId);
            addAncestors(pId);
          }
        });
      }
    };

    // Downstream
    const addDescendants = (id: string) => {
      const n = nodeMap.get(id);
      if (n?.childIds) {
        n.childIds.forEach(cId => {
          if (!set.has(cId)) {
            set.add(cId);
            addDescendants(cId);
          }
        });
      }
    };

    addAncestors(targetId);
    addDescendants(targetId);

    return set;
  }, [hoveredNodeId, selectedNodeId, nodes]);

  // Compute active highlight edges
  const activeHighlightEdgeIds = useMemo(() => {
    if (!activeHighlightNodeIds) return null;
    const set = new Set<string>();
    edges.forEach(e => {
      if (activeHighlightNodeIds.has(e.source) && activeHighlightNodeIds.has(e.target)) {
        set.add(e.id);
      }
    });
    return set;
  }, [activeHighlightNodeIds, edges]);

  // Mouse pan handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.canvas-interactive-node') || (e.target as HTMLElement).closest('.canvas-control-button')) {
      return;
    }
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Native non-passive Wheel / Pinch Zoom Listener (strictly contained to canvas only)
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const handleNativeWheel = (e: WheelEvent) => {
      // Prevent entire browser/page zooming and scrolling when cursor is inside the graph canvas
      e.preventDefault();
      e.stopPropagation();

      const rect = el.getBoundingClientRect();
      const cursorX = e.clientX - rect.left;
      const cursorY = e.clientY - rect.top;

      let zoomFactor: number;
      if (e.ctrlKey) {
        // Trackpad pinch-to-zoom gesture
        zoomFactor = 1 - e.deltaY * 0.01;
      } else {
        // Standard mouse wheel
        zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
      }

      setZoom((prevZoom) => {
        const nextZoom = Math.min(Math.max(prevZoom * zoomFactor, 0.2), 3.0);
        if (Math.abs(nextZoom - prevZoom) < 0.0001) return prevZoom;

        // Anchor zooming directly around cursor focal point
        setPan((prevPan) => ({
          x: cursorX - (cursorX - prevPan.x) * (nextZoom / prevZoom),
          y: cursorY - (cursorY - prevPan.y) * (nextZoom / prevZoom),
        }));

        return nextZoom;
      });
    };

    el.addEventListener('wheel', handleNativeWheel, { passive: false });

    return () => {
      el.removeEventListener('wheel', handleNativeWheel);
    };
  }, []);

  // Fit to screen
  const handleFitToScreen = useCallback(() => {
    if (!containerRef.current || nodes.length === 0) return;
    const rect = containerRef.current.getBoundingClientRect();
    const maxX = Math.max(...nodes.map(n => n.x + n.width), 800);
    const maxY = Math.max(...nodes.map(n => n.y + n.height), 600);

    const padding = 80;
    const scaleX = (rect.width - padding) / maxX;
    const scaleY = (rect.height - padding) / maxY;
    const newZoom = Math.min(Math.max(Math.min(scaleX, scaleY), 0.35), 1.1);

    setZoom(newZoom);
    setPan({ x: 50, y: 40 });
  }, [nodes]);

  const handleResetZoom = () => {
    setZoom(0.95);
    setPan({ x: 40, y: 40 });
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Node Category Icon & Style Helper
  const getNodeCategoryConfig = (category: string) => {
    switch (category) {
      case 'BU':
        return {
          icon: Layers,
          border: 'border-orange-500/80',
          bg: 'bg-gradient-to-br from-[#1a1209] to-[#0f0b06]',
          badgeBg: 'bg-orange-500/20 text-orange-400 border-orange-500/30'
        };
      case 'PROJECT':
        return {
          icon: Layers,
          border: 'border-amber-500/80',
          bg: 'bg-gradient-to-br from-[#181508] to-[#0d0a04]',
          badgeBg: 'bg-amber-500/20 text-amber-400 border-amber-500/30'
        };
      case 'COMPONENT':
        return {
          icon: ComponentIcon,
          border: 'border-indigo-500/80',
          bg: 'bg-gradient-to-br from-[#121024] to-[#080712]',
          badgeBg: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30'
        };
      case 'APPLICATION':
        return {
          icon: Layers,
          border: 'border-purple-500/80',
          bg: 'bg-gradient-to-br from-[#160b24] to-[#0b0512]',
          badgeBg: 'bg-purple-500/20 text-purple-400 border-purple-500/30'
        };
      case 'ENVIRONMENT':
        return {
          icon: Globe,
          border: 'border-cyan-500/80',
          bg: 'bg-gradient-to-br from-[#091524] to-[#040a12]',
          badgeBg: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
        };
      case 'SERVER':
        return {
          icon: Server,
          border: 'border-blue-500/80',
          bg: 'bg-gradient-to-br from-[#09172e] to-[#050c18]',
          badgeBg: 'bg-blue-500/20 text-blue-400 border-blue-500/30'
        };
      case 'SOFTWARE':
        return {
          icon: Cpu,
          border: 'border-teal-500/80',
          bg: 'bg-gradient-to-br from-[#081f1d] to-[#030e0d]',
          badgeBg: 'bg-teal-500/20 text-teal-400 border-teal-500/30'
        };
      case 'CLOUD_RESOURCE':
        return {
          icon: Cloud,
          border: 'border-sky-500/80',
          bg: 'bg-gradient-to-br from-[#0a1b2e] to-[#040c14]',
          badgeBg: 'bg-sky-500/20 text-sky-400 border-sky-500/30'
        };
      default:
        return {
          icon: HardDrive,
          border: 'border-emerald-500/80',
          bg: 'bg-gradient-to-br from-[#091c13] to-[#040e09]',
          badgeBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
        };
    }
  };

  const getHealthRing = (health: string) => {
    switch (health) {
      case 'HEALTHY':
        return 'border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.35)]';
      case 'WARNING':
        return 'border-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.4)]';
      case 'CRITICAL':
        return 'border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.5)] animate-pulse';
      default:
        return 'border-slate-700';
    }
  };

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className={`relative w-full h-[650px] bg-[#070b13] border border-slate-800/90 rounded-2xl overflow-hidden select-none cursor-grab active:cursor-grabbing font-mono shadow-2xl ${
        isFullscreen ? 'fixed inset-0 z-50 h-screen rounded-none' : ''
      }`}
    >
      {/* Grid Pattern Background */}
      <div
        className="absolute inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#334155 1px, transparent 1px)`,
          backgroundSize: '24px 24px'
        }}
      />

      {/* Floating Canvas Controls */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-1.5 bg-[#0c121e]/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/80 shadow-xl canvas-control-button">
        <button
          type="button"
          onClick={() => setZoom(prev => Math.min(prev + 0.15, 2.2))}
          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => setZoom(prev => Math.max(prev - 0.15, 0.25))}
          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={handleFitToScreen}
          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          title="Fit Graph to Viewport"
        >
          <Focus className="w-4 h-4 text-orange-400" />
        </button>

        <button
          type="button"
          onClick={handleResetZoom}
          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          title="Reset Zoom & Pan"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <div className="w-[1px] h-5 bg-slate-700 mx-0.5" />

        <button
          type="button"
          onClick={toggleFullscreen}
          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          title="Toggle Fullscreen"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* Floating Info Pill at Top-Left */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-[#0c121e]/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/80 text-xs text-slate-300 shadow-xl">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="font-bold text-white">{nodes.length} Visible Nodes</span>
        <span className="text-slate-600">|</span>
        <span className="text-slate-400">{edges.length} Dependencies</span>
        <span className="text-slate-600">|</span>
        <span className="text-orange-400 font-bold">{Math.round(zoom * 100)}%</span>
      </div>

      {/* Empty State Overlay */}
      {nodes.length === 0 && (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 z-20 pointer-events-none">
          <div className="w-14 h-14 rounded-2xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400 mb-3 shadow-[0_0_20px_rgba(249,115,22,0.2)]">
            <Search className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">No Resources Match Current Filters</h3>
          <p className="text-xs text-slate-400 max-w-md font-sans">
            Try clearing your search query, switching the visual paradigm, or selecting &quot;All Business Units&quot;.
          </p>
        </div>
      )}

      {/* Main Interactive Zoom/Pan Transform Canvas */}
      <div
        className="absolute inset-0 origin-top-left transition-transform duration-75"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`
        }}
      >
        {/* SVG Edges Layer */}
        <svg
          className="absolute inset-0 overflow-visible pointer-events-none"
          style={{ width: '4000px', height: '3000px' }}
        >
          <defs>
            <marker
              id="arrow-default"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#64748b" />
            </marker>
            <marker
              id="arrow-highlighted"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#f97316" />
            </marker>
          </defs>

          {edges.map(edge => {
            const sourceNode = nodes.find(n => n.id === edge.source);
            const targetNode = nodes.find(n => n.id === edge.target);

            if (!sourceNode || !targetNode) return null;

            const startX = sourceNode.x + sourceNode.width;
            const startY = sourceNode.y + sourceNode.height / 2;
            const endX = targetNode.x;
            const endY = targetNode.y + targetNode.height / 2;

            const controlDist = Math.max(Math.abs(endX - startX) * 0.45, 60);
            const pathD = `M ${startX} ${startY} C ${startX + controlDist} ${startY}, ${endX - controlDist} ${endY}, ${endX} ${endY}`;

            const isHighlighted = activeHighlightEdgeIds ? activeHighlightEdgeIds.has(edge.id) : false;
            const isDimmed = activeHighlightEdgeIds && !isHighlighted;

            return (
              <g key={edge.id} className="transition-opacity duration-200">
                <path
                  d={pathD}
                  fill="none"
                  stroke={isHighlighted ? '#f97316' : '#334155'}
                  strokeWidth={isHighlighted ? 2.5 : 1.5}
                  strokeDasharray={edge.animated || edge.style === 'dashed' ? '5,5' : 'none'}
                  markerEnd={isHighlighted ? 'url(#arrow-highlighted)' : 'url(#arrow-default)'}
                  className={edge.animated ? 'animate-[dash_1s_linear_infinite]' : ''}
                  opacity={isDimmed ? 0.15 : 1}
                />
              </g>
            );
          })}
        </svg>

        {/* HTML Rich Nodes Layer */}
        {nodes.map(node => {
          const cfg = getNodeCategoryConfig(node.category);
          const Icon = cfg.icon;
          const isSelected = selectedNodeId === node.id;
          const isHovered = hoveredNodeId === node.id;
          const isPathHighlighted = activeHighlightNodeIds ? activeHighlightNodeIds.has(node.id) : false;
          const isDimmed = activeHighlightNodeIds && !isPathHighlighted;
          const isSearchMatch = Boolean(
            searchQuery &&
              (node.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
                node.subLabel?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                node.ipAddress?.toLowerCase().includes(searchQuery.toLowerCase()))
          );

          return (
            <div
              key={node.id}
              onClick={e => {
                e.stopPropagation();
                onSelectNode(node);
              }}
              onMouseEnter={() => setHoveredNodeId(node.id)}
              onMouseLeave={() => setHoveredNodeId(null)}
              style={{
                left: `${node.x}px`,
                top: `${node.y}px`,
                width: `${node.width}px`,
                height: `${node.height}px`
              }}
              className={`absolute canvas-interactive-node cursor-pointer rounded-xl p-3 border transition-all duration-150 group shadow-lg ${
                cfg.bg
              } ${cfg.border} ${
                isSelected
                  ? 'ring-2 ring-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.6)] scale-[1.03] z-30'
                  : isPathHighlighted
                  ? 'ring-1 ring-orange-400 shadow-[0_0_12px_rgba(249,115,22,0.4)] scale-[1.01] z-20'
                  : isSearchMatch
                  ? 'ring-2 ring-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.6)] animate-pulse z-20'
                  : 'hover:border-slate-500 hover:scale-[1.01] z-10'
              } ${isDimmed ? 'opacity-25' : 'opacity-100'}`}
            >
              {/* Top Bar inside Node */}
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5 min-w-0">
                  <div className="w-5 h-5 rounded-md bg-black/40 flex items-center justify-center shrink-0">
                    <Icon className="w-3.5 h-3.5 text-white" />
                  </div>
                  <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase border truncate ${cfg.badgeBg}`}>
                    {node.category}
                  </span>
                </div>

                {/* Health & Status Indicator Dot */}
                <div className="flex items-center gap-1 shrink-0">
                  <span
                    className={`w-2 h-2 rounded-full border ${
                      node.health === 'HEALTHY'
                        ? 'bg-emerald-400 border-emerald-600'
                        : node.health === 'WARNING'
                        ? 'bg-amber-400 border-amber-600'
                        : 'bg-rose-500 border-rose-700 animate-ping'
                    }`}
                    title={`Health: ${node.health} | Status: ${node.status}`}
                  />
                </div>
              </div>

              {/* Node Title & SubLabel */}
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-white truncate leading-tight group-hover:text-orange-400 transition-colors">
                  {node.label}
                </h4>
                <p className="text-[10px] text-slate-400 truncate mt-0.5 font-sans">
                  {node.subLabel || node.ipAddress || node.endpointUrl || node.tier || 'Active Component'}
                </p>
              </div>

              {/* Expand / Collapse Cluster Button */}
              {node.hasChildren && (
                <button
                  type="button"
                  onClick={e => {
                    e.stopPropagation();
                    onToggleCollapse(node.id);
                  }}
                  className={`absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-slate-900 border border-slate-700 hover:border-orange-500 text-slate-300 hover:text-white flex items-center justify-center shadow-md transition-transform ${
                    node.collapsed ? 'hover:scale-110' : ''
                  }`}
                  title={node.collapsed ? 'Expand child resources' : 'Collapse child resources'}
                >
                  {node.collapsed ? <Plus className="w-3.5 h-3.5 text-orange-400" /> : <Minus className="w-3.5 h-3.5 text-slate-400" />}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
