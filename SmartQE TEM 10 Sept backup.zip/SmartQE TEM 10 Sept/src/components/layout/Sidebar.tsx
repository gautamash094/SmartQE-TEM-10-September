import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutGrid,
  ClipboardList,
  Rocket,
  AlertTriangle,
  Settings,
  Shield,
  Users,
  KeyRound,
  BookOpen,
  Briefcase,
  Cpu,
  Zap,
  Boxes,
  Layers,
  ChevronDown,
  ChevronRight,
  Compass,
  PanelLeftClose,
  Activity,
  Sparkles,
  User,
  Webhook,
  Calendar,
  GitFork,
} from 'lucide-react';
import { accessService } from '../../services/accessService';
import { useAuth } from '../../context/AuthContext';

interface NavItemChild {
  name: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface NavItem {
  name: string;
  path?: string;
  icon: React.ComponentType<{ className?: string }>;
  children?: NavItemChild[];
}

interface SidebarProps {
  mobileOpen?: boolean;
  onMobileClose?: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  isHovered?: boolean;
  onMouseEnter?: () => void;
  onMouseLeave?: () => void;
}

const SIDEBAR_STORAGE_KEY = 'smartqe_tem_sidebar_expanded_menus';

export const Sidebar: React.FC<SidebarProps> = ({
  mobileOpen,
  onMobileClose,
  isCollapsed,
  onToggleCollapse,
  isHovered: externalHovered,
  onMouseEnter: externalMouseEnter,
  onMouseLeave: externalMouseLeave,
}) => {
  const location = useLocation();
  const { currentUser, hasPermission } = useAuth();

  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>(() => {
    const isResourceChildActive =
      location.pathname === '/ai-predictive-demand' ||
      location.pathname === '/environment-monitoring' ||
      location.pathname.startsWith('/environment-monitoring/') ||
      location.pathname === '/monitoring' ||
      location.pathname === '/inventory' ||
      location.pathname.startsWith('/inventory/') ||
      location.pathname === '/environment-topology' ||
      location.pathname.startsWith('/environment-topology/') ||
      location.pathname === '/topology';

    const isSettingsChildActive =
      location.pathname === '/settings' ||
      location.pathname.startsWith('/settings/') ||
      location.pathname === '/settings/users' ||
      location.pathname === '/settings/roles' ||
      location.pathname === '/settings/access';

    if (isSettingsChildActive) {
      return {
        'Settings': true,
        'Resource Management': false,
      };
    }

    if (isResourceChildActive) {
      return {
        'Settings': false,
        'Resource Management': true,
      };
    }

    // Default for TEM Dashboard / Home / Other Modules: All parent menus collapsed
    return {
      'Settings': false,
      'Resource Management': false,
    };
  });

  useEffect(() => {
    const isResourceChildActive =
      location.pathname === '/ai-predictive-demand' ||
      location.pathname === '/environment-monitoring' ||
      location.pathname.startsWith('/environment-monitoring/') ||
      location.pathname === '/monitoring' ||
      location.pathname === '/inventory' ||
      location.pathname.startsWith('/inventory/') ||
      location.pathname === '/environment-topology' ||
      location.pathname.startsWith('/environment-topology/') ||
      location.pathname === '/topology';

    const isSettingsChildActive =
      location.pathname === '/settings' ||
      location.pathname.startsWith('/settings/') ||
      location.pathname === '/settings/users' ||
      location.pathname === '/settings/roles' ||
      location.pathname === '/settings/access';

    if (isSettingsChildActive) {
      setExpandedMenus({
        'Settings': true,
        'Resource Management': false,
      });
      try {
        localStorage.setItem(
          SIDEBAR_STORAGE_KEY,
          JSON.stringify({ 'Settings': true, 'Resource Management': false })
        );
      } catch {}
    } else if (isResourceChildActive) {
      setExpandedMenus({
        'Settings': false,
        'Resource Management': true,
      });
      try {
        localStorage.setItem(
          SIDEBAR_STORAGE_KEY,
          JSON.stringify({ 'Settings': false, 'Resource Management': true })
        );
      } catch {}
    } else {
      // When navigating to any other module (TEM Dashboard, Entity Management, Worklist, etc.), collapse Settings
      setExpandedMenus({
        'Settings': false,
        'Resource Management': false,
      });
      try {
        localStorage.setItem(
          SIDEBAR_STORAGE_KEY,
          JSON.stringify({ 'Settings': false, 'Resource Management': false })
        );
      } catch {}
    }
  }, [location.pathname]);

  const [internalHovered, setInternalHovered] = useState<boolean>(false);
  const hoverTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);

  const isHovered = externalHovered !== undefined ? externalHovered : internalHovered;

  const handleMouseEnter = () => {
    if (externalMouseEnter) {
      externalMouseEnter();
    } else {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current);
        hoverTimeoutRef.current = null;
      }
      if (isCollapsed) {
        setInternalHovered(true);
      }
    }
  };

  const handleMouseLeave = () => {
    if (externalMouseLeave) {
      externalMouseLeave();
    } else {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current);
      }
      hoverTimeoutRef.current = setTimeout(() => {
        setInternalHovered(false);
      }, 250);
    }
  };

  useEffect(() => {
    return () => {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current);
      }
    };
  }, []);

  const toggleMenu = (name: string) => {
    setExpandedMenus((prev) => {
      const willBeOpen = !prev[name];
      const next: Record<string, boolean> = { ...prev };
      if (willBeOpen) {
        // Mutually exclusive: close other parent menus when opening one
        Object.keys(next).forEach((key) => {
          if (key !== name) {
            next[key] = false;
          }
        });
      }
      next[name] = willBeOpen;
      try {
        localStorage.setItem(SIDEBAR_STORAGE_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const isSuperAdmin =
    Boolean(currentUser?.isSuperAdmin) ||
    currentUser?.username?.toLowerCase() === 'admin' ||
    (currentUser?.roles || []).some((r) => r.name?.toLowerCase().trim() === 'super admin');

  const isItemVisible = (itemPath?: string, children?: NavItemChild[]): boolean => {
    if (!currentUser) return false;

    // 1. Super Admin ALWAYS has 100% unrestricted visibility to every screen and module
    if (isSuperAdmin) {
      return true;
    }

    // 2. Non-Super Admin: check configured permissions
    if (itemPath && hasPermission(itemPath)) {
      return true;
    }
    if (children && children.some((c) => hasPermission(c.path))) {
      return true;
    }
    return false;
  };

  const rawMainModules: NavItem[] = [
    { name: 'TEM Dashboard', path: '/tem-dashboard', icon: LayoutGrid },
    {
      name: 'Settings',
      icon: Settings,
      children: [
        { name: 'User Management', path: '/settings/users', icon: User },
        { name: 'Role Management', path: '/settings/roles', icon: Shield },
        { name: 'Access Management', path: '/settings/access', icon: KeyRound },
        { name: 'User Group Management', path: '/settings/user-groups', icon: Users },
        { name: 'Define Workflow', path: '/settings/define-workflow', icon: GitFork },
      ],
    },
    { name: 'Entity Management', path: '/entity-management', icon: Briefcase },
    { name: 'Environment Details', path: '/environment-details', icon: Cpu },
    { name: 'Worklist', path: '/worklist', icon: ClipboardList },
    { name: 'Bookings Grid', path: '/bookings', icon: Calendar },
    { name: 'Releases', path: '/releases', icon: Rocket },
    { name: 'Incidents', path: '/incidents', icon: AlertTriangle },
    {
      name: 'Resource Management',
      icon: Layers,
      children: [
        { name: 'Inventory Management', path: '/inventory', icon: Boxes },
        { name: 'Environment Topology', path: '/environment-topology', icon: Compass },
        { name: 'Environment Monitoring', path: '/environment-monitoring', icon: Activity },
        { name: 'AI Predictive Demand', path: '/ai-predictive-demand', icon: Sparkles },
      ],
    },
    { name: 'External Integrations', path: '/external-integrations', icon: Webhook },
  ];

  const mainModules: NavItem[] = rawMainModules
    .filter((item) => isItemVisible(item.path, item.children))
    .map((item) => ({
      ...item,
      children: item.children?.filter((c) => isSuperAdmin || hasPermission(c.path)),
    }))
    .filter((item) => (item.children ? item.children.length > 0 : true));

  const systemModules: NavItem[] = [
    { name: 'Runbooks', path: '/runbooks', icon: BookOpen },
  ].filter((item) => isItemVisible(item.path));

  const isDrawerOpen = mobileOpen || !isCollapsed || isHovered;

  return (
    <>
      {/* 0. Left Edge Hover Trigger Strip when Sidebar is collapsed */}
      {isCollapsed && !isHovered && (
        <div
          onMouseEnter={handleMouseEnter}
          className="fixed top-0 left-0 bottom-0 w-3 z-40 pointer-events-auto cursor-pointer"
          aria-hidden="true"
        />
      )}



      {/* 1. BRAND LOGO HEADER */}
      <div
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className={`fixed top-0 left-0 z-50 h-16 w-64 bg-white dark:bg-[#090d14] border-r border-b border-slate-200 dark:border-slate-800/80 px-5 flex items-center justify-between shadow-sm select-none transition-all duration-300 ease-in-out ${
          isDrawerOpen
            ? 'translate-x-0 opacity-100 pointer-events-auto'
            : '-translate-x-full opacity-0 pointer-events-none'
        }`}
      >
        <NavLink
          to="/tem-dashboard"
          onClick={onMobileClose}
          className="flex items-center gap-3 truncate group cursor-pointer hover:opacity-90 transition-opacity"
          title="Navigate to TEM Dashboard"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white shadow-[0_0_12px_rgba(249,115,22,0.4)] shrink-0 group-hover:scale-105 transition-transform">
            <Zap className="w-5 h-5 fill-current text-white" />
          </div>
          <div className="truncate">
            <h1 className="text-sm font-bold tracking-wider text-slate-900 dark:text-white uppercase font-mono truncate group-hover:text-orange-500 dark:group-hover:text-orange-400 transition-colors">
              SmartQE
            </h1>
            <p className="text-[10px] font-mono tracking-widest text-slate-500 dark:text-slate-400 truncate group-hover:text-slate-700 dark:group-hover:text-slate-200 transition-colors">
              TEM CONTROL
            </p>
          </div>
        </NavLink>

        {/* Quick Pin / Collapse Button on Logo Header */}
        {onToggleCollapse && (
          <button
            onClick={onToggleCollapse}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
            title={isCollapsed ? "Pin Sidebar Open" : "Collapse Sidebar"}
            aria-label={isCollapsed ? "Pin Sidebar Open" : "Collapse Sidebar"}
          >
            <PanelLeftClose className={`w-4 h-4 transition-transform ${isCollapsed ? 'rotate-180 text-orange-500' : 'text-slate-400'}`} />
          </button>
        )}
      </div>

      {/* 2. COLLAPSIBLE NAVIGATION MENU DRAWER (Below Logo Header) */}
      <aside
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className={`fixed top-16 left-0 bottom-0 z-50 w-64 bg-white dark:bg-[#090d14] border-r border-slate-200 dark:border-slate-800/80 flex flex-col transition-all duration-300 ease-in-out ${
          isCollapsed && isHovered ? 'shadow-[0_20px_30px_rgba(0,0,0,0.6)]' : 'shadow-sm'
        } ${
          isDrawerOpen
            ? 'translate-x-0 opacity-100 pointer-events-auto'
            : '-translate-x-full opacity-0 pointer-events-none'
        }`}
      >
        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
          {/* MODULES Section */}
          <div>
            <div className="flex items-center justify-between px-3 mb-3">
              <h2 className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400 dark:text-slate-500">
                MODULES
              </h2>

              {/* Collapse Sidebar Button on the MODULES Header Line */}
              {onToggleCollapse && (
                <button
                  onClick={onToggleCollapse}
                  className="p-1 rounded text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1 group"
                  title="Collapse Menu"
                  aria-label="Collapse Menu"
                >
                  <PanelLeftClose className="w-4 h-4 text-slate-400 group-hover:text-orange-500 dark:group-hover:text-orange-400 transition-colors" />
                </button>
              )}
            </div>
            <nav className="space-y-1">
              {mainModules.map((item) => {
                const Icon = item.icon;

                if (item.children && item.children.length > 0) {
                  const isExpanded = !!expandedMenus[item.name];
                  const isAnyChildActive = item.children.some(
                    (child) => location.pathname === child.path || location.pathname.startsWith(child.path + '/')
                  );

                  return (
                    <div key={item.name} className="space-y-1">
                      <button
                        type="button"
                        onClick={() => toggleMenu(item.name)}
                        className={`flex items-center justify-between w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                          isAnyChildActive
                            ? 'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-slate-800/60 font-bold border border-orange-200 dark:border-orange-500/20'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0 flex-1">
                          <Icon className={`w-4 h-4 shrink-0 ${isAnyChildActive ? 'text-orange-600 dark:text-orange-400' : 'text-slate-500 dark:text-slate-400'}`} />
                          <span className="whitespace-nowrap truncate">{item.name}</span>
                        </div>
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4 text-slate-400 shrink-0 ml-1 transition-transform duration-200" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 ml-1 transition-transform duration-200" />
                        )}
                      </button>

                      {isExpanded && (
                        <div className="pl-3 pr-1 mt-1 space-y-1 border-l border-slate-200 dark:border-slate-800/80 ml-5 animate-in fade-in duration-150">
                          {item.children.map((child) => {
                            const ChildIcon = child.icon;
                            return (
                              <NavLink
                                key={child.path}
                                to={child.path}
                                onClick={onMobileClose}
                                className={({ isActive }) =>
                                  `flex items-center gap-2 px-2.5 py-2 rounded-md text-xs font-medium transition-all ${
                                    isActive
                                      ? 'bg-orange-500/10 text-orange-600 dark:bg-orange-500/20 dark:text-orange-400 border border-orange-500/30 dark:border-orange-500/40 font-bold shadow-sm'
                                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/40'
                                  }`
                                }
                              >
                                <ChildIcon className="w-3.5 h-3.5 shrink-0" />
                                <span className="whitespace-nowrap truncate">{child.name}</span>
                              </NavLink>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                }

                return (
                  <NavLink
                    key={item.path}
                    to={item.path!}
                    onClick={onMobileClose}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                        isActive
                          ? 'bg-slate-100 dark:bg-slate-800/90 text-slate-900 dark:text-white border-l-4 border-orange-500 shadow-sm font-bold'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/40'
                      }`
                    }
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="whitespace-nowrap truncate">{item.name}</span>
                  </NavLink>
                );
              })}
            </nav>
          </div>

          {/* SYSTEM Section */}
          <div>
            <h2 className="px-3 text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400 dark:text-slate-500 mb-3">
              SYSTEM
            </h2>
            <nav className="space-y-1">
              {systemModules.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.path}
                    to={item.path!}
                    onClick={onMobileClose}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                        isActive
                          ? 'bg-slate-100 dark:bg-slate-800/90 text-slate-900 dark:text-white border-l-4 border-orange-500 shadow-sm font-bold'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/40'
                      }`
                    }
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.name}</span>
                  </NavLink>
                );
              })}
            </nav>
          </div>
        </div>

        {/* User Footer Profile Card */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-slate-950/40 transition-colors duration-150">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300">
              <User className="w-4 h-4" />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                {currentUser?.fullName || currentUser?.username || 'User'}
              </p>
              <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
                {currentUser?.email || (currentUser?.username ? `${currentUser.username}@smartqe.io` : '')}
              </p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};