import { Environment, Incident, Release, Booking, Runbook, OverviewMetrics } from '../types';

export const INITIAL_ENVIRONMENTS: Environment[] = [];

export const INITIAL_INCIDENTS: Incident[] = [];

export const INITIAL_RELEASES: Release[] = [];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: '278f8189-7993-4217-b663-bcc942267a26',
    environmentId: '2c2726a3-e358-4537-9862-e5ab41059d6e',
    environmentName: 'Akash Env',
    businessUnit: 'AkashBU',
    project: 'Akash_Project',
    application: 'Akash_Application',
    purpose: 'Regression test execution',
    team: 'QA Guild',
    requestedBy: 'System Admin',
    startDate: '2026-09-04T12:00:00',
    endDate: '2026-09-05T12:00:00',
    status: 'AUTO_REJECTED',
    reservationMode: 'SHARED',
    ownerId: 'user-1788331',
    createdBy: 'akash',
    priority: 'MEDIUM',
    auditHistory: []
  },
  {
    id: '894e6695-68ba-4ba6-8de3-39d081c0dfe2',
    environmentId: '0dfaa9d2-322b-48ed-b051-a844507372b2',
    environmentName: 'Akn_Env_12_aug',
    businessUnit: 'Ash_BU1',
    project: 'AshProject1',
    application: 'AshApp',
    purpose: 'Testing',
    team: 'SQE',
    requestedBy: 'System Admin',
    startDate: '2026-09-04T00:00:00',
    endDate: '2026-09-07T00:00:00',
    status: 'AUTO_REJECTED',
    reservationMode: 'DISRUPTIVE',
    ownerId: 'user-1788331',
    createdBy: 'akash',
    priority: 'MEDIUM',
    auditHistory: []
  }
];

export const INITIAL_RUNBOOKS: Runbook[] = [];

export const INITIAL_METRICS: OverviewMetrics = {
  totalEnvironments: 0,
  healthyEnvironments: 0,
  activeBookings: 0,
  utilizationRate: 0,
  openIncidents: 0,
  downEnvironmentsCount: 0,
  upcomingReleases: 0,
  trackedReleasesCount: 0,
  cpuAverage: 0,
  memoryAverage: 0,
  storageAverage: 0,
};
