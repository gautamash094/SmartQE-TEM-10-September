import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useTEM } from '../context/TEMContext';
import { userService, User, UserCreatePayload, UserUpdatePayload } from '../services/userService';
import { roleService, Role } from '../services/roleService';
import { portfolioService, BusinessUnit } from '../services/portfolioService';
import { authService } from '../services/authService';
import {
  Users,
  UserPlus,
  Shield,
  Briefcase,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Edit2,
  Trash2,
  Plus,
  X,
  Lock,
  ChevronDown,
  Info,
  Calendar,
  User as UserIcon,
  Sparkles,
  RefreshCw,
  AlertTriangle,
  KeyRound,
  Eye,
  EyeOff,
} from 'lucide-react';
import { ButtonLoader } from '../components/common/ButtonLoader';
import { TableSkeleton } from '../components/common/Skeleton';

export const UserManagementPage: React.FC = () => {
  const { showToast } = useTEM();

  const [users, setUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>('ALL');
  const [selectedBUFilter, setSelectedBUFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [page, setPage] = useState<number>(1);
  const pageSize = 10;

  // Add / Edit Modal State
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isSavingUser, setIsSavingUser] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');

  // Form State
  const [firstName, setFirstName] = useState<string>('');
  const [lastName, setLastName] = useState<string>('');
  const [username, setUsername] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [selectedRoleIds, setSelectedRoleIds] = useState<string[]>([]);
  const [selectedBUId, setSelectedBUId] = useState<string>('');
  const [isActive, setIsActive] = useState<boolean>(true);
  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);

  // Admin Reset Password Modal State
  const [adminResetUser, setAdminResetUser] = useState<User | null>(null);
  const [adminNewPassword, setAdminNewPassword] = useState<string>('');
  const [adminConfirmNewPassword, setAdminConfirmNewPassword] = useState<string>('');
  const [showAdminNewPassword, setShowAdminNewPassword] = useState<boolean>(false);
  const [showAdminConfirmNewPassword, setShowAdminConfirmNewPassword] = useState<boolean>(false);
  const [isAdminResetLoading, setIsAdminResetLoading] = useState<boolean>(false);
  const [adminResetError, setAdminResetError] = useState<string>('');

  // Role Dropdown Open inside Modal
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState<boolean>(false);
  const roleDropdownRef = useRef<HTMLDivElement>(null);

  // Delete Modal State
  const [deleteConfirmUser, setDeleteConfirmUser] = useState<User | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Load Data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [fetchedUsers, fetchedRoles, fetchedBUs] = await Promise.all([
        userService.getUsers(),
        roleService.getRoles(),
        portfolioService.getBusinessUnits(),
      ]);

      setUsers(fetchedUsers);
      setRoles(fetchedRoles.filter((r) => r.isActive));
      setBusinessUnits(fetchedBUs.filter((b) => b.isActive));
    } catch (err: any) {
      showToast(err.message || 'Failed to load user management data', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Close role multi-select dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (roleDropdownRef.current && !roleDropdownRef.current.contains(event.target as Node)) {
        setIsRoleDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Open Add Modal
  const handleOpenAddModal = () => {
    setEditingUser(null);
    setFirstName('');
    setLastName('');
    setUsername('');
    setEmail('');
    // Default to first active role if available
    setSelectedRoleIds(roles.length > 0 ? [roles[0].id] : []);
    setSelectedBUId('');
    setIsActive(true);
    setPassword('');
    setConfirmPassword('');
    setShowPassword(false);
    setShowConfirmPassword(false);
    setFormError('');
    setIsRoleDropdownOpen(false);
    setModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (user: User) => {
    setEditingUser(user);
    setFirstName(user.firstName);
    setLastName(user.lastName);
    setUsername(user.username);
    setEmail(user.email);
    setSelectedRoleIds(user.roles.map((r) => r.id));
    setSelectedBUId(user.businessUnitId || '');
    setIsActive(user.isActive);
    setPassword('');
    setConfirmPassword('');
    setFormError('');
    setIsRoleDropdownOpen(false);
    setModalOpen(true);
  };

  // Open Admin Reset Password Modal
  const handleOpenAdminReset = (user: User) => {
    setAdminResetUser(user);
    setAdminNewPassword('');
    setAdminConfirmNewPassword('');
    setShowAdminNewPassword(false);
    setShowAdminConfirmNewPassword(false);
    setAdminResetError('');
    setIsAdminResetLoading(false);
  };

  const handleAdminResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminResetUser) return;
    setAdminResetError('');

    if (!adminNewPassword) {
      setAdminResetError('New password cannot be empty.');
      return;
    }

    if (adminNewPassword !== adminConfirmNewPassword) {
      setAdminResetError('Password and Confirm Password do not match.');
      return;
    }

    setIsAdminResetLoading(true);
    try {
      await authService.adminResetPassword(adminResetUser.id, adminNewPassword);
      await loadData();
      showToast(`Password for user "${adminResetUser.fullName}" reset successfully!`, 'success');
      setAdminResetUser(null);
    } catch (err: any) {
      setAdminResetError(err.message || 'Failed to reset password.');
    } finally {
      setIsAdminResetLoading(false);
    }
  };

  // Toggle Role in Multi-Select
  const handleToggleRole = (roleId: string) => {
    if (selectedRoleIds.includes(roleId)) {
      if (selectedRoleIds.length === 1) {
        setFormError('At least one role must be assigned to the user.');
        return;
      }
      setSelectedRoleIds(selectedRoleIds.filter((id) => id !== roleId));
    } else {
      setSelectedRoleIds([...selectedRoleIds, roleId]);
    }
    setFormError('');
  };

  // Remove Role Tag
  const handleRemoveRoleTag = (roleId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedRoleIds.length === 1) {
      setFormError('At least one role must be assigned to the user.');
      return;
    }
    setSelectedRoleIds(selectedRoleIds.filter((id) => id !== roleId));
  };

  // Save / Update User
  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const trimmedFirst = firstName.trim();
    const trimmedLast = lastName.trim();
    const trimmedUsername = username.trim();
    const trimmedEmail = email.trim();

    if (!trimmedFirst) {
      setFormError('First Name cannot be empty or contain only whitespace.');
      return;
    }

    if (!trimmedLast) {
      setFormError('Last Name cannot be empty or contain only whitespace.');
      return;
    }

    if (!editingUser) {
      if (!trimmedUsername) {
        setFormError('Username cannot be empty or contain only whitespace.');
        return;
      }

      if (!trimmedEmail) {
        setFormError('Email cannot be empty or contain only whitespace.');
        return;
      }

      // Email Format Check
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(trimmedEmail)) {
        setFormError('Please enter a valid email address (e.g. user@company.com).');
        return;
      }

      if (!password.trim()) {
        setFormError('Password cannot be empty.');
        return;
      }

      if (password !== confirmPassword) {
        setFormError('Password and Confirm Password do not match.');
        return;
      }
    }

    if (selectedRoleIds.length === 0) {
      setFormError('Please assign at least one active role.');
      return;
    }

    const isAssigningSuperAdmin = selectedRoleIds.some((id) => {
      const roleObj = roles.find((r) => r.id === id);
      return roleObj?.name.toLowerCase().trim() === 'super admin';
    });

    if (isAssigningSuperAdmin && isActive) {
      const hasOtherActiveSuperAdmin = users.some(
        (u) =>
          (editingUser ? u.id !== editingUser.id : true) &&
          u.isActive &&
          u.roles.some((r) => r.name.toLowerCase().trim() === 'super admin')
      );
      if (hasOtherActiveSuperAdmin) {
        setFormError('A Super Admin already exists. Only one active Super Admin user is allowed in the system.');
        return;
      }
    }

    setIsSavingUser(true);
    try {
      if (editingUser) {
        const updatePayload: UserUpdatePayload = {
          firstName: trimmedFirst,
          lastName: trimmedLast,
          roleIds: selectedRoleIds,
          businessUnitId: selectedBUId || undefined,
          isActive,
          status: isActive ? 'ACTIVE' : 'INACTIVE',
        };

        const updated = await userService.updateUser(editingUser.id, updatePayload);
        setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
        showToast(`User "${updated.fullName}" updated successfully.`, 'success');
      } else {
        const createPayload: UserCreatePayload = {
          firstName: trimmedFirst,
          lastName: trimmedLast,
          username: trimmedUsername,
          email: trimmedEmail,
          password: password.trim(),
          roleIds: selectedRoleIds,
          businessUnitId: selectedBUId || undefined,
          isActive,
        };

        const created = await userService.createUser(createPayload);
        setUsers((prev) => [created, ...prev]);
        showToast(`User "${created.fullName}" created successfully.`, 'success');
      }
      setModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to save user.');
    } finally {
      setIsSavingUser(false);
    }
  };

  // Toggle User Status
  const handleToggleStatus = async (user: User) => {
    try {
      const updated = await userService.toggleUserStatus(user.id);
      setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
      showToast(`User "${user.fullName}" is now ${updated.isActive ? 'Active' : 'Inactive'}.`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle status.', 'error');
    }
  };

  // Delete User Confirmation
  const handleDeleteUser = async () => {
    if (!deleteConfirmUser) return;
    setIsDeleting(true);
    try {
      await userService.deleteUser(deleteConfirmUser.id);
      setUsers((prev) => prev.filter((u) => u.id !== deleteConfirmUser.id));
      showToast(`User "${deleteConfirmUser.fullName}" deleted successfully.`, 'success');
      setDeleteConfirmUser(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to delete user.', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Filtered Users
  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        user.fullName.toLowerCase().includes(q) ||
        user.username.toLowerCase().includes(q) ||
        user.email.toLowerCase().includes(q) ||
        user.roles.some((r) => r.name.toLowerCase().includes(q)) ||
        (user.businessUnit && user.businessUnit.name.toLowerCase().includes(q));

      const matchesRole =
        selectedRoleFilter === 'ALL' || user.roles.some((r) => r.id === selectedRoleFilter);

      const matchesBU =
        selectedBUFilter === 'ALL' || user.businessUnitId === selectedBUFilter;

      const matchesStatus =
        selectedStatusFilter === 'ALL' ||
        (selectedStatusFilter === 'ACTIVE' && user.isActive) ||
        (selectedStatusFilter === 'INACTIVE' && !user.isActive);

      return matchesSearch && matchesRole && matchesBU && matchesStatus;
    });
  }, [users, searchQuery, selectedRoleFilter, selectedBUFilter, selectedStatusFilter]);

  // Pagination
  const totalPages = Math.ceil(filteredUsers.length / pageSize) || 1;
  const paginatedUsers = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredUsers.slice(start, start + pageSize);
  }, [filteredUsers, page]);

  // KPI Metrics
  const activeCount = users.filter((u) => u.isActive).length;
  const inactiveCount = users.filter((u) => !u.isActive).length;
  const multiRoleCount = users.filter((u) => u.roles.length > 1).length;

  return (
    <div className="space-y-6">
      {/* 1. HEADER & ACTION BUTTON */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            SETTINGS &bull; ACCESS CONTROL
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1 flex items-center gap-3">
            <span>User Management</span>
            <span className="text-xs font-mono font-normal bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 border border-orange-300 dark:border-orange-800/80 px-2.5 py-0.5 rounded-full">
              {users.length} Users
            </span>
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
            Create, configure, and manage user accounts with multi-role assignments, optional Business Unit affiliations, and full audit traceability.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadData}
            className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f1724] text-slate-600 dark:text-slate-400 hover:text-orange-500 transition-colors shadow-sm"
            title="Refresh Users"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-500' : ''}`} />
          </button>

          <button
            onClick={handleOpenAddModal}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_16px_rgba(249,115,22,0.4)] cursor-pointer"
          >
            <UserPlus className="w-4 h-4" /> ADD USER
          </button>
        </div>
      </div>

      {/* 2. KPI METRICS CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400 uppercase font-semibold">
              Total Users
            </span>
            <Users className="w-4 h-4 text-orange-500" />
          </div>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-2 font-mono">
            {users.length}
          </p>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 block">
            Registered in TEM
          </span>
        </div>

        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400 uppercase font-semibold">
              Active Users
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-2 font-mono">
            {activeCount}
          </p>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 block">
            Authorized to log in
          </span>
        </div>

        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-rose-500 uppercase font-semibold">
              Inactive Users
            </span>
            <XCircle className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-black text-rose-500 mt-2 font-mono">
            {inactiveCount}
          </p>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 block">
            Deactivated accounts
          </span>
        </div>

        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-amber-500 uppercase font-semibold">
              Multi-Role Users
            </span>
            <Shield className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-black text-amber-500 mt-2 font-mono">
            {multiRoleCount}
          </p>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 block">
            &gt;1 assigned role
          </span>
        </div>
      </div>

      {/* 3. FILTERS & SEARCH BAR */}
      <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 shadow-sm flex flex-col md:flex-row items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input autoComplete="off" data-lpignore="true"
            type="text"
            placeholder="Search by name, username, email, or role..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setPage(1);
            }}
            className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500"
          />
        </div>

        {/* Role Filter */}
        <div className="w-full md:w-48">
          <select
            value={selectedRoleFilter}
            onChange={(e) => {
              setSelectedRoleFilter(e.target.value);
              setPage(1);
            }}
            className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
          >
            <option value="ALL">All Roles</option>
            {roles.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
        </div>

        {/* BU Filter */}
        <div className="w-full md:w-48">
          <select
            value={selectedBUFilter}
            onChange={(e) => {
              setSelectedBUFilter(e.target.value);
              setPage(1);
            }}
            className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
          >
            <option value="ALL">All Business Units</option>
            {businessUnits.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.code})
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div className="w-full md:w-36">
          <select
            value={selectedStatusFilter}
            onChange={(e) => {
              setSelectedStatusFilter(e.target.value);
              setPage(1);
            }}
            className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="INACTIVE">Inactive</option>
          </select>
        </div>
      </div>

      {/* 4. USERS TABLE */}
      <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800/80 text-[10px] font-mono uppercase tracking-wider text-slate-500 dark:text-slate-400">
                <th className="py-3.5 px-4 font-semibold">User Details</th>
                <th className="py-3.5 px-4 font-semibold">Username & Email</th>
                <th className="py-3.5 px-4 font-semibold">Assigned Roles</th>
                <th className="py-3.5 px-4 font-semibold">Business Unit</th>
                <th className="py-3.5 px-4 font-semibold w-36">Status</th>
                <th className="py-3.5 px-4 font-semibold min-w-[210px]">Audit Tracking</th>
                <th className="py-3.5 px-4 font-semibold text-right w-24">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 font-sans">
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="p-4">
                    <TableSkeleton rows={5} columns={7} />
                  </td>
                </tr>
              ) : paginatedUsers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Users className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600 mb-2" />
                    <p className="font-semibold text-sm text-slate-600 dark:text-slate-300">
                      No users match the search criteria.
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      Try clearing filters or click &quot;Add User&quot; to create a new user.
                    </p>
                  </td>
                </tr>
              ) : (
                paginatedUsers.map((user) => {
                  const initials = `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || 'U';

                  return (
                    <tr
                      key={user.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/30 transition-colors group"
                    >
                      {/* Name & Avatar */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-white font-mono font-bold text-xs shadow-sm shrink-0">
                            {initials}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white block text-sm">
                              {user.fullName}
                            </span>
                            <span className="text-[11px] font-mono text-slate-400">
                              ID: {user.id.substring(0, 12)}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Username & Email */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5">
                          <span className="font-mono text-xs font-semibold text-slate-900 dark:text-slate-200 block">
                            @{user.username}
                          </span>
                          <span className="text-xs text-slate-500 dark:text-slate-400 block truncate max-w-[200px]">
                            {user.email}
                          </span>
                        </div>
                      </td>

                      {/* Roles */}
                      <td className="py-3.5 px-4">
                        <div className="flex flex-wrap gap-1.5 max-w-xs">
                          {user.roles.map((r) => (
                            <span
                              key={r.id}
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-mono font-semibold border ${
                                r.isSystem
                                  ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-300 dark:border-amber-800/80'
                                  : 'bg-orange-50 dark:bg-orange-950/30 text-orange-700 dark:text-orange-300 border-orange-200 dark:border-orange-800/60'
                              }`}
                            >
                              <Shield className="w-3 h-3" />
                              {r.name}
                            </span>
                          ))}
                        </div>
                      </td>

                      {/* BU */}
                      <td className="py-3.5 px-4">
                        {user.businessUnit ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono font-medium bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700/80">
                            <Briefcase className="w-3 h-3 text-slate-400" />
                            {user.businessUnit.name}
                          </span>
                        ) : (
                          <span className="text-slate-400 dark:text-slate-500 font-mono text-xs italic">
                            — None —
                          </span>
                        )}
                      </td>

                      {/* Status Toggle */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2.5">
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(user)}
                            className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                              user.isActive ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                            }`}
                            title={`Click to set ${user.isActive ? 'Inactive' : 'Active'}`}
                          >
                            <span
                              className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                                user.isActive ? 'translate-x-4' : 'translate-x-0'
                              }`}
                            />
                          </button>
                          <span
                            className={`text-[11px] font-mono font-bold uppercase tracking-wider ${
                              user.isActive
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : 'text-slate-400 dark:text-slate-500'
                            }`}
                          >
                            {user.status}
                          </span>
                        </div>
                      </td>

                      {/* Audit Details */}
                      <td className="py-3.5 px-4 whitespace-nowrap min-w-[210px]">
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 space-y-1">
                          <div className="flex items-center gap-1.5" title={`Created on ${user.createdAt} by ${user.createdBy}`}>
                            <span className="text-slate-400 font-semibold">Created:</span>
                            <span className="text-slate-700 dark:text-slate-200 font-medium">
                              {user.createdAt.substring(0, 10)}
                            </span>
                            <span className="text-slate-400">by {user.createdBy}</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-[10px]" title={`Last modified on ${user.updatedAt} by ${user.updatedBy}`}>
                            <span className="text-slate-400 font-semibold">Mod:</span>
                            <span className="text-slate-600 dark:text-slate-300">
                              {user.updatedAt.substring(0, 10)}
                            </span>
                            <span className="text-slate-400">by {user.updatedBy}</span>
                          </div>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenAdminReset(user)}
                            className="p-1.5 rounded text-slate-400 hover:text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors cursor-pointer"
                            title="Reset User Password"
                          >
                            <KeyRound className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleOpenEditModal(user)}
                            className="p-1.5 rounded text-slate-400 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-orange-50 dark:hover:bg-orange-950/40 transition-colors cursor-pointer"
                            title="Edit User"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmUser(user)}
                            className="p-1.5 rounded text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title="Delete User"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-500">
              Showing {(page - 1) * pageSize + 1} to {Math.min(page * pageSize, filteredUsers.length)} of{' '}
              {filteredUsers.length} users
            </span>
            <div className="flex items-center gap-2">
              <button
                disabled={page === 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="px-3 py-1 text-xs font-mono rounded border border-slate-300 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                PREV
              </button>
              <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                {page} / {totalPages}
              </span>
              <button
                disabled={page === totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="px-3 py-1 text-xs font-mono rounded border border-slate-300 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                NEXT
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 5. ADD / EDIT USER MODAL */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-orange-100 dark:bg-orange-950/60 border border-orange-300 dark:border-orange-800/80 flex items-center justify-center text-orange-600 dark:text-orange-400 shadow-sm">
                  {editingUser ? <Edit2 className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                    {editingUser ? 'Edit User Account' : 'Add New User'}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {editingUser
                      ? 'Update name, assigned roles, and business unit affiliation.'
                      : 'Configure credentials, roles, and business unit association for the user.'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Error Banner */}
            {formError && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800/80 rounded-lg text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSaveUser} autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" data-form-type="other" className="space-y-4">
              {/* First & Last Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    FIRST NAME <span className="text-orange-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    autoComplete="off"
                    autoCorrect="off"
                    autoCapitalize="off"
                    spellCheck={false}
                    data-lpignore="true"
                    data-form-type="other"
                    name="user_first_name_no_autofill"
                    placeholder="e.g. John"
                    value={firstName}
                    onChange={(e) => {
                      setFirstName(e.target.value);
                      setFormError('');
                    }}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    LAST NAME <span className="text-orange-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    autoComplete="off"
                    autoCorrect="off"
                    autoCapitalize="off"
                    spellCheck={false}
                    data-lpignore="true"
                    data-form-type="other"
                    name="user_last_name_no_autofill"
                    placeholder="e.g. Smith"
                    value={lastName}
                    onChange={(e) => {
                      setLastName(e.target.value);
                      setFormError('');
                    }}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              {/* Username & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                    <span>
                      USERNAME <span className="text-orange-500">*</span>
                    </span>
                    {editingUser && (
                      <span className="text-[10px] font-mono text-amber-500 flex items-center gap-1">
                        <Lock className="w-3 h-3" /> Non-editable
                      </span>
                    )}
                  </label>
                  <input
                    type="text"
                    required
                    autoComplete="off"
                    autoCorrect="off"
                    autoCapitalize="off"
                    spellCheck={false}
                    data-lpignore="true"
                    data-form-type="other"
                    name="user_username_no_autofill"
                    disabled={!!editingUser}
                    placeholder="e.g. john.smith"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      setFormError('');
                    }}
                    className={`w-full border rounded-lg px-3.5 py-2 text-sm font-mono focus:outline-none ${
                      editingUser
                        ? 'bg-slate-100 dark:bg-slate-800/80 border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 cursor-not-allowed'
                        : 'bg-slate-50 dark:bg-[#161f2e] border-slate-300 dark:border-slate-700/80 text-slate-900 dark:text-white focus:ring-2 focus:ring-orange-500'
                    }`}
                  />
                  {editingUser && (
                    <p className="text-[10px] font-mono text-slate-500 mt-1">
                      Username is permanently bound to this user identity.
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                    <span>
                      EMAIL ADDRESS <span className="text-orange-500">*</span>
                    </span>
                    {editingUser && (
                      <span className="text-[10px] font-mono text-amber-500 flex items-center gap-1">
                        <Lock className="w-3 h-3" /> Non-editable
                      </span>
                    )}
                  </label>
                  <input
                    type="email"
                    required
                    autoComplete="off"
                    autoCorrect="off"
                    autoCapitalize="off"
                    spellCheck={false}
                    data-lpignore="true"
                    data-form-type="other"
                    name="user_email_no_autofill"
                    disabled={!!editingUser}
                    placeholder="e.g. john.smith@company.com"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setFormError('');
                    }}
                    className={`w-full border rounded-lg px-3.5 py-2 text-sm font-mono focus:outline-none ${
                      editingUser
                        ? 'bg-slate-100 dark:bg-slate-800/80 border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 cursor-not-allowed'
                        : 'bg-slate-50 dark:bg-[#161f2e] border-slate-300 dark:border-slate-700/80 text-slate-900 dark:text-white focus:ring-2 focus:ring-orange-500'
                    }`}
                  />
                  {editingUser && (
                    <p className="text-[10px] font-mono text-slate-500 mt-1">
                      Email address cannot be changed after initial registration.
                    </p>
                  )}
                </div>
              </div>

              {/* Role Multi-Select Dropdown */}
              <div className="relative" ref={roleDropdownRef}>
                <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                  <span>
                    ASSIGNED ROLE(S) <span className="text-orange-500">*</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">Multi-select enabled</span>
                </label>

                {/* Selected Roles Box (Clickable Trigger) */}
                <div
                  onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
                  className="min-h-[42px] w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg p-1.5 flex flex-wrap items-center gap-1.5 cursor-pointer hover:border-orange-500 transition-colors"
                >
                  {selectedRoleIds.length === 0 ? (
                    <span className="text-xs text-slate-400 px-2 py-1 font-mono">
                      Select one or more roles...
                    </span>
                  ) : (
                    selectedRoleIds.map((roleId) => {
                      const roleObj = roles.find((r) => r.id === roleId);
                      if (!roleObj) return null;
                      return (
                        <span
                          key={roleId}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-mono font-semibold bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300 border border-orange-300 dark:border-orange-800/80 shadow-sm"
                        >
                          <Shield className="w-3 h-3" />
                          {roleObj.name}
                          <button
                            type="button"
                            onClick={(e) => handleRemoveRoleTag(roleId, e)}
                            className="hover:text-rose-600 dark:hover:text-rose-400 p-0.5"
                            title={`Remove ${roleObj.name}`}
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      );
                    })
                  )}
                  <div className="ml-auto pr-2 text-slate-400">
                    <ChevronDown className={`w-4 h-4 transition-transform ${isRoleDropdownOpen ? 'rotate-180' : ''}`} />
                  </div>
                </div>

                {/* Dropdown Options */}
                {isRoleDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 z-30 mt-1 bg-white dark:bg-[#121b2d] border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl p-2 max-h-48 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                    {roles.map((r) => {
                      const isSelected = selectedRoleIds.includes(r.id);
                      return (
                        <div
                          key={r.id}
                          onClick={() => handleToggleRole(r.id)}
                          className={`flex items-center justify-between p-2.5 rounded-lg cursor-pointer transition-colors ${
                            isSelected
                              ? 'bg-orange-50 dark:bg-orange-950/30 text-orange-600 dark:text-orange-400 font-bold'
                              : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}}
                              className="accent-orange-500 rounded cursor-pointer"
                            />
                            <div>
                              <span className="text-xs font-mono block">{r.name}</span>
                              {r.description && (
                                <span className="text-[10px] text-slate-400 font-sans block truncate max-w-sm">
                                  {r.description}
                                </span>
                              )}
                            </div>
                          </div>
                          {r.isSystem && (
                            <span className="text-[9px] font-mono uppercase bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 px-1.5 py-0.5 rounded border border-amber-300 dark:border-amber-800/80">
                              System
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* BU Single-Select (Optional) */}
              <div>
                <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                  <span>BUSINESS UNIT (BU)</span>
                  <span className="text-[10px] font-mono text-slate-500 italic">Optional field</span>
                </label>
                <select
                  value={selectedBUId}
                  onChange={(e) => setSelectedBUId(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">— No Business Unit Assigned —</option>
                  {businessUnits.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.code})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] font-mono text-slate-500 mt-1">
                  Reuses active Business Units dynamically from Entity Management.
                </p>
              </div>

              {/* Password & Confirm Password for New User */}
              {!editingUser && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                      PASSWORD <span className="text-orange-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        autoComplete="new-password"
                        data-lpignore="true"
                        data-form-type="other"
                        value={password}
                        onChange={(e) => {
                          setPassword(e.target.value);
                          setFormError('');
                        }}
                        placeholder="Enter password"
                        className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                      CONFIRM PASSWORD <span className="text-orange-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showConfirmPassword ? 'text' : 'password'}
                        required
                        autoComplete="new-password"
                        data-lpignore="true"
                        data-form-type="other"
                        value={confirmPassword}
                        onChange={(e) => {
                          setConfirmPassword(e.target.value);
                          setFormError('');
                        }}
                        placeholder="Confirm password"
                        className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* When Editing User: Password Management Option */}
              {editingUser && (
                <div className="p-3.5 bg-slate-50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 uppercase">
                      SECURITY & CREDENTIALS
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      Need to reset this user&apos;s login password?
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setModalOpen(false);
                      handleOpenAdminReset(editingUser);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800/80 hover:bg-amber-100 dark:hover:bg-amber-900/60 transition-colors cursor-pointer"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    Reset Password
                  </button>
                </div>
              )}

              {/* Status Toggle */}
              <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-xs font-bold text-slate-900 dark:text-white block">
                    Account Status: {isActive ? 'ACTIVE' : 'INACTIVE'}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Active users can authenticate and access authorized modules.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="w-5 h-5 accent-orange-500 rounded cursor-pointer"
                />
              </div>

              {/* Audit Card in Edit Mode */}
              {editingUser && (
                <div className="p-3.5 bg-slate-100 dark:bg-[#121b2d] border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400 block">
                    Audit Tracking Information
                  </span>
                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <div>
                      <span className="text-slate-400 block text-[10px]">CREATED</span>
                      <span className="text-slate-700 dark:text-slate-200 block">{editingUser.createdAt}</span>
                      <span className="text-slate-500 block text-[11px]">by {editingUser.createdBy}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">LAST MODIFIED</span>
                      <span className="text-slate-700 dark:text-slate-200 block">{editingUser.updatedAt}</span>
                      <span className="text-slate-500 block text-[11px]">by {editingUser.updatedBy}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-mono font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  CANCEL
                </button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingUser}
                  loadingText={editingUser ? 'SAVING CHANGES...' : 'CREATING USER...'}
                  icon={editingUser ? <Edit2 className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
                  className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 disabled:opacity-50 transition-all shadow-[0_0_12px_rgba(249,115,22,0.3)]"
                >
                  {editingUser ? 'SAVE CHANGES' : 'CREATE USER'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. DELETE CONFIRMATION MODAL */}
      {deleteConfirmUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#0f1724] border border-rose-300 dark:border-rose-900/80 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600 dark:text-rose-400">
              <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800/80 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Delete User Account</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  This action is permanent and cannot be undone.
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Are you sure you want to delete user{' '}
              <strong className="text-slate-900 dark:text-white font-mono">
                {deleteConfirmUser.fullName} (@{deleteConfirmUser.username})
              </strong>
              ? All role associations will be revoked.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmUser(null)}
                className="px-4 py-2 rounded-lg text-xs font-mono font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                CANCEL
              </button>
              <ButtonLoader
                onClick={handleDeleteUser}
                isLoading={isDeleting}
                loadingText="DELETING..."
                className="px-4 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-rose-600 hover:bg-rose-500 shadow-[0_0_12px_rgba(225,29,72,0.35)]"
              >
                CONFIRM DELETE
              </ButtonLoader>
            </div>
          </div>
        </div>
      )}

      {/* 7. ADMIN RESET PASSWORD MODAL */}
      {adminResetUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#0f1724] border border-amber-300 dark:border-amber-900/80 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800/80 flex items-center justify-center text-amber-600 dark:text-amber-400">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white font-mono uppercase">
                    Reset User Password
                  </h3>
                  <span className="text-[10px] text-slate-400 font-mono">
                    For {adminResetUser.fullName} (@{adminResetUser.username})
                  </span>
                </div>
              </div>
              <button
                onClick={() => setAdminResetUser(null)}
                className="p-1 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {adminResetError && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 rounded-lg text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
                <span>{adminResetError}</span>
              </div>
            )}

            <form
              onSubmit={handleAdminResetSubmit}
              className="space-y-4"
              autoComplete="off"
              autoCorrect="off"
              autoCapitalize="off"
              spellCheck={false}
              data-lpignore="true"
              data-form-type="other"
            >
              <div>
                <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  NEW PASSWORD <span className="text-orange-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showAdminNewPassword ? 'text' : 'password'}
                    required
                    name="admin_new_password_no_autofill"
                    autoComplete="new-password"
                    autoCorrect="off"
                    autoCapitalize="off"
                    spellCheck={false}
                    data-lpignore="true"
                    data-form-type="other"
                    value={adminNewPassword}
                    onChange={(e) => {
                      setAdminNewPassword(e.target.value);
                      setAdminResetError('');
                    }}
                    placeholder="Enter new password"
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminNewPassword(!showAdminNewPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    {showAdminNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                  CONFIRM PASSWORD <span className="text-orange-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showAdminConfirmNewPassword ? 'text' : 'password'}
                    required
                    name="admin_confirm_password_no_autofill"
                    autoComplete="new-password"
                    autoCorrect="off"
                    autoCapitalize="off"
                    spellCheck={false}
                    data-lpignore="true"
                    data-form-type="other"
                    value={adminConfirmNewPassword}
                    onChange={(e) => {
                      setAdminConfirmNewPassword(e.target.value);
                      setAdminResetError('');
                    }}
                    placeholder="Confirm new password"
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminConfirmNewPassword(!showAdminConfirmNewPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    {showAdminConfirmNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setAdminResetUser(null)}
                  className="px-4 py-2 rounded-lg text-xs font-mono font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  CANCEL
                </button>
                <ButtonLoader
                  type="submit"
                  isLoading={isAdminResetLoading}
                  loadingText="RESETTING..."
                  icon={<KeyRound className="w-3.5 h-3.5" />}
                  className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-amber-600 hover:bg-amber-500 shadow-[0_0_12px_rgba(217,119,6,0.35)]"
                >
                  SET NEW PASSWORD
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
