import React, { useState } from 'react';
import { useTEM } from '../context/TEMContext';
import {
  IntegrationConfig,
  IntegrationProvider,
  IntegrationLogEntry,
  CICDPipelineEventPayload,
  ITSMTicketSyncPayload,
  FieldMappingRule,
  StatusMappingRule,
  EnvironmentMappingRule
} from '../types/integrations';
import {
  Webhook,
  RefreshCw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Play,
  Settings,
  Activity,
  ArrowRightLeft,
  Search,
  Copy,
  ExternalLink,
  Shield,
  Layers,
  Terminal,
  Cpu,
  RotateCw,
  Code
} from 'lucide-react';
import { Pagination } from '../components/common/Pagination';
import { TableSkeleton } from '../components/common/Skeleton';
import { ButtonLoader } from '../components/common/ButtonLoader';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const ExternalIntegrationsPage: React.FC = () => {
  const {
    integrationConfigs,
    integrationLogs,
    integrationHealth,
    environmentProfiles,
    incidents,
    updateIntegrationConfig,
    testIntegrationConnection,
    simulateCICDEvent,
    syncITSMTicket,
    reconcileIntegrations,
    clearIntegrationLogs,
    isLoading
  } = useTEM();

  const [activeTab, setActiveTab] = useState<'overview' | 'logs' | 'mappings'>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [providerFilter, setProviderFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [testingProvider, setTestingProvider] = useState<IntegrationProvider | null>(null);
  const [isReconciling, setIsReconciling] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);

  // Pagination for logs
  const [logPage, setLogPage] = useState(1);
  const [logPageSize, setLogPageSize] = useState(10);

  // Modal States
  const [configModalConfig, setConfigModalConfig] = useState<IntegrationConfig | null>(null);
  const [testLogModal, setTestLogModal] = useState<IntegrationLogEntry | null>(null);
  const [simulatorProvider, setSimulatorProvider] = useState<IntegrationProvider | null>(null);

  // Simulator Form States
  const [simITSM, setSimITSM] = useState<{
    externalKey: string;
    title: string;
    priority: string;
    status: string;
    temIncidentId: string;
  }>({
    externalKey: '',
    title: '',
    priority: 'High',
    status: 'In Progress',
    temIncidentId: '',
  });

  const [simCICD, setSimCICD] = useState<{
    pipelineName: string;
    buildNumber: string;
    eventType: 'PIPELINE_STARTED' | 'DEPLOYMENT_STARTED' | 'DEPLOYMENT_SUCCESS' | 'DEPLOYMENT_FAILED' | 'TEST_STARTED' | 'TEST_COMPLETED';
    targetEnvId: string;
  }>({
    pipelineName: '',
    buildNumber: '',
    eventType: 'DEPLOYMENT_STARTED',
    targetEnvId: environmentProfiles[0]?.id || '',
  });

  // Filtered logs
  const filteredLogs = integrationLogs.filter((log) => {
    const matchesProvider = providerFilter === 'ALL' || log.provider === providerFilter;
    const matchesStatus = statusFilter === 'ALL' || log.status === statusFilter;
    const matchesSearch =
      !searchQuery ||
      log.eventType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.externalEntityId && log.externalEntityId.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (log.temEntityId && log.temEntityId.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesProvider && matchesStatus && matchesSearch;
  });

  const totalLogPages = Math.ceil(filteredLogs.length / logPageSize) || 1;
  const paginatedLogs = filteredLogs.slice((logPage - 1) * logPageSize, logPage * logPageSize);

  const handleTestConnection = async (provider: IntegrationProvider) => {
    setTestingProvider(provider);
    try {
      await testIntegrationConnection(provider);
    } finally {
      setTestingProvider(null);
    }
  };

  const handleReconcile = async () => {
    setIsReconciling(true);
    try {
      await reconcileIntegrations();
    } finally {
      setIsReconciling(false);
    }
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (configModalConfig) {
      updateIntegrationConfig(configModalConfig.id, configModalConfig);
      setConfigModalConfig(null);
    }
  };

  const handleExecuteITSMSimulation = async () => {
    if (!simulatorProvider) return;
    setIsSimulating(true);
    try {
      await syncITSMTicket({
        provider: 'SERVICENOW',
        ticketType: 'INCIDENT',
        externalId: simITSM.externalKey,
        externalKeyOrNumber: simITSM.externalKey,
        title: simITSM.title,
        priority: simITSM.priority,
        status: simITSM.status,
        temIncidentId: simITSM.temIncidentId || undefined,
        externalUrl: `https://${simulatorProvider.toLowerCase()}.company.com/browse/${simITSM.externalKey}`,
        updatedAt: new Date().toISOString(),
      });
      setSimulatorProvider(null);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleExecuteCICDSimulation = async () => {
    if (!simulatorProvider) return;
    setIsSimulating(true);
    try {
      const targetEnv = environmentProfiles.find((e) => e.id === simCICD.targetEnvId);

      await simulateCICDEvent({
        provider: simulatorProvider as 'AZURE_DEVOPS' | 'JENKINS',
        pipelineName: simCICD.pipelineName,
        runId: `run-${Date.now()}`,
        buildNumber: simCICD.buildNumber,
        eventType: simCICD.eventType,
        targetEnvironmentIdentifier: targetEnv ? targetEnv.name : 'QA Core',
        targetEnvironmentId: simCICD.targetEnvId || targetEnv?.id,
        timestamp: new Date().toISOString(),
      });
      setSimulatorProvider(null);
    } finally {
      setIsSimulating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-6 font-mono text-xs text-slate-200">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#090d14] p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-600 to-amber-600 flex items-center justify-center text-white shadow-[0_0_20px_rgba(249,115,22,0.35)] shrink-0">
            <Webhook className="w-6 h-6 fill-current" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest">
                TOOLCHAIN INTEGRATION HUB
              </span>
              <span className="px-2 py-0.5 rounded bg-orange-950 text-orange-300 font-bold text-[10px] border border-orange-800">
                ENTERPRISE ECOSYSTEM
              </span>
            </div>
            <h1 className="text-xl font-bold text-white mt-0.5">External Toolchain Integrations</h1>
            <p className="text-xs text-slate-400 font-sans mt-1">
              Connect TEM with ServiceNow, Azure DevOps, and Jenkins for bi-directional ITSM &amp; CI/CD pipeline automation.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <ButtonLoader
            onClick={handleReconcile}
            isLoading={isReconciling}
            loadingText="RECONCILING..."
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs shadow-[0_0_15px_rgba(249,115,22,0.3)] transition-all"
          >
            <RotateCw className="w-4 h-4" /> RECONCILE NOW
          </ButtonLoader>
        </div>
      </div>

      {/* Health Metrics Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-lg flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">ACTIVE INTEGRATIONS</span>
            <div className="text-2xl font-extrabold text-white mt-1">
              {integrationHealth.connectedCount} / {integrationHealth.totalIntegrations}
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-950/80 border border-emerald-800/80 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-lg flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">24H SYNC EVENTS</span>
            <div className="text-2xl font-extrabold text-white mt-1">{integrationHealth.events24hCount}</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-blue-950/80 border border-blue-800/80 flex items-center justify-center text-blue-400">
            <Activity className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-lg flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">24H SUCCESS RATE</span>
            <div className="text-2xl font-extrabold text-emerald-400 mt-1">{integrationHealth.successRate24h}%</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-950/80 border border-emerald-800/80 flex items-center justify-center text-emerald-400">
            <Shield className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-lg flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">SYNC ENGINE</span>
            <div className="text-xs font-bold text-slate-300 mt-1 flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>NEAR-REALTIME</span>
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-orange-950/80 border border-orange-800/80 flex items-center justify-center text-orange-400">
            <ArrowRightLeft className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-2 transition-all ${
              activeTab === 'overview'
                ? 'bg-orange-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-200 dark:border-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" /> PROVIDER CONNECTORS ({integrationConfigs.length})
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-2 transition-all ${
              activeTab === 'logs'
                ? 'bg-orange-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-200 dark:border-slate-800'
            }`}
          >
            <Terminal className="w-4 h-4" /> INTEGRATION LOGS &amp; RETRY QUEUE ({integrationLogs.length})
          </button>
        </div>
      </div>

      {/* TAB 1: PROVIDER CONNECTORS */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {integrationConfigs.map((cfg) => {
            const isConnected = cfg.connectionStatus === 'CONNECTED';
            return (
              <div
                key={cfg.id}
                className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 hover:border-slate-700 p-6 rounded-xl space-y-5 relative shadow-xl transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Top Row: Icon, Provider, Status Badge */}
                  <div className="flex items-start justify-between gap-3 border-b border-slate-200 dark:border-slate-800/80 pb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-11 h-11 rounded-lg border flex items-center justify-center font-bold text-base ${
                          cfg.provider === 'SERVICENOW'
                            ? 'bg-emerald-950/80 border-emerald-800 text-emerald-400'
                            : cfg.provider === 'AZURE_DEVOPS'
                            ? 'bg-sky-950/80 border-sky-800 text-sky-400'
                            : 'bg-amber-950/80 border-amber-800 text-amber-400'
                        }`}
                      >
                        {cfg.provider === 'SERVICENOW'
                          ? 'SN'
                          : cfg.provider === 'AZURE_DEVOPS'
                          ? 'AD'
                          : 'JK'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold uppercase text-orange-400 tracking-wider">
                            {cfg.type} INTEGRATION
                          </span>
                          <span className="text-[9px] px-2 py-0.2 rounded bg-slate-800 text-slate-300 font-bold">
                            {cfg.syncDirection}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-white mt-0.5">{cfg.name}</h3>
                      </div>
                    </div>

                    <div className="flex flex-col items-end">
                      <span
                        className={`px-2.5 py-1 rounded text-[10px] font-bold flex items-center gap-1.5 border ${
                          isConnected
                            ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                            : 'bg-red-950 text-red-400 border-red-800'
                        }`}
                      >
                        <span
                          className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`}
                        />
                        {cfg.connectionStatus}
                      </span>
                      <span className="text-[9px] text-slate-500 mt-1 font-mono">
                        Last Sync: {cfg.lastSuccessfulSync ? new Date(cfg.lastSuccessfulSync).toLocaleTimeString() : 'Never'}
                      </span>
                    </div>
                  </div>

                  {/* Details & Specs */}
                  <div className="space-y-3 pt-3 text-xs">
                    <div className="grid grid-cols-2 gap-2 bg-black/40 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
                      <div>
                        <span className="text-slate-500 text-[9px] uppercase block">INSTANCE BASE URL</span>
                        <span className="text-white font-mono text-[11px] truncate block">{cfg.baseUrl}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[9px] uppercase block">AUTHENTICATION</span>
                        <span className="text-orange-400 font-mono text-[11px] block">{cfg.authType}</span>
                      </div>
                    </div>

                    {/* Webhook Endpoint */}
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase font-bold flex items-center justify-between">
                        <span>TEM WEBHOOK LISTENER ENDPOINT</span>
                        <button
                          onClick={() => copyToClipboard(cfg.webhookUrl)}
                          className="text-orange-400 hover:text-orange-300 text-[10px] flex items-center gap-1"
                        >
                          <Copy className="w-3 h-3" /> Copy URL
                        </button>
                      </span>
                      <div className="bg-[#162032] border border-slate-700/80 rounded p-2 text-[10px] font-mono text-slate-300 truncate flex items-center justify-between">
                        <span className="truncate">{cfg.webhookUrl}</span>
                      </div>
                    </div>

                    {/* Features & Events Enabled */}
                    <div className="flex items-center gap-2 pt-1 flex-wrap">
                      <span className="text-[10px] text-slate-400 uppercase font-bold">EVENTS:</span>
                      {cfg.eventsEnabled.incidents && (
                        <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 text-[10px] border border-blue-800">
                          Incidents Sync
                        </span>
                      )}
                      {cfg.eventsEnabled.changes && (
                        <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 text-[10px] border border-purple-800">
                          Changes Sync
                        </span>
                      )}
                      {cfg.eventsEnabled.pipelines && (
                        <span className="px-2 py-0.5 rounded bg-sky-950 text-sky-300 text-[10px] border border-sky-800">
                          Pipeline Runs
                        </span>
                      )}
                      {cfg.eventsEnabled.deployments && (
                        <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] border border-emerald-800">
                          Deployments
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Bottom Action Bar */}
                <div className="flex items-center justify-between gap-2 pt-4 border-t border-slate-200 dark:border-slate-800 mt-4">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleTestConnection(cfg.provider)}
                      disabled={testingProvider === cfg.provider}
                      className={`px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 ${
                        testingProvider === cfg.provider ? 'opacity-70 cursor-wait' : ''
                      }`}
                    >
                      {testingProvider === cfg.provider ? (
                        <LoadingSpinner size="xs" variant="accent" inline />
                      ) : (
                        <RotateCw className="w-3.5 h-3.5 text-orange-400" />
                      )}
                      <span>TEST</span>
                    </button>
                    <button
                      onClick={() => setSimulatorProvider(cfg.provider)}
                      className="px-3 py-1.5 rounded bg-orange-950/80 hover:bg-orange-900 border border-orange-800 text-orange-300 text-xs font-bold flex items-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5" /> SIMULATE EVENT
                    </button>
                  </div>

                  <button
                    onClick={() => setConfigModalConfig({ ...cfg })}
                    className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5"
                  >
                    <Settings className="w-3.5 h-3.5" /> CONFIGURE
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 2: INTEGRATION LOGS & RETRY QUEUE */}
      {activeTab === 'logs' && (
        <div className="space-y-4">
          {/* Controls & Search */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search log messages, entities..."
                  className="w-full bg-[#162032] border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>

              <select
                value={providerFilter}
                onChange={(e) => setProviderFilter(e.target.value)}
                className="bg-[#162032] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="ALL">All Providers</option>
                <option value="SERVICENOW">ServiceNow</option>
                <option value="AZURE_DEVOPS">Azure DevOps</option>
                <option value="JENKINS">Jenkins</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-[#162032] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="ALL">All Statuses</option>
                <option value="SUCCESS">SUCCESS</option>
                <option value="FAILED">FAILED</option>
              </select>
            </div>

            <button
              onClick={() => clearIntegrationLogs()}
              className="px-3 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
            >
              CLEAR LOGS
            </button>
          </div>

          {/* Logs Table */}
          {isLoading ? (
            <TableSkeleton rows={logPageSize} columns={8} />
          ) : (
            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#162032] border-b border-slate-200 dark:border-slate-800 text-[10px] text-slate-400 uppercase tracking-wider font-bold">
                    <th className="p-3">TIMESTAMP</th>
                    <th className="p-3">PROVIDER</th>
                    <th className="p-3">EVENT TYPE</th>
                    <th className="p-3">DIRECTION</th>
                    <th className="p-3">EXTERNAL ID</th>
                    <th className="p-3">TEM ENTITY</th>
                    <th className="p-3">STATUS</th>
                    <th className="p-3 text-right">ACTION</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 text-xs">
                  {paginatedLogs.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500 font-sans">
                        No integration activity logs matching current filters.
                      </td>
                    </tr>
                  ) : (
                    paginatedLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-3 text-slate-400 whitespace-nowrap">{log.timestamp}</td>
                        <td className="p-3 font-bold text-orange-400 whitespace-nowrap">{log.provider}</td>
                        <td className="p-3 font-bold text-white whitespace-nowrap">{log.eventType}</td>
                        <td className="p-3 text-slate-300 whitespace-nowrap">
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px]">
                            {log.direction}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-sky-300 whitespace-nowrap">{log.externalEntityId || '—'}</td>
                        <td className="p-3 font-bold text-emerald-300 whitespace-nowrap">{log.temEntityId || '—'}</td>
                        <td className="p-3 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                              log.status === 'SUCCESS'
                                ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                                : 'bg-red-950 text-red-400 border-red-800'
                            }`}
                          >
                            {log.status}
                          </span>
                        </td>
                        <td className="p-3 text-right whitespace-nowrap">
                          <button
                            onClick={() => setTestLogModal(log)}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-bold"
                          >
                            INSPECT PAYLOAD
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-800">
              <Pagination
                currentPage={logPage}
                totalItems={filteredLogs.length}
                pageSize={logPageSize}
                onPageChange={setLogPage}
                onPageSizeChange={setLogPageSize}
              />
            </div>
          </div>
        )}
      </div>
    )}

      {/* ================= MODAL 1: NO-CODE CONFIGURATION ================= */}
      {configModalConfig && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-slate-700 rounded-xl max-w-2xl w-full font-mono text-xs relative shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-3 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => setConfigModalConfig(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>
              <span className="text-[10px] text-orange-400 uppercase font-bold">NO-CODE CONNECTOR CONFIGURATION</span>
              <h2 className="text-lg font-bold text-white mt-0.5">{configModalConfig.name}</h2>
            </div>

            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveConfig} className="flex flex-col flex-1 min-h-0">
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      INTEGRATION NAME
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={configModalConfig.name}
                      onChange={(e) => setConfigModalConfig({ ...configModalConfig, name: e.target.value })}
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      INSTANCE BASE URL
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={configModalConfig.baseUrl}
                      onChange={(e) => setConfigModalConfig({ ...configModalConfig, baseUrl: e.target.value })}
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      AUTHENTICATION TYPE
                    </label>
                    <select
                      value={configModalConfig.authType}
                      onChange={(e) => setConfigModalConfig({ ...configModalConfig, authType: e.target.value as any })}
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    >
                      <option value="OAUTH2">OAuth 2.0 Client Credentials</option>
                      <option value="API_TOKEN">API Personal Access Token</option>
                      <option value="BASIC_AUTH">Basic Authentication</option>
                      <option value="WEBHOOK_SECRET">HMAC Webhook Secret Signature</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      CONFLICT POLICY
                    </label>
                    <select
                      value={configModalConfig.conflictPolicy}
                      onChange={(e) => setConfigModalConfig({ ...configModalConfig, conflictPolicy: e.target.value as any })}
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    >
                      <option value="LAST_WRITE_WINS">Last-Write-Wins (Timestamp Comparison)</option>
                      <option value="TEM_AUTHORITATIVE">TEM is Authoritative Source of Truth</option>
                      <option value="EXTERNAL_AUTHORITATIVE">External System is Authoritative</option>
                    </select>
                  </div>
                </div>

                {/* Secret token input */}
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    API TOKEN / SECRET BEARER KEY
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="password"
                    value={configModalConfig.apiTokenOrSecret || ''}
                    onChange={(e) => setConfigModalConfig({ ...configModalConfig, apiTokenOrSecret: e.target.value })}
                    placeholder="Enter encrypted API Token or Webhook Secret Key..."
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                {/* Field Mappings Section */}
                {configModalConfig.fieldMappings.length > 0 && (
                  <div className="space-y-2 pt-2">
                    <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider block">
                      CONFIGURED FIELD MAPPINGS ({configModalConfig.fieldMappings.length})
                    </span>
                    <div className="space-y-1.5 max-h-36 overflow-y-auto bg-black/40 p-2.5 rounded border border-slate-200 dark:border-slate-800">
                      {configModalConfig.fieldMappings.map((m) => (
                        <div key={m.id} className="flex items-center justify-between text-[11px] bg-[#162032] p-2 rounded">
                          <span className="text-white font-bold">{m.temField}</span>
                          <span className="text-slate-500">↔</span>
                          <span className="text-sky-300 font-bold">{m.externalField}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Fixed Footer */}
              <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3 z-10">
                <button
                  type="button"
                  onClick={() => setConfigModalConfig(null)}
                  className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold shadow-[0_0_14px_rgba(249,115,22,0.4)]"
                >
                  SAVE CONFIGURATION
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL 2: LIVE WEBHOOK EVENT SIMULATOR ================= */}
      {simulatorProvider && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-orange-500/60 rounded-xl max-w-xl w-full font-mono text-xs relative shadow-[0_0_50px_rgba(249,115,22,0.2)] max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-3 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => setSimulatorProvider(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>
              <span className="text-[10px] text-orange-400 uppercase font-bold tracking-widest">
                LIVE WEBHOOK EVENT TESTER
              </span>
              <h2 className="text-lg font-bold text-white mt-0.5">Simulate {simulatorProvider} Payload Ingestion</h2>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* ITSM Simulator Form */}
              {simulatorProvider === 'SERVICENOW' && (
                <div className="space-y-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      EXTERNAL TICKET NUMBER / KEY
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={simITSM.externalKey}
                      onChange={(e) => setSimITSM({ ...simITSM, externalKey: e.target.value })}
                      placeholder="e.g. PROJ-924 or INC009941"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      TICKET SUMMARY / TITLE
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={simITSM.title}
                      onChange={(e) => setSimITSM({ ...simITSM, title: e.target.value })}
                      placeholder="Summary of incident..."
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        EXTERNAL STATUS
                      </label>
                      <select
                        value={simITSM.status}
                        onChange={(e) => setSimITSM({ ...simITSM, status: e.target.value })}
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white"
                      >
                        <option value="To Do">To Do / New</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Done">Done / Resolved</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        LINK TO TEM INCIDENT
                      </label>
                      <select
                        value={simITSM.temIncidentId}
                        onChange={(e) => setSimITSM({ ...simITSM, temIncidentId: e.target.value })}
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white"
                      >
                        <option value="">Create / Link Automatic</option>
                        {incidents.map((i) => (
                          <option key={i.id} value={i.id}>
                            {i.id} - {i.title.substring(0, 24)}...
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* CI/CD Simulator Form */}
              {(simulatorProvider === 'AZURE_DEVOPS' || simulatorProvider === 'JENKINS') && (
                <div className="space-y-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      PIPELINE / JOB NAME
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={simCICD.pipelineName}
                      onChange={(e) => setSimCICD({ ...simCICD, pipelineName: e.target.value })}
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        PIPELINE EVENT TYPE
                      </label>
                      <select
                        value={simCICD.eventType}
                        onChange={(e) => setSimCICD({ ...simCICD, eventType: e.target.value as any })}
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white"
                      >
                        <option value="DEPLOYMENT_STARTED">DEPLOYMENT_STARTED → MAINTENANCE</option>
                        <option value="DEPLOYMENT_SUCCESS">DEPLOYMENT_SUCCESS → HEALTHY</option>
                        <option value="DEPLOYMENT_FAILED">DEPLOYMENT_FAILED → DOWN</option>
                        <option value="TEST_STARTED">TEST_STARTED → DEGRADED</option>
                        <option value="TEST_COMPLETED">TEST_COMPLETED → HEALTHY</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        TARGET TEM ENVIRONMENT
                      </label>
                      <select
                        value={simCICD.targetEnvId}
                        onChange={(e) => setSimCICD({ ...simCICD, targetEnvId: e.target.value })}
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white"
                      >
                        {environmentProfiles.map((env) => (
                          <option key={env.id} value={env.id}>
                            {env.name} ({env.type})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Fixed Footer */}
            <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3 z-10">
              <button
                type="button"
                onClick={() => setSimulatorProvider(null)}
                disabled={isSimulating}
                className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold disabled:opacity-50"
              >
                CANCEL
              </button>
              <ButtonLoader
                type="button"
                isLoading={isSimulating}
                loadingText="INGESTING..."
                onClick={
                  simulatorProvider === 'SERVICENOW'
                    ? handleExecuteITSMSimulation
                    : handleExecuteCICDSimulation
                }
                className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold shadow-[0_0_14px_rgba(249,115,22,0.4)]"
              >
                TRIGGER INGESTION EVENT
              </ButtonLoader>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL 3: INSPECT LOG PAYLOAD ================= */}
      {testLogModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-slate-700 rounded-xl max-w-xl w-full font-mono text-xs relative shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-3 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => setTestLogModal(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>
              <span className="text-[10px] text-orange-400 uppercase font-bold tracking-widest">
                INTEGRATION PAYLOAD INSPECTOR
              </span>
              <h2 className="text-lg font-bold text-white mt-0.5">Event Log ID #{testLogModal.id}</h2>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="bg-black/50 p-3 rounded border border-slate-200 dark:border-slate-800 space-y-1 font-mono text-[11px]">
                <div>
                  <span className="text-slate-500 uppercase">Provider:</span>{' '}
                  <span className="text-orange-400 font-bold">{testLogModal.provider}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase">Event Type:</span>{' '}
                  <span className="text-white font-bold">{testLogModal.eventType}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase">Direction:</span>{' '}
                  <span className="text-slate-300">{testLogModal.direction}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase">Message:</span>{' '}
                  <span className="text-slate-200">{testLogModal.message}</span>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  RAW JSON EVENT PAYLOAD
                </span>
                <pre className="bg-[#05080f] border border-slate-200 dark:border-slate-800 rounded p-3 text-[11px] text-emerald-400 font-mono overflow-x-auto">
                  {testLogModal.payloadSnippet || '{"status": "OK"}'}
                </pre>
              </div>
            </div>

            {/* Fixed Footer */}
            <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center justify-end z-10">
              <button
                onClick={() => setTestLogModal(null)}
                className="px-5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                CLOSE INSPECTOR
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
