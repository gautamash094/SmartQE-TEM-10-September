import React, { useState, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import {
  Cpu,
  Server,
  Package,
  Layers,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  HardDrive,
  Globe,
  Shield,
  Edit2,
  Trash2,
  Power,
  ToggleLeft,
  ToggleRight,
  Eye,
  Activity,
  Terminal,
  Clock,
  Radio,
  ExternalLink,
  ChevronRight,
  Cloud,
  Building,
  MapPin,
  Network,
  Database
} from 'lucide-react';
import {
  ServerDetail,
  SoftwareDetail,
  EnvironmentProfile,
  ServerType,
  EnvironmentType,
  EnvironmentStatus,
  InfrastructureType,
  CloudProvider
} from '../types/environmentDetails';
import { Pagination } from '../components/common/Pagination';
import { EnvironmentReadinessBadge } from '../components/monitoring/EnvironmentReadinessBadge';
import { isValidIp, isValidPort, isPositiveNumber, cleanTrim } from '../utils/validationUtils';
import { monitoringService } from '../services/monitoringService';
import { TableSkeleton, CardSkeleton } from '../components/common/Skeleton';
import { ButtonLoader } from '../components/common/ButtonLoader';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const EnvironmentDetailsManagementPage: React.FC = () => {
  const {
    servers,
    softwareList,
    environmentProfiles,
    incidents,
    bookings,
    addServer,
    updateServer,
    toggleServer,
    deleteServer,
    addSoftware,
    updateSoftware,
    toggleSoftware,
    deleteSoftware,
    addEnvironmentProfile,
    updateEnvironmentProfile,
    toggleEnvironmentProfile,
    deleteEnvironmentProfile,
    showToast,
    isLoading
  } = useTEM();

  const [activeTab, setActiveTab] = useState<'profiles' | 'servers' | 'software' | 'overview'>('profiles');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSavingServer, setIsSavingServer] = useState(false);
  const [isSavingSoftware, setIsSavingSoftware] = useState(false);
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [togglingProfileId, setTogglingProfileId] = useState<string | null>(null);
  const [togglingServerId, setTogglingServerId] = useState<string | null>(null);
  const [togglingSoftwareId, setTogglingSoftwareId] = useState<string | null>(null);
  const [selectedTypeFilter, setSelectedTypeFilter] = useState('ALL');
  
  // Infrastructure filters for Server tab
  const [infraFilter, setInfraFilter] = useState<'ALL' | 'ON_PREMISES' | 'CLOUD'>('ALL');
  const [cloudProviderFilter, setCloudProviderFilter] = useState<string>('ALL');

  // Pagination states
  const [profilePage, setProfilePage] = useState<number>(1);
  const [profilePageSize, setProfilePageSize] = useState<number>(10);

  const [serverPage, setServerPage] = useState<number>(1);
  const [serverPageSize, setServerPageSize] = useState<number>(10);

  const [softwarePage, setSoftwarePage] = useState<number>(1);
  const [softwarePageSize, setSoftwarePageSize] = useState<number>(10);

  // Modal States
  const [serverModalOpen, setServerModalOpen] = useState(false);
  const [editingServer, setEditingServer] = useState<ServerDetail | null>(null);

  const [softwareModalOpen, setSoftwareModalOpen] = useState(false);
  const [editingSoftware, setEditingSoftware] = useState<SoftwareDetail | null>(null);

  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [editingProfile, setEditingProfile] = useState<EnvironmentProfile | null>(null);

  const [inspectProfile, setInspectProfile] = useState<EnvironmentProfile | null>(null);

  // Cannot Deactivate Environment Modal State
  const [cannotDeactivateModal, setCannotDeactivateModal] = useState<{
    isOpen: boolean;
    environmentName: string;
  }>({
    isOpen: false,
    environmentName: '',
  });

  const handleToggleProfile = async (prof: EnvironmentProfile) => {
    const isProfActive = prof.isActive !== false;
    if (isProfActive) {
      // Check if there are active, confirmed, future, or conflicting reservations
      const activeRes = (bookings || []).filter((b) => {
        if (!b.status) return true;
        const st = String(b.status).toUpperCase();
        const isNotCancelled = st !== 'CANCELLED' && st !== 'REJECTED' && st !== 'AUTO_REJECTED';
        const matchesEnv =
          (b.environmentId && b.environmentId === prof.id) ||
          (b.environmentName && b.environmentName.toLowerCase().trim() === prof.name.toLowerCase().trim());
        return isNotCancelled && matchesEnv;
      });

      if (activeRes.length > 0) {
        setCannotDeactivateModal({
          isOpen: true,
          environmentName: prof.name,
        });
        return;
      }
    }

    setTogglingProfileId(prof.id);
    try {
      await toggleEnvironmentProfile(prof.id);
    } catch (err: any) {
      setCannotDeactivateModal({
        isOpen: true,
        environmentName: prof.name,
      });
    } finally {
      setTogglingProfileId(null);
    }
  };

  const handleToggleServer = async (id: string) => {
    setTogglingServerId(id);
    try {
      await toggleServer(id);
    } finally {
      setTogglingServerId(null);
    }
  };

  const handleToggleSoftware = async (id: string) => {
    setTogglingSoftwareId(id);
    try {
      await toggleSoftware(id);
    } finally {
      setTogglingSoftwareId(null);
    }
  };

  // Form States - Server (supports both On-Premises and Cloud)
  const [serverForm, setServerForm] = useState<Omit<ServerDetail, 'id' | 'createdAt'>>({
    name: '',
    hostIp: '',
    serverType: 'Application Server',
    operatingSystem: 'Ubuntu 22.04 LTS (Jammy)',
    cpuCores: 8,
    ramGb: 32,
    storageGb: 500,
    status: 'ONLINE',
    infrastructureType: 'ON_PREMISES',
    datacenter: 'US-East (Virginia DC-1)',
    rackUnit: 'Rack A-04',
    cloudProvider: 'AWS',
    instanceId: '',
    instanceType: 't3.2xlarge',
    region: 'us-east-1',
    availabilityZone: 'us-east-1a',
    publicIp: '',
    privateIp: '',
    vpcSubnet: 'vpc-main-01 / subnet-app',
    installedSoftwareIds: [],
    description: '',
    environmentName: 'Development',
  });

  // Form States - Software
  const [softwareForm, setSoftwareForm] = useState<Omit<SoftwareDetail, 'id' | 'createdAt'>>({
    name: '',
    version: '',
    installPath: '',
    port: '',
    serviceName: '',
    runtimeStack: 'Python 3.12 / FastAPI',
    vendor: '',
    status: 'ACTIVE',
    description: '',
  });

  // Form States - Environment Profile
  const [profileForm, setProfileForm] = useState<Omit<EnvironmentProfile, 'id' | 'updatedAt'>>({
    name: '',
    type: 'Development',
    description: '',
    status: 'HEALTHY',
    ownerTeam: 'Platform Operations',
    networkZone: 'VPC-EAST-CORE',
    serverIds: [],
    softwareIds: [],
  });

  // Open Create Handlers
  const handleOpenCreateServer = () => {
    setEditingServer(null);
    setServerForm({
      name: '',
      hostIp: '',
      serverType: 'Application Server',
      operatingSystem: 'Ubuntu 22.04 LTS (Jammy)',
      cpuCores: 8,
      ramGb: 32,
      storageGb: 500,
      status: 'ONLINE',
      infrastructureType: 'ON_PREMISES',
      datacenter: 'US-East (Virginia DC-1)',
      rackUnit: 'Rack A-04',
      cloudProvider: 'AWS',
      instanceId: '',
      instanceType: 't3.2xlarge',
      region: 'us-east-1',
      availabilityZone: 'us-east-1a',
      publicIp: '',
      privateIp: '',
      vpcSubnet: 'vpc-main-01 / subnet-app',
      installedSoftwareIds: [],
      description: '',
      environmentName: 'Development',
    });
    setServerModalOpen(true);
  };

  const handleOpenEditServer = (srv: ServerDetail) => {
    setEditingServer(srv);
    setServerForm({
      name: srv.name,
      hostIp: srv.hostIp,
      serverType: srv.serverType,
      operatingSystem: srv.operatingSystem,
      cpuCores: srv.cpuCores,
      ramGb: srv.ramGb,
      storageGb: srv.storageGb,
      status: srv.status,
      infrastructureType: srv.infrastructureType || 'ON_PREMISES',
      datacenter: srv.datacenter || 'US-East (Virginia DC-1)',
      rackUnit: srv.rackUnit || 'Rack A-04',
      cloudProvider: srv.cloudProvider || 'AWS',
      instanceId: srv.instanceId || '',
      instanceType: srv.instanceType || 't3.2xlarge',
      region: srv.region || 'us-east-1',
      availabilityZone: srv.availabilityZone || 'us-east-1a',
      publicIp: srv.publicIp || '',
      privateIp: srv.privateIp || '',
      vpcSubnet: srv.vpcSubnet || 'vpc-main-01 / subnet-app',
      installedSoftwareIds: srv.installedSoftwareIds || [],
      description: srv.description || '',
      environmentName: srv.environmentName || 'Development',
    });
    setServerModalOpen(true);
  };

  // Open Create / Edit Software
  const handleOpenCreateSoftware = () => {
    setEditingSoftware(null);
    setSoftwareForm({
      name: '',
      version: '',
      installPath: '',
      port: '',
      serviceName: '',
      runtimeStack: 'Python 3.12 / FastAPI',
      vendor: '',
      status: 'ACTIVE',
      description: '',
    });
    setSoftwareModalOpen(true);
  };

  const handleOpenEditSoftware = (soft: SoftwareDetail) => {
    setEditingSoftware(soft);
    setSoftwareForm({
      name: soft.name,
      version: soft.version,
      installPath: soft.installPath,
      port: soft.port,
      serviceName: soft.serviceName,
      runtimeStack: soft.runtimeStack,
      vendor: soft.vendor || '',
      status: soft.status,
      description: soft.description || '',
    });
    setSoftwareModalOpen(true);
  };

  // Open Create Profile
  const handleOpenCreateProfile = () => {
    setEditingProfile(null);
    setProfileForm({
      name: '',
      type: 'Development',
      description: '',
      status: 'HEALTHY',
      ownerTeam: 'Platform Operations',
      networkZone: 'VPC-EAST-CORE',
      serverIds: [],
      softwareIds: [],
    });
    setProfileModalOpen(true);
  };

  // Open Edit Profile
  const handleOpenEditProfile = (prof: EnvironmentProfile) => {
    setEditingProfile(prof);
    setProfileForm({
      name: prof.name,
      type: prof.type,
      description: prof.description,
      status: prof.status,
      ownerTeam: prof.ownerTeam,
      networkZone: prof.networkZone,
      serverIds: prof.serverIds,
      softwareIds: prof.softwareIds,
    });
    setProfileModalOpen(true);
  };

  // Submit Server
  const handleSubmitServer = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = serverForm.name.trim();
    const cleanHostIp = serverForm.hostIp.trim();

    if (!cleanName || !cleanHostIp) {
      showToast('Server Name and Host IP are required fields (*).', 'error');
      return;
    }
    if (!isValidIp(cleanHostIp)) {
      showToast('Please enter a valid IPv4 or IPv6 address for Host IP.', 'error');
      return;
    }
    if (serverForm.publicIp && serverForm.publicIp.trim() && !isValidIp(serverForm.publicIp.trim())) {
      showToast('Please enter a valid IPv4 or IPv6 address for Public IP.', 'error');
      return;
    }
    if (serverForm.privateIp && serverForm.privateIp.trim() && !isValidIp(serverForm.privateIp.trim())) {
      showToast('Please enter a valid IPv4 or IPv6 address for Private IP.', 'error');
      return;
    }
    if (!isPositiveNumber(serverForm.cpuCores) || Number(serverForm.cpuCores) < 1) {
      showToast('CPU Cores must be an integer of at least 1.', 'error');
      return;
    }
    if (!isPositiveNumber(serverForm.ramGb) || Number(serverForm.ramGb) <= 0) {
      showToast('RAM (GB) must be greater than 0.', 'error');
      return;
    }
    if (!isPositiveNumber(serverForm.storageGb) || Number(serverForm.storageGb) <= 0) {
      showToast('Storage (GB) must be greater than 0.', 'error');
      return;
    }

    // Pre-save uniqueness
    const nameExists = servers.some(
      s => (!editingServer || s.id !== editingServer.id) && s.name.toLowerCase() === cleanName.toLowerCase()
    );
    if (nameExists) {
      showToast(`A server named "${cleanName}" already exists.`, 'error');
      return;
    }

    setIsSavingServer(true);
    try {
      const payload: Omit<ServerDetail, 'id' | 'createdAt'> = {
        ...serverForm,
        name: cleanName,
        hostIp: cleanHostIp,
        publicIp: serverForm.publicIp ? serverForm.publicIp.trim() : undefined,
        privateIp: serverForm.privateIp ? serverForm.privateIp.trim() : undefined,
        cpuCores: Math.round(Number(serverForm.cpuCores)),
        ramGb: Number(serverForm.ramGb),
        storageGb: Number(serverForm.storageGb),
        cloudProvider: serverForm.infrastructureType === 'ON_PREMISES' ? undefined : (serverForm.cloudProvider || 'AWS'),
      };
      if (editingServer) {
        await updateServer(editingServer.id, payload);
      } else {
        await addServer(payload);
      }
      setServerModalOpen(false);
      setEditingServer(null);
      showToast(editingServer ? 'Server details updated successfully.' : 'Server registered successfully.', 'success');
    } finally {
      setIsSavingServer(false);
    }
  };

  // Submit Software
  const handleSubmitSoftware = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = softwareForm.name.trim();
    const cleanVersion = softwareForm.version.trim();

    if (!cleanName || !cleanVersion) {
      showToast('Software Name and Version are required (*).', 'error');
      return;
    }
    if (softwareForm.port && softwareForm.port.trim() && !isValidPort(softwareForm.port.trim())) {
      showToast('Port must be a valid number between 1 and 65535.', 'error');
      return;
    }

    setIsSavingSoftware(true);
    try {
      const cleanPayload = {
        ...softwareForm,
        name: cleanName,
        version: cleanVersion,
        port: softwareForm.port ? softwareForm.port.trim() : '',
        serviceName: softwareForm.serviceName ? softwareForm.serviceName.trim() : '',
        installPath: softwareForm.installPath ? softwareForm.installPath.trim() : ''
      };
      if (editingSoftware) {
        await updateSoftware(editingSoftware.id, cleanPayload);
      } else {
        await addSoftware(cleanPayload);
      }
      setSoftwareModalOpen(false);
      setEditingSoftware(null);
      showToast(editingSoftware ? 'Software runtime updated successfully.' : 'Software runtime registered successfully.', 'success');
    } finally {
      setIsSavingSoftware(false);
    }
  };

  // Submit Profile
  const handleSubmitProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = profileForm.name.trim();
    if (!cleanName) {
      showToast('Environment Profile Name is mandatory (*).', 'error');
      return;
    }

    // Pre-save uniqueness
    const nameExists = environmentProfiles.some(
      p => (!editingProfile || p.id !== editingProfile.id) && p.name.toLowerCase() === cleanName.toLowerCase()
    );
    if (nameExists) {
      showToast(`An Environment Profile named "${cleanName}" already exists.`, 'error');
      return;
    }

    setIsSavingProfile(true);
    try {
      const cleanPayload = {
        ...profileForm,
        name: cleanName,
        description: profileForm.description ? profileForm.description.trim() : '',
        ownerTeam: profileForm.ownerTeam ? profileForm.ownerTeam.trim() : 'Platform Operations'
      };
      if (editingProfile) {
        await updateEnvironmentProfile(editingProfile.id, cleanPayload);
      } else {
        await addEnvironmentProfile(cleanPayload);
      }
      setProfileModalOpen(false);
      setEditingProfile(null);
      showToast(editingProfile ? 'Environment Profile updated successfully.' : 'Environment Profile created successfully.', 'success');
    } finally {
      setIsSavingProfile(false);
    }
  };

  // Aggregated Stats for Overview & Inventory
  const onPremServersCount = useMemo(
    () => servers.filter((s) => (s.infrastructureType || 'ON_PREMISES') === 'ON_PREMISES').length,
    [servers]
  );
  const cloudServersCount = useMemo(
    () => servers.filter((s) => s.infrastructureType === 'CLOUD').length,
    [servers]
  );
  const awsCount = useMemo(() => servers.filter((s) => s.cloudProvider === 'AWS').length, [servers]);
  const azureCount = useMemo(() => servers.filter((s) => s.cloudProvider === 'Azure').length, [servers]);
  const gcpCount = useMemo(() => servers.filter((s) => s.cloudProvider === 'GCP').length, [servers]);

  const totalCores = useMemo(() => servers.reduce((acc, s) => acc + (s.cpuCores || 0), 0), [servers]);
  const totalRam = useMemo(() => servers.reduce((acc, s) => acc + (s.ramGb || 0), 0), [servers]);
  const totalStorage = useMemo(() => servers.reduce((acc, s) => acc + (s.storageGb || 0), 0), [servers]);

  // Filtered lists
  const filteredProfiles = useMemo(() => {
    return environmentProfiles.filter((p) => {
      const q = searchQuery.toLowerCase();
      const matchSearch = !q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.ownerTeam.toLowerCase().includes(q);
      const matchType = selectedTypeFilter === 'ALL' || p.type === selectedTypeFilter;
      return matchSearch && matchType;
    });
  }, [environmentProfiles, searchQuery, selectedTypeFilter]);

  const filteredServers = useMemo(() => {
    return servers.filter((s) => {
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !q ||
        s.name.toLowerCase().includes(q) ||
        s.hostIp.includes(q) ||
        (s.instanceId && s.instanceId.toLowerCase().includes(q)) ||
        (s.datacenter && s.datacenter.toLowerCase().includes(q)) ||
        (s.region && s.region.toLowerCase().includes(q)) ||
        (s.cloudProvider && s.cloudProvider.toLowerCase().includes(q)) ||
        s.operatingSystem.toLowerCase().includes(q) ||
        s.serverType.toLowerCase().includes(q) ||
        (s.environmentName && s.environmentName.toLowerCase().includes(q));

      const matchType = selectedTypeFilter === 'ALL' || s.serverType === selectedTypeFilter;

      const currentInfra = s.infrastructureType || (s.cloudProvider ? 'CLOUD' : 'ON_PREMISES');
      const matchInfra = infraFilter === 'ALL' || currentInfra === infraFilter;

      const matchProvider = cloudProviderFilter === 'ALL' || s.cloudProvider === cloudProviderFilter;

      return matchSearch && matchType && matchInfra && matchProvider;
    });
  }, [servers, searchQuery, selectedTypeFilter, infraFilter, cloudProviderFilter]);

  const filteredSoftware = useMemo(() => {
    return softwareList.filter((s) => {
      const q = searchQuery.toLowerCase();
      return !q || s.name.toLowerCase().includes(q) || s.version.toLowerCase().includes(q) || s.runtimeStack.toLowerCase().includes(q) || s.port.includes(q);
    });
  }, [softwareList, searchQuery]);

  // Paginated Slices (min 5, max 10)
  const paginatedProfiles = useMemo(() => {
    return filteredProfiles.slice((profilePage - 1) * profilePageSize, profilePage * profilePageSize);
  }, [filteredProfiles, profilePage, profilePageSize]);

  const paginatedServers = useMemo(() => {
    return filteredServers.slice((serverPage - 1) * serverPageSize, serverPage * serverPageSize);
  }, [filteredServers, serverPage, serverPageSize]);

  const paginatedSoftware = useMemo(() => {
    return filteredSoftware.slice((softwarePage - 1) * softwarePageSize, softwarePage * softwarePageSize);
  }, [filteredSoftware, softwarePage, softwarePageSize]);

  const handleSearchChange = (q: string) => {
    setSearchQuery(q);
    setProfilePage(1);
    setServerPage(1);
    setSoftwarePage(1);
  };

  const handleTypeFilterChange = (val: string) => {
    setSelectedTypeFilter(val);
    setProfilePage(1);
    setServerPage(1);
  };

  return (
    <div className="space-y-6 font-sans w-full min-w-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            INFRASTRUCTURE & TOPOLOGY
          </span>
          <h1 className="text-3xl font-extrabold text-white tracking-tight flex items-center gap-3 mt-0.5">
            <Cpu className="w-8 h-8 text-orange-500" />
            Environment Details
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Capture, configure, and manage Server details, Software components, and Environment mapping profiles.
          </p>
        </div>

        {/* Dynamic Action Button according to Tab */}
        <div className="flex items-center gap-3">
          {activeTab === 'profiles' && (
            <button
              onClick={() => {
                setEditingProfile(null);
                setProfileForm({
                  name: '',
                  type: 'Development',
                  description: '',
                  status: 'HEALTHY',
                  ownerTeam: '',
                  networkZone: '',
                  serverIds: [],
                  softwareIds: [],
                });
                setProfileModalOpen(true);
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_16px_rgba(249,115,22,0.4)]"
            >
              <Plus className="w-4 h-4" /> NEW ENVIRONMENT PROFILE
            </button>
          )}

          {activeTab === 'servers' && (
            <button
              onClick={() => {
                setEditingServer(null);
                setServerForm({
                  name: '',
                  hostIp: '',
                  serverType: 'Application Server',
                  operatingSystem: 'Ubuntu 22.04 LTS (Jammy)',
                  cpuCores: 8,
                  ramGb: 32,
                  storageGb: 500,
                  status: 'ONLINE',
                  infrastructureType: 'ON_PREMISES',
                  datacenter: 'US-East (Virginia DC-1)',
                  rackUnit: 'Rack A-04',
                  cloudProvider: 'AWS',
                  instanceId: '',
                  instanceType: 't3.2xlarge',
                  region: 'us-east-1',
                  availabilityZone: 'us-east-1a',
                  publicIp: '',
                  privateIp: '',
                  vpcSubnet: 'vpc-main-01 / subnet-app',
                  installedSoftwareIds: [],
                  description: '',
                  environmentName: 'Development',
                });
                setServerModalOpen(true);
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_16px_rgba(249,115,22,0.4)]"
            >
              <Plus className="w-4 h-4" /> ADD INFRASTRUCTURE
            </button>
          )}

          {activeTab === 'software' && (
            <button
              onClick={() => {
                setEditingSoftware(null);
                setSoftwareForm({
                  name: '',
                  version: '',
                  installPath: '',
                  port: '',
                  serviceName: '',
                  runtimeStack: 'Python 3.12 / FastAPI',
                  vendor: '',
                  status: 'ACTIVE',
                  description: '',
                });
                setSoftwareModalOpen(true);
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_16px_rgba(249,115,22,0.4)]"
            >
              <Plus className="w-4 h-4" /> REGISTER SOFTWARE
            </button>
          )}
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="border-b border-slate-200 dark:border-slate-800 flex items-center gap-6 text-sm font-mono font-bold">
        <button
          onClick={() => {
            setActiveTab('profiles');
            setSelectedTypeFilter('ALL');
          }}
          className={`pb-3.5 flex items-center gap-2 relative transition-colors ${
            activeTab === 'profiles' ? 'text-orange-500' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>ENVIRONMENT PROFILES</span>
          <span className="px-1.5 py-0.2 text-[10px] rounded bg-slate-800 text-slate-300">
            {environmentProfiles.length}
          </span>
          {activeTab === 'profiles' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]" />}
        </button>

        <button
          onClick={() => {
            setActiveTab('servers');
            setSelectedTypeFilter('ALL');
          }}
          className={`pb-3.5 flex items-center gap-2 relative transition-colors ${
            activeTab === 'servers' ? 'text-orange-500' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>SERVER DETAILS</span>
          <span className="px-1.5 py-0.2 text-[10px] rounded bg-slate-800 text-slate-300">
            {servers.length}
          </span>
          {activeTab === 'servers' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]" />}
        </button>

        <button
          onClick={() => {
            setActiveTab('software');
            setSelectedTypeFilter('ALL');
          }}
          className={`pb-3.5 flex items-center gap-2 relative transition-colors ${
            activeTab === 'software' ? 'text-orange-500' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>SOFTWARE DETAILS</span>
          <span className="px-1.5 py-0.2 text-[10px] rounded bg-slate-800 text-slate-300">
            {softwareList.length}
          </span>
          {activeTab === 'software' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]" />}
        </button>

        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-3.5 flex items-center gap-2 relative transition-colors ${
            activeTab === 'overview' ? 'text-orange-500' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>OVERVIEW & TOPOLOGY</span>
          {activeTab === 'overview' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]" />}
        </button>
      </div>

      {/* SEARCH & FILTER TOOLBAR (For profiles, servers, software) */}
      {activeTab !== 'overview' && (
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-xs shadow-lg">
          <div className="relative flex-1 w-full max-w-md">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input autoComplete="off" data-lpignore="true"
              type="text"
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder={
                activeTab === 'profiles'
                  ? 'Search environments, owner team, network zone...'
                  : activeTab === 'servers'
                  ? 'Search server name, host IP, OS, datacenter...'
                  : 'Search software name, version, stack, port...'
              }
              className="w-full bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
            />
          </div>

          {activeTab === 'profiles' && (
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-slate-500 font-bold uppercase text-[10px]">ENV TYPE:</span>
              <select
                value={selectedTypeFilter}
                onChange={(e) => handleTypeFilterChange(e.target.value)}
                className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-2 text-white text-xs focus:outline-none focus:border-orange-500"
              >
                <option value="ALL">All Types</option>
                <option value="Development">Development</option>
                <option value="QA / Testing">QA / Testing</option>
                <option value="UAT / Staging">UAT / Staging</option>
                <option value="Production">Production</option>
                <option value="Performance / Stress">Performance / Stress</option>
                <option value="Disaster Recovery (DR)">Disaster Recovery (DR)</option>
              </select>
            </div>
          )}

          {activeTab === 'servers' && (
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg border border-slate-200 dark:border-slate-800">
                <button
                  onClick={() => {
                    setInfraFilter('ALL');
                    setServerPage(1);
                  }}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold transition-colors ${
                    infraFilter === 'ALL'
                      ? 'bg-orange-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All ({servers.length})
                </button>
                <button
                  onClick={() => {
                    setInfraFilter('ON_PREMISES');
                    setServerPage(1);
                  }}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold flex items-center gap-1 transition-colors ${
                    infraFilter === 'ON_PREMISES'
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Building className="w-3 h-3 text-orange-400" /> On-Prem ({onPremServersCount})
                </button>
                <button
                  onClick={() => {
                    setInfraFilter('CLOUD');
                    setServerPage(1);
                  }}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold flex items-center gap-1 transition-colors ${
                    infraFilter === 'CLOUD'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Cloud className="w-3 h-3 text-sky-400" /> Cloud ({cloudServersCount})
                </button>
              </div>

              {infraFilter === 'CLOUD' && (
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500 font-bold uppercase text-[10px]">PROVIDER:</span>
                  <select
                    value={cloudProviderFilter}
                    onChange={(e) => {
                      setCloudProviderFilter(e.target.value);
                      setServerPage(1);
                    }}
                    className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2 py-1 text-white text-xs focus:outline-none focus:border-orange-500"
                  >
                    <option value="ALL">All Cloud Providers</option>
                    <option value="AWS">AWS</option>
                    <option value="Azure">Azure</option>
                    <option value="GCP">Google Cloud (GCP)</option>
                    <option value="OCI">Oracle Cloud (OCI)</option>
                    <option value="Alibaba Cloud">Alibaba Cloud</option>
                    <option value="DigitalOcean">DigitalOcean</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              )}

              <div className="flex items-center gap-1.5">
                <span className="text-slate-500 font-bold uppercase text-[10px]">TYPE:</span>
                <select
                  value={selectedTypeFilter}
                  onChange={(e) => handleTypeFilterChange(e.target.value)}
                  className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-1 text-white text-xs focus:outline-none focus:border-orange-500"
                >
                  <option value="ALL">All Types</option>
                  <option value="Application Server">Application Server</option>
                  <option value="Database Server">Database Server</option>
                  <option value="Web Server">Web Server</option>
                  <option value="Cache Server">Cache Server</option>
                  <option value="Load Balancer / Proxy">Load Balancer / Proxy</option>
                  <option value="Message Broker">Message Broker</option>
                  <option value="API Gateway">API Gateway</option>
                </select>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= TAB 1: ENVIRONMENT PROFILES ================= */}
      {activeTab === 'profiles' && (
        isLoading ? (
          <CardSkeleton count={4} className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs" />
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
              {filteredProfiles.length === 0 ? (
                <div className="col-span-full p-12 text-center text-slate-500 bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg">
                  <Layers className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                  <p className="font-bold text-slate-300">No Environment Profiles Found</p>
                  <p className="text-xs text-slate-500 mt-1">Create an environment profile to map servers and software stacks together.</p>
                </div>
              ) : (
                paginatedProfiles.map((prof) => {
                  const linkedServers = servers.filter((s) => prof.serverIds.includes(s.id));
                  const linkedSoftware = softwareList.filter((s) => prof.softwareIds.includes(s.id));
                  const readinessResult = monitoringService.evaluateTestReadiness(prof, incidents, bookings);
                  const isProfActive = prof.isActive !== false;
                  const isTogglingThis = togglingProfileId === prof.id;

                  return (
                    <div
                      key={prof.id}
                      className={`bg-[#0f1724] border rounded-lg p-5 space-y-4 shadow-xl transition-all flex flex-col justify-between ${
                        isProfActive ? 'border-slate-200 dark:border-slate-800 hover:border-slate-700' : 'border-slate-850 opacity-75'
                      }`}
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-orange-950/80 text-orange-400 border border-orange-800/80">
                                {prof.type}
                              </span>
                              <span
                                className={`inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                                  isProfActive
                                    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80'
                                    : 'bg-slate-900 text-slate-400 border-slate-700'
                                }`}
                              >
                                <span className={`w-1.5 h-1.5 rounded-full ${isProfActive ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                                {isProfActive ? 'Active' : 'Inactive'}
                              </span>
                              <EnvironmentReadinessBadge status={readinessResult.status} result={readinessResult} size="sm" />
                            </div>
                            <h3 className="text-lg font-bold text-white mt-1.5 flex items-center gap-2">
                              {prof.name}
                            </h3>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => setInspectProfile(prof)}
                              title="View Blueprint Architecture"
                              className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleOpenEditProfile(prof)}
                              title="Edit Profile"
                              className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleToggleProfile(prof)}
                              disabled={isTogglingThis}
                              title={isProfActive ? "Deactivate Profile" : "Activate Profile"}
                              className={`px-2.5 py-1 rounded text-xs font-mono font-bold inline-flex items-center gap-1.5 transition-colors border ${
                                isProfActive
                                  ? 'bg-slate-800 hover:bg-amber-950/80 text-slate-300 hover:text-amber-300 border-slate-700 hover:border-amber-700'
                                  : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-700'
                              } ${isTogglingThis ? 'opacity-70 cursor-wait' : ''}`}
                            >
                              {isTogglingThis ? (
                                <LoadingSpinner size="xs" variant={isProfActive ? 'slate' : 'accent'} inline />
                              ) : (
                                <Power className={`w-3.5 h-3.5 ${isProfActive ? 'text-slate-400' : 'text-emerald-400'}`} />
                              )}
                              <span>{isProfActive ? 'Deactivate' : 'Activate'}</span>
                            </button>
                          </div>
                        </div>

                      <p className="text-slate-300 text-xs leading-relaxed font-sans">{prof.description}</p>

                      <div className="grid grid-cols-2 gap-2 text-[11px] bg-black/40 p-2.5 rounded border border-slate-200 dark:border-slate-800/80">
                        <div>
                          <span className="text-slate-500 block text-[9px] uppercase">OWNER TEAM</span>
                          <span className="text-white font-bold">{prof.ownerTeam || 'Platform Operations'}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[9px] uppercase">NETWORK ZONE</span>
                          <span className="text-orange-400 font-bold">{prof.networkZone || 'VPC-DEFAULT'}</span>
                        </div>
                      </div>

                      {/* Associated Servers */}
                      <div className="space-y-1.5">
                        <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1">
                          <Server className="w-3 h-3 text-orange-400" />
                          ASSOCIATED SERVERS ({linkedServers.length})
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {linkedServers.length === 0 ? (
                            <span className="text-[10px] text-slate-500 italic">No servers mapped yet</span>
                          ) : (
                            linkedServers.map((s) => {
                              const isCloud = s.infrastructureType === 'CLOUD' || !!s.cloudProvider;
                              return (
                                <span
                                  key={s.id}
                                  className="px-2 py-1 rounded bg-[#162032] border border-slate-700 text-slate-200 text-[10px] flex items-center gap-1.5 font-mono"
                                >
                                  {isCloud ? (
                                    <Cloud className="w-3 h-3 text-sky-400 shrink-0" />
                                  ) : (
                                    <Building className="w-3 h-3 text-orange-400 shrink-0" />
                                  )}
                                  <span className="font-bold text-white">{s.name}</span>
                                  <span className="text-slate-400">({s.hostIp})</span>
                                </span>
                              );
                            })
                          )}
                        </div>
                      </div>

                      {/* Associated Software */}
                      <div className="space-y-1.5">
                        <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1">
                          <Package className="w-3 h-3 text-blue-400" />
                          INSTALLED SOFTWARE ({linkedSoftware.length})
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {linkedSoftware.length === 0 ? (
                            <span className="text-[10px] text-slate-500 italic">No software mapped yet</span>
                          ) : (
                            linkedSoftware.map((s) => (
                              <span
                                key={s.id}
                                className="px-2 py-0.5 rounded bg-blue-950/60 border border-blue-800 text-blue-300 text-[10px] flex items-center gap-1 font-mono"
                              >
                                <span>{s.name}</span>
                                <span className="text-white font-bold">v{s.version}</span>
                                {s.port && <span className="text-orange-400">:{s.port}</span>}
                              </span>
                            ))
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500">
                      <span>Updated: {prof.updatedAt}</span>
                      <button
                        onClick={() => setInspectProfile(prof)}
                        className="text-orange-400 hover:text-orange-300 flex items-center gap-1 font-bold"
                      >
                        Inspect Blueprint <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
            <Pagination
              currentPage={profilePage}
              totalItems={filteredProfiles.length}
              pageSize={profilePageSize}
              onPageChange={setProfilePage}
              onPageSizeChange={(s) => {
                setProfilePageSize(s);
                setProfilePage(1);
              }}
              pageSizeOptions={[10, 20, 50]}
            />
          </div>
        </div>
      )
    )}

      {/* ================= TAB 2: SERVER DETAILS (ON-PREMISES & CLOUD) ================= */}
      {activeTab === 'servers' && (
        <div className="space-y-4">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">TOTAL INFRA</span>
                <span className="text-xl font-bold text-white">{servers.length}</span>
              </div>
              <Server className="w-5 h-5 text-slate-500" />
            </div>

            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">ON-PREMISES</span>
                <span className="text-xl font-bold text-orange-400">{onPremServersCount}</span>
              </div>
              <Building className="w-5 h-5 text-orange-400" />
            </div>

            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">CLOUD INSTANCES</span>
                <span className="text-xl font-bold text-sky-400">{cloudServersCount}</span>
              </div>
              <Cloud className="w-5 h-5 text-sky-400" />
            </div>

            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">TOTAL vCPU / RAM</span>
                <span className="text-sm font-bold text-emerald-400">{totalCores} vCPU / {totalRam} GB</span>
              </div>
              <Cpu className="w-5 h-5 text-emerald-400" />
            </div>
          </div>

          {isLoading ? (
            <TableSkeleton rows={serverPageSize} columns={8} />
          ) : (
            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold tracking-wider">
                    <tr>
                      <th className="p-3.5">SERVER / INSTANCE</th>
                      <th className="p-3.5">INFRASTRUCTURE & PROVIDER</th>
                      <th className="p-3.5">NETWORK / HOST IP</th>
                      <th className="p-3.5">LOCATION / REGION & AZ</th>
                      <th className="p-3.5">SPECS (CPU/RAM/DISK)</th>
                      <th className="p-3.5">ENVIRONMENT</th>
                      <th className="p-3.5">STATUS</th>
                      <th className="p-3.5 text-right">ACTIONS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                    {filteredServers.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-500">
                          No servers found matching criteria. Click "+ ADD SERVER" to register new infrastructure.
                        </td>
                      </tr>
                    ) : (
                      paginatedServers.map((s) => {
                        const isCloud = s.infrastructureType ? s.infrastructureType === 'CLOUD' : !!s.cloudProvider;
                        const providerName = s.cloudProvider || 'AWS';
                        const isTogglingThis = togglingServerId === s.id;

                        // Find mapped software
                        const mappedSoftware = softwareList.filter(
                          (soft) => (s.installedSoftwareIds || []).includes(soft.id)
                        );

                        return (
                          <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                            {/* Name & Type */}
                            <td className="p-3.5">
                              <div className="font-bold text-white text-sm flex items-center gap-1.5">
                                {isCloud ? (
                                  <Cloud className="w-4 h-4 text-sky-400 shrink-0" />
                                ) : (
                                  <Building className="w-4 h-4 text-orange-400 shrink-0" />
                                )}
                                <span>{s.name}</span>
                              </div>
                              <div className="text-[10px] text-slate-400 mt-0.5">
                                {s.serverType} · <span className="text-slate-500">{s.operatingSystem}</span>
                              </div>
                            </td>

                            {/* Infrastructure Badge */}
                            <td className="p-3.5">
                              {isCloud ? (
                                <div className="space-y-1">
                                  <span
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold border inline-flex items-center gap-1 ${
                                      providerName === 'AWS'
                                        ? 'bg-amber-950/80 text-amber-300 border-amber-800'
                                        : providerName === 'Azure'
                                        ? 'bg-blue-950/80 text-blue-300 border-blue-800'
                                        : providerName === 'GCP'
                                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                                        : 'bg-purple-950/80 text-purple-300 border-purple-800'
                                    }`}
                                  >
                                    <Cloud className="w-2.5 h-2.5" /> {providerName}
                                  </span>
                                  {s.instanceType && (
                                    <span className="text-[10px] text-slate-300 block font-mono">
                                      {s.instanceType}
                                    </span>
                                  )}
                                  {s.instanceId && (
                                    <span className="text-[9px] text-slate-500 block font-mono truncate max-w-[120px]" title={s.instanceId}>
                                      ID: {s.instanceId}
                                    </span>
                                  )}
                                </div>
                              ) : (
                                <div className="space-y-1">
                                  <span className="px-2 py-0.5 rounded bg-orange-950/80 text-orange-400 border border-orange-800 text-[10px] font-bold inline-flex items-center gap-1">
                                    <Building className="w-2.5 h-2.5" /> ON-PREMISES
                                  </span>
                                  {s.rackUnit && (
                                    <span className="text-[9px] text-slate-400 block font-mono">
                                      {s.rackUnit}
                                    </span>
                                  )}
                                </div>
                              )}
                            </td>

                            {/* Network & IP */}
                            <td className="p-3.5 font-mono">
                              <div className="text-orange-300 font-bold text-[11px]">{s.hostIp}</div>
                              {isCloud && (
                                <div className="space-y-0.5 text-[10px] text-slate-400 mt-0.5">
                                  {s.publicIp && <div><span className="text-slate-500">Pub:</span> {s.publicIp}</div>}
                                  {s.vpcSubnet && <div className="text-slate-500 truncate max-w-[130px]" title={s.vpcSubnet}>{s.vpcSubnet}</div>}
                                </div>
                              )}
                            </td>

                            {/* Location / Datacenter / Region */}
                            <td className="p-3.5 text-slate-300 text-[11px]">
                              {isCloud ? (
                                <div>
                                  <span className="text-white font-bold block">{s.region || 'us-east-1'}</span>
                                  {s.availabilityZone && (
                                    <span className="text-[10px] text-slate-400">AZ: {s.availabilityZone}</span>
                                  )}
                                </div>
                              ) : (
                                <div>
                                  <span className="text-white font-bold block">{s.datacenter || 'Enterprise DC'}</span>
                                  <span className="text-[10px] text-slate-400">Physical Server Room</span>
                                </div>
                              )}
                            </td>

                            {/* Specs */}
                            <td className="p-3.5 text-[11px]">
                              <div className="space-y-0.5 text-slate-300 font-mono">
                                <div><span className="text-slate-500">CPU:</span> <strong className="text-white">{s.cpuCores} vCPU</strong></div>
                                <div><span className="text-slate-500">RAM:</span> <strong className="text-white">{s.ramGb} GB</strong></div>
                                <div><span className="text-slate-500">DISK:</span> <strong className="text-white">{s.storageGb} GB</strong></div>
                              </div>
                            </td>

                            {/* Environment & Software */}
                            <td className="p-3.5">
                              <span className="px-2 py-0.5 rounded bg-slate-800 text-orange-400 font-bold text-[10px] block w-fit mb-1 border border-slate-700">
                                {s.environmentName || 'Development'}
                              </span>
                              {mappedSoftware.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-1 max-w-[150px]">
                                  {mappedSoftware.map((soft) => (
                                    <span key={soft.id} className="text-[9px] px-1.5 py-0.2 rounded bg-blue-950/60 text-blue-300 border border-blue-900 truncate">
                                      {soft.name}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </td>

                            {/* Status */}
                            <td className="p-3.5 space-y-1">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span
                                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold border ${
                                    s.status === 'ONLINE'
                                      ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                                      : s.status === 'MAINTENANCE'
                                      ? 'bg-amber-950 text-amber-400 border-amber-800'
                                      : 'bg-red-950 text-red-400 border-red-800'
                                  }`}
                                >
                                  <span className="h-1.5 w-1.5 rounded-full bg-current" />
                                  {s.status}
                                </span>

                                <span
                                  className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${
                                    s.isActive !== false
                                      ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800/80'
                                      : 'bg-slate-900 text-slate-400 border-slate-700'
                                  }`}
                                >
                                  <span className={`w-1.5 h-1.5 rounded-full ${s.isActive !== false ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                                  {s.isActive !== false ? 'Active' : 'Inactive'}
                                </span>
                              </div>
                            </td>

                            {/* Actions */}
                            <td className="p-3.5 text-right space-x-2">
                              <button
                                onClick={() => handleOpenEditServer(s)}
                                title="Edit Server Details"
                                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                              >
                                <Edit2 className="w-3.5 h-3.5 inline" />
                              </button>
                              <button
                                onClick={() => handleToggleServer(s.id)}
                                disabled={isTogglingThis}
                                title={s.isActive !== false ? "Deactivate Server" : "Activate Server"}
                                className={`px-2.5 py-1 rounded text-xs font-mono font-bold inline-flex items-center gap-1.5 transition-colors border ${
                                  s.isActive !== false
                                    ? 'bg-slate-800 hover:bg-amber-950/80 text-slate-300 hover:text-amber-300 border-slate-700 hover:border-amber-700'
                                    : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-700'
                                } ${isTogglingThis ? 'opacity-70 cursor-wait' : ''}`}
                              >
                                {isTogglingThis ? (
                                  <LoadingSpinner size="xs" variant={s.isActive !== false ? 'slate' : 'accent'} inline />
                                ) : (
                                  <Power className={`w-3.5 h-3.5 ${s.isActive !== false ? 'text-slate-400' : 'text-emerald-400'}`} />
                                )}
                                <span>{s.isActive !== false ? 'Deactivate' : 'Activate'}</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              <Pagination
                currentPage={serverPage}
                totalItems={filteredServers.length}
                pageSize={serverPageSize}
                onPageChange={setServerPage}
                onPageSizeChange={(s) => {
                  setServerPageSize(s);
                  setServerPage(1);
                }}
                pageSizeOptions={[10, 20, 50]}
              />
            </div>
          )}
        </div>
      )}

      {/* ================= TAB 3: SOFTWARE DETAILS ================= */}
      {activeTab === 'software' && (
        isLoading ? (
          <TableSkeleton rows={softwarePageSize} columns={6} />
        ) : (
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold tracking-wider">
                  <tr>
                    <th className="p-3.5">SOFTWARE / APPLICATION</th>
                    <th className="p-3.5">VERSION & RUNTIME</th>
                    <th className="p-3.5">INSTALLATION PATH & SERVICE</th>
                    <th className="p-3.5">PORTS & NETWORKING</th>
                    <th className="p-3.5">STATUS</th>
                    <th className="p-3.5 text-right">ACTIONS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredSoftware.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-500">
                        No software registered in catalog.
                      </td>
                    </tr>
                  ) : (
                    paginatedSoftware.map((soft) => {
                      const isTogglingThis = togglingSoftwareId === soft.id;
                      return (
                        <tr key={soft.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="p-3.5">
                            <div className="font-bold text-white text-sm flex items-center gap-1.5">
                              <Package className="w-4 h-4 text-blue-400 shrink-0" />
                              {soft.name}
                            </div>
                            {soft.vendor && <span className="text-[10px] text-slate-400 block mt-0.5">Vendor: {soft.vendor}</span>}
                          </td>

                          <td className="p-3.5">
                            <span className="px-2 py-0.5 rounded bg-blue-950/90 text-blue-300 border border-blue-800 font-bold text-[10px] inline-block">
                              v{soft.version}
                            </span>
                            <div className="text-slate-300 text-[11px] mt-1">{soft.runtimeStack}</div>
                          </td>

                          <td className="p-3.5">
                            <div className="text-slate-300 text-[11px] font-mono">
                              <span className="text-slate-500">Path: </span>{soft.installPath}
                            </div>
                            <div className="text-slate-400 text-[10px] font-mono mt-0.5">
                              <span className="text-slate-500">Service: </span>{soft.serviceName}
                            </div>
                          </td>

                          <td className="p-3.5 font-mono">
                            <span className="text-orange-400 font-bold bg-[#1a2333] px-2 py-1 rounded border border-slate-700 text-[11px]">
                              Port {soft.port}
                            </span>
                          </td>

                          <td className="p-3.5 space-y-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {soft.status && soft.status !== 'ACTIVE' && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-blue-950 text-blue-300 border border-blue-800">
                                  <CheckCircle2 className="w-3 h-3" /> {soft.status}
                                </span>
                              )}

                              <span
                                className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${
                                  soft.isActive !== false
                                    ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800/80'
                                    : 'bg-slate-900 text-slate-400 border-slate-700'
                                }`}
                              >
                                <span className={`w-1.5 h-1.5 rounded-full ${soft.isActive !== false ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                                {soft.isActive !== false ? 'Active' : 'Inactive'}
                              </span>
                            </div>
                          </td>

                          <td className="p-3.5 text-right space-x-2">
                            <button
                              onClick={() => handleOpenEditSoftware(soft)}
                              title="Edit Software"
                              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                            >
                              <Edit2 className="w-3.5 h-3.5 inline" />
                            </button>
                            <button
                              onClick={() => handleToggleSoftware(soft.id)}
                              disabled={isTogglingThis}
                              title={soft.isActive !== false ? "Deactivate Software" : "Activate Software"}
                              className={`px-2.5 py-1 rounded text-xs font-mono font-bold inline-flex items-center gap-1.5 transition-colors border ${
                                soft.isActive !== false
                                  ? 'bg-slate-800 hover:bg-amber-950/80 text-slate-300 hover:text-amber-300 border-slate-700 hover:border-amber-700'
                                  : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-700'
                              } ${isTogglingThis ? 'opacity-70 cursor-wait' : ''}`}
                            >
                              {isTogglingThis ? (
                                <LoadingSpinner size="xs" variant={soft.isActive !== false ? 'slate' : 'accent'} inline />
                              ) : (
                                <Power className={`w-3.5 h-3.5 ${soft.isActive !== false ? 'text-slate-400' : 'text-emerald-400'}`} />
                              )}
                              <span>{soft.isActive !== false ? 'Deactivate' : 'Activate'}</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <Pagination
              currentPage={softwarePage}
              totalItems={filteredSoftware.length}
              pageSize={softwarePageSize}
              onPageChange={setSoftwarePage}
              onPageSizeChange={(s) => {
                setSoftwarePageSize(s);
                setSoftwarePage(1);
              }}
              pageSizeOptions={[10, 20, 50]}
            />
          </div>
        )
      )}

      {/* ================= TAB 4: OVERVIEW & ARCHITECTURE TOPOLOGY ================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6 font-mono text-xs">
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[10px] uppercase font-bold">TOTAL INFRA NODES</span>
                <Server className="w-4 h-4 text-emerald-400" />
              </div>
              <p className="text-3xl font-extrabold text-emerald-400 mt-2">{servers.length}</p>
              <div className="flex items-center justify-between text-xs text-slate-400 mt-1">
                <span>🏢 On-Prem: <strong className="text-orange-400">{onPremServersCount}</strong></span>
                <span>☁️ Cloud: <strong className="text-sky-400">{cloudServersCount}</strong></span>
              </div>
            </div>

            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[10px] uppercase font-bold">MULTI-CLOUD BREAKDOWN</span>
                <Cloud className="w-4 h-4 text-sky-400" />
              </div>
              <div className="space-y-1 mt-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-amber-400 font-bold">AWS</span>
                  <span className="text-white font-mono">{awsCount} instances</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-blue-400 font-bold">Azure</span>
                  <span className="text-white font-mono">{azureCount} instances</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-emerald-400 font-bold">GCP</span>
                  <span className="text-white font-mono">{gcpCount} instances</span>
                </div>
              </div>
            </div>

            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[10px] uppercase font-bold">COMPUTE CAPACITY</span>
                <Cpu className="w-4 h-4 text-blue-400" />
              </div>
              <p className="text-3xl font-extrabold text-blue-400 mt-2">{totalCores} vCPUs</p>
              <p className="text-xs text-slate-400 mt-1">{totalRam} GB RAM / {totalStorage} GB Disk</p>
            </div>

            <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[10px] uppercase font-bold">CATALOGED SOFTWARE</span>
                <Package className="w-4 h-4 text-purple-400" />
              </div>
              <p className="text-3xl font-extrabold text-purple-400 mt-2">{softwareList.length}</p>
              <p className="text-xs text-slate-500 mt-1">Application services & runtimes</p>
            </div>
          </div>

          {/* Full Topology Breakdown */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-6 rounded-lg space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Globe className="w-5 h-5 text-orange-400" /> Environment Deployment Architecture Matrix
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Cross-cutting relationship map between environments, physical/virtual servers, and deployed application binaries.
                </p>
              </div>
            </div>

            <div className="space-y-4 pt-2">
              {environmentProfiles.length === 0 ? (
                <div className="p-8 text-center text-slate-500 bg-black/30 border border-slate-200 dark:border-slate-800 rounded-lg space-y-2">
                  <Layers className="w-10 h-10 text-slate-600 mx-auto" />
                  <p className="font-bold text-slate-300">No Environment Topology Available</p>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Add servers, register software, and create an environment profile to view the live architecture topology matrix.
                  </p>
                </div>
              ) : (
                environmentProfiles.map((p) => {
                  const linkedSrvs = servers.filter((s) => p.serverIds.includes(s.id));
                  const linkedSoft = softwareList.filter((s) => p.softwareIds.includes(s.id));

                  return (
                    <div key={p.id} className="bg-black/50 border border-slate-200 dark:border-slate-800 rounded-lg p-4 space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800/80 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-base font-bold text-white">{p.name}</span>
                          <span className="px-2 py-0.5 rounded bg-orange-950 text-orange-400 text-[10px] font-bold border border-orange-800">
                            {p.type}
                          </span>
                          <span className="text-xs text-slate-400">Zone: {p.networkZone}</span>
                        </div>
                        <span className="text-[11px] text-slate-400">Owner: {p.ownerTeam}</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                        {/* Servers Column */}
                        <div className="space-y-2">
                          <span className="text-[10px] text-slate-400 uppercase font-bold flex items-center gap-1.5">
                            <Server className="w-3.5 h-3.5 text-orange-400" /> Linked Server Hosts ({linkedSrvs.length})
                          </span>
                          <div className="space-y-1.5">
                            {linkedSrvs.length === 0 ? (
                              <span className="text-[10px] text-slate-500 italic">No servers mapped to profile</span>
                            ) : (
                              linkedSrvs.map((s) => {
                                const isCloud = s.infrastructureType ? s.infrastructureType === 'CLOUD' : !!s.cloudProvider;
                                return (
                                  <div key={s.id} className="bg-[#121a28] p-2.5 rounded border border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs">
                                    <div>
                                      <div className="font-bold text-white flex items-center gap-1.5">
                                        {isCloud ? (
                                          <Cloud className="w-3.5 h-3.5 text-sky-400" />
                                        ) : (
                                          <Building className="w-3.5 h-3.5 text-orange-400" />
                                        )}
                                        {s.name}
                                        {isCloud && (
                                          <span className="text-[9px] px-1 py-0.2 rounded bg-sky-950 text-sky-300 border border-sky-800">
                                            {s.cloudProvider || 'Cloud'}
                                          </span>
                                        )}
                                      </div>
                                      <div className="text-[10px] text-slate-400">{s.operatingSystem} · {s.serverType}</div>
                                    </div>
                                    <div className="text-right">
                                      <span className="text-orange-400 font-bold">{s.hostIp}</span>
                                      <div className="text-[10px] text-slate-500">{s.cpuCores}C / {s.ramGb}GB</div>
                                    </div>
                                  </div>
                                );
                              })
                            )}
                          </div>
                        </div>

                        {/* Software Column */}
                        <div className="space-y-2">
                          <span className="text-[10px] text-slate-400 uppercase font-bold flex items-center gap-1.5">
                            <Package className="w-3.5 h-3.5 text-blue-400" /> Installed Software Stack ({linkedSoft.length})
                          </span>
                          <div className="space-y-1.5">
                            {linkedSoft.length === 0 ? (
                              <span className="text-[10px] text-slate-500 italic">No software mapped to profile</span>
                            ) : (
                              linkedSoft.map((s) => (
                                <div key={s.id} className="bg-[#121a28] p-2.5 rounded border border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs">
                                  <div>
                                    <div className="font-bold text-white">{s.name} <span className="text-blue-300 text-[10px]">v{s.version}</span></div>
                                    <div className="text-[10px] text-slate-400">{s.runtimeStack}</div>
                                  </div>
                                  <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-orange-400 font-mono text-[10px]">
                                    Port {s.port}
                                  </span>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADD / EDIT SERVER (ON-PREMISES & CLOUD) ================= */}
      {serverModalOpen && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-slate-700 rounded-xl max-w-2xl w-full font-mono text-xs relative shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-3 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => setServerModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>

              <span className="text-[10px] text-orange-400 uppercase font-bold">INFRASTRUCTURE INVENTORY</span>
              <h2 className="text-xl font-bold text-white mt-0.5">
                {editingServer ? 'Edit Infrastructure Details' : 'Add New Infrastructure'}
              </h2>
            </div>

            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" id="server-form" onSubmit={handleSubmitServer} className="flex flex-col flex-1 min-h-0">
              {/* Scrollable Body */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {/* Top Segmented Control: On-Premises vs Cloud */}
                <div className="bg-[#162032] p-1.5 rounded-lg border border-slate-700 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setServerForm({ ...serverForm, infrastructureType: 'ON_PREMISES' })}
                    className={`flex-1 py-2 rounded-md font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                      serverForm.infrastructureType === 'ON_PREMISES'
                        ? 'bg-orange-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Building className="w-4 h-4" />
                    <span>🏢 On-Premises Server</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setServerForm({ ...serverForm, infrastructureType: 'CLOUD' })}
                    className={`flex-1 py-2 rounded-md font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                      serverForm.infrastructureType === 'CLOUD'
                        ? 'bg-sky-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Cloud className="w-4 h-4" />
                    <span>☁️ Cloud Instance / VM</span>
                  </button>
                </div>

              {/* ================= CLOUD-SPECIFIC FIELDS ================= */}
              {serverForm.infrastructureType === 'CLOUD' && (
                <div className="bg-sky-950/20 border border-sky-900/60 p-3.5 rounded-lg space-y-3">
                  <span className="text-[10px] font-bold text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Cloud className="w-3.5 h-3.5" /> Cloud Provider & Instance Identity
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        CLOUD PROVIDER <span className="text-orange-500">*</span>
                      </label>
                      <select
                        value={serverForm.cloudProvider || 'AWS'}
                        onChange={(e) => setServerForm({ ...serverForm, cloudProvider: e.target.value as CloudProvider })}
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      >
                        <option value="AWS">Amazon Web Services (AWS)</option>
                        <option value="Azure">Microsoft Azure</option>
                        <option value="GCP">Google Cloud Platform (GCP)</option>
                        <option value="OCI">Oracle Cloud Infrastructure (OCI)</option>
                        <option value="Alibaba Cloud">Alibaba Cloud</option>
                        <option value="DigitalOcean">DigitalOcean</option>
                        <option value="Other">Other Provider</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        INSTANCE / VM NAME <span className="text-orange-500">*</span>
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        required
                        value={serverForm.name}
                        onChange={(e) => setServerForm({ ...serverForm, name: e.target.value })}
                        placeholder="e.g. uat-eks-worker-01"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        INSTANCE ID (AWS/Azure/GCP)
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={serverForm.instanceId || ''}
                        onChange={(e) => setServerForm({ ...serverForm, instanceId: e.target.value })}
                        placeholder="e.g. i-0a8b9c1d2e3f"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        REGION
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={serverForm.region || ''}
                        onChange={(e) => setServerForm({ ...serverForm, region: e.target.value })}
                        placeholder="e.g. us-east-1 / westeurope"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        AVAILABILITY ZONE
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={serverForm.availabilityZone || ''}
                        onChange={(e) => setServerForm({ ...serverForm, availabilityZone: e.target.value })}
                        placeholder="e.g. us-east-1a / zone-1"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        INSTANCE TYPE / SIZE
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={serverForm.instanceType || ''}
                        onChange={(e) => setServerForm({ ...serverForm, instanceType: e.target.value })}
                        placeholder="e.g. t3.2xlarge / Standard_D4s"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        PRIVATE IP / HOSTNAME <span className="text-orange-500">*</span>
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        required
                        value={serverForm.hostIp}
                        onChange={(e) => setServerForm({ ...serverForm, hostIp: e.target.value, privateIp: e.target.value })}
                        placeholder="e.g. 10.0.12.45"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        PUBLIC IP (OPTIONAL)
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={serverForm.publicIp || ''}
                        onChange={(e) => setServerForm({ ...serverForm, publicIp: e.target.value })}
                        placeholder="e.g. 54.210.45.12"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        VPC / SUBNET ID
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={serverForm.vpcSubnet || ''}
                        onChange={(e) => setServerForm({ ...serverForm, vpcSubnet: e.target.value })}
                        placeholder="e.g. vpc-0a12b / subnet-03f"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* ================= ON-PREMISES SPECIFIC FIELDS ================= */}
              {serverForm.infrastructureType === 'ON_PREMISES' && (
                <div className="bg-orange-950/20 border border-orange-900/60 p-3.5 rounded-lg space-y-3">
                  <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5" /> On-Premises Server & Physical Location
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        SERVER NAME / HOSTNAME <span className="text-orange-500">*</span>
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        required
                        value={serverForm.name}
                        onChange={(e) => setServerForm({ ...serverForm, name: e.target.value })}
                        placeholder="e.g. uat-core-app01.internal"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        HOST / IP ADDRESS <span className="text-orange-500">*</span>
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        required
                        value={serverForm.hostIp}
                        onChange={(e) => setServerForm({ ...serverForm, hostIp: e.target.value })}
                        placeholder="e.g. 192.168.10.42"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        DATA CENTER / PHYSICAL LOCATION
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={serverForm.datacenter || ''}
                        onChange={(e) => setServerForm({ ...serverForm, datacenter: e.target.value })}
                        placeholder="e.g. Chicago DC-1 / Frankfurt Site B"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                        RACK / UNIT / SLOT
                      </label>
                      <input autoComplete="off" data-lpignore="true"
                        type="text"
                        value={serverForm.rackUnit || ''}
                        onChange={(e) => setServerForm({ ...serverForm, rackUnit: e.target.value })}
                        placeholder="e.g. Rack A-04, Unit 12-14"
                        className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* ================= COMMON SPECS & SOFTWARE FIELDS ================= */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    SERVER TYPE
                  </label>
                  <select
                    value={serverForm.serverType}
                    onChange={(e) => setServerForm({ ...serverForm, serverType: e.target.value as ServerType })}
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  >
                    <option value="Application Server">Application Server</option>
                    <option value="Database Server">Database Server</option>
                    <option value="Web Server">Web Server</option>
                    <option value="Cache Server">Cache Server</option>
                    <option value="Load Balancer / Proxy">Load Balancer / Proxy</option>
                    <option value="Message Broker">Message Broker</option>
                    <option value="API Gateway">API Gateway</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    OPERATING SYSTEM
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={serverForm.operatingSystem}
                    onChange={(e) => setServerForm({ ...serverForm, operatingSystem: e.target.value })}
                    placeholder="e.g. Ubuntu 22.04 LTS / RHEL 9"
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    CPU CORES
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="number"
                    min="1"
                    value={serverForm.cpuCores}
                    onChange={(e) => setServerForm({ ...serverForm, cpuCores: parseInt(e.target.value) || 1 })}
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    RAM (GB)
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="number"
                    min="1"
                    value={serverForm.ramGb}
                    onChange={(e) => setServerForm({ ...serverForm, ramGb: parseInt(e.target.value) || 1 })}
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    DISK (GB)
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="number"
                    min="1"
                    value={serverForm.storageGb}
                    onChange={(e) => setServerForm({ ...serverForm, storageGb: parseInt(e.target.value) || 1 })}
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    ENVIRONMENT ALLOCATION
                  </label>
                  <select
                    value={serverForm.environmentName || 'Development'}
                    onChange={(e) => setServerForm({ ...serverForm, environmentName: e.target.value })}
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  >
                    <option value="Development">Development</option>
                    <option value="QA / Testing">QA / Testing</option>
                    <option value="UAT / Staging">UAT / Staging</option>
                    <option value="Production">Production</option>
                    <option value="Performance / Stress">Performance / Stress</option>
                    <option value="Disaster Recovery (DR)">Disaster Recovery (DR)</option>
                    <option value="Sandbox">Sandbox</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    STATUS
                  </label>
                  <select
                    value={serverForm.status}
                    onChange={(e) => setServerForm({ ...serverForm, status: e.target.value as any })}
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  >
                    <option value="ONLINE">ONLINE</option>
                    <option value="MAINTENANCE">MAINTENANCE</option>
                    <option value="OFFLINE">OFFLINE</option>
                    <option value="PROVISIONING">PROVISIONING</option>
                  </select>
                </div>
              </div>

              {/* Installed Software Multi-Select */}
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  INSTALLED SOFTWARE (MAPPED FROM CATALOG)
                </label>
                {softwareList.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic">No software registered in catalog yet.</p>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 bg-[#090d14] p-3 rounded border border-slate-200 dark:border-slate-800 max-h-36 overflow-y-auto">
                    {softwareList.map((soft) => {
                      const isSelected = (serverForm.installedSoftwareIds || []).includes(soft.id);
                      return (
                        <label
                          key={soft.id}
                          className={`flex items-center gap-2 p-2 rounded cursor-pointer border text-[11px] transition-colors ${
                            isSelected
                              ? 'bg-blue-950/80 border-blue-700 text-white'
                              : 'bg-[#121c2d] border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => {
                              const curr = serverForm.installedSoftwareIds || [];
                              if (e.target.checked) {
                                setServerForm({ ...serverForm, installedSoftwareIds: [...curr, soft.id] });
                              } else {
                                setServerForm({ ...serverForm, installedSoftwareIds: curr.filter((id) => id !== soft.id) });
                              }
                            }}
                            className="rounded border-slate-700 text-orange-600 focus:ring-0"
                          />
                          <span className="truncate">{soft.name} (v{soft.version})</span>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  DESCRIPTION / OPERATIONAL NOTES
                </label>
                <textarea
                  rows={2}
                  value={serverForm.description}
                  onChange={(e) => setServerForm({ ...serverForm, description: e.target.value })}
                  placeholder="Operational notes regarding this host / instance..."
                  className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                />
              </div>

              </div>

              {/* Fixed Footer */}
              <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3 z-10">
                <button
                  type="button"
                  onClick={() => setServerModalOpen(false)}
                  disabled={isSavingServer}
                  className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold disabled:opacity-50"
                >
                  CANCEL
                </button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingServer}
                  loadingText="SAVING..."
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold shadow-[0_0_14px_rgba(249,115,22,0.4)]"
                >
                  {editingServer ? 'SAVE CHANGES' : 'CREATE INFRASTRUCTURE'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADD / EDIT SOFTWARE ================= */}
      {softwareModalOpen && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-slate-700 rounded-lg max-w-xl w-full font-mono text-xs relative shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-3 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => setSoftwareModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>

              <span className="text-[10px] text-blue-400 uppercase font-bold">SOFTWARE CATALOG REGISTRATION</span>
              <h2 className="text-lg font-bold text-white mt-0.5">
                {editingSoftware ? 'Edit Software Details' : 'Register Software / Component'}
              </h2>
            </div>

            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSubmitSoftware} className="flex flex-col flex-1 min-h-0">
              {/* Scrollable Body */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      SOFTWARE / APP NAME <span className="text-orange-500">*</span>
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      required
                      value={softwareForm.name}
                      onChange={(e) => setSoftwareForm({ ...softwareForm, name: e.target.value })}
                      placeholder="e.g. TEM Backend Core"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      VERSION <span className="text-orange-500">*</span>
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      required
                      value={softwareForm.version}
                      onChange={(e) => setSoftwareForm({ ...softwareForm, version: e.target.value })}
                      placeholder="e.g. 2.4.1-LTS"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      INSTALLATION PATH
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={softwareForm.installPath}
                      onChange={(e) => setSoftwareForm({ ...softwareForm, installPath: e.target.value })}
                      placeholder="e.g. /opt/smartqe/tem-backend"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      PORT(S)
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={softwareForm.port}
                      onChange={(e) => setSoftwareForm({ ...softwareForm, port: e.target.value })}
                      placeholder="e.g. 8000 or 80, 443"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      SERVICE NAME / DAEMON
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={softwareForm.serviceName}
                      onChange={(e) => setSoftwareForm({ ...softwareForm, serviceName: e.target.value })}
                      placeholder="e.g. tem-api.service"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      RUNTIME / TECH STACK
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={softwareForm.runtimeStack}
                      onChange={(e) => setSoftwareForm({ ...softwareForm, runtimeStack: e.target.value })}
                      placeholder="e.g. Python 3.12 / FastAPI"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    VENDOR / MAINTAINER
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={softwareForm.vendor}
                    onChange={(e) => setSoftwareForm({ ...softwareForm, vendor: e.target.value })}
                    placeholder="e.g. Internal SmartQE Team"
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              {/* Fixed Footer */}
              <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3 z-10">
                <button
                  type="button"
                  onClick={() => setSoftwareModalOpen(false)}
                  disabled={isSavingSoftware}
                  className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold disabled:opacity-50"
                >
                  CANCEL
                </button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingSoftware}
                  loadingText="SAVING..."
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold shadow-[0_0_14px_rgba(249,115,22,0.4)]"
                >
                  {editingSoftware ? 'SAVE CHANGES' : 'REGISTER SOFTWARE'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADD / EDIT ENVIRONMENT PROFILE ================= */}
      {profileModalOpen && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-slate-700 rounded-lg max-w-2xl w-full font-mono text-xs relative shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-3 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => setProfileModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>

              <span className="text-[10px] text-orange-400 uppercase font-bold">ENVIRONMENT TOPOLOGY MAPPING</span>
              <h2 className="text-lg font-bold text-white mt-0.5">
                {editingProfile ? 'Edit Environment Profile' : 'New Environment Profile'}
              </h2>
            </div>

            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSubmitProfile} className="flex flex-col flex-1 min-h-0">
              {/* Scrollable Body */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      ENVIRONMENT NAME <span className="text-orange-500">*</span>
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      required
                      value={profileForm.name}
                      onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                      placeholder="e.g. QA Core, Ashish G"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      ENVIRONMENT TYPE
                    </label>
                    <select
                      value={profileForm.type}
                      onChange={(e) => setProfileForm({ ...profileForm, type: e.target.value as EnvironmentType })}
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    >
                      <option value="Development">Development</option>
                      <option value="QA / Testing">QA / Testing</option>
                      <option value="UAT / Staging">UAT / Staging</option>
                      <option value="Production">Production</option>
                      <option value="Performance / Stress">Performance / Stress</option>
                      <option value="Disaster Recovery (DR)">Disaster Recovery (DR)</option>
                      <option value="Sandbox">Sandbox</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      INITIAL STATUS <span className="text-orange-500">*</span>
                    </label>
                    <select
                      value={profileForm.status}
                      onChange={(e) => setProfileForm({ ...profileForm, status: e.target.value as EnvironmentStatus })}
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-orange-500"
                    >
                      <option value="HEALTHY">HEALTHY</option>
                      <option value="DEGRADED">DEGRADED</option>
                      <option value="MAINTENANCE">MAINTENANCE</option>
                      <option value="DOWN">DOWN</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      OWNER TEAM / DEPARTMENT
                    </label>
                    <input autoComplete="off" data-lpignore="true"
                      type="text"
                      value={profileForm.ownerTeam}
                      onChange={(e) => setProfileForm({ ...profileForm, ownerTeam: e.target.value })}
                      placeholder="e.g. Core Banking Platform QE"
                      className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    NETWORK / VPC ZONE
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={profileForm.networkZone}
                    onChange={(e) => setProfileForm({ ...profileForm, networkZone: e.target.value })}
                    placeholder="e.g. VPC-QA-EAST (10.240.20.0/24)"
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    ENVIRONMENT DESCRIPTION
                  </label>
                  <textarea
                    rows={2}
                    value={profileForm.description}
                    onChange={(e) => setProfileForm({ ...profileForm, description: e.target.value })}
                    placeholder="Primary objective, test coverage, and SLAs of this environment..."
                    className="w-full bg-[#161f2e] border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                {/* Server Multi-Select */}
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 uppercase font-bold block">
                    SELECT ASSOCIATED SERVERS ({profileForm.serverIds.length} Selected)
                  </label>
                  <div className="max-h-36 overflow-y-auto bg-[#161f2e] border border-slate-700 rounded p-2.5 space-y-1.5">
                    {servers.length === 0 ? (
                      <p className="text-slate-500 text-xs">No servers available. Add a server first.</p>
                    ) : (
                      servers.map((s) => {
                        const isSelected = profileForm.serverIds.includes(s.id);
                        return (
                          <label
                            key={s.id}
                            className={`flex items-center justify-between p-2 rounded cursor-pointer transition-colors ${
                              isSelected ? 'bg-orange-950/60 border border-orange-700/80 text-white' : 'hover:bg-slate-800/60 text-slate-300'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    setProfileForm({
                                      ...profileForm,
                                      serverIds: [...profileForm.serverIds, s.id],
                                    });
                                  } else {
                                    setProfileForm({
                                      ...profileForm,
                                      serverIds: profileForm.serverIds.filter((id) => id !== s.id),
                                    });
                                  }
                                }}
                                className="accent-orange-500"
                              />
                              <span className="font-bold">{s.name}</span>
                              <span className="text-slate-400 text-[10px]">({s.hostIp})</span>
                            </div>
                            <span className="text-[10px] text-orange-400">{s.serverType}</span>
                          </label>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* Software Multi-Select */}
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 uppercase font-bold block">
                    SELECT ASSOCIATED SOFTWARE ({profileForm.softwareIds.length} Selected)
                  </label>
                  <div className="max-h-36 overflow-y-auto bg-[#161f2e] border border-slate-700 rounded p-2.5 space-y-1.5">
                    {softwareList.length === 0 ? (
                      <p className="text-slate-500 text-xs">No software available. Register software first.</p>
                    ) : (
                      softwareList.map((soft) => {
                        const isSelected = profileForm.softwareIds.includes(soft.id);
                        return (
                          <label
                            key={soft.id}
                            className={`flex items-center justify-between p-2 rounded cursor-pointer transition-colors ${
                              isSelected ? 'bg-blue-950/60 border border-blue-700/80 text-white' : 'hover:bg-slate-800/60 text-slate-300'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    setProfileForm({
                                      ...profileForm,
                                      softwareIds: [...profileForm.softwareIds, soft.id],
                                    });
                                  } else {
                                    setProfileForm({
                                      ...profileForm,
                                      softwareIds: profileForm.softwareIds.filter((id) => id !== soft.id),
                                    });
                                  }
                                }}
                                className="accent-orange-500"
                              />
                              <span className="font-bold">{soft.name}</span>
                              <span className="text-blue-300 text-[10px]">v{soft.version}</span>
                            </div>
                            <span className="text-[10px] text-orange-400">Port {soft.port}</span>
                          </label>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>

              {/* Fixed Footer */}
              <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3 z-10">
                <button
                  type="button"
                  onClick={() => setProfileModalOpen(false)}
                  disabled={isSavingProfile}
                  className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold disabled:opacity-50"
                >
                  CANCEL
                </button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingProfile}
                  loadingText="SAVING..."
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold shadow-[0_0_14px_rgba(249,115,22,0.4)]"
                >
                  {editingProfile ? 'SAVE PROFILE' : 'CREATE PROFILE'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: ARCHITECTURE BLUEPRINT INSPECTOR ================= */}
      {inspectProfile && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-orange-500/60 rounded-xl max-w-3xl w-full font-mono text-xs relative shadow-[0_0_50px_rgba(249,115,22,0.2)] max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-4 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => setInspectProfile(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>

              <span className="text-[10px] text-orange-400 uppercase font-bold tracking-widest">
                ENVIRONMENT TOPOLOGY BLUEPRINT
              </span>
              <div className="flex items-center gap-3 mt-1">
                <h2 className="text-2xl font-bold text-white">{inspectProfile.name}</h2>
                <span className="px-2.5 py-0.5 rounded bg-orange-950 text-orange-400 text-xs font-bold border border-orange-800">
                  {inspectProfile.type}
                </span>
                <span
                  className={`px-2.5 py-0.5 rounded text-xs font-bold border ${
                    inspectProfile.status === 'HEALTHY'
                      ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                      : inspectProfile.status === 'DEGRADED'
                      ? 'bg-amber-950 text-amber-400 border-amber-800'
                      : inspectProfile.status === 'MAINTENANCE'
                      ? 'bg-yellow-950 text-yellow-400 border-yellow-800'
                      : 'bg-red-950 text-red-400 border-red-800'
                  }`}
                >
                  {inspectProfile.status}
                </span>
              </div>
              <p className="text-slate-300 font-sans text-xs mt-2">{inspectProfile.description}</p>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* Network & Zone Details */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-black/40 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-slate-500 text-[9px] uppercase block">OWNER TEAM</span>
                  <span className="text-white font-bold">{inspectProfile.ownerTeam}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[9px] uppercase block">NETWORK ZONE</span>
                  <span className="text-orange-400 font-bold">{inspectProfile.networkZone}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[9px] uppercase block">LAST SYNCED</span>
                  <span className="text-slate-300">{inspectProfile.updatedAt}</span>
                </div>
              </div>

              {/* Deployed Servers Breakdown */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-200 dark:border-slate-800/80 pb-1.5">
                  <Server className="w-4 h-4 text-orange-400" /> Linked Server Hosts ({inspectProfile.serverIds.length})
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {servers
                    .filter((s) => inspectProfile.serverIds.includes(s.id))
                    .map((srv) => (
                      <div key={srv.id} className="bg-[#161f2e] border border-slate-700/80 p-3.5 rounded space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-bold text-white text-sm">{srv.name}</div>
                            <div className="text-[11px] text-orange-400">{srv.hostIp}</div>
                          </div>
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-emerald-400 font-bold text-[9px]">
                            {srv.status}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-300">OS: {srv.operatingSystem}</div>
                        <div className="text-[10px] text-slate-400">
                          Specs: {srv.cpuCores} Cores · {srv.ramGb} GB RAM · {srv.storageGb} GB Disk
                        </div>
                        <div className="text-[9px] text-slate-500">Region: {srv.datacenter}</div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Deployed Software Breakdown */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-200 dark:border-slate-800/80 pb-1.5">
                  <Package className="w-4 h-4 text-blue-400" /> Active Software Catalog Stack ({inspectProfile.softwareIds.length})
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {softwareList
                    .filter((s) => inspectProfile.softwareIds.includes(s.id))
                    .map((soft) => (
                      <div key={soft.id} className="bg-[#161f2e] border border-slate-700/80 p-3.5 rounded space-y-1.5">
                        <div className="flex justify-between items-start">
                          <div className="font-bold text-white text-sm">{soft.name}</div>
                          <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 font-bold text-[10px] border border-blue-800">
                            v{soft.version}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-300">Stack: {soft.runtimeStack}</div>
                        <div className="text-[10px] text-slate-400">Path: {soft.installPath}</div>
                        <div className="flex justify-between items-center pt-1 text-[10px]">
                          <span className="text-orange-400 font-bold">Port: {soft.port}</span>
                          <span className="text-slate-500">{soft.serviceName}</span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>

            {/* Fixed Footer Close */}
            <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center justify-end z-10">
              <button
                onClick={() => setInspectProfile(null)}
                className="px-5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                CLOSE BLUEPRINT
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CANNOT DEACTIVATE ENVIRONMENT MODAL */}
      {cannotDeactivateModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 dark:bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#0f1724] border border-red-800/80 rounded-xl p-6 max-w-md w-full shadow-2xl space-y-4 font-mono">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-lg bg-red-950/80 border border-red-800 text-red-400 shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-white tracking-tight">
                  Cannot Deactivate Environment
                </h3>
                <p className="text-xs text-slate-300 font-sans leading-relaxed">
                  Environment <strong className="text-white font-mono font-bold">{cannotDeactivateModal.environmentName}</strong> has one or more confirmed, future, or conflicting reservations. Hence, this environment cannot be deactivated.
                </p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setCannotDeactivateModal({ isOpen: false, environmentName: '' })}
                className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors border border-slate-700 font-mono"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
