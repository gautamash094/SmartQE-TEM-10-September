import React, { useState } from 'react';
import { useTEM } from '../context/TEMContext';
import { RiskBadge } from '../components/common/RiskBadge';
import { ReleaseModal } from '../components/features/ReleaseModal';
import { CardSkeleton } from '../components/common/Skeleton';
import { Plus, Rocket } from 'lucide-react';
import { ReleaseStatus } from '../types';

export const ReleasesPage: React.FC = () => {
  const { releases, isLoading } = useTEM();
  const [isReleaseModalOpen, setIsReleaseModalOpen] = useState<boolean>(false);

  const columns: { status: ReleaseStatus; label: string }[] = [
    { status: 'SCHEDULED', label: 'SCHEDULED' },
    { status: 'IN_PROGRESS', label: 'IN PROGRESS' },
    { status: 'DEPLOYED', label: 'DEPLOYED' },
  ];

  return (
    <div className="space-y-6">
      {/* Header & Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            CHANGE PIPELINE
          </span>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Releases</h1>
          <p className="text-sm text-slate-400 mt-1">
            Track every deployment tied to an environment, its risk, and its lead.
          </p>
        </div>

        <button
          onClick={() => setIsReleaseModalOpen(true)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_16px_rgba(249,115,22,0.4)] shrink-0"
        >
          <Plus className="w-4 h-4" /> NEW RELEASE
        </button>
      </div>

      {/* Kanban Board Columns */}
      {isLoading ? (
        <CardSkeleton count={3} className="grid grid-cols-1 md:grid-cols-3 gap-6 min-h-[400px]" />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {columns.map((col) => {
          const colReleases = releases.filter((r) => r.status === col.status);

          return (
            <div
              key={col.status}
              className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-4 flex flex-col min-h-[500px]"
            >
              {/* Column Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                  {col.label}
                </h3>
                <span className="text-xs font-mono font-bold text-slate-400 px-2 py-0.5 rounded bg-slate-900 border border-slate-200 dark:border-slate-800">
                  {colReleases.length}
                </span>
              </div>

              {/* Cards list */}
              <div className="space-y-3 flex-1 overflow-y-auto pr-1">
                {colReleases.map((rel) => (
                  <div
                    key={rel.id}
                    className="p-4 rounded-lg bg-[#141e2e] border border-slate-200 dark:border-slate-800 hover:border-slate-700 transition-all shadow-md space-y-3 group"
                  >
                    {/* Top Row: Version & Risk */}
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-xs font-mono font-bold text-orange-400">
                        <Rocket className="w-3.5 h-3.5" />
                        {rel.version}
                      </span>
                      <RiskBadge risk={rel.risk} />
                    </div>

                    {/* Title */}
                    <h4 className="text-sm font-bold text-white group-hover:text-orange-300 transition-colors">
                      {rel.name}
                    </h4>

                    {/* Environment */}
                    <p className="text-xs font-mono text-slate-400">{rel.environmentName}</p>

                    {/* Lead & Change Ref & Date */}
                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-2 border-t border-slate-200 dark:border-slate-800/80">
                      <span>
                        Lead · <strong className="text-slate-300 font-sans">{rel.lead}</strong> · {rel.changeRef}
                      </span>
                      <span>{rel.scheduledDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    )}

      {/* Schedule Release Modal */}
      <ReleaseModal isOpen={isReleaseModalOpen} onClose={() => setIsReleaseModalOpen(false)} />
    </div>
  );
};
