import React, { useState } from 'react';
import { useTEM } from '../context/TEMContext';
import { IncidentModal } from '../components/features/IncidentModal';
import { Pagination } from '../components/common/Pagination';
import { TableSkeleton } from '../components/common/Skeleton';
import { Plus } from 'lucide-react';
import { IncidentSeverity } from '../types';

export const IncidentsPage: React.FC = () => {
  const { incidents, isLoading } = useTEM();
  const [selectedSevFilter, setSelectedSevFilter] = useState<string>('ALL');
  const [isIncidentModalOpen, setIsIncidentModalOpen] = useState<boolean>(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Severity counts
  const countSev1 = incidents.filter((i) => i.severity === 'SEV1').length;
  const countSev2 = incidents.filter((i) => i.severity === 'SEV2').length;
  const countSev3 = incidents.filter((i) => i.severity === 'SEV3').length;
  const countSev4 = incidents.filter((i) => i.severity === 'SEV4').length;

  const filteredIncidents = incidents.filter((inc) => {
    if (selectedSevFilter === 'ALL') return true;
    return inc.severity === selectedSevFilter;
  });

  const paginatedIncidents = filteredIncidents.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleSevFilterChange = (sev: string) => {
    setSelectedSevFilter(sev);
    setCurrentPage(1);
  };

  return (
    <div className="space-y-6">
      {/* Header & Raise Incident Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            ALERTING
          </span>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Incidents</h1>
          <p className="text-sm text-slate-400 mt-1">
            Active and recent incidents impacting your test environment fleet.
          </p>
        </div>

        <button
          onClick={() => setIsIncidentModalOpen(true)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_16px_rgba(249,115,22,0.4)] shrink-0"
        >
          <Plus className="w-4 h-4" /> RAISE INCIDENT
        </button>
      </div>

      {/* 4 Severity Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* SEV1 */}
        <div
          onClick={() => handleSevFilterChange('SEV1')}
          className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg cursor-pointer hover:border-slate-700 transition-all"
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
            SEV1
          </span>
          <div className="text-3xl font-extrabold text-red-500 font-mono mt-2">{countSev1}</div>
        </div>

        {/* SEV2 */}
        <div
          onClick={() => handleSevFilterChange('SEV2')}
          className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg cursor-pointer hover:border-slate-700 transition-all"
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
            SEV2
          </span>
          <div className="text-3xl font-extrabold text-amber-500 font-mono mt-2">{countSev2}</div>
        </div>

        {/* SEV3 */}
        <div
          onClick={() => handleSevFilterChange('SEV3')}
          className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg cursor-pointer hover:border-slate-700 transition-all"
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
            SEV3
          </span>
          <div className="text-3xl font-extrabold text-amber-400 font-mono mt-2">{countSev3}</div>
        </div>

        {/* SEV4 */}
        <div
          onClick={() => handleSevFilterChange('SEV4')}
          className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg cursor-pointer hover:border-slate-700 transition-all"
        >
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
            SEV4
          </span>
          <div className="text-3xl font-extrabold text-slate-500 font-mono mt-2">{countSev4}</div>
        </div>
      </div>

      {/* Filter Pills */}
      <div className="flex items-center gap-2">
        {['ALL', 'SEV1', 'SEV2', 'SEV3', 'SEV4'].map((sev) => (
          <button
            key={sev}
            onClick={() => handleSevFilterChange(sev)}
            className={`px-3 py-1.5 rounded text-xs font-mono font-semibold uppercase transition-colors ${
              selectedSevFilter === sev
                ? 'bg-orange-600 text-white shadow-sm'
                : 'bg-[#0f1724] text-slate-400 hover:text-white border border-slate-200 dark:border-slate-800'
            }`}
          >
            {sev}
          </button>
        ))}
      </div>

      {/* Incidents Data Table */}
      {isLoading ? (
        <TableSkeleton rows={pageSize} columns={8} />
      ) : (
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse font-mono text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-950/40">
                  <th className="py-3 px-4">TICKET</th>
                  <th className="py-3 px-4">SEVERITY</th>
                  <th className="py-3 px-4">TITLE</th>
                  <th className="py-3 px-4">ENVIRONMENT</th>
                  <th className="py-3 px-4">ASSIGNEE</th>
                  <th className="py-3 px-4">ITSM SYNC</th>
                  <th className="py-3 px-4">STATUS</th>
                  <th className="py-3 px-4">OPENED</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                {paginatedIncidents.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-500">
                      No incidents matching this severity filter.
                    </td>
                  </tr>
                ) : (
                  paginatedIncidents.map((inc, idx) => {
                    const itsmProvider = 'ServiceNow';
                    const externalKey = `INC009${100 + idx * 3}`;
                    const externalUrl = `https://smartqe.service-now.com/nav_to.do?uri=incident.do?sys_id=${externalKey}`;

                    return (
                      <tr key={inc.id} className="hover:bg-[#152032] transition-colors">
                        <td className="py-3.5 px-4 font-bold text-slate-300">{inc.id}</td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`inline-flex items-center gap-1 font-bold text-[10px] px-2 py-0.5 rounded border ${
                              inc.severity === 'SEV1'
                                ? 'bg-red-950/60 border-red-800 text-red-400'
                                : inc.severity === 'SEV2'
                                ? 'bg-amber-950/60 border-amber-800 text-amber-400'
                                : 'bg-amber-950/40 border-amber-800/60 text-amber-300'
                            }`}
                          >
                            ▲ {inc.severity}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 font-sans font-bold text-white">{inc.title}</td>
                        <td className="py-3.5 px-4 text-slate-300">{inc.environmentName}</td>
                        <td className="py-3.5 px-4 text-slate-300 font-sans">{inc.assignee}</td>
                        <td className="py-3.5 px-4">
                          <a
                            href={externalUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-900 border border-slate-700 hover:border-orange-500 text-[10px] font-bold text-orange-400 hover:text-orange-300 transition-colors"
                            title={`Open ${externalKey} in ${itsmProvider}`}
                          >
                            <span>{itsmProvider}</span>
                            <span className="text-white">{externalKey}</span>
                            <span className="text-emerald-400">⚡</span>
                          </a>
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold border ${
                              inc.status === 'OPEN'
                                ? 'bg-slate-900 text-slate-300 border-slate-700'
                                : inc.status === 'INVESTIGATING'
                                ? 'bg-amber-950/40 text-amber-400 border-amber-800'
                                : 'bg-emerald-950/40 text-emerald-400 border-emerald-800'
                            }`}
                          >
                            {inc.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-400">{inc.openedAt}</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={currentPage}
            totalItems={filteredIncidents.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(size) => {
              setPageSize(size);
              setCurrentPage(1);
            }}
            pageSizeOptions={[10, 20, 50]}
          />
        </div>
      )}

      {/* Raise Incident Modal */}
      <IncidentModal isOpen={isIncidentModalOpen} onClose={() => setIsIncidentModalOpen(false)} />
    </div>
  );
};
