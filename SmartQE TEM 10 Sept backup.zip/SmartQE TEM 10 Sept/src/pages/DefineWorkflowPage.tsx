import React, { useState, useEffect, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import { useAuth } from '../context/AuthContext';
import {
  workflowService,
  Workflow,
  WorkflowApproverInput,
  WorkflowCreatePayload,
  WorkflowUpdatePayload,
  TEM_SERVICES,
  TEMServiceCode,
} from '../services/workflowService';
import { userService, User } from '../services/userService';
import { portfolioService, BusinessUnit, ApplicationEntity } from '../services/portfolioService';
import { environmentDetailsService } from '../services/environmentDetailsService';
import { EnvironmentProfile } from '../types/environmentDetails';
import {
  GitFork,
  ArrowRight,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Search,
  Filter,
  Building2,
  Cpu,
  AppWindow,
  Layers,
  ArrowUp,
  ArrowDown,
  X,
  Shield,
  Clock,
  Sparkles,
  ChevronRight,
  UserCheck,
} from 'lucide-react';
import { ButtonLoader } from '../components/common/ButtonLoader';
import { TableSkeleton } from '../components/common/Skeleton';
import { Pagination } from '../components/common/Pagination';

export const DefineWorkflowPage: React.FC = () => {
  const { showToast } = useTEM();
  const { currentUser } = useAuth();

  const isSuperAdmin = useMemo(() => {
    if (!currentUser) return false;
    return (
      Boolean(currentUser.isSuperAdmin) ||
      currentUser.username.toLowerCase() === 'admin' ||
      currentUser.email?.toLowerCase() === 'admin@tem.com' ||
      (currentUser.roles || []).some((r) => r.name.toLowerCase().trim() === 'super admin')
    );
  }, [currentUser]);

  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>([]);
  const [environments, setEnvironments] = useState<EnvironmentProfile[]>([]);
  const [applications, setApplications] = useState<ApplicationEntity[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedBUFilter, setSelectedBUFilter] = useState<string>('ALL');
  const [selectedServiceFilter, setSelectedServiceFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [page, setPage] = useState<number>(1);
  const pageSize = 10;

  // Add / Edit Modal State
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingWorkflow, setEditingWorkflow] = useState<Workflow | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');

  // Form State
  const [selectedBUId, setSelectedBUId] = useState<string>('');
  const [selectedEnvId, setSelectedEnvId] = useState<string>('');
  const [selectedAppId, setSelectedAppId] = useState<string>('');
  const [selectedServiceCode, setSelectedServiceCode] = useState<TEMServiceCode | ''>('');
  const [approverSteps, setApproverSteps] = useState<{ userId: string }[]>([]);
  const [isActive, setIsActive] = useState<boolean>(true);

  // Delete Modal State
  const [deleteConfirmWorkflow, setDeleteConfirmWorkflow] = useState<Workflow | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Load Data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [fetchedWorkflows, fetchedUsers, fetchedBUs, fetchedApps] = await Promise.all([
        workflowService.getWorkflows(),
        userService.getUsers(),
        portfolioService.getBusinessUnits(),
        portfolioService.getApplications(),
      ]);

      const fetchedEnvs = environmentDetailsService.getProfiles();

      setWorkflows(fetchedWorkflows);
      setUsers(fetchedUsers);
      setBusinessUnits(fetchedBUs.filter((bu) => bu.isActive !== false && bu.status !== 'INACTIVE'));
      setEnvironments(fetchedEnvs.filter((env) => env.isActive !== false));
      setApplications(fetchedApps.filter((app) => app.isActive !== false && app.status !== 'INACTIVE'));
    } catch (err: any) {
      showToast(err.message || 'Failed to load workflow configuration data', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // User's BU context resolution
  const currentUserObj = useMemo(() => {
    if (!currentUser) return null;
    return (
      users.find(
        (u) =>
          u.id === currentUser.id ||
          u.username.toLowerCase() === currentUser.username.toLowerCase() ||
          (currentUser.email && u.email?.toLowerCase() === currentUser.email.toLowerCase())
      ) || currentUser
    );
  }, [currentUser, users]);

  const currentUserBUId = useMemo(() => {
    if (!currentUserObj) return null;
    const obj = currentUserObj as any;
    return obj.businessUnitId || obj.businessUnit?.id || null;
  }, [currentUserObj]);

  const currentUserBUName = useMemo(() => {
    if (!currentUserObj) return null;
    const obj = currentUserObj as any;
    return obj.businessUnit?.name || null;
  }, [currentUserObj]);

  // Active BUs
  const activeBUs = useMemo(() => {
    return businessUnits.filter((b) => b.isActive !== false && b.status !== 'INACTIVE');
  }, [businessUnits]);

  // Allowed BUs for current user (Super Admin has global access to all active BUs; normal user/admin is scoped to their tagged BU)
  const userAllowedBUs = useMemo(() => {
    if (isSuperAdmin) return activeBUs;
    if (!currentUserBUId && !currentUserBUName) return activeBUs;

    const matched = activeBUs.filter(
      (b) =>
        (currentUserBUId && (b.id === currentUserBUId || b.id.toLowerCase() === currentUserBUId.toLowerCase())) ||
        (currentUserBUName && b.name.toLowerCase().trim() === currentUserBUName.toLowerCase().trim())
    );

    return matched.length > 0 ? matched : activeBUs;
  }, [activeBUs, isSuperAdmin, currentUserBUId, currentUserBUName]);

  // Visible Workflows (Strict BU Isolation: non-super-admin users only see workflows belonging to their tagged BU)
  const userVisibleWorkflows = useMemo(() => {
    if (isSuperAdmin) return workflows;

    // If user is not tagged to any BU, fallback to all workflows
    if (!currentUserBUId && !currentUserBUName && userAllowedBUs.length === activeBUs.length) {
      return workflows;
    }

    const allowedBUIds = new Set(userAllowedBUs.map((b) => b.id.toLowerCase()));
    const allowedBUNames = new Set(userAllowedBUs.map((b) => b.name.toLowerCase().trim()));

    return workflows.filter((w) => {
      const buIdMatch =
        w.buId &&
        (allowedBUIds.has(w.buId.toLowerCase()) ||
          (currentUserBUId && w.buId.toLowerCase() === currentUserBUId.toLowerCase()));
      const buNameMatch =
        w.buName &&
        (allowedBUNames.has(w.buName.toLowerCase().trim()) ||
          (currentUserBUName && w.buName.toLowerCase().trim() === currentUserBUName.toLowerCase().trim()));
      return Boolean(buIdMatch || buNameMatch);
    });
  }, [workflows, isSuperAdmin, userAllowedBUs, currentUserBUId, currentUserBUName, activeBUs]);

  // Selected BU object in Modal
  const currentSelectedBU = useMemo(() => {
    return activeBUs.find((b) => b.id === selectedBUId || b.name.toLowerCase() === selectedBUId.toLowerCase());
  }, [activeBUs, selectedBUId]);

  // Active Environments
  const activeEnvironments = useMemo(() => {
    return environments.filter((e) => e.isActive !== false);
  }, [environments]);

  // Applications filtered by selected BU context
  const applicationsForSelectedBU = useMemo(() => {
    if (!selectedBUId) return applications;
    const buName = currentSelectedBU?.name?.toLowerCase().trim() || '';
    return applications.filter(
      (a) =>
        a.businessUnit.toLowerCase().trim() === buName ||
        (a as any).businessUnitId === selectedBUId
    );
  }, [applications, selectedBUId, currentSelectedBU]);

  // Available Users Strictly Filtered by Selected BU
  // CRITICAL RULE: Only active users tagged to the selected BU can be workflow approvers
  const availableUsersForBU = useMemo(() => {
    if (!selectedBUId) return [];

    const targetBU = currentSelectedBU;
    const targetBUId = targetBU?.id || selectedBUId;
    const targetBUName = targetBU?.name?.toLowerCase().trim() || '';

    return users.filter((u) => {
      if (u.isActive === false || u.status === 'INACTIVE') return false;
      if (u.businessUnitId && u.businessUnitId === targetBUId) return true;
      if (u.businessUnit?.id && u.businessUnit.id === targetBUId) return true;
      if (u.businessUnit?.name && targetBUName && u.businessUnit.name.toLowerCase().trim() === targetBUName) return true;
      return false;
    });
  }, [users, selectedBUId, currentSelectedBU]);

  // Open Create Modal
  const handleOpenCreateModal = () => {
    setEditingWorkflow(null);
    const defaultBU = userAllowedBUs.length > 0 ? userAllowedBUs[0].id : (activeBUs.length > 0 ? activeBUs[0].id : '');
    const defaultEnv = activeEnvironments.length > 0 ? activeEnvironments[0].id : '';
    const defaultApp = applications.length > 0 ? applications[0].id : '';

    setSelectedBUId(defaultBU);
    setSelectedEnvId(defaultEnv);
    setSelectedAppId(defaultApp);
    setSelectedServiceCode('');
    setApproverSteps([{ userId: '' }]);
    setIsActive(true);
    setFormError('');
    setModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (wf: Workflow) => {
    setEditingWorkflow(wf);
    setSelectedBUId(wf.buId);
    setSelectedEnvId(wf.environmentId);
    setSelectedAppId(wf.applicationId);
    setSelectedServiceCode(wf.serviceCode);
    setApproverSteps(wf.approvers.map((a) => ({ userId: a.userId })));
    setIsActive(wf.isActive);
    setFormError('');
    setModalOpen(true);
  };

  // BU Change in Modal
  const handleBUChange = (newBuId: string) => {
    setSelectedBUId(newBuId);

    // Reset application to first valid for BU if any
    const targetBU = activeBUs.find((b) => b.id === newBuId);
    const buName = targetBU?.name?.toLowerCase().trim() || '';
    const validApps = applications.filter((a) => a.businessUnit.toLowerCase().trim() === buName);
    if (validApps.length > 0) {
      setSelectedAppId(validApps[0].id);
    } else {
      setSelectedAppId('');
    }

    // Filter approvers to only valid ones in new BU
    const newBUId = targetBU?.id || newBuId;
    const validUsersForNewBU = users.filter((u) => {
      if (u.isActive === false || u.status === 'INACTIVE') return false;
      if (u.businessUnitId && u.businessUnitId === newBUId) return true;
      if (u.businessUnit?.id && u.businessUnit.id === newBUId) return true;
      if (u.businessUnit?.name && buName && u.businessUnit.name.toLowerCase().trim() === buName) return true;
      return false;
    });

    const validUserIdsSet = new Set(validUsersForNewBU.map((u) => u.id));
    setApproverSteps((prev) => {
      const filtered = prev.filter((s) => s.userId && validUserIdsSet.has(s.userId));
      return filtered.length > 0 ? filtered : [{ userId: '' }];
    });
  };

  // Approver Step Management
  const handleAddApproverStep = () => {
    setApproverSteps((prev) => [...prev, { userId: '' }]);
  };

  const handleRemoveApproverStep = (index: number) => {
    setApproverSteps((prev) => prev.filter((_, i) => i !== index));
  };

  const handleApproverUserChange = (index: number, userId: string) => {
    setApproverSteps((prev) => {
      const next = [...prev];
      next[index] = { userId };
      return next;
    });
  };

  const handleMoveStepUp = (index: number) => {
    if (index === 0) return;
    setApproverSteps((prev) => {
      const next = [...prev];
      const temp = next[index - 1];
      next[index - 1] = next[index];
      next[index] = temp;
      return next;
    });
  };

  const handleMoveStepDown = (index: number) => {
    if (index >= approverSteps.length - 1) return;
    setApproverSteps((prev) => {
      const next = [...prev];
      const temp = next[index + 1];
      next[index + 1] = next[index];
      next[index] = temp;
      return next;
    });
  };

  // Save Workflow
  const handleSaveWorkflow = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!selectedBUId) {
      setFormError('Business Unit is required.');
      return;
    }
    if (!selectedEnvId) {
      setFormError('Environment is required.');
      return;
    }
    if (!selectedAppId) {
      setFormError('Application is required.');
      return;
    }
    if (!selectedServiceCode) {
      setFormError('Please select a Service.');
      return;
    }

    // Validate approvers
    const validApproverUserIds = approverSteps.map((s) => s.userId).filter(Boolean);
    if (validApproverUserIds.length === 0) {
      setFormError('Please select at least one approver for the workflow.');
      return;
    }
    if (validApproverUserIds.length !== new Set(validApproverUserIds).size) {
      setFormError('The same user cannot be configured multiple times in the approval sequence.');
      return;
    }

    // Check duplicate workflow definition locally
    const duplicate = workflows.find(
      (w) =>
        w.buId === selectedBUId &&
        w.environmentId === selectedEnvId &&
        w.applicationId === selectedAppId &&
        w.serviceCode === selectedServiceCode &&
        (!editingWorkflow || w.id !== editingWorkflow.id)
    );
    if (duplicate) {
      setFormError('A workflow definition already exists for the selected BU, Environment, Application, and Service.');
      return;
    }

    const formattedApprovers: WorkflowApproverInput[] = validApproverUserIds.map((userId, idx) => ({
      userId,
      workflowOrder: idx + 1,
    }));

    setIsSaving(true);
    try {
      if (editingWorkflow) {
        const payload: WorkflowUpdatePayload = {
          buId: selectedBUId,
          environmentId: selectedEnvId,
          applicationId: selectedAppId,
          serviceCode: selectedServiceCode,
          approvers: formattedApprovers,
          isActive,
          status: isActive ? 'ACTIVE' : 'INACTIVE',
        };
        const updated = await workflowService.updateWorkflow(editingWorkflow.id, payload);
        setWorkflows((prev) => prev.map((w) => (w.id === updated.id ? updated : w)));
        showToast('Workflow definition updated successfully!', 'success');
      } else {
        const payload: WorkflowCreatePayload = {
          buId: selectedBUId,
          environmentId: selectedEnvId,
          applicationId: selectedAppId,
          serviceCode: selectedServiceCode,
          approvers: formattedApprovers,
          isActive,
        };
        const created = await workflowService.createWorkflow(payload);
        setWorkflows((prev) => [created, ...prev]);
        showToast('Workflow definition created successfully!', 'success');
      }
      setModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to save workflow definition.');
    } finally {
      setIsSaving(false);
    }
  };

  // Toggle Status
  const handleToggleStatus = async (wf: Workflow) => {
    try {
      const updated = await workflowService.toggleWorkflowStatus(wf.id);
      setWorkflows((prev) => prev.map((w) => (w.id === updated.id ? updated : w)));
      showToast(
        `Workflow for "${updated.serviceName}" is now ${updated.isActive ? 'Active' : 'Inactive'}.`,
        'success'
      );
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle workflow status', 'error');
    }
  };

  // Delete Workflow
  const handleConfirmDelete = async () => {
    if (!deleteConfirmWorkflow) return;
    setIsDeleting(true);
    try {
      await workflowService.deleteWorkflow(deleteConfirmWorkflow.id);
      setWorkflows((prev) => prev.filter((w) => w.id !== deleteConfirmWorkflow.id));
      showToast('Workflow definition deleted successfully!', 'success');
      setDeleteConfirmWorkflow(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to delete workflow', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Filtered workflows table
  const filteredWorkflows = useMemo(() => {
    return userVisibleWorkflows.filter((w) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        (w.buName && w.buName.toLowerCase().includes(q)) ||
        (w.environmentName && w.environmentName.toLowerCase().includes(q)) ||
        (w.applicationName && w.applicationName.toLowerCase().includes(q)) ||
        w.serviceName.toLowerCase().includes(q) ||
        w.approvers.some((a) => a.fullName?.toLowerCase().includes(q) || a.username?.toLowerCase().includes(q));

      const matchBU =
        selectedBUFilter === 'ALL' ||
        w.buId === selectedBUFilter ||
        (w.buName && w.buName.toLowerCase() === selectedBUFilter.toLowerCase());

      const matchService = selectedServiceFilter === 'ALL' || w.serviceCode === selectedServiceFilter;

      const matchStatus =
        selectedStatusFilter === 'ALL' ||
        (selectedStatusFilter === 'ACTIVE' && w.isActive) ||
        (selectedStatusFilter === 'INACTIVE' && !w.isActive);

      return matchSearch && matchBU && matchService && matchStatus;
    });
  }, [userVisibleWorkflows, searchQuery, selectedBUFilter, selectedServiceFilter, selectedStatusFilter]);

  // Paginated
  const paginatedWorkflows = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredWorkflows.slice(start, start + pageSize);
  }, [filteredWorkflows, page, pageSize]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12 font-sans">
      {/* 1. HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            SETTINGS &bull; GOVERNANCE & APPROVALS
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1 flex items-center gap-3">
            <GitFork className="w-7 h-7 text-orange-500" />
            <span>Define Workflow</span>
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
            Configure multi-tier sequential approval hierarchies for Environment Services (Reservations, Provisioning, Monitoring, Health Checks) based on BU, Environment, and Application.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadData}
            className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f1724] text-slate-600 dark:text-slate-400 hover:text-orange-500 transition-colors shadow-sm cursor-pointer"
            title="Reload Workflows"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-500' : ''}`} />
          </button>
          {!isSuperAdmin && (
            <button
              onClick={handleOpenCreateModal}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_16px_rgba(249,115,22,0.4)] cursor-pointer"
            >
              <Plus className="w-4 h-4" /> DEFINE WORKFLOW
            </button>
          )}
        </div>
      </div>


      {/* 2. SUMMARY METRIC CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono">
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400">TOTAL WORKFLOWS</span>
            <GitFork className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-3xl font-extrabold text-slate-900 dark:text-white mt-2">{userVisibleWorkflows.length}</p>
          <p className="text-xs text-slate-500 mt-1 font-sans">Defined approval routes</p>
        </div>

        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-emerald-500">ACTIVE WORKFLOWS</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-2">
            {userVisibleWorkflows.filter((w) => w.isActive).length}
          </p>
          <p className="text-xs text-slate-500 mt-1 font-sans">Live enforcement routes</p>
        </div>
      </div>

      {/* 3. FILTER TOOLBAR */}
      <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 p-4 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-xs shadow-sm">
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input autoComplete="off" data-lpignore="true"
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setPage(1);
            }}
            placeholder="Search by BU, Environment, Application, Service, or Approver..."
            className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* BU Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">BU:</span>
            <select
              value={selectedBUFilter}
              onChange={(e) => {
                setSelectedBUFilter(e.target.value);
                setPage(1);
              }}
              className="bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-2.5 py-1.5 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="ALL">All Business Units</option>
              {userAllowedBUs.map((bu) => (
                <option key={bu.id} value={bu.id}>
                  {bu.name}
                </option>
              ))}
            </select>
          </div>

          {/* Service Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">SERVICE:</span>
            <select
              value={selectedServiceFilter}
              onChange={(e) => {
                setSelectedServiceFilter(e.target.value);
                setPage(1);
              }}
              className="bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-2.5 py-1.5 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="ALL">All Services</option>
              {TEM_SERVICES.map((s) => (
                <option key={s.code} value={s.code}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">STATUS:</span>
            <select
              value={selectedStatusFilter}
              onChange={(e) => {
                setSelectedStatusFilter(e.target.value);
                setPage(1);
              }}
              className="bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-2.5 py-1.5 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="ALL">All Status</option>
              <option value="ACTIVE">Active Only</option>
              <option value="INACTIVE">Inactive Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* 4. WORKFLOWS TABLE */}
      {isLoading ? (
        <TableSkeleton rows={6} columns={6} />
      ) : (
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl overflow-hidden shadow-sm">
          {filteredWorkflows.length === 0 ? (
            <div className="p-12 text-center text-slate-400 space-y-3 font-mono">
              <GitFork className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">No Workflows Defined</p>
              <p className="text-xs text-slate-500 max-w-md mx-auto font-sans">
                {workflows.length === 0
                  ? 'No approval workflows configured yet. Click "+ DEFINE WORKFLOW" above to create your first sequential approval pipeline.'
                  : 'No workflows matched your filter criteria. Try adjusting search query or filters.'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse font-sans text-xs">
                <thead className="bg-slate-50 dark:bg-slate-900/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-mono font-bold tracking-wider">
                  <tr>
                    <th className="p-4">SERVICE</th>
                    <th className="p-4">SCOPE (BU / ENV / APP)</th>
                    <th className="p-4">WORKFLOW ORDER</th>
                    <th className="p-4">STATUS</th>
                    <th className="p-4">AUDIT (MODIFIED)</th>
                    <th className="p-4 text-right">ACTIONS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800/80">
                  {paginatedWorkflows.map((wf) => {
                    return (
                      <tr
                        key={wf.id}
                        className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                      >
                        {/* Service */}
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-orange-100 dark:bg-orange-950/60 border border-orange-200 dark:border-orange-800/60 flex items-center justify-center text-orange-600 dark:text-orange-400 font-bold shrink-0">
                              <GitFork className="w-4 h-4" />
                            </div>
                            <div>
                              <span className="font-bold text-slate-900 dark:text-white block text-sm">
                                {wf.serviceName}
                              </span>
                              <span className="text-[10px] font-mono text-slate-400 uppercase">
                                {wf.serviceCode}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Scope (BU / Environment / Application) */}
                        <td className="p-4 space-y-1 font-mono text-xs">
                          <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-200">
                            <Building2 className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                            <span className="font-bold">{wf.buName || wf.buId}</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 text-[11px]">
                            <Cpu className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>{wf.environmentName || wf.environmentId}</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 text-[11px]">
                            <AppWindow className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>{wf.applicationName || wf.applicationId}</span>
                          </div>
                        </td>

                        {/* Sequential Approval Hierarchy */}
                        <td className="p-4">
                          <div className="flex flex-wrap items-center gap-1.5 max-w-md">
                            {wf.approvers.map((approver, idx) => (
                              <React.Fragment key={approver.id}>
                                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-orange-50/80 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-800/60 text-xs font-mono">
                                  <span className="w-4 h-4 rounded-full bg-orange-500 text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                                    {approver.workflowOrder}
                                  </span>
                                  <span className="font-bold text-slate-900 dark:text-white">
                                    {approver.fullName || approver.username}
                                  </span>
                                </div>
                                {idx < wf.approvers.length - 1 && (
                                  <ArrowRight className="w-3 h-3 text-slate-400 shrink-0" />
                                )}
                              </React.Fragment>
                            ))}
                          </div>
                        </td>

                        {/* Status */}
                        <td className="p-4">
                          <button
                            type="button"
                            onClick={() => !isSuperAdmin && handleToggleStatus(wf)}
                            disabled={isSuperAdmin}
                            className={`inline-flex items-center gap-1.5 ${isSuperAdmin ? 'cursor-default' : 'cursor-pointer group'}`}
                            title={isSuperAdmin ? 'Workflow status (Read-Only)' : 'Click to toggle active status'}
                          >
                            <span
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold transition-colors ${
                                wf.isActive
                                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800/80 group-hover:bg-emerald-200'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 group-hover:bg-slate-200'
                              }`}
                            >
                              {wf.isActive ? (
                                <>
                                  <CheckCircle2 className="w-3.5 h-3.5" /> ACTIVE
                                </>
                              ) : (
                                <>
                                  <XCircle className="w-3.5 h-3.5" /> INACTIVE
                                </>
                              )}
                            </span>
                          </button>
                        </td>

                        {/* Audit */}
                        <td className="p-4 font-mono text-[11px] text-slate-500 space-y-0.5">
                          <span className="text-slate-700 dark:text-slate-300 font-semibold block">
                            {wf.modifiedBy || wf.createdBy}
                          </span>
                          <span className="text-slate-400 text-[10px]">
                            {new Date(wf.updatedAt || wf.createdAt).toLocaleDateString()}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="p-4 text-right">
                          {isSuperAdmin ? (
                            <span className="text-[10px] font-mono text-slate-500 italic">Read-Only</span>
                          ) : (
                            <div className="flex items-center justify-end space-x-2">
                              <button
                                onClick={() => handleOpenEditModal(wf)}
                                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-orange-50 dark:hover:bg-orange-950/40 text-slate-600 dark:text-slate-300 hover:text-orange-600 transition-colors cursor-pointer"
                                title="Edit Workflow"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => setDeleteConfirmWorkflow(wf)}
                                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-600 dark:text-slate-300 hover:text-rose-600 transition-colors cursor-pointer"
                                title="Delete Workflow"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {filteredWorkflows.length > pageSize && (
            <div className="p-4 border-t border-slate-200 dark:border-slate-800">
              <Pagination
                currentPage={page}
                totalItems={filteredWorkflows.length}
                pageSize={pageSize}
                onPageChange={setPage}
              />
            </div>
          )}
        </div>
      )}

      {/* 5. DEFINE / EDIT WORKFLOW MODAL */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-2xl max-w-3xl w-full p-6 shadow-2xl space-y-5 relative my-8">
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-orange-100 dark:bg-orange-950/60 border border-orange-300 dark:border-orange-800/80 flex items-center justify-center text-orange-600 dark:text-orange-400">
                  <GitFork className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    {editingWorkflow ? 'Edit Approval Workflow' : 'Define Approval Workflow'}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono">
                    Step-by-step approval chain with strict BU-based user eligibility.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 rounded-xl flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300 font-mono">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
                <span>{formError}</span>
              </div>
            )}

            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveWorkflow} className="space-y-4 font-sans text-xs">
              {/* Scope & Service Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Business Unit */}
                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                    Business Unit <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={selectedBUId}
                    onChange={(e) => handleBUChange(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
                  >
                    <option value="">-- Select BU --</option>
                    {userAllowedBUs.map((bu) => (
                      <option key={bu.id} value={bu.id}>
                        {bu.name} ({bu.code})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Target Environment */}
                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                    Environment <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={selectedEnvId}
                    onChange={(e) => setSelectedEnvId(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
                  >
                    <option value="">-- Select Environment --</option>
                    {activeEnvironments.map((env) => (
                      <option key={env.id} value={env.id}>
                        {env.name} ({env.type})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Application */}
                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                    Application <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={selectedAppId}
                    onChange={(e) => setSelectedAppId(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
                  >
                    <option value="">-- Select Application --</option>
                    {applicationsForSelectedBU.map((app) => (
                      <option key={app.id} value={app.id}>
                        {app.name} ({app.code})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Services Selection */}
                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1 uppercase">
                    Services <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={selectedServiceCode}
                    onChange={(e) => setSelectedServiceCode(e.target.value as TEMServiceCode)}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
                  >
                    <option value="">-- Select Services --</option>
                    {TEM_SERVICES.map((srv) => (
                      <option key={srv.code} value={srv.code}>
                        {srv.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* WORKFLOW ORDER BUILDER */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-950/40 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-2.5">
                  <div>
                    <label className="text-xs font-mono font-bold text-slate-900 dark:text-white uppercase flex items-center gap-1.5">
                      <span>Workflow Order</span>
                      <span className="text-orange-500 font-bold">({approverSteps.length} Approver{approverSteps.length !== 1 ? 's' : ''})</span>
                    </label>
                    <span className="text-[11px] text-slate-500">
                      Requests will be routed sequentially in the order selected below (Order 1, Order 2, etc.).
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddApproverStep}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-mono font-bold bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 border border-orange-300 dark:border-orange-800/80 hover:bg-orange-200 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> ADD APPROVER
                  </button>
                </div>

                {/* BU Restriction Alert */}
                {selectedBUId && availableUsersForBU.length === 0 && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800/80 rounded-lg text-amber-800 dark:text-amber-300 text-xs font-mono flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
                    <span>No active users are currently assigned to this BU in User Management.</span>
                  </div>
                )}

                {/* Steps List */}
                <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                  {approverSteps.map((step, idx) => {
                    return (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-white dark:bg-[#161f2e] border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3"
                      >
                        {/* Order Badge */}
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="w-6 h-6 rounded-full bg-orange-500 text-white font-mono font-bold text-xs flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <span className="font-mono text-xs font-bold text-slate-700 dark:text-slate-300 uppercase">
                            Order {idx + 1}
                          </span>
                        </div>

                        {/* User Selector */}
                        <div className="flex-1 min-w-0">
                          <select
                            required
                            value={step.userId}
                            onChange={(e) => handleApproverUserChange(idx, e.target.value)}
                            className="w-full bg-slate-50 dark:bg-[#0f1724] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
                          >
                            <option value="">-- Select Approver (from {currentSelectedBU?.name || 'Selected BU'}) --</option>
                            {availableUsersForBU.map((u) => {
                              const isSelectedElsewhere = approverSteps.some(
                                (s, sIdx) => sIdx !== idx && s.userId === u.id
                              );
                              return (
                                <option key={u.id} value={u.id} disabled={isSelectedElsewhere}>
                                  {u.fullName || u.username} (@{u.username}){isSelectedElsewhere ? ' (Already selected in Order)' : ''}
                                </option>
                              );
                            })}
                          </select>
                        </div>

                        {/* Step Ordering Controls */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => handleMoveStepUp(idx)}
                            className="p-1 text-slate-400 hover:text-slate-800 dark:hover:text-white disabled:opacity-30 cursor-pointer"
                            title="Move Up in Order"
                          >
                            <ArrowUp className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            disabled={idx >= approverSteps.length - 1}
                            onClick={() => handleMoveStepDown(idx)}
                            className="p-1 text-slate-400 hover:text-slate-800 dark:hover:text-white disabled:opacity-30 cursor-pointer"
                            title="Move Down in Order"
                          >
                            <ArrowDown className="w-4 h-4" />
                          </button>
                          {approverSteps.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveApproverStep(idx)}
                              className="p-1 text-rose-400 hover:text-rose-600 cursor-pointer ml-1"
                              title="Remove Approver"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Status */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="wfActiveCheckbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="w-4 h-4 accent-orange-500 rounded cursor-pointer"
                />
                <label htmlFor="wfActiveCheckbox" className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                  Activate this workflow upon saving
                </label>
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-mono font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  CANCEL
                </button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSaving}
                  loadingText="SAVING..."
                  className="px-6 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_12px_rgba(249,115,22,0.35)] cursor-pointer"
                >
                  {editingWorkflow ? 'UPDATE WORKFLOW' : 'SAVE WORKFLOW'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. DELETE CONFIRMATION MODAL */}
      {deleteConfirmWorkflow && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#0f1724] border border-rose-300 dark:border-rose-900/80 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-950/80 border border-rose-300 dark:border-rose-800 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white font-mono">
                  Delete Workflow?
                </h4>
                <p className="text-xs text-slate-500 font-mono">Permanent workflow removal</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-sans">
              Are you sure you want to delete the approval workflow definition for{' '}
              <strong className="text-slate-900 dark:text-white">
                "{deleteConfirmWorkflow.serviceName}" ({deleteConfirmWorkflow.buName || deleteConfirmWorkflow.buId})
              </strong>? This action cannot be undone.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmWorkflow(null)}
                className="px-4 py-2 rounded-lg text-xs font-mono font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                CANCEL
              </button>
              <ButtonLoader
                onClick={handleConfirmDelete}
                isLoading={isDeleting}
                loadingText="DELETING..."
                className="px-5 py-2 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-rose-600 hover:bg-rose-500 transition-all shadow-[0_0_12px_rgba(225,29,72,0.4)] cursor-pointer"
              >
                CONFIRM DELETE
              </ButtonLoader>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
