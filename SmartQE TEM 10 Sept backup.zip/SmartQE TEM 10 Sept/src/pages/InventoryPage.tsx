import React, { useState, useMemo, useEffect } from 'react';
import { useTEM } from '../context/TEMContext';
import {
  InventoryAsset,
  InventoryFilterState,
  SavedFilterPreset,
  AssetStatus,
  AssetType,
  CloudProvider
} from '../types/inventory';
import { inventoryService } from '../services/inventoryService';
import { InventoryDashboard } from '../components/inventory/InventoryDashboard';
import { InventoryFilterBar, PRESET_FILTERS } from '../components/inventory/InventoryFilterBar';
import { InventoryAssetModal } from '../components/inventory/InventoryAssetModal';
import { InventoryAssetDossierModal } from '../components/inventory/InventoryAssetDossierModal';
import { InventoryVisualView } from '../components/inventory/visual/InventoryVisualView';
import { Pagination } from '../components/common/Pagination';
import { TableSkeleton } from '../components/common/Skeleton';
import { ButtonLoader } from '../components/common/ButtonLoader';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import {
  Boxes,
  Server,
  Database,
  Cloud,
  Network,
  Cpu,
  Layers,
  Plus,
  Eye,
  Edit2,
  Trash2,
  Activity,
  HardDrive,
  Globe,
  Building2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldAlert,
  Archive,
  BarChart3,
  ListFilter,
  RefreshCw,
  Power,
  Workflow
} from 'lucide-react';

const INITIAL_FILTERS: InventoryFilterState = {
  search: '',
  businessUnit: 'ALL',
  accountName: 'ALL',
  environment: 'ALL',
  environmentType: 'ALL',
  assetType: 'ALL',
  infrastructureType: 'ALL',
  cloudProvider: 'ALL',
  region: 'ALL',
  status: 'ALL',
  operatingSystem: 'ALL',
  ownerTeam: 'ALL'
};

const DEFAULT_VISIBLE_COLUMNS: Record<string, boolean> = {
  assetId: true,
  name: true,
  assetType: true,
  environment: true,
  hierarchy: true,
  infrastructure: true,
  ipHostname: true,
  specs: true,
  software: true,
  status: true,
  owner: true,
  actions: true
};

export const InventoryPage: React.FC = () => {
  const {
    // Environment Details is the single source of truth for environments
    environmentProfiles,
    businessUnits,
    projects,
    servers,
    softwareList,
    bookings,
    showToast
  } = useTEM();

  const [activeTab, setActiveTab] = useState<'grid' | 'visual' | 'dashboard' | 'servers' | 'databases' | 'cloud' | 'network' | 'software'>('grid');
  const [assets, setAssets] = useState<InventoryAsset[]>([]);
  const [filters, setFilters] = useState<InventoryFilterState>(INITIAL_FILTERS);
  const [visibleColumns, setVisibleColumns] = useState<Record<string, boolean>>(DEFAULT_VISIBLE_COLUMNS);
  const [isLoading, setIsLoading] = useState(false);

  // Pagination
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Modals
  const [assetModalOpen, setAssetModalOpen] = useState(false);
  const [dossierModalOpen, setDossierModalOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<InventoryAsset | null>(null);
  const [editingAsset, setEditingAsset] = useState<InventoryAsset | null>(null);

  // Load Assets
  const loadAssets = async () => {
    try {
      setIsLoading(true);
      const data = await inventoryService.getAssets();
      setAssets(data);
    } catch (err: any) {
      showToast(err.message || 'Failed to load inventory assets', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAssets();
  }, []);

  // Consolidate & synthesize assets from Environment Details, Servers, Software, Bookings, and explicit Assets
  const consolidatedAssets = useMemo(() => {
    const map = new Map<string, InventoryAsset>();

    // Environment name/ID to Business Unit lookup map derived from Bookings & Portfolio
    const envToBuMap = new Map<string, string>();
    bookings?.forEach((b) => {
      if (b.businessUnit && b.environmentName) {
        envToBuMap.set(b.environmentName.toLowerCase(), b.businessUnit);
      }
      if (b.businessUnit && b.environmentId) {
        envToBuMap.set(b.environmentId.toLowerCase(), b.businessUnit);
      }
    });

    // 1. Synthesize Servers from Environment Details
    servers?.forEach((srv) => {
      const profile = environmentProfiles?.find(
        (p) => p.serverIds?.includes(srv.id) || p.name === srv.environmentName
      );
      const envName = srv.environmentName || profile?.name;
      const defaultBU = (businessUnits && businessUnits.length > 0) ? businessUnits[0].name : (profile?.ownerTeam || 'Enterprise Operations');
      const bu =
        (envName && envToBuMap.get(envName.toLowerCase())) ||
        (profile && envToBuMap.get(profile.id.toLowerCase())) ||
        profile?.ownerTeam ||
        defaultBU;

      const isCloudInfra = srv.infrastructureType ? srv.infrastructureType === 'CLOUD' : !!srv.cloudProvider;
      const key = `server-${srv.id}`;
      map.set(key, {
        id: key,
        assetId: `AST-SRV-${srv.id.slice(-4).toUpperCase()}`,
        name: srv.name,
        assetType: 'SERVER',
        infrastructureType: srv.infrastructureType || (isCloudInfra ? 'CLOUD' : 'ON_PREMISES'),
        cloudProvider: isCloudInfra ? ((srv.cloudProvider || 'On-Premises') as CloudProvider) : 'On-Premises',
        businessUnit: bu,
        accountName: profile?.networkZone || 'Enterprise Core',
        environmentId: profile?.id,
        environmentName: envName || profile?.name,
        environmentType: profile?.type || 'UAT / Staging',
        ipAddress: srv.hostIp || srv.privateIp || srv.publicIp,
        hostname: srv.name,
        operatingSystem: srv.operatingSystem || 'Linux (Ubuntu 22.04 LTS)',
        cpuCores: srv.cpuCores || 4,
        ramGb: srv.ramGb || 16,
        storageGb: srv.storageGb || 250,
        installedSoftware: [],
        status: srv.status === 'ONLINE' ? 'ACTIVE' : srv.status === 'OFFLINE' ? 'INACTIVE' : 'MAINTENANCE',
        ownerTeam: profile?.ownerTeam || bu,
        responsiblePerson: 'Ops Engineer',
        costCenter: 'CC-ENG-402',
        createdAt: srv.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: 'System Admin',
        updatedBy: 'System Admin',
        auditLogs: [],
      });
    });

    // 2. Synthesize Software from Environment Details
    softwareList?.forEach((sw) => {
      const profile = environmentProfiles?.find((p) => p.softwareIds?.includes(sw.id));
      const envName = profile?.name;
      const defaultBU = (businessUnits && businessUnits.length > 0) ? businessUnits[0].name : (profile?.ownerTeam || 'Enterprise Operations');
      const bu =
        (envName && envToBuMap.get(envName.toLowerCase())) ||
        (profile && envToBuMap.get(profile.id.toLowerCase())) ||
        profile?.ownerTeam ||
        defaultBU;

      const key = `software-${sw.id}`;
      map.set(key, {
        id: key,
        assetId: `AST-SW-${sw.id.slice(-4).toUpperCase()}`,
        name: `${sw.name}${sw.version ? ' v' + sw.version : ''}`,
        assetType: 'SOFTWARE',
        infrastructureType: 'ON_PREMISES',
        cloudProvider: 'On-Premises',
        businessUnit: bu,
        accountName: profile?.networkZone || 'Enterprise Core',
        environmentId: profile?.id,
        environmentName: envName,
        environmentType: profile?.type || 'UAT / Staging',
        runtimeStack: sw.runtimeStack,
        installedSoftware: [],
        status: sw.status === 'ACTIVE' || sw.status === 'INSTALLED' ? 'ACTIVE' : 'INACTIVE',
        ownerTeam: profile?.ownerTeam || bu,
        responsiblePerson: 'Ops Engineer',
        costCenter: 'CC-ENG-402',
        createdAt: sw.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: 'System Admin',
        updatedBy: 'System Admin',
        auditLogs: [],
      });
    });

    // 4. Merge explicit assets from inventoryService (override synthesized if same ID or add new)
    assets?.forEach((explicitAsset) => {
      map.set(explicitAsset.id, explicitAsset);
    });

    return Array.from(map.values());
  }, [environmentProfiles, servers, softwareList, bookings, assets, businessUnits]);

  // Consolidate Distinct Filter Values from Environment Details, Portfolio, and Consolidated Assets
  const availableBUs = useMemo(() => {
    const set = new Set<string>();
    businessUnits.forEach((b) => set.add(b.name));
    consolidatedAssets.forEach((a) => a.businessUnit && set.add(a.businessUnit));
    return Array.from(set);
  }, [businessUnits, consolidatedAssets]);

  const availableAccounts = useMemo(() => {
    const set = new Set<string>();
    projects.forEach((p) => set.add(p.name));
    consolidatedAssets.forEach((a) => a.accountName && set.add(a.accountName));
    return Array.from(set);
  }, [projects, consolidatedAssets]);

  // Environment filter options — sourced from Environment Details (single source of truth)
  const availableEnvironments = useMemo(() => {
    const map = new Map<string, { id: string; name: string }>();
    if (environmentProfiles) {
      environmentProfiles.forEach((p) => map.set(p.name.toLowerCase(), { id: p.id, name: p.name }));
    }
    consolidatedAssets.forEach((a) => {
      if (a.environmentName && !map.has(a.environmentName.toLowerCase())) {
        map.set(a.environmentName.toLowerCase(), { id: a.environmentId || a.environmentName, name: a.environmentName });
      }
    });
    return Array.from(map.values());
  }, [environmentProfiles, consolidatedAssets]);

  const availableCloudProviders = useMemo(() => {
    const set = new Set<string>(['AWS', 'Azure', 'GCP', 'OCI', 'Alibaba Cloud', 'On-Premises', 'Other']);
    consolidatedAssets.forEach((a) => a.cloudProvider && set.add(a.cloudProvider));
    return Array.from(set);
  }, [consolidatedAssets]);

  const availableOperatingSystems = useMemo(() => {
    const set = new Set<string>();
    consolidatedAssets.forEach((a) => a.operatingSystem && set.add(a.operatingSystem));
    return Array.from(set);
  }, [consolidatedAssets]);

  const availableEnvironmentTypes = [
    'Development',
    'QA / Testing',
    'UAT / Staging',
    'Performance / Stress',
    'Disaster Recovery (DR)',
    'Production'
  ];

  // Tab Filtering Hook
  const effectiveFilters = useMemo(() => {
    const f = { ...filters };
    if (activeTab === 'servers') f.assetType = 'SERVER';
    else if (activeTab === 'databases') f.assetType = 'DATABASE';
    else if (activeTab === 'cloud') f.assetType = 'CLOUD_RESOURCE';
    else if (activeTab === 'network') f.assetType = 'NETWORK_COMPONENT';
    else if (activeTab === 'software') f.assetType = 'SOFTWARE';
    return f;
  }, [filters, activeTab]);

  // Filtered Assets List
  const filteredAssets = useMemo(() => {
    return consolidatedAssets.filter((a) => {
      // Search
      if (effectiveFilters.search) {
        const q = effectiveFilters.search.toLowerCase();
        const matchSearch =
          a.name.toLowerCase().includes(q) ||
          a.assetId.toLowerCase().includes(q) ||
          (a.ipAddress && a.ipAddress.toLowerCase().includes(q)) ||
          (a.hostname && a.hostname.toLowerCase().includes(q)) ||
          (a.businessUnit && a.businessUnit.toLowerCase().includes(q)) ||
          (a.accountName && a.accountName.toLowerCase().includes(q)) ||
          (a.environmentName && a.environmentName.toLowerCase().includes(q)) ||
          (a.applicationName && a.applicationName.toLowerCase().includes(q)) ||
          (a.instanceId && a.instanceId.toLowerCase().includes(q)) ||
          (a.ownerTeam && a.ownerTeam.toLowerCase().includes(q));
        if (!matchSearch) return false;
      }

      // BU
      if (effectiveFilters.businessUnit !== 'ALL' && a.businessUnit.toLowerCase() !== effectiveFilters.businessUnit.toLowerCase()) {
        return false;
      }

      // Account / Project
      if (effectiveFilters.accountName !== 'ALL' && a.accountName.toLowerCase() !== effectiveFilters.accountName.toLowerCase()) {
        return false;
      }

      // Environment
      if (effectiveFilters.environment !== 'ALL') {
        const matchEnv =
          (a.environmentId && a.environmentId === effectiveFilters.environment) ||
          (a.environmentName && a.environmentName.toLowerCase() === effectiveFilters.environment.toLowerCase());
        if (!matchEnv) return false;
      }

      // Environment Type
      if (effectiveFilters.environmentType !== 'ALL' && a.environmentType && a.environmentType.toLowerCase() !== effectiveFilters.environmentType.toLowerCase()) {
        return false;
      }

      // Asset Type
      if (effectiveFilters.assetType !== 'ALL' && a.assetType !== effectiveFilters.assetType) {
        return false;
      }

      // Infra Type
      if (effectiveFilters.infrastructureType !== 'ALL' && a.infrastructureType !== effectiveFilters.infrastructureType) {
        return false;
      }

      // Cloud Provider
      if (effectiveFilters.cloudProvider !== 'ALL' && a.cloudProvider !== effectiveFilters.cloudProvider) {
        return false;
      }

      // Region
      if (effectiveFilters.region !== 'ALL' && effectiveFilters.region) {
        const matchReg = (a.region && a.region.toLowerCase().includes(effectiveFilters.region.toLowerCase())) ||
                         (a.datacenter && a.datacenter.toLowerCase().includes(effectiveFilters.region.toLowerCase()));
        if (!matchReg) return false;
      }

      // Status
      if (effectiveFilters.status !== 'ALL' && a.status !== effectiveFilters.status) {
        return false;
      }

      // Operating System
      if (effectiveFilters.operatingSystem !== 'ALL' && (!a.operatingSystem || !a.operatingSystem.toLowerCase().includes(effectiveFilters.operatingSystem.toLowerCase()))) {
        return false;
      }

      return true;
    });
  }, [consolidatedAssets, effectiveFilters]);

  // Paginated Sliced Assets
  const paginatedAssets = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredAssets.slice(start, start + pageSize);
  }, [filteredAssets, page, pageSize]);

  // Executive Metrics Calculation
  const metrics = useMemo(() => {
    const total = consolidatedAssets.length;
    const envSet = new Set(consolidatedAssets.map((a) => a.environmentName).filter(Boolean));

    let cloudCount = 0;
    let onPremCount = 0;
    let hybridCount = 0;
    let activeCount = 0;
    let inactiveCount = 0;
    let maintCount = 0;
    let retiredCount = 0;
    let approachingEol = 0;

    let serversCount = 0;
    let dbsCount = 0;
    let cloudResCount = 0;
    let networkCount = 0;
    let softwareCount = 0;

    const assetsByBu: Record<string, number> = {};
    const assetsByProvider: Record<string, number> = {};
    const assetsByStatus: Record<string, number> = {};
    const assetsByType: Record<string, number> = {};
    const assetsByOs: Record<string, number> = {};

    consolidatedAssets.forEach((a) => {
      assetsByBu[a.businessUnit || 'General'] = (assetsByBu[a.businessUnit || 'General'] || 0) + 1;
      assetsByProvider[a.cloudProvider || 'Other'] = (assetsByProvider[a.cloudProvider || 'Other'] || 0) + 1;
      assetsByStatus[a.status || 'ACTIVE'] = (assetsByStatus[a.status || 'ACTIVE'] || 0) + 1;
      assetsByType[a.assetType || 'SERVER'] = (assetsByType[a.assetType || 'SERVER'] || 0) + 1;
      assetsByOs[a.operatingSystem || 'Other'] = (assetsByOs[a.operatingSystem || 'Other'] || 0) + 1;

      if (a.infrastructureType === 'CLOUD') cloudCount++;
      else if (a.infrastructureType === 'ON_PREMISES') onPremCount++;
      else if (a.infrastructureType === 'HYBRID') hybridCount++;

      if (a.status === 'ACTIVE') activeCount++;
      else if (a.status === 'INACTIVE') inactiveCount++;
      else if (a.status === 'MAINTENANCE') maintCount++;
      else if (a.status === 'RETIRED' || a.status === 'DECOMMISSIONED') retiredCount++;

      if (a.assetType === 'SERVER') serversCount++;
      else if (a.assetType === 'DATABASE') dbsCount++;
      else if (a.assetType === 'CLOUD_RESOURCE') cloudResCount++;
      else if (a.assetType === 'NETWORK_COMPONENT') networkCount++;
      else if (a.assetType === 'SOFTWARE') softwareCount++;

      if (a.endOfLifeDate && a.endOfLifeDate <= '2027-01-01') approachingEol++;
    });

    return {
      totalAssets: total,
      totalEnvironments: envSet.size,
      totalServers: serversCount,
      totalDatabases: dbsCount,
      totalCloudResources: cloudResCount,
      totalNetworkComponents: networkCount,
      totalSoftware: softwareCount,
      cloudAssetsCount: cloudCount,
      onPremAssetsCount: onPremCount,
      hybridAssetsCount: hybridCount,
      activeAssetsCount: activeCount,
      inactiveAssetsCount: inactiveCount,
      maintenanceAssetsCount: maintCount,
      retiredAssetsCount: retiredCount,
      approachingEolCount: approachingEol,
      assetsByBu,
      assetsByProvider,
      assetsByStatus,
      assetsByType,
      assetsByOs
    };
  }, [consolidatedAssets]);

  // Handlers
  const handleFilterChange = (key: keyof InventoryFilterState, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setPage(1);
  };

  const handleResetFilters = () => {
    setFilters(INITIAL_FILTERS);
    setPage(1);
  };

  const handleApplyPreset = (preset: SavedFilterPreset) => {
    setFilters((prev) => ({ ...prev, ...preset.filters }));
    setPage(1);
    showToast(`Applied preset: ${preset.name}`, 'info');
  };

  const handleToggleColumn = (colKey: string) => {
    setVisibleColumns((prev) => ({ ...prev, [colKey]: !prev[colKey] }));
  };

  const handleOpenCreateModal = () => {
    setEditingAsset(null);
    setAssetModalOpen(true);
  };

  const handleOpenEditModal = (asset: InventoryAsset) => {
    setEditingAsset(asset);
    setAssetModalOpen(true);
  };

  const handleOpenDossier = (asset: InventoryAsset) => {
    setSelectedAsset(asset);
    setDossierModalOpen(true);
  };

  const handleSaveAsset = async (assetData: Partial<InventoryAsset>) => {
    if (editingAsset) {
      const updated = await inventoryService.updateAsset(editingAsset.id, assetData);
      setAssets((prev) => prev.map((a) => (a.id === editingAsset.id ? updated : a)));
      if (selectedAsset && selectedAsset.id === editingAsset.id) {
        setSelectedAsset(updated);
      }
      showToast(`Asset "${updated.name}" updated successfully`, 'success');
    } else {
      const created = await inventoryService.createAsset(assetData as any);
      setAssets((prev) => [created, ...prev]);
      showToast(`Asset "${created.name}" created with ID ${created.assetId}`, 'success');
    }
  };

  const handleStatusChange = async (id: string, newStatus: AssetStatus, reason?: string) => {
    const updated = await inventoryService.changeAssetStatus(id, newStatus, reason);
    setAssets((prev) => prev.map((a) => (a.id === id ? updated : a)));
    if (selectedAsset && selectedAsset.id === id) {
      setSelectedAsset(updated);
    }
    showToast(`Asset status updated to ${newStatus}`, 'success');
  };

  const handleToggleAsset = async (id: string) => {
    const target = consolidatedAssets.find((a) => a.id === id);
    if (!target) return;
    try {
      const updated = await inventoryService.toggleAssetStatus(id);
      setAssets((prev) => prev.map((a) => (a.id === id ? updated : a)));
      showToast(`Asset "${target.name}" is now ${updated.status}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle asset status', 'error');
    }
  };

  const handleDeleteAsset = async (id: string, hardDelete: boolean = false) => {
    const target = consolidatedAssets.find((a) => a.id === id);
    if (!target) return;
    await inventoryService.deleteAsset(id, false);
    setAssets((prev) => prev.map((a) => (a.id === id ? { ...a, status: 'INACTIVE' } : a)));
    showToast(`Asset "${target.name}" deactivated successfully`, 'info');
    if (dossierModalOpen && selectedAsset?.id === id) {
      setDossierModalOpen(false);
    }
  };

  const handleExportCsv = () => {
    if (filteredAssets.length === 0) {
      showToast('No records to export', 'info');
      return;
    }
    const headers = ['Asset ID', 'Name', 'Category', 'Infra Type', 'Cloud Provider', 'Business Unit', 'Account', 'Environment', 'IP Address', 'Hostname', 'OS', 'CPU', 'RAM(GB)', 'Storage(GB)', 'Status', 'Owner Team'];
    const rows = filteredAssets.map((a) => [
      a.assetId,
      `"${a.name}"`,
      a.assetType,
      a.infrastructureType,
      a.cloudProvider,
      `"${a.businessUnit}"`,
      `"${a.accountName}"`,
      `"${a.environmentName || 'Standalone'}"`,
      a.ipAddress || '',
      a.hostname || '',
      `"${a.operatingSystem || ''}"`,
      a.cpuCores || '',
      a.ramGb || '',
      a.storageGb || '',
      a.status,
      `"${a.ownerTeam}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `smartqe_inventory_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    showToast(`Exported ${filteredAssets.length} assets to CSV`, 'success');
  };

  const getStatusColor = (st: AssetStatus) => {
    switch (st) {
      case 'ACTIVE':
        return 'bg-emerald-950/80 border-emerald-700 text-emerald-300';
      case 'MAINTENANCE':
        return 'bg-amber-950/80 border-amber-700 text-amber-300';
      case 'INACTIVE':
      case 'PROVISIONING':
        return 'bg-blue-950/80 border-blue-700 text-blue-300';
      case 'RETIRED':
      case 'DECOMMISSIONED':
        return 'bg-rose-950/80 border-rose-700 text-rose-300';
      default:
        return 'bg-slate-800 border-slate-700 text-slate-300';
    }
  };

  const getCategoryIcon = (t: AssetType) => {
    switch (t) {
      case 'SERVER':
        return <Server className="w-4 h-4 text-emerald-400" />;
      case 'DATABASE':
        return <Database className="w-4 h-4 text-purple-400" />;
      case 'CLOUD_RESOURCE':
        return <Cloud className="w-4 h-4 text-cyan-400" />;
      case 'NETWORK_COMPONENT':
        return <Network className="w-4 h-4 text-amber-400" />;
      case 'STORAGE':
        return <HardDrive className="w-4 h-4 text-blue-400" />;
      case 'SOFTWARE':
        return <Cpu className="w-4 h-4 text-orange-400" />;
      default:
        return <Boxes className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-6 font-mono w-full min-w-0">
      {/* Top Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-gradient-to-r from-[#0b1019] via-[#0f1726] to-[#090d14] p-6 rounded-2xl border border-slate-200 dark:border-slate-800/80 shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white shadow-[0_0_15px_rgba(249,115,22,0.4)]">
            <Boxes className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-black text-white uppercase tracking-wider">Inventory Management</h1>
              <span className="px-2.5 py-0.5 rounded bg-orange-500/20 border border-orange-500/40 text-orange-400 text-xs font-bold">
                ENTERPRISE TRACEABILITY
              </span>
            </div>
            <p className="text-xs text-slate-400 font-sans mt-1">
              Centralized single source of truth for all environment infrastructure, cloud resources, servers, databases, and software.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadAssets}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-700"
            title="Refresh asset telemetry"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Refresh</span>
          </button>

          <button
            onClick={handleOpenCreateModal}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white text-xs font-bold transition-all shadow-[0_0_15px_rgba(249,115,22,0.4)]"
          >
            <Plus className="w-4 h-4" />
            <span>Add Asset</span>
          </button>
        </div>
      </div>

      {/* Navigation Subtabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveTab('grid')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'grid'
              ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <ListFilter className="w-4 h-4" />
          <span>All Assets ({metrics.totalAssets})</span>
        </button>

        <button
          onClick={() => setActiveTab('visual')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'visual'
              ? 'bg-gradient-to-r from-orange-600 to-amber-500 text-white shadow-[0_0_15px_rgba(249,115,22,0.4)]'
              : 'text-orange-400 hover:text-white hover:bg-orange-500/10 border border-orange-500/30'
          }`}
        >
          <Workflow className="w-4 h-4" />
          <span>Graphical View</span>
        </button>

        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'dashboard'
              ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Executive Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('servers')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'servers'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Server className="w-4 h-4 text-emerald-400" />
          <span>Servers ({metrics.totalServers})</span>
        </button>

        <button
          onClick={() => setActiveTab('databases')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'databases'
              ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Database className="w-4 h-4 text-purple-400" />
          <span>Databases ({metrics.totalDatabases})</span>
        </button>

        <button
          onClick={() => setActiveTab('cloud')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'cloud'
              ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Cloud className="w-4 h-4 text-cyan-400" />
          <span>Cloud Infra ({metrics.totalCloudResources})</span>
        </button>

        <button
          onClick={() => setActiveTab('network')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'network'
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Network className="w-4 h-4 text-amber-400" />
          <span>Network ({metrics.totalNetworkComponents})</span>
        </button>

        <button
          onClick={() => setActiveTab('software')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'software'
              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Cpu className="w-4 h-4 text-rose-400" />
          <span>Software / Apps ({metrics.totalSoftware})</span>
        </button>
      </div>

      {/* Main Tab Content */}
      {activeTab === 'visual' ? (
        <InventoryVisualView consolidatedAssets={consolidatedAssets} />
      ) : activeTab === 'dashboard' ? (
        <InventoryDashboard
          metrics={metrics}
          onFilterByStatus={(st) => {
            handleFilterChange('status', st);
            setActiveTab('grid');
          }}
          onFilterByProvider={(p) => {
            handleFilterChange('cloudProvider', p);
            setActiveTab('grid');
          }}
          onFilterByType={(t) => {
            handleFilterChange('assetType', t);
            setActiveTab('grid');
          }}
          onRefresh={loadAssets}
        />
      ) : (
        <div className="space-y-4">
          {/* Advanced Filter Bar */}
          <InventoryFilterBar
            filters={effectiveFilters}
            onFilterChange={handleFilterChange}
            onResetFilters={handleResetFilters}
            onApplyPreset={handleApplyPreset}
            businessUnits={availableBUs}
            accounts={availableAccounts}
            environments={availableEnvironments.map((e) => e.name)}
            environmentTypes={availableEnvironmentTypes}
            cloudProviders={availableCloudProviders}
            operatingSystems={availableOperatingSystems}
            totalResults={filteredAssets.length}
            onExportCsv={handleExportCsv}
            visibleColumns={visibleColumns}
            onToggleColumn={handleToggleColumn}
          />

          {/* Enterprise Inventory Data Grid */}
          {isLoading ? (
            <TableSkeleton rows={pageSize} columns={10} />
          ) : (
            <div className="border border-slate-200 dark:border-slate-800/90 rounded-2xl overflow-hidden bg-[#090d14] shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                <thead className="bg-[#0e1522] text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800 font-bold">
                  <tr>
                    {visibleColumns.assetId && <th className="px-4 py-3.5">Asset ID</th>}
                    {visibleColumns.name && <th className="px-4 py-3.5">Asset Name</th>}
                    {visibleColumns.assetType && <th className="px-4 py-3.5">Category</th>}
                    {visibleColumns.environment && <th className="px-4 py-3.5">Environment</th>}
                    {visibleColumns.hierarchy && <th className="px-4 py-3.5">BU / Account</th>}
                    {visibleColumns.infrastructure && <th className="px-4 py-3.5">Hosting / Provider</th>}
                    {visibleColumns.ipHostname && <th className="px-4 py-3.5">IP / Hostname</th>}
                    {visibleColumns.specs && <th className="px-4 py-3.5">Specs</th>}
                    {visibleColumns.software && <th className="px-4 py-3.5">Software</th>}
                    {visibleColumns.status && <th className="px-4 py-3.5">Status</th>}
                    {visibleColumns.owner && <th className="px-4 py-3.5">Owner Team</th>}
                    {visibleColumns.actions && <th className="px-4 py-3.5 text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                  {paginatedAssets.map((asset) => (
                    <tr
                      key={asset.id}
                      onClick={() => handleOpenDossier(asset)}
                      className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                    >
                      {/* Asset ID */}
                      {visibleColumns.assetId && (
                        <td className="px-4 py-3.5 text-orange-400 font-bold font-mono">
                          {asset.assetId}
                        </td>
                      )}

                      {/* Name */}
                      {visibleColumns.name && (
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-2">
                            {getCategoryIcon(asset.assetType)}
                            <span className="text-white font-bold group-hover:text-orange-400 transition-colors">
                              {asset.name}
                            </span>
                          </div>
                          {asset.applicationName && (
                            <p className="text-[10px] text-slate-500 font-sans mt-0.5">{asset.applicationName}</p>
                          )}
                        </td>
                      )}

                      {/* Asset Type */}
                      {visibleColumns.assetType && (
                        <td className="px-4 py-3.5 text-slate-300">
                          <span className="px-2 py-0.5 rounded bg-slate-800/80 text-slate-300 text-[10px] font-bold border border-slate-700">
                            {asset.assetType}
                          </span>
                        </td>
                      )}

                      {/* Environment */}
                      {visibleColumns.environment && (
                        <td className="px-4 py-3.5">
                          <span className="text-cyan-300 font-bold font-sans">
                            {asset.environmentName || 'Standalone'}
                          </span>
                          <p className="text-[10px] text-slate-500 font-sans">{asset.environmentType}</p>
                        </td>
                      )}

                      {/* BU / Account */}
                      {visibleColumns.hierarchy && (
                        <td className="px-4 py-3.5 font-sans">
                          <p className="text-slate-200 font-bold truncate max-w-[140px]">{asset.businessUnit}</p>
                          <p className="text-[10px] text-slate-500 truncate max-w-[140px]">{asset.accountName}</p>
                        </td>
                      )}

                      {/* Hosting / Provider */}
                      {visibleColumns.infrastructure && (
                        <td className="px-4 py-3.5">
                          <span className="text-slate-300 font-bold">{asset.cloudProvider}</span>
                          <p className="text-[10px] text-slate-500">{asset.infrastructureType} ({asset.region || asset.datacenter || 'Global'})</p>
                        </td>
                      )}

                      {/* IP / Hostname */}
                      {visibleColumns.ipHostname && (
                        <td className="px-4 py-3.5 font-mono">
                          <p className="text-slate-300 font-bold">{asset.ipAddress || '10.0.0.1'}</p>
                          <p className="text-[10px] text-slate-500 truncate max-w-[150px]" title={asset.hostname}>
                            {asset.hostname}
                          </p>
                        </td>
                      )}

                      {/* Specs */}
                      {visibleColumns.specs && (
                        <td className="px-4 py-3.5 text-slate-300">
                          <p className="text-[11px] font-bold">{asset.cpuCores} vCPU / {asset.ramGb}GB</p>
                          <p className="text-[10px] text-slate-500">{asset.storageGb}GB SSD</p>
                        </td>
                      )}

                      {/* Software */}
                      {visibleColumns.software && (
                        <td className="px-4 py-3.5">
                          <span className="px-2 py-0.5 rounded bg-purple-950/60 border border-purple-800 text-purple-300 text-[10px] font-bold">
                            {asset.installedSoftware.length} Software
                          </span>
                        </td>
                      )}

                      {/* Status */}
                      {visibleColumns.status && (
                        <td className="px-4 py-3.5">
                          <span className={`px-2.5 py-1 rounded text-[10px] font-bold border ${getStatusColor(asset.status)}`}>
                            ● {asset.status}
                          </span>
                        </td>
                      )}

                      {/* Owner */}
                      {visibleColumns.owner && (
                        <td className="px-4 py-3.5 text-slate-400 font-sans">
                          <p className="text-slate-300">{asset.ownerTeam}</p>
                          <p className="text-[10px] text-slate-500">{asset.responsiblePerson}</p>
                        </td>
                      )}

                      {/* Actions */}
                      {visibleColumns.actions && (
                        <td className="px-4 py-3.5 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleOpenDossier(asset)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                              title="View full asset dossier"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>

                            <button
                              onClick={() => handleOpenEditModal(asset)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-orange-400 hover:text-orange-300 transition-colors"
                              title="Edit asset details"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              onClick={() => handleToggleAsset(asset.id)}
                              className={`p-1.5 rounded-lg transition-colors ${
                                asset.status === 'ACTIVE'
                                  ? 'bg-slate-800 hover:bg-amber-950 text-slate-300 hover:text-amber-300'
                                  : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300'
                              }`}
                              title={asset.status === 'ACTIVE' ? "Deactivate asset" : "Activate asset"}
                            >
                              <Power className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}

                  {paginatedAssets.length === 0 && (
                    <tr>
                      <td colSpan={12} className="px-6 py-12 text-center text-slate-500 space-y-2">
                        <Boxes className="w-8 h-8 text-slate-600 mx-auto" />
                        {assets.length === 0 ? (
                          <>
                            <p className="text-sm font-bold text-slate-300">No inventory assets registered yet.</p>
                            <p className="text-xs text-slate-500 font-sans">
                              Start by adding your first compute server, database, cloud resource, or software asset.
                            </p>
                            <button
                              onClick={handleOpenCreateModal}
                              className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 text-white text-xs font-bold shadow transition-all hover:from-orange-500 hover:to-amber-400"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>Add First Asset</span>
                            </button>
                          </>
                        ) : (
                          <>
                            <p className="text-sm font-bold text-slate-400">No assets match your search & filter criteria.</p>
                            <p className="text-xs text-slate-600">Try adjusting your filters or click below to clear.</p>
                            <button
                              onClick={handleResetFilters}
                              className="mt-2 px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-orange-400 text-xs font-bold"
                            >
                              Clear All Filters
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {filteredAssets.length > 0 && (
              <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-[#0c121e]">
                <Pagination
                  currentPage={page}
                  pageSize={pageSize}
                  totalItems={filteredAssets.length}
                  onPageChange={setPage}
                  onPageSizeChange={(sz) => {
                    setPageSize(sz);
                    setPage(1);
                  }}
                  pageSizeOptions={[5, 10, 20, 50, 100]}
                />
              </div>
            )}
          </div>
        )}
      </div>
    )}

      {/* Modals */}
      <InventoryAssetModal
        isOpen={assetModalOpen}
        onClose={() => setAssetModalOpen(false)}
        onSave={handleSaveAsset}
        editingAsset={editingAsset}
        businessUnits={availableBUs}
        projects={availableAccounts}
        environments={availableEnvironments}
        softwareOptions={softwareList}
      />

      <InventoryAssetDossierModal
        asset={selectedAsset}
        isOpen={dossierModalOpen}
        onClose={() => setDossierModalOpen(false)}
        onEdit={(ast) => {
          setDossierModalOpen(false);
          handleOpenEditModal(ast);
        }}
        onStatusChange={handleStatusChange}
      />
    </div>
  );
};
