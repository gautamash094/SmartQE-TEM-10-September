import React, { useState } from 'react';
import { useTEM } from '../context/TEMContext';
import { Pagination } from '../components/common/Pagination';
import { Plus, FolderGit2, AppWindow, Search, Building2, Edit2, Power, Globe, ExternalLink, Copy, Check, Boxes } from 'lucide-react';
import { BusinessUnit, Project, ComponentEntity, ApplicationEntity } from '../services/portfolioService';
import { TableSkeleton } from '../components/common/Skeleton';
import { ButtonLoader } from '../components/common/ButtonLoader';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { isValidUrl, isValidCode, cleanTrim } from '../utils/validationUtils';

export const PortfolioPage: React.FC = () => {
  const {
    businessUnits,
    projects,
    components,
    applications,
    addBusinessUnit,
    updateBusinessUnit,
    toggleBusinessUnit,
    addProject,
    updateProject,
    toggleProject,
    addComponent,
    updateComponent,
    toggleComponent,
    addApplication,
    updateApplication,
    toggleApplication,
    showToast,
    isLoading
  } = useTEM();

  const [activeTab, setActiveTab] = useState<'bu' | 'projects' | 'components' | 'apps'>('bu');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSavingBU, setIsSavingBU] = useState(false);
  const [isSavingProj, setIsSavingProj] = useState(false);
  const [isSavingComp, setIsSavingComp] = useState(false);
  const [isSavingApp, setIsSavingApp] = useState(false);
  const [togglingId, setTogglingId] = useState<string | null>(null);
  const [copiedUrlId, setCopiedUrlId] = useState<string | null>(null);

  const [buPage, setBuPage] = useState<number>(1);
  const [buPageSize, setBuPageSize] = useState<number>(10);

  const [projPage, setProjPage] = useState<number>(1);
  const [projPageSize, setProjPageSize] = useState<number>(10);

  const [compPage, setCompPage] = useState<number>(1);
  const [compPageSize, setCompPageSize] = useState<number>(10);

  const [appPage, setAppPage] = useState<number>(1);
  const [appPageSize, setAppPageSize] = useState<number>(10);

  const [buModalOpen, setBuModalOpen] = useState(false);
  const [projModalOpen, setProjModalOpen] = useState(false);
  const [compModalOpen, setCompModalOpen] = useState(false);
  const [appModalOpen, setAppModalOpen] = useState(false);

  const [editingBU, setEditingBU] = useState<BusinessUnit | null>(null);
  const [editingProj, setEditingProj] = useState<Project | null>(null);
  const [editingComp, setEditingComp] = useState<ComponentEntity | null>(null);
  const [editingApp, setEditingApp] = useState<ApplicationEntity | null>(null);

  const [buForm, setBuForm] = useState({ name: '', code: '', lead: '', description: '' });
  const [projForm, setProjForm] = useState({ name: '', code: '', businessUnit: '', lead: '', status: 'ACTIVE' });
  const [compForm, setCompForm] = useState({
    name: '',
    code: '',
    businessUnit: '',
    projectName: '',
    endpointUrl: '',
    description: '',
    status: 'ACTIVE'
  });
  const [appForm, setAppForm] = useState({
    name: '',
    code: '',
    businessUnit: '',
    projectName: '',
    componentName: '',
    owner: ''
  });

  const isValidUrl = (urlString: string): boolean => {
    if (!urlString || !urlString.trim()) return false;
    try {
      const parsed = new URL(urlString.trim());
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  };

  const handleCopyUrl = (id: string, url: string) => {
    if (!url) return;
    navigator.clipboard.writeText(url);
    setCopiedUrlId(id);
    showToast('Endpoint URL copied to clipboard!', 'info');
    setTimeout(() => {
      setCopiedUrlId(null);
    }, 2000);
  };

  const handleOpenCreateBU = () => {
    setEditingBU(null);
    setBuForm({ name: '', code: '', lead: '', description: '' });
    setBuModalOpen(true);
  };

  const handleOpenEditBU = (bu: BusinessUnit) => {
    setEditingBU(bu);
    setBuForm({ name: bu.name, code: bu.code, lead: bu.lead || '', description: bu.description || '' });
    setBuModalOpen(true);
  };

  const handleOpenCreateProj = () => {
    setEditingProj(null);
    const defaultBU = businessUnits[0]?.name || '';
    setProjForm({ name: '', code: '', businessUnit: defaultBU, lead: '', status: 'ACTIVE' });
    setProjModalOpen(true);
  };

  const handleOpenEditProj = (proj: Project) => {
    setEditingProj(proj);
    setProjForm({
      name: proj.name,
      code: proj.code,
      businessUnit: proj.businessUnit,
      lead: proj.lead || '',
      status: proj.status || 'ACTIVE'
    });
    setProjModalOpen(true);
  };

  const handleOpenCreateComp = () => {
    setEditingComp(null);
    const defaultBU = businessUnits[0]?.name || '';
    const defaultProj = projects.find(p => p.businessUnit.toLowerCase() === defaultBU.toLowerCase())?.name || projects[0]?.name || '';
    setCompForm({
      name: '',
      code: '',
      businessUnit: defaultBU,
      projectName: defaultProj,
      endpointUrl: '',
      description: '',
      status: 'ACTIVE'
    });
    setCompModalOpen(true);
  };

  const handleOpenEditComp = (comp: ComponentEntity) => {
    setEditingComp(comp);
    setCompForm({
      name: comp.name,
      code: comp.code || '',
      businessUnit: comp.businessUnit,
      projectName: comp.projectName || '',
      endpointUrl: comp.endpointUrl || '',
      description: comp.description || '',
      status: comp.status || 'ACTIVE'
    });
    setCompModalOpen(true);
  };

  const handleOpenCreateApp = () => {
    setEditingApp(null);
    const defaultBU = businessUnits[0]?.name || '';
    const defaultProj = projects.find(p => p.businessUnit.toLowerCase() === defaultBU.toLowerCase())?.name || '';
    const defaultComp = components.find(c => (c.projectName || '').toLowerCase() === defaultProj.toLowerCase())?.name || '';
    setAppForm({
      name: '',
      code: '',
      businessUnit: defaultBU,
      projectName: defaultProj,
      componentName: defaultComp,
      owner: ''
    });
    setAppModalOpen(true);
  };

  const handleOpenEditApp = (app: ApplicationEntity) => {
    setEditingApp(app);
    setAppForm({
      name: app.name,
      code: app.code,
      businessUnit: app.businessUnit,
      projectName: app.projectName || '',
      componentName: app.componentName || '',
      owner: app.owner || ''
    });
    setAppModalOpen(true);
  };

  const handleSaveBU = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = buForm.name.trim();
    const cleanCode = buForm.code.trim().toUpperCase();

    if (!cleanName || !cleanCode) {
      showToast('Business Unit Name and Code are required and cannot be empty whitespace.', 'error');
      return;
    }
    if (!isValidCode(cleanCode)) {
      showToast('Code must be 2-30 characters (letters, numbers, dashes, underscores).', 'error');
      return;
    }

    // Check pre-save uniqueness
    const nameExists = businessUnits.some(
      b => (!editingBU || b.id !== editingBU.id) && b.name.toLowerCase() === cleanName.toLowerCase()
    );
    if (nameExists) {
      showToast(`A Business Unit named "${cleanName}" already exists.`, 'error');
      return;
    }

    const codeExists = businessUnits.some(
      b => (!editingBU || b.id !== editingBU.id) && b.code.toUpperCase() === cleanCode
    );
    if (codeExists) {
      showToast(`Business Unit Code "${cleanCode}" is already in use.`, 'error');
      return;
    }

    setIsSavingBU(true);
    try {
      if (editingBU) await updateBusinessUnit(editingBU.id, { ...buForm, name: cleanName, code: cleanCode });
      else await addBusinessUnit({ ...buForm, name: cleanName, code: cleanCode });
      setBuForm({ name: '', code: '', lead: '', description: '' });
      setEditingBU(null);
      setBuModalOpen(false);
      showToast(editingBU ? 'Business Unit updated successfully.' : 'Business Unit created successfully.', 'success');
    } finally { setIsSavingBU(false); }
  };

  const handleSaveProj = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = projForm.name.trim();
    const cleanCode = projForm.code.trim().toUpperCase();
    const cleanBU = projForm.businessUnit.trim();

    if (!cleanName || !cleanCode || !cleanBU) {
      showToast('Associated Business Unit, Project Name, and Project Code are mandatory (*).', 'error');
      return;
    }
    if (!isValidCode(cleanCode)) {
      showToast('Project Code must be 2-30 characters (alphanumeric, dashes, underscores).', 'error');
      return;
    }

    // Pre-save uniqueness
    const codeExists = projects.some(
      p => (!editingProj || p.id !== editingProj.id) && p.code.toUpperCase() === cleanCode
    );
    if (codeExists) {
      showToast(`Project Code "${cleanCode}" is already in use.`, 'error');
      return;
    }

    const nameExistsInBU = projects.some(
      p => (!editingProj || p.id !== editingProj.id) &&
           p.name.toLowerCase() === cleanName.toLowerCase() &&
           p.businessUnit.toLowerCase() === cleanBU.toLowerCase()
    );
    if (nameExistsInBU) {
      showToast(`A Project named "${cleanName}" already exists in Business Unit "${cleanBU}".`, 'error');
      return;
    }

    setIsSavingProj(true);
    try {
      if (editingProj) await updateProject(editingProj.id, { ...projForm, name: cleanName, code: cleanCode, businessUnit: cleanBU });
      else await addProject({ ...projForm, name: cleanName, code: cleanCode, businessUnit: cleanBU });
      setProjForm({ name: '', code: '', businessUnit: '', lead: '', status: 'ACTIVE' });
      setEditingProj(null);
      setProjModalOpen(false);
      showToast(editingProj ? 'Project updated successfully.' : 'Project created successfully.', 'success');
    } finally { setIsSavingProj(false); }
  };

  const handleSaveComp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = compForm.name.trim();
    const cleanCode = compForm.code ? compForm.code.trim().toUpperCase() : '';
    const cleanBU = compForm.businessUnit.trim();
    const cleanProj = compForm.projectName ? compForm.projectName.trim() : '';
    const cleanUrl = compForm.endpointUrl ? compForm.endpointUrl.trim() : '';

    if (!cleanName || !cleanBU) {
      showToast('Component Name and Business Unit are mandatory (*).', 'error');
      return;
    }

    if (cleanCode) {
      if (!isValidCode(cleanCode)) {
        showToast('Component Code must be 2-30 characters (alphanumeric, dashes, underscores).', 'error');
        return;
      }

      // Pre-save uniqueness check
      const codeExists = components.some(
        c => (!editingComp || c.id !== editingComp.id) && (c.code || '').toUpperCase() === cleanCode
      );
      if (codeExists) {
        showToast(`Component Code "${cleanCode}" is already in use.`, 'error');
        return;
      }
    }

    if (cleanUrl && !isValidUrl(cleanUrl)) {
      showToast('Please enter a valid Endpoint URL starting with http:// or https://', 'error');
      return;
    }

    setIsSavingComp(true);
    try {
      if (editingComp) {
        await updateComponent(editingComp.id, {
          name: cleanName,
          code: cleanCode || undefined,
          businessUnit: cleanBU,
          projectName: cleanProj || undefined,
          endpointUrl: cleanUrl,
          description: compForm.description
        });
      } else {
        await addComponent({
          name: cleanName,
          code: cleanCode || undefined,
          businessUnit: cleanBU,
          projectName: cleanProj || undefined,
          endpointUrl: cleanUrl,
          description: compForm.description,
          status: compForm.status || 'ACTIVE'
        });
      }
      setCompForm({ name: '', code: '', businessUnit: '', projectName: '', endpointUrl: '', description: '', status: 'ACTIVE' });
      setEditingComp(null);
      setCompModalOpen(false);
      showToast(editingComp ? 'Component updated successfully.' : 'Component registered successfully.', 'success');
    } finally { setIsSavingComp(false); }
  };

  const handleSaveApp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = appForm.name.trim();
    const cleanCode = appForm.code.trim().toUpperCase();
    const cleanBU = appForm.businessUnit.trim();
    const cleanProj = appForm.projectName.trim();
    const cleanComp = appForm.componentName.trim();
    const cleanOwner = appForm.owner.trim();

    if (!cleanName || !cleanCode || !cleanBU || !cleanProj || !cleanComp || !cleanOwner) {
      showToast('All fields including Associated Project, Associated Component, and Owner are mandatory (*)', 'error');
      return;
    }
    if (!isValidCode(cleanCode)) {
      showToast('Application Code must be 2-30 characters (alphanumeric, dashes, underscores).', 'error');
      return;
    }

    // Pre-save uniqueness
    const codeExists = applications.some(
      a => (!editingApp || a.id !== editingApp.id) && a.code.toUpperCase() === cleanCode
    );
    if (codeExists) {
      showToast(`Application Code "${cleanCode}" is already in use.`, 'error');
      return;
    }

    const nameExists = applications.some(
      a => (!editingApp || a.id !== editingApp.id) && a.name.toLowerCase() === cleanName.toLowerCase()
    );
    if (nameExists) {
      showToast(`An Application named "${cleanName}" is already registered.`, 'error');
      return;
    }

    setIsSavingApp(true);
    try {
      if (editingApp) await updateApplication(editingApp.id, { ...appForm, name: cleanName, code: cleanCode, businessUnit: cleanBU, projectName: cleanProj, componentName: cleanComp, owner: cleanOwner });
      else await addApplication({ ...appForm, name: cleanName, code: cleanCode, businessUnit: cleanBU, projectName: cleanProj, componentName: cleanComp, owner: cleanOwner });
      setAppForm({ name: '', code: '', businessUnit: '', projectName: '', componentName: '', owner: '' });
      setEditingApp(null);
      setAppModalOpen(false);
      showToast(editingApp ? 'Application updated successfully.' : 'Application registered successfully.', 'success');
    } finally { setIsSavingApp(false); }
  };

  const handleToggleBU = async (id: string) => { setTogglingId(id); try { await toggleBusinessUnit(id); } finally { setTogglingId(null); } };
  const handleToggleProj = async (id: string) => { setTogglingId(id); try { await toggleProject(id); } finally { setTogglingId(null); } };
  const handleToggleComp = async (id: string) => { setTogglingId(id); try { await toggleComponent(id); } finally { setTogglingId(null); } };
  const handleToggleApp = async (id: string) => { setTogglingId(id); try { await toggleApplication(id); } finally { setTogglingId(null); } };

  const handleSearchChange = (q: string) => {
    setSearchQuery(q);
    setBuPage(1);
    setProjPage(1);
    setCompPage(1);
    setAppPage(1);
  };

  const filteredBUs = businessUnits.filter(b => b.name.toLowerCase().includes(searchQuery.toLowerCase()) || b.code.toLowerCase().includes(searchQuery.toLowerCase()));
  const filteredProjects = projects.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.businessUnit.toLowerCase().includes(searchQuery.toLowerCase()));
  const filteredComponents = components.filter(c =>
    (c.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (c.code ? c.code.toLowerCase().includes(searchQuery.toLowerCase()) : false) ||
    (c.businessUnit || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (c.projectName ? c.projectName.toLowerCase().includes(searchQuery.toLowerCase()) : false) ||
    (c.endpointUrl ? c.endpointUrl.toLowerCase().includes(searchQuery.toLowerCase()) : false)
  );
  const filteredApps = applications.filter(a => a.name.toLowerCase().includes(searchQuery.toLowerCase()) || a.businessUnit.toLowerCase().includes(searchQuery.toLowerCase()));

  const paginatedBUs = filteredBUs.slice((buPage - 1) * buPageSize, buPage * buPageSize);
  const paginatedProjects = filteredProjects.slice((projPage - 1) * projPageSize, projPage * projPageSize);
  const paginatedComponents = filteredComponents.slice((compPage - 1) * compPageSize, compPage * compPageSize);
  const paginatedApps = filteredApps.slice((appPage - 1) * appPageSize, appPage * appPageSize);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">ENTERPRISE ENTITIES</span>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Entity Management</h1>
          <p className="text-sm text-slate-400 mt-1">Manage Business Units, Projects, Components, and Applications across the enterprise ecosystem.</p>
        </div>
        <div className="flex items-center gap-2">
          {activeTab === 'bu' && <button onClick={handleOpenCreateBU} className="flex items-center gap-2 px-4 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 shadow-[0_0_16px_rgba(249,115,22,0.4)]"><Plus className="w-4 h-4" /> NEW BUSINESS UNIT</button>}
          {activeTab === 'projects' && <button onClick={handleOpenCreateProj} className="flex items-center gap-2 px-4 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 shadow-[0_0_16px_rgba(249,115,22,0.4)]"><Plus className="w-4 h-4" /> NEW PROJECT</button>}
          {activeTab === 'components' && <button onClick={handleOpenCreateComp} className="flex items-center gap-2 px-4 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 shadow-[0_0_16px_rgba(249,115,22,0.4)]"><Plus className="w-4 h-4" /> NEW COMPONENT</button>}
          {activeTab === 'apps' && <button onClick={handleOpenCreateApp} className="flex items-center gap-2 px-4 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 shadow-[0_0_16px_rgba(249,115,22,0.4)]"><Plus className="w-4 h-4" /> NEW APPLICATION</button>}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
        <div onClick={() => setActiveTab('bu')} className={`p-5 rounded-lg border cursor-pointer transition-all ${activeTab === 'bu' ? 'bg-[#152032] border-orange-500 shadow-lg' : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'}`}>
          <div className="flex items-center justify-between"><span className="text-[10px] uppercase font-bold text-slate-400">BUSINESS UNITS</span><Building2 className="w-4 h-4 text-orange-400" /></div>
          <p className="text-3xl font-extrabold text-white mt-2">{businessUnits.length}</p>
          <p className="text-[11px] text-slate-400 mt-1">Divisions & Guilds</p>
        </div>
        <div onClick={() => setActiveTab('projects')} className={`p-5 rounded-lg border cursor-pointer transition-all ${activeTab === 'projects' ? 'bg-[#152032] border-orange-500 shadow-lg' : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'}`}>
          <div className="flex items-center justify-between"><span className="text-[10px] uppercase font-bold text-slate-400">PROJECTS</span><FolderGit2 className="w-4 h-4 text-blue-400" /></div>
          <p className="text-3xl font-extrabold text-white mt-2">{projects.length}</p>
          <p className="text-[11px] text-slate-400 mt-1">Active Deliverables</p>
        </div>
        <div onClick={() => setActiveTab('components')} className={`p-5 rounded-lg border cursor-pointer transition-all ${activeTab === 'components' ? 'bg-[#152032] border-orange-500 shadow-lg' : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'}`}>
          <div className="flex items-center justify-between"><span className="text-[10px] uppercase font-bold text-slate-400">COMPONENTS</span><Boxes className="w-4 h-4 text-purple-400" /></div>
          <p className="text-3xl font-extrabold text-white mt-2">{components.length}</p>
          <p className="text-[11px] text-slate-400 mt-1">Services & Endpoints</p>
        </div>
        <div onClick={() => setActiveTab('apps')} className={`p-5 rounded-lg border cursor-pointer transition-all ${activeTab === 'apps' ? 'bg-[#152032] border-orange-500 shadow-lg' : 'bg-[#0f1724] border-slate-200 dark:border-slate-800 hover:border-slate-700'}`}>
          <div className="flex items-center justify-between"><span className="text-[10px] uppercase font-bold text-slate-400">APPLICATIONS</span><AppWindow className="w-4 h-4 text-emerald-400" /></div>
          <p className="text-3xl font-extrabold text-white mt-2">{applications.length}</p>
          <p className="text-[11px] text-slate-400 mt-1">Registered Services</p>
        </div>
      </div>

      <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-3 rounded-lg flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1 bg-slate-950/60 p-1 rounded border border-slate-200 dark:border-slate-800 text-xs font-mono overflow-x-auto max-w-full">
          <button onClick={() => setActiveTab('bu')} className={`px-4 py-1.5 rounded font-bold transition-colors shrink-0 ${activeTab === 'bu' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'}`}>🏢 Business Units ({businessUnits.length})</button>
          <button onClick={() => setActiveTab('projects')} className={`px-4 py-1.5 rounded font-bold transition-colors shrink-0 ${activeTab === 'projects' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'}`}>📁 Projects ({projects.length})</button>
          <button onClick={() => setActiveTab('components')} className={`px-4 py-1.5 rounded font-bold transition-colors shrink-0 ${activeTab === 'components' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'}`}>🧩 Components ({components.length})</button>
          <button onClick={() => setActiveTab('apps')} className={`px-4 py-1.5 rounded font-bold transition-colors shrink-0 ${activeTab === 'apps' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'}`}>📱 Applications ({applications.length})</button>
        </div>
        <div className="relative flex-1 max-w-md w-full">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input autoComplete="off" data-lpignore="true" type="text" value={searchQuery} onChange={(e) => handleSearchChange(e.target.value)} placeholder="search catalog by name, code, BU, endpoint..." className="w-full bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded pl-9 pr-4 py-2 text-xs text-white font-mono placeholder:text-slate-500 focus:outline-none focus:border-orange-500" />
        </div>
      </div>

      {activeTab === 'bu' && (
        isLoading ? <TableSkeleton rows={buPageSize} columns={7} /> :
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold">
                <tr><th className="p-3.5">CODE</th><th className="p-3.5">BUSINESS UNIT NAME</th><th className="p-3.5">LEAD</th><th className="p-3.5">DESCRIPTION</th><th className="p-3.5 text-right">PROJECTS COUNT</th><th className="p-3.5">STATUS</th><th className="p-3.5 text-right">ACTIONS</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {paginatedBUs.length === 0 ? <tr><td colSpan={7} className="p-8 text-center text-slate-500">No business units found matching your criteria.</td></tr> :
                  paginatedBUs.map(bu => {
                    const isBUActive = bu.isActive !== false && bu.status !== 'INACTIVE';
                    const isTogglingThis = togglingId === bu.id;
                    return (
                      <tr key={bu.id} className="hover:bg-slate-800/40">
                        <td className="p-3.5"><span className="bg-slate-800 px-2 py-0.5 rounded text-orange-400 font-bold">{bu.code}</span></td>
                        <td className="p-3.5 font-bold text-white text-sm">{bu.name}</td>
                        <td className="p-3.5 text-slate-300 font-sans">{bu.lead || 'N/A'}</td>
                        <td className="p-3.5 text-slate-400 max-w-xs truncate">{bu.description || 'No description provided'}</td>
                        <td className="p-3.5 text-right font-bold text-white">{projects.filter(p => p.businessUnit.toLowerCase() === bu.name.toLowerCase()).length}</td>
                        <td className="p-3.5"><span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${isBUActive ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80' : 'bg-slate-900 text-slate-400 border-slate-700'}`}><span className={`w-1.5 h-1.5 rounded-full ${isBUActive ? 'bg-emerald-400' : 'bg-slate-500'}`} />{isBUActive ? 'Active' : 'Inactive'}</span></td>
                        <td className="p-3.5 text-right space-x-2"><button onClick={() => handleOpenEditBU(bu)} className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-orange-400 hover:text-orange-300 text-xs font-bold inline-flex items-center gap-1.5 transition-colors border border-slate-700"><Edit2 className="w-3 h-3" /> Edit</button><button onClick={() => handleToggleBU(bu.id)} disabled={isTogglingThis} className={`px-2.5 py-1 rounded text-xs font-bold inline-flex items-center gap-1.5 transition-colors border ${isBUActive ? 'bg-slate-800 hover:bg-amber-950/80 text-slate-300 hover:text-amber-300 border-slate-700 hover:border-amber-700' : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-700'} ${isTogglingThis ? 'opacity-70 cursor-wait' : ''}`}>{isTogglingThis ? <LoadingSpinner size="xs" variant={isBUActive ? 'slate' : 'accent'} inline /> : <Power className={`w-3 h-3 ${isBUActive ? 'text-slate-400' : 'text-emerald-400'}`} />}<span>{isBUActive ? 'Deactivate' : 'Activate'}</span></button></td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          <Pagination currentPage={buPage} totalItems={filteredBUs.length} pageSize={buPageSize} onPageChange={setBuPage} onPageSizeChange={(s) => { setBuPageSize(s); setBuPage(1); }} pageSizeOptions={[10, 20, 50]} />
        </div>
      )}

      {activeTab === 'projects' && (
        isLoading ? <TableSkeleton rows={projPageSize} columns={6} /> :
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold">
                <tr><th className="p-3.5">CODE</th><th className="p-3.5">PROJECT NAME</th><th className="p-3.5">BUSINESS UNIT</th><th className="p-3.5">LEAD</th><th className="p-3.5">STATUS</th><th className="p-3.5 text-right">ACTIONS</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {paginatedProjects.length === 0 ? <tr><td colSpan={6} className="p-8 text-center text-slate-500">No projects found matching your criteria.</td></tr> :
                  paginatedProjects.map(proj => {
                    const isProjActive = proj.isActive !== false && proj.status !== 'INACTIVE';
                    const isTogglingThis = togglingId === proj.id;
                    return (
                      <tr key={proj.id} className="hover:bg-slate-800/40">
                        <td className="p-3.5"><span className="bg-slate-800 px-2 py-0.5 rounded text-blue-400 font-bold">{proj.code}</span></td>
                        <td className="p-3.5 font-bold text-white text-sm">{proj.name}</td>
                        <td className="p-3.5"><span className="text-orange-400 font-bold">{proj.businessUnit}</span></td>
                        <td className="p-3.5 text-slate-300 font-sans">{proj.lead || 'N/A'}</td>
                        <td className="p-3.5"><span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${isProjActive ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80' : 'bg-slate-900 text-slate-400 border-slate-700'}`}><span className={`w-1.5 h-1.5 rounded-full ${isProjActive ? 'bg-emerald-400' : 'bg-slate-500'}`} />{isProjActive ? 'Active' : 'Inactive'}</span></td>
                        <td className="p-3.5 text-right space-x-2"><button onClick={() => handleOpenEditProj(proj)} className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-blue-300 text-xs font-bold inline-flex items-center gap-1.5 transition-colors border border-slate-700"><Edit2 className="w-3 h-3" /> Edit</button><button onClick={() => handleToggleProj(proj.id)} disabled={isTogglingThis} className={`px-2.5 py-1 rounded text-xs font-bold inline-flex items-center gap-1.5 transition-colors border ${isProjActive ? 'bg-slate-800 hover:bg-amber-950/80 text-slate-300 hover:text-amber-300 border-slate-700 hover:border-amber-700' : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-700'} ${isTogglingThis ? 'opacity-70 cursor-wait' : ''}`}>{isTogglingThis ? <LoadingSpinner size="xs" variant={isProjActive ? 'slate' : 'accent'} inline /> : <Power className={`w-3 h-3 ${isProjActive ? 'text-slate-400' : 'text-emerald-400'}`} />}<span>{isProjActive ? 'Deactivate' : 'Activate'}</span></button></td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          <Pagination currentPage={projPage} totalItems={filteredProjects.length} pageSize={projPageSize} onPageChange={setProjPage} onPageSizeChange={(s) => { setProjPageSize(s); setProjPage(1); }} pageSizeOptions={[10, 20, 50]} />
        </div>
      )}

      {activeTab === 'components' && (
        isLoading ? <TableSkeleton rows={compPageSize} columns={8} /> :
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold">
                <tr><th className="p-3.5">CODE</th><th className="p-3.5">COMPONENT NAME</th><th className="p-3.5">BUSINESS UNIT</th><th className="p-3.5">PROJECT</th><th className="p-3.5">ENDPOINT URL</th><th className="p-3.5">DESCRIPTION</th><th className="p-3.5">STATUS</th><th className="p-3.5 text-right">ACTIONS</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {paginatedComponents.length === 0 ? <tr><td colSpan={8} className="p-8 text-center text-slate-500">No components found matching your criteria.</td></tr> :
                  paginatedComponents.map(comp => {
                    const isCompActive = comp.isActive !== false && comp.status !== 'INACTIVE';
                    const isTogglingThis = togglingId === comp.id;
                    const hasUrl = !!comp.endpointUrl && comp.endpointUrl.trim().length > 0;
                    const isCopied = copiedUrlId === comp.id;
                    return (
                      <tr key={comp.id} className="hover:bg-slate-800/40">
                        <td className="p-3.5">
                          {comp.code ? (
                            <span className="bg-purple-950/60 text-purple-300 border border-purple-800/60 px-2 py-0.5 rounded font-bold">
                              {comp.code}
                            </span>
                          ) : (
                            <span className="text-slate-500 italic text-[11px]">—</span>
                          )}
                        </td>
                        <td className="p-3.5 font-bold text-white text-sm">{comp.name}</td>
                        <td className="p-3.5"><span className="text-orange-400 font-bold">{comp.businessUnit}</span></td>
                        <td className="p-3.5 text-blue-300 font-semibold">
                          {comp.projectName || <span className="text-slate-500 italic font-normal">—</span>}
                        </td>
                        <td className="p-3.5 max-w-xs">
                          {hasUrl ? (
                            <div className="flex items-center gap-1.5 group/url">
                              <a href={comp.endpointUrl} target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:text-cyan-300 font-sans underline underline-offset-2 truncate flex items-center gap-1 max-w-[200px]" title={comp.endpointUrl}><Globe className="w-3 h-3 shrink-0" /><span className="truncate">{comp.endpointUrl}</span><ExternalLink className="w-2.5 h-2.5 shrink-0 opacity-70 group-hover/url:opacity-100" /></a>
                              <button onClick={() => comp.endpointUrl && handleCopyUrl(comp.id, comp.endpointUrl)} className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition-colors" title="Copy Endpoint URL">{isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}</button>
                            </div>
                          ) : <span className="text-slate-500 italic">No URL configured</span>}
                        </td>
                        <td className="p-3.5 text-slate-400 max-w-xs truncate">{comp.description || 'No description'}</td>
                        <td className="p-3.5"><span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${isCompActive ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80' : 'bg-slate-900 text-slate-400 border-slate-700'}`}><span className={`w-1.5 h-1.5 rounded-full ${isCompActive ? 'bg-emerald-400' : 'bg-slate-500'}`} />{isCompActive ? 'Active' : 'Inactive'}</span></td>
                        <td className="p-3.5 text-right space-x-2"><button onClick={() => handleOpenEditComp(comp)} className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-purple-400 hover:text-purple-300 text-xs font-bold inline-flex items-center gap-1.5 transition-colors border border-slate-700"><Edit2 className="w-3 h-3" /> Edit</button><button onClick={() => handleToggleComp(comp.id)} disabled={isTogglingThis} className={`px-2.5 py-1 rounded text-xs font-bold inline-flex items-center gap-1.5 transition-colors border ${isCompActive ? 'bg-slate-800 hover:bg-amber-950/80 text-slate-300 hover:text-amber-300 border-slate-700 hover:border-amber-700' : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-700'} ${isTogglingThis ? 'opacity-70 cursor-wait' : ''}`}>{isTogglingThis ? <LoadingSpinner size="xs" variant={isCompActive ? 'slate' : 'accent'} inline /> : <Power className={`w-3 h-3 ${isCompActive ? 'text-slate-400' : 'text-emerald-400'}`} />}<span>{isCompActive ? 'Deactivate' : 'Activate'}</span></button></td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          <Pagination currentPage={compPage} totalItems={filteredComponents.length} pageSize={compPageSize} onPageChange={setCompPage} onPageSizeChange={(s) => { setCompPageSize(s); setCompPage(1); }} pageSizeOptions={[10, 20, 50]} />
        </div>
      )}

      {activeTab === 'apps' && (
        isLoading ? <TableSkeleton rows={appPageSize} columns={7} /> :
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold">
                <tr><th className="p-3.5">CODE</th><th className="p-3.5">APPLICATION NAME</th><th className="p-3.5">BUSINESS UNIT</th><th className="p-3.5">PROJECT</th><th className="p-3.5">COMPONENT</th><th className="p-3.5">OWNER</th><th className="p-3.5">STATUS</th><th className="p-3.5 text-right">ACTIONS</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {paginatedApps.length === 0 ? <tr><td colSpan={8} className="p-8 text-center text-slate-500">No applications found matching your criteria.</td></tr> :
                  paginatedApps.map(app => {
                    const isAppActive = app.isActive !== false && app.status !== 'INACTIVE';
                    const isTogglingThis = togglingId === app.id;
                    return (
                      <tr key={app.id} className="hover:bg-slate-800/40">
                        <td className="p-3.5"><span className="bg-slate-800 px-2 py-0.5 rounded text-emerald-400 font-bold">{app.code}</span></td>
                        <td className="p-3.5 font-bold text-white text-sm">{app.name}</td>
                        <td className="p-3.5"><span className="text-orange-400 font-bold">{app.businessUnit}</span></td>
                        <td className="p-3.5 text-slate-300">{app.projectName || 'General'}</td>
                        <td className="p-3.5 text-purple-300 font-semibold">{app.componentName || 'N/A'}</td>
                        <td className="p-3.5 text-slate-300 font-sans">{app.owner}</td>
                        <td className="p-3.5"><span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${isAppActive ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80' : 'bg-slate-900 text-slate-400 border-slate-700'}`}><span className={`w-1.5 h-1.5 rounded-full ${isAppActive ? 'bg-emerald-400' : 'bg-slate-500'}`} />{isAppActive ? 'Active' : 'Inactive'}</span></td>
                        <td className="p-3.5 text-right space-x-2"><button onClick={() => handleOpenEditApp(app)} className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 text-xs font-bold inline-flex items-center gap-1.5 transition-colors border border-slate-700"><Edit2 className="w-3 h-3" /> Edit</button><button onClick={() => handleToggleApp(app.id)} disabled={isTogglingThis} className={`px-2.5 py-1 rounded text-xs font-bold inline-flex items-center gap-1.5 transition-colors border ${isAppActive ? 'bg-slate-800 hover:bg-amber-950/80 text-slate-300 hover:text-amber-300 border-slate-700 hover:border-amber-700' : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-700'} ${isTogglingThis ? 'opacity-70 cursor-wait' : ''}`}>{isTogglingThis ? <LoadingSpinner size="xs" variant={isAppActive ? 'slate' : 'accent'} inline /> : <Power className={`w-3 h-3 ${isAppActive ? 'text-slate-400' : 'text-emerald-400'}`} />}<span>{isAppActive ? 'Deactivate' : 'Activate'}</span></button></td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          <Pagination currentPage={appPage} totalItems={filteredApps.length} pageSize={appPageSize} onPageChange={setAppPage} onPageSizeChange={(s) => { setAppPageSize(s); setAppPage(1); }} pageSizeOptions={[10, 20, 50]} />
        </div>
      )}

      {/* MODAL 1: ADD / EDIT BUSINESS UNIT */}
      {buModalOpen && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-lg max-w-md w-full p-6 space-y-4 font-mono text-xs relative shadow-2xl">
            <button onClick={() => setBuModalOpen(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white text-base">✕</button>
            <span className="text-[10px] uppercase text-orange-400 font-bold">ORGANIZATIONAL REGISTRY</span>
            <h2 className="text-xl font-bold text-white">{editingBU ? 'Edit Business Unit' : 'Add Business Unit'}</h2>
            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveBU} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">BUSINESS UNIT NAME *</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={buForm.name}
                  onChange={e => setBuForm({ ...buForm, name: e.target.value })}
                  placeholder="e.g. Wealth Management"
                  disabled={!!editingBU}
                  className={`w-full border rounded p-2 text-white ${
                    editingBU ? 'bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400 cursor-not-allowed' : 'bg-[#161f2e] border-slate-700'
                  }`}
                  required
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">CODE *</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={buForm.code}
                  onChange={e => setBuForm({ ...buForm, code: e.target.value.toUpperCase() })}
                  placeholder="e.g. WM"
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white uppercase"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">DEPARTMENT LEAD</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={buForm.lead}
                  onChange={e => setBuForm({ ...buForm, lead: e.target.value })}
                  placeholder="e.g. Elena Rostova"
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">DESCRIPTION</label>
                <textarea
                  value={buForm.description}
                  onChange={e => setBuForm({ ...buForm, description: e.target.value })}
                  placeholder="Brief description of operations..."
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white h-20"
                />
              </div>
              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button type="button" onClick={() => setBuModalOpen(false)} disabled={isSavingBU} className="px-4 py-2 rounded bg-slate-800 text-slate-300 disabled:opacity-50">CANCEL</button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingBU}
                  loadingText="SAVING..."
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold transition-colors"
                >
                  {editingBU ? 'UPDATE BUSINESS UNIT' : 'SAVE BUSINESS UNIT'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: ADD / EDIT PROJECT */}
      {projModalOpen && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-lg max-w-md w-full p-6 space-y-4 font-mono text-xs relative shadow-2xl">
            <button onClick={() => setProjModalOpen(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white text-base">✕</button>
            <span className="text-[10px] uppercase text-blue-400 font-bold">PROJECT REGISTRY</span>
            <h2 className="text-xl font-bold text-white">{editingProj ? 'Edit Project' : 'Add Project'}</h2>
            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveProj} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">ASSOCIATED BUSINESS UNIT *</label>
                <select
                  value={projForm.businessUnit}
                  onChange={e => setProjForm({ ...projForm, businessUnit: e.target.value })}
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                  required
                >
                  <option value="">Select Business Unit...</option>
                  {businessUnits.map(b => (
                    <option key={b.id} value={b.name}>
                      {b.name} ({b.code})
                    </option>
                  ))}
                </select>
                {businessUnits.length === 0 && (
                  <p className="text-[10px] text-amber-400 mt-1">
                    ⚠ No Business Units registered yet. Please create a Business Unit first.
                  </p>
                )}
              </div>
              <div>
                <label className="block text-slate-400 mb-1">PROJECT NAME *</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={projForm.name}
                  onChange={e => setProjForm({ ...projForm, name: e.target.value })}
                  placeholder="e.g. Instant Loan Disbursal"
                  disabled={!!editingProj}
                  className={`w-full border rounded p-2 text-white ${
                    editingProj ? 'bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400 cursor-not-allowed' : 'bg-[#161f2e] border-slate-700'
                  }`}
                  required
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">PROJECT CODE *</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={projForm.code}
                  onChange={e => setProjForm({ ...projForm, code: e.target.value.toUpperCase() })}
                  placeholder="e.g. LOAN-DISBURSAL"
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white uppercase"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">PROJECT LEAD</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={projForm.lead}
                  onChange={e => setProjForm({ ...projForm, lead: e.target.value })}
                  placeholder="e.g. Jessica M."
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button type="button" onClick={() => setProjModalOpen(false)} disabled={isSavingProj} className="px-4 py-2 rounded bg-slate-800 text-slate-300 disabled:opacity-50">CANCEL</button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingProj}
                  loadingText="SAVING..."
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold transition-colors"
                >
                  {editingProj ? 'UPDATE PROJECT' : 'SAVE PROJECT'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: ADD / EDIT COMPONENT */}
      {compModalOpen && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-lg max-w-lg w-full p-6 space-y-4 font-mono text-xs relative shadow-2xl">
            <button onClick={() => setCompModalOpen(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white text-base">✕</button>
            <span className="text-[10px] uppercase text-purple-400 font-bold">COMPONENT REGISTRY</span>
            <h2 className="text-xl font-bold text-white">{editingComp ? 'Edit Component' : 'Add Component'}</h2>
            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveComp} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">COMPONENT NAME *</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={compForm.name}
                  onChange={e => setCompForm({ ...compForm, name: e.target.value })}
                  placeholder="e.g. Payment Service"
                  disabled={!!editingComp}
                  className={`w-full border rounded p-2 text-white ${
                    editingComp ? 'bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400 cursor-not-allowed' : 'bg-[#161f2e] border-slate-700'
                  }`}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">COMPONENT ID / CODE</label>
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={compForm.code}
                    onChange={e => setCompForm({ ...compForm, code: e.target.value.toUpperCase() })}
                    placeholder="e.g. COMP-001 (Optional)"
                    className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white uppercase"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">BUSINESS UNIT *</label>
                  <select
                    value={compForm.businessUnit}
                    onChange={e => {
                      setCompForm({ ...compForm, businessUnit: e.target.value });
                    }}
                    className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                    required
                  >
                    <option value="">Select Business Unit...</option>
                    {businessUnits.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">ASSOCIATED PROJECT</label>
                <select
                  value={compForm.projectName}
                  onChange={e => setCompForm({ ...compForm, projectName: e.target.value })}
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                >
                  <option value="">(None / Unassigned)</option>
                  {projects
                    .filter(p => !compForm.businessUnit || p.businessUnit.toLowerCase() === compForm.businessUnit.toLowerCase())
                    .map(p => <option key={p.id} value={p.name}>{p.name}</option>)}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-400 font-bold flex items-center gap-1.5"><Globe className="w-3.5 h-3.5 text-cyan-400" /> ENDPOINT URL</label>
                  {compForm.endpointUrl && compForm.endpointUrl.trim() && (
                    <span className={`text-[10px] font-bold ${isValidUrl(compForm.endpointUrl) ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {isValidUrl(compForm.endpointUrl) ? '✓ Valid URL' : '⚠ Invalid URL format'}
                    </span>
                  )}
                </div>
                <input autoComplete="off" data-lpignore="true"
                  type="url"
                  value={compForm.endpointUrl}
                  onChange={e => setCompForm({ ...compForm, endpointUrl: e.target.value })}
                  placeholder="https://payment.company.com/api"
                  className={`w-full bg-[#161f2e] border rounded p-2 text-white font-sans ${
                    compForm.endpointUrl && !isValidUrl(compForm.endpointUrl)
                      ? 'border-amber-500/80 focus:border-amber-500'
                      : 'border-slate-700 focus:border-cyan-500'
                  }`}
                />
                <p className="text-[10px] text-slate-500 mt-1">Full endpoint route including protocol (e.g. <span className="text-cyan-400 font-mono">https://service.domain.com/v1</span>).</p>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">DESCRIPTION</label>
                <textarea
                  value={compForm.description}
                  onChange={e => setCompForm({ ...compForm, description: e.target.value })}
                  placeholder="Handles payment processing, transaction verification, etc."
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white h-16"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button type="button" onClick={() => setCompModalOpen(false)} disabled={isSavingComp} className="px-4 py-2 rounded bg-slate-800 text-slate-300 disabled:opacity-50">CANCEL</button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingComp}
                  loadingText="SAVING..."
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold transition-colors"
                >
                  {editingComp ? 'UPDATE COMPONENT' : 'SAVE COMPONENT'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: ADD / EDIT APPLICATION */}
      {appModalOpen && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-lg max-w-md w-full p-6 space-y-4 font-mono text-xs relative shadow-2xl">
            <button onClick={() => setAppModalOpen(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white text-base">✕</button>
            <span className="text-[10px] uppercase text-emerald-400 font-bold">APPLICATION REGISTRY</span>
            <h2 className="text-xl font-bold text-white">{editingApp ? 'Edit Application' : 'Add Application'}</h2>
            <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveApp} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">BUSINESS UNIT *</label>
                <select
                  value={appForm.businessUnit}
                  onChange={e => {
                    const newBU = e.target.value;
                    const defaultProj = projects.find(p => p.businessUnit.toLowerCase() === newBU.toLowerCase())?.name || '';
                    const defaultComp = components.find(c => (c.projectName || '').toLowerCase() === defaultProj.toLowerCase() && c.businessUnit.toLowerCase() === newBU.toLowerCase())?.name || '';
                    setAppForm({ ...appForm, businessUnit: newBU, projectName: defaultProj, componentName: defaultComp });
                  }}
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                  required
                >
                  <option value="">Select Business Unit...</option>
                  {businessUnits.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                </select>
                {businessUnits.length === 0 && (
                  <p className="text-[10px] text-amber-400 mt-1">
                    ⚠ No Business Units found. Please create a Business Unit first.
                  </p>
                )}
              </div>
              <div>
                <label className="block text-slate-400 mb-1">ASSOCIATED PROJECT *</label>
                <select
                  value={appForm.projectName}
                  onChange={e => {
                    const newProj = e.target.value;
                    const defaultComp = components.find(c => (c.projectName || '').toLowerCase() === newProj.toLowerCase() && (!appForm.businessUnit || c.businessUnit.toLowerCase() === appForm.businessUnit.toLowerCase()))?.name || '';
                    setAppForm({ ...appForm, projectName: newProj, componentName: defaultComp });
                  }}
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                  required
                >
                  <option value="">Select Associated Project...</option>
                  {projects
                    .filter(p => !appForm.businessUnit || p.businessUnit.toLowerCase() === appForm.businessUnit.toLowerCase())
                    .map(p => <option key={p.id} value={p.name}>{p.name}</option>)}
                </select>
                {projects.filter(p => !appForm.businessUnit || p.businessUnit.toLowerCase() === appForm.businessUnit.toLowerCase()).length === 0 && (
                  <p className="text-[10px] text-amber-400 mt-1">
                    ⚠ No Projects registered under the selected Business Unit. Please create a Project first.
                  </p>
                )}
              </div>
              <div>
                <label className="block text-slate-400 mb-1">ASSOCIATED COMPONENT *</label>
                <select
                  value={appForm.componentName}
                  onChange={e => setAppForm({ ...appForm, componentName: e.target.value })}
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                  required
                >
                  <option value="">Select Associated Component...</option>
                  {components
                    .filter(c => (!appForm.projectName || (c.projectName || '').toLowerCase() === appForm.projectName.toLowerCase()) && (!appForm.businessUnit || c.businessUnit.toLowerCase() === appForm.businessUnit.toLowerCase()))
                    .map(c => <option key={c.id} value={c.name}>{c.name} {c.code ? `(${c.code})` : ''}</option>)}
                </select>
                {components.filter(c => (!appForm.projectName || (c.projectName || '').toLowerCase() === appForm.projectName.toLowerCase()) && (!appForm.businessUnit || c.businessUnit.toLowerCase() === appForm.businessUnit.toLowerCase())).length === 0 && (
                  <p className="text-[10px] text-amber-400 mt-1">
                    ⚠ No Components registered under the selected Project. Please create a Component first.
                  </p>
                )}
              </div>
              <div>
                <label className="block text-slate-400 mb-1">APPLICATION NAME *</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={appForm.name}
                  onChange={e => setAppForm({ ...appForm, name: e.target.value })}
                  placeholder="e.g. Credit Decision Engine"
                  disabled={!!editingApp}
                  className={`w-full border rounded p-2 text-white ${
                    editingApp ? 'bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400 cursor-not-allowed' : 'bg-[#161f2e] border-slate-700'
                  }`}
                  required
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">APPLICATION CODE *</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={appForm.code}
                  onChange={e => setAppForm({ ...appForm, code: e.target.value.toUpperCase() })}
                  placeholder="e.g. CRED-ENGINE"
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white uppercase"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">APPLICATION OWNER *</label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={appForm.owner}
                  onChange={e => setAppForm({ ...appForm, owner: e.target.value })}
                  placeholder="e.g. Jessica M."
                  className="w-full bg-[#161f2e] border border-slate-700 rounded p-2 text-white"
                  required
                />
              </div>
              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button type="button" onClick={() => setAppModalOpen(false)} disabled={isSavingApp} className="px-4 py-2 rounded bg-slate-800 text-slate-300 disabled:opacity-50">CANCEL</button>
                <ButtonLoader
                  type="submit"
                  isLoading={isSavingApp}
                  loadingText="SAVING..."
                  className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold transition-colors"
                >
                  {editingApp ? 'UPDATE APPLICATION' : 'SAVE APPLICATION'}
                </ButtonLoader>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
