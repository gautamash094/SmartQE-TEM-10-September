import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useTEM } from '../context/TEMContext';
import { EnvironmentFleetStatusSection } from '../components/dashboard/EnvironmentFleetStatusSection';
import { RiskBadge } from '../components/common/RiskBadge';
import { CardSkeleton, TableSkeleton } from '../components/common/Skeleton';
import { Server, Calendar, AlertTriangle, Rocket, Activity, Sparkles, Webhook, CheckCircle2 } from 'lucide-react';

export const CommandCenterPage: React.FC = () => {
  const navigate = useNavigate();
  const { metrics, incidents, releases, integrationHealth, integrationLogs, isLoading } = useTEM();

  return (
    <div className="space-y-8 w-full min-w-0">
      {/* Top Banner Overview */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            OVERVIEW
          </span>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">TEM Dashboard</h1>
          <p className="text-sm text-slate-400 mt-1">
            Real-time state of every non-production environment across your delivery pipeline.
          </p>
        </div>
      </div>

      {/* AI PREDICTIVE INTELLIGENCE & DEMAND BANNER */}
      <div
        onClick={() => navigate('/ai-predictive-demand')}
        className="bg-[#0b1320] border border-orange-500/50 hover:border-orange-400 p-4 rounded-lg cursor-pointer transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-[0_0_20px_rgba(249,115,22,0.15)] group"
      >
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-400 shrink-0 group-hover:scale-110 transition-transform">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 font-mono text-[10px]">
              <span className="font-bold text-orange-400 uppercase tracking-widest">AI PREDICTIVE CONTROL PLANE</span>
              <span className="bg-orange-950 text-orange-300 px-2 py-0.5 rounded font-bold">NEXT 30 DAYS</span>
            </div>
            <h3 className="text-sm font-bold text-white font-mono mt-0.5">
              Predicted Demand: <strong className="text-orange-400">126 Bookings</strong> · Capacity Shortage: <strong className="text-red-400">+5 Envs Peak</strong>
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              High conflict contention predicted on UAT tier during Finance BU release window. Click to inspect full predictive analytics & scenario models.
            </p>
          </div>
        </div>

        <button className="px-4 py-2 rounded bg-orange-600 group-hover:bg-orange-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors shrink-0 flex items-center gap-1.5 shadow-[0_0_12px_rgba(249,115,22,0.4)]">
          OPEN AI DEMAND MODULE →
        </button>
      </div>

      {/* 4 Summary Stat Cards */}
      {isLoading ? (
        <CardSkeleton count={4} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Environments */}
          <div
            onClick={() => navigate('/environment-details')}
            className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 hover:border-slate-700 p-5 rounded-lg transition-all cursor-pointer group shadow-lg"
          >
            <div className="flex items-center justify-between text-slate-400 mb-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider">ENVIRONMENTS</span>
              <Server className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-extrabold text-white font-mono">{metrics.totalEnvironments}</div>
            <p className="text-xs font-mono text-emerald-400 mt-2">{metrics.healthyEnvironments} HEALTHY</p>
          </div>

          {/* Active Bookings */}
          <div
            onClick={() => navigate('/bookings')}
            className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 hover:border-slate-700 p-5 rounded-lg transition-all cursor-pointer group shadow-lg"
          >
            <div className="flex items-center justify-between text-slate-400 mb-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider">ACTIVE BOOKINGS</span>
              <Calendar className="w-5 h-5 text-orange-400 group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-extrabold text-white font-mono">{metrics.activeBookings}</div>
            <p className="text-xs font-mono text-slate-400 mt-2">{metrics.utilizationRate}% UTILIZATION</p>
          </div>

          {/* Open Incidents */}
          <div
            onClick={() => navigate('/incidents')}
            className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 hover:border-slate-700 p-5 rounded-lg transition-all cursor-pointer group shadow-lg"
          >
            <div className="flex items-center justify-between text-slate-400 mb-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider">OPEN INCIDENTS</span>
              <AlertTriangle className="w-5 h-5 text-red-400 group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-extrabold text-white font-mono">{metrics.openIncidents}</div>
            <p className="text-xs font-mono text-red-400 mt-2">{metrics.downEnvironmentsCount} ENVS DOWN</p>
          </div>

          {/* Upcoming Releases */}
          <div
            onClick={() => navigate('/releases')}
            className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 hover:border-slate-700 p-5 rounded-lg transition-all cursor-pointer group shadow-lg"
          >
            <div className="flex items-center justify-between text-slate-400 mb-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider">UPCOMING RELEASES</span>
              <Rocket className="w-5 h-5 text-blue-400 group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-extrabold text-white font-mono">{metrics.upcomingReleases}</div>
            <p className="text-xs font-mono text-slate-400 mt-2">{metrics.trackedReleasesCount} TRACKED</p>
          </div>
        </div>
      )}

      {/* Enhanced Environment Fleet Status Section (Single Source of Truth: Environment Details) */}
      <EnvironmentFleetStatusSection />

      {/* EXTERNAL ECOSYSTEM TOOLCHAIN ACTIVITY WIDGET */}
      <div
        onClick={() => navigate('/external-integrations')}
        className="bg-[#0b1320] border border-slate-200 dark:border-slate-800 hover:border-orange-500/60 p-5 rounded-xl transition-all cursor-pointer shadow-xl group font-mono text-xs"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-orange-950/80 border border-orange-800/80 flex items-center justify-center text-orange-400 group-hover:scale-110 transition-transform">
              <Webhook className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest">
                  EXTERNAL TOOLCHAIN INTEGRATIONS
                </span>
                <span className="px-2 py-0.2 rounded bg-emerald-950 text-emerald-400 font-bold text-[9px] border border-emerald-800">
                  {integrationHealth.connectedCount}/{integrationHealth.totalIntegrations} CONNECTED
                </span>
              </div>
              <h3 className="text-sm font-bold text-white mt-0.5">
                Live ITSM &amp; CI/CD Pipeline Activity
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-3 text-slate-400 text-[11px] shrink-0">
            <span>24h Events: <strong className="text-white">{integrationHealth.events24hCount}</strong></span>
            <span>Success Rate: <strong className="text-emerald-400">{integrationHealth.successRate24h}%</strong></span>
            <span className="text-orange-400 font-bold group-hover:translate-x-1 transition-transform">VIEW CONNECTORS →</span>
          </div>
        </div>

        {/* Live Recent Event Ticker */}
        <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
          {integrationLogs.slice(0, 2).map((log) => (
            <div key={log.id} className="bg-black/40 p-2.5 rounded border border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
              <div className="truncate">
                <span className="text-orange-400 font-bold mr-2">[{log.provider}]</span>
                <span className="text-slate-300 font-sans">{log.message}</span>
              </div>
              <span className="text-[9px] text-slate-500 shrink-0 ml-2">{log.timestamp.substring(11, 16)}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right & Secondary Grid Section: Recent Incidents & Next Releases */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Incidents */}
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center justify-between">
            <span>RECENT INCIDENTS</span>
            <AlertTriangle className="w-4 h-4 text-red-400" />
          </h3>
          <div className="space-y-3">
            {incidents.slice(0, 4).map((inc) => (
              <div
                key={inc.id}
                onClick={() => navigate('/incidents')}
                className="p-2.5 rounded bg-slate-900/60 border border-slate-200 dark:border-slate-800 hover:border-slate-700 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                      inc.severity === 'SEV1'
                        ? 'bg-red-950 text-red-400 border border-red-800'
                        : inc.severity === 'SEV2'
                        ? 'bg-amber-950 text-amber-400 border border-amber-800'
                        : 'bg-blue-950 text-blue-400 border border-blue-800'
                    }`}
                  >
                    {inc.severity}
                  </span>
                  <h4 className="text-xs font-semibold text-slate-200 truncate flex-1">{inc.title}</h4>
                </div>
                <p className="text-[11px] font-mono text-slate-500">
                  {inc.environmentName} · <span className="lowercase">{inc.status}</span>
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Next Releases */}
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center justify-between">
            <span>NEXT RELEASES</span>
            <Rocket className="w-4 h-4 text-blue-400" />
          </h3>
          <div className="space-y-3">
            {releases.slice(0, 3).map((rel) => (
              <div
                key={rel.id}
                onClick={() => navigate('/releases')}
                className="p-2.5 rounded bg-slate-900/60 border border-slate-200 dark:border-slate-800 hover:border-slate-700 cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-xs font-semibold text-slate-200 truncate">{rel.name}</h4>
                  <span className="text-[10px] font-mono text-slate-400">{rel.version}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-slate-500">{rel.environmentName}</span>
                  <RiskBadge risk={rel.risk} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Fleet Utilization Progress Bars */}
      <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              CAPACITY
            </span>
            <h2 className="text-base font-bold text-white">Fleet Utilization & Telemetry</h2>
          </div>
          <Activity className="w-5 h-5 text-emerald-400" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* CPU AVG */}
          <div>
            <div className="flex items-center justify-between text-xs font-mono mb-2">
              <span className="text-slate-400 uppercase font-semibold">CPU AVG</span>
              <span className="text-white font-bold">{metrics.cpuAverage}%</span>
            </div>
            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-200 dark:border-slate-800">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]"
                style={{ width: `${metrics.cpuAverage}%` }}
              />
            </div>
          </div>

          {/* MEMORY AVG */}
          <div>
            <div className="flex items-center justify-between text-xs font-mono mb-2">
              <span className="text-slate-400 uppercase font-semibold">MEMORY AVG</span>
              <span className="text-white font-bold">{metrics.memoryAverage}%</span>
            </div>
            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-200 dark:border-slate-800">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]"
                style={{ width: `${metrics.memoryAverage}%` }}
              />
            </div>
          </div>

          {/* STORAGE AVG */}
          <div>
            <div className="flex items-center justify-between text-xs font-mono mb-2">
              <span className="text-slate-400 uppercase font-semibold">STORAGE AVG</span>
              <span className="text-white font-bold">{metrics.storageAverage}%</span>
            </div>
            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-200 dark:border-slate-800">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]"
                style={{ width: `${metrics.storageAverage}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

