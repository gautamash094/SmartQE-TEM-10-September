import React, { useState, useEffect, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import { useAuth } from '../context/AuthContext';
import { roleService, Role } from '../services/roleService';
import { accessService, ApplicationScreen, RoleScreenAccessItem } from '../services/accessService';
import {
  KeyRound,
  Shield,
  CheckCircle2,
  XCircle,
  Save,
  Lock,
  LayoutGrid,
  Briefcase,
  Cpu,
  ClipboardList,
  Calendar,
  Rocket,
  AlertTriangle,
  Layers,
  Settings,
  Webhook,
  BookOpen,
  Boxes,
  Compass,
  Activity,
  Sparkles,
  Users,
  Sliders,
  CheckSquare,
  Square,
  RefreshCw,
  Info,
  GitFork,
} from 'lucide-react';
import { ButtonLoader } from '../components/common/ButtonLoader';

// Icon mapping helper
const SCREEN_ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  dashboard: LayoutGrid,
  entity_management: Briefcase,
  environment_details: Cpu,
  worklist: ClipboardList,
  bookings: Calendar,
  releases: Rocket,
  incidents: AlertTriangle,
  resource_management: Layers,
  inventory: Boxes,
  topology: Compass,
  monitoring: Activity,
  predictive_demand: Sparkles,
  settings: Settings,
  settings_users: Users,
  settings_roles: Shield,
  settings_access: KeyRound,
  settings_user_groups: Users,
  settings_define_workflow: GitFork,
  integrations: Webhook,
  runbooks: BookOpen,
};

export const AccessManagementPage: React.FC = () => {
  const { showToast } = useTEM();
  const { refreshPermissions } = useAuth();

  const [roles, setRoles] = useState<Role[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState<string>('');
  const [screens, setScreens] = useState<ApplicationScreen[]>([]);
  const [accessibleScreenIds, setAccessibleScreenIds] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Load active roles & screens
  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const [fetchedRoles, fetchedScreens] = await Promise.all([
        roleService.getRoles(),
        accessService.getScreens(),
      ]);

      const activeRoles = fetchedRoles.filter((r) => r.isActive);
      setRoles(activeRoles);
      setScreens(fetchedScreens);

      if (activeRoles.length > 0) {
        const defaultRole = activeRoles[0];
        setSelectedRoleId(defaultRole.id);
        await loadRoleAccess(defaultRole.id);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to load access control data', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const loadRoleAccess = async (roleId: string) => {
    try {
      const roleAccess = await accessService.getRoleAccess(roleId);
      const allowed = new Set(
        roleAccess.screens.filter((s) => s.hasAccess).map((s) => s.screenId)
      );
      setAccessibleScreenIds(allowed);
    } catch (err: any) {
      showToast(err.message || 'Failed to load role permissions', 'error');
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  const currentRole = useMemo(() => {
    return roles.find((r) => r.id === selectedRoleId) || null;
  }, [roles, selectedRoleId]);

  const isSuperAdminRole = useMemo(() => {
    return currentRole?.name.toLowerCase().trim() === 'super admin' || currentRole?.isSystem;
  }, [currentRole]);

  // Handle changing selected role
  const handleRoleChange = async (roleId: string) => {
    setSelectedRoleId(roleId);
    await loadRoleAccess(roleId);
  };

  // Toggle single screen
  const handleToggleScreen = (screenId: string) => {
    if (isSuperAdminRole) return;

    setAccessibleScreenIds((prev) => {
      const next = new Set(prev);
      if (next.has(screenId)) {
        next.delete(screenId);
      } else {
        next.add(screenId);
      }
      return next;
    });
  };

  // Toggle parent module & its children
  const handleToggleParentModule = (parentKey: string, childScreens: ApplicationScreen[]) => {
    if (isSuperAdminRole) return;

    const parentScreen = screens.find((s) => s.key === parentKey);
    const parentId = parentScreen?.id;
    const allIds = [parentId, ...childScreens.map((c) => c.id)].filter(Boolean) as string[];

    const allChecked = allIds.every((id) => accessibleScreenIds.has(id));

    setAccessibleScreenIds((prev) => {
      const next = new Set(prev);
      if (allChecked) {
        allIds.forEach((id) => next.delete(id));
      } else {
        allIds.forEach((id) => next.add(id));
      }
      return next;
    });
  };

  // Select all screens
  const handleSelectAll = () => {
    if (isSuperAdminRole) return;
    setAccessibleScreenIds(new Set(screens.map((s) => s.id)));
  };

  // Deselect all screens
  const handleDeselectAll = () => {
    if (isSuperAdminRole) return;
    setAccessibleScreenIds(new Set());
  };

  // Save configuration
  const handleSaveAccess = async () => {
    if (!selectedRoleId || isSuperAdminRole) return;
    setIsSaving(true);
    try {
      await accessService.saveRoleAccess(selectedRoleId, Array.from(accessibleScreenIds));
      await refreshPermissions();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('auth_state_changed', { detail: null }));
      }
      showToast(`Access configuration for role "${currentRole?.name}" saved successfully!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save access configuration', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Group screens into Categories & Parent/Child hierarchies
  const groupedSections = useMemo(() => {
    const parentMap = new Map<string, ApplicationScreen[]>();
    const standaloneScreens: ApplicationScreen[] = [];

    screens.forEach((s) => {
      if (s.parentKey) {
        const existing = parentMap.get(s.parentKey) || [];
        existing.push(s);
        parentMap.set(s.parentKey, existing);
      } else if (!screens.some((child) => child.parentKey === s.key)) {
        standaloneScreens.push(s);
      }
    });

    return {
      parentMap,
      standaloneScreens,
    };
  }, [screens]);

  const accessCount = isSuperAdminRole ? screens.length : accessibleScreenIds.size;
  const accessPercentage = screens.length > 0 ? Math.round((accessCount / screens.length) * 100) : 0;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            SETTINGS &bull; AUTHORIZATION
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1 flex items-center gap-3">
            <KeyRound className="w-7 h-7 text-orange-500" />
            <span>Access Management</span>
            <span className="text-xs font-mono font-normal bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 border border-orange-300 dark:border-orange-800/80 px-2.5 py-0.5 rounded-full">
              RBAC Matrix
            </span>
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
            Configure screen and module visibility permissions per role. Users inherit the union of permissions from all their active assigned roles.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => selectedRoleId && loadRoleAccess(selectedRoleId)}
            className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f1724] text-slate-600 dark:text-slate-400 hover:text-orange-500 transition-colors shadow-sm cursor-pointer"
            title="Reload Role Access"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-500' : ''}`} />
          </button>

          {!isSuperAdminRole && (
            <ButtonLoader
              onClick={handleSaveAccess}
              isLoading={isSaving}
              loadingText="SAVING CONFIG..."
              icon={<Save className="w-4 h-4" />}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_16px_rgba(249,115,22,0.4)] cursor-pointer"
            >
              SAVE CONFIGURATION
            </ButtonLoader>
          )}
        </div>
      </div>

      {/* 2. ROLE SELECTOR BAR & SUMMARY STATS */}
      <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Role Dropdown */}
          <div className="flex-1 max-w-md">
            <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1.5 uppercase">
              SELECT TARGET ROLE TO CONFIGURE
            </label>
            <div className="relative">
              <select
                value={selectedRoleId}
                onChange={(e) => handleRoleChange(e.target.value)}
                className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-4 py-2.5 text-sm font-semibold text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
              >
                {roles.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} {r.isSystem ? '(System Role)' : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="flex items-center gap-4 border-t md:border-t-0 md:border-l border-slate-200 dark:border-slate-800 pt-3 md:pt-0 md:pl-6">
            <div>
              <span className="text-[10px] font-mono text-slate-400 uppercase block">Accessible Screens</span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xl font-mono font-extrabold text-slate-900 dark:text-white">
                  {accessCount} / {screens.length}
                </span>
                <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800/80">
                  {accessPercentage}%
                </span>
              </div>
            </div>

            {/* Quick Actions (Disabled for Super Admin) */}
            {!isSuperAdminRole && (
              <div className="flex items-center gap-2 pl-4 border-l border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
                >
                  <CheckSquare className="w-3.5 h-3.5 text-emerald-500" /> Select All
                </button>
                <button
                  type="button"
                  onClick={handleDeselectAll}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5 text-rose-500" /> Deselect All
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Super Admin Notice Banner */}
        {isSuperAdminRole && (
          <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800/80 rounded-xl flex items-start gap-3">
            <Lock className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-amber-900 dark:text-amber-200 uppercase font-mono">
                Super Admin Role - Permanent Full Access Guarantee
              </h4>
              <p className="text-xs text-amber-800 dark:text-amber-300/90 mt-0.5 leading-relaxed">
                The Super Admin role is protected and permanently maintains complete, unrestricted access to all screens, submodules, and API endpoints across the TEM application. Permission toggles cannot be restricted.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 3. SCREEN ACCESS MATRIX */}
      <div className="space-y-6">
        {/* Parent Groups: Settings & Resource Management */}
        {['settings', 'resource_management'].map((parentKey) => {
          const parentScreen = screens.find((s) => s.key === parentKey);
          const childScreens = groupedSections.parentMap.get(parentKey) || [];
          if (!parentScreen) return null;

          const ParentIcon = SCREEN_ICON_MAP[parentKey] || Layers;
          const allChildrenChecked = childScreens.every((c) =>
            isSuperAdminRole ? true : accessibleScreenIds.has(c.id)
          );
          const isParentChecked = isSuperAdminRole ? true : accessibleScreenIds.has(parentScreen.id);

          return (
            <div
              key={parentKey}
              className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-5 shadow-sm space-y-4"
            >
              {/* Group Header with Master Toggle */}
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3.5">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-orange-100 dark:bg-orange-950/60 border border-orange-300 dark:border-orange-800/80 flex items-center justify-center text-orange-600 dark:text-orange-400 shadow-sm">
                    <ParentIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <span>{parentScreen.name}</span>
                      <span className="text-[10px] font-mono font-semibold uppercase bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">
                        Parent Module &bull; {childScreens.length} Submodules
                      </span>
                    </h3>
                    <span className="text-xs text-slate-500 font-mono">Route: {parentScreen.route}</span>
                  </div>
                </div>

                {/* Master Toggle */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-semibold text-slate-600 dark:text-slate-400 hidden sm:inline">
                    Toggle All:
                  </span>
                  <button
                    type="button"
                    disabled={isSuperAdminRole}
                    onClick={() => handleToggleParentModule(parentKey, childScreens)}
                    className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none disabled:opacity-75 disabled:cursor-not-allowed ${
                      allChildrenChecked ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                        allChildrenChecked ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Child Submodule Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-1">
                {childScreens.map((child) => {
                  const ChildIcon = SCREEN_ICON_MAP[child.key] || Shield;
                  const isChecked = isSuperAdminRole ? true : accessibleScreenIds.has(child.id);

                  return (
                    <div
                      key={child.id}
                      onClick={() => handleToggleScreen(child.id)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isChecked
                          ? 'bg-orange-50/40 dark:bg-orange-950/20 border-orange-300 dark:border-orange-800/70 shadow-sm'
                          : 'bg-slate-50/70 dark:bg-[#121b2d]/60 border-slate-200 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700'
                      } ${isSuperAdminRole ? 'cursor-default' : ''}`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            isChecked
                              ? 'bg-orange-100 dark:bg-orange-900/40 text-orange-600 dark:text-orange-400'
                              : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                          }`}
                        >
                          <ChildIcon className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <span className="text-xs font-bold text-slate-900 dark:text-white block truncate">
                            {child.name}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400 block truncate">
                            {child.route}
                          </span>
                        </div>
                      </div>

                      {/* Switch Toggle */}
                      <button
                        type="button"
                        disabled={isSuperAdminRole}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleScreen(child.id);
                        }}
                        className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none disabled:opacity-75 disabled:cursor-not-allowed ${
                          isChecked ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                            isChecked ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}

        {/* Standalone Modules (Dashboard, Entity Mgmt, Environment Details, Worklist, Bookings, Releases, Incidents, Integrations, Runbooks) */}
        <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-5 shadow-sm space-y-4">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Main Application Modules</h3>
            <p className="text-xs text-slate-500">Core operational and monitoring views.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {groupedSections.standaloneScreens.map((screen) => {
              const ScreenIcon = SCREEN_ICON_MAP[screen.key] || LayoutGrid;
              const isChecked = isSuperAdminRole ? true : accessibleScreenIds.has(screen.id);

              return (
                <div
                  key={screen.id}
                  onClick={() => handleToggleScreen(screen.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isChecked
                      ? 'bg-orange-50/40 dark:bg-orange-950/20 border-orange-300 dark:border-orange-800/70 shadow-sm'
                      : 'bg-slate-50/70 dark:bg-[#121b2d]/60 border-slate-200 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700'
                  } ${isSuperAdminRole ? 'cursor-default' : ''}`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        isChecked
                          ? 'bg-orange-100 dark:bg-orange-900/40 text-orange-600 dark:text-orange-400'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                      }`}
                    >
                      <ScreenIcon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-xs font-bold text-slate-900 dark:text-white block truncate">
                        {screen.name}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400 block truncate">
                        {screen.route}
                      </span>
                    </div>
                  </div>

                  {/* Switch Toggle */}
                  <button
                    type="button"
                    disabled={isSuperAdminRole}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleScreen(screen.id);
                    }}
                    className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none disabled:opacity-75 disabled:cursor-not-allowed ${
                      isChecked ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                        isChecked ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
