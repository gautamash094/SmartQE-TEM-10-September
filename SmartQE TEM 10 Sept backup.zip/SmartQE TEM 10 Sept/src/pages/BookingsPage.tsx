import React, { useState, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import { useAuth } from '../context/AuthContext';
import { BookingModal } from '../components/features/BookingModal';
import { WeeklyView } from '../components/calendar/WeeklyView';
import { MonthlyView } from '../components/calendar/MonthlyView';
import { QuarterlyView } from '../components/calendar/QuarterlyView';
import { TimelineGanttView, GanttScope } from '../components/calendar/TimelineGanttView';
import { BookingCalendarDetailModal } from '../components/calendar/BookingCalendarDetailModal';
import { ChartSkeleton } from '../components/common/Skeleton';
import { ButtonLoader } from '../components/common/ButtonLoader';
import {
  Plus,
  Calendar as CalendarIcon,
  Clock,
  AlertTriangle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Search,
  Filter,
  Layers,
  LayoutGrid,
  BarChart3,
  Ban
} from 'lucide-react';
import { Booking, Environment } from '../types';

export const BookingsPage: React.FC = () => {
  // Environment Details is the single source of truth for environments
  const { environmentProfiles, bookings, isLoading } = useTEM();
  const { currentUser } = useAuth();

  const isSuperAdmin = useMemo(() => {
    if (!currentUser) return false;
    return (
      Boolean(currentUser.isSuperAdmin) ||
      currentUser.username.toLowerCase() === 'admin' ||
      currentUser.email?.toLowerCase() === 'admin@tem.com' ||
      (currentUser.roles || []).some((r) => r.name.toLowerCase().trim() === 'super admin')
    );
  }, [currentUser]);

  // Derive the effective environment list for display in Calendar/Gantt views.
  // Strictly sourced from environmentProfiles (Environment Details module — single source of truth)
  const effectiveEnvironments: Environment[] = useMemo(() => {
    if (!environmentProfiles || environmentProfiles.length === 0) return [];
    return environmentProfiles.map((p) => ({
      id: p.id,
      name: p.name,
      tier: (p.type === 'Development' ? 'DEV' : p.type === 'QA / Testing' ? 'QA' : p.type === 'UAT / Staging' ? 'UAT' : p.type === 'Production' ? 'PRE-PROD' : 'QA') as any,
      team: p.ownerTeam || 'Platform QE',
      owner: p.ownerTeam || 'QE Guild',
      region: p.networkZone || 'VPC-EAST',
      status: p.status,
      isActive: p.isActive !== false,
      uptime: 99.9,
      cpuUsage: 0,
      memoryUsage: 0,
      storageUsage: 0,
      techStack: [],
      topology: [],
    }));
  }, [environmentProfiles]);

  // Primary view mode: 'calendar' or 'gantt'
  const [viewMode, setViewMode] = useState<'calendar' | 'gantt'>('calendar');

  // Calendar sub-view: 'weekly' | 'monthly' | 'quarterly'
  const [calendarSubView, setCalendarSubView] = useState<'weekly' | 'monthly' | 'quarterly'>('monthly');

  // Gantt timeline scope: '2weeks' | 'month' | 'quarter' | '6months'
  const [ganttScope, setGanttScope] = useState<GanttScope>('month');

  // Active anchor date initialized dynamically to current date
  const [currentDate, setCurrentDate] = useState<Date>(() => new Date());

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEnvFilter, setSelectedEnvFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'CONFLICTS' | 'CONFIRMED'>('ALL');
  const [modeFilter, setModeFilter] = useState<'ALL' | 'SHARED' | 'DISRUPTIVE'>('ALL');

  // Modal States
  const [isBookingModalOpen, setIsBookingModalOpen] = useState<boolean>(false);
  const [detailModalBooking, setDetailModalBooking] = useState<Booking | null>(null);

  // Valid environment IDs and names from Environment Details module
  const validProfileEnvSet = useMemo(() => {
    const ids = new Set<string>();
    const names = new Set<string>();
    (environmentProfiles || []).forEach((p) => {
      if (p.id) ids.add(p.id);
      if (p.name) names.add(p.name.toLowerCase().trim());
    });
    return { ids, names };
  }, [environmentProfiles]);

  // Filter reservations to only those belonging to environments or all bookings
  const envDetailsBookings = useMemo(() => {
    if (!validProfileEnvSet.ids.size && !validProfileEnvSet.names.size) {
      return bookings || [];
    }
    return (bookings || []).filter((b) => {
      const matchId = b.environmentId && validProfileEnvSet.ids.has(b.environmentId);
      const matchName = b.environmentName && validProfileEnvSet.names.has(b.environmentName.toLowerCase().trim());
      return matchId || matchName || !b.environmentId;
    });
  }, [bookings, validProfileEnvSet]);

  // Filter Active Reservations Only for Calendar & Gantt views
  const activeReservations = useMemo(() => {
    return envDetailsBookings.filter((b) => {
      if (!b.status) return true;
      const st = String(b.status).toUpperCase();
      return st !== 'CANCELLED' && st !== 'REJECTED' && st !== 'AUTO_REJECTED';
    });
  }, [envDetailsBookings]);

  // Overlap / Conflict detection algorithm considering Reservation Mode Matrix
  const { conflictMap, totalConflicts } = useMemo(() => {
    const map = new Map<string, string[]>(); // bookingId -> list of conflicting booking IDs

    for (let i = 0; i < activeReservations.length; i++) {
      for (let j = i + 1; j < activeReservations.length; j++) {
        const a = activeReservations[i];
        const b = activeReservations[j];

        const sameEnv =
          (a.environmentId && b.environmentId && a.environmentId === b.environmentId) ||
          (a.environmentName && b.environmentName && a.environmentName.toLowerCase() === b.environmentName.toLowerCase());

        if (sameEnv && a.startDate && a.endDate && b.startDate && b.endDate) {
          const aStart = new Date(a.startDate).getTime();
          const aEnd = new Date(a.endDate).getTime();
          const bStart = new Date(b.startDate).getTime();
          const bEnd = new Date(b.endDate).getTime();

          const isOverlap = aStart < bEnd && aEnd > bStart;
          if (isOverlap) {
            const aMode = a.reservationMode || 'SHARED';
            const bMode = b.reservationMode || 'SHARED';
            const isConflict = aMode === 'DISRUPTIVE' || bMode === 'DISRUPTIVE';

            if (isConflict) {
              const listA = map.get(a.id) || [];
              listA.push(b.id);
              map.set(a.id, listA);

              const listB = map.get(b.id) || [];
              listB.push(a.id);
              map.set(b.id, listB);
            }
          }
        }
      }
    }

    return {
      conflictMap: map,
      totalConflicts: map.size,
    };
  }, [activeReservations]);

  // Filtered Active Bookings for Display in Calendar/Gantt Views
  const filteredBookings = useMemo(() => {
    return activeReservations.filter((b) => {
      // Search
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        !q ||
        (b.purpose && b.purpose.toLowerCase().includes(q)) ||
        (b.environmentName && b.environmentName.toLowerCase().includes(q)) ||
        (b.businessUnit && b.businessUnit.toLowerCase().includes(q)) ||
        (b.application && b.application.toLowerCase().includes(q)) ||
        (b.project && b.project.toLowerCase().includes(q)) ||
        (b.requestedBy && b.requestedBy.toLowerCase().includes(q));

      // Environment filter
      const matchesEnv =
        selectedEnvFilter === 'ALL' ||
        b.environmentId === selectedEnvFilter ||
        b.environmentName.toLowerCase() === selectedEnvFilter.toLowerCase();

      // Mode filter
      const matchesMode = modeFilter === 'ALL' || (b.reservationMode || 'SHARED') === modeFilter;

      // Status filter
      const isConflict = conflictMap.has(b.id);
      let matchesStatus = true;
      if (statusFilter === 'CONFLICTS') {
        matchesStatus = isConflict;
      } else if (statusFilter === 'CONFIRMED') {
        matchesStatus = !isConflict;
      }

      return matchesSearch && matchesEnv && matchesMode && matchesStatus;
    });
  }, [activeReservations, searchQuery, selectedEnvFilter, modeFilter, statusFilter, conflictMap]);

  // Navigation handlers for Calendar & Gantt timeline
  const handlePrev = () => {
    setCurrentDate((prev) => {
      const d = new Date(prev);
      if (viewMode === 'gantt') {
        if (ganttScope === '2weeks') {
          d.setDate(d.getDate() - 14);
        } else if (ganttScope === 'quarter') {
          d.setMonth(d.getMonth() - 3);
        } else if (ganttScope === '6months') {
          d.setMonth(d.getMonth() - 6);
        } else {
          d.setMonth(d.getMonth() - 1);
        }
        return d;
      }

      if (calendarSubView === 'weekly') {
        d.setDate(d.getDate() - 7);
      } else if (calendarSubView === 'monthly') {
        d.setMonth(d.getMonth() - 1);
      } else if (calendarSubView === 'quarterly') {
        d.setMonth(d.getMonth() - 3);
      }
      return d;
    });
  };

  const handleNext = () => {
    setCurrentDate((prev) => {
      const d = new Date(prev);
      if (viewMode === 'gantt') {
        if (ganttScope === '2weeks') {
          d.setDate(d.getDate() + 14);
        } else if (ganttScope === 'quarter') {
          d.setMonth(d.getMonth() + 3);
        } else if (ganttScope === '6months') {
          d.setMonth(d.getMonth() + 6);
        } else {
          d.setMonth(d.getMonth() + 1);
        }
        return d;
      }

      if (calendarSubView === 'weekly') {
        d.setDate(d.getDate() + 7);
      } else if (calendarSubView === 'monthly') {
        d.setMonth(d.getMonth() + 1);
      } else if (calendarSubView === 'quarterly') {
        d.setMonth(d.getMonth() + 3);
      }
      return d;
    });
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  // Compute formatted label for current date range
  const formattedDateRangeLabel = useMemo(() => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    if (viewMode === 'gantt') {
      if (ganttScope === 'month') {
        return `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;
      }
      if (ganttScope === '2weeks') {
        const start = new Date(currentDate);
        start.setDate(start.getDate() - 3);
        const end = new Date(start);
        end.setDate(start.getDate() + 13);
        return `${start.toLocaleString('default', { month: 'short', day: 'numeric' })} – ${end.toLocaleString('default', { month: 'short', day: 'numeric', year: 'numeric' })}`;
      }
      if (ganttScope === 'quarter') {
        const end = new Date(year, month + 2, 1);
        return `${currentDate.toLocaleString('default', { month: 'short' })} – ${end.toLocaleString('default', { month: 'short', year: 'numeric' })}`;
      }
      if (ganttScope === '6months') {
        const end = new Date(year, month + 5, 1);
        return `${currentDate.toLocaleString('default', { month: 'short' })} – ${end.toLocaleString('default', { month: 'short', year: 'numeric' })}`;
      }
    }

    if (calendarSubView === 'weekly') {
      const d = new Date(currentDate);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      const monday = new Date(d.setDate(diff));
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);

      const mMonth = monday.toLocaleString('default', { month: 'short' });
      const sMonth = sunday.toLocaleString('default', { month: 'short' });
      if (mMonth === sMonth) {
        return `${mMonth} ${monday.getDate()} – ${sunday.getDate()}, ${year}`;
      }
      return `${mMonth} ${monday.getDate()} – ${sMonth} ${sunday.getDate()}, ${year}`;
    }

    if (calendarSubView === 'monthly') {
      return `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;
    }

    if (calendarSubView === 'quarterly') {
      const qIdx = Math.floor(month / 3) + 1;
      const quarterMonths = [
        ['January', 'March'],
        ['April', 'June'],
        ['July', 'September'],
        ['October', 'December'],
      ][qIdx - 1];
      return `Q${qIdx} ${year} (${quarterMonths[0]} – ${quarterMonths[1]})`;
    }

    return '';
  }, [currentDate, calendarSubView, viewMode, ganttScope]);

  return (
    <div className="space-y-6 font-sans w-full min-w-0">
      {/* Header & New Booking Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              SCHEDULING & ALLOCATIONS
            </span>
            {totalConflicts > 0 && (
              <span className="bg-red-950 text-red-400 border border-red-800 text-[10px] font-mono font-bold px-2 py-0.5 rounded flex items-center gap-1 animate-pulse">
                <AlertTriangle className="w-3 h-3" /> {totalConflicts} OVERLAPPING CONFLICTS
              </span>
            )}
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight flex items-center gap-3 mt-0.5">
            <CalendarIcon className="w-8 h-8 text-orange-500" />
            Bookings Grid
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Visual calendar and dynamic Gantt timeline for environment allocations with schedule collision highlights.
          </p>
        </div>

        {!isSuperAdmin && (
          <button
            onClick={() => setIsBookingModalOpen(true)}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_16px_rgba(249,115,22,0.4)] shrink-0"
          >
            <Plus className="w-4 h-4" /> NEW BOOKING
          </button>
        )}
      </div>

      {/* VIEW SWITCHER & TOOLBAR */}
      <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xl space-y-4 font-mono text-xs">
        {/* Row 1: Primary Mode Switcher & Calendar View Options */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800/80 pb-4">
          {/* Main Mode Toggle: Calendar vs Gantt */}
          <div className="flex items-center gap-1 bg-[#162032] p-1 rounded-lg border border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setViewMode('calendar')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded font-bold transition-all ${
                viewMode === 'calendar'
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Calendar View</span>
            </button>

            <button
              onClick={() => setViewMode('gantt')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded font-bold transition-all ${
                viewMode === 'gantt'
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Timeline (Gantt)</span>
            </button>
          </div>

          {/* Calendar View Type Switcher (Weekly / Monthly / Quarterly) */}
          {viewMode === 'calendar' && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-slate-500 font-bold uppercase hidden sm:inline">CALENDAR VIEW:</span>
              <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg border border-slate-200 dark:border-slate-800">
                <button
                  onClick={() => setCalendarSubView('weekly')}
                  className={`px-3 py-1.5 rounded font-bold text-xs transition-colors ${
                    calendarSubView === 'weekly'
                      ? 'bg-slate-800 text-orange-400 border border-slate-700'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Weekly View
                </button>
                <button
                  onClick={() => setCalendarSubView('monthly')}
                  className={`px-3 py-1.5 rounded font-bold text-xs transition-colors ${
                    calendarSubView === 'monthly'
                      ? 'bg-slate-800 text-orange-400 border border-slate-700'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Monthly View
                </button>
                <button
                  onClick={() => setCalendarSubView('quarterly')}
                  className={`px-3 py-1.5 rounded font-bold text-xs transition-colors ${
                    calendarSubView === 'quarterly'
                      ? 'bg-slate-800 text-orange-400 border border-slate-700'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Quarterly View
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Row 2: Date Navigation & Search/Filter Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Date Navigation Controls (Unified for both Calendar and Gantt) */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <button
                onClick={handlePrev}
                title="Previous Range"
                className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleToday}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-bold transition-colors"
              >
                Today
              </button>
              <button
                onClick={handleNext}
                title="Next Range"
                className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="text-white font-bold text-sm tracking-tight flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-orange-400" />
              <span>{formattedDateRangeLabel}</span>
            </div>
          </div>

          {/* Search & Filters */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Search */}
            <div className="relative flex-1 min-w-[200px] max-w-xs">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input autoComplete="off" data-lpignore="true"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search bookings, teams..."
                className="w-full bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
              />
            </div>

            {/* Environment Filter populated from Environment Details */}
            <select
              value={selectedEnvFilter}
              onChange={(e) => setSelectedEnvFilter(e.target.value)}
              className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-1.5 text-white text-xs focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">All Environments</option>
              {effectiveEnvironments.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.name}
                </option>
              ))}
            </select>

            {/* Reservation Mode Filter */}
            <select
              value={modeFilter}
              onChange={(e) => setModeFilter(e.target.value as any)}
              className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-1.5 text-white text-xs focus:outline-none focus:border-orange-500 font-mono"
            >
              <option value="ALL">All Modes</option>
              <option value="SHARED">👥 Shared</option>
              <option value="DISRUPTIVE">⚡ Disruptive</option>
            </select>

            {/* Status Filter Pills */}
            <div className="flex flex-wrap items-center gap-1 bg-black/40 p-0.5 rounded border border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setStatusFilter('ALL')}
                className={`px-2 py-1 rounded text-[10px] font-bold ${
                  statusFilter === 'ALL' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                All Active
              </button>
              <button
                onClick={() => setStatusFilter('CONFIRMED')}
                className={`px-2 py-1 rounded text-[10px] font-bold ${
                  statusFilter === 'CONFIRMED'
                    ? 'bg-emerald-600 text-white'
                    : 'text-emerald-400 hover:text-emerald-300'
                }`}
              >
                Confirmed
              </button>
              <button
                onClick={() => setStatusFilter('CONFLICTS')}
                className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 ${
                  statusFilter === 'CONFLICTS'
                    ? 'bg-red-600 text-white'
                    : 'text-red-400 hover:text-red-300'
                }`}
              >
                <AlertTriangle className="w-2.5 h-2.5" /> Conflicts
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ================= CALENDAR / GANTT VIEWS ================= */}
      {isLoading ? (
        <ChartSkeleton height={480} className="w-full" />
      ) : (
        <>
          {viewMode === 'calendar' && (
            <div>
              {calendarSubView === 'weekly' && (
                <WeeklyView
                  currentDate={currentDate}
                  bookings={filteredBookings}
                  conflictMap={conflictMap}
                  onSelectBooking={(b) => setDetailModalBooking(b)}
                />
              )}

              {calendarSubView === 'monthly' && (
                <MonthlyView
                  currentDate={currentDate}
                  bookings={filteredBookings}
                  conflictMap={conflictMap}
                  onSelectBooking={(b) => setDetailModalBooking(b)}
                />
              )}

              {calendarSubView === 'quarterly' && (
                <QuarterlyView
                  currentDate={currentDate}
                  bookings={filteredBookings}
                  conflictMap={conflictMap}
                  onSelectBooking={(b) => setDetailModalBooking(b)}
                  onNavigateToMonth={(mDate) => {
                    setCurrentDate(mDate);
                    setCalendarSubView('monthly');
                  }}
                />
              )}
            </div>
          )}

          {/* ================= TIMELINE / GANTT VIEW ================= */}
          {viewMode === 'gantt' && (
            <TimelineGanttView
              currentDate={currentDate}
              environments={effectiveEnvironments}
              bookings={filteredBookings}
              conflictMap={conflictMap}
              ganttScope={ganttScope}
              onChangeScope={(s) => setGanttScope(s)}
              onSelectBooking={(b) => setDetailModalBooking(b)}
              onNavigateMonth={(mDate) => setCurrentDate(mDate)}
            />
          )}
        </>
      )}

      {/* Booking Calendar Detail Modal */}
      <BookingCalendarDetailModal
        booking={detailModalBooking}
        isOpen={!!detailModalBooking}
        onClose={() => setDetailModalBooking(null)}
        conflictMap={conflictMap}
      />

      {/* New Booking Modal */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
      />
    </div>
  );
};
