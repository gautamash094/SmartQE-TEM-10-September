import React, { useState, useMemo } from 'react';
import { useTEM } from '../context/TEMContext';
import { monitoringService } from '../services/monitoringService';
import {
  EnvironmentHealthStatus,
  TestReadinessStatus,
  TimeframeOption,
  MonitoringAlert,
  AlertRule,
  MaintenanceWindow,
} from '../types/monitoring';
import { EnvironmentReadinessBadge } from '../components/monitoring/EnvironmentReadinessBadge';
import { ImpactAnalysisDrawer } from '../components/monitoring/ImpactAnalysisDrawer';
import { CardSkeleton, TableSkeleton } from '../components/common/Skeleton';
import {
  Activity,
  Server,
  Cpu,
  Layers,
  Clock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ShieldCheck,
  Filter,
  Plus,
  Search,
  Bell,
  Sliders,
  Database,
  Terminal,
  Zap,
  Globe,
  Radio,
  ExternalLink,
} from 'lucide-react';

export const EnvironmentMonitoringPage: React.FC = () => {
  const { environmentProfiles, incidents, bookings, showToast, isLoading } = useTEM();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'telemetry' | 'alerts' | 'maintenance' | 'sources'
  >('overview');

  const [selectedEnvId, setSelectedEnvId] = useState<string>(
    environmentProfiles[0]?.id || ''
  );

  React.useEffect(() => {
    if (!selectedEnvId && environmentProfiles.length > 0) {
      setSelectedEnvId(environmentProfiles[0].id);
    }
  }, [environmentProfiles, selectedEnvId]);
  const [selectedTimeframe, setSelectedTimeframe] = useState<TimeframeOption>('24h');
  const [logLevelFilter, setLogLevelFilter] = useState<string>('ALL');
  const [logSearch, setLogSearch] = useState<string>('');

  // Alerts & Rules state
  const [alerts, setAlerts] = useState<MonitoringAlert[]>(() => monitoringService.getAlerts());
  const [alertRules, setAlertRules] = useState<AlertRule[]>(() => monitoringService.getAlertRules());
  const [maintenanceList, setMaintenanceList] = useState<MaintenanceWindow[]>(() =>
    monitoringService.getMaintenanceWindows()
  );

  // Impact Analysis Drawer state
  const [impactDrawerNode, setImpactDrawerNode] = useState<{
    type: 'SERVER' | 'SOFTWARE' | 'ENVIRONMENT';
    name: string;
    id: string;
    environmentName?: string;
  } | null>(null);

  // Computed Environment Monitoring Summaries
  const fleetHealthList = useMemo(() => {
    return (environmentProfiles || []).map((env) => {
      const health = monitoringService.calculateEnvironmentHealth(env, incidents);
      const readiness = monitoringService.evaluateTestReadiness(env, incidents, bookings);
      return { env, health, readiness };
    });
  }, [environmentProfiles, incidents, bookings]);

  const metricsSummary = useMemo(() => {
    const total = fleetHealthList.length;
    const healthy = fleetHealthList.filter((f) => f.health.status === 'HEALTHY').length;
    const degraded = fleetHealthList.filter((f) => f.health.status === 'DEGRADED').length;
    const unhealthy = fleetHealthList.filter((f) => f.health.status === 'UNHEALTHY').length;
    const maintenance = fleetHealthList.filter((f) => f.health.status === 'MAINTENANCE').length;
    const readyForTesting = fleetHealthList.filter(
      (f) => f.readiness.status === 'READY_FOR_TESTING'
    ).length;

    return { total, healthy, degraded, unhealthy, maintenance, readyForTesting };
  }, [fleetHealthList]);

  // Selected Environment Data
  const currentEnvProfile = useMemo(() => {
    return environmentProfiles.find((e) => e.id === selectedEnvId) || environmentProfiles[0];
  }, [environmentProfiles, selectedEnvId]);

  const currentTelemetry = useMemo(() => {
    return monitoringService.getHistoricalTelemetry(selectedEnvId, selectedTimeframe);
  }, [selectedEnvId, selectedTimeframe]);

  const currentLogs = useMemo(() => {
    const raw = monitoringService.getCorrelatedLogs(selectedEnvId, logLevelFilter);
    if (!logSearch) return raw;
    const q = logSearch.toLowerCase();
    return raw.filter(
      (l) =>
        l.message.toLowerCase().includes(q) ||
        l.serviceName.toLowerCase().includes(q) ||
        l.serverName.toLowerCase().includes(q)
    );
  }, [selectedEnvId, logLevelFilter, logSearch]);

  const currentTraces = useMemo(() => {
    return monitoringService.getCorrelatedTraces(selectedEnvId);
  }, [selectedEnvId]);

  // Alert Actions
  const handleAcknowledgeAlert = (id: string) => {
    const updated = monitoringService.acknowledgeAlert(id, 'Ops Engineer');
    setAlerts(updated);
    showToast('Monitoring Alert acknowledged', 'info');
  };

  const handleResolveAlert = (id: string) => {
    const updated = monitoringService.resolveAlert(id);
    setAlerts(updated);
    showToast('Monitoring Alert resolved', 'success');
  };

  const integrations = useMemo(() => monitoringService.getIntegrations(), []);

  return (
    <div className="space-y-6 font-sans w-full min-w-0">
      {/* Top Banner Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              RESOURCE MANAGEMENT
            </span>
            <span className="text-slate-600">/</span>
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-orange-400 flex items-center gap-1">
              <Activity className="w-3 h-3" /> OBSERVABILITY LAYER
            </span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight flex items-center gap-3 mt-1">
            Environment Monitoring
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time telemetry, test environment readiness, infrastructure metrics, alerts, and dependency observability.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => showToast('Refreshed telemetry pipelines', 'success')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-xs font-mono font-bold text-slate-300 transition-colors shadow-sm"
          >
            <RefreshCw className="w-3.5 h-3.5 text-orange-400" />
            <span>SYNC TELEMETRY</span>
          </button>
        </div>
      </div>

      {/* 5 Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'overview'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Fleet Overview & Readiness ({metricsSummary.total})</span>
        </button>

        <button
          onClick={() => setActiveTab('telemetry')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'telemetry'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Metrics, Logs & Traces</span>
        </button>

        <button
          onClick={() => setActiveTab('alerts')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'alerts'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Bell className="w-4 h-4" />
          <span>Active Alerts & Rules ({alerts.filter((a) => a.status === 'ACTIVE').length})</span>
        </button>

        <button
          onClick={() => setActiveTab('maintenance')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'maintenance'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Maintenance Windows ({maintenanceList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('sources')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'sources'
              ? 'bg-orange-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Radio className="w-4 h-4" />
          <span>Telemetry Sources</span>
        </button>
      </div>

      {/* TAB 1: EXECUTIVE FLEET HEALTH & READINESS */}
      {activeTab === 'overview' && (
        isLoading ? (
          <CardSkeleton count={6} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" />
        ) : (
          <div className="space-y-6">
            {/* KPI Summary Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-slate-500 uppercase font-bold block">MONITORED ENVS</span>
                <span className="text-2xl font-extrabold text-white block">{metricsSummary.total}</span>
                <span className="text-[10px] text-slate-400">100% Covered</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-emerald-400 uppercase font-bold block">HEALTHY ENVS</span>
                <span className="text-2xl font-extrabold text-emerald-400 block">{metricsSummary.healthy}</span>
                <span className="text-[10px] text-emerald-500">Optimal State</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-amber-400 uppercase font-bold block">DEGRADED</span>
                <span className="text-2xl font-extrabold text-amber-400 block">{metricsSummary.degraded}</span>
                <span className="text-[10px] text-amber-500">Elevated Saturation</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-rose-400 uppercase font-bold block">UNHEALTHY</span>
                <span className="text-2xl font-extrabold text-rose-400 block">{metricsSummary.unhealthy}</span>
                <span className="text-[10px] text-rose-500">Action Required</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-1 shadow-lg">
                <span className="text-[10px] text-blue-400 uppercase font-bold block">MAINTENANCE</span>
                <span className="text-2xl font-extrabold text-blue-400 block">{metricsSummary.maintenance}</span>
                <span className="text-[10px] text-blue-500">Alerts Suppressed</span>
              </div>

              <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-1 shadow-lg bg-gradient-to-br from-emerald-950/30 to-slate-900">
                <span className="text-[10px] text-emerald-400 uppercase font-bold block">READY FOR TEST</span>
                <span className="text-2xl font-extrabold text-white block">{metricsSummary.readyForTesting}</span>
                <span className="text-[10px] text-emerald-400 font-bold">Passed 6/6 Checks</span>
              </div>
            </div>

            {/* Fleet Health & Test Readiness Dossiers */}
            <div className="space-y-3">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                ENVIRONMENT HEALTH & READINESS DOSSIERS
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {fleetHealthList.map(({ env, health, readiness }) => (
                  <div
                    key={env.id}
                    className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 hover:border-slate-700 rounded-xl p-5 space-y-4 transition-all shadow-xl font-mono text-xs group"
                  >
                  {/* Top Header */}
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] text-slate-500 font-bold uppercase block">{env.type}</span>
                      <h4 className="text-base font-extrabold text-white group-hover:text-orange-400 transition-colors">
                        {env.name}
                      </h4>
                      <p className="text-[10px] text-slate-500 mt-0.5">ID: {env.id}</p>
                    </div>

                    <EnvironmentReadinessBadge status={readiness.status} result={readiness} size="md" />
                  </div>

                  {/* Health Score Gauge */}
                  <div className="space-y-1 bg-slate-950/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800/80">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Environment Health Score</span>
                      <span className="font-extrabold text-white">{health.score}%</span>
                    </div>
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          health.score >= 90
                            ? 'bg-emerald-500'
                            : health.score >= 65
                            ? 'bg-amber-500'
                            : 'bg-rose-500'
                        }`}
                        style={{ width: `${health.score}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-slate-400 pt-1">{health.details}</p>
                  </div>

                  {/* Quick Component Telemetry Breakdown */}
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="bg-slate-900/60 p-2.5 rounded border border-slate-200 dark:border-slate-800/80 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-bold flex items-center gap-1">
                          <Server className="w-3.5 h-3.5 text-emerald-400" /> Servers
                        </span>
                        <span className="text-white font-extrabold">{env.serverIds?.length || 0}</span>
                      </div>
                      <p className="text-[10px] text-emerald-400">All Nodes Online</p>
                    </div>

                    <div className="bg-slate-900/60 p-2.5 rounded border border-slate-200 dark:border-slate-800/80 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-bold flex items-center gap-1">
                          <Cpu className="w-3.5 h-3.5 text-rose-400" /> Services
                        </span>
                        <span className="text-white font-extrabold">{env.softwareIds?.length || 0}</span>
                      </div>
                      <p className="text-[10px] text-slate-400">API P95: 140ms</p>
                    </div>
                  </div>

                  {/* Action Bar */}
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
                    <button
                      onClick={() => {
                        setSelectedEnvId(env.id);
                        setActiveTab('telemetry');
                      }}
                      className="text-orange-400 font-bold text-[11px] hover:underline flex items-center gap-1"
                    >
                      <span>VIEW METRICS & LOGS</span> →
                    </button>

                    <button
                      onClick={() =>
                        setImpactDrawerNode({
                          type: 'ENVIRONMENT',
                          id: env.id,
                          name: env.name,
                          environmentName: env.name,
                        })
                      }
                      className="text-slate-400 hover:text-white font-bold text-[11px] flex items-center gap-1"
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-400" /> BLAST RADIUS
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )
    )}

      {/* TAB 2: METRICS, LOGS & TRACES DEEP-DIVE */}
      {activeTab === 'telemetry' && (
        <div className="space-y-6 font-mono text-xs">
          {/* Controls Bar */}
          <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-xl flex flex-wrap items-center justify-between gap-4 shadow-lg">
            <div className="flex items-center gap-3">
              <span className="text-slate-400 font-bold">SELECT ENVIRONMENT:</span>
              <select
                value={selectedEnvId}
                onChange={(e) => setSelectedEnvId(e.target.value)}
                className="bg-[#161f2e] border border-slate-700 rounded px-3 py-1.5 text-white font-bold text-xs focus:outline-none focus:border-orange-500"
              >
                {environmentProfiles.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} ({e.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-slate-400 font-bold">TIMEFRAME:</span>
              {(['1h', '6h', '24h', '7d', '30d'] as TimeframeOption[]).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setSelectedTimeframe(tf)}
                  className={`px-2.5 py-1 rounded font-bold transition-colors ${
                    selectedTimeframe === tf
                      ? 'bg-orange-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>

          {/* Historical Telemetry Metric Charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* CPU */}
            <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold uppercase text-[10px]">CPU SATURATION</span>
                <Server className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-extrabold text-white">
                {currentTelemetry.cpu.current}%
              </div>
              <p className="text-[10px] text-slate-500">
                Avg: {currentTelemetry.cpu.avg}% · Peak: {currentTelemetry.cpu.peak}%
              </p>
            </div>

            {/* RAM */}
            <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold uppercase text-[10px]">MEMORY UTILIZATION</span>
                <Cpu className="w-4 h-4 text-rose-400" />
              </div>
              <div className="text-2xl font-extrabold text-white">
                {currentTelemetry.memory.current}%
              </div>
              <p className="text-[10px] text-slate-500">
                Avg: {currentTelemetry.memory.avg}% · Peak: {currentTelemetry.memory.peak}%
              </p>
            </div>

            {/* Response Time */}
            <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold uppercase text-[10px]">API P95 RESPONSE TIME</span>
                <Clock className="w-4 h-4 text-orange-400" />
              </div>
              <div className="text-2xl font-extrabold text-white">
                {currentTelemetry.responseTime.current}ms
              </div>
              <p className="text-[10px] text-slate-500">
                Avg: {currentTelemetry.responseTime.avg}ms · Peak: {currentTelemetry.responseTime.peak}ms
              </p>
            </div>

            {/* Error Rate */}
            <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold uppercase text-[10px]">APPLICATION ERROR RATE</span>
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-extrabold text-white">
                {currentTelemetry.errorRate.current}%
              </div>
              <p className="text-[10px] text-slate-500">
                Avg: {currentTelemetry.errorRate.avg}% · Peak: {currentTelemetry.errorRate.peak}%
              </p>
            </div>
          </div>

          {/* Correlated Log Streams Viewer */}
          <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Terminal className="w-4 h-4 text-orange-400" /> CORRELATED TELEMETRY LOG STREAM ({currentLogs.length})
              </h3>

              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input autoComplete="off" data-lpignore="true"
                    type="text"
                    value={logSearch}
                    onChange={(e) => setLogSearch(e.target.value)}
                    placeholder="Search logs..."
                    className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded pl-8 pr-3 py-1 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                  />
                </div>

                <select
                  value={logLevelFilter}
                  onChange={(e) => setLogLevelFilter(e.target.value)}
                  className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-1 text-white text-xs"
                >
                  <option value="ALL">All Severities</option>
                  <option value="ERROR">ERROR Only</option>
                  <option value="WARN">WARN Only</option>
                  <option value="INFO">INFO Only</option>
                </select>
              </div>
            </div>

            <div className="bg-black/60 dark:bg-black/80 rounded-lg p-3 space-y-2 font-mono text-[11px] max-h-72 overflow-y-auto border border-slate-900 divide-y divide-slate-900">
              {currentLogs.length === 0 ? (
                <p className="text-slate-600 italic text-center py-6">No telemetry logs matched filter criteria.</p>
              ) : (
                currentLogs.map((log) => (
                  <div key={log.id} className="pt-2 flex items-start gap-3">
                    <span className="text-slate-500 shrink-0">{log.timestamp.replace('T', ' ').substring(11, 19)}</span>
                    <span
                      className={`font-bold shrink-0 px-1.5 py-0.2 rounded text-[10px] ${
                        log.level === 'ERROR'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : log.level === 'WARN'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {log.level}
                    </span>
                    <span className="text-orange-400 font-bold shrink-0">[{log.serviceName}]</span>
                    <span className="text-slate-300 flex-1">{log.message}</span>
                    {log.traceId && (
                      <span className="text-[10px] text-slate-500 font-mono bg-slate-900 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-800 shrink-0">
                        Trace: {log.traceId}
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Distributed Traces Waterfall Viewer */}
          <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <Layers className="w-4 h-4 text-orange-400" /> DISTRIBUTED TRACE WATERFALLS ({currentTraces.length})
            </h3>

            <div className="space-y-4">
              {currentTraces.map((trace) => (
                <div key={trace.traceId} className="bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between font-bold">
                    <div className="flex items-center gap-2">
                      <span className="text-orange-400">{trace.rootService}</span>
                      <span className="text-slate-400 font-mono text-[11px]">{trace.operationName}</span>
                    </div>
                    <span className="text-slate-300 text-[11px]">
                      Duration: <strong className="text-white">{trace.totalDurationMs}ms</strong>
                    </span>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-900">
                    {trace.spans.map((span) => {
                      const pctStart = (span.startTimeOffsetMs / trace.totalDurationMs) * 100;
                      const pctWidth = (span.durationMs / trace.totalDurationMs) * 100;

                      return (
                        <div key={span.id} className="space-y-1">
                          <div className="flex items-center justify-between text-[10px] text-slate-400">
                            <span>{span.serviceName} · {span.name}</span>
                            <span>{span.durationMs}ms</span>
                          </div>
                          <div className="h-2 w-full bg-slate-900 rounded relative overflow-hidden">
                            <div
                              className={`h-full rounded ${span.status === 'ERROR' ? 'bg-rose-500' : 'bg-emerald-500'}`}
                              style={{ left: `${pctStart}%`, width: `${Math.max(5, pctWidth)}%`, position: 'relative' }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ACTIVE ALERTS & THRESHOLD RULES */}
      {activeTab === 'alerts' && (
        <div className="space-y-6 font-mono text-xs">
          {/* Active Alerts Feed */}
          <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <Bell className="w-4 h-4 text-rose-400" /> ACTIVE MONITORING ALERTS ({alerts.length})
            </h3>

            <div className="space-y-3">
              {alerts.length === 0 ? (
                <p className="text-slate-500 italic text-center py-6">No active monitoring alerts.</p>
              ) : (
                alerts.map((alt) => (
                  <div
                    key={alt.id}
                    className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg ${
                      alt.severity === 'CRITICAL'
                        ? 'bg-[#1f0b0e] border-rose-800 text-rose-100'
                        : alt.severity === 'WARNING'
                        ? 'bg-[#1c1409] border-amber-800 text-amber-100'
                        : 'bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-200'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-white text-sm">{alt.title}</span>
                        <span className="px-2 py-0.2 rounded text-[10px] font-bold uppercase bg-black/60 border border-slate-200 dark:border-slate-800">
                          {alt.severity}
                        </span>
                        <span className="text-[10px] text-slate-400">{alt.environmentName}</span>
                      </div>
                      <p className="text-xs text-slate-300">{alt.message}</p>
                      <p className="text-[10px] text-slate-500">
                        Triggered: {alt.triggeredAt.replace('T', ' ').substring(0, 19)} · Target: {alt.targetName}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {alt.status === 'ACTIVE' && (
                        <button
                          onClick={() => handleAcknowledgeAlert(alt.id)}
                          className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700"
                        >
                          Acknowledge
                        </button>
                      )}
                      <button
                        onClick={() => handleResolveAlert(alt.id)}
                        className="px-3 py-1.5 rounded bg-emerald-700 hover:bg-emerald-600 text-xs font-bold text-white border border-emerald-600"
                      >
                        Resolve
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: MAINTENANCE WINDOWS */}
      {activeTab === 'maintenance' && (
        <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-400" /> SCHEDULED MAINTENANCE WINDOWS
            </h3>
            <button
              onClick={() => showToast('Opened Maintenance Scheduler', 'info')}
              className="px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
            >
              + SCHEDULE MAINTENANCE
            </button>
          </div>

          <div className="space-y-3">
            {maintenanceList.map((m) => (
              <div key={m.id} className="bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">{m.title}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-950 text-blue-300 border border-blue-800">
                    {m.status}
                  </span>
                </div>
                <p className="text-xs text-slate-400">{m.description}</p>
                <p className="text-[10px] text-slate-500">
                  Target: <strong className="text-white">{m.environmentName}</strong> · Alert Suppression:{' '}
                  {m.suppressAlerts ? 'Enabled' : 'Disabled'}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: TELEMETRY SOURCES */}
      {activeTab === 'sources' && (
        <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
            <Radio className="w-4 h-4 text-orange-400" /> TELEMETRY ADAPTERS & SOURCES ({integrations.length})
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {integrations.map((integ) => (
              <div key={integ.id} className="bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-white">{integ.name}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                    {integ.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{integ.endpoint}</p>
                <p className="text-[10px] text-slate-500">
                  Active Metrics: <strong className="text-orange-400">{integ.activeMetricsCount}</strong> · Last Sync: {integ.lastSyncAt.replace('T', ' ').substring(11, 19)} UTC
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Impact Analysis Drawer Modal */}
      <ImpactAnalysisDrawer
        isOpen={!!impactDrawerNode}
        onClose={() => setImpactDrawerNode(null)}
        targetNode={impactDrawerNode}
        environments={environmentProfiles}
        bookings={bookings}
      />
    </div>
  );
};
