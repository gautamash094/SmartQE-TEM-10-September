import React, { useState, useMemo, useEffect } from 'react';
import { useTEM } from '../context/TEMContext';
import { useAuth } from '../context/AuthContext';
import { BookingModal } from '../components/features/BookingModal';
import { Pagination } from '../components/common/Pagination';
import { DateTimePicker } from '../components/common/DateTimePicker';
import { TableSkeleton } from '../components/common/Skeleton';
import { ButtonLoader } from '../components/common/ButtonLoader';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { aiIntelligenceService } from '../services/aiIntelligenceService';
import {
  ClipboardList,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Clock,
  Search,
  Filter,
  Download,
  Ban,
  Eye,
  Plus,
  Building2,
  AppWindow,
  Server,
  Layers,
  ArrowUpDown,
  ShieldAlert,
  XCircle,
  Users,
  Zap,
  Sparkles,
  Edit3,
  BrainCircuit,
  ArrowRight,
  Check,
  ShieldCheck,
} from 'lucide-react';
import { Booking, BookingAuditEntry } from '../types';
import { bookingService, AvailableSlotOption } from '../services/bookingService';
import { workflowService, Workflow } from '../services/workflowService';

const formatDisplayDateTime = (dtStr: string) => {
  if (!dtStr) return '-';
  try {
    const d = new Date(dtStr);
    if (isNaN(d.getTime())) return dtStr;
    const pad = (n: number) => n.toString().padStart(2, '0');
    const year = d.getFullYear();
    const month = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const hours = pad(d.getHours());
    const minutes = pad(d.getMinutes());
    const seconds = pad(d.getSeconds());
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  } catch (e) {
    return dtStr;
  }
};

const toInputDateTime = (dtStr: string) => {
  if (!dtStr) return '';
  try {
    const d = new Date(dtStr);
    if (isNaN(d.getTime())) return '';
    const pad = (n: number) => n.toString().padStart(2, '0');
    const year = d.getFullYear();
    const month = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const hours = pad(d.getHours());
    const minutes = pad(d.getMinutes());
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  } catch (e) {
    return '';
  }
};

interface ConflictPair {
  bookingA: Booking;
  bookingB: Booking;
  environmentName: string;
  overlapStart: string;
  overlapEnd: string;
}

export const WorklistPage: React.FC = () => {
  // Environment Details is the single source of truth for environments
  const { environmentProfiles, bookings, incidents, releases, approveBooking, cancelBooking, rejectBooking, updateBooking, showToast, isLoading } = useTEM();
  const { currentUser } = useAuth();
  const [allWorkflows, setAllWorkflows] = useState<Workflow[]>([]);

  useEffect(() => {
    workflowService.getWorkflows().then((wfs) => {
      if (Array.isArray(wfs)) setAllWorkflows(wfs);
    }).catch(() => {});
  }, []);

  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingToEdit, setBookingToEdit] = useState<Booking | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [isApplyingResolution, setIsApplyingResolution] = useState(false);

  // Approval Modal State
  const [bookingToApprove, setBookingToApprove] = useState<Booking | null>(null);
  const [approveComments, setApproveComments] = useState<string>('');

  // Cancellation Modal State
  const [bookingToCancel, setBookingToCancel] = useState<Booking | null>(null);

  // Rejection Modal State
  const [bookingToReject, setBookingToReject] = useState<Booking | null>(null);
  const [rejectReason, setRejectReason] = useState<string>('');

  // Check Availability Separate State
  const [isCheckingAvailability, setIsCheckingAvailability] = useState(false);
  const [availableSlots, setAvailableSlots] = useState<AvailableSlotOption[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<AvailableSlotOption | null>(null);

  // Conflict Resolution Flow State
  const [isResolvingConflict, setIsResolvingConflict] = useState(false);
  const [resolutionOption, setResolutionOption] = useState<'DATE_TIME' | 'MODE_CHANGE'>('DATE_TIME');
  const [resolveStartDate, setResolveStartDate] = useState('');
  const [resolveEndDate, setResolveEndDate] = useState('');
  const [resolutionError, setResolutionError] = useState<string | null>(null);
  const [resolutionSuccess, setResolutionSuccess] = useState<string | null>(null);

  // Live Date Order Validation for Conflict Resolution
  const isResolveDateOrderInvalid = useMemo(() => {
    if (!resolveStartDate || !resolveEndDate) return false;
    const s = new Date(resolveStartDate).getTime();
    const e = new Date(resolveEndDate).getTime();
    return !isNaN(s) && !isNaN(e) && s >= e;
  }, [resolveStartDate, resolveEndDate]);

  // Authorization helper checks - only System Admin (Super Admin account or Super Admin role)
  const isSuperAdmin = useMemo(() => {
    if (!currentUser) return false;
    return (
      Boolean(currentUser.isSuperAdmin) ||
      currentUser.username.toLowerCase() === 'admin' ||
      currentUser.email?.toLowerCase() === 'admin@tem.com' ||
      (currentUser.roles || []).some((r) => r.name.toLowerCase().trim() === 'super admin')
    );
  }, [currentUser]);

  const isCreator = (b: Booking): boolean => {
    if (!currentUser) return false;
    if (isSuperAdmin) return true;
    const userIdentifier = (currentUser.username || '').toLowerCase().trim();
    const userEmail = (currentUser.email || '').toLowerCase().trim();
    const userId = (currentUser.id || '').toLowerCase().trim();
    const requestedBy = (b.requestedBy || '').toLowerCase().trim();
    const createdBy = (b.createdBy || '').toLowerCase().trim();
    const ownerId = (b.ownerId || '').toLowerCase().trim();
    const assignedUserId = (b.assignedUserId || '').toLowerCase().trim();
    return Boolean(
      requestedBy === userIdentifier ||
      requestedBy === userEmail ||
      (createdBy && (createdBy === userIdentifier || createdBy === userEmail || createdBy === userId)) ||
      (ownerId && (ownerId === userId || ownerId === userIdentifier)) ||
      (assignedUserId && (assignedUserId === userId || assignedUserId === userIdentifier))
    );
  };

  const isCurrentApprover = (b: Booking): boolean => {
    if (!currentUser) return false;
    if (b.status !== 'PENDING') return false;
    // NOTE: Only the designated current approver can approve, NOT system admin unless they are explicitly the current approver!
    const username = (currentUser.username || '').toLowerCase().trim();
    const userEmail = (currentUser.email || '').toLowerCase().trim();
    const fullName = (currentUser.fullName || '').toLowerCase().trim();
    const userId = (currentUser.id || '').toLowerCase().trim();
    const curName = (b.currentApproverName || '').toLowerCase().trim();
    const curId = (b.currentApproverId || '').toLowerCase().trim();

    const matchesId = Boolean(curId && (curId === userId || curId === username));
    const matchesName = Boolean(
      curName && (
        curName === username ||
        curName === fullName ||
        curName === userEmail ||
        (fullName && (curName.includes(fullName) || fullName.includes(curName))) ||
        (username && (curName.includes(username) || username.includes(curName)))
      )
    );

    return matchesId || matchesName;
  };

  // AI Booking Intelligence for Conflict Resolution Flow
  const resolveAiAssistResult = useMemo(() => {
    if (!isResolvingConflict || !selectedBooking || !resolveStartDate || !resolveEndDate || isResolveDateOrderInvalid) return null;
    const effMode = resolutionOption === 'MODE_CHANGE' ? 'SHARED' : (selectedBooking.reservationMode || 'SHARED');
    return aiIntelligenceService.getBookingAIAssistance(
      selectedBooking.environmentId,
      resolveStartDate,
      resolveEndDate,
      effMode,
      environmentProfiles,
      bookings,
      incidents || [],
      releases || [],
      selectedBooking.id
    );
  }, [isResolvingConflict, selectedBooking, resolveStartDate, resolveEndDate, resolutionOption, isResolveDateOrderInvalid, environmentProfiles, bookings, incidents, releases]);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEnvFilter, setSelectedEnvFilter] = useState('ALL');
  const [selectedBuFilter, setSelectedBuFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'CONFIRMED' | 'CONFLICTS' | 'CANCELLED' | 'REJECTED' | 'AUTO_REJECTED'>('ALL');
  const [modeFilter, setModeFilter] = useState<'ALL' | 'SHARED' | 'DISRUPTIVE'>('ALL');

  // Pagination State
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Valid environment IDs and names from Environment Details module (single source of truth)
  const validProfileEnvSet = useMemo(() => {
    const ids = new Set<string>();
    const names = new Set<string>();
    (environmentProfiles || []).forEach((p) => {
      if (p.id) ids.add(p.id);
      if (p.name) names.add(p.name.toLowerCase().trim());
    });
    return { ids, names };
  }, [environmentProfiles]);

  // Filter reservations (all bookings for the authorized user / admin)
  const envDetailsBookings = useMemo(() => {
    if (!bookings) return [];
    if (isSuperAdmin) return bookings;
    if (!currentUser) return [];

    const userId = (currentUser.id || '').toLowerCase().trim();
    const username = (currentUser.username || '').toLowerCase().trim();
    const fullName = (currentUser.fullName || '').toLowerCase().trim();
    const email = (currentUser.email || '').toLowerCase().trim();

    return bookings.filter((b) => {
      const reqBy = (b.requestedBy || '').toLowerCase().trim();
      const ownerId = ((b as any).ownerId || '').toLowerCase().trim();
      const createdBy = ((b as any).createdBy || '').toLowerCase().trim();
      const approverId = ((b as any).currentApproverId || '').toLowerCase().trim();
      const approverName = ((b as any).currentApproverName || '').toLowerCase().trim();

      const isOwner = Boolean(ownerId && ownerId === userId);
      const isReq = Boolean(
        reqBy && (
          reqBy === username ||
          reqBy === fullName ||
          reqBy === email ||
          (fullName && (reqBy.includes(fullName) || fullName.includes(reqBy))) ||
          (username && (reqBy.includes(username) || username.includes(reqBy)))
        )
      );
      const isCreated = Boolean(
        createdBy && (
          createdBy === username ||
          createdBy === fullName ||
          createdBy === email ||
          (username && createdBy.includes(username))
        )
      );
      const isCurrentAppr = Boolean(
        (approverId && (approverId === userId || approverId === username)) ||
        (approverName && (approverName === username || approverName === fullName || approverName === email))
      );

      // Check if user is configured as ANY step approver in the reservation's workflow
      let isTaggedInWorkflow = false;
      if (allWorkflows.length > 0) {
        const matchingWfs = allWorkflows.filter((w) => {
          if (b.workflowId && w.id === b.workflowId) return true;
          const bBU = (b.businessUnit || '').toLowerCase().trim();
          const bEnvId = (b.environmentId || '').toLowerCase().trim();
          const bEnvName = (b.environmentName || '').toLowerCase().trim();
          const buMatch = (w.buId && w.buId.toLowerCase().trim() === bBU) || (w.buName && w.buName.toLowerCase().trim() === bBU) || (w.buCode && w.buCode.toLowerCase().trim() === bBU);
          const envMatch = (w.environmentId && (w.environmentId.toLowerCase().trim() === bEnvId || w.environmentId.toLowerCase().trim() === bEnvName)) || (w.environmentName && (w.environmentName.toLowerCase().trim() === bEnvName || w.environmentName.toLowerCase().trim() === bEnvId));
          return buMatch && envMatch;
        });

        isTaggedInWorkflow = matchingWfs.some((w) =>
          (w.approvers || []).some((a) => {
            const aId = (a.userId || '').toLowerCase().trim();
            const aUser = (a.username || '').toLowerCase().trim();
            const aName = (a.fullName || '').toLowerCase().trim();
            const aEmail = (a.email || '').toLowerCase().trim();
            return (
              (aId && (aId === userId || aId === username)) ||
              (aUser && (aUser === username || aUser === userId)) ||
              (aName && (aName === fullName || (fullName && aName.includes(fullName)))) ||
              (aEmail && aEmail === email)
            );
          })
        );
      }

      return isOwner || isReq || isCreated || isCurrentAppr || isTaggedInWorkflow;
    });
  }, [bookings, isSuperAdmin, currentUser, allWorkflows]);

  // --- CONFLICT DETECTION ALGORITHM ---
  // Evaluates Reservation Mode matrix: SHARED + SHARED -> No Conflict; DISRUPTIVE + ANY -> Conflict
  const { conflictMap, conflictPairs } = useMemo(() => {
    const map = new Map<string, Booking[]>(); // bookingId -> list of conflicting bookings
    const pairs: ConflictPair[] = [];

    for (let i = 0; i < envDetailsBookings.length; i++) {
      for (let j = i + 1; j < envDetailsBookings.length; j++) {
        const a = envDetailsBookings[i];
        const b = envDetailsBookings[j];

        // Skip canceled, rejected, and auto_rejected bookings from conflict detection
        if (
          a.status === 'CANCELLED' || a.status === 'REJECTED' || a.status === 'AUTO_REJECTED' ||
          b.status === 'CANCELLED' || b.status === 'REJECTED' || b.status === 'AUTO_REJECTED'
        ) {
          continue;
        }

        // Same environment check (by ID or name)
        const sameEnv =
          (a.environmentId && b.environmentId && a.environmentId === b.environmentId) ||
          (a.environmentName && b.environmentName && a.environmentName.toLowerCase() === b.environmentName.toLowerCase());

        if (sameEnv && a.startDate && a.endDate && b.startDate && b.endDate) {
          const aStart = new Date(a.startDate).getTime();
          const aEnd = new Date(a.endDate).getTime();
          const bStart = new Date(b.startDate).getTime();
          const bEnd = new Date(b.endDate).getTime();

          // Overlap condition: StartA < EndB && EndA > StartB
          const isTimeOverlap = aStart < bEnd && aEnd > bStart;
          if (isTimeOverlap) {
            const aMode = a.reservationMode || 'SHARED';
            const bMode = b.reservationMode || 'SHARED';
            const isConflict = aMode === 'DISRUPTIVE' || bMode === 'DISRUPTIVE';

            if (isConflict) {
              // Register conflict for a
              const aList = map.get(a.id) || [];
              aList.push(b);
              map.set(a.id, aList);

              // Register conflict for b
              const bList = map.get(b.id) || [];
              bList.push(a);
              map.set(b.id, bList);

              const overlapStart = new Date(Math.max(aStart, bStart)).toISOString().substring(0, 19).replace('T', ' ');
              const overlapEnd = new Date(Math.min(aEnd, bEnd)).toISOString().substring(0, 19).replace('T', ' ');

              pairs.push({
                bookingA: a,
                bookingB: b,
                environmentName: a.environmentName || 'Target Environment',
                overlapStart,
                overlapEnd,
              });
            }
          }
        }
      }
    }

    return { conflictMap: map, conflictPairs: pairs };
  }, [envDetailsBookings]);

  // Distinct BUs
  const distinctBUs = useMemo(() => {
    const set = new Set<string>();
    envDetailsBookings.forEach((b) => b.businessUnit && set.add(b.businessUnit));
    return Array.from(set);
  }, [envDetailsBookings]);

  // Available Environments for filter dropdown — strictly sourced from Environment Details (single source of truth)
  const availableEnvironments = useMemo(() => {
    if (!environmentProfiles || environmentProfiles.length === 0) return [];
    return environmentProfiles.map((p) => ({ id: p.id, name: p.name }));
  }, [environmentProfiles]);

  // Filtered Bookings
  const filteredBookings = useMemo(() => {
    return envDetailsBookings.filter((b) => {
      // Search
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        b.businessUnit?.toLowerCase().includes(q) ||
        b.project?.toLowerCase().includes(q) ||
        b.application?.toLowerCase().includes(q) ||
        b.environmentName?.toLowerCase().includes(q) ||
        b.purpose?.toLowerCase().includes(q) ||
        b.requestedBy?.toLowerCase().includes(q) ||
        b.currentApproverName?.toLowerCase().includes(q) ||
        b.id?.toLowerCase().includes(q);

      // Environment filter
      const matchEnv =
        selectedEnvFilter === 'ALL' ||
        b.environmentId === selectedEnvFilter ||
        b.environmentName === selectedEnvFilter;

      // BU filter
      const matchBU = selectedBuFilter === 'ALL' || b.businessUnit === selectedBuFilter;

      // Mode filter
      const matchMode = modeFilter === 'ALL' || (b.reservationMode || 'SHARED') === modeFilter;

      // Conflict / Status filter
      const isPending = b.status === 'PENDING';
      const isApproved = b.status === 'APPROVED';
      const isCancelled = b.status === 'CANCELLED';
      const isRejected = b.status === 'REJECTED';
      const isAutoRejected = b.status === 'AUTO_REJECTED';
      const isInactive = isCancelled || isRejected || isAutoRejected;
      const isConflict = !isInactive && conflictMap.has(b.id);

      const matchStatus =
        statusFilter === 'ALL' ||
        (statusFilter === 'PENDING' && isPending) ||
        (statusFilter === 'APPROVED' && isApproved) ||
        (statusFilter === 'CONFLICTS' && isConflict) ||
        (statusFilter === 'CONFIRMED' && (b.status === 'CONFIRMED' || isApproved) && !isConflict && !isInactive) ||
        (statusFilter === 'CANCELLED' && isCancelled) ||
        (statusFilter === 'REJECTED' && isRejected) ||
        (statusFilter === 'AUTO_REJECTED' && isAutoRejected);

      return matchSearch && matchEnv && matchBU && matchStatus && matchMode;
    });
  }, [envDetailsBookings, searchQuery, selectedEnvFilter, selectedBuFilter, statusFilter, modeFilter, conflictMap]);

  // Paginated bookings (min 5, max 10)
  const paginatedBookings = useMemo(() => {
    return filteredBookings.slice(
      (currentPage - 1) * pageSize,
      currentPage * pageSize
    );
  }, [filteredBookings, currentPage, pageSize]);

  // Reset page to 1 when filters change
  const handleSearchChange = (q: string) => {
    setSearchQuery(q);
    setCurrentPage(1);
  };
  const handleEnvFilterChange = (env: string) => {
    setSelectedEnvFilter(env);
    setCurrentPage(1);
  };
  const handleBuFilterChange = (bu: string) => {
    setSelectedBuFilter(bu);
    setCurrentPage(1);
  };
  const handleStatusFilterChange = (st: 'ALL' | 'PENDING' | 'APPROVED' | 'CONFIRMED' | 'CONFLICTS' | 'CANCELLED' | 'REJECTED' | 'AUTO_REJECTED') => {
    setStatusFilter(st);
    setCurrentPage(1);
  };

  // Export CSV
  const handleExportCSV = () => {
    if (envDetailsBookings.length === 0) return;
    const headers = 'ID,Environment,Business Unit,Project,Application,Purpose,Team,Requested By,Start Date,End Date,Status,Current Approver,Conflict\n';
    const rows = envDetailsBookings.map((b) => {
      const isConf = conflictMap.has(b.id) ? 'YES' : 'NO';
      return `"${b.id}","${b.environmentName}","${b.businessUnit}","${b.project}","${b.application}","${b.purpose}","${b.team}","${b.requestedBy}","${formatDisplayDateTime(b.startDate)}","${formatDisplayDateTime(b.endDate)}","${b.status}","${b.currentApproverName || ''}","${isConf}"`;
    }).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TEM_Bookings_Worklist_${new Date().toISOString().substring(0, 10)}.csv`;
    a.click();
  };

  // Open booking details
  const handleOpenBookingDetail = (b: Booking) => {
    setSelectedBooking(b);
    setIsResolvingConflict(false);
    setResolveStartDate(toInputDateTime(b.startDate));
    setResolveEndDate(toInputDateTime(b.endDate));
    setResolutionError(null);
    setResolutionSuccess(null);
  };

  // Action: Confirm Approval
  const handleConfirmApprove = async () => {
    if (!bookingToApprove) return;
    const bId = bookingToApprove.id;
    setIsApproving(true);
    try {
      const comments = approveComments.trim() || undefined;
      const res = await approveBooking(bId, 'APPROVE', comments);
      setBookingToApprove(null);
      setApproveComments('');
      if (selectedBooking && selectedBooking.id === bId) {
        setSelectedBooking(res?.booking || null);
      }
      showToast(res?.message || 'Reservation approved successfully.', 'success');
    } catch (err: any) {
      // Toast already shown in context
    } finally {
      setIsApproving(false);
    }
  };

  // Action 1: Check Availability (DOES NOT AUTO-RESOLVE OR UPDATE BOOKING)
  const handleWorklistCheckAvailability = () => {
    if (!selectedBooking) return;
    const slots = bookingService.findAvailableAlternativeSlots(selectedBooking, envDetailsBookings);
    setAvailableSlots(slots);
    setIsCheckingAvailability(true);
    setResolutionError(null);
    showToast('Available slots discovered. Select a slot and click "Resolve Conflict" to apply.', 'info');
  };

  const handleSelectWorklistSlot = (slot: AvailableSlotOption) => {
    setSelectedSlot(slot);
    setResolveStartDate(toInputDateTime(slot.startDate));
    setResolveEndDate(toInputDateTime(slot.endDate));
    showToast(`Selected slot (${slot.displayDate} ${slot.displayStartTime}). Click 'Resolve Conflict' to apply.`, 'info');
  };

  // Action 2: Open conflict resolution sub-interface
  const handleStartResolveConflict = () => {
    if (!selectedBooking) return;
    setIsResolvingConflict(true);
    if (selectedSlot) {
      setResolveStartDate(toInputDateTime(selectedSlot.startDate));
      setResolveEndDate(toInputDateTime(selectedSlot.endDate));
    } else {
      setResolveStartDate(toInputDateTime(selectedBooking.startDate));
      setResolveEndDate(toInputDateTime(selectedBooking.endDate));
    }
    setResolutionOption(selectedSlot ? 'DATE_TIME' : 'DATE_TIME');
    setResolutionError(null);
    setResolutionSuccess(null);
  };

  // Submit and execute conflict resolution with final validation
  const handleResolveConflictSubmit = async () => {
    if (!selectedBooking) return;
    setResolutionError(null);

    // Option B: Change Reservation Mode (Disruptive -> Shared)
    if (resolutionOption === 'MODE_CHANGE') {
      const modeCheck = bookingService.validateSlotAvailability(
        selectedBooking.id,
        selectedBooking.environmentId,
        selectedBooking.environmentName,
        selectedBooking.startDate,
        selectedBooking.endDate,
        'SHARED',
        envDetailsBookings
      );

      if (!modeCheck.isAvailable) {
        const errorMsg = modeCheck.conflictReason || 'Cannot resolve conflict by mode change alone: Overlapping bookings also require exclusive control.';
        setResolutionError(errorMsg);
        showToast(errorMsg, 'error');
        return;
      }

      const rawAudit = selectedBooking.auditHistory;
      const auditList: BookingAuditEntry[] = Array.isArray(rawAudit)
        ? rawAudit
        : typeof rawAudit === 'string'
        ? JSON.parse(rawAudit || '[]')
        : [];
      const isAlreadyFullyApproved = auditList.some(
        (a: any) =>
          a.status === 'APPROVED' &&
          a.newValue &&
          a.newValue.toLowerCase().includes('all workflow approvers have approved')
      );

      const nextResolvedStatus = isAlreadyFullyApproved
        ? 'APPROVED'
        : (selectedBooking.workflowId && selectedBooking.currentApproverId)
        ? 'PENDING'
        : 'CONFIRMED';
      try {
        const updated = await updateBooking(selectedBooking.id, {
          reservationMode: 'SHARED',
          status: nextResolvedStatus,
          currentApproverId: isAlreadyFullyApproved ? undefined : selectedBooking.currentApproverId,
          currentApproverName: isAlreadyFullyApproved ? undefined : selectedBooking.currentApproverName,
        });
        const successMsg = isAlreadyFullyApproved
          ? 'Conflict resolved by changing the reservation mode to Shared. Reservation is confirmed and active.'
          : 'Conflict resolved by changing the reservation mode to Shared. You can now proceed to approve the reservation.';
        setResolutionError(null);
        setResolutionSuccess(successMsg);
        showToast(successMsg, 'success');
        setSelectedBooking(updated || {
          ...selectedBooking,
          reservationMode: 'SHARED',
          status: nextResolvedStatus,
          currentApproverId: isAlreadyFullyApproved ? undefined : selectedBooking.currentApproverId,
          currentApproverName: isAlreadyFullyApproved ? undefined : selectedBooking.currentApproverName,
        });
        setIsResolvingConflict(false);
        setIsCheckingAvailability(false);
      } catch (err: any) {
        setResolutionError(err.message || 'Failed to resolve conflict.');
      }
      return;
    }

    // Option A: Change Date & Time
    if (!resolveStartDate || !resolveEndDate) {
      setResolutionError('Please select both start and end date/time.');
      return;
    }

    const newStart = new Date(resolveStartDate).getTime();
    const newEnd = new Date(resolveEndDate).getTime();

    if (isNaN(newStart) || isNaN(newEnd)) {
      setResolutionError('Invalid date/time format.');
      return;
    }

    if (newEnd <= newStart) {
      const dateOrderError = 'Start date time is greater than the end date time.';
      setResolutionError(dateOrderError);
      setResolutionSuccess(null);
      showToast(dateOrderError, 'error');
      return;
    }

    // Final Race Condition Validation right before saving
    const finalValidation = bookingService.validateSlotAvailability(
      selectedBooking.id,
      selectedBooking.environmentId,
      selectedBooking.environmentName,
      resolveStartDate,
      resolveEndDate,
      selectedBooking.reservationMode || 'SHARED',
      envDetailsBookings
    );

    if (!finalValidation.isAvailable) {
      const raceError = 'The selected slot is no longer available. Please check availability again.';
      setResolutionError(raceError);
      setResolutionSuccess(null);
      showToast(raceError, 'error');
      return;
    }

    const rawAudit = selectedBooking.auditHistory;
    const auditList: BookingAuditEntry[] = Array.isArray(rawAudit)
      ? rawAudit
      : typeof rawAudit === 'string'
      ? JSON.parse(rawAudit || '[]')
      : [];
    const isAlreadyFullyApproved = auditList.some(
      (a: any) =>
        a.status === 'APPROVED' &&
        a.newValue &&
        a.newValue.toLowerCase().includes('all workflow approvers have approved')
    );

    const nextResolvedStatus = isAlreadyFullyApproved
      ? 'APPROVED'
      : (selectedBooking.workflowId && selectedBooking.currentApproverId)
      ? 'PENDING'
      : 'CONFIRMED';
    setIsApplyingResolution(true);
    try {
      const updated = await updateBooking(selectedBooking.id, {
        startDate: resolveStartDate,
        endDate: resolveEndDate,
        status: nextResolvedStatus,
        currentApproverId: isAlreadyFullyApproved ? undefined : selectedBooking.currentApproverId,
        currentApproverName: isAlreadyFullyApproved ? undefined : selectedBooking.currentApproverName,
      });
      const successMsg = isAlreadyFullyApproved
        ? 'Conflict resolved. The reservation time window has been updated and reservation is active.'
        : 'Conflict resolved. The reservation time window has been updated. You can now proceed to approve the reservation.';
      setResolutionError(null);
      setResolutionSuccess(successMsg);
      showToast(successMsg, 'success');
      setSelectedBooking(updated || {
        ...selectedBooking,
        startDate: resolveStartDate,
        endDate: resolveEndDate,
        status: nextResolvedStatus,
        currentApproverId: isAlreadyFullyApproved ? undefined : selectedBooking.currentApproverId,
        currentApproverName: isAlreadyFullyApproved ? undefined : selectedBooking.currentApproverName,
      });
      setIsResolvingConflict(false);
      setIsCheckingAvailability(false);
    } catch (err: any) {
      setResolutionError(err.message || 'Failed to resolve conflict.');
    } finally {
      setIsApplyingResolution(false);
    }
  };

  // Confirm and execute date-wide cancellation
  const handleConfirmCancel = async () => {
    if (!bookingToCancel) return;
    const bId = bookingToCancel.id;
    setIsCancelling(true);
    try {
      setBookingToCancel(null);
      if (selectedBooking && selectedBooking.id === bId) {
        setSelectedBooking((prev) => (prev ? { ...prev, status: 'CANCELLED' } : null));
      }
      setIsResolvingConflict(false);
      await cancelBooking(bId);
    } finally {
      setIsCancelling(false);
    }
  };

  // Confirm and execute manual rejection
  const handleConfirmReject = async () => {
    if (!bookingToReject) return;
    const bId = bookingToReject.id;
    const reason = rejectReason.trim() || 'Manually rejected by user';
    setIsRejecting(true);
    try {
      setBookingToReject(null);
      setRejectReason('');
      if (selectedBooking && selectedBooking.id === bId) {
        setSelectedBooking((prev) =>
          prev
            ? {
                ...prev,
                status: 'REJECTED',
                rejectionReason: reason,
                rejectionType: 'MANUAL',
                rejectedAt: new Date().toISOString(),
              }
            : null
        );
      }
      setIsResolvingConflict(false);
      await rejectBooking(bId, reason);
    } finally {
      setIsRejecting(false);
    }
  };

  return (
    <div className="space-y-6 font-sans w-full min-w-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              OPERATIONS & DISPATCH
            </span>
            {conflictPairs.length > 0 && (
              <span className="bg-red-950 text-red-400 border border-red-800 text-[10px] font-mono font-bold px-2 py-0.5 rounded flex items-center gap-1 animate-pulse">
                <AlertTriangle className="w-3 h-3" /> {conflictPairs.length} OVERLAPPING CONFLICT{conflictPairs.length > 1 ? 'S' : ''} DETECTED
              </span>
            )}
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight flex items-center gap-3 mt-0.5">
            <ClipboardList className="w-8 h-8 text-orange-500" />
            Bookings Worklist
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Enterprise schedule ledger with multi-variable collision detection, BU tracking, and resource dispatch.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            disabled={envDetailsBookings.length === 0}
            className="flex items-center gap-2 px-4 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors disabled:opacity-50"
          >
            <Download className="w-4 h-4" /> EXPORT CSV
          </button>
          {!isSuperAdmin && (
            <button
              onClick={() => setIsBookingModalOpen(true)}
              className="flex items-center gap-2 px-5 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_16px_rgba(249,115,22,0.4)]"
            >
              <Plus className="w-4 h-4" /> NEW RESERVATION
            </button>
          )}
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400">TOTAL BOOKINGS</span>
            <Calendar className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-3xl font-extrabold text-white mt-2">{envDetailsBookings.length}</p>
          <p className="text-xs text-slate-500 mt-1">All registered slots</p>
        </div>

        <div
          onClick={() => setStatusFilter(statusFilter === 'CONFLICTS' ? 'ALL' : 'CONFLICTS')}
          className={`p-5 rounded-lg border cursor-pointer transition-all ${
            conflictPairs.length > 0
              ? 'bg-[#220d0f] border-red-600/80 shadow-[0_0_15px_rgba(239,68,68,0.2)]'
              : 'bg-[#0f1724] border-slate-200 dark:border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-red-400">CONFLICTING RESERVATIONS</span>
            <ShieldAlert className="w-4 h-4 text-red-400 animate-pulse" />
          </div>
          <p className="text-3xl font-extrabold text-red-400 mt-2">{conflictMap.size}</p>
          <p className="text-xs text-red-300/80 mt-1 font-sans">
            {conflictPairs.length === 0 ? '0 collisions detected' : `${conflictPairs.length} overlapping slot(s)`}
          </p>
        </div>

        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400">BUSINESS UNITS ENGAGED</span>
            <Building2 className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-3xl font-extrabold text-white mt-2">{distinctBUs.length}</p>
          <p className="text-xs text-slate-500 mt-1">Divisions reserving</p>
        </div>

        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-5 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400">CLEAN SCHEDULE SLOTS</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-extrabold text-emerald-400 mt-2">
            {envDetailsBookings.filter((b) => b.status !== 'CANCELLED' && b.status !== 'REJECTED' && b.status !== 'AUTO_REJECTED' && !conflictMap.has(b.id)).length}
          </p>
          <p className="text-xs text-emerald-500/80 mt-1">Non-conflicting</p>
        </div>
      </div>

      {/* CONFLICT ALERT BANNER */}
      {conflictPairs.length > 0 && (
        <div className="bg-[#1f0b0e] border-2 border-red-600/90 rounded-lg p-5 shadow-2xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded bg-red-950 border border-red-800 text-red-400">
                <AlertTriangle className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-bold text-red-200">
                  CRITICAL: Schedule Collision Detected on {conflictPairs.length} Environment Slot{conflictPairs.length > 1 ? 's' : ''}
                </h3>
                <p className="text-xs text-red-300/80 font-mono">
                  Two or more teams have booked overlapping time windows (down to the second) on the same environment. Review collisions below:
                </p>
              </div>
            </div>
            <button
              onClick={() => setStatusFilter(statusFilter === 'CONFLICTS' ? 'ALL' : 'CONFLICTS')}
              className="px-4 py-2 rounded bg-red-900/80 hover:bg-red-800 text-xs font-mono font-bold text-white border border-red-600 transition-colors shrink-0"
            >
              {statusFilter === 'CONFLICTS' ? 'SHOW ALL RESERVATIONS' : 'FILTER CONFLICTS ONLY'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            {conflictPairs.map((pair, idx) => (
              <div
                key={idx}
                className="bg-black/40 border border-red-800/80 rounded p-3 text-xs font-mono text-slate-200 space-y-1.5"
              >
                <div className="flex items-center justify-between font-bold text-orange-400">
                  <span>🏢 {pair.environmentName}</span>
                  <span className="text-red-400 text-[10px] bg-red-950 px-2 py-0.5 rounded border border-red-800">
                    OVERLAP: {pair.overlapStart} → {pair.overlapEnd}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-red-900/50">
                  <div className="bg-red-950/40 p-2 rounded border border-red-900/40">
                    <p className="font-bold text-white truncate">{pair.bookingA.purpose}</p>
                    <p className="text-slate-400 truncate">BU: {pair.bookingA.businessUnit}</p>
                    <p className="text-slate-400 truncate">App: {pair.bookingA.application}</p>
                    <p className="text-orange-400 text-[10px]">Req: {pair.bookingA.requestedBy}</p>
                  </div>
                  <div className="bg-red-950/40 p-2 rounded border border-red-900/40">
                    <p className="font-bold text-white truncate">{pair.bookingB.purpose}</p>
                    <p className="text-slate-400 truncate">BU: {pair.bookingB.businessUnit}</p>
                    <p className="text-slate-400 truncate">App: {pair.bookingB.application}</p>
                    <p className="text-orange-400 text-[10px]">Req: {pair.bookingB.requestedBy}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* FILTER & SEARCH TOOLBAR */}
      <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 p-4 rounded-lg flex flex-col lg:flex-row items-center justify-between gap-4 font-mono text-xs shadow-lg">
        {/* Search */}
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input autoComplete="off" data-lpignore="true"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by BU, Project, App, Environment, Purpose..."
            className="w-full bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
          />
        </div>

        {/* Dropdown Filters */}
        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          {/* Environment Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">ENV:</span>
            <select
              value={selectedEnvFilter}
              onChange={(e) => handleEnvFilterChange(e.target.value)}
              className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-2 text-white text-xs focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">All Environments</option>
              {availableEnvironments.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </select>
          </div>

          {/* Business Unit Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">BU:</span>
            <select
              value={selectedBuFilter}
              onChange={(e) => handleBuFilterChange(e.target.value)}
              className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-2 text-white text-xs focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">All Business Units</option>
              {distinctBUs.map((bu) => (
                <option key={bu} value={bu}>
                  {bu}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">STATUS:</span>
            <select
              value={statusFilter}
              onChange={(e) => handleStatusFilterChange(e.target.value as any)}
              className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-2 text-white text-xs focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">All Status</option>
              <option value="CONFIRMED">✅ Confirmed (Clean)</option>
              <option value="CONFLICTS">⚠️ Conflicts Only</option>
              <option value="REJECTED">❌ Rejected</option>
              <option value="AUTO_REJECTED">⏰ Auto Rejected</option>
              <option value="CANCELLED">🚫 Canceled</option>
            </select>
          </div>

          {/* Reservation Mode Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold uppercase text-[10px]">MODE:</span>
            <select
              value={modeFilter}
              onChange={(e) => {
                setModeFilter(e.target.value as any);
                setCurrentPage(1);
              }}
              className="bg-[#161f2e] border border-slate-200 dark:border-slate-800 rounded px-2.5 py-2 text-white text-xs focus:outline-none focus:border-orange-500"
            >
              <option value="ALL">All Modes</option>
              <option value="SHARED">👥 Shared</option>
              <option value="DISRUPTIVE">⚡ Disruptive</option>
            </select>
          </div>
        </div>
      </div>

      {/* ENTERPRISE WORKLIST TABLE */}
      {isLoading ? (
        <TableSkeleton rows={pageSize} columns={7} />
      ) : (
        <div className="bg-[#0f1724] border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
        {filteredBookings.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <ClipboardList className="w-12 h-12 text-slate-600 mx-auto" />
            <p className="text-sm font-bold text-slate-300">No Reservations Found</p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {envDetailsBookings.length === 0
                ? 'No bookings have been scheduled in the system yet. Click "+ NEW RESERVATION" above to create your first booking.'
                : 'No bookings matched your current filter criteria. Try adjusting your search query or filters.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold tracking-wider">
                <tr>
                  <th className="p-3.5">COLLISION / STATUS</th>
                  <th className="p-3.5">RESERVATION MODE</th>
                  <th className="p-3.5">TARGET ENVIRONMENT</th>
                  <th className="p-3.5">BUSINESS UNIT & APP</th>
                  <th className="p-3.5">PURPOSE / TEAM</th>
                  <th className="p-3.5">TIME WINDOW (HH:MM:SS)</th>
                  <th className="p-3.5">REQUESTED BY</th>
                  <th className="p-3.5 text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {paginatedBookings.map((b) => {
                  const conflictingWith = conflictMap.get(b.id);
                  const isCancelled = b.status === 'CANCELLED';
                  const isRejected = b.status === 'REJECTED';
                  const isAutoRejected = b.status === 'AUTO_REJECTED';
                  const isInactive = isCancelled || isRejected || isAutoRejected;
                  const isConflict = !isInactive && !!conflictingWith && conflictingWith.length > 0;

                  return (
                    <tr
                      key={b.id}
                      onClick={() => handleOpenBookingDetail(b)}
                      className={`hover:bg-slate-800/40 transition-colors cursor-pointer group ${
                        isInactive
                          ? 'bg-slate-900/30 opacity-75'
                          : isConflict
                          ? 'bg-red-950/20 hover:bg-red-950/40 border-l-4 border-l-red-500'
                          : ''
                      }`}
                    >
                      {/* Collision / Status */}
                      <td className="p-3.5">
                        {isCancelled ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                            <Ban className="w-3 h-3" /> Canceled
                          </span>
                        ) : isRejected ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800">
                            <XCircle className="w-3 h-3 text-rose-400" /> Rejected
                          </span>
                        ) : isAutoRejected ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-800">
                            <Clock className="w-3 h-3 text-purple-400" /> Auto Rejected
                          </span>
                        ) : b.status === 'PENDING' ? (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-700">
                              <Clock className="w-3 h-3 text-amber-400" /> Pending (Step {b.currentWorkflowOrder || 1})
                            </span>
                            {b.currentApproverName && (
                              <div className="text-[10px] text-amber-400/90 flex items-center gap-1 font-sans">
                                <span>Waiting on:</span>
                                <span className="font-semibold text-white font-mono">{b.currentApproverName}</span>
                              </div>
                            )}
                          </div>
                        ) : isConflict ? (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-700 animate-pulse">
                              <AlertTriangle className="w-3.5 h-3.5 text-red-400" /> CONFLICT ({conflictingWith.length} OVERLAP)
                            </span>
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                            <CheckCircle2 className="w-3 h-3" /> {b.status === 'APPROVED' ? 'Approved' : (b.status || 'Confirmed')}
                          </span>
                        )}
                      </td>

                      {/* Reservation Mode */}
                      <td className="p-3.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded text-[10px] font-bold uppercase border ${
                            (b.reservationMode || 'SHARED') === 'DISRUPTIVE'
                              ? 'bg-amber-950/80 text-amber-300 border-amber-800'
                              : 'bg-cyan-950/80 text-cyan-300 border-cyan-800'
                          }`}
                        >
                          {(b.reservationMode || 'SHARED') === 'DISRUPTIVE' ? (
                            <>
                              <Zap className="w-3 h-3 text-amber-400" /> DISRUPTIVE
                            </>
                          ) : (
                            <>
                              <Users className="w-3 h-3 text-cyan-400" /> SHARED
                            </>
                          )}
                        </span>
                      </td>

                      {/* Environment */}
                      <td className="p-3.5">
                        <div className="font-bold text-white text-sm group-hover:text-orange-400 transition-colors flex items-center gap-1.5">
                          <Server className="w-3.5 h-3.5 text-slate-500" />
                          {b.environmentName}
                        </div>
                      </td>

                      {/* Business Unit & Application */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-1.5">
                          <span className="bg-slate-800 text-orange-400 font-bold px-2 py-0.5 rounded text-[10px]">
                            {b.businessUnit}
                          </span>
                        </div>
                        <div className="text-white font-bold text-xs mt-1">{b.application}</div>
                        <div className="text-[10px] text-slate-400">Proj: {b.project}</div>
                      </td>

                      {/* Purpose & Team */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-white text-xs max-w-xs truncate">{b.purpose}</span>
                          {b.priority && b.priority !== 'MEDIUM' && (
                            <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                              b.priority === 'CRITICAL' ? 'bg-red-950 text-red-400 border border-red-800' :
                              b.priority === 'HIGH' ? 'bg-orange-950 text-orange-400 border border-orange-800' :
                              'bg-slate-800 text-slate-400'
                            }`}>
                              {b.priority}
                            </span>
                          )}
                          {b.autoApprovalEnabled && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                              AUTO: {b.autoApprovalRule || 'ON'}
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-400 block mt-0.5">{b.team}</span>
                      </td>

                      {/* Time Window */}
                      <td className="p-3.5 font-mono">
                        <div className="text-orange-300 font-bold text-xs flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                          <span>{formatDisplayDateTime(b.startDate)}</span>
                        </div>
                        <div className="text-slate-400 text-[11px] ml-5">
                          → {formatDisplayDateTime(b.endDate)}
                        </div>
                      </td>

                      {/* Requested By */}
                      <td className="p-3.5">
                        <span className="text-white font-sans text-xs">{b.requestedBy}</span>
                      </td>

                      {/* Actions */}
                      <td className="p-3.5 text-right space-x-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenBookingDetail(b);
                          }}
                          title="View Details"
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5 inline" />
                        </button>
                        {!isInactive && b.status === 'PENDING' && (
                          <>
                            {isCurrentApprover(b) && (
                              <>
                                <button
                                  disabled={conflictMap.has(b.id)}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (conflictMap.has(b.id)) {
                                      showToast('Please resolve the schedule conflict first before approving this reservation.', 'error');
                                      return;
                                    }
                                    setBookingToApprove(b);
                                    setApproveComments('');
                                  }}
                                  title={conflictMap.has(b.id) ? "Please resolve the schedule conflict first before approving this reservation." : "Approve Reservation Step"}
                                  className={`px-2.5 py-1 rounded transition-colors ${
                                    conflictMap.has(b.id)
                                      ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed opacity-50 shadow-none'
                                      : 'bg-emerald-950 hover:bg-emerald-700 text-emerald-300 hover:text-white border border-emerald-800'
                                  }`}
                                >
                                  <Check className="w-3.5 h-3.5 inline" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setBookingToReject(b);
                                    setRejectReason('');
                                  }}
                                  title="Reject Reservation"
                                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-rose-700 text-rose-300 hover:text-white transition-colors"
                                >
                                  <XCircle className="w-3.5 h-3.5 inline" />
                                </button>
                              </>
                            )}
                            {isCreator(b) && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setBookingToCancel(b);
                                }}
                                title="Cancel My Reservation"
                                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-red-600 text-slate-300 hover:text-white transition-colors"
                              >
                                <Ban className="w-3.5 h-3.5 inline" />
                              </button>
                            )}
                          </>
                        )}
                        {!isInactive && b.status !== 'PENDING' && (
                          <>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setBookingToEdit(b);
                                setIsBookingModalOpen(true);
                              }}
                              title="Edit Reservation"
                              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-orange-600 text-orange-400 hover:text-white transition-colors"
                            >
                              <Edit3 className="w-3.5 h-3.5 inline" />
                            </button>
                            {isSuperAdmin && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setBookingToReject(b);
                                  setRejectReason('');
                                }}
                                title="Reject Reservation"
                                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-rose-700 text-rose-300 hover:text-white transition-colors"
                              >
                                <XCircle className="w-3.5 h-3.5 inline" />
                              </button>
                            )}
                            {isCreator(b) && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setBookingToCancel(b);
                                }}
                                title="Cancel Reservation"
                                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-red-600 text-slate-300 hover:text-white transition-colors"
                              >
                                <Ban className="w-3.5 h-3.5 inline" />
                              </button>
                            )}
                          </>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Footer */}
        <Pagination
          currentPage={currentPage}
          totalItems={filteredBookings.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
          onPageSizeChange={(size) => {
            setPageSize(size);
            setCurrentPage(1);
          }}
          pageSizeOptions={[10, 20, 50]}
        />
      </div>
    )}

      {/* DETAIL MODAL FOR SELECTED BOOKING */}
      {selectedBooking && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-slate-700 rounded-lg max-w-4xl w-full font-mono text-xs relative shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
            {/* STICKY HEADER */}
            <div className="shrink-0 p-6 pb-4 border-b border-slate-200 dark:border-slate-800 relative bg-[#0f1724] z-10">
              <button
                onClick={() => {
                  setSelectedBooking(null);
                  setIsResolvingConflict(false);
                  setIsCheckingAvailability(false);
                }}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>

              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase text-orange-400 font-bold">RESERVATION DISPATCH DOSSIER</span>
                {selectedBooking.status === 'CANCELLED' ? (
                  <span className="px-2.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 font-bold">
                    CANCELED
                  </span>
                ) : selectedBooking.status === 'REJECTED' ? (
                  <span className="px-2.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold flex items-center gap-1">
                    <XCircle className="w-3.5 h-3.5 text-rose-400" /> REJECTED
                  </span>
                ) : selectedBooking.status === 'AUTO_REJECTED' ? (
                  <span className="px-2.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-bold flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-purple-400" /> AUTO REJECTED
                  </span>
                ) : selectedBooking.status === 'PENDING' ? (
                  <span className="px-2.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-amber-400" /> PENDING APPROVAL (STEP {selectedBooking.currentWorkflowOrder || 1})
                  </span>
                ) : conflictMap.has(selectedBooking.id) ? (
                  <span className="px-2.5 py-0.5 rounded bg-red-950 text-red-400 border border-red-800 font-bold flex items-center gap-1 animate-pulse">
                    <AlertTriangle className="w-3.5 h-3.5" /> OVERLAPPING CONFLICT
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> {selectedBooking.status === 'APPROVED' ? 'APPROVED' : (selectedBooking.status || 'CONFIRMED')}
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold text-white mt-1">{selectedBooking.purpose}</h2>
            </div>

            {/* SCROLLABLE MODAL BODY */}
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* PENDING APPROVAL WORKFLOW BANNER */}
              {selectedBooking.status === 'PENDING' && (
                <div className="bg-amber-950/40 border border-amber-700/80 p-4 rounded-lg space-y-2 font-mono text-xs">
                  <div className="flex items-center justify-between text-amber-300 font-bold">
                    <span className="flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                      <Clock className="w-4 h-4 text-amber-400" />
                      SEQUENTIAL APPROVAL WORKFLOW ACTIVE
                    </span>
                    <span className="text-[10px] bg-amber-900/60 px-2 py-0.5 rounded border border-amber-700">
                      STEP {selectedBooking.currentWorkflowOrder || 1}
                    </span>
                  </div>
                  <div className="text-slate-200">
                    <span className="text-slate-400">Current Assigned Approver: </span>
                    <span className="font-bold text-white bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                      {selectedBooking.currentApproverName || 'Designated Approver'}
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-200/80 font-sans">
                    This reservation is held in pending status until all configured approvers in the sequence complete their approval.
                  </p>
                </div>
              )}

              {/* Breakdown Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="bg-slate-900/90 p-3 rounded border border-slate-200 dark:border-slate-800">
                  <p className="text-[10px] text-slate-500 uppercase">ENVIRONMENT</p>
                  <p className="font-bold text-white text-sm mt-1">{selectedBooking.environmentName}</p>
                </div>
                <div className="bg-slate-900/90 p-3 rounded border border-slate-200 dark:border-slate-800">
                  <p className="text-[10px] text-slate-500 uppercase">BUSINESS UNIT</p>
                  <p className="font-bold text-orange-400 text-sm mt-1">{selectedBooking.businessUnit}</p>
                </div>
                <div className="bg-slate-900/90 p-3 rounded border border-slate-200 dark:border-slate-800">
                  <p className="text-[10px] text-slate-500 uppercase">PROJECT</p>
                  <p className="font-bold text-white text-sm mt-1">{selectedBooking.project}</p>
                </div>
                <div className="bg-slate-900/90 p-3 rounded border border-slate-200 dark:border-slate-800">
                  <p className="text-[10px] text-slate-500 uppercase">APPLICATION</p>
                  <p className="font-bold text-white text-sm mt-1">{selectedBooking.application}</p>
                </div>
                <div className="bg-slate-900/90 p-3 rounded border border-slate-200 dark:border-slate-800">
                  <p className="text-[10px] text-slate-500 uppercase">TEAM</p>
                  <p className="font-bold text-slate-300 mt-1">{selectedBooking.team}</p>
                </div>
                <div className="bg-slate-900/90 p-3 rounded border border-slate-200 dark:border-slate-800">
                  <p className="text-[10px] text-slate-500 uppercase">PRIORITY</p>
                  <p className="font-bold text-white text-sm mt-1">{selectedBooking.priority || 'MEDIUM'}</p>
                </div>
                <div className="bg-slate-900/90 p-3 rounded border border-slate-200 dark:border-slate-800">
                  <p className="text-[10px] text-slate-500 uppercase">AUTO APPROVAL</p>
                  <p className="font-bold text-emerald-400 text-sm mt-1">
                    {selectedBooking.autoApprovalEnabled
                      ? `Enabled (${selectedBooking.autoApprovalRule})`
                      : 'Disabled'}
                  </p>
                </div>
              </div>

              {/* Rejection Details Banner if Rejected or Auto Rejected */}
              {(selectedBooking.status === 'REJECTED' || selectedBooking.status === 'AUTO_REJECTED') && (
                <div className="bg-rose-950/30 border border-rose-900/60 p-4 rounded-lg space-y-2 font-mono text-xs">
                  <div className="flex items-center justify-between text-rose-300 font-bold">
                    <span className="flex items-center gap-1.5 uppercase tracking-wider text-[10px]">
                      <XCircle className="w-3.5 h-3.5 text-rose-400" />
                      {selectedBooking.rejectionType === 'AUTO' || selectedBooking.status === 'AUTO_REJECTED'
                        ? 'AUTOMATIC EXPIRATION AUDIT'
                        : 'MANUAL REJECTION AUDIT'}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {formatDisplayDateTime(selectedBooking.rejectedAt || '')}
                    </span>
                  </div>
                  <div className="text-slate-200">
                    <span className="text-slate-400">Reason: </span>
                    <span className="font-semibold text-rose-200">
                      {selectedBooking.rejectionReason || (selectedBooking.status === 'AUTO_REJECTED' ? 'Booking end date and time has passed' : 'Manually rejected by user')}
                    </span>
                  </div>
                </div>
              )}

              {/* Time Window Details */}
              <div className="bg-slate-950/80 p-4 rounded border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="text-[10px] text-slate-400 uppercase font-bold flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-orange-400" /> CURRENT SCHEDULED TIME WINDOW (HH:MM:SS)
                </div>
                <div className="text-white font-bold text-sm font-mono">
                  {formatDisplayDateTime(selectedBooking.startDate)} → {formatDisplayDateTime(selectedBooking.endDate)}
                </div>
              </div>

              {/* SYSTEMATIC WORKFLOW APPROVAL TRAIL & REVIEWER NOTES */}
              {(() => {
                const rawAudit = selectedBooking.auditHistory;
                const auditList: BookingAuditEntry[] = Array.isArray(rawAudit)
                  ? rawAudit
                  : typeof rawAudit === 'string'
                  ? JSON.parse(rawAudit || '[]')
                  : [];

                const approvalEntries = auditList.filter(
                  (a) =>
                    a.field === 'workflow_approval' ||
                    a.field === 'workflow_rejection' ||
                    a.field === 'workflow' ||
                    Boolean(a.comments)
                );

                if (approvalEntries.length === 0 && !selectedBooking.workflowId && selectedBooking.status !== 'PENDING') {
                  return null;
                }

                return (
                  <div className="bg-[#0b1320] border border-slate-700/80 rounded-lg p-4 space-y-3 font-mono text-xs">
                    <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                      <span className="text-[11px] font-bold text-emerald-400 uppercase flex items-center gap-1.5">
                        <ClipboardList className="w-4 h-4 text-emerald-400" />
                        WORKFLOW APPROVAL TRAIL & REVIEWER NOTES
                      </span>
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                        {approvalEntries.length} {approvalEntries.length === 1 ? 'RECORD' : 'RECORDS'}
                      </span>
                    </div>

                    {approvalEntries.length === 0 ? (
                      <div className="text-slate-400 text-xs italic py-2">
                        No reviewer actions recorded yet. Reservation is waiting on Step {selectedBooking.currentWorkflowOrder || 1} approver ({selectedBooking.currentApproverName || 'Designated Approver'}).
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        {approvalEntries.map((entry, idx) => {
                          const isApproved = entry.status === 'APPROVED' || entry.field === 'workflow_approval' || (entry.newValue && entry.newValue.toLowerCase().includes('approved'));
                          const isRejected = entry.status === 'REJECTED' || entry.field === 'workflow_rejection' || (entry.newValue && entry.newValue.toLowerCase().includes('rejected'));
                          
                          return (
                            <div
                              key={entry.id || idx}
                              className={`p-3 rounded-lg border space-y-2 ${
                                isApproved
                                  ? 'bg-emerald-950/20 border-emerald-900/60'
                                  : isRejected
                                  ? 'bg-rose-950/20 border-rose-900/60'
                                  : 'bg-slate-900/60 border-slate-800'
                              }`}
                            >
                              <div className="flex flex-wrap items-center justify-between gap-2">
                                <div className="flex items-center gap-2">
                                  <span
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 ${
                                      isApproved
                                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                        : isRejected
                                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                                    }`}
                                  >
                                    {isApproved ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : isRejected ? <XCircle className="w-3 h-3 text-rose-400" /> : <Clock className="w-3 h-3 text-amber-400" />}
                                    {isApproved ? 'APPROVED' : isRejected ? 'REJECTED' : 'WORKFLOW ACTION'}
                                  </span>
                                  <span className="font-bold text-white text-xs">
                                    {entry.oldValue || `Step ${entry.stepOrder || idx + 1}`}
                                  </span>
                                </div>
                                <span className="text-[10px] text-slate-400">
                                  {formatDisplayDateTime(entry.changedAt)}
                                </span>
                              </div>

                              <div className="text-slate-300 text-xs flex items-center gap-2 flex-wrap">
                                <span className="text-slate-400">Reviewer:</span>
                                <span className="text-white font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                                  {entry.changedBy}
                                </span>
                                {entry.newValue && (
                                  <span className="text-slate-400 text-[11px]">
                                    • {entry.newValue}
                                  </span>
                                )}
                              </div>

                              {/* Dedicated Approval / Reviewer Comment Box */}
                              <div className="bg-[#070c14] border border-slate-700/60 rounded p-2.5 space-y-1">
                                <span className="text-[10px] text-orange-400 font-bold uppercase tracking-wider flex items-center gap-1">
                                  💬 Approver Notes / Comments:
                                </span>
                                <p className="text-xs text-slate-200 font-sans italic pl-1">
                                  {entry.comments && entry.comments.trim() ? `"${entry.comments.trim()}"` : <span className="text-slate-500 font-mono text-[11px]">No comment entered.</span>}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Success feedback after resolution */}
              {resolutionSuccess && (
                <div className="bg-emerald-950/70 border border-emerald-700 p-3.5 rounded text-xs text-emerald-300 flex items-center gap-2 animate-fadeIn font-mono">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="font-bold">{resolutionSuccess}</span>
                </div>
              )}

              {/* CHECK AVAILABILITY RESULTS DISPLAY (DOES NOT AUTO-RESOLVE OR UPDATE BOOKING) */}
              {isCheckingAvailability && availableSlots.length > 0 && (
                <div className="bg-[#0b1424] border border-cyan-500/50 p-4 rounded-lg space-y-3 font-mono text-xs shadow-lg animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
                    <span className="text-[11px] font-bold text-cyan-400 uppercase flex items-center gap-1.5">
                      <Search className="w-3.5 h-3.5 text-cyan-400" /> Discovered Available Slots ({availableSlots.length})
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsCheckingAvailability(false)}
                      className="text-[10px] text-slate-400 hover:text-white"
                    >
                      Close
                    </button>
                  </div>

                  <p className="text-[11px] font-sans text-slate-300">
                    Select an available slot below. <strong className="text-white">No changes will be saved until you click 'Resolve Conflict'.</strong>
                  </p>

                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {availableSlots.map((slot) => {
                      const isSelected = selectedSlot?.id === slot.id;
                      const isAvailable = slot.status === 'AVAILABLE';

                      return (
                        <div
                          key={slot.id}
                          className={`p-3 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all ${
                            isSelected
                              ? 'bg-cyan-950/90 border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                              : isAvailable
                              ? 'bg-slate-900/80 border-slate-200 dark:border-slate-800 hover:border-slate-700'
                              : 'bg-slate-950/50 border-slate-900 opacity-60'
                          }`}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <strong className="text-white text-xs">{slot.displayDate}</strong>
                              <span className="text-orange-400 text-[11px] font-bold">
                                {slot.displayStartTime} → {slot.displayEndTime}
                              </span>
                              <span className="text-[10px] text-slate-400">({slot.durationHours} hrs)</span>
                            </div>
                            <div className="flex items-center gap-2 text-[10px]">
                              <span
                                className={`px-1.5 py-0.5 rounded font-bold ${
                                  isAvailable ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800'
                                }`}
                              >
                                {isAvailable ? 'AVAILABLE' : 'ALREADY BOOKED'}
                              </span>
                              <span className="text-slate-400">{slot.reservationModeCompatibility}</span>
                            </div>
                          </div>

                          {isAvailable && (
                            <button
                              type="button"
                              onClick={() => handleSelectWorklistSlot(slot)}
                              className={`px-3 py-1.5 rounded text-xs font-bold transition-all shrink-0 ${
                                isSelected
                                  ? 'bg-cyan-500 text-black font-extrabold shadow-sm'
                                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                              }`}
                            >
                              {isSelected ? '✓ SLOT SELECTED' : 'SELECT SLOT'}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {selectedSlot && (
                    <div className="bg-cyan-950/60 border border-cyan-800 p-2.5 rounded text-cyan-200 flex items-center justify-between text-xs">
                      <span>
                        Selected: <strong>{selectedSlot.displayDate} ({selectedSlot.displayStartTime} → {selectedSlot.displayEndTime})</strong>
                      </span>
                      <button
                        type="button"
                        onClick={handleStartResolveConflict}
                        className="px-3 py-1 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs transition-colors"
                      >
                        Proceed to Resolve Conflict →
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* DATE & TIME / MODE RESOLUTION INTERFACE */}
              {isResolvingConflict ? (
                <div className="bg-[#161f2e] border-2 border-orange-500/80 rounded-lg p-4 space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-slate-700/80 pb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="p-1.5 rounded bg-orange-950 border border-orange-800 text-orange-400">
                        <Sparkles className="w-4 h-4" />
                      </span>
                      <div>
                        <h4 className="font-bold text-white text-sm">Resolve Reservation Conflict</h4>
                        <p className="text-[11px] text-slate-400">
                          Target Environment: <span className="text-orange-400 font-semibold">{selectedBooking.environmentName}</span>.
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setIsResolvingConflict(false);
                        setResolutionError(null);
                      }}
                      className="text-slate-400 hover:text-white text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
                    >
                      ✕ Cancel
                    </button>
                  </div>

                  {/* Error Banner */}
                  {(resolutionError || isResolveDateOrderInvalid) && (
                    <div className="bg-red-950/90 border-2 border-red-600 rounded p-3 text-red-200 text-xs flex items-center gap-2.5 animate-pulse font-mono">
                      <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                      <span className="font-bold">
                        {isResolveDateOrderInvalid
                          ? 'Start date time is greater than the end date time.'
                          : resolutionError}
                      </span>
                    </div>
                  )}

                  {/* RESOLUTION METHOD TOGGLE */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div
                      onClick={() => setResolutionOption('DATE_TIME')}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        resolutionOption === 'DATE_TIME'
                          ? 'bg-orange-950/80 border-orange-500 text-white shadow-[0_0_12px_rgba(249,115,22,0.3)]'
                          : 'bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-xs font-mono flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-orange-400" /> Option A – Change Date/Time
                        </span>
                        {resolutionOption === 'DATE_TIME' && <CheckCircle2 className="w-4 h-4 text-orange-400" />}
                      </div>
                      <p className="text-[10px] text-slate-400 font-sans leading-tight">
                        Shift window to non-conflicting available slot.
                      </p>
                    </div>

                    <div
                      onClick={() => setResolutionOption('MODE_CHANGE')}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        resolutionOption === 'MODE_CHANGE'
                          ? 'bg-cyan-950/80 border-cyan-500 text-white shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                          : 'bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-xs font-mono flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-cyan-400" /> Option B – Disruptive → Shared
                        </span>
                        {resolutionOption === 'MODE_CHANGE' && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                      </div>
                      <p className="text-[10px] text-slate-400 font-sans leading-tight">
                        Convert to Shared mode for non-interfering co-existence.
                      </p>
                    </div>
                  </div>

                  {resolutionOption === 'DATE_TIME' && (
                    <div className="space-y-3 bg-black/40 p-3 rounded border border-slate-200 dark:border-slate-800 font-mono">
                      {selectedSlot && (
                        <div className="bg-cyan-950/60 border border-cyan-800 p-2.5 rounded text-xs text-cyan-200">
                          <strong className="block text-white mb-0.5">Using Discovered Available Slot:</strong>
                          <span>{selectedSlot.displayDate} ({selectedSlot.displayStartTime} → {selectedSlot.displayEndTime})</span>
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <DateTimePicker
                          label="NEW START DATE & TIME"
                          subLabel="HH:MM:SS"
                          required
                          value={resolveStartDate}
                          onChange={(val) => {
                            setResolveStartDate(val);
                            setResolutionError(null);
                          }}
                        />

                        <DateTimePicker
                          label="NEW END DATE & TIME"
                          subLabel="HH:MM:SS"
                          required
                          value={resolveEndDate}
                          onChange={(val) => {
                            setResolveEndDate(val);
                            setResolutionError(null);
                          }}
                        />
                      </div>
                    </div>
                  )}

                  {resolutionOption === 'MODE_CHANGE' && (
                    <div className="bg-cyan-950/40 border border-cyan-800/80 p-3.5 rounded text-xs text-cyan-200 space-y-2 font-mono">
                      <span className="font-bold block text-white">Convert Reservation Mode to SHARED</span>
                      <p className="text-[11px] text-slate-300 font-sans">
                        Changing mode from <strong className="text-amber-400">DISRUPTIVE</strong> to <strong className="text-cyan-300">SHARED</strong> removes exclusive control requirements and permits co-existence with other shared reservations.
                      </p>
                    </div>
                  )}

                  {/* AI BOOKING INTELLIGENCE CARD IN RESOLUTION DRAWER */}
                  {resolveAiAssistResult && (
                    <div className="bg-[#0b1320] border border-orange-500/50 rounded-lg p-3.5 space-y-2.5 text-xs font-mono shadow-[0_0_15px_rgba(249,115,22,0.15)]">
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 font-bold text-orange-400">
                          <BrainCircuit className="w-4 h-4 text-orange-400" /> AI BOOKING INTELLIGENCE
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            resolveAiAssistResult.prediction.riskLevel === 'VERY_HIGH'
                              ? 'bg-red-950 text-red-400 border border-red-800'
                              : resolveAiAssistResult.prediction.riskLevel === 'HIGH'
                              ? 'bg-orange-950 text-orange-400 border border-orange-800'
                              : resolveAiAssistResult.prediction.riskLevel === 'MEDIUM'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          }`}
                        >
                          RISK: {resolveAiAssistResult.prediction.riskLevel} ({resolveAiAssistResult.prediction.conflictProbability}%)
                        </span>
                      </div>

                      {/* Explanations */}
                      <div className="space-y-1 bg-black/40 p-2 rounded border border-slate-200 dark:border-slate-800 text-[11px]">
                        {resolveAiAssistResult.prediction.explanations.map((exp) => (
                          <div key={exp.id} className="flex items-start gap-1.5 text-slate-300">
                            <span className="text-orange-400 shrink-0">•</span>
                            <span>
                              <strong className="text-white">{exp.title}:</strong> {exp.detail}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Recommended Alternatives */}
                      {resolveAiAssistResult.recommendations.length > 0 && (
                        <div className="space-y-1.5 pt-1 border-t border-slate-200 dark:border-slate-800">
                          <span className="text-[10px] text-emerald-400 font-bold uppercase flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-emerald-400" /> RECOMMENDED ALTERNATIVES (LOWER CONFLICT RISK)
                          </span>

                          <div className="space-y-1.5">
                            {resolveAiAssistResult.recommendations.map((rec) => (
                              <div
                                key={rec.environmentId}
                                className="bg-slate-900/90 p-2 rounded border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 hover:border-slate-700 transition-colors"
                              >
                                <div className="min-w-0 flex-1">
                                  <div className="flex items-center gap-2">
                                    <strong className="text-white text-xs truncate">{rec.environmentName}</strong>
                                    <span className="text-[10px] text-emerald-400 font-bold">{rec.compatibilityScore}% MATCH</span>
                                  </div>
                                  <p className="text-[10px] text-slate-400 truncate">{rec.reasoning}</p>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setBookingToEdit({
                                      ...selectedBooking,
                                      environmentId: rec.environmentId,
                                      environmentName: rec.environmentName,
                                      startDate: resolveStartDate,
                                      endDate: resolveEndDate,
                                    });
                                    setIsBookingModalOpen(true);
                                    showToast(`Configuring reservation on recommended environment: ${rec.environmentName}`, 'success');
                                  }}
                                  className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] shrink-0 flex items-center gap-1 transition-colors"
                                >
                                  USE THIS <ArrowRight className="w-3 h-3" />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Conflict Resolution Actions */}
                  <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-700/60 font-mono">
                    <button
                      type="button"
                      onClick={() => {
                        setIsResolvingConflict(false);
                        setResolutionError(null);
                      }}
                      className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors"
                    >
                      BACK
                    </button>
                    <button
                      type="button"
                      disabled={isResolveDateOrderInvalid}
                      onClick={handleResolveConflictSubmit}
                      className="px-5 py-2 rounded bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white text-xs font-bold shadow-[0_0_14px_rgba(249,115,22,0.5)] flex items-center gap-1.5 transition-colors uppercase"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> CONFIRM RESOLUTION & SAVE
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* Conflict details if any */}
                  {conflictMap.has(selectedBooking.id) && selectedBooking.status !== 'CANCELLED' && selectedBooking.status !== 'REJECTED' && selectedBooking.status !== 'AUTO_REJECTED' && (
                    <div className="bg-red-950/40 border border-red-800 p-3.5 rounded space-y-2.5">
                      <p className="text-xs font-bold text-red-400 flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-red-400" /> Overlaps With The Following Bookings:
                      </p>
                      <div className="space-y-1.5">
                        {conflictMap.get(selectedBooking.id)?.map((cb) => (
                          <div
                            key={cb.id}
                            className="bg-black/50 p-2.5 rounded border border-red-900 text-[11px] text-slate-200 flex justify-between items-center"
                          >
                            <div>
                              <p className="font-bold text-white">{cb.purpose} ({cb.businessUnit} - {cb.application})</p>
                              <p className="text-red-300 text-[10px]">
                                {formatDisplayDateTime(cb.startDate)} → {formatDisplayDateTime(cb.endDate)}
                              </p>
                            </div>
                            <span className="text-slate-400">{cb.requestedBy}</span>
                          </div>
                        ))}
                      </div>
                      <div className="bg-amber-950/70 border border-amber-600/90 p-3 rounded text-xs text-amber-200 flex items-center gap-2.5">
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                        <div>
                          <strong className="text-amber-300 block font-bold">Conflict Resolution Required</strong>
                          <span>Please resolve the schedule conflict first before approving this reservation.</span>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* FIXED STICKY FOOTER ACTIONS */}
            <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 z-10">
              {(() => {
                const isModalInactive = selectedBooking.status === 'CANCELLED' || selectedBooking.status === 'REJECTED' || selectedBooking.status === 'AUTO_REJECTED';
                const hasModalConflict = conflictMap.has(selectedBooking.id);
                return (
                  <div className="flex flex-wrap items-center gap-2">
                    {!isModalInactive && selectedBooking.status === 'PENDING' && (
                      <>
                        {isCurrentApprover(selectedBooking) && (
                          <>
                            <button
                              disabled={hasModalConflict}
                              onClick={() => {
                                if (hasModalConflict) {
                                  showToast('Please resolve the schedule conflict first before approving this reservation.', 'error');
                                  return;
                                }
                                setBookingToApprove(selectedBooking);
                                setApproveComments('');
                              }}
                              title={hasModalConflict ? "Please resolve the schedule conflict first before approving this reservation." : "Approve Reservation"}
                              className={`px-3.5 py-2 rounded text-xs font-bold border transition-colors flex items-center gap-1.5 shrink-0 ${
                                hasModalConflict
                                  ? 'bg-slate-900 text-slate-600 border-slate-800 cursor-not-allowed opacity-50 shadow-none'
                                  : 'bg-emerald-950 hover:bg-emerald-700 text-emerald-300 hover:text-white border-emerald-700 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                              }`}
                            >
                              <Check className="w-3.5 h-3.5" /> APPROVE RESERVATION
                            </button>
                            <button
                              onClick={() => {
                                setBookingToReject(selectedBooking);
                                setRejectReason('');
                              }}
                              className="px-3.5 py-2 rounded bg-rose-950 hover:bg-rose-800 text-rose-200 text-xs font-bold border border-rose-700 transition-colors flex items-center gap-1.5 shrink-0"
                            >
                              <XCircle className="w-3.5 h-3.5" /> REJECT RESERVATION
                            </button>
                          </>
                        )}
                        {isCreator(selectedBooking) && (
                          <button
                            onClick={() => {
                              setBookingToCancel(selectedBooking);
                            }}
                            className="px-3.5 py-2 rounded bg-red-900/60 hover:bg-red-700 text-red-200 text-xs font-bold border border-red-700 transition-colors flex items-center gap-1.5 shrink-0"
                          >
                            <Ban className="w-3.5 h-3.5" /> CANCEL THIS RESERVATION
                          </button>
                        )}
                      </>
                    )}

                    {!isModalInactive && selectedBooking.status !== 'PENDING' && (
                      <>
                        <button
                          onClick={() => {
                            setBookingToEdit(selectedBooking);
                            setIsBookingModalOpen(true);
                          }}
                          className="px-3.5 py-2 rounded bg-slate-800 hover:bg-orange-600 text-orange-400 hover:text-white text-xs font-bold border border-slate-700 transition-colors flex items-center gap-1.5 shrink-0"
                        >
                          <Edit3 className="w-3.5 h-3.5" /> EDIT RESERVATION
                        </button>
                        {isSuperAdmin && (
                          <button
                            onClick={() => {
                              setBookingToReject(selectedBooking);
                              setRejectReason('');
                            }}
                            className="px-3.5 py-2 rounded bg-rose-950 hover:bg-rose-800 text-rose-200 text-xs font-bold border border-rose-700 transition-colors flex items-center gap-1.5 shrink-0"
                          >
                            <XCircle className="w-3.5 h-3.5" /> REJECT THIS RESERVATION
                          </button>
                        )}
                        {isCreator(selectedBooking) && (
                          <button
                            onClick={() => {
                              setBookingToCancel(selectedBooking);
                            }}
                            className="px-3.5 py-2 rounded bg-red-900/60 hover:bg-red-700 text-red-200 text-xs font-bold border border-red-700 transition-colors flex items-center gap-1.5 shrink-0"
                          >
                            <Ban className="w-3.5 h-3.5" /> CANCEL THIS RESERVATION
                          </button>
                        )}
                      </>
                    )}
                    {!isModalInactive && conflictMap.has(selectedBooking.id) && !isResolvingConflict && (
                      <>
                        <button
                          onClick={handleWorklistCheckAvailability}
                          className="px-3.5 py-2 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 text-xs font-bold border border-cyan-700 transition-colors flex items-center gap-1.5 shrink-0"
                        >
                          <Search className="w-3.5 h-3.5 text-cyan-400" /> CHECK AVAILABILITY
                        </button>
                        <button
                          onClick={handleStartResolveConflict}
                          className="px-3.5 py-2 rounded bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)] flex items-center gap-1.5 shrink-0"
                        >
                          <Sparkles className="w-3.5 h-3.5" /> RESOLVE CONFLICT
                        </button>
                      </>
                    )}
                  </div>
                );
              })()}
              <button
                onClick={() => {
                  setSelectedBooking(null);
                  setIsResolvingConflict(false);
                  setIsCheckingAvailability(false);
                }}
                className="px-5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors shrink-0 ml-auto"
              >
                CLOSE
              </button>
            </div>
          </div>
        </div>
      )}

      {/* APPROVE RESERVATION CONFIRMATION MODAL */}
      {bookingToApprove && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-emerald-900/70 rounded-2xl max-w-lg w-full font-mono relative shadow-[0_0_50px_rgba(16,185,129,0.25)] max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-4 border-b border-slate-200 dark:border-slate-800 bg-[#0f1724] relative z-10">
              <button
                onClick={() => setBookingToApprove(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white text-lg transition-colors"
              >
                ✕
              </button>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-emerald-950/90 border border-emerald-800/90 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <span className="text-[11px] font-mono font-bold text-emerald-400 tracking-wider uppercase block">
                    WORKFLOW STEP APPROVAL
                  </span>
                  <h3 className="text-xl font-bold text-white leading-snug mt-1 font-mono">
                    Approve Reservation Request
                  </h3>
                </div>
              </div>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
              {/* Inner Details Card */}
              <div className="bg-[#070b12] border border-slate-200 dark:border-slate-800/90 rounded-lg p-4 space-y-2 text-xs font-mono">
                <h4 className="text-sm font-bold text-white tracking-wide">
                  &quot;{bookingToApprove.purpose}&quot;
                </h4>
                <p className="text-slate-400">
                  Environment: <span className="text-orange-400 font-bold">{bookingToApprove.environmentName}</span>
                </p>
                <p className="text-slate-400">
                  Requested By: <span className="text-white font-bold">{bookingToApprove.requestedBy}</span>
                </p>
                <p className="text-slate-400">
                  Step Order: <span className="text-amber-400 font-bold">Step {bookingToApprove.currentWorkflowOrder || 1}</span>
                </p>
                <p className="text-orange-300 font-bold flex items-center gap-1.5 pt-1">
                  <span>⏱️</span>
                  <span>
                    {formatDisplayDateTime(bookingToApprove.startDate)} → {formatDisplayDateTime(bookingToApprove.endDate)}
                  </span>
                </p>
              </div>

              {/* Comments Textarea */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                  Approval Notes / Comments (Optional)
                </label>
                <textarea
                  value={approveComments}
                  onChange={(e) => setApproveComments(e.target.value)}
                  placeholder="Add optional reviewer comments or verification notes..."
                  rows={3}
                  className="w-full bg-[#162032] border border-slate-700/80 rounded-lg p-3 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 transition-colors font-mono"
                />
              </div>

              {/* Conflict Guard Alert */}
              {conflictMap.has(bookingToApprove.id) && (
                <div className="bg-amber-950/70 border border-amber-600/90 p-3 rounded text-xs text-amber-200 flex items-center gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <strong className="text-amber-300 block font-bold">Conflict Resolution Required</strong>
                    <span>This reservation has an active schedule conflict. Please resolve the conflict first to approve.</span>
                  </div>
                </div>
              )}

              {/* Explanation Note */}
              <p className="text-xs text-slate-400 font-mono leading-relaxed pt-1">
                Your approval will be recorded in the audit history and the workflow will either progress to the next approver or finalize the reservation.
              </p>
            </div>

            {/* Fixed Sticky Footer */}
            <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center gap-3 z-10">
              <button
                type="button"
                onClick={() => setBookingToApprove(null)}
                disabled={isApproving}
                className="w-1/2 py-3 rounded-lg bg-[#162032] hover:bg-slate-700 text-slate-300 hover:text-white font-mono font-bold text-xs uppercase tracking-wider border border-slate-700/60 transition-colors disabled:opacity-50"
              >
                CANCEL
              </button>
              <ButtonLoader
                type="button"
                isLoading={isApproving}
                disabled={conflictMap.has(bookingToApprove.id)}
                loadingText="APPROVING..."
                onClick={handleConfirmApprove}
                className={`w-1/2 py-3 rounded-lg font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all ${
                  conflictMap.has(bookingToApprove.id)
                    ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-50 shadow-none'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]'
                }`}
              >
                <Check className="w-4 h-4" /> YES, APPROVE
              </ButtonLoader>
            </div>
          </div>
        </div>
      )}

      {/* REJECT RESERVATION CONFIRMATION MODAL */}
      {bookingToReject && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-rose-900/70 rounded-2xl max-w-lg w-full font-mono relative shadow-[0_0_50px_rgba(225,29,72,0.25)] max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-4 border-b border-slate-200 dark:border-slate-800 bg-[#0f1724] relative z-10">
              <button
                onClick={() => setBookingToReject(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white text-lg transition-colors"
              >
                ✕
              </button>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-rose-950/90 border border-rose-800/90 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
                  <XCircle className="w-6 h-6 text-rose-500" />
                </div>
                <div>
                  <span className="text-[11px] font-mono font-bold text-rose-400 tracking-wider uppercase block">
                    CONFIRM REJECTION
                  </span>
                  <h3 className="text-xl font-bold text-white leading-snug mt-1 font-mono">
                    Are you sure you want to reject this reservation?
                  </h3>
                </div>
              </div>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
              {/* Inner Details Card */}
              <div className="bg-[#070b12] border border-slate-200 dark:border-slate-800/90 rounded-lg p-4 space-y-2 text-xs font-mono">
                <h4 className="text-sm font-bold text-white tracking-wide">
                  &quot;{bookingToReject.purpose}&quot;
                </h4>
                <p className="text-slate-400">
                  Environment: <span className="text-orange-400 font-bold">{bookingToReject.environmentName}</span>
                </p>
                <p className="text-slate-400">
                  BU: <span className="text-white font-bold">{bookingToReject.businessUnit}</span> <span className="text-slate-600">|</span> App: <span className="text-white font-bold">{bookingToReject.application}</span>
                </p>
                <p className="text-orange-300 font-bold flex items-center gap-1.5 pt-1">
                  <span>⏱️</span>
                  <span>
                    {formatDisplayDateTime(bookingToReject.startDate)} → {formatDisplayDateTime(bookingToReject.endDate)}
                  </span>
                </p>
              </div>

              {/* Reason Textarea */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                  Rejection Reason
                </label>
                <textarea
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  placeholder="Specify the reason for rejecting this reservation (e.g. Schedule priority change, SEV1 incident remediation)..."
                  rows={3}
                  className="w-full bg-[#162032] border border-slate-700/80 rounded-lg p-3 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-rose-500 transition-colors font-mono"
                />
              </div>

              {/* Explanation Note */}
              <p className="text-xs text-slate-400 font-mono leading-relaxed pt-1">
                This will update the reservation status to <strong className="text-rose-400">Rejected</strong> with full audit history and free up the environment slot for all other teams.
              </p>
            </div>

            {/* Fixed Sticky Footer */}
            <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center gap-3 z-10">
              <button
                type="button"
                onClick={() => setBookingToReject(null)}
                disabled={isRejecting}
                className="w-1/2 py-3 rounded-lg bg-[#162032] hover:bg-slate-700 text-slate-300 hover:text-white font-mono font-bold text-xs uppercase tracking-wider border border-slate-700/60 transition-colors disabled:opacity-50"
              >
                NO, KEEP IT
              </button>
              <ButtonLoader
                type="button"
                isLoading={isRejecting}
                loadingText="REJECTING..."
                onClick={handleConfirmReject}
                className="w-1/2 py-3 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(225,29,72,0.4)] transition-all"
              >
                <XCircle className="w-4 h-4" /> YES, REJECT
              </ButtonLoader>
            </div>
          </div>
        </div>
      )}

      {/* CANCEL RESERVATION CONFIRMATION MODAL */}
      {bookingToCancel && (
        <div className="fixed inset-0 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#0f1724] border border-red-900/60 rounded-2xl max-w-lg w-full font-mono relative shadow-[0_0_50px_rgba(239,68,68,0.2)] max-h-[90vh] flex flex-col overflow-hidden">
            {/* Fixed Header */}
            <div className="shrink-0 p-6 pb-4 border-b border-slate-200 dark:border-slate-800 bg-[#0f1724] relative z-10">
              <button
                onClick={() => setBookingToCancel(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white text-lg transition-colors"
              >
                ✕
              </button>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-red-950/90 border border-red-800/90 flex items-center justify-center text-red-400 shrink-0 mt-0.5">
                  <AlertTriangle className="w-6 h-6 text-red-500" />
                </div>
                <div>
                  <span className="text-[11px] font-mono font-bold text-red-400 tracking-wider uppercase block">
                    CONFIRM CANCELLATION
                  </span>
                  <h3 className="text-xl font-bold text-white leading-snug mt-1 font-mono">
                    Are you sure you want to cancel this reservation?
                  </h3>
                </div>
              </div>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
              {/* Inner Details Card */}
              <div className="bg-[#070b12] border border-slate-200 dark:border-slate-800/90 rounded-lg p-4 space-y-2 text-xs font-mono">
                <h4 className="text-sm font-bold text-white tracking-wide">
                  &quot;{bookingToCancel.purpose}&quot;
                </h4>
                <p className="text-slate-400">
                  Environment: <span className="text-orange-400 font-bold">{bookingToCancel.environmentName}</span>
                </p>
                <p className="text-slate-400">
                  BU: <span className="text-white font-bold">{bookingToCancel.businessUnit}</span> <span className="text-slate-600">|</span> App: <span className="text-white font-bold">{bookingToCancel.application}</span>
                </p>
                <p className="text-orange-300 font-bold flex items-center gap-1.5 pt-1">
                  <span>⏱️</span>
                  <span>
                    {formatDisplayDateTime(bookingToCancel.startDate)} → {formatDisplayDateTime(bookingToCancel.endDate)}
                  </span>
                </p>
              </div>

              {/* Explanation Note */}
              <p className="text-xs text-slate-400 font-mono leading-relaxed pt-1">
                This action will release the reserved time slot and immediately update schedule availability for all teams.
              </p>
            </div>

            {/* Fixed Sticky Footer */}
            <div className="shrink-0 p-4 bg-[#0f1724] border-t border-slate-200 dark:border-slate-800 flex items-center gap-3 z-10">
              <button
                type="button"
                onClick={() => setBookingToCancel(null)}
                disabled={isCancelling}
                className="w-1/2 py-3 rounded-lg bg-[#162032] hover:bg-slate-700 text-slate-300 hover:text-white font-mono font-bold text-xs uppercase tracking-wider border border-slate-700/60 transition-colors disabled:opacity-50"
              >
                NO, KEEP IT
              </button>
              <ButtonLoader
                type="button"
                isLoading={isCancelling}
                loadingText="CANCELLING..."
                onClick={handleConfirmCancel}
                className="w-1/2 py-3 rounded-lg bg-red-600 hover:bg-red-500 text-white font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(239,68,68,0.4)] transition-all"
              >
                <Ban className="w-4 h-4" /> YES, CANCEL
              </ButtonLoader>
            </div>
          </div>
        </div>
      )}

      {/* CREATE / EDIT BOOKING MODAL */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => {
          setIsBookingModalOpen(false);
          setBookingToEdit(null);
        }}
        editingBooking={bookingToEdit}
      />
    </div>
  );
};
