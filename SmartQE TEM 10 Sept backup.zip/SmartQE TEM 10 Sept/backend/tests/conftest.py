import asyncio
import pytest
import pytest_asyncio
from typing import AsyncGenerator, Optional
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from app.main import app
from app.database.base import Base
from app.database.session import get_db

# Async SQLite in-memory database for fast unit testing
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"

test_engine = create_async_engine(TEST_DATABASE_URL, echo=False)
TestingSessionLocal = async_sessionmaker(bind=test_engine, class_=AsyncSession, expire_on_commit=False)


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="function")
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    from app.utils.seed_data import seed_initial_data
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with TestingSessionLocal() as session:
        await seed_initial_data(session)
        yield session
        await session.rollback()

    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest_asyncio.fixture(scope="function")
async def client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    from fastapi import Request, Depends
    from fastapi.security import HTTPAuthorizationCredentials

    from app.dao.user_dao import user_dao
    from app.dependencies.auth import (
        get_current_user_optional, get_current_user,
        oauth2_scheme, security_bearer,
        extract_raw_token, resolve_session_and_user
    )

    async def _override_get_db():
        yield db_session

    async def _override_get_current_user(
        request: Request,
        db: AsyncSession = Depends(_override_get_db),
        oauth_token: Optional[str] = Depends(oauth2_scheme),
        bearer_creds: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer)
    ):
        token = extract_raw_token(request, oauth_token, bearer_creds)
        if token:
            user, _ = await resolve_session_and_user(request, db, token)
            return user
        admin_user = await user_dao.get_by_username(db, "admin")
        return admin_user

    async def _override_get_current_user_optional(
        request: Request,
        db: AsyncSession = Depends(_override_get_db),
        oauth_token: Optional[str] = Depends(oauth2_scheme),
        bearer_creds: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer)
    ):
        token = extract_raw_token(request, oauth_token, bearer_creds)
        if token:
            user, _ = await resolve_session_and_user(request, db, token)
            return user
        admin_user = await user_dao.get_by_username(db, "admin")
        return admin_user

    app.dependency_overrides[get_db] = _override_get_db
    app.dependency_overrides[get_current_user] = _override_get_current_user
    app.dependency_overrides[get_current_user_optional] = _override_get_current_user_optional

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.clear()


