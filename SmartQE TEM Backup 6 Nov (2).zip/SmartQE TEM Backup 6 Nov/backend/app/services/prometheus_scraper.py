import re
import time
from typing import List, Dict, Any, Tuple, Optional
import httpx

from app.core.logging import logger


class PrometheusMetricSample:
    """Represents a single parsed Prometheus time-series metric sample."""
    def __init__(self, name: str, labels: Dict[str, str], value: float, timestamp: Optional[float] = None):
        self.name = name
        self.labels = labels
        self.value = value
        self.timestamp = timestamp or time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "labels": self.labels,
            "value": self.value,
            "timestamp": self.timestamp
        }


class PrometheusScraperService:
    """
    Enterprise Prometheus Pull-Based Metrics Scraper & Exposition Engine.
    Strictly parses and extracts real Prometheus / OpenMetrics exposition text.
    Zero synthetic or simulated fallbacks.
    """

    METRIC_LINE_REGEX = re.compile(
        r'^(?P<name>[a-zA-Z_:][a-zA-Z0-9_:]*)'
        r'(?:\{(?P<labels>[^}]*)\})?'
        r'\s+(?P<value>[+-]?(?:(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|NaN|[+-]?Inf))'
        r'(?:\s+(?P<timestamp>\d+))?'
    )
    LABEL_REGEX = re.compile(r'([a-zA-Z_][a-zA-Z0-9_]*)=(?:"([^"\\]*(?:\\.[^"\\]*)*)")')

    @classmethod
    def parse_prometheus_text(cls, text: str) -> List[PrometheusMetricSample]:
        """
        Parses Prometheus / OpenMetrics text exposition format into structured samples.
        Robustly handles comments (# HELP, # TYPE), quotes, escaped characters, and scientific notation.
        """
        samples: List[PrometheusMetricSample] = []
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            match = cls.METRIC_LINE_REGEX.match(line)
            if not match:
                continue

            name = match.group("name")
            val_str = match.group("value")
            labels_raw = match.group("labels")
            ts_str = match.group("timestamp")

            # Parse value
            try:
                if val_str.lower() == "nan":
                    val = 0.0
                elif val_str.lower() in ["inf", "+inf"]:
                    val = float("inf")
                elif val_str.lower() == "-inf":
                    val = float("-inf")
                else:
                    val = float(val_str)
            except ValueError:
                continue

            # Parse labels
            labels: Dict[str, str] = {}
            if labels_raw:
                for lbl_match in cls.LABEL_REGEX.finditer(labels_raw):
                    k, v = lbl_match.group(1), lbl_match.group(2)
                    labels[k] = v.replace(r'\"', '"').replace(r'\n', '\n').replace(r'\\', '\\')

            timestamp = float(ts_str) / 1000.0 if ts_str else None
            samples.append(PrometheusMetricSample(name=name, labels=labels, value=val, timestamp=timestamp))

        return samples

    @classmethod
    def extract_normalized_metrics(cls, samples: List[PrometheusMetricSample], target_type: str = "DATABASE") -> Dict[str, float]:
        """
        Extracts metrics only from actual parsed samples.
        Does not return hardcoded values for missing metrics.
        """
        metrics: Dict[str, float] = {}
        sample_map: Dict[str, List[PrometheusMetricSample]] = {}
        for s in samples:
            sample_map.setdefault(s.name, []).append(s)

        # 1. SQLite Database Metrics
        if "sqlite_database_up" in sample_map:
            metrics["DATABASE_UP"] = float(sample_map["sqlite_database_up"][0].value)
        if "sqlite_database_size_bytes" in sample_map:
            metrics["DATABASE_SIZE_BYTES"] = float(sample_map["sqlite_database_size_bytes"][0].value)
        if "sqlite_database_used_bytes" in sample_map:
            metrics["DATABASE_USED_BYTES"] = float(sample_map["sqlite_database_used_bytes"][0].value)
        if "sqlite_database_tables_total" in sample_map:
            metrics["DATABASE_TABLES_TOTAL"] = float(sample_map["sqlite_database_tables_total"][0].value)
        if "sqlite_database_query_duration_seconds" in sample_map:
            metrics["DATABASE_QUERY_DURATION"] = float(sample_map["sqlite_database_query_duration_seconds"][0].value)
        if "sqlite_database_wal_size_bytes" in sample_map:
            metrics["DATABASE_WAL_SIZE_BYTES"] = float(sample_map["sqlite_database_wal_size_bytes"][0].value)
        if "sqlite_database_page_count" in sample_map:
            metrics["DATABASE_PAGE_COUNT"] = float(sample_map["sqlite_database_page_count"][0].value)
        if "sqlite_table_rows_total" in sample_map:
            metrics["TOTAL_TABLE_ROWS"] = float(sum(s.value for s in sample_map["sqlite_table_rows_total"]))

        # 2. General Target / Exporter Health
        if "up" in sample_map:
            metrics["UP"] = float(sample_map["up"][0].value)
        if "scrape_duration_seconds" in sample_map:
            metrics["SCRAPE_DURATION"] = float(sample_map["scrape_duration_seconds"][0].value)

        # 3. CPU Utilization (%)
        if "node_cpu_seconds_total" in sample_map:
            idle_samples = [s.value for s in sample_map["node_cpu_seconds_total"] if s.labels.get("mode") == "idle"]
            total_samples = [s.value for s in sample_map["node_cpu_seconds_total"]]
            if total_samples and idle_samples:
                metrics["CPU"] = round(max(0.0, min(100.0, 100.0 - (sum(idle_samples) / max(1.0, sum(total_samples)) * 100.0))), 1)
        elif "process_cpu_usage" in sample_map:
            metrics["CPU"] = round(sample_map["process_cpu_usage"][0].value * 100.0, 1)
        elif "cpu_utilization" in sample_map:
            metrics["CPU"] = round(sample_map["cpu_utilization"][0].value, 1)

        # 4. Memory Utilization (%)
        if "node_memory_MemTotal_bytes" in sample_map and "node_memory_MemAvailable_bytes" in sample_map:
            total = sample_map["node_memory_MemTotal_bytes"][0].value
            avail = sample_map["node_memory_MemAvailable_bytes"][0].value
            if total > 0:
                metrics["MEMORY"] = round(max(0.0, min(100.0, ((total - avail) / total) * 100.0)), 1)
        elif "memory_utilization" in sample_map:
            metrics["MEMORY"] = round(sample_map["memory_utilization"][0].value, 1)

        # 5. Disk Storage Utilization (%)
        if "node_filesystem_size_bytes" in sample_map and "node_filesystem_avail_bytes" in sample_map:
            total_disk = sum(s.value for s in sample_map["node_filesystem_size_bytes"] if s.labels.get("mountpoint") in ["/", "/data", "C:"])
            avail_disk = sum(s.value for s in sample_map["node_filesystem_avail_bytes"] if s.labels.get("mountpoint") in ["/", "/data", "C:"])
            if total_disk > 0:
                metrics["DISK"] = round(max(0.0, min(100.0, ((total_disk - avail_disk) / total_disk) * 100.0)), 1)
        elif "disk_utilization" in sample_map:
            metrics["DISK"] = round(sample_map["disk_utilization"][0].value, 1)

        # 6. Response Time & Error Rate (ms / %)
        if "http_server_requests_seconds_sum" in sample_map and "http_server_requests_seconds_count" in sample_map:
            total_time = sum(s.value for s in sample_map["http_server_requests_seconds_sum"])
            total_reqs = sum(s.value for s in sample_map["http_server_requests_seconds_count"])
            if total_reqs > 0:
                metrics["LATENCY"] = round((total_time / total_reqs) * 1000.0, 1)
        elif "http_response_time_ms" in sample_map:
            metrics["LATENCY"] = round(sample_map["http_response_time_ms"][0].value, 1)

        if "http_server_requests_seconds_count" in sample_map:
            err_reqs = sum(s.value for s in sample_map["http_server_requests_seconds_count"] if str(s.labels.get("status", "")).startswith(("4", "5")))
            all_reqs = sum(s.value for s in sample_map["http_server_requests_seconds_count"])
            if all_reqs > 0:
                metrics["ERROR_RATE"] = round((err_reqs / all_reqs) * 100.0, 2)
        elif "http_error_rate_pct" in sample_map:
            metrics["ERROR_RATE"] = round(sample_map["http_error_rate_pct"][0].value, 2)

        return metrics

    async def scrape_endpoint(
        self,
        endpoint_url: str,
        target_name: str,
        target_type: str = "DATABASE",
        timeout_seconds: int = 5,
        retry_count: int = 1
    ) -> Tuple[bool, str, str, float, Dict[str, float], List[PrometheusMetricSample]]:
        """
        Executes HTTP/HTTPS pull-based metrics scrape directly against the specified endpoint.
        Returns:
            (success: bool, status_code: str, message: str, duration_ms: float, normalized_metrics: dict, samples: list)
        Strictly returns failure if unreachable. No simulated data.
        """
        start_time = time.perf_counter()
        last_error = None

        for attempt in range(max(1, retry_count + 1)):
            try:
                async with httpx.AsyncClient(timeout=timeout_seconds, verify=False, follow_redirects=True) as client:
                    resp = await client.get(endpoint_url, headers={"Accept": "text/plain;version=0.0.4, text/plain; q=0.5, */*; q=0.1"})
                    elapsed_ms = round((time.perf_counter() - start_time) * 1000, 1)

                    if resp.status_code == 200:
                        samples = self.parse_prometheus_text(resp.text)
                        normalized = self.extract_normalized_metrics(samples, target_type)
                        return True, "SUCCESS", f"Scraped {len(samples)} metrics from {target_name} ({elapsed_ms}ms)", elapsed_ms, normalized, samples
                    elif resp.status_code in [404, 502, 503]:
                        return False, "EXPORTER_DOWN", f"EXPORTER DOWN: Endpoint returned HTTP {resp.status_code}", elapsed_ms, {}, []
                    else:
                        return False, "FAILURE", f"SCRAPE FAILURE: Target responded with HTTP {resp.status_code}", elapsed_ms, {}, []

            except (httpx.ConnectError, httpx.NetworkError) as exc:
                last_error = exc
            except httpx.TimeoutException:
                elapsed_ms = round((time.perf_counter() - start_time) * 1000, 1)
                return False, "TIMEOUT", f"SCRAPE TIMEOUT: Request exceeded {timeout_seconds}s limit", elapsed_ms, {}, []
            except Exception as exc:
                last_error = exc
                break

        elapsed_ms = round((time.perf_counter() - start_time) * 1000, 1)
        err_detail = str(last_error) if last_error else "Connection refused"
        return False, "TARGET_DOWN", f"SCRAPE FAILED: Unable to reach {target_name} at {endpoint_url} ({err_detail})", elapsed_ms, {}, []


prometheus_scraper = PrometheusScraperService()
