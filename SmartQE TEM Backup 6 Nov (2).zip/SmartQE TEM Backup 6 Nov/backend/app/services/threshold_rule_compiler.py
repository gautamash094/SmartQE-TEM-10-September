import os
import shutil
import yaml
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import logger
from app.models.monitoring import MonitoringThresholdRule
from app.adapters.monitoring.prometheus_client import prometheus_client


class ThresholdRuleCompiler:
    """
    Compiles configured server and environment threshold rules from the database
    into standard PromQL alert rule YAML format, syncs configuration files, and
    triggers Prometheus hot reload via the Prometheus lifecycle API.
    """

    PROMETHEUS_DIRS = [
        r"C:\Users\GenAILUCKAWPUSR5\Downloads\prometheus-3.15.1.windows-amd64\prometheus-3.15.1.windows-amd64",
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "monitoring"))
    ]

    BASE_ALERT_RULES_PATH = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "..", "monitoring", "alert_rules.yml")
    )

    def _sanitize_alert_name(self, name: str) -> str:
        """Sanitizes rule name to adhere to Prometheus alert naming standards (alphanumeric & underscore)."""
        clean = "".join([c if c.isalnum() else "_" for c in name])
        while "__" in clean:
            clean = clean.replace("__", "_")
        return clean.strip("_") or "AlertRule"

    def _build_promql_expr(
        self,
        category: str,
        target_resource: Optional[str],
        operator: str,
        threshold_value: float,
        unit: Optional[str] = "%"
    ) -> str:
        """Constructs an idiomatic PromQL expression based on normalized category, resource, and threshold."""
        cat = (category or "").upper()
        res_filter = ""
        if target_resource and target_resource.strip() and target_resource.strip().upper() != "ALL":
            res_val = target_resource.strip()
            res_filter = f'{{volume="{res_val}"}}' if cat in ["DISK", "DISK_VOLUME"] else (
                f'{{core="{res_val}"}}' if cat == "CORE" else (
                    f'{{nic="{res_val}"}}' if cat == "NETWORK" else (
                        f'{{name="{res_val}"}}' if cat == "SERVICE" else ""
                    )
                )
            )

        op = operator if operator in [">", "<", ">=", "<=", "==", "!="] else ">"

        if cat == "CPU":
            return f"windows_cpu_utilization_percent {op} {threshold_value}"
        elif cat == "CORE":
            return f"windows_cpu_core_utilization_percent{res_filter} {op} {threshold_value}"
        elif cat == "MEMORY":
            return f"windows_memory_utilization_percent {op} {threshold_value}"
        elif cat in ["DISK", "DISK_VOLUME"]:
            if unit == "GB" or op in ["<", "<="] and threshold_value > 10:
                # Absolute free space in GB
                return f"(windows_logical_disk_free_bytes{res_filter} / 1024 / 1024 / 1024) {op} {threshold_value}"
            elif op in ["<", "<="]:
                # Free space percentage
                return f"windows_logical_disk_free_percent{res_filter} {op} {threshold_value}"
            else:
                # Disk utilization percentage
                return f"windows_logical_disk_utilization_percent{res_filter} {op} {threshold_value}"
        elif cat == "DISK_IO":
            if "ms" in (unit or "").lower():
                return f"(((rate(windows_logical_disk_read_latency_seconds_total[1m]) + rate(windows_logical_disk_write_latency_seconds_total[1m])) / 2) * 1000) {op} {threshold_value}"
            elif "queue" in (unit or "").lower():
                return f"windows_logical_disk_requests_queued {op} {threshold_value}"
            else:
                return f"(((rate(windows_logical_disk_read_bytes_total[1m]) + rate(windows_logical_disk_write_bytes_total[1m])) / 1024 / 1024)) {op} {threshold_value}"
        elif cat == "NETWORK":
            if "err" in (unit or "").lower():
                return f"(rate(windows_net_packets_outbound_errors_total[1m]) + rate(windows_net_packets_received_errors_total[1m])) {op} {threshold_value}"
            elif "status" in (unit or "").lower():
                return f"windows_net_interface_status{res_filter} == {int(threshold_value)}"
            else:
                return f"((rate(windows_net_bytes_received_total[1m]) + rate(windows_net_bytes_sent_total[1m])) / 1024) {op} {threshold_value}"
        elif cat == "AVAILABILITY":
            return f"windows_exporter_availability == {int(threshold_value)}"
        elif cat == "SERVICE":
            return f'windows_service_status{{status="running"}}{res_filter} == 0'
        else:
            return f"windows_cpu_utilization_percent {op} {threshold_value}"

    def _get_recording_rules(self) -> List[Dict[str, Any]]:
        """
        Synthesizes standard continuous gauge recording rules from raw Windows Exporter counters.
        These are recorded on every scrape cycle (15s) so Prometheus alerting rules and UI metrics
        can instantly evaluate clean percentage gauges.
        """
        return [
            {
                "record": "windows_cpu_utilization_percent",
                "expr": 'clamp(100 - (avg by (instance, job) (irate(windows_cpu_time_seconds_total{mode="idle"}[2m])) * 100), 0, 100)',
                "labels": {
                    "tier": "INFRASTRUCTURE",
                    "os": "windows"
                }
            },
            {
                "record": "windows_cpu_core_utilization_percent",
                "expr": 'clamp(100 - (irate(windows_cpu_time_seconds_total{mode="idle"}[2m]) * 100), 0, 100)',
                "labels": {
                    "tier": "INFRASTRUCTURE",
                    "os": "windows"
                }
            },
            {
                "record": "windows_memory_utilization_percent",
                "expr": 'clamp(100 - ((windows_memory_physical_free_bytes / windows_memory_physical_total_bytes) * 100), 0, 100)',
                "labels": {
                    "tier": "INFRASTRUCTURE",
                    "os": "windows"
                }
            },
            {
                "record": "windows_logical_disk_utilization_percent",
                "expr": 'clamp(100 - ((windows_logical_disk_free_bytes / windows_logical_disk_size_bytes) * 100), 0, 100)',
                "labels": {
                    "tier": "INFRASTRUCTURE",
                    "os": "windows"
                }
            },
            {
                "record": "windows_logical_disk_free_percent",
                "expr": 'clamp((windows_logical_disk_free_bytes / windows_logical_disk_size_bytes) * 100, 0, 100)',
                "labels": {
                    "tier": "INFRASTRUCTURE",
                    "os": "windows"
                }
            }
        ]

    def _get_static_baseline_rules(self) -> List[Dict[str, Any]]:
        """Baseline platform rules that are always evaluated."""
        return [
            {
                "alert": "WindowsExporterDown",
                "expr": 'up{job="windows-exporter"} == 0',
                "for": "1m",
                "labels": {"severity": "critical", "tier": "INFRASTRUCTURE", "category": "AVAILABILITY", "os": "windows"},
                "annotations": {
                    "summary": "Windows Exporter is unreachable on {{ $labels.instance }}",
                    "description": "Scrape target for Windows exporter failed. Telemetry is currently unavailable."
                }
            },
            {
                "alert": "WindowsServerUnreachable",
                "expr": "windows_exporter_availability == 0",
                "for": "1m",
                "labels": {"severity": "critical", "tier": "INFRASTRUCTURE", "category": "AVAILABILITY", "os": "windows"},
                "annotations": {
                    "summary": "Server {{ $labels.instance }} is completely unreachable",
                    "description": "Windows host is not responding to heartbeats or metrics scrapers."
                }
            },
            {
                "alert": "SystemRestartDetected",
                "expr": "windows_system_restart_detected == 1",
                "for": "1m",
                "labels": {"severity": "warning", "tier": "INFRASTRUCTURE", "category": "SYSTEM", "os": "windows"},
                "annotations": {
                    "summary": "Host {{ $labels.instance }} system restart detected",
                    "description": "Server was recently rebooted. System uptime is under 15 minutes."
                }
            },
            {
                "alert": "NetworkInterfaceDown",
                "expr": "windows_net_interface_status == 0",
                "for": "1m",
                "labels": {"severity": "critical", "tier": "INFRASTRUCTURE", "category": "NETWORK", "os": "windows"},
                "annotations": {
                    "summary": "Network interface {{ $labels.nic }} is DOWN on {{ $labels.instance }}",
                    "description": "Operational network interface state transitioned to disconnected/down."
                }
            }
        ]

    async def compile_rules_from_db(self, db: AsyncSession) -> Dict[str, Any]:
        """
        Queries all enabled MonitoringThresholdRule rows from the database and compiles
        them into standard Prometheus alerting rule groups.
        """
        stmt = select(MonitoringThresholdRule).where(
            MonitoringThresholdRule.is_enabled == True,
            MonitoringThresholdRule.is_visible == True
        ).order_by(
            MonitoringThresholdRule.updated_at.desc(),
            MonitoringThresholdRule.created_at.desc()
        )
        result = await db.execute(stmt)
        rules = list(result.scalars().all())

        compiled_rules: List[Dict[str, Any]] = list(self._get_static_baseline_rules())

        for r in rules:
            base_name = self._sanitize_alert_name(r.name)
            duration_str = f"{max(1, r.duration_minutes)}m"
            category = r.metric_category or (r.metric_type.value if hasattr(r.metric_type, "value") else str(r.metric_type))
            target_res = r.target_resource or "ALL"
            unit = r.unit or "%"

            # 1. Warning Rule
            if r.warning_threshold is not None:
                warn_expr = self._build_promql_expr(category, target_res, r.operator, r.warning_threshold, unit)
                compiled_rules.append({
                    "alert": f"{base_name}Warning",
                    "expr": warn_expr,
                    "for": duration_str,
                    "labels": {
                        "severity": "warning",
                        "rule_id": str(r.id),
                        "server_id": str(r.server_id or "ALL"),
                        "category": category,
                        "resource": target_res,
                        "unit": unit,
                        "tier": "INFRASTRUCTURE",
                        "os": "windows"
                    },
                    "annotations": {
                        "summary": f"Warning: {r.name} threshold exceeded",
                        "description": f"{category} on {target_res} exceeded warning limit of {r.warning_threshold}{unit} (current: {{{{ $value | printf \"%.2f\" }}}}{unit})."
                    }
                })

            # 2. Critical Rule
            if r.critical_threshold is not None:
                crit_expr = self._build_promql_expr(category, target_res, r.operator, r.critical_threshold, unit)
                compiled_rules.append({
                    "alert": f"{base_name}Critical",
                    "expr": crit_expr,
                    "for": duration_str,
                    "labels": {
                        "severity": "critical",
                        "rule_id": str(r.id),
                        "server_id": str(r.server_id or "ALL"),
                        "category": category,
                        "resource": target_res,
                        "unit": unit,
                        "tier": "INFRASTRUCTURE",
                        "os": "windows"
                    },
                    "annotations": {
                        "summary": f"Critical: {r.name} threshold breached",
                        "description": f"{category} on {target_res} breached critical limit of {r.critical_threshold}{unit} (current: {{{{ $value | printf \"%.2f\" }}}}{unit})."
                    }
                })

            # 3. Severe Rule (if defined)
            if r.severe_threshold is not None:
                sev_expr = self._build_promql_expr(category, target_res, r.operator, r.severe_threshold, unit)
                compiled_rules.append({
                    "alert": f"{base_name}Severe",
                    "expr": sev_expr,
                    "for": duration_str,
                    "labels": {
                        "severity": "severe",
                        "rule_id": str(r.id),
                        "server_id": str(r.server_id or "ALL"),
                        "category": category,
                        "resource": target_res,
                        "unit": unit,
                        "tier": "INFRASTRUCTURE",
                        "os": "windows"
                    },
                    "annotations": {
                        "summary": f"Severe Outage Risk: {r.name}",
                        "description": f"{category} on {target_res} reached severe operational ceiling of {r.severe_threshold}{unit} (current: {{{{ $value | printf \"%.2f\" }}}}{unit})."
                    }
                })

        yaml_structure = {
            "groups": [
                {
                    "name": "windows_server_monitoring_rules",
                    "rules": self._get_recording_rules() + compiled_rules
                }
            ]
        }
        return yaml_structure

    async def sync_to_prometheus(self, db: AsyncSession) -> Dict[str, Any]:
        """
        Compiles dynamic rules from the DB, saves them to disk across Prometheus config locations,
        and triggers hot configuration reload on Prometheus.
        """
        rule_structure = await self.compile_rules_from_db(db)
        yaml_content = yaml.dump(rule_structure, sort_keys=False, default_flow_style=False)

        # 1. Write to primary backend monitoring alert_rules.yml
        os.makedirs(os.path.dirname(self.BASE_ALERT_RULES_PATH), exist_ok=True)
        with open(self.BASE_ALERT_RULES_PATH, "w", encoding="utf-8") as f:
            f.write(yaml_content)
        logger.info(f"Compiled alert rules written to {self.BASE_ALERT_RULES_PATH}")

        # 2. Replicate to active Prometheus runtime directories
        replicated_paths: List[str] = []
        for target_dir in self.PROMETHEUS_DIRS:
            if os.path.isdir(target_dir):
                dest_path = os.path.join(target_dir, "alert_rules.yml")
                if os.path.abspath(dest_path) == os.path.abspath(self.BASE_ALERT_RULES_PATH):
                    continue
                try:
                    shutil.copyfile(self.BASE_ALERT_RULES_PATH, dest_path)
                    replicated_paths.append(dest_path)
                    logger.info(f"Replicated alert rules to Prometheus runtime directory: {dest_path}")
                except Exception as exc:
                    logger.warning(f"Could not copy alert rules to {dest_path}: {exc}")

        # 3. Trigger Prometheus reload via lifecycle API
        reload_success, reload_err = await prometheus_client.reload_config()
        total_rules = len(rule_structure["groups"][0]["rules"])

        return {
            "success": True,
            "rules_count": total_rules,
            "prometheus_reloaded": reload_success,
            "reload_message": reload_err or "Configuration reloaded successfully",
            "synced_at": datetime.now(timezone.utc).isoformat(),
            "destinations": replicated_paths
        }


threshold_rule_compiler = ThresholdRuleCompiler()
