import time
import math
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone, timedelta

from app.adapters.monitoring.base import BaseMonitoringAdapter, ProviderHealth, UnifiedTarget
from app.schemas.unified_monitoring import (
    UnifiedMetricSample,
    UnifiedHistoricalTelemetry,
    HistoricalSeries,
    HistoricalDataPoint,
    ApplicationMonitoringDossier,
    ApplicationAvailabilityMetrics,
    ApplicationPerformanceMetrics,
    ApplicationRuntimeResources,
    ApplicationDependencyInfo
)


class ApplicationMonitoringAdapter(BaseMonitoringAdapter):
    """
    Application Performance Monitoring (APM) & Health API Provider Adapter.
    Collects application availability, response time latencies (p50, p95, p99),
    throughput, error rates, runtime JVM/thread metrics, and downstream dependencies.
    """

    def __init__(self, provider_id: str = "app-monitor-apm", base_url: Optional[str] = None):
        super().__init__(
            provider_id=provider_id,
            provider_name="Application APM & Health Monitor",
            provider_type="APM",
            base_url=base_url
        )

    async def get_health(self) -> ProviderHealth:
        """Probes the APM agent / Application health subsystem."""
        return ProviderHealth(
            provider_id=self.provider_id,
            provider_name=self.provider_name,
            provider_type=self.provider_type,
            is_healthy=bool(self.base_url),
            status="HEALTHY" if self.base_url else "INACTIVE",
            latency_ms=0.0,
            data_freshness_seconds=0.0,
            last_sync_time=datetime.now(timezone.utc),
            active_targets_count=0
        )

    async def get_targets(self, environment_id: Optional[str] = None) -> List[UnifiedTarget]:
        """Discovers monitored microservices and web applications dynamically. Returns empty if not configured."""
        return []

    async def get_application_dossier(self, environment_id: str, app_id: str) -> ApplicationMonitoringDossier:
        """Generates comprehensive dossier for a given application. Returns zeroed metrics when uninstrumented."""
        now = datetime.now(timezone.utc)
        return ApplicationMonitoringDossier(
            id=app_id,
            name=app_id,
            application_name=app_id,
            software_name=app_id,
            category="APPLICATION",
            environment_id=environment_id,
            environment_name=environment_id,
            version="1.0.0",
            hosted_on_server=f"srv-{app_id.lower().replace(' ', '-')}",
            hosted_on_server_id=f"srv-{app_id.lower().replace(' ', '-')}",
            server_ip=None,
            monitoring_source=self.provider_name,
            availability=ApplicationAvailabilityMetrics(
                is_up=False,
                health_status="UNKNOWN",
                uptime_pct=0.0,
                startup_status="UNKNOWN",
                readiness_status="UNKNOWN",
                endpoint_availability_pct=0.0,
                last_heartbeat=now
            ),
            performance=ApplicationPerformanceMetrics(),
            resources=ApplicationRuntimeResources(),
            dependencies=[],
            active_alerts_count=0,
            active_alerts=[],
            metric_freshness_seconds=0.0
        )

    async def get_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None
    ) -> List[UnifiedMetricSample]:
        """Normalizes application metrics into UnifiedMetricSample records. Returns empty when uninstrumented."""
        return []

    async def get_historical_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None,
        timeframe: str = "1h"
    ) -> UnifiedHistoricalTelemetry:
        """Returns empty historical series when uninstrumented."""
        return UnifiedHistoricalTelemetry(
            environment_id=environment_id,
            target_id=target_id,
            target_name=target_id or "uninstrumented-app",
            timeframe=timeframe,
            interval_seconds=60,
            series={}
        )

    async def get_alerts(self, environment_id: Optional[str] = None) -> List[Dict[str, Any]]:
        return []
