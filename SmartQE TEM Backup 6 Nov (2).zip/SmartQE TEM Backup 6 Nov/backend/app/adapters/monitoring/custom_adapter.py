import time
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from app.adapters.monitoring.base import BaseMonitoringAdapter, ProviderHealth, UnifiedTarget
from app.schemas.unified_monitoring import UnifiedMetricSample, UnifiedHistoricalTelemetry


class CustomMonitoringAdapter(BaseMonitoringAdapter):
    """
    Extensible Custom Monitoring Adapter.
    Demonstrates frictionless integration of future monitoring tools (e.g. Dynatrace, Datadog,
    OpenTelemetry Collector, or custom enterprise observability systems).
    
    Architectural guarantee:
    Adding a new monitoring source only requires implementing this adapter class and
    registering it with MonitoringAdapterRegistry. The TEM frontend and ECharts components
    remain 100% unchanged.
    """

    def __init__(self, provider_id: str = "custom-otel-collector", provider_name: str = "OpenTelemetry Collector", base_url: Optional[str] = None):
        super().__init__(
            provider_id=provider_id,
            provider_name=provider_name,
            provider_type="CUSTOM",
            base_url=base_url
        )

    async def get_health(self) -> ProviderHealth:
        return ProviderHealth(
            provider_id=self.provider_id,
            provider_name=self.provider_name,
            provider_type=self.provider_type,
            is_healthy=bool(self.base_url),
            status="HEALTHY" if self.base_url else "INACTIVE",
            latency_ms=0.0,
            data_freshness_seconds=0.0,
            last_sync_time=datetime.now(timezone.utc),
            active_targets_count=0
        )

    async def get_targets(self, environment_id: Optional[str] = None) -> List[UnifiedTarget]:
        return []

    async def get_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None
    ) -> List[UnifiedMetricSample]:
        now = datetime.now(timezone.utc)
        return [
            UnifiedMetricSample(
                environment="TEST-01",
                environment_id=environment_id,
                target=target_id or "otel-collector-gateway",
                target_type="SERVICE",
                service="otel-collector",
                metric="collector_queue_length",
                metric_type="GAUGE",
                value=12.0,
                unit="count",
                timestamp=now,
                status="HEALTHY",
                severity="INFO",
                source="custom-otel",
                provider=self.__class__.__name__,
                data_freshness_seconds=0.8,
                freshness_status="FRESH"
            )
        ]

    async def get_historical_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None,
        timeframe: str = "1h"
    ) -> UnifiedHistoricalTelemetry:
        return UnifiedHistoricalTelemetry(
            environment_id=environment_id,
            target_id=target_id,
            target_name="otel-collector-gateway",
            timeframe=timeframe,
            interval_seconds=60,
            series={}
        )

    async def get_alerts(self, environment_id: Optional[str] = None) -> List[Dict[str, Any]]:
        return []
