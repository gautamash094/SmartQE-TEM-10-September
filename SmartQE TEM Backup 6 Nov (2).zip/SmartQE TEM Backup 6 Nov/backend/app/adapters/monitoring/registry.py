from typing import Dict, List, Optional, Any
from app.core.config import settings
from app.adapters.monitoring.base import BaseMonitoringAdapter, ProviderHealth, UnifiedTarget
from app.adapters.monitoring.prometheus_adapter import PrometheusAdapter
from app.adapters.monitoring.postgres_adapter import PostgreSQLAdapter
from app.adapters.monitoring.application_adapter import ApplicationMonitoringAdapter
from app.adapters.monitoring.server_adapter import ServerMonitoringAdapter
from app.adapters.monitoring.custom_adapter import CustomMonitoringAdapter
from app.schemas.normalized_monitoring import NormalizedResource, DiscoveredMetric
from app.schemas.unified_monitoring import (
    MonitoringSourceHealth,
    UnifiedMetricSample,
    UnifiedHistoricalTelemetry
)


class MonitoringAdapterRegistry:
    """
    Central Registry and Dispatcher for Monitoring Provider Adapters.
    Decouples TEM from concrete monitoring tools and allows dynamic registration
    of new monitoring backends (Prometheus, PostgreSQL, MySQL, MongoDB, Kubernetes, etc.).
    """

    def __init__(self):
        self._adapters: Dict[str, BaseMonitoringAdapter] = {}
        self._register_default_adapters()

    def _register_default_adapters(self):
        """Initializes default enterprise monitoring adapters with externalized configuration."""
        prom_url = getattr(settings, "PROMETHEUS_URL", "http://localhost:9090")
        prom_timeout = getattr(settings, "PROMETHEUS_TIMEOUT", 5.0)
        self.register_adapter(PrometheusAdapter(base_url=prom_url, timeout=prom_timeout))
        if getattr(settings, "POSTGRES_ENABLED", True):
            self.register_adapter(PostgreSQLAdapter())
        self.register_adapter(ServerMonitoringAdapter(base_url=prom_url, timeout=prom_timeout))

    def register_adapter(self, adapter: BaseMonitoringAdapter):
        """Registers a new monitoring provider adapter."""
        self._adapters[adapter.provider_id] = adapter

    def unregister_adapter(self, provider_id: str) -> Optional[BaseMonitoringAdapter]:
        """Removes a monitoring adapter from the registry."""
        return self._adapters.pop(provider_id, None)

    def get_adapter(self, provider_id: str) -> Optional[BaseMonitoringAdapter]:
        """Retrieves a registered adapter by provider ID."""
        return self._adapters.get(provider_id)

    def list_adapters(self) -> List[BaseMonitoringAdapter]:
        """Lists all registered monitoring adapters."""
        return list(self._adapters.values())

    async def get_all_sources_health(self) -> List[MonitoringSourceHealth]:
        """
        Polls health and liveness for all registered monitoring sources.
        CRITICAL ARCHITECTURAL PRINCIPLE:
        Monitoring source failures are isolated and distinguished from actual
        server, application, or database downtime.
        """
        health_list: List[MonitoringSourceHealth] = []
        for adapter in self._adapters.values():
            try:
                p_health = await adapter.get_health()
                health_list.append(adapter.to_source_health(p_health))
            except Exception as exc:
                health_list.append(MonitoringSourceHealth(
                    source_id=adapter.provider_id,
                    source_name=adapter.provider_name,
                    adapter_name=adapter.__class__.__name__,
                    source_type=adapter.provider_type,
                    status="DOWN",
                    connectivity=False,
                    api_available=False,
                    latency_ms=0.0,
                    data_freshness_seconds=999.0,
                    error_message=f"Monitoring source unreachable: {str(exc)}"
                ))
        return health_list

    async def get_all_targets(self, environment_id: Optional[str] = None) -> List[UnifiedTarget]:
        """Collects targets across all registered adapters."""
        targets: List[UnifiedTarget] = []
        for adapter in self._adapters.values():
            try:
                ad_targets = await adapter.get_targets(environment_id)
                targets.extend(ad_targets)
            except Exception:
                continue
        return targets

    async def get_all_resources(self, environment_id: Optional[str] = None) -> List[NormalizedResource]:
        """Collects normalized resources across all registered adapters."""
        resources: List[NormalizedResource] = []
        for adapter in self._adapters.values():
            try:
                ad_resources = await adapter.get_resources(environment_id)
                resources.extend(ad_resources)
            except Exception:
                continue
        return resources

    async def get_all_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        target_type: Optional[str] = None
    ) -> List[UnifiedMetricSample]:
        """Aggregates unified metrics across all registered adapters."""
        all_metrics: List[UnifiedMetricSample] = []
        for adapter in self._adapters.values():
            try:
                metrics = await adapter.get_metrics(environment_id, target_id=target_id)
                all_metrics.extend(metrics)
            except Exception:
                continue
        return all_metrics

    async def discover_all_metrics(self) -> List[DiscoveredMetric]:
        """Discovers metrics available across all registered monitoring providers."""
        all_discovered: List[DiscoveredMetric] = []
        seen = set()
        for adapter in self._adapters.values():
            try:
                disc = await adapter.discover_metrics()
                for item in disc:
                    if item.name not in seen:
                        seen.add(item.name)
                        all_discovered.append(item)
            except Exception:
                continue
        return all_discovered

    async def get_historical_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        timeframe: str = "1h"
    ) -> UnifiedHistoricalTelemetry:
        """Retrieves historical metrics from appropriate adapter."""
        # 1. PostgreSQL target specifically
        if target_id and "postgres" in target_id.lower():
            prom_adapter = self.get_adapter("prometheus-core")
            if prom_adapter:
                res = await prom_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)
                if res and res.series:
                    return res
            pg_adapter = self.get_adapter("postgres-core")
            if pg_adapter:
                return await pg_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        # 2. Database or SQLite target
        if target_id and ("database" in target_id.lower() or "sqlite" in target_id.lower() or "db" in target_id.lower()):
            prom_adapter = self.get_adapter("prometheus-core")
            if prom_adapter:
                return await prom_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        # 2. Application target
        if target_id and ("service" in target_id.lower() or "app" in target_id.lower() and "server" not in target_id.lower()):
            app_adapter = self.get_adapter("app-monitor-apm")
            if app_adapter:
                return await app_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        # 3. Server target
        server_adapter = self.get_adapter("server-monitor-infra")
        is_server_target = target_id and any(k in target_id.lower() for k in ["server", "srv", "win", "node", "host", "infra"])
        if server_adapter and is_server_target:
            return await server_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        # 4. Default: Aggregate Prometheus metrics + Server metrics
        prom_adapter = self.get_adapter("prometheus-core")
        if prom_adapter:
            return await prom_adapter.get_historical_metrics(environment_id, target_id, timeframe=timeframe)

        return UnifiedHistoricalTelemetry(
            environment_id=environment_id,
            target_id=target_id,
            timeframe=timeframe,
            series={}
        )


adapter_registry = MonitoringAdapterRegistry()
