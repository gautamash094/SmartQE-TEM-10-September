import time
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from app.core.config import settings
from app.core.logging import logger
from app.adapters.monitoring.base import BaseMonitoringAdapter, ProviderHealth, UnifiedTarget
from app.adapters.monitoring.normalizer import normalizer
from app.adapters.monitoring.metrics import operational_metrics
from app.schemas.normalized_monitoring import (
    NormalizedMetric,
    NormalizedResource,
    DataFreshness,
    DiscoveredMetric
)
from app.schemas.unified_monitoring import (
    UnifiedMetricSample,
    UnifiedHistoricalTelemetry,
    HistoricalSeries,
    HistoricalDataPoint
)


class PostgreSQLAdapter(BaseMonitoringAdapter):
    """
    Enterprise PostgreSQL Monitoring Adapter.
    Integrates PostgreSQL as a first-class monitoring provider in SmartQE TEM.
    Discovers instances, databases, tables, connections, query performance,
    lock contention, and storage metrics dynamically.
    """

    def __init__(
        self,
        provider_id: str = "postgres-core",
        base_url: Optional[str] = None,
        timeout: Optional[float] = None
    ):
        host = getattr(settings, "postgres_effective_host", "localhost")
        port = getattr(settings, "POSTGRES_PORT", 5432)
        endpoint = base_url or f"postgresql://{host}:{port}"

        super().__init__(
            provider_id=provider_id,
            provider_name="PostgreSQL Database Monitor",
            provider_type="DATABASE",
            base_url=endpoint
        )
        self.host = host
        self.port = port
        self.timeout = timeout or getattr(settings, "POSTGRES_CONNECT_TIMEOUT", 5.0)
        self.database_name = getattr(settings, "postgres_effective_database", "smartqe_tem")
        self.user = getattr(settings, "POSTGRES_USER", "postgres")
        self.password = getattr(settings, "POSTGRES_PASSWORD", "postgres")
        self.ssl_mode = getattr(settings, "POSTGRES_SSL_MODE", "prefer")
        self.slow_query_threshold = getattr(settings, "POSTGRES_SLOW_QUERY_THRESHOLD_SECONDS", 1.0)
        self.exporter_port = getattr(settings, "POSTGRES_EXPORTER_PORT", 9188)

    async def get_health(self) -> ProviderHealth:
        """
        Probes PostgreSQL connectivity and collection latency.
        Distinguishes strictly between PostgreSQL UP and PostgreSQL DOWN.
        """
        start = time.perf_counter()
        is_healthy = False
        latency_ms = 0.0
        error_msg = None

        try:
            import asyncpg
            ssl_arg = True if self.ssl_mode in ["require", "verify-ca", "verify-full"] else False
            conn = await asyncpg.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                database=self.database_name,
                timeout=self.timeout,
                ssl=ssl_arg
            )
            latency_ms = round((time.perf_counter() - start) * 1000, 2)
            await conn.close()
            is_healthy = True
        except Exception as exc:
            latency_ms = round((time.perf_counter() - start) * 1000, 2)
            is_healthy = False
            error_msg = f"PostgreSQL connection failed ({type(exc).__name__}): {str(exc)}"
            logger.warning(f"PostgreSQLAdapter probe failed: {error_msg}")

        duration = time.perf_counter() - start
        operational_metrics.record_provider_query(
            provider="postgresql",
            operation="get_health",
            duration_seconds=duration,
            is_error=not is_healthy,
            error_type="unreachable" if not is_healthy else "none"
        )

        status = "HEALTHY" if is_healthy else "DOWN"
        freshness_seconds = 0.5 if is_healthy else 999.0

        return ProviderHealth(
            provider_id=self.provider_id,
            provider_name=self.provider_name,
            provider_type=self.provider_type,
            is_healthy=is_healthy,
            status=status,
            latency_ms=latency_ms,
            data_freshness_seconds=freshness_seconds,
            last_sync_time=datetime.now(timezone.utc),
            error_message=error_msg,
            active_targets_count=1 if is_healthy else 0
        )

    async def get_targets(self, environment_id: Optional[str] = None) -> List[UnifiedTarget]:
        """Discovers PostgreSQL database targets dynamically."""
        targets: List[UnifiedTarget] = []
        is_up = await self.check_connectivity()

        targets.append(UnifiedTarget(
            id=f"target-postgresql-{self.database_name}",
            name=f"PostgreSQL ({self.host}:{self.port}/{self.database_name})",
            environment_id=environment_id or "env-01",
            environment_name="SmartQE Core Environment",
            target_type="DATABASE",
            endpoint_url=f"postgresql://{self.host}:{self.port}/{self.database_name}",
            is_up=is_up,
            status="UP" if is_up else "DOWN",
            labels={
                "database": self.database_name,
                "technology": "postgresql",
                "tier": "DATABASE",
                "host": self.host,
                "port": str(self.port)
            }
        ))
        return targets

    async def get_resources(self, environment_id: Optional[str] = None) -> List[NormalizedResource]:
        """
        Discovers and normalizes all PostgreSQL resources:
        PostgreSQL Database, PostgreSQL Tables, and Exporter Target.
        """
        resources: List[NormalizedResource] = []
        now_ts = time.time()

        try:
            import asyncpg
            ssl_arg = True if self.ssl_mode in ["require", "verify-ca", "verify-full"] else False
            conn = await asyncpg.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                database=self.database_name,
                timeout=self.timeout,
                ssl=ssl_arg
            )

            # 1. Database-level resource
            db_size = await conn.fetchval(
                "SELECT pg_database_size($1)", self.database_name
            ) or 0

            stats_row = await conn.fetchrow(
                """
                SELECT
                    COALESCE(xact_commit, 0) AS commits,
                    COALESCE(xact_rollback, 0) AS rollbacks,
                    COALESCE(blks_read, 0) AS blks_read,
                    COALESCE(blks_hit, 0) AS blks_hit,
                    COALESCE(deadlocks, 0) AS deadlocks
                FROM pg_stat_database
                WHERE datname = $1
                """,
                self.database_name
            )

            total_blks = (stats_row["blks_read"] or 0) + (stats_row["blks_hit"] or 0) if stats_row else 0
            cache_hit = round(((stats_row["blks_hit"] or 0) / max(1, total_blks)) * 100.0, 2) if total_blks > 0 else 100.0

            # Active connections count
            active_conns = await conn.fetchval(
                "SELECT count(*) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid()",
                self.database_name
            ) or 0

            max_conns_str = await conn.fetchval("SHOW max_connections")
            max_conns = float(max_conns_str) if max_conns_str else 100.0
            conn_utilization = round((float(active_conns) / max(1.0, max_conns)) * 100.0, 1)

            # Tables count
            tables_total = await conn.fetchval(
                "SELECT count(*) FROM pg_stat_user_tables"
            ) or 0

            resources.append(NormalizedResource(
                id=f"resource-postgres-db-{self.database_name}",
                name=f"PostgreSQL Database ({self.database_name})",
                type="database",
                technology="postgresql",
                monitoring_source=self.provider_id,
                status="HEALTHY",
                is_up=True,
                environment_id=environment_id or "env-01",
                environment_name="SmartQE Core Environment",
                labels={
                    "database": self.database_name,
                    "technology": "postgresql",
                    "host": self.host
                },
                metadata={
                    "size_bytes": float(db_size),
                    "tables_total": int(tables_total),
                    "connections_active": int(active_conns),
                    "max_connections": float(max_conns),
                    "cache_hit_ratio": float(cache_hit),
                    "deadlocks": int(stats_row["deadlocks"] if stats_row else 0)
                },
                metrics_summary={
                    "database_up": 1.0,
                    "size_bytes": float(db_size),
                    "tables_count": float(tables_total),
                    "connection_utilization": float(conn_utilization),
                    "cache_hit_ratio": float(cache_hit),
                    "active_connections": float(active_conns)
                },
                last_updated=datetime.now(timezone.utc),
                data_freshness=normalizer.calculate_freshness(now_ts)
            ))

            # 2. Table-level resources
            table_rows = await conn.fetch(
                """
                SELECT
                    relname AS table_name,
                    COALESCE(n_live_tup, 0) AS row_count,
                    pg_total_relation_size(relid) AS size_bytes
                FROM pg_stat_user_tables
                ORDER BY size_bytes DESC
                """
            )

            for tr in table_rows:
                tbl = tr["table_name"]
                rc = float(tr["row_count"] or 0)
                tb_size = float(tr["size_bytes"] or 0)

                resources.append(NormalizedResource(
                    id=f"table-pg-{self.database_name}-{tbl}",
                    name=f"Table: {tbl}",
                    type="database_table",
                    technology="postgresql",
                    monitoring_source=self.provider_id,
                    status="HEALTHY",
                    is_up=True,
                    environment_id=environment_id or "env-01",
                    environment_name="SmartQE Core Environment",
                    labels={
                        "table": tbl,
                        "database": self.database_name,
                        "technology": "postgresql"
                    },
                    metadata={"rows": rc, "size_bytes": tb_size},
                    metrics_summary={"row_count": rc, "table_size_bytes": tb_size},
                    last_updated=datetime.now(timezone.utc),
                    data_freshness=normalizer.calculate_freshness(now_ts)
                ))

            await conn.close()

        except Exception as exc:
            logger.debug(f"PostgreSQLAdapter get_resources offline fallback: {exc}")
            # If PostgreSQL is offline, return representation showing DOWN
            resources.append(NormalizedResource(
                id=f"resource-postgres-db-{self.database_name}",
                name=f"PostgreSQL Database ({self.database_name})",
                type="database",
                technology="postgresql",
                monitoring_source=self.provider_id,
                status="DOWN",
                is_up=False,
                environment_id=environment_id or "env-01",
                environment_name="SmartQE Core Environment",
                labels={
                    "database": self.database_name,
                    "technology": "postgresql",
                    "host": self.host
                },
                metadata={"size_bytes": 0.0, "tables_total": 0},
                metrics_summary={"database_up": 0.0, "connection_utilization": 0.0},
                last_updated=datetime.now(timezone.utc),
                data_freshness=DataFreshness(age_seconds=999.0, status="STALE")
            ))

        return resources

    async def get_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None
    ) -> List[UnifiedMetricSample]:
        """Retrieves and normalizes live PostgreSQL metrics."""
        samples: List[UnifiedMetricSample] = []
        is_up = await self.check_connectivity()
        now_ts = time.time()

        val_up = 1.0 if is_up else 0.0
        m_up = normalizer.normalize_metric(
            raw_name="pg_up",
            value=val_up,
            timestamp=now_ts,
            labels={"database": self.database_name, "technology": "postgresql"},
            source="postgresql",
            provider=self.__class__.__name__,
            environment_id=environment_id
        )
        samples.append(normalizer.to_unified_metric_sample(m_up))

        if is_up:
            try:
                import asyncpg
                ssl_arg = True if self.ssl_mode in ["require", "verify-ca", "verify-full"] else False
                conn = await asyncpg.connect(
                    host=self.host,
                    port=self.port,
                    user=self.user,
                    password=self.password,
                    database=self.database_name,
                    timeout=self.timeout,
                    ssl=ssl_arg
                )

                # Query basic database size & stats
                db_size = await conn.fetchval("SELECT pg_database_size($1)", self.database_name) or 0
                m_size = normalizer.normalize_metric(
                    raw_name="pg_database_size_bytes",
                    value=float(db_size),
                    timestamp=now_ts,
                    labels={"database": self.database_name, "technology": "postgresql"},
                    source="postgresql",
                    provider=self.__class__.__name__,
                    environment_id=environment_id
                )
                samples.append(normalizer.to_unified_metric_sample(m_size))

                # Activity
                active_conns = await conn.fetchval(
                    "SELECT count(*) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid()",
                    self.database_name
                ) or 0
                max_conns_str = await conn.fetchval("SHOW max_connections")
                max_conns = float(max_conns_str) if max_conns_str else 100.0
                utilization = round((float(active_conns) / max(1.0, max_conns)) * 100.0, 1)

                m_util = normalizer.normalize_metric(
                    raw_name="pg_connection_utilization_ratio",
                    value=utilization,
                    timestamp=now_ts,
                    labels={"database": self.database_name, "technology": "postgresql"},
                    source="postgresql",
                    provider=self.__class__.__name__,
                    environment_id=environment_id
                )
                samples.append(normalizer.to_unified_metric_sample(m_util))

                await conn.close()
            except Exception as exc:
                logger.debug(f"PostgreSQLAdapter get_metrics query failed: {exc}")

        return samples

    async def get_historical_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None,
        timeframe: str = "1h"
    ) -> UnifiedHistoricalTelemetry:
        """Provides time-series historical telemetry for ECharts rendering."""
        now_ts = time.time()
        is_up = await self.check_connectivity()

        conn_util = 0.0
        if is_up:
            try:
                conn = await self._get_connection()
                if conn:
                    active = await conn.fetchval(
                        "SELECT count(*) FROM pg_stat_activity WHERE datname = $1",
                        self.database_name
                    ) or 0
                    max_conns_str = await conn.fetchval("SHOW max_connections") or "100"
                    max_conns = float(max_conns_str)
                    if max_conns > 0:
                        conn_util = round((float(active) / max_conns) * 100.0, 2)
                    await conn.close()
            except Exception:
                conn_util = 0.0

        # Build clean series for PostgreSQL operational indicators
        series_map: Dict[str, HistoricalSeries] = {
            "database_availability": HistoricalSeries(
                name="Database Availability",
                unit="status",
                points=[HistoricalDataPoint(timestamp="Now", value=1.0 if is_up else 0.0)],
                current=1.0 if is_up else 0.0,
                avg=1.0 if is_up else 0.0,
                peak=1.0 if is_up else 0.0,
                min_val=1.0 if is_up else 0.0
            ),
            "connection_utilization": HistoricalSeries(
                name="Connection Utilization",
                unit="%",
                points=[HistoricalDataPoint(timestamp="Now", value=conn_util)],
                current=conn_util,
                avg=conn_util,
                peak=conn_util,
                min_val=conn_util
            )
        }

        return UnifiedHistoricalTelemetry(
            environment_id=environment_id,
            target_id=target_id,
            target_name=target_id or f"PostgreSQL ({self.database_name})",
            timeframe=timeframe,
            interval_seconds=60,
            series=series_map
        )

    async def get_alerts(self, environment_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Evaluates active PostgreSQL alerts."""
        alerts: List[Dict[str, Any]] = []
        is_up = await self.check_connectivity()

        if not is_up:
            alerts.append({
                "alert_id": "alert-postgres-db-down",
                "source": "postgresql",
                "resource": f"postgresql-{self.database_name}",
                "environment": "SmartQE Core Environment",
                "metric": "pg_up",
                "condition": "pg_up == 0",
                "severity": "CRITICAL",
                "status": "ACTIVE",
                "message": f"PostgreSQL database '{self.database_name}' on {self.host}:{self.port} is offline or unreachable",
                "labels": {"job": "smartqe-tem-postgresql", "database": self.database_name, "technology": "postgresql"}
            })

        return alerts

    async def discover_metrics(self) -> List[DiscoveredMetric]:
        """Discovers metric families supported by PostgreSQL monitoring."""
        return [
            DiscoveredMetric(name="pg_up", type="gauge", help_text="PostgreSQL server availability", unit="status", category="DATABASE"),
            DiscoveredMetric(name="pg_database_up", type="gauge", help_text="Database availability status", unit="status", category="DATABASE"),
            DiscoveredMetric(name="pg_connection_status", type="gauge", help_text="Connection status", unit="status", category="CONNECTION"),
            DiscoveredMetric(name="pg_settings_max_connections", type="gauge", help_text="Max configured connections", unit="count", category="CONNECTION"),
            DiscoveredMetric(name="pg_stat_activity_count", type="gauge", help_text="Connections by state", unit="count", category="CONNECTION"),
            DiscoveredMetric(name="pg_connection_utilization_ratio", type="gauge", help_text="Connection utilization percentage", unit="%", category="CONNECTION"),
            DiscoveredMetric(name="pg_database_size_bytes", type="gauge", help_text="Database size in bytes", unit="bytes", category="STORAGE"),
            DiscoveredMetric(name="pg_database_tables_total", type="gauge", help_text="User tables count", unit="count", category="DATABASE"),
            DiscoveredMetric(name="pg_table_size_bytes", type="gauge", help_text="Table size in bytes", unit="bytes", category="STORAGE"),
            DiscoveredMetric(name="pg_table_rows_total", type="gauge", help_text="Table live row count", unit="rows", category="DATABASE"),
            DiscoveredMetric(name="pg_cache_hit_ratio", type="gauge", help_text="Buffer cache hit ratio", unit="%", category="DATABASE"),
            DiscoveredMetric(name="pg_stat_database_deadlocks", type="gauge", help_text="Total deadlocks detected", unit="count", category="DATABASE"),
            DiscoveredMetric(name="pg_slow_queries_total", type="gauge", help_text="Active slow queries count", unit="count", category="QUERY"),
            DiscoveredMetric(name="pg_locks_waiting_total", type="gauge", help_text="Waiting lock requests count", unit="count", category="LOCK")
        ]
