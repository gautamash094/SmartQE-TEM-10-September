import time
from typing import List, Dict, Any, Optional, Tuple
import httpx

from app.core.config import settings
from app.core.logging import logger


class PrometheusClientError(Exception):
    """Base exception for Prometheus client failures."""
    pass


class PrometheusConnectionError(PrometheusClientError):
    """Raised when unable to establish connection to Prometheus."""
    pass


class PrometheusTimeoutError(PrometheusClientError):
    """Raised when query or request to Prometheus exceeds configured timeout."""
    pass


class PrometheusQueryError(PrometheusClientError):
    """Raised when Prometheus returns an execution or syntax error for PromQL."""
    pass


class PrometheusClient:
    """
    Production-grade asynchronous HTTP client for Prometheus Server API.
    Interacts with Prometheus HTTP v1 endpoints:
      - /api/v1/query (instant vector evaluation)
      - /api/v1/query_range (matrix time series)
      - /api/v1/targets (scrape target discovery & health)
      - /api/v1/label/__name__/values (dynamic metric discovery)
      - /api/v1/metadata (metric type & unit help)
      - /-/healthy (liveness probe)
    
    Guarantees:
      - Never leaks raw networking/transport exceptions upward.
      - Provides latency and timing telemetry.
      - Externalized configuration with fallback resilience.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None
    ):
        self.base_url = (base_url or getattr(settings, "PROMETHEUS_URL", "http://localhost:9090")).rstrip("/")
        self.timeout = float(timeout or getattr(settings, "PROMETHEUS_TIMEOUT", 5.0))
        self._client: Optional[httpx.AsyncClient] = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={"Accept": "application/json"},
                limits=httpx.Limits(max_keepalive_connections=30, max_connections=60)
            )
        return self._client

    async def aclose(self):
        """Closes the underlying HTTP transport."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def check_health(self) -> Tuple[bool, float, Optional[str]]:
        """
        Probes Prometheus server availability.
        Returns:
            (is_healthy: bool, latency_ms: float, error_message: Optional[str])
        """
        start = time.perf_counter()
        try:
            client = self._get_client()
            # Prometheus provides /-/healthy endpoint
            resp = await client.get("/-/healthy")
            latency_ms = round((time.perf_counter() - start) * 1000, 2)
            if resp.status_code == 200:
                return True, latency_ms, None
            
            # Fallback check against /api/v1/status/buildinfo
            resp_info = await client.get("/api/v1/status/buildinfo")
            latency_ms = round((time.perf_counter() - start) * 1000, 2)
            if resp_info.status_code == 200:
                return True, latency_ms, None
            
            return False, latency_ms, f"Prometheus responded with HTTP {resp.status_code}"
        except httpx.TimeoutException:
            latency_ms = round((time.perf_counter() - start) * 1000, 2)
            return False, latency_ms, f"Connection timeout ({self.timeout}s) contacting Prometheus at {self.base_url}"
        except (httpx.ConnectError, httpx.NetworkError) as exc:
            latency_ms = round((time.perf_counter() - start) * 1000, 2)
            return False, latency_ms, f"Unable to connect to Prometheus at {self.base_url}: {str(exc)}"
        except Exception as exc:
            latency_ms = round((time.perf_counter() - start) * 1000, 2)
            return False, latency_ms, f"Unexpected error probing Prometheus: {str(exc)}"

    async def query_instant(self, query: str, query_time: Optional[float] = None) -> Dict[str, Any]:
        """
        Evaluates an instant PromQL expression.
        Returns the contents of payload["data"] containing resultType and result array.
        """
        params: Dict[str, Any] = {"query": query}
        if query_time is not None:
            params["time"] = str(query_time)

        try:
            client = self._get_client()
            resp = await client.get("/api/v1/query", params=params)
            if resp.status_code != 200:
                err_msg = resp.text
                try:
                    err_json = resp.json()
                    err_msg = err_json.get("error", resp.text)
                except Exception:
                    pass
                raise PrometheusQueryError(f"PromQL instant query failed [HTTP {resp.status_code}]: {err_msg}")

            data = resp.json()
            if data.get("status") != "success":
                raise PrometheusQueryError(f"Prometheus error: {data.get('error', 'Unknown query failure')}")

            return data.get("data", {"resultType": "vector", "result": []})
        except httpx.TimeoutException:
            raise PrometheusTimeoutError(f"PromQL instant query timed out after {self.timeout}s: '{query}'")
        except (httpx.ConnectError, httpx.NetworkError) as exc:
            raise PrometheusConnectionError(f"Prometheus connection failure at {self.base_url}: {str(exc)}")
        except PrometheusClientError:
            raise
        except Exception as exc:
            raise PrometheusQueryError(f"Query execution failed for '{query}': {str(exc)}")

    async def query_range(
        self,
        query: str,
        start: float,
        end: float,
        step: str = "15s"
    ) -> Dict[str, Any]:
        """
        Evaluates an expression over a time range.
        Returns data payload with resultType='matrix' and series results.
        """
        params = {
            "query": query,
            "start": str(start),
            "end": str(end),
            "step": step
        }

        try:
            client = self._get_client()
            resp = await client.get("/api/v1/query_range", params=params)
            if resp.status_code != 200:
                err_msg = resp.text
                try:
                    err_json = resp.json()
                    err_msg = err_json.get("error", resp.text)
                except Exception:
                    pass
                raise PrometheusQueryError(f"PromQL range query failed [HTTP {resp.status_code}]: {err_msg}")

            data = resp.json()
            if data.get("status") != "success":
                raise PrometheusQueryError(f"Prometheus range error: {data.get('error', 'Unknown range query error')}")

            return data.get("data", {"resultType": "matrix", "result": []})
        except httpx.TimeoutException:
            raise PrometheusTimeoutError(f"PromQL range query timed out after {self.timeout}s: '{query}'")
        except (httpx.ConnectError, httpx.NetworkError) as exc:
            raise PrometheusConnectionError(f"Prometheus connection failure at {self.base_url}: {str(exc)}")
        except PrometheusClientError:
            raise
        except Exception as exc:
            raise PrometheusQueryError(f"Range query execution failed for '{query}': {str(exc)}")

    async def get_targets(self, state: Optional[str] = "active") -> List[Dict[str, Any]]:
        """
        Retrieves active and dropped targets registered with Prometheus.
        Returns a list of target dictionaries.
        """
        params = {}
        if state:
            params["state"] = state

        try:
            client = self._get_client()
            resp = await client.get("/api/v1/targets", params=params)
            if resp.status_code != 200:
                raise PrometheusQueryError(f"Failed to fetch Prometheus targets [HTTP {resp.status_code}]")

            data = resp.json()
            if data.get("status") != "success":
                raise PrometheusQueryError(f"Prometheus targets error: {data.get('error')}")

            targets_data = data.get("data", {})
            return targets_data.get("activeTargets", [])
        except httpx.TimeoutException:
            raise PrometheusTimeoutError(f"Target discovery timed out after {self.timeout}s")
        except (httpx.ConnectError, httpx.NetworkError) as exc:
            raise PrometheusConnectionError(f"Target discovery failed (Prometheus offline at {self.base_url}): {str(exc)}")
        except PrometheusClientError:
            raise
        except Exception as exc:
            raise PrometheusQueryError(f"Unable to discover targets: {str(exc)}")

    async def get_metric_names(self) -> List[str]:
        """
        Dynamically discovers all metric names known to Prometheus.
        """
        try:
            client = self._get_client()
            resp = await client.get("/api/v1/label/__name__/values")
            if resp.status_code != 200:
                raise PrometheusQueryError(f"Failed to retrieve metric names [HTTP {resp.status_code}]")

            data = resp.json()
            if data.get("status") != "success":
                raise PrometheusQueryError(f"Error retrieving metric names: {data.get('error')}")

            return data.get("data", [])
        except httpx.TimeoutException:
            raise PrometheusTimeoutError(f"Metric discovery timed out after {self.timeout}s")
        except (httpx.ConnectError, httpx.NetworkError) as exc:
            raise PrometheusConnectionError(f"Metric discovery failed: {str(exc)}")
        except PrometheusClientError:
            raise
        except Exception as exc:
            raise PrometheusQueryError(f"Failed to discover metric names: {str(exc)}")

    async def get_label_values(self, label_name: str) -> List[str]:
        """
        Retrieves values for a given label name.
        """
        try:
            client = self._get_client()
            resp = await client.get(f"/api/v1/label/{label_name}/values")
            if resp.status_code == 200:
                data = resp.json()
                return data.get("data", [])
            return []
        except Exception:
            return []

    async def get_metric_metadata(self, metric: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieves metric type and help metadata from Prometheus.
        """
        params = {}
        if metric:
            params["metric"] = metric

        try:
            client = self._get_client()
            resp = await client.get("/api/v1/metadata", params=params)
            if resp.status_code == 200:
                data = resp.json()
                return data.get("data", {})
            return {}
        except Exception:
            return {}

    async def get_alerts(self) -> List[Dict[str, Any]]:
        """
        Retrieves active firing and pending alerts from Prometheus.
        Combines firing alerts from /api/v1/alerts and pending/firing alerts from /api/v1/rules.
        """
        try:
            client = self._get_client()
            alerts_map: Dict[str, Dict[str, Any]] = {}

            # 1. Fetch firing alerts from /api/v1/alerts
            resp = await client.get("/api/v1/alerts")
            if resp.status_code == 200:
                data = resp.json()
                for a in data.get("data", {}).get("alerts", []):
                    fp = a.get("fingerprint") or f"{a.get('labels', {}).get('alertname')}-{a.get('labels', {}).get('instance')}"
                    alerts_map[fp] = a

            # 2. Fetch pending and firing alerts from /api/v1/rules
            rules_resp = await client.get("/api/v1/rules")
            if rules_resp.status_code == 200:
                rdata = rules_resp.json()
                for group in rdata.get("data", {}).get("groups", []):
                    for rule in group.get("rules", []):
                        for rule_alert in rule.get("alerts", []):
                            fp = rule_alert.get("fingerprint") or f"{rule_alert.get('labels', {}).get('alertname')}-{rule_alert.get('labels', {}).get('instance')}"
                            if fp not in alerts_map:
                                alerts_map[fp] = rule_alert

            return list(alerts_map.values())
        except Exception as exc:
            logger.warning(f"Error fetching alerts from Prometheus: {exc}")
            return []

    async def get_rules(self) -> List[Dict[str, Any]]:
        """
        Retrieves rule groups and alerting rules from Prometheus.
        """
        try:
            client = self._get_client()
            resp = await client.get("/api/v1/rules")
            if resp.status_code == 200:
                data = resp.json()
                return data.get("data", {}).get("groups", [])
            return []
        except Exception as exc:
            logger.warning(f"Error fetching rules from Prometheus: {exc}")
            return []

    async def reload_config(self) -> Tuple[bool, Optional[str]]:
        """
        Triggers Prometheus configuration hot reload via HTTP POST /-/reload.
        """
        try:
            client = self._get_client()
            resp = await client.post("/-/reload")
            if resp.status_code in [200, 204]:
                return True, None
            return False, f"Prometheus reload returned HTTP {resp.status_code}: {resp.text}"
        except Exception as exc:
            return False, f"Failed to reload Prometheus config: {str(exc)}"


prometheus_client = PrometheusClient()


