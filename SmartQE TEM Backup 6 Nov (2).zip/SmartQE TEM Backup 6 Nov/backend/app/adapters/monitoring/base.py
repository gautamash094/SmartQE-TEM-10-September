from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from pydantic import BaseModel, Field

from app.schemas.unified_monitoring import (
    UnifiedMetricSample,
    UnifiedHistoricalTelemetry,
    MonitoringSourceHealth
)


class ProviderHealth(BaseModel):
    """Normalized health status of a monitoring provider adapter."""
    provider_id: str
    provider_name: str
    provider_type: str
    is_healthy: bool
    status: str  # HEALTHY, WARNING, DOWN, UNKNOWN
    latency_ms: float
    data_freshness_seconds: float
    last_sync_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    error_message: Optional[str] = None
    active_targets_count: int = 0


class UnifiedTarget(BaseModel):
    """Normalized target discovered or managed by a monitoring provider."""
    id: str
    name: str
    environment_id: str
    environment_name: str
    target_type: str  # SERVER, APPLICATION, DATABASE, SERVICE
    endpoint_url: str
    is_up: bool = True
    status: str = "UP"
    labels: Dict[str, str] = Field(default_factory=dict)


class BaseMonitoringAdapter(ABC):
    """
    Abstract Base Monitoring Adapter defining the provider contract.
    Any new monitoring source (Prometheus, APM, Datadog, Dynatrace, CloudWatch, Custom)
    must implement this contract. The TEM platform and frontend interact ONLY with this contract.
    """

    def __init__(self, provider_id: str, provider_name: str, provider_type: str, base_url: Optional[str] = None):
        self.provider_id = provider_id
        self.provider_name = provider_name
        self.provider_type = provider_type
        self.base_url = base_url
        self.is_enabled = True

    @abstractmethod
    async def get_health(self) -> ProviderHealth:
        """Probes the monitoring source connectivity, API latency, and data freshness."""
        pass

    @abstractmethod
    async def get_targets(self, environment_id: Optional[str] = None) -> List[UnifiedTarget]:
        """Discovers or lists all monitored entities handled by this provider."""
        pass

    @abstractmethod
    async def get_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None
    ) -> List[UnifiedMetricSample]:
        """
        Retrieves live metrics from the source, validates, transforms, and normalizes
        them into UnifiedMetricSample records.
        """
        pass

    @abstractmethod
    async def get_historical_metrics(
        self,
        environment_id: str,
        target_id: Optional[str] = None,
        metric_names: Optional[List[str]] = None,
        timeframe: str = "1h"
    ) -> UnifiedHistoricalTelemetry:
        """Retrieves normalized historical time series data formatted for Apache ECharts."""
        pass

    @abstractmethod
    async def get_alerts(self, environment_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Retrieves and normalizes alerts from the monitoring provider."""
        pass

    async def get_resources(self, environment_id: Optional[str] = None) -> List[Any]:
        """Discovers or retrieves normalized resources (databases, tables, servers, applications)."""
        targets = await self.get_targets(environment_id)
        from app.schemas.normalized_monitoring import NormalizedResource, DataFreshness
        return [
            NormalizedResource(
                id=t.id,
                name=t.name,
                type=t.target_type.lower(),
                technology=t.labels.get("os", "windows" if "windows" in t.name.lower() or "win" in t.name.lower() else "generic"),
                monitoring_source=self.provider_id,
                status="HEALTHY" if t.is_up else "DOWN",
                is_up=t.is_up,
                environment_id=t.environment_id,
                environment_name=t.environment_name,
                endpoint_url=t.endpoint_url,
                labels=t.labels,
                data_freshness=DataFreshness(age_seconds=1.0, status="FRESH")
            )
            for t in targets
        ]

    async def discover_metrics(self) -> List[Any]:
        """Dynamically discovers metric names/families supported by this provider."""
        return []

    async def check_connectivity(self) -> bool:
        """Lightweight connectivity health check."""
        try:
            health = await self.get_health()
            return health.is_healthy
        except Exception:
            return False

    def to_source_health(self, health: ProviderHealth) -> MonitoringSourceHealth:
        """Transforms provider health to schema output."""
        return MonitoringSourceHealth(
            source_id=self.provider_id,
            source_name=self.provider_name,
            adapter_name=self.__class__.__name__,
            source_type=self.provider_type,
            status=health.status,
            connectivity=health.is_healthy,
            api_available=health.is_healthy,
            latency_ms=health.latency_ms,
            data_freshness_seconds=health.data_freshness_seconds,
            last_sync_time=health.last_sync_time,
            error_message=health.error_message
        )
