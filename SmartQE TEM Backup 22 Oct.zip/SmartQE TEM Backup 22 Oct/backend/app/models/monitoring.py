import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, Enum as SQLEnum, Text, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.database.base import Base


class EventSeverity(str, enum.Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    WARNING = "WARNING"
    INFO = "INFO"


class EventState(str, enum.Enum):
    NORMAL = "NORMAL"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    RECOVERED = "RECOVERED"


class MonitoringMetricType(str, enum.Enum):
    CPU = "CPU"
    MEMORY = "MEMORY"
    DISK = "DISK"
    LATENCY = "LATENCY"
    ERROR_RATE = "ERROR_RATE"
    SERVICE_DOWN = "SERVICE_DOWN"
    DRIFT_DETECTED = "DRIFT_DETECTED"
    HEALTH_SCORE_DROP = "HEALTH_SCORE_DROP"


class MonitoringThresholdRule(Base):
    """Configurable threshold rule for environment telemetry metrics."""
    __tablename__ = "monitoring_threshold_rules"

    name = Column(String, nullable=False, index=True)
    environment_id = Column(String, nullable=True, index=True)  # Null or 'ALL' for global
    metric_type = Column(
        SQLEnum(MonitoringMetricType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False,
        index=True
    )
    operator = Column(String, default=">", nullable=False)  # >, >=, <, <=, ==
    warning_threshold = Column(Float, nullable=False)
    critical_threshold = Column(Float, nullable=False)
    duration_minutes = Column(Integer, default=5, nullable=False)
    is_enabled = Column(Boolean, default=True, nullable=False)
    auto_heal_enabled = Column(Boolean, default=False, nullable=False)
    auto_heal_runbook_id = Column(String, nullable=True)

    # Multi-tenancy & governance
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)


class MonitoringEvent(Base):
    """Real-time event record with lifecycle state management (NORMAL -> WARNING -> CRITICAL -> RECOVERED)."""
    __tablename__ = "monitoring_events"

    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=False, index=True)
    target_type = Column(String, default="ENVIRONMENT", nullable=False)  # SERVER, SERVICE, DATABASE, ENVIRONMENT
    target_id = Column(String, nullable=True)
    target_name = Column(String, nullable=False)
    
    event_type = Column(
        SQLEnum(MonitoringMetricType, values_callable=lambda obj: [e.value for e in obj]),
        nullable=False,
        index=True
    )
    severity = Column(
        SQLEnum(EventSeverity, values_callable=lambda obj: [e.value for e in obj]),
        default=EventSeverity.WARNING,
        nullable=False
    )
    state = Column(
        SQLEnum(EventState, values_callable=lambda obj: [e.value for e in obj]),
        default=EventState.WARNING,
        nullable=False,
        index=True
    )
    title = Column(String, nullable=False)
    message = Column(Text, nullable=False)
    current_value = Column(Float, nullable=True)
    threshold_value = Column(Float, nullable=True)
    
    # Lifecycle Timestamps
    triggered_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    acknowledged_at = Column(DateTime(timezone=True), nullable=True)
    acknowledged_by = Column(String, nullable=True)
    recovered_at = Column(DateTime(timezone=True), nullable=True)
    
    # Impact & Remediation Linkage
    impact_metadata = Column(JSON, default=dict, nullable=False)
    linked_incident_id = Column(String, nullable=True)
    auto_heal_triggered = Column(Boolean, default=False, nullable=False)
    auto_heal_execution_id = Column(String, nullable=True)

    # Multi-tenancy & governance
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)


class TargetType(str, enum.Enum):
    LINUX_SERVER = "LINUX_SERVER"
    WINDOWS_SERVER = "WINDOWS_SERVER"
    APPLICATION = "APPLICATION"
    REST_API = "REST_API"
    MICROSERVICE = "MICROSERVICE"
    DATABASE = "DATABASE"
    CONTAINER = "CONTAINER"
    MIDDLEWARE = "MIDDLEWARE"
    CUSTOM = "CUSTOM"


class TargetStatus(str, enum.Enum):
    UP = "UP"
    DOWN = "DOWN"
    DEGRADED = "DEGRADED"
    UNREACHABLE = "UNREACHABLE"
    UNKNOWN = "UNKNOWN"


class ExporterType(str, enum.Enum):
    NODE_EXPORTER = "NODE_EXPORTER"
    WMI_EXPORTER = "WMI_EXPORTER"
    JVM_EXPORTER = "JVM_EXPORTER"
    DATABASE_EXPORTER = "DATABASE_EXPORTER"
    API_EXPORTER = "API_EXPORTER"
    BLACKBOX_EXPORTER = "BLACKBOX_EXPORTER"
    OTEL_COLLECTOR = "OTEL_COLLECTOR"
    CUSTOM = "CUSTOM"


class ExporterStatus(str, enum.Enum):
    EXPORTER_UP = "EXPORTER_UP"
    EXPORTER_DOWN = "EXPORTER_DOWN"
    DEGRADED = "DEGRADED"
    UNKNOWN = "UNKNOWN"


class ScrapeStatus(str, enum.Enum):
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    TIMEOUT = "TIMEOUT"
    STALE = "STALE"
    UNKNOWN = "UNKNOWN"


class ComponentType(str, enum.Enum):
    INFRASTRUCTURE = "INFRASTRUCTURE"
    APPLICATION = "APPLICATION"
    DATABASE = "DATABASE"
    SERVICE = "SERVICE"
    NETWORK = "NETWORK"


class MonitoringTarget(Base):
    """Monitored target entity (Server, Application, Database, API, Container)."""
    __tablename__ = "monitoring_targets"

    name = Column(String, nullable=False, index=True)
    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=False, index=True)
    application_name = Column(String, nullable=True, index=True)
    service_name = Column(String, nullable=True, index=True)
    server_name = Column(String, nullable=True, index=True)
    target_type = Column(String, default="LINUX_SERVER", nullable=False)
    endpoint_url = Column(String, nullable=False)
    scrape_interval_seconds = Column(Integer, default=15, nullable=False)
    scrape_timeout_seconds = Column(Integer, default=5, nullable=False)
    is_enabled = Column(Boolean, default=True, nullable=False)
    target_status = Column(String, default="UP", nullable=False)
    scrape_status = Column(String, default="SUCCESS", nullable=False)
    last_scrape_time = Column(DateTime(timezone=True), nullable=True)
    last_successful_scrape = Column(DateTime(timezone=True), nullable=True)
    last_failed_scrape = Column(DateTime(timezone=True), nullable=True)
    scrape_duration_ms = Column(Float, default=0.0, nullable=False)
    metrics_freshness_seconds = Column(Float, default=0.0, nullable=False)
    is_stale = Column(Boolean, default=False, nullable=False)
    error_message = Column(Text, nullable=True)
    labels = Column(JSON, default=dict, nullable=False)

    # Multi-tenancy & governance
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True)
    owner_id = Column(String, nullable=True)

    exporters = relationship("MonitoringExporter", back_populates="target", cascade="all, delete-orphan", lazy="selectin")


class MonitoringExporter(Base):
    """Exporter attached to a monitored target."""
    __tablename__ = "monitoring_exporters"

    target_id = Column(String, ForeignKey("monitoring_targets.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String, nullable=False, index=True)
    exporter_type = Column(String, default="NODE_EXPORTER", nullable=False)
    endpoint_url = Column(String, nullable=False)
    status = Column(String, default="EXPORTER_UP", nullable=False)
    version = Column(String, default="1.0.0", nullable=True)
    last_scrape_time = Column(DateTime(timezone=True), nullable=True)
    scrape_duration_ms = Column(Float, default=0.0, nullable=False)
    success_count = Column(Integer, default=0, nullable=False)
    failure_count = Column(Integer, default=0, nullable=False)
    error_message = Column(Text, nullable=True)

    target = relationship("MonitoringTarget", back_populates="exporters")


class TimeSeriesMetric(Base):
    """Persistent time-series metric sample for historical telemetry & queries."""
    __tablename__ = "monitoring_time_series_metrics"

    target_id = Column(String, nullable=True, index=True)
    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=False, index=True)
    component_type = Column(String, default="INFRASTRUCTURE", nullable=False, index=True)
    component_name = Column(String, nullable=False, index=True)
    metric_category = Column(String, nullable=False, index=True)
    metric_name = Column(String, nullable=False, index=True)
    metric_value = Column(Float, nullable=False)
    unit = Column(String, default="%", nullable=False)
    timestamp = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False, index=True)
    labels = Column(JSON, default=dict, nullable=False)


class CorrelatedIncident(Base):
    """Grouped enterprise incident derived from intelligent alert correlation."""
    __tablename__ = "monitoring_correlated_incidents"

    incident_code = Column(String, unique=True, index=True, nullable=False)
    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=False, index=True)
    title = Column(String, nullable=False)
    severity = Column(String, default="WARNING", nullable=False)
    status = Column(String, default="TRIGGERED", nullable=False, index=True)  # TRIGGERED, ACKNOWLEDGED, INVESTIGATING, RESOLVED
    root_cause_type = Column(String, default="INFRASTRUCTURE", nullable=False)
    root_cause_summary = Column(Text, nullable=False)
    recommended_action = Column(Text, nullable=True)
    correlated_alert_ids = Column(JSON, default=list, nullable=False)
    affected_components = Column(JSON, default=list, nullable=False)
    blast_radius_summary = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    acknowledged_at = Column(DateTime(timezone=True), nullable=True)
    acknowledged_by = Column(String, nullable=True)
    resolved_at = Column(DateTime(timezone=True), nullable=True)
    resolved_by = Column(String, nullable=True)


class MonitoringNotificationRule(Base):
    """Alert notification routing rule."""
    __tablename__ = "monitoring_notification_rules"

    name = Column(String, nullable=False, index=True)
    environment_id = Column(String, nullable=True, index=True)  # Null or 'ALL'
    min_severity = Column(String, default="WARNING", nullable=False)
    channel = Column(String, default="IN_APP", nullable=False)  # IN_APP, EMAIL, SLACK, WEBHOOK
    recipients = Column(String, nullable=False)
    is_enabled = Column(Boolean, default=True, nullable=False)
    template = Column(Text, nullable=True)


class TestExecutionCorrelationRecord(Base):
    """Correlation record between TEM test executions and live environment health."""
    __tablename__ = "monitoring_test_execution_correlations"

    test_run_id = Column(String, unique=True, index=True, nullable=False)
    test_suite_name = Column(String, nullable=False, index=True)
    test_phase = Column(String, default="SIT", nullable=False)
    environment_id = Column(String, nullable=False, index=True)
    environment_name = Column(String, nullable=False, index=True)
    started_at = Column(DateTime(timezone=True), nullable=False)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    status = Column(String, default="PASSED", nullable=False)  # PASSED, FAILED, RUNNING
    total_tests = Column(Integer, default=0, nullable=False)
    passed_tests = Column(Integer, default=0, nullable=False)
    failed_tests = Column(Integer, default=0, nullable=False)
    is_environment_caused = Column(Boolean, default=False, nullable=False)
    failure_root_cause = Column(Text, nullable=True)
    correlated_anomalies = Column(JSON, default=list, nullable=False)
    environment_health_at_run = Column(Float, default=100.0, nullable=False)

