from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import PlainTextResponse
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.common import StandardResponse
from app.schemas.monitoring import (
    FleetObservabilitySummary, EnvironmentDetailedObservability, HistoricalTelemetryOut,
    ThresholdRuleCreate, ThresholdRuleOut, MonitoringEventOut, RemediateEventRequest,
    MonitoringTargetCreate, MonitoringTargetOut, MonitoringExporterOut,
    CorrelatedIncidentOut, CorrelatedIncidentAcknowledgeRequest, CorrelatedIncidentResolveRequest,
    NotificationRuleCreate, NotificationRuleOut, CapacityForecastOut,
    TestExecutionCorrelationCreate, TestExecutionCorrelationOut, MonitoringSelfHealthOut,
    PrometheusTargetSD, PromQLInstantQueryRequest, PromQLRangeQueryRequest, PromQLQueryResponse,
    GrafanaDashboardSummary, GrafanaConfigOut, GrafanaConfigUpdate
)
from app.services.monitoring_service import monitoring_service
from app.services.health_check_service import health_check_service
from app.dependencies.auth import get_current_user_optional
from app.models.user import User


router = APIRouter(prefix="/monitoring", tags=["Enterprise Environment Observability"])


@router.get("/summary", response_model=StandardResponse[FleetObservabilitySummary])
async def get_fleet_observability_summary(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves fleet-wide executive environment observability summary,
    including health scores, test readiness, drift counts, and operational KPIs.
    """
    summary = await monitoring_service.get_fleet_observability_summary(db)
    return StandardResponse(
        success=True,
        message="Fleet observability summary retrieved successfully",
        data=summary
    )


@router.get("/environments/{env_id}", response_model=StandardResponse[EnvironmentDetailedObservability])
async def get_environment_observability(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves granular environment observability dossier, covering multi-tier health,
    test readiness reasons, configuration drift, active release impact, and auto-heal status.
    """
    dossier = await monitoring_service.get_environment_detailed_observability(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Environment observability retrieved for '{dossier.environment_name}'",
        data=dossier
    )


@router.get("/environments/{env_id}/trends", response_model=StandardResponse[HistoricalTelemetryOut])
async def get_historical_telemetry_trends(
    env_id: str,
    timeframe: str = Query("24h", description="Timeframe: 1h, 6h, 24h, 7d, 30d"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves historical metrics telemetry and health score trends across 1h, 6h, 24h, 7d, 30d timeframes.
    """
    trends = await monitoring_service.get_historical_telemetry(db, env_id, timeframe)
    return StandardResponse(
        success=True,
        message=f"Historical telemetry trends for '{timeframe}' retrieved successfully",
        data=trends
    )


@router.get("/events", response_model=StandardResponse[List[MonitoringEventOut]])
async def list_monitoring_events(
    state: Optional[str] = Query(None, description="Filter by event state: NORMAL, WARNING, CRITICAL, RECOVERED"),
    severity: Optional[str] = Query(None, description="Filter by severity: CRITICAL, WARNING, INFO"),
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists real-time threshold and observability events with state machine transitions.
    """
    events = await monitoring_service.get_monitoring_events(db, state=state, severity=severity, limit=limit)
    data = [MonitoringEventOut.model_validate(e) for e in events]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} monitoring events",
        data=data
    )


@router.post("/events/{event_id}/acknowledge", response_model=StandardResponse[Optional[MonitoringEventOut]])
async def acknowledge_monitoring_event(
    event_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Acknowledges an active threshold alert event.
    """
    user_name = getattr(current_user, "username", "Ops Engineer") if current_user else "Ops Engineer"
    event = await monitoring_service.acknowledge_event(db, event_id, user_name)
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Monitoring event not found")

    return StandardResponse(
        success=True,
        message="Monitoring event acknowledged successfully",
        data=MonitoringEventOut.model_validate(event)
    )


@router.post("/events/{event_id}/remediate", response_model=StandardResponse[dict])
async def remediate_monitoring_event(
    event_id: str,
    payload: Optional[RemediateEventRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Triggers Auto-Heal remediation for the event and performs closed-loop validation.
    """
    user_name = getattr(current_user, "username", "Ops Lead") if current_user else "Ops Lead"
    success, msg = await monitoring_service.remediate_event(db, event_id, user_name)

    return StandardResponse(
        success=success,
        message=msg,
        data={"event_id": event_id, "status": "RECOVERED" if success else "REMEDIATION_FAILED"}
    )


@router.get("/threshold-rules", response_model=StandardResponse[List[ThresholdRuleOut]])
async def list_threshold_rules(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists all configured telemetry threshold rules.
    """
    rules = await monitoring_service.get_threshold_rules(db)
    data = [ThresholdRuleOut.model_validate(r) for r in rules]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} threshold rules",
        data=data
    )


@router.post("/threshold-rules", response_model=StandardResponse[ThresholdRuleOut], status_code=status.HTTP_201_CREATED)
async def create_threshold_rule(
    payload: ThresholdRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Creates a new metric threshold rule.
    """
    rule = await monitoring_service.create_threshold_rule(db, payload)
    return StandardResponse(
        success=True,
        message=f"Threshold rule '{rule.name}' created successfully",
        data=ThresholdRuleOut.model_validate(rule)
    )


@router.post("/environments/{env_id}/health-check", response_model=StandardResponse[EnvironmentDetailedObservability])
async def trigger_environment_health_and_refresh(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Triggers an on-demand synthetic health check run and returns the freshly updated observability dossier.
    """
    user_name = getattr(current_user, "username", "Ops Tester") if current_user else "Ops Tester"
    await health_check_service.execute_environment_health_check(
        db=db,
        environment_id=env_id,
        triggered_by=user_name,
        trigger_type="MANUAL",
        auto_heal_if_critical=True
    )
    dossier = await monitoring_service.get_environment_detailed_observability(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Health check executed and observability refreshed for '{dossier.environment_name}'",
        data=dossier
    )


# =========================================================================
# MONITORING TARGETS & EXPORTERS ENDPOINTS
# =========================================================================

@router.get("/targets", response_model=StandardResponse[List[MonitoringTargetOut]])
async def list_monitoring_targets(
    environment_id: Optional[str] = Query(None, description="Filter by environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists registered monitoring targets, their scrape health, and attached exporters."""
    targets = await monitoring_service.get_targets(db, environment_id=environment_id)
    data = [MonitoringTargetOut.model_validate(t) for t in targets]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} monitoring targets",
        data=data
    )


@router.post("/targets", response_model=StandardResponse[MonitoringTargetOut], status_code=status.HTTP_201_CREATED)
async def register_monitoring_target(
    payload: MonitoringTargetCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Registers a new monitoring target with initial exporter."""
    target = await monitoring_service.register_target(db, payload)
    return StandardResponse(
        success=True,
        message=f"Monitoring target '{target.name}' registered successfully",
        data=MonitoringTargetOut.model_validate(target)
    )


@router.delete("/targets/{target_id}", response_model=StandardResponse[dict])
async def delete_monitoring_target(
    target_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Deletes a monitoring target and attached exporters."""
    deleted = await monitoring_service.delete_target(db, target_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Target not found")
    return StandardResponse(
        success=True,
        message="Monitoring target deleted successfully",
        data={"target_id": target_id}
    )


@router.get("/exporters", response_model=StandardResponse[List[MonitoringExporterOut]])
async def list_monitoring_exporters(
    target_id: Optional[str] = Query(None, description="Filter by target ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists monitoring exporters with health status."""
    exporters = await monitoring_service.get_exporters(db, target_id=target_id)
    data = [MonitoringExporterOut.model_validate(e) for e in exporters]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} exporters",
        data=data
    )


# =========================================================================
# METRICS SCRAPING ENDPOINTS
# =========================================================================

@router.post("/scrape/execute", response_model=StandardResponse[dict])
async def execute_metrics_scrape(
    target_id: Optional[str] = Query(None, description="Specific target ID to scrape; omit to scrape all targets"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Executes on-demand pull-based metrics scrape with error isolation."""
    if target_id:
        success, msg, data = await monitoring_service.scrape_target(db, target_id)
        return StandardResponse(
            success=success,
            message=msg,
            data=data
        )
    else:
        summary = await monitoring_service.scrape_all_active_targets(db)
        return StandardResponse(
            success=True,
            message=f"Scraped {summary['scraped_count']} active targets ({summary['success_count']} succeeded)",
            data=summary
        )


# =========================================================================
# INTELLIGENT CORRELATED INCIDENTS ENDPOINTS
# =========================================================================

@router.get("/incidents", response_model=StandardResponse[List[CorrelatedIncidentOut]])
async def list_correlated_incidents(
    environment_id: Optional[str] = Query(None, description="Filter by environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists correlated multi-tier incidents with automated root-cause analysis."""
    incidents = await monitoring_service.get_correlated_incidents(db, environment_id=environment_id)
    data = [CorrelatedIncidentOut.model_validate(i) for i in incidents]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} correlated incidents",
        data=data
    )


@router.post("/incidents/{incident_id}/acknowledge", response_model=StandardResponse[CorrelatedIncidentOut])
async def acknowledge_correlated_incident(
    incident_id: str,
    payload: Optional[CorrelatedIncidentAcknowledgeRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Acknowledges an active correlated incident."""
    user_name = payload.user_name if payload else (getattr(current_user, "username", "Ops Engineer") if current_user else "Ops Engineer")
    inc = await monitoring_service.acknowledge_correlated_incident(db, incident_id, user_name)
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Correlated incident not found")
    return StandardResponse(
        success=True,
        message=f"Correlated incident '{inc.incident_code}' acknowledged",
        data=CorrelatedIncidentOut.model_validate(inc)
    )


@router.post("/incidents/{incident_id}/resolve", response_model=StandardResponse[CorrelatedIncidentOut])
async def resolve_correlated_incident(
    incident_id: str,
    payload: Optional[CorrelatedIncidentResolveRequest] = None,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Resolves a correlated incident and records resolution notes."""
    user_name = payload.user_name if payload else (getattr(current_user, "username", "Ops Lead") if current_user else "Ops Lead")
    notes = payload.resolution_notes if payload else ""
    inc = await monitoring_service.resolve_correlated_incident(db, incident_id, user_name, notes)
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Correlated incident not found")
    return StandardResponse(
        success=True,
        message=f"Correlated incident '{inc.incident_code}' resolved",
        data=CorrelatedIncidentOut.model_validate(inc)
    )


# =========================================================================
# NOTIFICATION RULES ENDPOINTS
# =========================================================================

@router.get("/notification-rules", response_model=StandardResponse[List[NotificationRuleOut]])
async def list_notification_rules(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists alert notification routing rules."""
    rules = await monitoring_service.get_notification_rules(db)
    data = [NotificationRuleOut.model_validate(r) for r in rules]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} notification rules",
        data=data
    )


@router.post("/notification-rules", response_model=StandardResponse[NotificationRuleOut], status_code=status.HTTP_201_CREATED)
async def create_notification_rule(
    payload: NotificationRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Creates a new alert notification routing rule."""
    rule = await monitoring_service.create_notification_rule(db, payload)
    return StandardResponse(
        success=True,
        message=f"Notification rule '{rule.name}' created",
        data=NotificationRuleOut.model_validate(rule)
    )


# =========================================================================
# CAPACITY FORECASTING ENDPOINTS
# =========================================================================

@router.get("/environments/{env_id}/capacity", response_model=StandardResponse[List[CapacityForecastOut]])
async def get_environment_capacity_forecast(
    env_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Retrieves growth trend models and days-to-breach forecasts for Disk, Memory, and DB Pools."""
    forecasts = await monitoring_service.get_capacity_forecast(db, env_id)
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(forecasts)} capacity forecasts",
        data=forecasts
    )


# =========================================================================
# TEST EXECUTION CORRELATION ENDPOINTS
# =========================================================================

@router.get("/test-executions", response_model=StandardResponse[List[TestExecutionCorrelationOut]])
async def list_test_execution_correlations(
    environment_id: Optional[str] = Query(None, description="Filter by environment ID"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Lists test suite executions correlated with environment telemetry."""
    records = await monitoring_service.get_test_execution_correlations(db, env_id=environment_id)
    data = [TestExecutionCorrelationOut.model_validate(r) for r in records]
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(data)} test execution correlations",
        data=data
    )


@router.post("/test-executions/correlate", response_model=StandardResponse[TestExecutionCorrelationOut], status_code=status.HTTP_201_CREATED)
async def record_test_execution_correlation(
    payload: TestExecutionCorrelationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Records a test suite execution and diagnoses whether test failures were environment-caused."""
    record = await monitoring_service.record_test_execution_correlation(db, payload)
    return StandardResponse(
        success=True,
        message=f"Test execution '{record.test_run_id}' correlated with environment telemetry",
        data=TestExecutionCorrelationOut.model_validate(record)
    )


# =========================================================================
# MONITORING SELF-HEALTH ENDPOINTS
# =========================================================================

@router.get("/self-health", response_model=StandardResponse[MonitoringSelfHealthOut])
async def get_monitoring_self_health(
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Returns self-observability metrics of the monitoring platform itself."""
    health = await monitoring_service.get_self_health(db)
    return StandardResponse(
        success=True,
        message="Monitoring self-health retrieved successfully",
        data=health
    )


# =========================================================================
# PROMETHEUS SCRAPING, SD & PROMQL QUERY ENDPOINTS
# =========================================================================

@router.get("/prometheus/targets.json")
async def get_prometheus_http_service_discovery(
    db: AsyncSession = Depends(get_db)
):
    """
    Standard Prometheus HTTP Service Discovery endpoint (http_sd_config compatible).
    Enables external Prometheus servers to auto-discover all TEM test environments and exporter targets.
    """
    return await monitoring_service.get_prometheus_targets_sd(db)


@router.get("/prometheus/metrics", response_class=PlainTextResponse)
async def export_prometheus_metrics(
    db: AsyncSession = Depends(get_db)
):
    """
    Exposes TEM's own platform observability metrics in standard OpenMetrics/Prometheus exposition text format.
    Allows external Prometheus instances to scrape TEM fleet health, scraper duration, and active alert counters.
    """
    metrics_text = await monitoring_service.export_prometheus_metrics(db)
    return PlainTextResponse(content=metrics_text, media_type="text/plain; version=0.0.4; charset=utf-8")


@router.post("/prometheus/query", response_model=PromQLQueryResponse)
async def query_promql_instant(
    payload: PromQLInstantQueryRequest,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Evaluates instant PromQL expressions against live and historical time-series metrics.
    """
    return await monitoring_service.query_promql_instant(
        db, query=payload.query, time_val=payload.time, env_id=payload.environment_id
    )


@router.post("/prometheus/query_range", response_model=PromQLQueryResponse)
async def query_promql_range(
    payload: PromQLRangeQueryRequest,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Evaluates range PromQL expressions across a specified time window with step intervals.
    """
    import time
    start = payload.start or (time.time() - 3600.0)
    end = payload.end or time.time()
    step = payload.step or "15s"
    return await monitoring_service.query_promql_range(
        db, query=payload.query, start=start, end=end, step=step, env_id=payload.environment_id
    )


# =========================================================================
# GRAFANA DASHBOARD & CONFIGURATION ENDPOINTS
# =========================================================================

@router.get("/grafana/dashboards", response_model=StandardResponse[List[GrafanaDashboardSummary]])
async def list_grafana_dashboards(
    environment_id: Optional[str] = Query(None, description="Filter by environment ID"),
    environment_name: Optional[str] = Query(None, description="Filter by environment name"),
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lists pre-configured Grafana dashboard templates for Enterprise, Environment, Server, App, Database, and Test Correlation.
    """
    dashboards = monitoring_service.get_grafana_dashboards(env_id=environment_id, env_name=environment_name)
    return StandardResponse(
        success=True,
        message=f"Retrieved {len(dashboards)} Grafana dashboard templates",
        data=dashboards
    )


@router.get("/grafana/config", response_model=StandardResponse[GrafanaConfigOut])
async def get_grafana_config(
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Retrieves current Grafana server integration and embedding parameters.
    """
    cfg = monitoring_service.get_grafana_config()
    return StandardResponse(
        success=True,
        message="Grafana configuration retrieved successfully",
        data=cfg
    )


@router.put("/grafana/config", response_model=StandardResponse[GrafanaConfigOut])
async def update_grafana_config(
    payload: GrafanaConfigUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Updates Grafana server URL, authentication mode, and kiosk embedding settings.
    """
    cfg = monitoring_service.update_grafana_config(payload)
    return StandardResponse(
        success=True,
        message="Grafana configuration updated successfully",
        data=cfg
    )


