from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.schemas.common import StandardResponse
from app.schemas.assistant import (
    AssistantChatRequest,
    AssistantChatResponse,
    SuggestedPrompt,
    BotBookingRequest,
    BotBookingResult,
)
from app.services.assistant_service import assistant_service
from app.services.assistant_booking_agent import assistant_booking_agent

router = APIRouter(prefix="/assistant", tags=["Intelligent Conversational Assistant"])


@router.post("/chat", response_model=StandardResponse[AssistantChatResponse])
async def chat_with_assistant(
    request: AssistantChatRequest,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Conversational assistant endpoint for the complete TEM application.
    Supports Natural Language Queries for live Data Retrieval, Relational Drill-Downs,
    and TEM Functional Knowledge Base answers.
    """
    response_data = await assistant_service.process_message(
        db=db,
        request=request,
        current_user=current_user
    )
    return StandardResponse(
        success=True,
        message="Assistant response generated successfully",
        data=response_data
    )


@router.post("/book-environment", response_model=StandardResponse[BotBookingResult])
async def book_environment_via_bot(
    request: BotBookingRequest,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    """
    Executes an environment reservation directly from the assistant bot interface.
    Performs conflict detection, attaches workflows, and returns confirmed reservation ID.
    """
    result = await assistant_booking_agent.execute_booking(
        db=db,
        req=request,
        current_user=current_user
    )
    return StandardResponse(
        success=result.success,
        message=result.message if not result.success else f"Environment '{result.environment_name}' reserved successfully (Ref: #{result.reservation_id})",
        data=result
    )


@router.get("/suggested-prompts", response_model=StandardResponse[List[SuggestedPrompt]])
async def get_suggested_prompts():
    """
    Returns categorized starter suggestions for the chat interface.
    """
    prompts = [
        # Health & Monitoring
        SuggestedPrompt(category="Health", prompt="Which environments are currently down?"),
        SuggestedPrompt(category="Health", prompt="Which environments have high CPU usage?"),
        SuggestedPrompt(category="Health", prompt="Run health check sweep on SIT environments"),
        SuggestedPrompt(category="Health", prompt="Show fleet-wide test readiness scores"),

        # Bookings & Worklist
        SuggestedPrompt(category="Bookings", prompt="Which SIT environments are available right now?"),
        SuggestedPrompt(category="Bookings", prompt="Who booked SIT-01?"),
        SuggestedPrompt(category="Bookings", prompt="Show active bookings in my worklist"),
        SuggestedPrompt(category="Bookings", prompt="Are there any overlapping booking conflicts?"),

        # Diagnosis & Comparison
        SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01"),
        SuggestedPrompt(category="Diagnosis", prompt="What software versions are installed in SIT-01?"),
        SuggestedPrompt(category="Diagnosis", prompt="Is Python or Java mismatched across environments?"),
        SuggestedPrompt(category="Diagnosis", prompt="Show software diagnosis baseline results"),

        # Releases
        SuggestedPrompt(category="Releases", prompt="Show all upcoming releases"),
        SuggestedPrompt(category="Releases", prompt="Which environments are mapped to upcoming releases?"),
        SuggestedPrompt(category="Releases", prompt="What test phases are configured for Release R2026.11?"),
        SuggestedPrompt(category="Releases", prompt="Show release calendar and milestones"),

        # Demand & Capacity
        SuggestedPrompt(category="Demand", prompt="How many SIT environments will we need next month?"),
        SuggestedPrompt(category="Demand", prompt="Do we have enough environments for upcoming releases?"),
        SuggestedPrompt(category="Demand", prompt="What is our current capacity gap in UAT?"),
        SuggestedPrompt(category="Demand", prompt="Show predictive demand contention heatmap"),

        # How-To Guides
        SuggestedPrompt(category="How-To", prompt="How does booking conflict detection work?"),
        SuggestedPrompt(category="How-To", prompt="What does Auto-Heal do?"),
        SuggestedPrompt(category="How-To", prompt="How do I provision a new environment?"),
        SuggestedPrompt(category="How-To", prompt="What is the use of worklist?"),
        SuggestedPrompt(category="How-To", prompt="How does topology blast radius simulation work?"),
    ]
    return StandardResponse(
        success=True,
        message="Suggested prompts retrieved",
        data=prompts
    )
