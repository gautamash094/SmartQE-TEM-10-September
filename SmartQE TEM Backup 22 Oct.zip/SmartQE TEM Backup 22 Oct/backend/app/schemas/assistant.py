from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: str = Field(..., description="'user', 'assistant', or 'system'")
    content: str = Field(..., description="The message content text")
    timestamp: Optional[str] = Field(None, description="ISO timestamp")


class AssistantActionLink(BaseModel):
    label: str = Field(..., description="Action button display label")
    action_type: str = Field(..., description="e.g. 'NAVIGATE', 'RUN_HEALTH_CHECK', 'RUN_DIAGNOSIS', 'VIEW_DETAILS'")
    route: Optional[str] = Field(None, description="Frontend navigation route")
    params: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Action parameters")


class AssistantChatRequest(BaseModel):
    message: str = Field(..., description="User question or prompt in natural language")
    history: Optional[List[ChatMessage]] = Field(default_factory=list, description="Prior conversation messages")
    context_entity: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Active entity context (e.g. current page, environment_id)")
    provider: Optional[str] = Field(None, description="Preferred LLM provider: 'gemini', 'openai', 'ollama', or 'auto'")
    model: Optional[str] = Field(None, description="Specific model override (e.g. 'gemini-1.5-flash', 'gemini-1.5-pro', 'gpt-4o', 'gpt-4o-mini')")


class SuggestedPrompt(BaseModel):
    category: str = Field(..., description="Category: e.g. 'Health & Monitoring', 'Bookings', 'Releases', 'Diagnosis', 'Demand', 'How-To'")
    prompt: str = Field(..., description="Prompt text")
    icon: Optional[str] = Field(None, description="Lucide icon name identifier")


class AssistantChatResponse(BaseModel):
    reply: str = Field(..., description="Markdown-formatted assistant response")
    intent: str = Field(..., description="Detected intent key")
    category: str = Field(..., description="DATA_QUERY or FUNCTIONAL_KNOWLEDGE or AMBIGUOUS or ACTION or AI_ASSISTANT")
    entities: Dict[str, Any] = Field(default_factory=dict, description="Extracted entity mappings")
    suggested_prompts: Optional[List[SuggestedPrompt]] = Field(default_factory=list, description="Relevant follow-up prompts")
    action_links: Optional[List[AssistantActionLink]] = Field(default_factory=list, description="Executable or navigational action buttons")
    raw_data: Optional[Any] = Field(None, description="Optional raw structured data for visualization")


class BotBookingRequest(BaseModel):
    environment_id: str = Field(..., description="Target environment ID or unique name")
    environment_name: Optional[str] = Field(None, description="Target environment display name")
    start_date: str = Field(..., description="ISO 8601 or YYYY-MM-DD HH:MM:SS start datetime")
    end_date: str = Field(..., description="ISO 8601 or YYYY-MM-DD HH:MM:SS end datetime")
    purpose: str = Field(..., description="Booking purpose or testing goal")
    business_unit: Optional[str] = Field(None, description="Organizational Business Unit")
    project: Optional[str] = Field("", description="Project name")
    application: Optional[str] = Field("", description="Application name")
    team: Optional[str] = Field(None, description="Engineering/QA Team")
    reservation_mode: Optional[str] = Field("SHARED", description="'SHARED' or 'EXCLUSIVE'")
    priority: Optional[str] = Field("MEDIUM", description="'LOW', 'MEDIUM', 'HIGH', or 'CRITICAL'")
    requested_by: Optional[str] = Field(None, description="Booker username or name")


class BotBookingPreview(BaseModel):
    environment_id: str
    environment_name: str
    tier: str
    start_date: str
    end_date: str
    purpose: str
    reservation_mode: str
    business_unit: str
    team: str
    has_conflict: bool
    conflict_count: int
    conflict_summary: Optional[str] = None
    overlapping_reservations: Optional[List[Dict[str, Any]]] = None
    is_ready_to_book: bool


class BotBookingResult(BaseModel):
    success: bool
    message: str
    reservation_id: Optional[str] = None
    environment_name: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    status: Optional[str] = None
    reservation_mode: Optional[str] = None
    conflict_detected: bool = False
    conflict_details: Optional[List[str]] = None