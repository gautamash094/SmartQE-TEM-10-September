from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime
from pydantic import BaseModel, ConfigDict
from app.models.monitoring import EventSeverity, EventState, MonitoringMetricType


class HealthCategoryScores(BaseModel):
    infrastructure: float = 100.0
    application: float = 100.0
    database: float = 100.0
    services: float = 100.0
    configuration: float = 100.0
    overall_health_score: float = 100.0
    status: str = "HEALTHY"
    status_details: str = "All systems operational"


class EnvironmentReadinessCheck(BaseModel):
    environment_available: bool = True
    servers_online: bool = True
    services_healthy: bool = True
    database_connected: bool = True
    no_version_drift: bool = True
    no_blocking_incidents: bool = True
    no_maintenance_block: bool = True
    no_booking_collision: bool = True


class EnvironmentReadinessResult(BaseModel):
    status: str = "READY_FOR_TESTING"  # READY_FOR_TESTING, PARTIALLY_READY, NOT_READY
    score: int = 100
    passed_count: int = 8
    total_count: int = 8
    checks: EnvironmentReadinessCheck
    reasons: List[str] = []


class SoftwareDriftSummary(BaseModel):
    total_software: int = 0
    matching: int = 0
    version_mismatch: int = 0
    missing: int = 0
    outdated: int = 0
    consistency_health_score: float = 100.0
    has_drift: bool = False


class ReleaseImpactSummary(BaseModel):
    has_active_workload: bool = False
    impacted_application: Optional[str] = None
    impacted_release: Optional[str] = None
    impacted_phase: Optional[str] = None
    active_bookings_count: int = 0
    affected_teams: List[str] = []
    affected_users_count: int = 0
    impact_level: str = "NONE"  # NONE, LOW, MEDIUM, HIGH, CRITICAL


class AutoHealActionSummary(BaseModel):
    is_auto_heal_available: bool = False
    rule_id: Optional[str] = None
    rule_name: Optional[str] = None
    action_type: Optional[str] = None
    action_target: Optional[str] = None
    requires_approval: bool = False
    last_execution_status: Optional[str] = None


class PredictiveInsightOut(BaseModel):
    insight_type: str  # CAPACITY_WARNING, FLAPPING_WARNING, PERFORMANCE_DEGRADATION, DRIFT_RISK
    severity: str  # INFO, WARNING, CRITICAL
    target: str
    message: str
    predicted_breach_timeline: Optional[str] = None
    confidence_score: float = 0.85
    recommended_action: str


class EnvironmentDetailedObservability(BaseModel):
    environment_id: str
    environment_name: str
    tier: str
    owner: str
    team: str
    current_status: str
    uptime: float = 99.9
    
    # Live Health & Tier Breakdown
    health: HealthCategoryScores
    readiness: EnvironmentReadinessResult
    
    # Telemetry Instantaneous Values
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    storage_usage: float = 0.0
    network_latency_ms: float = 25.0
    api_p95_ms: float = 120.0
    error_rate_pct: float = 0.0
    
    # Configuration & Software Drift Summary
    drift_summary: SoftwareDriftSummary
    
    # Business & Release Context
    impact_summary: ReleaseImpactSummary
    
    # Autonomous Healing Integration
    auto_heal: AutoHealActionSummary
    
    # Predictive Analytics
    predictive_insights: List[PredictiveInsightOut] = []
    
    # Active Alerts Count
    active_critical_alerts: int = 0
    active_warning_alerts: int = 0
    active_correlated_incidents: int = 0
    last_health_check_time: Optional[datetime] = None

    # Scrape & Freshness Telemetry
    data_freshness_seconds: float = 0.0
    is_data_stale: bool = False
    last_scrape_duration_ms: float = 45.0
    scraper_health: str = "HEALTHY"


class FleetObservabilityKPIs(BaseModel):
    total_monitored_environments: int = 0
    healthy_environments: int = 0
    degraded_environments: int = 0
    unhealthy_environments: int = 0
    unavailable_environments: int = 0
    maintenance_environments: int = 0
    ready_for_testing_environments: int = 0
    readiness_rate_pct: float = 100.0
    environments_with_drift: int = 0
    environments_with_active_releases: int = 0
    fleet_average_health_score: float = 100.0
    fleet_availability_pct: float = 99.9
    mean_time_to_recovery_minutes: float = 18.5
    auto_heal_success_rate_pct: float = 92.0
    active_critical_events: int = 0
    active_warning_events: int = 0
    active_correlated_incidents: int = 0
    active_targets_count: int = 0
    active_exporters_count: int = 0
    stale_metrics_count: int = 0
    scraper_success_rate_pct: float = 99.4


class FleetObservabilitySummary(BaseModel):
    kpis: FleetObservabilityKPIs
    environments: List[EnvironmentDetailedObservability]
    recent_events: List[Any] = []
    predictive_alerts: List[PredictiveInsightOut] = []
    correlated_incidents: List[Any] = []


class MetricDataPoint(BaseModel):
    timestamp: str
    value: float


class MetricSeriesOut(BaseModel):
    metric_name: str
    unit: str
    points: List[MetricDataPoint]
    current: float
    avg: float
    peak: float
    min: float


class HistoricalTelemetryOut(BaseModel):
    environment_id: str
    environment_name: str
    timeframe: str
    cpu: MetricSeriesOut
    memory: MetricSeriesOut
    disk: MetricSeriesOut
    network_latency: MetricSeriesOut
    response_time: MetricSeriesOut
    error_rate: MetricSeriesOut
    health_score_trend: MetricSeriesOut


class ThresholdRuleCreate(BaseModel):
    name: str
    environment_id: Optional[str] = None
    metric_type: MonitoringMetricType
    operator: str = ">"
    warning_threshold: float
    critical_threshold: float
    duration_minutes: int = 5
    is_enabled: bool = True
    auto_heal_enabled: bool = False
    auto_heal_runbook_id: Optional[str] = None


class ThresholdRuleOut(BaseModel):
    id: str
    name: str
    environment_id: Optional[str] = None
    metric_type: str
    operator: str
    warning_threshold: float
    critical_threshold: float
    duration_minutes: int
    is_enabled: bool
    auto_heal_enabled: bool
    auto_heal_runbook_id: Optional[str] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class MonitoringEventOut(BaseModel):
    id: str
    environment_id: str
    environment_name: str
    target_type: str
    target_id: Optional[str] = None
    target_name: str
    event_type: str
    severity: str
    state: str
    title: str
    message: str
    current_value: Optional[float] = None
    threshold_value: Optional[float] = None
    triggered_at: datetime
    acknowledged_at: Optional[datetime] = None
    acknowledged_by: Optional[str] = None
    recovered_at: Optional[datetime] = None
    impact_metadata: Dict[str, Any] = {}
    linked_incident_id: Optional[str] = None
    auto_heal_triggered: bool = False
    auto_heal_execution_id: Optional[str] = None
    model_config = ConfigDict(from_attributes=True)


class RemediateEventRequest(BaseModel):
    rule_id: Optional[str] = None
    action_type: Optional[str] = "SERVICE_RESTART"
    notes: Optional[str] = "Manual remediation triggered from Monitoring Observability Console"


# --- MONITORING TARGET & EXPORTER SCHEMAS ---

class MonitoringExporterOut(BaseModel):
    id: str
    target_id: str
    name: str
    exporter_type: str
    endpoint_url: str
    status: str
    version: Optional[str] = "1.0.0"
    last_scrape_time: Optional[datetime] = None
    scrape_duration_ms: float = 0.0
    success_count: int = 0
    failure_count: int = 0
    error_message: Optional[str] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class MonitoringExporterCreate(BaseModel):
    name: str
    exporter_type: str = "NODE_EXPORTER"
    endpoint_url: str
    version: Optional[str] = "1.0.0"


class MonitoringTargetCreate(BaseModel):
    name: str
    environment_id: str
    environment_name: str
    application_name: Optional[str] = None
    service_name: Optional[str] = None
    server_name: Optional[str] = None
    target_type: str = "LINUX_SERVER"
    endpoint_url: str
    scrape_interval_seconds: int = 15
    scrape_timeout_seconds: int = 5
    is_enabled: bool = True
    labels: Dict[str, Any] = {}
    exporters: List[MonitoringExporterCreate] = []


class MonitoringTargetOut(BaseModel):
    id: str
    name: str
    environment_id: str
    environment_name: str
    application_name: Optional[str] = None
    service_name: Optional[str] = None
    server_name: Optional[str] = None
    target_type: str
    endpoint_url: str
    scrape_interval_seconds: int
    scrape_timeout_seconds: int
    is_enabled: bool
    target_status: str
    scrape_status: str
    last_scrape_time: Optional[datetime] = None
    last_successful_scrape: Optional[datetime] = None
    last_failed_scrape: Optional[datetime] = None
    scrape_duration_ms: float
    metrics_freshness_seconds: float
    is_stale: bool
    error_message: Optional[str] = None
    labels: Dict[str, Any] = {}
    exporters: List[MonitoringExporterOut] = []
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


# --- TIME-SERIES METRICS SCHEMAS ---

class TimeSeriesMetricSampleOut(BaseModel):
    id: str
    target_id: Optional[str] = None
    environment_id: str
    environment_name: str
    component_type: str
    component_name: str
    metric_category: str
    metric_name: str
    metric_value: float
    unit: str
    timestamp: datetime
    labels: Dict[str, Any] = {}
    model_config = ConfigDict(from_attributes=True)


class TimeSeriesQueryRequest(BaseModel):
    environment_id: str
    metric_names: Optional[List[str]] = None
    component_name: Optional[str] = None
    timeframe: str = "24h"


# --- CORRELATED INCIDENTS SCHEMAS ---

class CorrelatedIncidentOut(BaseModel):
    id: str
    incident_code: str
    environment_id: str
    environment_name: str
    title: str
    severity: str
    status: str
    root_cause_type: str
    root_cause_summary: str
    recommended_action: Optional[str] = None
    correlated_alert_ids: List[str] = []
    affected_components: List[str] = []
    blast_radius_summary: Optional[str] = None
    created_at: datetime
    acknowledged_at: Optional[datetime] = None
    acknowledged_by: Optional[str] = None
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[str] = None
    model_config = ConfigDict(from_attributes=True)


class CorrelatedIncidentAcknowledgeRequest(BaseModel):
    user_name: Optional[str] = "Ops Engineer"


class CorrelatedIncidentResolveRequest(BaseModel):
    user_name: Optional[str] = "Ops Lead"
    resolution_notes: Optional[str] = "Incident resolved and root cause mitigated"


# --- NOTIFICATION RULES SCHEMAS ---

class NotificationRuleCreate(BaseModel):
    name: str
    environment_id: Optional[str] = None
    min_severity: str = "WARNING"
    channel: str = "IN_APP"
    recipients: str
    is_enabled: bool = True
    template: Optional[str] = None


class NotificationRuleOut(BaseModel):
    id: str
    name: str
    environment_id: Optional[str] = None
    min_severity: str
    channel: str
    recipients: str
    is_enabled: bool
    template: Optional[str] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


# --- CAPACITY FORECASTING SCHEMAS ---

class CapacityForecastOut(BaseModel):
    environment_id: str
    environment_name: str
    metric_name: str
    current_value: float
    unit: str
    warning_threshold: float
    critical_threshold: float
    growth_rate_daily: float
    days_to_warning_breach: Optional[int] = None
    days_to_critical_breach: Optional[int] = None
    projected_breach_date: Optional[str] = None
    capacity_health: str  # HEALTHY, APPROACHING_LIMIT, CRITICAL
    recommendation: str


# --- TEST EXECUTION CORRELATION SCHEMAS ---

class TestExecutionCorrelationCreate(BaseModel):
    test_run_id: str
    test_suite_name: str
    test_phase: str = "SIT"
    environment_id: str
    environment_name: str
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    status: str = "PASSED"
    total_tests: int = 0
    passed_tests: int = 0
    failed_tests: int = 0


class TestExecutionCorrelationOut(BaseModel):
    id: str
    test_run_id: str
    test_suite_name: str
    test_phase: str
    environment_id: str
    environment_name: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    status: str
    total_tests: int
    passed_tests: int
    failed_tests: int
    is_environment_caused: bool
    failure_root_cause: Optional[str] = None
    correlated_anomalies: List[Dict[str, Any]] = []
    environment_health_at_run: float
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


# --- MONITORING SELF-HEALTH SCHEMAS ---

class MonitoringSelfHealthOut(BaseModel):
    service_status: str = "HEALTHY"
    scraper_status: str = "RUNNING"
    collector_status: str = "HEALTHY"
    query_engine_status: str = "HEALTHY"
    active_targets_count: int = 0
    active_exporters_count: int = 0
    scrape_success_rate_pct: float = 99.8
    avg_scrape_duration_ms: float = 38.5
    stored_metric_samples_count: int = 0
    metrics_retention_days: int = 30
    queue_backlog_size: int = 0
    uptime_seconds: float = 86400.0
    storage_engine: str = "SQLAlchemy Async Time-Series Engine"
    last_scraper_run: datetime


# =========================================================================
# PROMETHEUS & GRAFANA INTEGRATION SCHEMAS
# =========================================================================

class PrometheusTargetSD(BaseModel):
    """Prometheus HTTP Service Discovery item (http_sd_config compatible)."""
    targets: List[str]
    labels: Dict[str, str] = {}


class PromQLInstantQueryRequest(BaseModel):
    """Instant PromQL evaluation request."""
    query: str
    time: Optional[float] = None
    environment_id: Optional[str] = None


class PromQLRangeQueryRequest(BaseModel):
    """Range PromQL evaluation request across a time window."""
    query: str
    start: Optional[float] = None
    end: Optional[float] = None
    step: Optional[str] = "15s"
    environment_id: Optional[str] = None


class PromQLMetricResult(BaseModel):
    """A single time series result from a PromQL query."""
    metric: Dict[str, str] = {}
    value: Optional[Tuple[float, str]] = None  # [timestamp, value_str]
    values: Optional[List[Tuple[float, str]]] = None  # [[timestamp, value_str], ...]


class PromQLDataBody(BaseModel):
    resultType: str = "matrix"  # matrix, vector, scalar, string
    result: List[PromQLMetricResult] = []


class PromQLQueryResponse(BaseModel):
    """Standard Prometheus Query API response wrapper."""
    status: str = "success"  # success, error
    data: PromQLDataBody
    errorType: Optional[str] = None
    error: Optional[str] = None


class GrafanaDashboardSummary(BaseModel):
    """Metadata for an integrated Grafana dashboard."""
    id: str
    uid: str
    title: str
    category: str  # ENTERPRISE, ENVIRONMENT, SERVER, APPLICATION, DATABASE, TEST_CORRELATION
    description: str
    tags: List[str] = []
    embed_url: str
    external_url: Optional[str] = None
    is_starred: bool = False


class GrafanaConfigOut(BaseModel):
    """Grafana server connection and embedding settings."""
    server_url: str = "http://localhost:3000"
    is_connected: bool = True
    auth_type: str = "ANONYMOUS"  # ANONYMOUS, API_KEY, SERVICE_ACCOUNT
    organization_id: int = 1
    default_theme: str = "dark"
    kiosk_mode: bool = True
    sync_interval_seconds: int = 15


class GrafanaConfigUpdate(BaseModel):
    """Grafana server configuration update."""
    server_url: str
    auth_type: Optional[str] = "ANONYMOUS"
    api_key: Optional[str] = None
    organization_id: Optional[int] = 1
    default_theme: Optional[str] = "dark"
    kiosk_mode: Optional[bool] = True

