"""
SmartQE TEM Assistant Booking Agent.
Handles conversational slot-filling, natural language date/time parsing,
pre-flight conflict verification, and direct in-chat environment reservation execution.
"""
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy.ext.asyncio import AsyncSession

# from app.dao.environment_dao import environment_dao
from app.dao.reservation_dao import reservation_dao
from app.dao.workflow_dao import workflow_dao
from app.dependencies.auth import is_user_super_admin
from app.models.environment import Environment
from app.models.reservation import ReservationMode, ReservationPriority, ReservationStatus
from app.models.user import User
from app.services.assistant_env_helper import (
    get_all_unified_environments,
    match_environment_in_text,
    UnifiedEnvironment,
)
from app.schemas.assistant import (
    AssistantActionLink,
    AssistantChatResponse,
    BotBookingPreview,
    BotBookingRequest,
    BotBookingResult,
    SuggestedPrompt,
)
from app.schemas.reservation import ReservationCreate
from app.services.reservation_service import reservation_service

logger = logging.getLogger("tem.assistant.booking_agent")



class AssistantBookingAgent:
    """
    Dedicated agent managing conversational environment reservations.
    """

    def is_booking_request(self, query: str) -> bool:
        """Determines if a natural language query is attempting to make a reservation."""
        q = query.lower().strip()
        # Explicit reservation verbs
        booking_triggers = [
            "book ", "reserve ", "reservation for", "schedule ",
            "make a booking", "create a booking", "create reservation",
            "i want to book", "can i book", "can i reserve", "need to book",
            "want to reserve", "book environment", "reserve environment"
        ]
        # Avoid simple questions like "who booked SIT-01" or "show active bookings"
        inquiry_triggers = [
            "who booked", "is it booked", "show bookings", "list bookings",
            "active bookings", "booking history", "booking conflicts",
            "how does booking", "what is a booking"
        ]
        if any(inq in q for inq in inquiry_triggers):
            return False

        return any(trig in q for trig in booking_triggers) or q.startswith("book") or q.startswith("reserve")

    async def handle_conversational_booking(
        self,
        db: AsyncSession,
        query: str,
        history: List[Any],
        resolved_context: Dict[str, Any],
        current_user: Optional[User] = None
    ) -> AssistantChatResponse:
        """
        Parses slots, performs pre-flight conflict check, and generates preview card.
        """
        # 1. Fetch unified environments (EnvironmentProfile from Environment Details + legacy Environments)
        all_envs = await get_all_unified_environments(db)

        # 2. Target Environment Resolution
        target_env = self._extract_environment(query, all_envs, resolved_context)

        # 3. Date & Time Window Resolution
        start_dt, end_dt, time_label = self._extract_time_window(query)

        # 4. Purpose Resolution
        purpose = self._extract_purpose(query)

        # 5. Mode & Priority
        is_exclusive = any(m in query.lower() for m in ["exclusive", "disruptive", "dedicated", "sole"])
        mode = "DISRUPTIVE" if is_exclusive else "SHARED"

        # If environment is not specified, ask user to select one
        if not target_env:
            available_env_names = [e.name for e in all_envs if getattr(e, "is_active", True)][:8]
            reply = f"""I can help you reserve a test environment! 📅

Which environment would you like to book?

**Available in Fleet**: {', '.join([f'`{name}`' for name in available_env_names])}

*Example*: *"Book {available_env_names[0] if available_env_names else 'QA-01'} tomorrow from 10:00 to 16:00 for Regression Testing"*"""
            return AssistantChatResponse(
                reply=reply,
                intent="BOOKING_PROMPT_ENV",
                category="ACTION",
                suggested_prompts=[
                    SuggestedPrompt(category="Bookings", prompt=f"Book {name} tomorrow 10am to 4pm" if name else "Book QA-01")
                    for name in available_env_names[:3]
                ],
                action_links=[AssistantActionLink(label="View Bookings Calendar", action_type="NAVIGATE", route="/bookings")]
            )

        # 6. Pre-Flight Conflict Check
        res_mode_enum = ReservationMode.DISRUPTIVE if is_exclusive else ReservationMode.SHARED
        conflicts = await reservation_dao.check_conflicts(
            db, target_env.id, start_dt, end_dt, reservation_mode=res_mode_enum
        )

        has_conflict = len(conflicts) > 0
        conflict_summaries = []
        for c in conflicts:
            st = c.start_date.strftime("%b %d %H:%M") if getattr(c, "start_date", None) else "N/A"
            et = c.end_date.strftime("%b %d %H:%M") if getattr(c, "end_date", None) else "N/A"
            c_label = getattr(c, "purpose", None) or getattr(c, "id", "Existing Reservation")
            conflict_summaries.append(f"Overlaps with '{c_label}' ({st} - {et})")

        # 6. Default Metadata & Workflow Alignment
        bu_name = getattr(target_env, "business_unit", None) or "Enterprise QA"
        app_name = getattr(target_env, "application", "") or ""
        team_name = getattr(target_env, "team", None) or (getattr(current_user, "team", None) if current_user else "QA Core")
        user_name = (
            getattr(current_user, "full_name", None)
            or getattr(current_user, "username", None)
            or (context.get("user_name") if isinstance(context, dict) else None)
            or "TEM Bot User"
        )

        try:
            wf_res = await workflow_dao.get_active_workflow_for_reservation(
                db,
                environment_id=target_env.id,
                environment_name=target_env.name,
                service_code="ENVIRONMENT_RESERVATION"
            )
            if wf_res:
                if wf_res.business_unit and wf_res.business_unit.name:
                    bu_name = wf_res.business_unit.name
                elif wf_res.bu_id:
                    bu_name = wf_res.bu_id
                if wf_res.application_name:
                    app_name = wf_res.application_name
                elif wf_res.application_id:
                    app_name = wf_res.application_id
        except Exception:
            pass

        booking_req = BotBookingRequest(
            environment_id=target_env.id,
            environment_name=target_env.name,
            start_date=start_dt.strftime("%Y-%m-%d %H:%M:%S"),
            end_date=end_dt.strftime("%Y-%m-%d %H:%M:%S"),
            purpose=purpose,
            business_unit=bu_name,
            project="",
            application=app_name,
            team=team_name,
            reservation_mode=mode,
            priority="MEDIUM",
            requested_by=user_name
        )

        preview_card = BotBookingPreview(
            environment_id=target_env.id,
            environment_name=target_env.name,
            tier=target_env.tier.value if hasattr(target_env.tier, "value") else str(target_env.tier),
            start_date=start_dt.strftime("%Y-%m-%d %H:%M"),
            end_date=end_dt.strftime("%Y-%m-%d %H:%M"),
            purpose=purpose,
            reservation_mode=mode,
            business_unit=bu_name,
            team=team_name,
            has_conflict=has_conflict,
            conflict_count=len(conflicts),
            conflict_summary="; ".join(conflict_summaries) if conflict_summaries else "Zero conflicts. Free for reservation.",
            is_ready_to_book=True
        )

        # Markdown reply formulation
        status_badge = "⚠️ **Conflict Detected**" if has_conflict else "🟢 **Available (No Conflicts)**"
        conflict_note = f"\n> ⚠️ *Note: {'; '.join(conflict_summaries)}*" if has_conflict else ""

        reply = f"""### 📋 Booking Request Summary

Ready to reserve **{target_env.name}** (`{preview_card.tier}`):

| Property | Details |
| :--- | :--- |
| **Target Environment** | **{target_env.name}** |
| **Window** | `{start_dt.strftime('%b %d, %Y %H:%M')}` to `{end_dt.strftime('%H:%M')} UTC` ({time_label}) |
| **Purpose** | {purpose} |
| **Reservation Mode** | `{mode}` |
| **Pre-Flight Conflict** | {status_badge} |
{conflict_note}

Click **Confirm & Reserve Now** below to finalize this booking directly."""

        return AssistantChatResponse(
            reply=reply,
            intent="BOOKING_PREVIEW",
            category="ACTION",
            entities={
                "environment_id": target_env.id,
                "environment_name": target_env.name,
                "has_conflict": has_conflict
            },
            suggested_prompts=[
                SuggestedPrompt(category="Bookings", prompt=f"Show all bookings on {target_env.name}"),
                SuggestedPrompt(category="Health", prompt=f"Run health check on {target_env.name}"),
            ],
            action_links=[
                AssistantActionLink(
                    label="✅ Confirm & Reserve Now",
                    action_type="EXECUTE_BOOKING",
                    params=booking_req.model_dump()
                ),
                AssistantActionLink(
                    label="Open Bookings Calendar",
                    action_type="NAVIGATE",
                    route="/bookings"
                )
            ],
            raw_data={
                "booking_preview": preview_card.model_dump(),
                "booking_request": booking_req.model_dump()
            }
        )

    async def execute_booking(
        self,
        db: AsyncSession,
        req: BotBookingRequest,
        current_user: Optional[User] = None
    ) -> BotBookingResult:
        """
        Executes the reservation creation via reservation_service.
        """
        try:
            # Parse dates
            st_dt = self._parse_iso_or_str(req.start_date)
            et_dt = self._parse_iso_or_str(req.end_date)

            mode_str = (req.reservation_mode or "").upper()
            mode_val = ReservationMode.DISRUPTIVE if mode_str in ("EXCLUSIVE", "DISRUPTIVE") else ReservationMode.SHARED
            priority_val = ReservationPriority.MEDIUM
            if (req.priority or "").upper() in ("LOW", "HIGH", "CRITICAL"):
                priority_val = ReservationPriority[(req.priority or "").upper()]

            bu_final = req.business_unit or "Enterprise QA"
            app_final = req.application or ""

            try:
                wf_res = await workflow_dao.get_active_workflow_for_reservation(
                    db,
                    environment_id=req.environment_id,
                    environment_name=req.environment_name,
                    service_code="ENVIRONMENT_RESERVATION"
                )
                if wf_res:
                    if not req.business_unit or req.business_unit == "Enterprise QA":
                        bu_final = wf_res.business_unit.name if (wf_res.business_unit and wf_res.business_unit.name) else wf_res.bu_id
                    if not req.application:
                        app_final = wf_res.application_name or wf_res.application_id or ""
            except Exception:
                pass

            res_create = ReservationCreate(
                environment_id=req.environment_id,
                environment_name=req.environment_name or req.environment_id,
                business_unit=bu_final,
                project=req.project or "",
                application=app_final,
                purpose=req.purpose or "Automated Test Execution",
                team=req.team or "QA Core",
                requested_by=req.requested_by or (getattr(current_user, "username", "TEM Assistant User")),
                priority=priority_val,
                start_date=st_dt,
                end_date=et_dt,
                status=ReservationStatus.CONFIRMED,
                reservation_mode=mode_val
            )

            # System Admin users are not permitted to create reservations by TEM business rule.
            # If current_user is Super Admin, execute on behalf of requested_by user without super-admin block.
            creator_user = current_user
            if current_user and is_user_super_admin(current_user):
                creator_user = None
                if req.requested_by:
                    try:
                        from app.dao.user_dao import user_dao
                        matched = await user_dao.get_by_username(db, req.requested_by)
                        if not matched:
                            matched = await user_dao.get_by_email(db, req.requested_by)
                        if matched and not is_user_super_admin(matched):
                            creator_user = matched
                    except Exception:
                        pass

            created_res, msg = await reservation_service.create_reservation(
                db=db,
                res_in=res_create,
                current_user=creator_user
            )

            return BotBookingResult(
                success=True,
                message=msg or "Environment reserved successfully",
                reservation_id=str(created_res.id),
                environment_name=created_res.environment_name,
                start_time=created_res.start_date.strftime("%Y-%m-%d %H:%M:%S") if created_res.start_date else None,
                end_time=created_res.end_date.strftime("%Y-%m-%d %H:%M:%S") if created_res.end_date else None,
                status=created_res.status.value if hasattr(created_res.status, "value") else str(created_res.status),
                reservation_mode=created_res.reservation_mode.value if hasattr(created_res.reservation_mode, "value") else str(created_res.reservation_mode),
                conflict_detected=getattr(created_res, "conflict_detected", False),
            )
        except Exception as e:
            logger.error(f"Failed to execute bot booking: {e}", exc_info=True)
            return BotBookingResult(
                success=False,
                message=str(e),
                environment_name=req.environment_name or req.environment_id
            )

    # -------------------------------------------------------------------------
    # Helper Parsing Methods
    # -------------------------------------------------------------------------
    def _extract_environment(
        self,
        query: str,
        all_envs: List[Any],
        resolved_context: Dict[str, Any]
    ) -> Optional[Any]:
        # 1. Match from text using resilient matcher (word-boundary & normalized)
        matched = match_environment_in_text(query, all_envs)
        if matched:
            return matched

        # 2. Context match
        if "environment" in resolved_context:
            return resolved_context["environment"]
        if "environment_name" in resolved_context:
            c_name = resolved_context["environment_name"].upper()
            for env in all_envs:
                if env.name.upper() == c_name:
                    return env

        return None

    def _extract_time_window(self, query: str) -> Tuple[datetime, datetime, str]:
        """
        Parses relative & absolute dates with fallback to tomorrow 09:00 - 17:00 UTC.
        """
        now = datetime.now(timezone.utc)
        q = query.lower()

        # Target Base Date
        target_day = now + timedelta(days=1)  # Default: tomorrow
        label = "Tomorrow"

        if "today" in q:
            target_day = now
            label = "Today"
        elif "day after tomorrow" in q:
            target_day = now + timedelta(days=2)
            label = "Day After Tomorrow"
        elif "next week" in q:
            target_day = now + timedelta(days=7)
            label = "Next Week"
        else:
            # Check days of week (e.g. next monday, on friday)
            days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
            for idx, d in enumerate(days):
                if d in q:
                    curr_weekday = now.weekday()
                    days_ahead = (idx - curr_weekday) % 7
                    if days_ahead == 0:
                        days_ahead = 7
                    target_day = now + timedelta(days=days_ahead)
                    label = f"Next {d.capitalize()}"
                    break

        # Check explicit date (e.g. 2026-10-15 or Oct 15)
        date_match = re.search(r"\b(20\d{2}-\d{2}-\d{2})\b", query)
        if date_match:
            try:
                parsed_d = datetime.strptime(date_match.group(1), "%Y-%m-%d").replace(tzinfo=timezone.utc)
                target_day = parsed_d
                label = date_match.group(1)
            except ValueError:
                pass

        # Time extraction (e.g. "from 10:00 to 16:00", "10am to 4pm", "9 to 5", "10 to 16")
        start_hour, start_min = 9, 0
        end_hour, end_min = 17, 0

        # Pattern 1: HH:MM to HH:MM (e.g. 10:00 to 16:00)
        time_hhmm = re.search(r"\b(\d{1,2}):(\d{2})\s*(?:to|-)\s*(\d{1,2}):(\d{2})\b", q)
        if time_hhmm:
            start_hour, start_min = int(time_hhmm.group(1)), int(time_hhmm.group(2))
            end_hour, end_min = int(time_hhmm.group(3)), int(time_hhmm.group(4))
        else:
            # Pattern 2: 10am to 4pm / 10 to 4
            time_ampm = re.search(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*(?:to|-)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b", q)
            if time_ampm:
                sh = int(time_ampm.group(1))
                sm = int(time_ampm.group(2) or 0)
                sampm = time_ampm.group(3)

                eh = int(time_ampm.group(4))
                em = int(time_ampm.group(5) or 0)
                eampm = time_ampm.group(6)

                if sampm == "pm" and sh < 12:
                    sh += 12
                if eampm == "pm" and eh < 12:
                    eh += 12
                elif not eampm and eh < 12 and eh <= sh:
                    eh += 12  # "from 10 to 4" -> 10 to 16

                start_hour, start_min = sh, sm
                end_hour, end_min = eh, em

        start_dt = target_day.replace(hour=start_hour, minute=start_min, second=0, microsecond=0)
        end_dt = target_day.replace(hour=end_hour, minute=end_min, second=0, microsecond=0)

        if end_dt <= start_dt:
            end_dt = start_dt + timedelta(hours=4)

        return start_dt, end_dt, label

    def _extract_purpose(self, query: str) -> str:
        q = query.strip()
        # Look for common test phases mentioned first
        for p in ["Regression Testing", "Smoke Testing", "Performance Testing", "Deployment Verification", "User Acceptance Testing", "Integration Testing"]:
            if p.lower() in q.lower():
                return p

        # Look for "for <purpose>"
        match = re.search(r"\bfor\s+([A-Za-z0-9\s\-_]+?)(?:\s+\b(?:from|at|on|tomorrow|today|next)\b|\s*$)", q, re.IGNORECASE)
        if match:
            clean = match.group(1).strip()
            if len(clean) >= 3 and clean.lower() not in ["exclusive", "shared", "tomorrow", "today"]:
                return clean.title()

        return "Automated Test Execution"

    def _parse_iso_or_str(self, date_str: str) -> datetime:
        try:
            # Handle ISO format
            clean_str = date_str.replace("Z", "+00:00")
            dt = datetime.fromisoformat(clean_str)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            pass

        # Try common formats
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(date_str, fmt)
                return dt.replace(tzinfo=timezone.utc)
            except ValueError:
                continue

        return datetime.now(timezone.utc) + timedelta(days=1)


assistant_booking_agent = AssistantBookingAgent()
