"""
Comprehensive SmartQE TEM Knowledge Base for Functional & Architecture Q&A
Covers all 15 TEM modules, business rules, workflows, algorithms, and definitions.
"""
import difflib
import re
from typing import Dict, List, Optional, Tuple


class KnowledgeTopic:
    def __init__(self, key: str, title: str, category: str, keywords: List[str], summary: str, full_content: str, related_routes: List[str]):
        self.key = key
        self.title = title
        self.category = category
        self.keywords = [k.lower() for k in keywords]
        self.summary = summary
        self.full_content = full_content
        self.related_routes = related_routes


TEM_KNOWLEDGE_TOPICS: List[KnowledgeTopic] = [
    KnowledgeTopic(
        key="overview",
        title="SmartQE TEM Platform Overview",
        category="General",
        keywords=["what is tem", "tem platform", "tem architecture", "tem overview", "control tower", "how tem works", "smartqe overview", "tem summary", "tem modules"],
        summary="SmartQE TEM is an enterprise Test Environment Management platform acting as the Central Control Tower for scheduling, monitoring, diagnosing, auto-healing, and forecasting test environments.",
        full_content="""### 🏢 SmartQE TEM (Test Environment Management) Overview

**SmartQE TEM** is the enterprise "Air Traffic Control" for software non-production environments. It eliminates environment contention, configuration drift, untracked outages, and cloud resource wastage across 15 integrated operational modules:

1. **Command Center (Dashboard)**: Fleet-wide health KPIs, capacity gauges, readiness matrix, and active incident/release sidebars.
2. **Portfolio Management**: Organizational master data hierarchy (`Business Unit` ➔ `Project` ➔ `Component` ➔ `Application`).
3. **Environment Details**: Configuration profiles, network endpoints, DB connection strings, and component topology mappings.
4. **Resource Inventory**: Physical & cloud infrastructure asset tracking (Servers, DBs, Queues, Gateways, Cloud Providers).
5. **Environment Topology**: Interactive graph visualization and **Blast Radius / Impact Analysis** simulations.
6. **Health Checks**: Multi-tier asynchronous health checks (Server, Software, Application, Database, Network).
7. **Enterprise Auto-Heal**: Automated fault detection, policy remediation rules, and operator approval workflows.
8. **Observability & Monitoring**: Real-time telemetry (CPU, Memory, Storage, Latency, Error Rate), readiness scores, and drift detection.
9. **Environment Diagnosis & Comparison**: Software inventory baselines, version mismatch detection, and **SIT vs UAT side-by-side comparison**.
10. **Booking & Reservation Engine**: Conflict-free scheduling with **Exclusive (Disruptive)** vs **Shared** reservation modes.
11. **Release Management & Calendar**: Deployment pipelines, risk ratings, and multi-view calendar (Gantt, Monthly, Quarterly, Yearly).
12. **Environment Provisioning Engine**: 7-step provisioning wizard, preflight validation, orchestrator execution, and SSE streaming.
13. **Usage Analysis & Utilization**: 4-tier environment classification (Frequently, Moderately, Rarely, Never Used).
14. **AI Predictive Demand & Capacity**: Contention risk heatmaps, upcoming release capacity gap forecasting, and recommendations.
15. **Incidents, Runbooks & Security**: SEV1-SEV4 incident triage, automated SOP execution, and fine-grained RBAC.""",
        related_routes=["/tem-dashboard", "/entity-management", "/environment-details", "/bookings", "/releases"]
    ),

    KnowledgeTopic(
        key="portfolio_hierarchy",
        title="Portfolio & Master Data Hierarchy",
        category="Master Data",
        keywords=["portfolio", "business unit", "bu", "project", "component", "application", "app tier", "hierarchy", "master data"],
        summary="TEM enforces an organizational hierarchy: Business Unit -> Project -> Component -> Application, ensuring every environment and booking is anchored.",
        full_content="""### 🏛️ Portfolio & Master Data Hierarchy

SmartQE TEM prevents "orphan" environment requests by enforcing a strict 4-level business hierarchy:

```
Business Unit (e.g. Retail Banking)
  └── Project (e.g. Mobile App V3)
        ├── Component (e.g. Auth Service)
        └── Application (e.g. Titan Gateway, Criticality Tier 1/2/3)
```

- **Business Unit (BU)**: Top-level organizational unit (e.g. *Retail Banking*, *Wealth Management*, *Commercial Payments*).
- **Project**: Target initiative with planned start and end dates.
- **Component**: Reusable functional building blocks within projects.
- **Application**: Specific software product mapped to criticality tiers:
  - **Tier 1**: Mission-critical core customer applications.
  - **Tier 2**: Important internal business services.
  - **Tier 3**: Auxiliary helper utilities and reporting tools.

Every booking and release in TEM **must** be associated with a valid BU, Project, and Application.""",
        related_routes=["/entity-management"]
    ),

    KnowledgeTopic(
        key="booking_modes_and_conflicts",
        title="Environment Booking, Reservation Modes & Conflict Detection",
        category="Bookings",
        keywords=["booking", "reservation", "conflict", "conflict detection", "exclusive", "shared", "disruptive", "double booking", "how booking works", "how to book", "book environment", "reserve environment"],
        summary="TEM supports Shared vs Disruptive (Exclusive) reservation modes and automatically flags overlapping date collisions.",
        full_content="""### 📅 Booking Engine, Reservation Modes & Conflict Prevention

SmartQE TEM eliminates double-booking and test collisions through automated conflict detection:

#### 1. Reservation Modes
- **Shared Mode**: Multiple testing teams can book and test on the environment concurrently for non-disruptive functional testing.
- **Exclusive (Disruptive) Mode**: Locks the entire environment exclusively. Required for:
  - Database schema migrations & data purges.
  - High-concurrency performance/load testing.
  - Destructive chaos engineering or major infrastructure patching.

#### 2. Conflict Detection Algorithm
When a user requests a booking window `[T_start, T_end]`:
1. Checks for any active/approved bookings overlapping `[T_start, T_end]` on the same environment.
2. If the new request OR any existing overlapping booking is **Exclusive/Disruptive**, TEM flags a **Hard Collision Conflict**.
3. If both bookings are **Shared**, TEM permits concurrency but warns of shared capacity.
4. If a booking window falls outside the associated Release start/end dates, a **Release Boundary Conflict** is flagged.

#### 3. Booking Lifecycle
`PENDING` ➔ `APPROVED` / `REJECTED` / `AUTO_REJECTED` ➔ `ACTIVE` ➔ `COMPLETED` / `CANCELLED`
- Expired unapproved bookings are automatically transitioned to `AUTO_REJECTED` by the background scheduler.""",
        related_routes=["/bookings", "/worklist"]
    ),

    KnowledgeTopic(
        key="worklist",
        title="Bookings Worklist, Approval Queue & Conflict Resolution",
        category="Operations",
        keywords=[
            "worklist", "work list", "use of worklist", "worklist use", "what is worklist",
            "approval queue", "pending approvals", "approve booking", "reject booking",
            "conflict resolution", "resolve conflict", "check availability", "available slots",
            "worklist table", "booking approvals", "approver", "worklist purpose", "why use worklist"
        ],
        summary="Central operational queue for environment managers and approvers to review pending bookings, approve/reject requests, and resolve scheduling collisions.",
        full_content="""### 📋 Bookings Worklist & Approval Queue

The **Worklist** (`/worklist`) is the central operational command center in TEM for managing environment bookings, approvals, and scheduling collisions:

#### 1. Centralized Approval Queue
- Displays all environment reservations across your fleet with live statuses: `PENDING`, `APPROVED`, `REJECTED`, `IN_PROGRESS`, `COMPLETED`, `CANCELLED`.
- Designated **Approvers & Environment Managers** can review reservation requests submitted by QA, Dev, and Release teams.

#### 2. One-Click Approval & Rejection Workflows
- **Approve Booking**: Approvers can accept requests with optional review notes, confirming environment allocation and dispatching automated email notifications.
- **Reject Booking**: Enforces a mandatory **Rejection Reason** for transparency and audit compliance.

#### 3. Conflict Detection & Visual Collision Alerts
- Flags hard collisions between overlapping bookings (especially when either reservation is requested in **Exclusive / Disruptive** mode) and warns if dates violate release boundaries.

#### 4. Smart Conflict Resolution Workbench
When a collision is detected, the Worklist provides an interactive resolution wizard:
- **Reschedule Window**: Adjust reservation start and end dates.
- **Mode Adjustment**: Switch an Exclusive booking to Shared mode if non-disruptive.
- **Smart Slot Finder**: Click **Check Availability** to automatically find and select alternate non-conflicting time slots on the requested environment.

#### 5. Email Notification Audit Trail
- Inspect delivery logs for all automated notifications sent to requesters, environment owners, and approvers.

#### 6. CSV Export & Bulk Filtering
- Filter by status, date range, tier, or environment, and export reports via **Export CSV** (`TEM_Bookings_Worklist.csv`).""",
        related_routes=["/worklist", "/bookings"]
    ),

    KnowledgeTopic(
        key="define_workflow",
        title="Define Workflow & Multi-Stage Approval Pipelines",
        category="Administration",
        keywords=[
            "define workflow", "define workflows", "how define workflow works", "how workflow works",
            "workflow", "workflows", "approval workflow", "approval pipeline", "sequential approval",
            "workflow approver", "approver chain", "workflow order", "tem service type",
            "workflow setup", "create workflow", "multi-level approval", "approval hierarchy"
        ],
        summary="Configures sequential multi-step approval pipelines for TEM services (Reservations, Provisioning, Monitoring, Health Checks) scoped by Business Unit, Environment, and Application.",
        full_content="""### 🔄 Define Workflow & Multi-Stage Approval Pipelines

The **Define Workflow** screen (`/settings/define-workflow`) allows Administrators to create and govern **Sequential Multi-Level Approval Chains** for critical TEM operational actions:

#### 1. 4-Dimensional Context Scoping
Every workflow is uniquely anchored to a 4-level context:
1. **Business Unit (BU)**: e.g. *Retail Banking*, *Wealth Management*, *Cards*.
2. **Environment**: Target environment profile (e.g. *SIT-01*, *UAT-02*, *DEV-01*).
3. **Application**: Associated application entity (e.g. *Payment Gateway*, *Core Banking API*).
4. **TEM Service Type**:
   - `ENVIRONMENT_RESERVATION`: Bookings and reservations.
   - `ENVIRONMENT_PROVISIONING`: Infrastructure spin-up and teardown.
   - `ENVIRONMENT_MONITORING`: Telemetry and threshold changes.
   - `ENVIRONMENT_HEALTH_CHECK`: Deep probe executions.

#### 2. Sequential Multi-Step Approvers
- Administrators configure an ordered chain of designated users (`Order 1`, `Order 2`, `Order 3`).
- Example Approval Chain:
  - **Step 1 (Order 1)**: Team QA Lead
  - **Step 2 (Order 2)**: Environment Manager
  - **Step 3 (Order 3)**: Release Director

#### 3. Execution & Integration with Worklist
1. When a user requests a reservation or provisioning on that target environment:
2. TEM matches the request against the configured Workflow for that BU + Environment + Application + Service.
3. The request enters the **Worklist (`/worklist`)** of the **Step 1 Approver**.
4. Once Step 1 approves, TEM automatically advances the request to **Step 2**, and so on.
5. If any approver rejects, the entire workflow halts, logs the rejection reason, and notifies the requester.
6. Once all steps approve, the environment reservation or provisioning automatically activates.

#### 4. Workflow Lifecycle & Auditing
- **Status**: Toggle workflows `ACTIVE` or `INACTIVE` at any time.
- **Audit Trails**: Full tracking of `Created By`, `Modified By`, timestamps, and historical execution steps.""",
        related_routes=["/settings/define-workflow", "/worklist", "/bookings"]
    ),

    KnowledgeTopic(
        key="release_calendar_and_phases",
        title="Release Management & Multi-View Calendar",
        category="Releases",
        keywords=["release", "release calendar", "phases", "test phases", "gantt", "custom phase", "risk type", "pipeline", "release manager", "deployments"],
        summary="Releases track change deployments across structured test phases (UNIT, SIT, UAT, QA, ST, PRE-PROD, PROD) with timeline and Gantt visualization.",
        full_content="""### 🚀 Release Management & Release Calendar

The Release module manages the end-to-end software deployment schedule across environments:

#### 1. Release Lifecycle & Risk Profiling
- **Risk Ratings**: `LOW`, `MEDIUM`, `HIGH` (High-risk releases trigger automated notifications and require exclusive locks).
- **Status Progression**: `SCHEDULED` ➔ `IN PROGRESS` ➔ `DEPLOYED` (or `CANCELLED`).
- **Release Metadata**: Release Version, Target BU, Project, Application, Release Manager, Repository URL, Start/End Dates.

#### 2. Test Phase Pipelines
Each release contains an ordered sequence of test phases:
- Built-in System Phases: **UNIT**, **SIT** (System Integration), **UAT** (User Acceptance), **QA**, **ST** (System Testing), **PRE-PROD**, **PROD**.
- **Custom / Other Phases**: Teams can define custom phases with tailored colors, order, and descriptions.

#### 3. Release Calendar Views
- **Application View**: Displays release phase progression grouped by application.
- **Environment View**: Visualizes environment reservations and release allocations on an interactive timeline.
- **Time Periods**: Toggle between **Month**, **Quarter**, **Year**, and **Gantt Chart** views.
- **Conflict Highlighting**: Shows conflicting release dates and recommends alternative free environments.""",
        related_routes=["/releases", "/releases/calendar"]
    ),

    KnowledgeTopic(
        key="health_checks_and_scoring",
        title="Enterprise Multi-Tier Health Checks",
        category="Health",
        keywords=["health", "health check", "probe", "health score", "unhealthy", "tcp check", "http check", "db check", "ping check", "tiers", "probes"],
        summary="Health checks run asynchronous multi-tier probes (Server, Software, App, DB, Network) and calculate composite scores from 0-100%.",
        full_content="""### 🩺 Enterprise Multi-Tier Health Checks

TEM evaluates environment health across 5 critical tiers using automated probes:

| Tier | Checked Elements | Probe Types |
| :--- | :--- | :--- |
| **1. Server / Infrastructure** | CPU load, Memory pressure, Disk space, Host OS | System Metrics, Ping |
| **2. Software & Runtimes** | Process alive, Runtime version (Java, Python, Node) | Process Checker, CLI Probe |
| **3. Application Services** | REST APIs, Microservices, Web endpoints | HTTP GET/POST, Status 200 OK |
| **4. Database Layer** | PostgreSQL, Oracle, MySQL, Connection pools | DB Ping, Query Execution |
| **5. Network & Middleware** | Redis cache, Kafka queues, Ports | TCP Socket Connect, Latency Probe |

#### Health Score Calculation
Composite health score ranges from **0% to 100%**:
- **100% (ONLINE)**: All probe checks passed within acceptable latency (<200ms).
- **70 - 99% (DEGRADED)**: Minor latency warnings or non-critical service warning.
- **< 70% (OFFLINE / CRITICAL)**: Critical component down (e.g. database unreachable or app 500 error). Triggers automated Auto-Heal.""",
        related_routes=["/environment-monitoring", "/environment-details"]
    ),

    KnowledgeTopic(
        key="auto_heal",
        title="Enterprise Auto-Heal & Automated Remediation",
        category="Auto-Heal",
        keywords=["auto-heal", "auto heal", "autoheal", "remediation", "self-healing", "restart service", "flush cache", "clean disk", "mttr", "rules", "remediation policy"],
        summary="Auto-Heal detects environment failures and applies automated or approved recovery runbooks to reduce Mean Time to Recovery (MTTR).",
        full_content="""### ⚡ Enterprise Auto-Heal & Automated Remediation

Auto-Heal continuously monitors health check failures and executes predefined remediation rules:

#### 1. Remediation Trigger Conditions
- **High Disk Usage (>90%)**: Executes log purge and temporary file cleanup.
- **Service Crash / HTTP 503**: Triggers automated service restart or container reboot.
- **Cache Eviction / High Memory**: Executes Redis cache flush or JVM heap compaction.
- **Database Connection Pool Exhaustion**: Restarts connection pool / resets zombie sessions.

#### 2. Execution Modes
- **Fully Automated**: Safely executes low-risk remediation actions immediately upon failure.
- **Operator Approval Gate**: High-impact actions (e.g. DB restart) generate a pending approval card in the **Pending Approvals Banner** for manual sign-off.

#### 3. Resilience & Safety
- **Max Retry Threshold**: Configurable limit (e.g., 3 retries within 15 minutes) to prevent infinite restart loops.
- **Audit Logs**: Complete record of trigger timestamp, rule name, stdout logs, and recovery status (`SUCCESS`, `FAILED`, `EXHAUSTED`).""",
        related_routes=["/environment-monitoring"]
    ),

    KnowledgeTopic(
        key="observability_and_monitoring",
        title="Environment Observability, Drift & Test Readiness",
        category="Monitoring",
        keywords=["monitoring", "observability", "cpu", "memory", "storage", "readiness", "readiness score", "drift", "configuration drift", "telemetry"],
        summary="Observability tracks live CPU/RAM/Disk, Latency, Configuration Drift flags, and calculates an overall Test Readiness score.",
        full_content="""### 📊 Environment Observability & Monitoring

The Observability module provides 360-degree visibility into environment fleet performance:

#### 1. Core Telemetry Metrics
- **CPU & Memory Utilization**: Live % gauges with threshold alert triggers (>80% Warning, >90% Critical).
- **Disk & Storage**: Volume consumption and growth trends.
- **API Response Latency**: Response time in milliseconds (ms).
- **Error Rate**: % of failed synthetic transactions.

#### 2. Test Readiness Score
A composite score (**0 - 100%**) that answers: *"Is this environment genuinely ready for QA test execution?"*
- Evaluates: Hardware health (30%) + Software match (30%) + DB connectivity (20%) + Active booking validity (20%).
- If Readiness < 80%, TEM issues a warning banner before test teams begin execution.

#### 3. Configuration Drift Detection
Identifies when an active environment deviates from its registered baseline profile (e.g., unauthorized port opening, modified environment variables, or hotfixed code).""",
        related_routes=["/environment-monitoring"]
    ),

    KnowledgeTopic(
        key="diagnosis_and_comparison",
        title="Environment Diagnosis & SIT vs UAT Version Comparison",
        category="Diagnosis",
        keywords=["diagnosis", "compare", "comparison", "sit vs uat", "version mismatch", "software inventory", "missing software", "drift", "expected version", "package version"],
        summary="Diagnosis audits software inventories and allows side-by-side comparison between environments (e.g., SIT vs UAT) highlighting version deltas.",
        full_content="""### 🔍 Environment Diagnosis & Comparison Workbench

Diagnosis verifies that test environments have the exact required runtimes, packages, and application versions:

#### 1. Software Inventory Diagnostics
Each environment tracks installed software components across categories (`RUNTIME`, `DATABASE`, `CACHE`, `WEB_SERVER`, `QUEUE`, `TOOL`):
- **MATCH**: Installed version matches expected baseline (e.g., Java `17.0.10` == `17.0.10`).
- **VERSION_MISMATCH**: Installed version differs from baseline (e.g., Python `3.10.12` vs expected `3.11.5`).
- **MISSING**: Mandatory package is not installed on the target environment.
- **EXTRA**: Unexpected or unauthorized software detected.

#### 2. Side-by-Side Comparison Workbench (e.g., SIT vs UAT)
Allows engineers to select any Source and Target environment to generate:
- **Comparison Diff Table**: Side-by-side table displaying Component, Source Version, Target Version, and Match Status.
- **Consistency Score**: Percentage of identical packages across environments.
- **Upgrade Recommendations**: Actionable instructions (e.g., *"Upgrade Python on UAT-01 from 3.10.12 to 3.11.5"*).""",
        related_routes=["/environment-monitoring", "/environment-details"]
    ),

    KnowledgeTopic(
        key="usage_analysis",
        title="Intelligent Environment Usage Analysis",
        category="Analytics",
        keywords=["usage", "usage analysis", "frequently used", "moderately used", "rarely used", "never used", "utilization", "under-utilized", "zombie environment", "underutilized"],
        summary="Classifies environments into 4 utilization tiers (Frequently, Moderately, Rarely, Never Used) to optimize cloud costs and prevent idle zombie servers.",
        full_content="""### 📈 Intelligent Environment Usage Analysis

Usage Analysis computes historical booking density and resource utilization over 30d, 90d, 180d, or 365d periods:

#### 4-Tier Intelligent Classification
1. **Frequently Used (🔥 High Demand)**:
   - Criteria: Utilization $\ge 60\%$ OR $\ge 15$ bookings in period.
   - Action: Prioritize for capacity scaling or dedicated scheduling.
2. **Moderately Used (⚖️ Healthy)**:
   - Criteria: Utilization $20\% - 59\%$ OR $5 - 14$ bookings in period.
3. **Rarely Used (⚠️ Low Utilization)**:
   - Criteria: Utilization $< 20\%$ AND $< 5$ bookings.
   - Action: Consolidate workloads or share with other projects.
4. **Never Used (🛑 Zombie Candidate)**:
   - Criteria: $0$ bookings recorded during the analysis window.
   - Action: Decommission or power down to save cloud budget.""",
        related_routes=["/environment-usage-analysis"]
    ),

    KnowledgeTopic(
        key="predictive_demand",
        title="AI Predictive Demand & Capacity Planning",
        category="AI & Demand",
        keywords=["predictive demand", "demand", "capacity", "forecast", "prediction", "capacity gap", "upcoming releases", "shortage", "contention heatmap"],
        summary="AI forecasts future environment demand based on upcoming release pipelines, test phase schedules, and historical utilization.",
        full_content="""### 🔮 AI Predictive Environment Demand & Capacity Forecasting

The AI Predictive Demand engine forecasts future environment needs before release crunches occur:

#### 1. Predictive Contention Heatmap
Visualizes future calendar dates with high probability of booking contention across environment tiers (DEV, SIT, UAT, PERF, PRE-PROD).

#### 2. Capacity Gap Analysis
Calculates:
$$\\text{Capacity Gap} = \\text{Forecasted Demand (Required Envs)} - \\text{Available Online Envs}$$
- Highlights impending shortages 30, 60, and 90 days in advance.
- Recommends provisioning specific environment profiles ahead of major release test phases.

#### 3. What-If Scenario Simulations
Allows TEM architects to simulate: *"If 2 new major releases are added to Q3, do we have enough SIT and UAT environments?"*""",
        related_routes=["/ai-predictive-demand"]
    ),

    KnowledgeTopic(
        key="provisioning_wizard",
        title="Environment Provisioning Engine & Wizard",
        category="Provisioning",
        keywords=[
            "provisioning", "provision", "provis", "wizard", "template", "orchestrator",
            "preflight", "how to provision", "new environment", "provision environment",
            "environment provisioning", "infrastructure provisioning", "spin up environment",
            "create environment", "deployment pipeline"
        ],
        summary="Automated 7-step provisioning wizard with preflight validation, orchestrator execution, and SSE event streaming.",
        full_content="""### 🛠️ Environment Provisioning Engine & Wizard

TEM provides automated, template-driven environment provisioning through a 7-step wizard:

1. **Step 1: Basic Info**: Environment Name, Tier (DEV/SIT/UAT/PERF), Business Unit, Project, and Owner.
2. **Step 2: Infrastructure**: Cloud Provider (AWS, Azure, GCP, On-Prem), Region, VM size, vCPU, RAM, Storage.
3. **Step 3: Software Stack**: Select required runtimes (Java, Python, Node), databases (Postgres, Oracle), and middleware.
4. **Step 4: Configuration**: Network ports, environment variables, and endpoint URLs.
5. **Step 5: Dependency Mapping**: Upstream APIs and downstream databases.
6. **Step 6: Resource Validation & Preflight**: Automated preflight checks verifying quota, subnet availability, and naming collisions.
7. **Step 7: Provisioning Plan & Execution**: Orchestrator step-by-step execution with live SSE log streaming and rollback support.""",
        related_routes=["/provisioning/new", "/provisioning/dashboard", "/provisioning/templates"]
    ),

    KnowledgeTopic(
        key="topology_and_impact",
        title="Environment Topology & Blast Radius Impact Analysis",
        category="Topology",
        keywords=["topology", "impact analysis", "blast radius", "downstream", "dependencies", "graph", "what if server down", "dependency graph"],
        summary="Visual graph map of environment architectures and automated Blast Radius calculator simulating the impact of component failures.",
        full_content="""### 🕸️ Environment Topology & Blast Radius Impact Analysis

Topology visualizes the interconnected architecture of applications, microservices, databases, and gateways:

#### 1. Interactive Topology Graph
- Nodes represent Environments, Applications, Databases, Microservices, and External Gateways.
- Directional edges represent API connections, message queues, and database socket links with protocol/port labels.

#### 2. Blast Radius / Impact Analysis Calculator
Simulates the failure of any target node (e.g. *"What happens if Payment DB crashes?"*):
- Computes upstream caller applications that will experience outages.
- Identifies downstream orphaned services.
- Lists active test suites and business projects directly impacted by the failure.""",
        related_routes=["/environment-topology"]
    ),

    KnowledgeTopic(
        key="incidents_and_runbooks",
        title="Incidents Management & Operational Runbooks",
        category="Operations",
        keywords=["incidents", "runbooks", "sev1", "sev2", "downtime", "rca", "sla", "sop", "kafka reset", "redis flush", "runbook execution"],
        summary="Incident management triages SEV1-SEV4 outages with SLA timers and RCA logging. Operational Runbooks execute automated SOPs.",
        full_content="""### 🚨 Incidents & Operational Runbooks

#### 1. Incident Management
- **Severities**: `SEV1` (Critical - Complete Outage), `SEV2` (High - Major Feature Blocked), `SEV3` (Medium), `SEV4` (Low / Cosmetic).
- **Incident Lifecycle**: `OPEN` ➔ `INVESTIGATING` ➔ `RESOLVED` ➔ `CLOSED`.
- **Automated Impact**: Logging a SEV1 incident automatically marks the target environment status as `OFFLINE` or `DEGRADED`.
- **RCA Enforcement**: Resolving incidents requires Root Cause Analysis notes.

#### 2. Operational Runbooks
Standard Operating Procedures (SOPs) executable with one click:
- *Kafka Offset Reset*: Resets consumer group offsets for clean test runs.
- *Redis Eviction Flush*: Flushes memory caches.
- *DB Schema Purge / Reset*: Sanitizes test databases between test phases.
- *Environment Health Deep Probe*: Runs comprehensive diagnostic suite.""",
        related_routes=["/incidents", "/runbooks"]
    ),

    KnowledgeTopic(
        key="security_rbac",
        title="Security, Roles & Access Management",
        category="Security",
        keywords=["security", "roles", "rbac", "permissions", "screen access", "user groups", "super admin", "users", "access control"],
        summary="Fine-grained Role-Based Access Control (RBAC) governing screen routes, entity ownership, and administrative privileges.",
        full_content="""### 🔒 Security & Access Management (RBAC)

SmartQE TEM secures access across all screens and resources:

- **Users & Roles**: Users belong to roles (e.g. `Super Admin`, `Environment Manager`, `QA Lead`, `Tester`, `DevOps Engineer`).
- **Screen Access Matrix**: Granular screen-by-screen read/write permissions for all 15 modules.
- **Entity Ownership & Isolation**: Ensures users only modify resources owned by their business unit or team unless granted Super Admin rights.
- **Audit Logging**: Comprehensive logging of authentication events, session timeouts, and configuration changes.""",
        related_routes=["/settings/users", "/settings/roles", "/settings/access"]
    ),

    KnowledgeTopic(
        key="settings_and_submodules",
        title="Settings Module & Administration Submodules",
        category="Administration",
        keywords=[
            "settings", "module settings", "settings module", "submodules", "submodule",
            "submodules in settings", "settings submodules", "user management", "role management",
            "access management", "user group management", "user groups", "define workflow",
            "system preferences", "settings options", "admin settings", "settings page",
            "what is in settings", "settings tabs", "platform settings", "settings sub modules"
        ],
        summary="The Settings module (/settings) provides enterprise administration across 5 core submodules: User Management, Role Management, Access Management, User Group Management, and Define Workflow (plus System & API Preferences).",
        full_content="""### ⚙️ TEM Platform Settings & Submodules Guide

The **Settings** module (`/settings`) is the administrative control tower in SmartQE TEM. It allows administrators to govern platform users, assign security roles, enforce screen-by-screen access permissions, manage cross-functional teams, and build multi-stage approval workflows.

The Settings module is structured into **5 distinct submodules** (plus the System Preferences tab):

---

#### 1. 👤 User Management (`/settings/users`)
- **Purpose**: Manage the platform-wide user directory and user lifecycle.
- **Key Capabilities**:
  - View all registered users with their Username, Email, Full Name, Department, and Status (`ACTIVE` / `INACTIVE`).
  - Add new users, edit existing user profiles, or toggle active/inactive account status.
  - Assign primary roles and inspect user permission tiers.
  - Search, filter by department, and audit user accounts.

---

#### 2. 🛡️ Role Management (`/settings/roles`)
- **Purpose**: Define and govern Role-Based Access Control (RBAC) security roles.
- **Key Capabilities**:
  - Built-in enterprise roles: `Super Admin`, `Environment Manager`, `QA Lead`, `Tester`, `DevOps Engineer`, `Release Manager`.
  - Create custom roles tailored to specific team responsibilities with custom role descriptions.
  - Define role hierarchies and configure default landing screens per role.

---

#### 3. 🔑 Access Management (`/settings/access`)
- **Purpose**: Granular Screen-by-Screen Permission Matrix.
- **Key Capabilities**:
  - Interactive grid mapping each Role against all platform screen routes (`/tem-dashboard`, `/entity-management`, `/environment-details`, `/bookings`, `/worklist`, `/releases`, `/environment-monitoring`, `/provisioning`, etc.).
  - Configure granular `Read`, `Write`, and `Execute` permissions per role.
  - Enforce least-privilege access so regular testers and developers cannot modify sensitive environment configurations.

---

#### 4. 👥 User Group Management (`/settings/user-groups`)
- **Purpose**: Organize users into functional teams and operational groups.
- **Key Capabilities**:
  - Create user groups by department or project team (e.g. *Payments QA Team*, *Core Banking DevOps*, *Release Approvers*).
  - Bulk-assign roles or screen permissions to entire groups.
  - Use groups as designated approval entities in multi-stage approval workflows.

---

#### 5. 🔄 Define Workflow (`/settings/define-workflow`)
- **Purpose**: Build sequential multi-level approval chains for operational TEM actions.
- **Key Capabilities**:
  - 4-Dimensional Context Scoping: **Business Unit** + **Environment** + **Application** + **TEM Service Type** (`ENVIRONMENT_RESERVATION`, `ENVIRONMENT_PROVISIONING`, `ENVIRONMENT_MONITORING`, `ENVIRONMENT_HEALTH_CHECK`).
  - Configure ordered approval stages (`Order 1`, `Order 2`, `Order 3`) assigning designated individual approvers or leads.
  - Seamlessly routes requests into the **Worklist (`/worklist`)** for step-by-step approval before activating reservations or environment spin-ups.

---

#### ⚙️ Additional Tab: System & API Preferences (`/settings?tab=system`)
- Accessible within the Settings screen under the **System & API Preferences** tab:
  - **FastAPI Base URL Endpoint**: Configure the backend API gateway URL (default: `http://localhost:8000/api/v1`).
  - **Sync Refresh Interval**: Adjust background data synchronization frequency (in seconds).
  - **Default Environment Region**: Set default deployment cloud/datacenter region (e.g. `us-west-2`).
  - **Incident & Health Alerting**: Toggle automated toast and incident notification alerts.""",
        related_routes=["/settings/users", "/settings/roles", "/settings/access", "/settings/user-groups", "/settings/define-workflow"]
    ),

    KnowledgeTopic(
        key="all_modules_and_submodules",
        title="SmartQE TEM Platform Modules & Submodules Architecture",
        category="General",
        keywords=[
            "all modules", "modules", "submodules", "list of modules", "modules and submodules",
            "platform modules", "tem modules", "submodules list", "menu structure", "sidebar modules",
            "navigation modules", "what modules", "module hierarchy", "features and modules"
        ],
        summary="Complete catalog of all 12 modules in SmartQE TEM, including the submodules under Settings, Environment Provisioning, Releases, and Resource Management.",
        full_content="""### 🗺️ SmartQE TEM Platform Modules & Submodules Guide

SmartQE TEM is organized into **12 primary operational modules** accessible via the sidebar navigation:

1. **📊 TEM Dashboard (`/tem-dashboard`)**: Central command center displaying fleet health KPIs, capacity gauges, readiness matrix, active releases, and incident sidebars.
2. **⚙️ Settings (`/settings`)**: Platform administrative governance organized into **5 core submodules**:
   - **User Management** (`/settings/users`): Platform user directory and account statuses.
   - **Role Management** (`/settings/roles`): Role definitions and security boundaries.
   - **Access Management** (`/settings/access`): Granular screen-by-screen RBAC permission matrix.
   - **User Group Management** (`/settings/user-groups`): Team and department user group assignments.
   - **Define Workflow** (`/settings/define-workflow`): Multi-stage sequential approval chains for reservations and provisioning.
   *(Plus **System & API Preferences** tab at `/settings?tab=system` for FastAPI backend URL and sync interval)*
3. **🏛️ Entity Management (`/entity-management`)**: 4-level organizational master data hierarchy: Business Unit (BU) ➔ Project ➔ Component ➔ Application.
4. **🖥️ Environment Details (`/environment-details`)**: Configuration profiles, host IPs, connection strings, tiers (`DEV`, `SIT`, `UAT`, `PERF`, `PROD`), and component mappings.
5. **📋 Worklist (`/worklist`)**: Operational queue for reviewing pending bookings, approving/rejecting requests with notes, and resolving scheduling collisions.
6. **📅 Bookings Grid (`/bookings`)**: Reservation calendar supporting **Shared** vs **Exclusive (Disruptive)** booking modes with conflict detection.
7. **🛠️ Environment Provisioning (`/provisioning`)**: Automated infrastructure provisioning with **5 submodules**:
   - **Provisioning Dashboard** (`/provisioning/dashboard`): Real-time provisioning metrics and active jobs.
   - **Provisioning Requests** (`/provisioning/requests`): Queue of submitted, running, and past requests.
   - **New Request (Wizard)** (`/provisioning/new`): 7-step provisioning wizard with preflight validation.
   - **Templates** (`/provisioning/templates`): Infrastructure blueprint templates.
   - **Provisioning History** (`/provisioning/history`): Historical execution logs, SSE trace, and audit records.
8. **🚀 Releases (`/releases`)**: Software delivery management with **2 submodules**:
   - **Release Management** (`/releases`): Deployment schedules, risk ratings (Low/Medium/High), and test phases (UNIT, SIT, UAT, QA, ST, PRE-PROD, PROD).
   - **Release Calendar** (`/releases/calendar`): Multi-view interactive calendar (Application View, Environment View; Month, Quarter, Year, Gantt).
9. **🚨 Incidents (`/incidents`)**: SEV1–SEV4 outage triage, SLA timers, Root Cause Analysis (RCA) logging, and automatic environment degradation status updates.
10. **🗄️ Resource Management**: Fleet observability and asset management with **5 submodules**:
    - **Inventory Management** (`/inventory`): Physical and cloud IT assets (Servers, DBs, Queues, Gateways, Cloud Providers).
    - **Environment Topology** (`/environment-topology`): Interactive architecture graph and Blast Radius / Impact Analysis calculator.
    - **Environment Monitoring** (`/environment-monitoring`): Real-time telemetry (CPU, RAM, Disk, Latency, Error Rate) and multi-tier health probe scores.
    - **AI Predictive Demand** (`/ai-predictive-demand`): Release capacity gap forecasting and contention heatmaps.
    - **Usage Analysis** (`/environment-usage-analysis`): 4-tier utilization classification (Frequently, Moderately, Rarely, Never Used).
11. **🔌 External Integrations (`/external-integrations`)**: Connectors for Cloud Providers (AWS, Azure, GCP), CI/CD pipelines (Jenkins, GitLab CI, GitHub Actions), and monitoring webhooks.
12. **📖 Runbooks (`/runbooks`)**: One-click executable Standard Operating Procedures (Kafka Offset Reset, Redis Eviction Flush, DB Purge/Sanitize, Health Deep Probes).""",
        related_routes=["/tem-dashboard", "/settings", "/provisioning/dashboard", "/releases", "/inventory"]
    ),

    KnowledgeTopic(
        key="environment_servers_and_infrastructure",
        title="Adding & Managing Servers in Environment Details (On-Premises & Cloud)",
        category="Infrastructure",
        keywords=[
            "servers", "server", "add server", "add servers", "how servers are added",
            "how to add server", "how to add servers", "adding servers", "server onboarding",
            "infrastructure", "add infrastructure", "on premises", "onprem", "on-prem",
            "cloud instance", "cloud vm", "vm servers", "cloud servers", "datacenter",
            "server types", "server details", "host ip", "aws server", "azure server",
            "gcp server", "rack unit", "instance type", "infrastructure inventory",
            "how are servers added", "where servers are added", "server modal"
        ],
        summary="In SmartQE TEM, servers (hosts/VMs) are added and configured directly from the Environment Details module (/environment-details) under the Servers tab by clicking '+ ADD INFRASTRUCTURE'. The platform supports 2 primary infrastructure types: On-Premises Servers and Cloud Instances / VMs.",
        full_content="""### 🖥️ How Servers are Added in SmartQE TEM (Environment Details)

In **SmartQE TEM**, all infrastructure servers, compute hosts, and virtual machines are added and managed directly from the **Environment Details** module (`/environment-details`).

---

#### 📍 Step-by-Step Navigation:
1. Navigate to **Environment Details** (`/environment-details`) from the left sidebar.
2. Click on the **Servers** tab (located next to *Profiles* and *Software*).
3. Click the orange **`+ ADD INFRASTRUCTURE`** button in the top-right header to open the modal.

---

### 🏗️ Supported Server & Infrastructure Types (2 Types)

The **Add New Infrastructure** modal features a top segmented toggle between two infrastructure types:

#### 1. 🏢 On-Premises Servers (`ON_PREMISES`)
Designed for bare-metal physical servers or internal enterprise virtual machines hosted in on-prem corporate data centers.
- **Key Fields & Attributes**:
  - **Server Name / Hostname** *(Required)*: e.g. `uat-core-app01.internal`
  - **Host / IP Address** *(Required)*: Static IP or hostname (e.g. `192.168.10.42`)
  - **Data Center / Physical Location**: Facility or site designation (e.g. `Chicago DC-1`, `Frankfurt Site B`)
  - **Rack / Unit / Slot**: Physical chassis identifier (e.g. `Rack A-04, Unit 12-14`)
  - **Server Type**: Role-based classification (`Application Server`, `Database Server`, `Web Server`, `Cache Server`, `Load Balancer / Proxy`, `Message Broker`, `API Gateway`)
  - **Operating System**: Host OS (e.g. `Ubuntu 22.04 LTS`, `RHEL 9`, `Windows Server 2022`)
  - **Hardware Sizing**: CPU Cores, RAM (GB), and Storage/Disk (GB)
  - **Environment Allocation**: Link directly to a target Environment Tier (`Development`, `QA / Testing`, `UAT / Staging`, `Production`, `Performance / Stress`, `Disaster Recovery (DR)`, `Sandbox`)

#### 2. ☁️ Cloud Instances / VMs (`CLOUD`)
Designed for virtual machines, compute instances, and elastic nodes running on cloud hyperscalers.
- **Key Fields & Attributes**:
  - **Cloud Provider** *(Required dropdown)*: Supports `AWS` (Amazon Web Services), `Azure` (Microsoft Azure), `GCP` (Google Cloud Platform), `OCI` (Oracle Cloud), `Alibaba Cloud`, `DigitalOcean`, or `Other Provider`
  - **Instance / VM Name** *(Required)*: Instance identifier or hostname (e.g. `uat-eks-worker-01`)
  - **Instance ID**: Cloud resource ID (e.g. `i-0a8b9c1d2e3f` for EC2, Azure VM Resource ID)
  - **Region & Availability Zone**: Cloud deployment geography (e.g. Region: `us-east-1` / `westeurope`, AZ: `us-east-1a` / `zone-1`)
  - **Instance Type / Size**: Machine compute flavor (e.g. `t3.2xlarge`, `Standard_D4s_v5`, `e2-standard-8`)
  - **Network & IP Configuration**:
    - **Private IP / Hostname** *(Required)*: Internal VPC subnet IP (e.g. `10.0.12.45`)
    - **Public IP**: Optional external/elastic IP (e.g. `54.210.45.12`)
    - **VPC / Subnet ID**: Virtual network descriptor (e.g. `vpc-main-01 / subnet-app`)
  - **Server Type & OS**: Compute category, operating system, CPU Cores, RAM (GB), and Storage (GB)
  - **Environment Allocation**: Association to target environment profile

---

### 🔗 Linking Servers to Environment Profiles
After servers are created:
1. In **Environment Details > Profiles** tab, click **`+ NEW ENVIRONMENT PROFILE`** or click **Edit** on an existing profile (e.g., `AshEnv_12Aug`, `SIT-01`).
2. In the profile configuration modal under **Server Allocation**, select the checkboxes for the registered servers.
3. Once linked, the servers automatically:
   - Appear in **Environment Topology (`/environment-topology`)** as interconnected compute nodes in the architecture graph.
   - Feed telemetry metrics (CPU, Memory, Disk) into **Environment Monitoring (`/environment-monitoring`)**.
   - Are evaluated by **Enterprise Health Checks** and protected by automated **Auto-Heal** policies.""",
        related_routes=["/environment-details", "/environment-topology", "/environment-monitoring"]
    ),
]


STOP_WORDS = {
    "tell", "me", "about", "what", "is", "are", "am", "how", "do", "does", "did", "i", "to",
    "the", "a", "an", "for", "please", "show", "give", "can", "could", "would", "you", "your",
    "explain", "describe", "details", "of", "in", "on", "with", "and", "or", "my", "any", "some",
    "module", "feature", "app", "application", "works", "work", "hi", "hello", "hey", "there",
    "along", "it", "its", "at", "within", "under", "list", "which", "where"
}


def search_knowledge_base(query: str) -> Optional[KnowledgeTopic]:
    """
    Search indexed knowledge base topics by keyword matching, fuzzy typo-tolerance, and semantic relevance.
    """
    q_raw = query.lower().strip()
    q_clean = re.sub(r"[^\w\s-]", " ", q_raw)
    tokens = [t for t in q_clean.split() if t]
    meaningful_tokens = [t for t in tokens if t not in STOP_WORDS]

    if not meaningful_tokens:
        return None

    best_match: Optional[KnowledgeTopic] = None
    highest_score = 0.0

    for topic in TEM_KNOWLEDGE_TOPICS:
        score = 0.0

        # Exact phrase match in query
        for kw in topic.keywords:
            if kw in q_clean:
                score += len(kw) * 3.0
            elif q_clean in kw and len(q_clean) > 3:
                score += len(q_clean) * 1.5

        # Token-level exact & fuzzy match
        for token in meaningful_tokens:
            for kw in topic.keywords:
                kw_parts = kw.split()
                # Exact word match within keyword
                if token in kw_parts:
                    score += 12.0
                elif len(token) >= 4 and f" {token} " in f" {kw} ":
                    score += 8.0
                else:
                    # Fuzzy match against individual words of keyword (minimum 4 chars)
                    for kw_part in kw_parts:
                        if len(token) >= 4 and len(kw_part) >= 4:
                            ratio = difflib.SequenceMatcher(None, token, kw_part).ratio()
                            if ratio >= 0.78:
                                score += ratio * 10.0

        # Title & Category match
        if topic.title.lower() in q_clean:
            score += 25.0
        else:
            title_tokens = [t for t in re.sub(r"[^\w\s-]", " ", topic.title.lower()).split() if t not in STOP_WORDS]
            for token in meaningful_tokens:
                for tt in title_tokens:
                    if token == tt:
                        score += 10.0
                    elif len(token) >= 4 and len(tt) >= 4:
                        ratio = difflib.SequenceMatcher(None, token, tt).ratio()
                        if ratio >= 0.78:
                            score += ratio * 8.0

        # Small penalty for general overview if specific meaningful domain tokens exist
        if topic.key == "overview" and meaningful_tokens:
            if not any(t in ["tem", "smartqe", "overview", "summary", "modules"] for t in meaningful_tokens):
                score *= 0.2

        if score > highest_score:
            highest_score = score
            best_match = topic

    if highest_score >= 6.0:
        return best_match
    return None