"""
SmartQE TEM Assistant Environment Helper.
Unifies EnvironmentProfile (from the Environment Details screen) and legacy Environment models
so the conversational assistant has complete visibility over the user's fleet.
"""
from typing import Any, List, Optional
import re
from sqlalchemy.ext.asyncio import AsyncSession

# from app.dao.environment_dao import environment_dao
from app.dao.environment_profile_dao import environment_profile_dao


class StrEnumProxy(str):
    """String proxy that safely exposes a .value property for enum-like access."""
    @property
    def value(self) -> str:
        return str(self)


class UnifiedEnvironment:
    """
    Standardized environment representation supporting EnvironmentProfile
    (Environment Details screen).
    """
    def __init__(self, raw: Any):
        self.raw = raw
        self.id = str(getattr(raw, "id", "") or "")
        self.name = str(getattr(raw, "name", "") or "")

        # Tier / Type resolution
        raw_tier = getattr(raw, "tier", None) or getattr(raw, "type", "QA")
        raw_tier_str = getattr(raw_tier, "value", str(raw_tier)) if raw_tier else "QA"
        self.tier = StrEnumProxy(raw_tier_str)

        # Status resolution
        raw_status = getattr(raw, "status", "HEALTHY")
        raw_status_str = getattr(raw_status, "value", str(raw_status)) if raw_status else "HEALTHY"
        self.status = StrEnumProxy(raw_status_str)

        # Team & BU
        self.team = (
            getattr(raw, "team", None)
            or getattr(raw, "owner_team", None)
            or "QA Team"
        )
        self.business_unit = getattr(raw, "business_unit", None) or "Enterprise QA"

        # Region & Network zone
        self.region = (
            getattr(raw, "region", None)
            or getattr(raw, "network_zone", None)
            or "us-east-1"
        )

        # Ownership & Active state
        self.owner = (
            getattr(raw, "owner", None)
            or getattr(raw, "created_by", None)
            or "Admin"
        )
        self.is_active = getattr(raw, "is_active", True) is not False

    def __repr__(self) -> str:
        return f"<UnifiedEnvironment id={self.id} name={self.name} tier={self.tier}>"


async def get_all_unified_environments(db: AsyncSession) -> List[UnifiedEnvironment]:
    """
    Retrieves all environments in the fleet:
    Prioritizes and strictly queries EnvironmentProfile records (created in Environment Details screen).
    Legacy Environment base table is commented out.
    """
    profiles = await environment_profile_dao.get_all(db, limit=200)
    # legacy_envs = await environment_dao.get_all(db, limit=200)

    unified: List[UnifiedEnvironment] = []
    seen_names = set()

    # 1. Environment Profiles (Primary environments from Environment Details screen)
    for p in profiles:
        if p and p.name and p.name.strip():
            seen_names.add(p.name.strip().lower())
            unified.append(UnifiedEnvironment(p))

    # 2. Legacy Environments (Commented out - using Environment Profiles exclusively)
    # for e in legacy_envs:
    #     if e and e.name and e.name.strip().lower() not in seen_names:
    #         seen_names.add(e.name.strip().lower())
    #         unified.append(UnifiedEnvironment(e))

    return unified


def match_environment_in_text(query: str, all_envs: List[UnifiedEnvironment]) -> Optional[UnifiedEnvironment]:
    """
    Resiliently searches for an environment in query text, supporting
    spaces, underscores, hyphens, and mixed casing.
    """
    q_upper = query.upper()
    q_norm = re.sub(r"[^A-Za-z0-9]", "", q_upper)

    # 1. Word boundary match
    for env in all_envs:
        e_upper = env.name.upper()
        if re.search(r"\b" + re.escape(e_upper) + r"\b", q_upper) or (env.id and env.id.upper() in q_upper):
            return env

    # 2. Normalized match (e.g. AshEnv_12Aug, AshEnv 12Aug, ashenv12aug)
    for env in all_envs:
        env_norm = re.sub(r"[^A-Za-z0-9]", "", env.name.upper())
        if env_norm and len(env_norm) >= 3 and env_norm in q_norm:
            return env

    return None
