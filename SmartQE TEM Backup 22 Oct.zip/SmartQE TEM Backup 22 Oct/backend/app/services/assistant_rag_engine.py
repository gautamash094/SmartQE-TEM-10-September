"""
SmartQE TEM RAG (Retrieval-Augmented Generation) Engine.
Extracts real-time fleet health, active reservations, upcoming releases,
incidents, and curated domain knowledge to feed into LLM prompts.
"""
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

# from app.dao.environment_dao import environment_dao
from app.dao.reservation_dao import reservation_dao
from app.dao.release_dao import release_dao
from app.dao.incident_dao import incident_dao
from app.dao.environment_software_dao import environment_software_dao
from app.services.assistant_env_helper import (
    get_all_unified_environments,
    match_environment_in_text,
    UnifiedEnvironment,
)
from app.services.assistant_knowledge_base import search_knowledge_base, TEM_KNOWLEDGE_TOPICS, KnowledgeTopic
from app.schemas.assistant import ChatMessage, AssistantActionLink, SuggestedPrompt
from app.models.user import User

logger = logging.getLogger("tem.assistant.rag")


class AssistantRAGEngine:
    """
    RAG Engine that dynamically collects real-time enterprise TEM facts
    and matches relevant architectural knowledge base articles.
    """

    async def build_rag_context(
        self,
        db: AsyncSession,
        query: str,
        history: Optional[List[ChatMessage]] = None,
        context_entity: Optional[Dict[str, Any]] = None,
        current_user: Optional[User] = None
    ) -> Dict[str, Any]:
        """
        Assembles live database state and relevant functional documentation.
        Returns:
            {
                "system_instruction": str,
                "context_summary": str,
                "suggested_prompts": List[SuggestedPrompt],
                "action_links": List[AssistantActionLink],
                "matched_topic": Optional[KnowledgeTopic]
            }
        """
        live_facts = await self._gather_live_facts(db, query, context_entity)
        matched_topic = search_knowledge_base(query)

        # Build System Instruction
        system_instruction = self._compose_system_instruction(live_facts, matched_topic)

        # Generate contextual follow-up prompts & navigation links
        suggested_prompts = self._derive_suggested_prompts(query, live_facts, matched_topic)
        action_links = self._derive_action_links(query, live_facts, matched_topic)

        return {
            "system_instruction": system_instruction,
            "live_facts": live_facts,
            "suggested_prompts": suggested_prompts,
            "action_links": action_links,
            "matched_topic": matched_topic
        }

    async def _gather_live_facts(
        self,
        db: AsyncSession,
        query: str,
        context_entity: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        facts: Dict[str, Any] = {
            "fleet_summary": {},
            "target_environments": [],
            "active_bookings": [],
            "upcoming_releases": [],
            "active_incidents": []
        }

        try:
            # 1. Environment Fleet Overview
            all_envs = await get_all_unified_environments(db)
            total_envs = len(all_envs)

            tier_counts: Dict[str, int] = {}
            status_counts: Dict[str, int] = {}
            for e in all_envs:
                t = e.tier.value if hasattr(e.tier, "value") else str(e.tier)
                s = e.status.value if hasattr(e.status, "value") else str(e.status)
                tier_counts[t] = tier_counts.get(t, 0) + 1
                status_counts[s] = status_counts.get(s, 0) + 1

            facts["fleet_summary"] = {
                "total_environments": total_envs,
                "tier_breakdown": tier_counts,
                "status_breakdown": status_counts,
                "fleet_names": [e.name for e in all_envs[:10]]
            }

            # Check if query references specific environments (e.g. SIT-01, AshEnv_12Aug)
            q_upper = query.upper()
            referenced_envs = [
                e for e in all_envs
                if match_environment_in_text(query, [e]) is not None or e.name.upper() in q_upper or (e.id and e.id.upper() in q_upper)
            ]

            if referenced_envs:
                target_env_details = []
                for re in referenced_envs[:3]:
                    # Fetch installed packages for target env
                    try:
                        softwares = await environment_software_dao.get_by_environment_id_or_name(db, re.id)
                        sw_list = [f"{s.software_name} v{s.version or 'latest'}" for s in softwares[:5]]
                    except Exception:
                        sw_list = []
                    target_env_details.append({
                        "id": re.id,
                        "name": re.name,
                        "tier": re.tier.value if hasattr(re.tier, "value") else str(re.tier),
                        "status": re.status.value if hasattr(re.status, "value") else str(re.status),
                        "region": re.region or "default",
                        "owner": re.owner or "unassigned",
                        "software_sample": sw_list
                    })
                facts["target_environments"] = target_env_details

            # 2. Active Bookings
            recent_bookings = await reservation_dao.get_all(db, limit=10)
            bookings_data = []
            for b in recent_bookings[:5]:
                bookings_data.append({
                    "id": b.id,
                    "environment_id": b.environment_id,
                    "title": b.title or "Reserved",
                    "status": b.status.value if hasattr(b.status, "value") else str(b.status),
                    "start_time": b.start_time.strftime("%Y-%m-%d %H:%M") if b.start_time else "N/A",
                    "end_time": b.end_time.strftime("%Y-%m-%d %H:%M") if b.end_time else "N/A",
                    "is_exclusive": getattr(b, "is_exclusive", False),
                })
            facts["active_bookings"] = bookings_data

            # 3. Upcoming Releases
            releases = await release_dao.get_all(db, limit=5)
            rel_data = []
            for r in releases[:5]:
                rel_ver = getattr(r, "version", "")
                rel_date = getattr(r, "scheduled_date", None) or getattr(r, "start_date", None)
                rel_data.append({
                    "id": r.id,
                    "name": r.name,
                    "version": rel_ver or "",
                    "target_date": rel_date.strftime("%Y-%m-%d") if rel_date else "TBD",
                    "status": r.status.value if hasattr(r.status, "value") else str(r.status)
                })
            facts["upcoming_releases"] = rel_data

            # 4. Open Incidents
            try:
                open_incidents = await incident_dao.get_all(db, limit=5)
                inc_list = []
                for inc in open_incidents[:5]:
                    inc_list.append({
                        "id": inc.id,
                        "title": inc.title,
                        "severity": inc.severity.value if hasattr(inc.severity, "value") else str(inc.severity),
                        "status": inc.status.value if hasattr(inc.status, "value") else str(inc.status)
                    })
                facts["active_incidents"] = inc_list
            except Exception:
                pass

        except Exception as e:
            logger.warning(f"Error gathering live facts for RAG: {e}")

        return facts

    def _compose_system_instruction(
        self,
        live_facts: Dict[str, Any],
        matched_topic: Optional[KnowledgeTopic]
    ) -> str:
        instructions = [
            "You are the SmartQE TEM (Test Environment Management) Conversational AI Assistant.",
            "You are an enterprise DevOps and Environment Management expert. You help QA, Engineering, and DevOps teams manage test environments, release schedules, booking conflicts, configuration drift, auto-healing, and observability.",
            "",
            "### GUIDELINES:",
            "1. Be concise, highly professional, friendly, and structured.",
            "2. Use clean Markdown (bullet points, bold highlights, tables, and code snippets where appropriate).",
            "3. Ground all answers in the live TEM environment state and domain knowledge provided below.",
            "4. When discussing environments, bookings, or releases, reference real names, tiers, and statuses from the live context.",
            "5. If a user asks how to do something or where a feature is located, mention the relevant platform path (e.g. `/environment-details`, `/bookings`, `/releases`, `/worklist`, `/settings/define-workflow`, `/settings/users`, `/inventory`).",
            "6. If the user asks about an environment or asset not in the live data, clearly state that it is not present in the current inventory.",
            "",
            "### === PLATFORM MODULES & SUBMODULES (GROUND TRUTH) ===",
            "SmartQE TEM consists strictly of the following 12 navigation modules and their exact submodules:",
            "1. TEM Dashboard (`/tem-dashboard`): Fleet health KPIs, readiness scores, active releases & incidents.",
            "2. Settings (`/settings`): Platform administrative governance organized into 5 core submodules:",
            "   - User Management (`/settings/users`): Manage users, accounts, email, department, active/inactive status.",
            "   - Role Management (`/settings/roles`): Enterprise roles (Super Admin, Environment Manager, QA Lead, Tester, DevOps Engineer, Release Manager).",
            "   - Access Management (`/settings/access`): Granular screen-by-screen RBAC permission matrix (Read, Write, Execute).",
            "   - User Group Management (`/settings/user-groups`): Team and department user groups for notifications and approvals.",
            "   - Define Workflow (`/settings/define-workflow`): Multi-stage sequential approval chains for reservations, provisioning, monitoring, and health checks.",
            "   - Plus System & API Preferences tab at `/settings?tab=system` (FastAPI backend URL, sync interval, default region).",
            "3. Entity Management (`/entity-management`): 4-level hierarchy (Business Unit -> Project -> Component -> Application).",
            "4. Environment Details (`/environment-details`): Environment profiles, tiers (DEV/SIT/UAT/PERF/PROD), host IPs, connection strings, component mappings.",
            "5. Worklist (`/worklist`): Operational queue for approving/rejecting booking requests and resolving schedule collisions.",
            "6. Bookings Grid (`/bookings`): Reservation calendar supporting Shared and Exclusive (Disruptive) modes with conflict detection.",
            "7. Environment Provisioning (`/provisioning`): 5 submodules:",
            "   - Provisioning Dashboard (`/provisioning/dashboard`)",
            "   - Provisioning Requests (`/provisioning/requests`)",
            "   - New Request (Wizard) (`/provisioning/new`)",
            "   - Templates (`/provisioning/templates`)",
            "   - Provisioning History (`/provisioning/history`)",
            "8. Releases (`/releases`): 2 submodules:",
            "   - Release Management (`/releases`)",
            "   - Release Calendar (`/releases/calendar`)",
            "9. Incidents (`/incidents`): Outage reporting (SEV1-SEV4), SLA timers, and RCA logging.",
            "10. Resource Management: 5 submodules:",
            "    - Inventory Management (`/inventory`)",
            "    - Environment Topology (`/environment-topology`)",
            "    - Environment Monitoring (`/environment-monitoring`)",
            "    - AI Predictive Demand (`/ai-predictive-demand`)",
            "    - Usage Analysis (`/environment-usage-analysis`)",
            "11. External Integrations (`/external-integrations`): Cloud Providers (AWS/Azure/GCP), CI/CD pipelines, and webhooks.",
            "12. Runbooks (`/runbooks`): One-click executable SOPs (Kafka Offset Reset, Redis Eviction Flush, DB Purge).",
            "",
            "CRITICAL: NEVER hallucinate fake submodules or routes (such as /settings/governance, /settings/integrations, or /settings/auto-heal). Always use the exact names and paths specified above.",
            "",
            "### === HOW SERVERS & INFRASTRUCTURE ARE ADDED (ENVIRONMENT DETAILS) ===",
            "In SmartQE TEM, servers (compute hosts, virtual machines, and infrastructure nodes) are added and configured directly from the Environment Details module (`/environment-details`).",
            "Navigation: Go to `Environment Details` (/environment-details) -> Click on the `Servers` tab -> Click the orange `+ ADD INFRASTRUCTURE` button.",
            "SmartQE TEM supports 2 primary infrastructure types (selected via a top segmented toggle in the modal):",
            "1. 🏢 On-Premises Server (`ON_PREMISES`):",
            "   - Bare-metal physical servers or internal enterprise VMs hosted in corporate data centers.",
            "   - Attributes: Server Name / Hostname (e.g. uat-core-app01.internal), Host / IP Address (e.g. 192.168.10.42), Data Center / Physical Location (e.g. Chicago DC-1), Rack / Unit / Slot (e.g. Rack A-04, Unit 12-14), Server Type (Application Server, Database Server, Web Server, Cache Server, Load Balancer / Proxy, Message Broker, API Gateway), Operating System (e.g. Ubuntu 22.04 LTS, RHEL 9), CPU Cores, RAM (GB), Storage (GB), and Environment Allocation tier.",
            "2. ☁️ Cloud Instance / VM (`CLOUD`):",
            "   - Cloud virtual machines and elastic compute nodes across cloud hyperscalers.",
            "   - Attributes: Cloud Provider dropdown (AWS, Azure, GCP, OCI, Alibaba Cloud, DigitalOcean, Other), Instance / VM Name (e.g. uat-eks-worker-01), Instance ID (e.g. i-0a8b9c1d2e3f), Region (e.g. us-east-1) & Availability Zone (e.g. us-east-1a), Instance Type / Size (e.g. t3.2xlarge, Standard_D4s_v5), Private IP / Hostname (e.g. 10.0.12.45), Public IP (optional), VPC / Subnet ID, Server Type, OS, CPU, RAM, Disk, and Environment Allocation tier.",
            "",
            "Linking Servers to Environments: In `Environment Details > Profiles`, users create or edit an Environment Profile (e.g. AshEnv_12Aug, SIT-01) and link registered servers using the server allocation checklist. Linked servers then automatically reflect in Environment Topology (`/environment-topology`) and Environment Monitoring (`/environment-monitoring`).",
            "",
            "CRITICAL: NEVER instruct users to add servers via /inventory or /external-integrations. Servers are added in Environment Details (`/environment-details`) under the Servers tab using the + ADD INFRASTRUCTURE button.",
            ""
        ]

        # Append Live TEM System State
        instructions.append("### === LIVE TEM SYSTEM CONTEXT ===")
        fleet = live_facts.get("fleet_summary", {})
        if fleet:
            instructions.append(f"- Total Fleet Environments: {fleet.get('total_environments', 0)}")
            instructions.append(f"- Status Breakdown: {fleet.get('status_breakdown', {})}")
            instructions.append(f"- Tier Breakdown: {fleet.get('tier_breakdown', {})}")

        targets = live_facts.get("target_environments", [])
        if targets:
            instructions.append("\n- Specific Environments Queried:")
            for te in targets:
                instructions.append(
                    f"  * {te['name']} (ID: {te['id']}) | Tier: {te['tier']} | Status: {te['status']} | Region: {te['region']} | Software: {', '.join(te['software_sample'])}"
                )

        bookings = live_facts.get("active_bookings", [])
        if bookings:
            instructions.append("\n- Recent/Active Bookings:")
            for b in bookings:
                instructions.append(
                    f"  * Booking '{b['title']}' on {b['environment_id']} | Status: {b['status']} | Mode: {'Exclusive' if b['is_exclusive'] else 'Shared'} | Window: {b['start_time']} to {b['end_time']}"
                )

        releases = live_facts.get("upcoming_releases", [])
        if releases:
            instructions.append("\n- Upcoming Releases:")
            for r in releases:
                instructions.append(f"  * {r['name']} (v{r['version']}) | Target Date: {r['target_date']} | Status: {r['status']}")

        incidents = live_facts.get("active_incidents", [])
        if incidents:
            instructions.append("\n- Active Incidents:")
            for inc in incidents:
                instructions.append(f"  * [{inc['severity']}] {inc['title']} ({inc['status']})")

        # Append Domain Knowledge Base Topic if relevant
        if matched_topic:
            instructions.append("\n### === TEM DOMAIN KNOWLEDGE REFERENCE ===")
            instructions.append(f"Topic: {matched_topic.title} (Category: {matched_topic.category})")
            instructions.append(f"Summary: {matched_topic.summary}")
            instructions.append(f"Content:\n{matched_topic.full_content}")

        return "\n".join(instructions)

    def _derive_suggested_prompts(
        self,
        query: str,
        live_facts: Dict[str, Any],
        matched_topic: Optional[KnowledgeTopic]
    ) -> List[SuggestedPrompt]:
        q_lower = query.lower()

        if "worklist" in q_lower:
            return [
                SuggestedPrompt(category="How-To", prompt="What are the approval statuses in worklist?"),
                SuggestedPrompt(category="Releases", prompt="Show all releases with pending approvals"),
                SuggestedPrompt(category="Bookings", prompt="Which bookings are currently active?"),
            ]
        elif "workflow" in q_lower or "define" in q_lower:
            return [
                SuggestedPrompt(category="How-To", prompt="How do I configure SLA triggers in workflows?"),
                SuggestedPrompt(category="How-To", prompt="What is the difference between parallel and sequential approvals?"),
                SuggestedPrompt(category="Health", prompt="Show all SIT environments."),
            ]
        elif "booking" in q_lower or "reserve" in q_lower:
            return [
                SuggestedPrompt(category="Bookings", prompt="Who booked SIT-01?"),
                SuggestedPrompt(category="Bookings", prompt="Is there any conflict with booking SIT-03?"),
                SuggestedPrompt(category="Releases", prompt="Which environments are reserved for upcoming releases?"),
            ]
        elif "release" in q_lower:
            return [
                SuggestedPrompt(category="Releases", prompt="Show all upcoming releases"),
                SuggestedPrompt(category="Health", prompt="Are all environments ready for Release R2026.11?"),
                SuggestedPrompt(category="Demand", prompt="How many SIT environments will we need next month?"),
            ]
        elif "heal" in q_lower or "auto" in q_lower:
            return [
                SuggestedPrompt(category="Health", prompt="Which environments are currently down?"),
                SuggestedPrompt(category="How-To", prompt="How do I set up automated service restart rules?"),
                SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01"),
            ]
        elif "setting" in q_lower or "submodule" in q_lower:
            return [
                SuggestedPrompt(category="How-To", prompt="How do I configure role permissions in Access Management?"),
                SuggestedPrompt(category="How-To", prompt="How do sequential approval workflows work?"),
                SuggestedPrompt(category="How-To", prompt="What are all the modules in SmartQE TEM?"),
            ]
        elif "server" in q_lower or "infra" in q_lower or "on-prem" in q_lower or "cloud" in q_lower:
            return [
                SuggestedPrompt(category="How-To", prompt="What fields are required for On-Premises servers?"),
                SuggestedPrompt(category="How-To", prompt="What cloud providers are supported for Cloud VM servers?"),
                SuggestedPrompt(category="How-To", prompt="How do I link servers to an Environment Profile?"),
            ]
        elif matched_topic and matched_topic.key in ["overview", "all_modules_and_submodules"]:
            return [
                SuggestedPrompt(category="Health", prompt="Which environments are currently down?"),
                SuggestedPrompt(category="Bookings", prompt="Show all SIT environments."),
                SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01"),
                SuggestedPrompt(category="Demand", prompt="How many SIT environments will we need next month?"),
            ]

        # Default multi-domain suggestions
        return [
            SuggestedPrompt(category="Health", prompt="Which environments are currently down?"),
            SuggestedPrompt(category="Bookings", prompt="Show all SIT environments."),
            SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01"),
            SuggestedPrompt(category="Releases", prompt="Show all upcoming releases"),
        ]

    def _derive_action_links(
        self,
        query: str,
        live_facts: Dict[str, Any],
        matched_topic: Optional[KnowledgeTopic]
    ) -> List[AssistantActionLink]:
        links: List[AssistantActionLink] = []
        q_lower = query.lower()

        if matched_topic and matched_topic.related_routes:
            for r in matched_topic.related_routes[:4]:
                parts = [p for p in r.split("/") if p]
                clean_name = parts[-1].replace("-", " ").title() if parts else "Home"
                label = f"Open {clean_name}"
                links.append(AssistantActionLink(label=label, action_type="NAVIGATE", route=r))
            return links

        if "worklist" in q_lower:
            links.append(AssistantActionLink(label="Go to Worklist", action_type="NAVIGATE", route="/worklist"))
        elif "workflow" in q_lower:
            links.append(AssistantActionLink(label="Define Workflows", action_type="NAVIGATE", route="/settings/define-workflow"))
        elif "setting" in q_lower or "submodule" in q_lower:
            links.append(AssistantActionLink(label="User Management", action_type="NAVIGATE", route="/settings/users"))
            links.append(AssistantActionLink(label="Role Management", action_type="NAVIGATE", route="/settings/roles"))
            links.append(AssistantActionLink(label="Access Management", action_type="NAVIGATE", route="/settings/access"))
            links.append(AssistantActionLink(label="Define Workflows", action_type="NAVIGATE", route="/settings/define-workflow"))
        elif "book" in q_lower or "reserve" in q_lower:
            links.append(AssistantActionLink(label="View Bookings", action_type="NAVIGATE", route="/bookings"))
            links.append(AssistantActionLink(label="New Booking", action_type="NAVIGATE", route="/bookings/new"))
        elif "release" in q_lower:
            links.append(AssistantActionLink(label="View Releases", action_type="NAVIGATE", route="/releases"))
        elif "compar" in q_lower or "drift" in q_lower or "diagnos" in q_lower:
            links.append(AssistantActionLink(label="Environment Diagnosis", action_type="NAVIGATE", route="/diagnosis"))
        elif "heal" in q_lower:
            links.append(AssistantActionLink(label="Auto-Heal Console", action_type="NAVIGATE", route="/auto-heal"))
        elif "server" in q_lower or "infra" in q_lower:
            links.append(AssistantActionLink(label="Environment Details", action_type="NAVIGATE", route="/environment-details"))
            links.append(AssistantActionLink(label="View Servers", action_type="NAVIGATE", route="/environment-details?tab=servers"))
            links.append(AssistantActionLink(label="Environment Topology", action_type="NAVIGATE", route="/environment-topology"))
        else:
            links.append(AssistantActionLink(label="Command Center", action_type="NAVIGATE", route="/tem-dashboard"))
            links.append(AssistantActionLink(label="Environment Fleet", action_type="NAVIGATE", route="/environment-details"))

        return links


assistant_rag_engine = AssistantRAGEngine()
