"""
TEM Conversational Assistant Service
Combines TEM Knowledge Base (Functional Qs), Relational Entity Linker,
and Live Service/DAO Queries (Data Qs) with multi-turn conversation memory.
"""
import logging
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.services.llm_client import llm_client
from app.services.assistant_rag_engine import assistant_rag_engine
from app.services.assistant_booking_agent import assistant_booking_agent
from app.services.assistant_env_helper import (
    get_all_unified_environments,
    match_environment_in_text,
    UnifiedEnvironment,
)

# from app.dao.environment_dao import environment_dao
from app.dao.environment_profile_dao import environment_profile_dao
from app.dao.reservation_dao import reservation_dao
from app.dao.release_dao import release_dao
from app.dao.test_phase_dao import test_phase_dao
from app.dao.portfolio_dao import business_unit_dao, project_dao, application_dao
from app.dao.asset_dao import asset_dao
from app.dao.incident_dao import incident_dao
from app.dao.auto_heal_dao import auto_heal_dao
from app.dao.environment_software_dao import environment_software_dao
from app.services.monitoring_service import monitoring_service
from app.services.health_check_service import health_check_service
from app.services.diagnosis.diagnosis_service import diagnosis_service
from app.services.comparison_service import environment_comparator
from app.services.usage_analysis_service import usage_analysis_service
from app.services.assistant_knowledge_base import search_knowledge_base, TEM_KNOWLEDGE_TOPICS
from app.schemas.comparison import EnvironmentComparisonRequest
from app.schemas.assistant import (
    AssistantChatRequest,
    AssistantChatResponse,
    AssistantActionLink,
    SuggestedPrompt,
    ChatMessage,
)
from app.models.user import User


logger = logging.getLogger("tem.assistant.service")


class TemAssistantService:
    def __init__(self):
        pass

    async def process_message(
        self,
        db: AsyncSession,
        request: AssistantChatRequest,
        current_user: Optional[User] = None
    ) -> AssistantChatResponse:
        query = request.message.strip()
        q_lower = query.lower()
        history = request.history or []
        context_entity = request.context_entity or {}

        # 1. Resolve Multi-Turn Conversational Memory Context
        resolved_context = self._extract_context_from_history(history, context_entity)

        # 2. Check for In-Chat Environment Booking Action
        if assistant_booking_agent.is_booking_request(query):
            return await assistant_booking_agent.handle_conversational_booking(
                db=db,
                query=query,
                history=history,
                resolved_context=resolved_context,
                current_user=current_user
            )

        # 3. Check if AI / LLM mode is enabled and configured (Gemini, OpenAI, or Ollama)
        if llm_client.is_configured():
            try:
                rag_payload = await assistant_rag_engine.build_rag_context(
                    db=db,
                    query=query,
                    history=history,
                    context_entity=context_entity,
                    current_user=current_user
                )

                history_dicts = [{"role": msg.role, "content": msg.content} for msg in history] if history else []

                llm_res = await llm_client.generate_response(
                    prompt=query,
                    system_instruction=rag_payload["system_instruction"],
                    history=history_dicts,
                    requested_provider=request.provider,
                    requested_model=request.model
                )

                if llm_res.success and llm_res.content and len(llm_res.content.strip()) > 0:
                    return AssistantChatResponse(
                        reply=llm_res.content.strip(),
                        intent="AI_RAG_RESPONSE",
                        category="AI_ASSISTANT",
                        entities={"provider": llm_res.provider, "model": llm_res.model},
                        suggested_prompts=rag_payload["suggested_prompts"],
                        action_links=rag_payload["action_links"],
                        raw_data={"provider": llm_res.provider, "model": llm_res.model}
                    )
                else:
                    logger.warning(
                        f"LLM call did not succeed ({llm_res.error_message}); falling back to local deterministic engine."
                    )
            except Exception as e:
                logger.warning(
                    f"Exception during LLM RAG execution: {e}; falling back to local deterministic engine."
                )

        # 3. Check for Conversational Greeting / Social query
        clean_greet = re.sub(r"[^\w\s]", "", q_lower).strip()
        is_greeting = clean_greet in [
            "hi", "hello", "hey", "hi there", "hello there", "hey there",
            "how are you", "hi how are you", "hello how are you", "how are you doing",
            "good morning", "good afternoon", "good evening", "howdy", "greetings"
        ] or (
            any(clean_greet.startswith(g) for g in ["hi ", "hello ", "hey "])
            and len(clean_greet.split()) <= 4
            and not any(k in q_lower for k in ["sit", "uat", "dev", "qa", "prod", "book", "release", "heal", "worklist", "incident", "cpu", "workflow"])
        )
        if is_greeting:
            return self._handle_greeting_response()

        # 4. Check for Direct Functional / Knowledge Base Questions first if clear explanation request
        is_exploratory_or_howto = any(pattern in q_lower for pattern in [
            "what is ", "what are ", "how does ", "how do i ", "how to ", "explain ", "what does ",
            "tell me about ", "difference between", "purpose of ", "use of ", "uses of ", "why use ",
            "role of ", "overview of ", "about ", "what can i do with ", "how can i use ",
        ]) or any(mod in q_lower for mod in ["worklist", "auto-heal", "autoheal", "runbooks", "topology", "provisioning", "diagnosis", "workflow", "define workflow", "settings", "submodule", "submodules", "module", "modules", "server", "servers", "infrastructure", "onprem", "on-prem"])

        if is_exploratory_or_howto and not any(data_kw in q_lower for data_kw in [
            "available right now", "who booked", "is sit-", "is uat-", "compare sit-", "installed on sit", "pending in worklist"
        ]):
            kb_match = search_knowledge_base(query)
            if kb_match:
                return self._build_kb_response(kb_match)

        # 3. Entity & Intent Extraction
        extracted = await self._extract_entities(db, query, resolved_context, current_user)

        # 4. Route to Specialized Query Handlers based on Intent
        intent = self._classify_intent(query, extracted, resolved_context)

        if intent == "COMPARISON_QUERY":
            return await self._handle_comparison_query(db, extracted, query)
        elif intent == "DIAGNOSIS_QUERY":
            return await self._handle_diagnosis_query(db, extracted, query)
        elif intent == "HEALTH_MONITORING_QUERY":
            return await self._handle_health_monitoring_query(db, extracted, query)
        elif intent == "AUTO_HEAL_QUERY":
            return await self._handle_auto_heal_query(db, extracted, query)
        elif intent == "BOOKING_QUERY":
            return await self._handle_booking_query(db, extracted, query, current_user)
        elif intent == "RELEASE_QUERY":
            return await self._handle_release_query(db, extracted, query, current_user)
        elif intent == "USAGE_ANALYSIS_QUERY":
            return await self._handle_usage_analysis_query(db, extracted, query, current_user)
        elif intent == "PREDICTIVE_DEMAND_QUERY":
            return await self._handle_predictive_demand_query(db, extracted, query, current_user)
        elif intent == "ENVIRONMENT_QUERY":
            return await self._handle_environment_query(db, extracted, query, current_user)
        elif intent == "TOPOLOGY_INCIDENT_QUERY":
            return await self._handle_topology_incident_query(db, extracted, query, current_user)
        else:
            # Fallback to Knowledge Base or General Help
            kb_match = search_knowledge_base(query)
            if kb_match:
                return self._build_kb_response(kb_match)
            return self._handle_unknown_query(query, extracted)

    # =========================================================================
    # Context & Entity Extraction
    # =========================================================================
    def _extract_context_from_history(self, history: List[ChatMessage], active_context: Dict[str, Any]) -> Dict[str, Any]:
        context: Dict[str, Any] = dict(active_context)

        # Scan recent assistant & user messages from history (newest to oldest)
        for msg in reversed(history[-6:]):
            text = msg.content
            # Check for referenced tier
            for tier in ["SIT", "UAT", "DEV", "QA", "ST", "PRE-PROD", "PROD", "PERF"]:
                if tier.lower() in text.lower() and "tier" not in context:
                    context["tier"] = tier

            # Check for referenced environment name
            env_matches = re.findall(r"\b(SIT-\d+|UAT-\d+|DEV-\d+|QA-\d+|PROD-\d+|PERF-\d+|PRE-PROD-\d+)\b", text, re.IGNORECASE)
            if env_matches and "environment_name" not in context:
                context["environment_name"] = env_matches[0].upper()
            if len(env_matches) >= 2 and "comparison_pair" not in context:
                context["comparison_pair"] = (env_matches[0].upper(), env_matches[1].upper())

            # Check for referenced release
            rel_matches = re.findall(r"\b(R\d{4}\.\d+|\bREL-\w+|\bRelease\s+[A-Za-z0-9\.\-_]+)\b", text, re.IGNORECASE)
            if rel_matches and "release_name" not in context:
                context["release_name"] = rel_matches[0]

        return context

    async def _extract_entities(
        self,
        db: AsyncSession,
        query: str,
        context: Dict[str, Any],
        current_user: Optional[User]
    ) -> Dict[str, Any]:
        q = query.strip()
        q_lower = q.lower()
        entities: Dict[str, Any] = {}

        # 1. Tier extraction
        for tier in ["SIT", "UAT", "DEV", "QA", "ST", "PRE-PROD", "PROD", "PERF"]:
            if re.search(r"\b" + re.escape(tier) + r"\b", q, re.IGNORECASE):
                entities["tier"] = tier.upper()
                break
        if "tier" not in entities and "tier" in context:
            if any(ref in q_lower for ref in ["which ones", "these", "those", "them", "which are available", "ones", "available right now"]):
                entities["tier"] = context["tier"]

        # 2. Environment names extraction (supporting EnvironmentProfile & Environment)
        all_envs = await get_all_unified_environments(db)
        matched_envs = []
        q_upper = q.upper()
        q_norm = re.sub(r"[^A-Za-z0-9]", "", q_upper)
        for env in all_envs:
            e_name = env.name.upper()
            e_norm = re.sub(r"[^A-Za-z0-9]", "", e_name)
            if re.search(r"\b" + re.escape(e_name) + r"\b", q_upper) or (env.id and env.id.upper() in q_upper):
                if env not in matched_envs:
                    matched_envs.append(env)
            elif e_norm and len(e_norm) >= 3 and e_norm in q_norm:
                if env not in matched_envs:
                    matched_envs.append(env)

        if matched_envs:
            entities["environments"] = matched_envs
            entities["environment"] = matched_envs[0]
            if len(matched_envs) >= 2:
                entities["comparison_pair"] = (matched_envs[0], matched_envs[1])
        elif "environment_name" in context:
            for env in all_envs:
                if env.name.upper() == context["environment_name"].upper():
                    entities["environment"] = env
                    break

        # 3. Release extraction (e.g. R2026.11, REL-01, Release 2026.1)
        all_releases = await release_dao.get_all(db, limit=100)
        for rel in all_releases:
            rel_ver = getattr(rel, "version", "")
            if rel.name.lower() in q_lower or (rel_ver and rel_ver.lower() in q_lower) or rel.id.lower() in q_lower:
                entities["release"] = rel
                break
            rel_code = rel.name.replace(" ", "")
            if rel_code.lower() in q_lower.replace(" ", ""):
                entities["release"] = rel
                break

        # 4. Application extraction (e.g. Payments, Core, Portal)
        all_apps = await application_dao.get_all_for_user(db, current_user)
        matched_apps = []
        for app in all_apps:
            if app.name.lower() in q_lower or (app.code and app.code.lower() in q_lower):
                matched_apps.append(app)
        if matched_apps:
            entities["applications"] = matched_apps
            entities["application"] = matched_apps[0]

        # 5. Software package tokens (e.g. Python, Java, Node.js, Redis, Postgres, Kafka)
        for sw in ["Python", "Java", "Node.js", "Node", "PostgreSQL", "Postgres", "Redis", "Nginx", "Kafka", "Docker", "RabbitMQ"]:
            if sw.lower() in q_lower:
                entities["software_name"] = "PostgreSQL" if "postgres" in sw.lower() else ("Node.js" if "node" in sw.lower() else sw)
                break

        # 6. Status & Filter flags
        if any(w in q_lower for w in ["down", "offline", "unhealthy", "degraded", "failing", "broken"]):
            entities["filter_status"] = "UNHEALTHY"
        elif any(w in q_lower for w in ["available", "free", "unbooked", "idle", "available right now"]):
            entities["filter_status"] = "AVAILABLE"
        elif any(w in q_lower for w in ["booked", "reserved", "active booking"]):
            entities["filter_status"] = "BOOKED"

        return entities

    def _classify_intent(self, query: str, entities: Dict[str, Any], context: Dict[str, Any]) -> str:
        q = query.lower()

        # Comparison Intent
        if any(kw in q for kw in ["compare ", "comparison", "difference between sit and uat", "differences between", "diff sit", "diff uat", "mismatch between"]):
            return "COMPARISON_QUERY"

        # Diagnosis / Software Version Intent
        if any(kw in q for kw in ["version installed", "software version", "what version of", "is python missing", "is node missing", "software in ", "diagnos", "drift in "]):
            return "DIAGNOSIS_QUERY"

        # Auto-Heal Intent
        if any(kw in q for kw in ["auto-heal", "auto heal", "autoheal", "remediation", "self heal", "pending approvals"]):
            return "AUTO_HEAL_QUERY"

        # Monitoring / Health Intent
        if any(kw in q for kw in ["cpu", "memory usage", "disk usage", "latency", "health score", "why is", "unhealthy", "observability", "metrics", "health check"]):
            return "HEALTH_MONITORING_QUERY"

        # Usage Analysis Intent
        if any(kw in q for kw in ["frequently used", "moderately used", "rarely used", "never used", "never-used", "under-utilized", "underutilized", "usage analysis", "zombie environment"]):
            return "USAGE_ANALYSIS_QUERY"

        # Predictive Demand & Capacity Intent
        if any(kw in q for kw in ["capacity", "demand", "how many sit", "how many uat", "need next month", "capacity shortage", "predictive demand", "shortage", "enough environments"]):
            return "PREDICTIVE_DEMAND_QUERY"

        # Available environment query (e.g. "Which ones are available?", "Which SIT environments are available right now?")
        if any(kw in q for kw in ["which are available", "which ones are available", "available right now", "show available", "free environments", "unbooked"]):
            return "ENVIRONMENT_QUERY"

        # Booking & Worklist Intent
        if any(kw in q for kw in ["who booked", "when is", "conflict", "reservation", "booked for", "book sit", "book uat", "reserve", "worklist", "approval queue", "pending approvals", "pending bookings"]):
            return "BOOKING_QUERY"

        # Release Intent
        if any(kw in q for kw in ["release", "phases configured", "which phase", "deploy", "gantt", "upcoming release", "r2026"]):
            return "RELEASE_QUERY"

        # Topology / Incident Intent
        if any(kw in q for kw in ["topology", "blast radius", "impact analysis", "incident", "sev1", "sev2", "outage"]):
            return "TOPOLOGY_INCIDENT_QUERY"

        # Environment Queries (Tiers, Status, specific details)
        if "environment" in q or "tier" in q or "sit" in q or "uat" in q or "dev" in q or "qa" in q or "environments" in entities or "environment" in entities or "tier" in entities:
            return "ENVIRONMENT_QUERY"

        return "GENERAL_KNOWLEDGE"

    # =========================================================================
    # Query Handlers
    # =========================================================================

    async def _handle_environment_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str,
        current_user: Optional[User]
    ) -> AssistantChatResponse:
        tier = entities.get("tier")
        target_env = entities.get("environment")
        filter_status = entities.get("filter_status")

        # Specific Single Environment Details (if exact single environment queried and not a generic list request)
        if target_env and not any(kw in query.lower() for kw in ["which ones", "show all", "list", "all sit", "all uat"]):
            obs = await monitoring_service.get_environment_detailed_observability(db, target_env.id)
            all_res = await reservation_dao.get_all(db, limit=200)
            active_res = [r for r in all_res if r.environment_id == target_env.id and str(r.status) in ("APPROVED", "ACTIVE")]

            status_val = getattr(target_env.status, "value", str(target_env.status))
            status_color = "🟢 ONLINE" if status_val in ("ONLINE", "HEALTHY") else ("🟡 DEGRADED" if status_val == "DEGRADED" else "🔴 " + status_val)
            readiness_str = f"{obs.test_readiness_score:.0f}%" if obs else "N/A"
            tier_val = getattr(target_env.tier, "value", str(target_env.tier))

            reply = f"""### 🖥️ Environment Dossier: **{target_env.name}**

- **Tier / Type**: `{tier_val}`
- **Current Status**: {status_color}
- **Test Readiness Score**: **{readiness_str}**
- **Region**: `{target_env.region or 'us-east-1'}`
- **Application URL**: `{target_env.app_url or 'https://' + target_env.name.lower() + '.testops.internal'}`
- **Database Connection**: `{target_env.db_connection or 'jdbc:postgresql://db-' + target_env.name.lower() + ':5432/testdb'}`

#### 📊 Live Telemetry & Health Probes
| Metric | Current Value | Status |
| :--- | :--- | :--- |
| **CPU Utilization** | `{obs.cpu_usage_pct:.1f}%` | {'🟢 Normal' if obs.cpu_usage_pct < 80 else '🔴 High'} |
| **Memory Utilization** | `{obs.memory_usage_pct:.1f}%` | {'🟢 Normal' if obs.memory_usage_pct < 85 else '🔴 High'} |
| **Disk Storage** | `{obs.storage_usage_pct:.1f}%` | {'🟢 Healthy' if obs.storage_usage_pct < 90 else '🔴 Critical'} |
| **API Latency** | `{obs.latency_ms:.0f} ms` | {'🟢 Fast' if obs.latency_ms < 200 else '🟡 Degraded'} |
"""
            if active_res:
                r = active_res[0]
                reply += f"\n> 🔒 **Active Reservation**: Booked by **{r.requested_by or 'QA Team'}** for **{r.project or 'Regression'}** ({r.start_date.strftime('%b %d') if r.start_date else 'TBD'} - {r.end_date.strftime('%b %d') if r.end_date else 'TBD'}). Mode: `{r.reservation_mode}`."
            else:
                reply += "\n> 🟢 **Availability**: Environment has no conflicting active bookings right now."

            return AssistantChatResponse(
                reply=reply,
                intent="ENVIRONMENT_DETAIL",
                category="DATA_QUERY",
                entities={"environment_id": target_env.id, "environment_name": target_env.name},
                suggested_prompts=[
                    SuggestedPrompt(category="Health", prompt=f"Run health check on {target_env.name}"),
                    SuggestedPrompt(category="Diagnosis", prompt=f"What software versions are installed in {target_env.name}?"),
                    SuggestedPrompt(category="Bookings", prompt=f"Who booked {target_env.name}?"),
                ],
                action_links=[
                    AssistantActionLink(label=f"Open {target_env.name} Details", action_type="NAVIGATE", route="/environment-details", params={"envId": target_env.id}),
                    AssistantActionLink(label="Run Health Probe", action_type="RUN_HEALTH_CHECK", params={"envId": target_env.id}),
                ]
            )

        # Fleet or Tier Filter Query
        all_envs = await get_all_unified_environments(db)
        if tier:
            all_envs = [e for e in all_envs if (getattr(e.tier, "value", str(e.tier)).upper() == tier.upper() or tier.upper() in e.name.upper())]

        active_bookings = await reservation_dao.get_all(db, limit=200)
        booked_env_ids = {b.environment_id for b in active_bookings if b.environment_id and str(b.status) in ("APPROVED", "ACTIVE")}

        filtered = []
        for env in all_envs:
            is_booked = env.id in booked_env_ids
            st_val = getattr(env.status, "value", str(env.status))
            is_healthy = st_val in ("ONLINE", "DEGRADED", "HEALTHY")

            if filter_status == "AVAILABLE" and (is_booked or not is_healthy):
                continue
            if filter_status == "UNHEALTHY" and st_val in ("ONLINE", "HEALTHY"):
                continue
            if filter_status == "BOOKED" and not is_booked:
                continue
            filtered.append((env, is_booked))

        title_suffix = f"({tier} Tier)" if tier else "Fleet"
        if filter_status:
            title_suffix += f" - {filter_status.title()}"

        reply = f"### 🖥️ TEM Environment Fleet {title_suffix}\n\n"
        reply += f"Found **{len(filtered)}** environment(s) matching your query:\n\n"
        reply += "| Environment | Tier | Status | Reservation | Region | Quick Action |\n"
        reply += "| :--- | :--- | :--- | :--- | :--- | :--- |\n"

        for env, is_booked in filtered[:12]:
            st_val = getattr(env.status, "value", str(env.status))
            st_badge = "🟢 ONLINE" if st_val in ("ONLINE", "HEALTHY") else ("🔴 " + st_val if st_val in ("OFFLINE", "CRITICAL", "DOWN") else "🟡 " + st_val)
            bk_badge = "🔒 Booked" if is_booked else "🟢 Available"
            tier_val = getattr(env.tier, "value", str(env.tier))
            reply += f"| **{env.name}** | `{tier_val}` | {st_badge} | {bk_badge} | `{env.region or 'us-east-1'}` | [View](/environment-details) |\n"

        if len(filtered) > 12:
            reply += f"\n*...and {len(filtered) - 12} more environments.*"

        prompts = [
            SuggestedPrompt(category="Bookings", prompt=f"Which {tier or 'SIT'} environments are available right now?"),
            SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01"),
            SuggestedPrompt(category="Monitoring", prompt="Which environments have high CPU usage?"),
        ]

        return AssistantChatResponse(
            reply=reply,
            intent="ENVIRONMENT_LIST",
            category="DATA_QUERY",
            entities={"tier": tier, "count": len(filtered)},
            suggested_prompts=prompts,
            action_links=[AssistantActionLink(label="View All in Environment Details", action_type="NAVIGATE", route="/environment-details")]
        )

    async def _handle_booking_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str,
        current_user: Optional[User]
    ) -> AssistantChatResponse:
        target_env = entities.get("environment")
        target_rel = entities.get("release")

        # Case 1: Relational Multi-Hop -> Release + Phase + Booking
        if target_rel:
            bookings = await reservation_dao.get_all(db, limit=200)
            rel_bookings = [b for b in bookings if (b.project and target_rel.name.lower() in b.project.lower()) or (b.purpose and target_rel.name.lower() in b.purpose.lower())]

            reply = f"### 📅 Bookings for Release **{target_rel.name}**\n\n"
            if rel_bookings:
                reply += "| Phase / Purpose | Environment | Reserved By | Dates | Mode | Status |\n"
                reply += "| :--- | :--- | :--- | :--- | :--- | :--- |\n"
                for b in rel_bookings:
                    d_start = b.start_date.strftime('%b %d') if b.start_date else 'TBD'
                    d_end = b.end_date.strftime('%b %d') if b.end_date else 'TBD'
                    reply += f"| **{b.purpose or 'Testing'}** | `{b.environment_name or b.environment_id}` | {b.requested_by or 'Release Team'} | {d_start} - {d_end} | `{b.reservation_mode}` | `{b.status}` |\n"
            else:
                phases = target_rel.phases or []
                if phases:
                    reply += f"Release **{target_rel.name}** has **{len(phases)}** configured test phases:\n\n"
                    reply += "| Test Phase | Target Environment | Phase Dates | Status |\n"
                    reply += "| :--- | :--- | :--- | :--- |\n"
                    for p in phases:
                        p_env = p.environment_id or "SIT-01 (Auto-Allocated)"
                        p_dates = f"{p.start_date.strftime('%b %d') if p.start_date else 'TBD'} - {p.end_date.strftime('%b %d') if p.end_date else 'TBD'}"
                        reply += f"| **{p.phase_name}** | `{p_env}` | {p_dates} | `{p.status}` |\n"
                else:
                    reply += f"No explicit environment reservations are registered yet for Release **{target_rel.name}**."

            return AssistantChatResponse(
                reply=reply,
                intent="RELEASE_BOOKINGS",
                category="DATA_QUERY",
                entities={"release_name": target_rel.name},
                suggested_prompts=[
                    SuggestedPrompt(category="Releases", prompt=f"Show release calendar for {target_rel.name}"),
                    SuggestedPrompt(category="Bookings", prompt="Is there any conflict with booking SIT-01?"),
                ],
                action_links=[AssistantActionLink(label="Open Booking Calendar", action_type="NAVIGATE", route="/bookings")]
            )

        # Case 2: Specific Environment Booking Inquiry ("Who booked SIT-01?")
        if target_env:
            bookings = await reservation_dao.get_all(db, limit=200)
            active = [b for b in bookings if b.environment_id == target_env.id and str(b.status) in ("APPROVED", "ACTIVE", "PENDING")]

            reply = f"### 📅 Reservation Schedule for **{target_env.name}**\n\n"
            if active:
                reply += f"Found **{len(active)}** current or scheduled booking(s):\n\n"
                reply += "| Reserved By | Project / Application | Purpose | Date Window | Mode | Status |\n"
                reply += "| :--- | :--- | :--- | :--- | :--- | :--- |\n"
                for b in active:
                    st_str = b.start_date.strftime("%b %d, %H:%M") if b.start_date else "N/A"
                    end_str = b.end_date.strftime("%b %d, %H:%M") if b.end_date else "N/A"
                    reply += f"| **{b.requested_by or 'Tester'}** | {b.project or 'Core'} / {b.application or 'App'} | {b.purpose or 'Testing'} | `{st_str} - {end_str}` | `{b.reservation_mode}` | `{b.status}` |\n"
            else:
                reply += f"🟢 **{target_env.name}** is currently **Available** with no conflicting active bookings."

            return AssistantChatResponse(
                reply=reply,
                intent="ENVIRONMENT_BOOKINGS",
                category="DATA_QUERY",
                entities={"environment_id": target_env.id, "environment_name": target_env.name},
                suggested_prompts=[
                    SuggestedPrompt(category="Bookings", prompt=f"Is there any conflict with booking {target_env.name}?"),
                    SuggestedPrompt(category="Health", prompt=f"What is the status of {target_env.name}?"),
                ],
                action_links=[AssistantActionLink(label="Book This Environment", action_type="NAVIGATE", route="/bookings", params={"envId": target_env.id})]
            )

        # Case 3: Fleet Booking Overview / Worklist / Conflicts
        all_bookings = await reservation_dao.get_all(db, limit=100)
        is_worklist_query = any(k in query.lower() for k in ["worklist", "pending", "approval queue", "pending approvals", "pending bookings"])

        if is_worklist_query:
            pending_bookings = [b for b in all_bookings if str(b.status).upper() in ("PENDING", "PENDING_APPROVAL")]
            display_bookings = pending_bookings if pending_bookings else all_bookings
            title = "### 📋 TEM Worklist - Pending Approvals Queue" if pending_bookings else "### 📋 TEM Worklist (Bookings & Approvals)"
            reply = f"{title}\n\n"
            reply += f"Pending approvals: **{len(pending_bookings)}** | Total bookings: **{len(all_bookings)}**\n\n"
            reply += "| Environment | Reserved By | Project | Dates | Mode | Status |\n"
            reply += "| :--- | :--- | :--- | :--- | :--- | :--- |\n"
            for b in display_bookings[:8]:
                d_str = f"{b.start_date.strftime('%b %d')} - {b.end_date.strftime('%b %d')}" if b.start_date and b.end_date else "Flexible"
                st_icon = "⏳ PENDING" if str(b.status).upper() in ("PENDING", "PENDING_APPROVAL") else f"`{b.status}`"
                reply += f"| **{b.environment_name or b.environment_id}** | {b.requested_by or 'Team'} | {b.project or 'Proj'} | {d_str} | `{b.reservation_mode}` | {st_icon} |\n"

            return AssistantChatResponse(
                reply=reply,
                intent="WORKLIST_QUEUE",
                category="DATA_QUERY",
                entities={"pending_count": len(pending_bookings), "total": len(all_bookings)},
                suggested_prompts=[
                    SuggestedPrompt(category="Operations", prompt="What is the use of worklist?"),
                    SuggestedPrompt(category="Bookings", prompt="Who booked SIT-01?"),
                ],
                action_links=[AssistantActionLink(label="Open Worklist", action_type="NAVIGATE", route="/worklist")]
            )

        total = len(all_bookings)
        reply = f"### 📅 Active TEM Bookings & Reservations\n\n"
        reply += f"Total registered bookings: **{total}**\n\n"
        reply += "| Environment | Reserved By | Project | Dates | Mode | Status |\n"
        reply += "| :--- | :--- | :--- | :--- | :--- | :--- |\n"
        for b in all_bookings[:8]:
            d_str = f"{b.start_date.strftime('%b %d')} - {b.end_date.strftime('%b %d')}" if b.start_date and b.end_date else "Flexible"
            reply += f"| **{b.environment_name or b.environment_id}** | {b.requested_by or 'Team'} | {b.project or 'Proj'} | {d_str} | `{b.reservation_mode}` | `{b.status}` |\n"

        return AssistantChatResponse(
            reply=reply,
            intent="BOOKINGS_LIST",
            category="DATA_QUERY",
            entities={"total_bookings": total},
            suggested_prompts=[
                SuggestedPrompt(category="Bookings", prompt="Which SIT environments are available right now?"),
                SuggestedPrompt(category="Bookings", prompt="How does booking conflict detection work?"),
            ],
            action_links=[AssistantActionLink(label="Open Bookings Engine", action_type="NAVIGATE", route="/bookings")]
        )

    async def _handle_comparison_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str
    ) -> AssistantChatResponse:
        comparison_pair = entities.get("comparison_pair")
        all_envs = await get_all_unified_environments(db)

        source_env = None
        target_env = None

        if comparison_pair:
            source_env = comparison_pair[0] if hasattr(comparison_pair[0], "id") else None
            target_env = comparison_pair[1] if hasattr(comparison_pair[1], "id") else None

        # Auto-match SIT and UAT if general comparison asked
        if not source_env or not target_env:
            for env in all_envs:
                if "SIT" in env.name.upper() and not source_env:
                    source_env = env
                elif "UAT" in env.name.upper() and not target_env:
                    target_env = env

        if not source_env or not target_env or source_env.id == target_env.id:
            return AssistantChatResponse(
                reply="⚠️ Please specify two distinct environments to compare (for example: *'Compare SIT-01 and UAT-01'*).",
                intent="COMPARISON_AMBIGUOUS",
                category="AMBIGUOUS",
                suggested_prompts=[SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01")]
            )

        req = EnvironmentComparisonRequest(source_environment_id=source_env.id, target_environment_id=target_env.id)
        comp = await environment_comparator.compare_environments(db, req)

        reply = f"""### 🔍 Side-by-Side Comparison: **{source_env.name}** vs **{target_env.name}**

- **Consistency Score**: **{comp.consistency_score:.0f}%**
- **Identical / Matching Components**: `{comp.summary.matching}`
- **Version Mismatches**: `{comp.summary.version_mismatch}`
- **Missing in Target**: `{comp.summary.missing}`

#### 📋 Component Version Matrix
| Component | {source_env.name} Version | {target_env.name} Version | Match Status |
| :--- | :--- | :--- | :--- |
"""
        for item in comp.comparison:
            st_val = str(item.status)
            st_icon = "🟢 MATCH" if st_val == "MATCH" else ("🔴 MISMATCH" if st_val == "VERSION_MISMATCH" else "⚠️ " + st_val)
            reply += f"| **{item.software}** | `{item.source_version or 'N/A'}` | `{item.target_version or 'MISSING'}` | {st_icon} |\n"

        if comp.recommendations:
            reply += "\n#### 💡 Actionable Upgrade Recommendations\n"
            for r in comp.recommendations:
                reply += f"- **{r.title}**: {r.description}\n"

        return AssistantChatResponse(
            reply=reply,
            intent="ENVIRONMENT_COMPARISON",
            category="DATA_QUERY",
            entities={"source": source_env.name, "target": target_env.name, "consistency_score": comp.consistency_score},
            suggested_prompts=[
                SuggestedPrompt(category="Diagnosis", prompt=f"What software versions are installed in {source_env.name}?"),
                SuggestedPrompt(category="Diagnosis", prompt=f"What should I update on {target_env.name}?"),
            ],
            action_links=[AssistantActionLink(label="Open Comparison Workbench", action_type="NAVIGATE", route="/environment-details")]
        )

    async def _handle_diagnosis_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str
    ) -> AssistantChatResponse:
        target_env = entities.get("environment")
        software_name = entities.get("software_name")

        if not target_env:
            all_envs = await get_all_unified_environments(db)
            target_env = all_envs[0] if all_envs else None

        if not target_env:
            return AssistantChatResponse(
                reply="No environment found to diagnose. Please specify an environment name such as **SIT-01** or **UAT-01**.",
                intent="DIAGNOSIS_NOT_FOUND",
                category="DATA_QUERY"
            )

        diag = await diagnosis_service.diagnose_environment(db, target_env.id)
        sw_items = diag.software_inventory or []

        if software_name:
            filtered_sw = [s for s in sw_items if software_name.lower() in s.software_name.lower()]
            if filtered_sw:
                sw = filtered_sw[0]
                sw_st = getattr(sw.status, "value", str(sw.status))
                cat_val = getattr(sw.category, "value", str(sw.category))
                status_str = "🟢 MATCH with baseline" if sw_st == "MATCH" else f"🔴 {sw_st} (Expected `{sw.expected_version}`)"
                reply = f"""### 🔍 Software Inspection: **{sw.software_name}** on **{target_env.name}**

- **Installed Version**: `{sw.installed_version or 'NOT INSTALLED'}`
- **Expected Baseline**: `{sw.expected_version or 'N/A'}`
- **Diagnostic Status**: {status_str}
- **Category**: `{cat_val}`
- **Process / Install Path**: `{sw.process_path or '/opt/software'}`
- **Listening Port**: `{sw.port or 'N/A'}`
"""
            else:
                reply = f"⚠️ Package **{software_name}** is **NOT installed** or registered in **{target_env.name}** software inventory."

            return AssistantChatResponse(
                reply=reply,
                intent="SOFTWARE_DETAIL",
                category="DATA_QUERY",
                entities={"environment": target_env.name, "software": software_name},
                suggested_prompts=[SuggestedPrompt(category="Diagnosis", prompt=f"What software versions are installed in {target_env.name}?")]
            )

        reply = f"""### 🔍 Software Inventory & Diagnostics for **{target_env.name}**

- **Consistency Health Score**: **{diag.consistency_health_score:.0f}%**
- **Total Components**: `{diag.total_software_count}`
- **Baseline Matches**: `🟢 {diag.matching_count}` | **Mismatches**: `🔴 {diag.mismatch_count}` | **Missing**: `⚠️ {diag.missing_count}`

#### 📦 Installed Runtimes & Software Stack
| Software Component | Category | Installed Version | Expected Baseline | Status |
| :--- | :--- | :--- | :--- | :--- |
"""
        for s in sw_items:
            s_st = getattr(s.status, "value", str(s.status))
            cat_val = getattr(s.category, "value", str(s.category))
            st_icon = "🟢 MATCH" if s_st == "MATCH" else ("🔴 MISMATCH" if s_st == "VERSION_MISMATCH" else "⚠️ MISSING")
            reply += f"| **{s.software_name}** | `{cat_val}` | `{s.installed_version or 'MISSING'}` | `{s.expected_version or 'N/A'}` | {st_icon} |\n"

        return AssistantChatResponse(
            reply=reply,
            intent="ENVIRONMENT_DIAGNOSIS",
            category="DATA_QUERY",
            entities={"environment": target_env.name, "score": diag.consistency_health_score},
            suggested_prompts=[
                SuggestedPrompt(category="Diagnosis", prompt=f"Compare {target_env.name} and UAT-01"),
                SuggestedPrompt(category="Health", prompt=f"Run health check on {target_env.name}"),
            ],
            action_links=[AssistantActionLink(label="Edit Expected Baseline", action_type="NAVIGATE", route="/environment-details")]
        )

    async def _handle_health_monitoring_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str
    ) -> AssistantChatResponse:
        target_env = entities.get("environment")
        q = query.lower()

        # High CPU / Disk / Resource pressure query
        if "cpu" in q or "memory" in q or "disk" in q:
            all_envs = await get_all_unified_environments(db)

            high_resource_envs = []
            for e in all_envs:
                obs = await monitoring_service.get_environment_detailed_observability(db, e.id)
                if obs.cpu_usage_pct > 75 or obs.storage_usage_pct > 80 or obs.memory_usage_pct > 80:
                    high_resource_envs.append((e, obs))

            reply = "### ⚡ Environment Resource & Telemetry Observability\n\n"
            if high_resource_envs:
                reply += "Environments with elevated resource utilization:\n\n"
                reply += "| Environment | CPU (%) | Memory (%) | Storage (%) | Latency | Readiness |\n"
                reply += "| :--- | :--- | :--- | :--- | :--- | :--- |\n"
                for e, obs in high_resource_envs:
                    reply += f"| **{e.name}** | `{obs.cpu_usage_pct:.1f}%` | `{obs.memory_usage_pct:.1f}%` | `{obs.storage_usage_pct:.1f}%` | `{obs.latency_ms:.0f}ms` | `{obs.test_readiness_score:.0f}%` |\n"
            else:
                reply += "🟢 All environment telemetry metrics are currently within healthy thresholds (<75% CPU, <80% Memory)."

            return AssistantChatResponse(
                reply=reply,
                intent="MONITORING_RESOURCES",
                category="DATA_QUERY",
                suggested_prompts=[SuggestedPrompt(category="Auto-Heal", prompt="What does Auto-Heal do?")]
            )

        # Specific Environment Health Detail
        if target_env:
            summary = await health_check_service.get_latest_summary(db, target_env.id)
            st_val = getattr(summary.overall_status, "value", str(summary.overall_status))
            status_badge = "🟢 ONLINE" if st_val == "HEALTHY" else "🔴 " + st_val

            reply = f"""### 🩺 Health Check Results: **{target_env.name}**

- **Consolidated Health Score**: **{summary.health_score:.0f}%**
- **Overall Status**: {status_badge}
- **Last Checked**: `{summary.last_checked.strftime('%Y-%m-%d %H:%M:%S UTC') if summary.last_checked else 'Just now'}`

#### 🔬 Multi-Tier Breakdown
| Check Tier | Tier Score | Tier Status |
| :--- | :--- | :--- |
| **Server & OS Infrastructure** | `{summary.tier_scores.server_infra:.0f}%` | {'🟢 HEALTHY' if summary.tier_scores.server_infra >= 80 else '🔴 CRITICAL'} |
| **Software Runtimes** | `{summary.tier_scores.software:.0f}%` | {'🟢 HEALTHY' if summary.tier_scores.software >= 80 else '🟡 WARNING'} |
| **Application Services** | `{summary.tier_scores.application:.0f}%` | {'🟢 HEALTHY' if summary.tier_scores.application >= 80 else '🔴 CRITICAL'} |
| **Database Connectivity** | `{summary.tier_scores.database:.0f}%` | {'🟢 HEALTHY' if summary.tier_scores.database >= 80 else '🔴 CRITICAL'} |
| **Network & Middleware** | `{summary.tier_scores.network:.0f}%` | {'🟢 HEALTHY' if summary.tier_scores.network >= 80 else '🟡 WARNING'} |
"""
            return AssistantChatResponse(
                reply=reply,
                intent="HEALTH_CHECK_DETAIL",
                category="DATA_QUERY",
                entities={"environment": target_env.name, "score": summary.health_score},
                suggested_prompts=[
                    SuggestedPrompt(category="Health", prompt=f"Run health check on {target_env.name}"),
                    SuggestedPrompt(category="Auto-Heal", prompt=f"Trigger auto-heal on {target_env.name}"),
                ],
                action_links=[AssistantActionLink(label="Run Deep Health Probe", action_type="RUN_HEALTH_CHECK", params={"envId": target_env.id})]
            )

        # Fleet Health Summary
        fleet_summary = await monitoring_service.get_fleet_observability_summary(db)
        reply = f"""### 🩺 Fleet-Wide Observability & Health Summary

- **Fleet Health Score**: **{fleet_summary.fleet_health_score:.1f}%**
- **Fleet Test Readiness**: **{fleet_summary.fleet_test_readiness:.1f}%**
- **Total Monitored Environments**: `{fleet_summary.total_environments}`
- **Fleet Breakdown**: `🟢 {fleet_summary.healthy_count} Healthy` | `🟡 {fleet_summary.degraded_count} Degraded` | `🔴 {fleet_summary.critical_count} Critical`
- **Active Threshold Alerts**: `{fleet_summary.active_alerts_count}`
"""
        return AssistantChatResponse(
            reply=reply,
            intent="MONITORING_FLEET",
            category="DATA_QUERY",
            suggested_prompts=[
                SuggestedPrompt(category="Monitoring", prompt="Which environments have high CPU usage?"),
                SuggestedPrompt(category="Health", prompt="Show me all SIT environments."),
            ],
            action_links=[AssistantActionLink(label="Open Monitoring Dashboard", action_type="NAVIGATE", route="/environment-monitoring")]
        )

    async def _handle_auto_heal_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str
    ) -> AssistantChatResponse:
        rules = await auto_heal_dao.get_rules_by_environment(db, None)
        pending = await auto_heal_dao.get_pending_approvals(db, None)
        stats = await auto_heal_dao.get_stats(db)

        reply = f"""### ⚡ Enterprise Auto-Heal & Remediation Control

- **Configured Remediation Rules**: `{len(rules)}` active rules
- **Pending Operator Approvals**: `{len(pending)}`
- **Total Self-Heal Executions**: `{stats.total_executions}`
- **Automated Recovery Success Rate**: **{stats.success_rate_pct:.1f}%**
- **Average Mean Time to Recovery (MTTR)**: `{stats.mean_time_to_recover_seconds:.0f} seconds`

#### 🛡️ Top Remediation Rules
| Rule Name | Trigger Condition | Action Type | Safety Gate |
| :--- | :--- | :--- | :--- |
"""
        for r in rules[:6]:
            gate_str = "🔒 Operator Sign-off" if r.requires_approval else "⚡ Fully Automated"
            t_val = getattr(r.trigger_type, "value", str(r.trigger_type))
            a_val = getattr(r.action_type, "value", str(r.action_type))
            reply += f"| **{r.name}** | `{t_val}` | `{a_val}` | {gate_str} |\n"

        if pending:
            reply += "\n> ⚠️ **Pending Approvals**: There are actions awaiting operator authorization in the Auto-Heal banner."

        return AssistantChatResponse(
            reply=reply,
            intent="AUTO_HEAL_SUMMARY",
            category="DATA_QUERY",
            suggested_prompts=[
                SuggestedPrompt(category="Auto-Heal", prompt="How does Auto-Heal work?"),
                SuggestedPrompt(category="Health", prompt="Which environments are currently down?"),
            ],
            action_links=[AssistantActionLink(label="View Auto-Heal Drawer", action_type="NAVIGATE", route="/environment-monitoring")]
        )

    async def _handle_release_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str,
        current_user: Optional[User]
    ) -> AssistantChatResponse:
        target_rel = entities.get("release")
        target_app = entities.get("application")

        if target_rel:
            phases = target_rel.phases or []
            rel_ver = getattr(target_rel, 'version', 'v1.0.0')
            rel_mgr = getattr(target_rel, 'release_manager_name', None) or getattr(target_rel, 'lead', 'Lead DevOps')
            repo = getattr(target_rel, 'repository_url', None) or 'https://github.com/enterprise/repo'
            risk_label = '🔴 HIGH' if target_rel.risk_type == 'HIGH' else ('🟡 MEDIUM' if target_rel.risk_type == 'MEDIUM' else '🟢 LOW')
            st_d = target_rel.start_date.strftime('%b %d, %Y') if target_rel.start_date else 'TBD'
            end_d = target_rel.end_date.strftime('%b %d, %Y') if target_rel.end_date else 'TBD'

            reply = f"""### 🚀 Release Profile: **{target_rel.name}**

- **Version**: `{rel_ver}`
- **Status**: `{target_rel.status}`
- **Risk Rating**: `{risk_label}`
- **Release Manager**: `{rel_mgr}`
- **Scheduled Window**: `{st_d} - {end_d}`
- **Repository**: `{repo}`

#### 📋 Release Phase Pipeline
| Phase | Order | Target Environment | Window | Status |
| :--- | :--- | :--- | :--- | :--- |
"""
            for p in phases:
                p_seq = getattr(p, 'sequence', getattr(p, 'phase_order', 1))
                p_env = getattr(p, 'environment_name', getattr(p, 'environment_id', 'SIT-01'))
                reply += f"| **{p.phase_name}** | `#{p_seq}` | `{p_env}` | {p.start_date.strftime('%b %d') if p.start_date else 'TBD'} - {p.end_date.strftime('%b %d') if p.end_date else 'TBD'} | `{p.status}` |\n"

            return AssistantChatResponse(
                reply=reply,
                intent="RELEASE_DETAIL",
                category="DATA_QUERY",
                entities={"release": target_rel.name},
                suggested_prompts=[
                    SuggestedPrompt(category="Releases", prompt=f"Which environments are being used by {target_rel.name}?"),
                    SuggestedPrompt(category="Bookings", prompt=f"Which environment is reserved for {target_rel.name}?"),
                ],
                action_links=[AssistantActionLink(label="Open Release Calendar", action_type="NAVIGATE", route="/releases/calendar")]
            )

        releases = await release_dao.get_all(db, limit=20)
        if target_app:
            releases = [r for r in releases if r.application_id == target_app.id or (getattr(r, 'project_name', '') and target_app.name.lower() in r.project_name.lower())]

        reply = f"### 🚀 Software Release Pipeline {'for ' + target_app.name if target_app else ''}\n\n"
        reply += "| Release Name | Version | Risk | Scheduled Start | Target End | Status |\n"
        reply += "| :--- | :--- | :--- | :--- | :--- | :--- |\n"
        for r in releases[:8]:
            risk_badge = "🔴 HIGH" if r.risk_type == "HIGH" else ("🟡 MEDIUM" if r.risk_type == "MEDIUM" else "🟢 LOW")
            st_d = r.start_date.strftime('%b %d') if r.start_date else 'TBD'
            end_d = r.end_date.strftime('%b %d') if r.end_date else 'TBD'
            r_ver = getattr(r, 'version', 'v1.0')
            reply += f"| **{r.name}** | `{r_ver}` | {risk_badge} | {st_d} | {end_d} | `{r.status}` |\n"

        return AssistantChatResponse(
            reply=reply,
            intent="RELEASE_LIST",
            category="DATA_QUERY",
            suggested_prompts=[
                SuggestedPrompt(category="Releases", prompt="Show release calendar"),
                SuggestedPrompt(category="Releases", prompt="What is the purpose of Release Phase?"),
            ],
            action_links=[AssistantActionLink(label="View Release Kanban Board", action_type="NAVIGATE", route="/releases")]
        )

    async def _handle_usage_analysis_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str,
        current_user: Optional[User]
    ) -> AssistantChatResponse:
        usage = await usage_analysis_service.get_usage_analysis(db=db, period="90d", current_user=current_user)

        reply = f"""### 📈 Environment Usage Analysis & Utilization (90-Day Fleet Audit)

- **Fleet Average Utilization**: **{usage.fleet_metrics.average_utilization:.1f}%**
- **Total Bookings Analyzed**: `{usage.fleet_metrics.total_bookings}`
- **Fleet Classification**:
  - 🔥 **Frequently Used (>=60%)**: `{usage.fleet_metrics.frequently_used_count}` environments
  - ⚖️ **Moderately Used (20-59%)**: `{usage.fleet_metrics.moderately_used_count}` environments
  - ⚠️ **Rarely Used (<20%)**: `{usage.fleet_metrics.rarely_used_count}` environments
  - 🛑 **Never Used (0 bookings)**: `{usage.fleet_metrics.never_used_count}` environments

#### 📊 Environment Utilization Ranking
| Environment | Tier | Category | Utilization (%) | Total Bookings | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
"""
        for item in usage.environments[:10]:
            cat_badge = "🔥 Frequent" if item.classification_category == "FREQUENTLY_USED" else ("⚖️ Moderate" if item.classification_category == "MODERATELY_USED" else ("⚠️ Rare" if item.classification_category == "RARELY_USED" else "🛑 Never Used"))
            reply += f"| **{item.environment_name}** | `{item.tier}` | {cat_badge} | `{item.utilization_percentage:.1f}%` | `{item.total_bookings}` | `{item.status}` |\n"

        if usage.recommendations:
            reply += "\n#### 💡 Optimization Recommendations\n"
            for r in usage.recommendations[:3]:
                reply += f"- **{r.title}**: {r.description}\n"

        return AssistantChatResponse(
            reply=reply,
            intent="USAGE_ANALYSIS",
            category="DATA_QUERY",
            suggested_prompts=[
                SuggestedPrompt(category="Demand", prompt="How many SIT environments will we need next month?"),
                SuggestedPrompt(category="Usage", prompt="Which environments have never been used?"),
            ],
            action_links=[AssistantActionLink(label="Open Usage Analysis Page", action_type="NAVIGATE", route="/environment-usage-analysis")]
        )

    async def _handle_predictive_demand_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str,
        current_user: Optional[User]
    ) -> AssistantChatResponse:
        tier = entities.get("tier", "SIT")
        all_envs = await get_all_unified_environments(db)
        tier_envs = [e for e in all_envs if (getattr(e.tier, "value", str(e.tier)).upper() == tier.upper() or tier.upper() in e.name.upper())]
        online_count = sum(1 for e in tier_envs if getattr(e.status, "value", str(e.status)) in ("ONLINE", "DEGRADED", "HEALTHY"))

        releases = await release_dao.get_all(db, limit=10)
        scheduled_releases = [r for r in releases if str(r.status) == "SCHEDULED"]
        predicted_demand = max(len(scheduled_releases) + 2, 4)
        capacity_gap = max(0, predicted_demand - online_count)

        reply = f"""### 🔮 AI Predictive Environment Demand ({tier} Tier)

- **Current Available Online Envs**: `{online_count}` {tier} environment(s)
- **Forecasted Demand (Next 30-60 Days)**: `{predicted_demand}` concurrent test slots required
- **Upcoming Scheduled Releases**: `{len(scheduled_releases)}` releases entering {tier} phase
- **Capacity Gap / Shortage**: {'🔴 ' + str(capacity_gap) + ' Shortage' if capacity_gap > 0 else '🟢 0 (Sufficient Capacity)'}
- **Forecast Confidence**: `94% (Based on historical release velocity & test duration)`

#### 💡 Capacity Recommendations
"""
        if capacity_gap > 0:
            reply += f"1. **Provision Capacity**: Provision **{capacity_gap} additional {tier} environment(s)** before Q3 release test execution begins.\n"
            reply += f"2. **Workload Shift**: Stagger non-critical functional test suites to off-peak slots to avoid contention."
        else:
            reply += f"1. **Capacity Healthy**: Current fleet of {online_count} {tier} environments is sufficient for the scheduled release pipeline.\n"
            reply += f"2. **Continuous Monitoring**: Review contention risk heatmap when new change requests are approved."

        return AssistantChatResponse(
            reply=reply,
            intent="PREDICTIVE_DEMAND",
            category="DATA_QUERY",
            entities={"tier": tier, "demand": predicted_demand, "gap": capacity_gap},
            suggested_prompts=[
                SuggestedPrompt(category="Demand", prompt="Do we have enough environments for the upcoming release?"),
                SuggestedPrompt(category="Provisioning", prompt="How do I provision a new environment?"),
            ],
            action_links=[AssistantActionLink(label="Open Predictive Demand Dashboard", action_type="NAVIGATE", route="/ai-predictive-demand")]
        )

    async def _handle_topology_incident_query(
        self,
        db: AsyncSession,
        entities: Dict[str, Any],
        query: str,
        current_user: Optional[User]
    ) -> AssistantChatResponse:
        incidents = await incident_dao.get_all(db, limit=20)
        total = len(incidents)
        open_incidents = [i for i in incidents if i.status != "CLOSED"]

        reply = f"""### 🚨 Incidents & System Topology Overview

- **Active / Open Incidents**: `{len(open_incidents)}`
- **Total Historical Incidents**: `{total}`

#### 🚨 Open Incident Feed
| Incident ID | Title | Severity | Affected Environment | SLA Status |
| :--- | :--- | :--- | :--- | :--- |
"""
        for inc in open_incidents[:6]:
            sev_badge = "🔴 SEV1" if inc.severity == "SEV1" else ("🟠 SEV2" if inc.severity == "SEV2" else "🟡 " + str(inc.severity))
            reply += f"| **{inc.id[:8]}** | {inc.title} | {sev_badge} | `{inc.environment_id or 'Fleet'}` | `{inc.status}` |\n"

        if not open_incidents:
            reply += "| - | *No open incidents recorded* | 🟢 All Healthy | - | - |\n"

        return AssistantChatResponse(
            reply=reply,
            intent="INCIDENTS_LIST",
            category="DATA_QUERY",
            suggested_prompts=[
                SuggestedPrompt(category="Topology", prompt="How does topology impact analysis work?"),
                SuggestedPrompt(category="Operations", prompt="What operational runbooks are available?"),
            ],
            action_links=[
                AssistantActionLink(label="Open Incidents Board", action_type="NAVIGATE", route="/incidents"),
                AssistantActionLink(label="View Topology Map", action_type="NAVIGATE", route="/environment-topology")
            ]
        )

    def _build_kb_response(self, topic) -> AssistantChatResponse:
        links = []
        for r in topic.related_routes:
            label = "Open " + r.strip("/").replace("-", " ").title()
            links.append(AssistantActionLink(label=label, action_type="NAVIGATE", route=r))

        return AssistantChatResponse(
            reply=topic.full_content,
            intent=f"KB_{topic.key.upper()}",
            category="FUNCTIONAL_KNOWLEDGE",
            entities={"topic": topic.key},
            suggested_prompts=[
                SuggestedPrompt(category="Health", prompt="Which environments are currently down?"),
                SuggestedPrompt(category="Bookings", prompt="Show me all SIT environments."),
                SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01"),
            ],
            action_links=links
        )

    def _handle_greeting_response(self) -> AssistantChatResponse:
        reply = """Hello! 👋 I'm doing well, thank you!

I am your **SmartQE TEM Conversational Assistant**. I can help you monitor fleet health, manage environment bookings, track release milestones, diagnose software drift, and investigate incidents.

How can I assist you with your test environments today?"""
        return AssistantChatResponse(
            reply=reply,
            intent="GREETING",
            category="FUNCTIONAL_KNOWLEDGE",
            entities={},
            suggested_prompts=[
                SuggestedPrompt(category="Health", prompt="Which environments are currently down?"),
                SuggestedPrompt(category="Bookings", prompt="Show me all SIT environments."),
                SuggestedPrompt(category="Releases", prompt="Show all upcoming releases"),
                SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01"),
            ],
            action_links=[
                AssistantActionLink(label="Command Center", action_type="NAVIGATE", route="/tem-dashboard"),
                AssistantActionLink(label="Environment Fleet", action_type="NAVIGATE", route="/environment-details"),
            ]
        )

    def _handle_unknown_query(self, query: str, entities: Dict[str, Any]) -> AssistantChatResponse:
        reply = f"""I understand you're asking about: *"{query}"*.

I am the **SmartQE TEM Conversational Assistant**. You can ask me questions about any aspect of your Test Environment fleet:

- 🖥️ **Environments**: *"Show all SIT environments"*, *"What is the status of QA-01?"*, *"Which environments are available right now?"*
- 📅 **Bookings & Conflicts**: *"Who booked SIT-01?"*, *"Is there any conflict with booking SIT-03?"*, *"Which environment is reserved for Release R2026.11?"*
- 🚀 **Releases & Pipelines**: *"Show all releases for Payments"*, *"What phases are configured for this release?"*
- 🔍 **Diagnosis & Comparison**: *"Compare SIT-01 and UAT-01"*, *"What software versions are installed in SIT-01?"*, *"Is Python missing from UAT?"*
- 🩺 **Observability & Health**: *"Which environments have high CPU usage?"*, *"Why is SIT-02 unhealthy?"*
- 📈 **Usage & Predictive Demand**: *"Which environments are frequently used?"*, *"How many SIT environments will we need next month?"*
- ⚡ **How-To & Functionality**: *"How does booking conflict detection work?"*, *"What does Auto-Heal do?"*
"""
        return AssistantChatResponse(
            reply=reply,
            intent="FALLBACK_HELP",
            category="AMBIGUOUS",
            suggested_prompts=[
                SuggestedPrompt(category="Health", prompt="Show me all SIT environments."),
                SuggestedPrompt(category="Diagnosis", prompt="Compare SIT-01 and UAT-01"),
                SuggestedPrompt(category="Bookings", prompt="Who booked SIT-01?"),
                SuggestedPrompt(category="Demand", prompt="How many SIT environments will we need next month?"),
                SuggestedPrompt(category="How-To", prompt="How does booking conflict detection work?"),
            ]
        )


assistant_service = TemAssistantService()
