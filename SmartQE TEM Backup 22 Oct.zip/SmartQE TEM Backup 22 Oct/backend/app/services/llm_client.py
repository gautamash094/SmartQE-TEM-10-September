"""
Multi-Provider Asynchronous LLM Client.
Supports Google Gemini (gemini-1.5-flash, gemini-1.5-pro) and OpenAI (gpt-4o, gpt-4o-mini),
as well as local Ollama, with zero external bloat using httpx.
Features automatic cross-provider failover (Gemini <-> OpenAI) and timeout handling.
"""
import logging
from typing import Any, Dict, List, Optional
import httpx

from app.core.config import settings

logger = logging.getLogger("tem.assistant.llm")


class LLMResponse:
    def __init__(
        self,
        content: str,
        provider: str,
        model: str,
        success: bool = True,
        error_message: Optional[str] = None
    ):
        self.content = content
        self.provider = provider
        self.model = model
        self.success = success
        self.error_message = error_message


class LLMClient:
    def __init__(self):
        self.timeout = float(settings.LLM_TIMEOUT_SECONDS)

    def is_configured(self) -> bool:
        """Checks if any valid LLM provider is active and configured."""
        if not settings.LLM_ENABLED:
            return False
        return bool(
            (settings.GEMINI_API_KEY and settings.GEMINI_API_KEY.strip()) or
            (settings.OPENAI_API_KEY and settings.OPENAI_API_KEY.strip()) or
            (settings.LLM_PROVIDER == "ollama")
        )

    def resolve_provider(self, requested_provider: Optional[str] = None) -> str:
        """
        Determines which provider to execute based on request, settings, and available keys.
        Supports 'gemini', 'openai', 'ollama', or 'auto'.
        """
        req_provider = (requested_provider or settings.LLM_PROVIDER or "auto").lower().strip()

        if req_provider == "gemini" and settings.GEMINI_API_KEY and settings.GEMINI_API_KEY.strip():
            return "gemini"
        elif req_provider == "openai" and settings.OPENAI_API_KEY and settings.OPENAI_API_KEY.strip():
            return "openai"
        elif req_provider == "ollama":
            return "ollama"
        elif req_provider in ("auto", "none", ""):
            # Auto preference: Prefer Google Gemini (high speed & large context), then OpenAI
            if settings.GEMINI_API_KEY and settings.GEMINI_API_KEY.strip():
                return "gemini"
            elif settings.OPENAI_API_KEY and settings.OPENAI_API_KEY.strip():
                return "openai"

        return "none"

    async def generate_response(
        self,
        prompt: str,
        system_instruction: Optional[str] = None,
        history: Optional[List[Dict[str, str]]] = None,
        requested_provider: Optional[str] = None,
        requested_model: Optional[str] = None
    ) -> LLMResponse:
        """
        Routes the prompt to the configured LLM provider.
        If the primary provider encounters a rate limit or error and the other provider is configured,
        automatically performs cross-provider failover (Gemini <-> OpenAI).
        """
        primary_provider = self.resolve_provider(requested_provider)

        if primary_provider == "none":
            return LLMResponse(
                content="",
                provider="none",
                model="none",
                success=False,
                error_message="No active LLM provider configured with API key."
            )

        resp: Optional[LLMResponse] = None

        # 1. Attempt Primary Provider Execution
        try:
            if primary_provider == "gemini":
                resp = await self._call_gemini(prompt, system_instruction, history, override_model=requested_model)
            elif primary_provider == "openai":
                resp = await self._call_openai(prompt, system_instruction, history, override_model=requested_model)
            elif primary_provider == "ollama":
                resp = await self._call_ollama(prompt, system_instruction, history, override_model=requested_model)
        except Exception as e:
            logger.warning(f"Primary provider '{primary_provider}' raised exception: {e}")
            resp = LLMResponse(
                content="",
                provider=primary_provider,
                model=requested_model or "unknown",
                success=False,
                error_message=str(e)
            )

        # 2. Check for Success
        if resp and resp.success and resp.content:
            return resp

        # 3. Automatic Failover: Gemini <-> OpenAI
        primary_err = resp.error_message if resp else "Unknown error"
        if primary_provider == "gemini" and settings.OPENAI_API_KEY and settings.OPENAI_API_KEY.strip():
            logger.info(f"Gemini returned error ({primary_err}). Attempting automatic failover to OpenAI...")
            try:
                fallback_resp = await self._call_openai(prompt, system_instruction, history, override_model=None)
                if fallback_resp.success and fallback_resp.content:
                    logger.info("Failover to OpenAI succeeded!")
                    return fallback_resp
            except Exception as fe:
                logger.warning(f"Failover to OpenAI also failed: {fe}")

        elif primary_provider == "openai" and settings.GEMINI_API_KEY and settings.GEMINI_API_KEY.strip():
            logger.info(f"OpenAI returned error ({primary_err}). Attempting automatic failover to Google Gemini...")
            try:
                fallback_resp = await self._call_gemini(prompt, system_instruction, history, override_model=None)
                if fallback_resp.success and fallback_resp.content:
                    logger.info("Failover to Google Gemini succeeded!")
                    return fallback_resp
            except Exception as fe:
                logger.warning(f"Failover to Gemini also failed: {fe}")

        return resp or LLMResponse(
            content="",
            provider=primary_provider,
            model="unknown",
            success=False,
            error_message="All providers failed"
        )

    async def _call_gemini(
        self,
        prompt: str,
        system_instruction: Optional[str],
        history: Optional[List[Dict[str, str]]],
        override_model: Optional[str] = None
    ) -> LLMResponse:
        api_key = (settings.GEMINI_API_KEY or "").strip()
        if not api_key:
            return LLMResponse(content="", provider="gemini", model="none", success=False, error_message="Missing GEMINI_API_KEY")

        model = override_model or settings.GEMINI_MODEL or "gemini-flash-lite-latest"
        contents: List[Dict[str, Any]] = []

        # Map conversation history
        if history:
            for msg in history[-6:]:
                role = "user" if msg.get("role") == "user" else "model"
                contents.append({"role": role, "parts": [{"text": msg.get("content", "")}]})

        # Append current user prompt
        contents.append({"role": "user", "parts": [{"text": prompt}]})

        payload: Dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "temperature": float(settings.LLM_TEMPERATURE),
                "maxOutputTokens": 2048,
            }
        }

        if system_instruction:
            payload["system_instruction"] = {
                "parts": [{"text": system_instruction}]
            }

        async with httpx.AsyncClient(timeout=self.timeout, verify=False) as client:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
            resp = await client.post(url, json=payload, headers={"Content-Type": "application/json"})

            # If chosen model returned 404, auto-retry with gemini-flash-lite-latest
            if resp.status_code == 404 and model != "gemini-flash-lite-latest":
                logger.info(f"Model '{model}' returned 404, falling back to 'gemini-flash-lite-latest'...")
                model = "gemini-flash-lite-latest"
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
                resp = await client.post(url, json=payload, headers={"Content-Type": "application/json"})

            if resp.status_code != 200:
                err_text = resp.text
                logger.warning(f"Gemini API returned status {resp.status_code}: {err_text}")
                return LLMResponse(content="", provider="gemini", model=model, success=False, error_message=err_text)

            data = resp.json()
            candidates = data.get("candidates", [])
            if not candidates:
                return LLMResponse(content="", provider="gemini", model=model, success=False, error_message="No candidates returned")

            first_candidate = candidates[0]
            parts = first_candidate.get("content", {}).get("parts", [])
            text_result = "".join([p.get("text", "") for p in parts]).strip()

            return LLMResponse(content=text_result, provider="gemini", model=model, success=True)

    async def _call_openai(
        self,
        prompt: str,
        system_instruction: Optional[str],
        history: Optional[List[Dict[str, str]]],
        override_model: Optional[str] = None
    ) -> LLMResponse:
        api_key = (settings.OPENAI_API_KEY or "").strip()
        if not api_key:
            return LLMResponse(content="", provider="openai", model="none", success=False, error_message="Missing OPENAI_API_KEY")

        model = override_model or settings.OPENAI_MODEL or "gpt-4o-mini"
        url = "https://api.openai.com/v1/chat/completions"

        messages: List[Dict[str, str]] = []
        if system_instruction:
            messages.append({"role": "system", "content": system_instruction})

        if history:
            for msg in history[-6:]:
                role = "user" if msg.get("role") == "user" else "assistant"
                messages.append({"role": role, "content": msg.get("content", "")})

        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": model,
            "messages": messages,
            "temperature": float(settings.LLM_TEMPERATURE),
            "max_tokens": 2048,
        }

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        async with httpx.AsyncClient(timeout=self.timeout, verify=False) as client:
            resp = await client.post(url, json=payload, headers=headers)
            if resp.status_code != 200:
                err_text = resp.text
                logger.warning(f"OpenAI API returned status {resp.status_code}: {err_text}")
                return LLMResponse(content="", provider="openai", model=model, success=False, error_message=err_text)

            data = resp.json()
            choices = data.get("choices", [])
            if not choices:
                return LLMResponse(content="", provider="openai", model=model, success=False, error_message="No choices returned")

            text_result = choices[0].get("message", {}).get("content", "").strip()
            return LLMResponse(content=text_result, provider="openai", model=model, success=True)

    async def _call_ollama(
        self,
        prompt: str,
        system_instruction: Optional[str],
        history: Optional[List[Dict[str, str]]],
        override_model: Optional[str] = None
    ) -> LLMResponse:
        base_url = (settings.OLLAMA_BASE_URL or "http://localhost:11434").rstrip("/")
        model = override_model or settings.OLLAMA_MODEL or "llama3"
        url = f"{base_url}/api/chat"

        messages: List[Dict[str, str]] = []
        if system_instruction:
            messages.append({"role": "system", "content": system_instruction})

        if history:
            for msg in history[-6:]:
                role = "user" if msg.get("role") == "user" else "assistant"
                messages.append({"role": role, "content": msg.get("content", "")})

        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": float(settings.LLM_TEMPERATURE)
            }
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(url, json=payload, headers={"Content-Type": "application/json"})
            if resp.status_code != 200:
                return LLMResponse(content="", provider="ollama", model=model, success=False, error_message=resp.text)

            data = resp.json()
            text_result = data.get("message", {}).get("content", "").strip()
            return LLMResponse(content=text_result, provider="ollama", model=model, success=True)


llm_client = LLMClient()
