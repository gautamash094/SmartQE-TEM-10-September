import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.environment import Environment, EnvironmentStatus, EnvironmentTier
from app.models.environment_software import EnvironmentSoftware, SoftwareDiagnosisStatus, SoftwareCategory
from app.models.incident import Incident, IncidentStatus, IncidentSeverity
from app.models.reservation import Reservation, ReservationStatus
from app.models.monitoring import MonitoringThresholdRule, MonitoringMetricType, MonitoringEvent, EventState, EventSeverity
from app.services.monitoring_service import monitoring_service


@pytest.mark.asyncio
async def test_monitoring_fleet_summary_and_detailed_endpoints(client: AsyncClient, db_session: AsyncSession):
    # 1. Setup Environment
    env = Environment(
        name="TEST-OBS-ENV-01",
        tier=EnvironmentTier.SIT,
        team="Digital Payments",
        owner="Observability Lead",
        region="us-east-1",
        status=EnvironmentStatus.HEALTHY,
        cpu_usage=45.0,
        memory_usage=60.0,
        storage_usage=55.0
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # 2. Add Software Component with Match
    sw1 = EnvironmentSoftware(
        environment_id=env.id,
        environment_name=env.name,
        software_name="Payment Gateway API",
        category=SoftwareCategory.APPLICATION,
        installed_version="2.4.0",
        expected_version="2.4.0",
        status=SoftwareDiagnosisStatus.MATCH
    )
    # Add Software Component with Version Mismatch (Drift)
    sw2 = EnvironmentSoftware(
        environment_id=env.id,
        environment_name=env.name,
        software_name="Java Runtime",
        category=SoftwareCategory.RUNTIME,
        installed_version="17.0.8",
        expected_version="17.0.10",
        status=SoftwareDiagnosisStatus.VERSION_MISMATCH
    )
    db_session.add_all([sw1, sw2])
    await db_session.commit()

    # 3. Test GET /api/v1/monitoring/summary
    summary_resp = await client.get("/api/v1/monitoring/summary")
    assert summary_resp.status_code == 200
    summary_data = summary_resp.json()["data"]
    assert "kpis" in summary_data
    assert "environments" in summary_data
    assert summary_data["kpis"]["total_monitored_environments"] >= 1
    assert summary_data["kpis"]["environments_with_drift"] >= 1

    # 4. Test GET /api/v1/monitoring/environments/{env_id}
    detail_resp = await client.get(f"/api/v1/monitoring/environments/{env.id}")
    assert detail_resp.status_code == 200
    dossier = detail_resp.json()["data"]
    assert dossier["environment_name"] == "TEST-OBS-ENV-01"
    assert "health" in dossier
    assert "readiness" in dossier
    assert "drift_summary" in dossier
    assert "impact_summary" in dossier
    assert "auto_heal" in dossier
    assert "predictive_insights" in dossier
    assert dossier["drift_summary"]["has_drift"] is True
    assert dossier["drift_summary"]["version_mismatch"] == 1

    # 5. Test GET /api/v1/monitoring/environments/{env_id}/trends
    trends_resp = await client.get(f"/api/v1/monitoring/environments/{env.id}/trends?timeframe=24h")
    assert trends_resp.status_code == 200
    trends_data = trends_resp.json()["data"]
    assert trends_data["timeframe"] == "24h"
    assert len(trends_data["cpu"]["points"]) == 24
    assert len(trends_data["memory"]["points"]) == 24
    assert len(trends_data["health_score_trend"]["points"]) == 24

    # 6. Test GET /api/v1/monitoring/threshold-rules
    rules_resp = await client.get("/api/v1/monitoring/threshold-rules")
    assert rules_resp.status_code == 200
    rules = rules_resp.json()["data"]
    assert len(rules) >= 1

    # 7. Test POST /api/v1/monitoring/threshold-rules
    new_rule_payload = {
        "name": "Custom Error Rate Alert",
        "environment_id": env.id,
        "metric_type": "ERROR_RATE",
        "operator": ">",
        "warning_threshold": 4.0,
        "critical_threshold": 9.0,
        "duration_minutes": 3,
        "is_enabled": True,
        "auto_heal_enabled": True
    }
    create_rule_resp = await client.post("/api/v1/monitoring/threshold-rules", json=new_rule_payload)
    assert create_rule_resp.status_code == 201
    created_rule = create_rule_resp.json()["data"]
    assert created_rule["name"] == "Custom Error Rate Alert"


@pytest.mark.asyncio
async def test_monitoring_event_lifecycle_and_remediation(client: AsyncClient, db_session: AsyncSession):
    # 1. Setup Environment
    env = Environment(
        name="TEST-EVENT-ENV",
        tier=EnvironmentTier.UAT,
        team="Core Banking",
        owner="UAT Lead",
        region="eu-west-1",
        status=EnvironmentStatus.DEGRADED
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # 2. Create Monitoring Event
    event = MonitoringEvent(
        environment_id=env.id,
        environment_name=env.name,
        target_type="SERVICE",
        target_name="Core Account Service",
        event_type=MonitoringMetricType.SERVICE_DOWN,
        severity=EventSeverity.CRITICAL,
        state=EventState.CRITICAL,
        title="Core Account Service Offline",
        message="TCP port probe failed on port 8080",
        current_value=0.0,
        threshold_value=1.0,
        impact_metadata={"impacted_release": "Release 2026.Q4"}
    )
    db_session.add(event)
    await db_session.commit()
    await db_session.refresh(event)

    # 3. Test GET /api/v1/monitoring/events
    events_resp = await client.get("/api/v1/monitoring/events?state=CRITICAL")
    assert events_resp.status_code == 200
    events = events_resp.json()["data"]
    assert len(events) >= 1
    found_event = next(e for e in events if e["id"] == event.id)
    assert found_event["state"] == "CRITICAL"
    assert found_event["title"] == "Core Account Service Offline"

    # 4. Test POST /api/v1/monitoring/events/{id}/acknowledge
    ack_resp = await client.post(f"/api/v1/monitoring/events/{event.id}/acknowledge")
    assert ack_resp.status_code == 200
    ack_data = ack_resp.json()["data"]
    assert ack_data["acknowledged_at"] is not None

    # 5. Test POST /api/v1/monitoring/events/{id}/remediate
    rem_resp = await client.post(f"/api/v1/monitoring/events/{event.id}/remediate", json={"notes": "Testing self-heal"})
    assert rem_resp.status_code == 200
    rem_data = rem_resp.json()
    assert rem_data["success"] is True


@pytest.mark.asyncio
async def test_monitoring_targets_exporters_and_scraping(client: AsyncClient, db_session: AsyncSession):
    # 1. Setup Environment
    env = Environment(
        name="TEST-SCRAPE-ENV",
        tier=EnvironmentTier.DEV,
        team="Platform Eng",
        owner="TEM Admin",
        region="us-east-1",
        status=EnvironmentStatus.HEALTHY
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # 2. Register Target via POST /api/v1/monitoring/targets
    target_payload = {
        "name": "TEST-APP-HOST",
        "environment_id": env.id,
        "environment_name": env.name,
        "target_type": "APPLICATION",
        "endpoint_url": "http://127.0.0.1:8080/metrics",
        "scrape_interval_seconds": 15,
        "scrape_timeout_seconds": 5,
        "is_enabled": True,
        "labels": {"app": "payment-api"},
        "exporters": [
            {
                "name": "App Metrics Exporter",
                "exporter_type": "APPLICATION_PROMETHEUS",
                "endpoint_url": "http://127.0.0.1:8080/metrics",
                "version": "1.0.0"
            }
        ]
    }
    tgt_resp = await client.post("/api/v1/monitoring/targets", json=target_payload)
    assert tgt_resp.status_code == 201
    created_target = tgt_resp.json()["data"]
    target_id = created_target["id"]
    assert created_target["name"] == "TEST-APP-HOST"
    assert len(created_target["exporters"]) == 1

    # 3. GET /api/v1/monitoring/targets
    list_resp = await client.get("/api/v1/monitoring/targets")
    assert list_resp.status_code == 200
    all_targets = list_resp.json()["data"]
    assert any(t["id"] == target_id for t in all_targets)

    # 4. GET /api/v1/monitoring/exporters
    exp_resp = await client.get(f"/api/v1/monitoring/exporters?target_id={target_id}")
    assert exp_resp.status_code == 200
    exporters = exp_resp.json()["data"]
    assert len(exporters) >= 1
    assert exporters[0]["endpoint_url"] == "http://127.0.0.1:8080/metrics"

    # 5. POST /api/v1/monitoring/scrape/execute
    scrape_resp = await client.post(f"/api/v1/monitoring/scrape/execute?target_id={target_id}")
    assert scrape_resp.status_code == 200
    scrape_data = scrape_resp.json()
    assert scrape_data["success"] is True

    # 6. DELETE /api/v1/monitoring/targets/{target_id}
    del_resp = await client.delete(f"/api/v1/monitoring/targets/{target_id}")
    assert del_resp.status_code == 200
    assert del_resp.json()["success"] is True


@pytest.mark.asyncio
async def test_monitoring_incidents_capacity_test_correlations_and_self_health(client: AsyncClient, db_session: AsyncSession):
    # 1. Setup Environment
    env = Environment(
        name="TEST-CORR-ENV",
        tier=EnvironmentTier.SIT,
        team="QE Automation",
        owner="Lead Architect",
        region="us-west-2",
        status=EnvironmentStatus.DEGRADED,
        cpu_usage=88.5,
        memory_usage=92.0,
        storage_usage=84.0
    )
    db_session.add(env)
    await db_session.commit()
    await db_session.refresh(env)

    # 2. Add Critical Monitoring Events to trigger correlation
    evt1 = MonitoringEvent(
        environment_id=env.id,
        environment_name=env.name,
        target_type="DATABASE",
        target_name="PostgreSQL Master",
        event_type=MonitoringMetricType.LATENCY,
        severity=EventSeverity.CRITICAL,
        state=EventState.CRITICAL,
        title="High Query Latency & Pool Saturation",
        message="Active connection pool saturated at 98%",
        current_value=98.0,
        threshold_value=85.0
    )
    evt2 = MonitoringEvent(
        environment_id=env.id,
        environment_name=env.name,
        target_type="APPLICATION",
        target_name="Payment API Service",
        event_type=MonitoringMetricType.ERROR_RATE,
        severity=EventSeverity.HIGH,
        state=EventState.CRITICAL,
        title="API 504 Gateway Timeout Cascade",
        message="Database query timeout causing 504 gateway response errors",
        current_value=12.4,
        threshold_value=5.0
    )
    db_session.add_all([evt1, evt2])
    await db_session.commit()

    # 3. GET /api/v1/monitoring/incidents
    inc_resp = await client.get(f"/api/v1/monitoring/incidents?environment_id={env.id}")
    assert inc_resp.status_code == 200
    incidents = inc_resp.json()["data"]
    assert len(incidents) >= 1
    target_inc = incidents[0]
    assert target_inc["severity"] in ["CRITICAL", "HIGH", "WARNING", "INFO"]
    assert target_inc["root_cause_summary"] is not None

    # Test Acknowledge Incident
    ack_inc_resp = await client.post(f"/api/v1/monitoring/incidents/{target_inc['id']}/acknowledge", json={"user_name": "TestOps Eng"})
    assert ack_inc_resp.status_code == 200
    assert ack_inc_resp.json()["data"]["status"] == "ACKNOWLEDGED"

    # Test Resolve Incident
    res_inc_resp = await client.post(f"/api/v1/monitoring/incidents/{target_inc['id']}/resolve", json={"resolution_notes": "Increased pool limit to 200"})
    assert res_inc_resp.status_code == 200
    assert res_inc_resp.json()["data"]["status"] == "RESOLVED"

    # 4. GET /api/v1/monitoring/environments/{env_id}/capacity
    cap_resp = await client.get(f"/api/v1/monitoring/environments/{env.id}/capacity")
    assert cap_resp.status_code == 200
    cap_data = cap_resp.json()["data"]
    assert len(cap_data) >= 1
    assert "days_to_critical_breach" in cap_data[0]
    assert "recommendation" in cap_data[0]

    # 5. POST /api/v1/monitoring/test-executions/correlate
    test_run_payload = {
        "test_run_id": "RUN-QE-9821",
        "test_suite_name": "Checkout End-to-End Regression",
        "test_phase": "PERFORMANCE",
        "environment_id": env.id,
        "environment_name": env.name,
        "status": "FAILED",
        "total_tests": 120,
        "passed_tests": 92,
        "failed_tests": 28
    }
    test_run_resp = await client.post("/api/v1/monitoring/test-executions/correlate", json=test_run_payload)
    assert test_run_resp.status_code == 201
    recorded_test = test_run_resp.json()["data"]
    assert recorded_test["test_run_id"] == "RUN-QE-9821"
    assert recorded_test["is_environment_caused"] is True
    assert "infrastructure" in recorded_test["failure_root_cause"].lower()

    # GET /api/v1/monitoring/test-executions
    get_tests_resp = await client.get(f"/api/v1/monitoring/test-executions?environment_id={env.id}")
    assert get_tests_resp.status_code == 200
    test_list = get_tests_resp.json()["data"]
    assert any(t["test_run_id"] == "RUN-QE-9821" for t in test_list)

    # 6. GET /api/v1/monitoring/self-health
    health_resp = await client.get("/api/v1/monitoring/self-health")
    assert health_resp.status_code == 200
    health_data = health_resp.json()["data"]
    assert health_data["service_status"] == "HEALTHY"
    assert health_data["scraper_status"] in ["RUNNING", "OPERATIONAL"]
    assert health_data["active_targets_count"] >= 0


@pytest.mark.asyncio
async def test_prometheus_exposition_parser_and_metrics():
    """Validates Prometheus text exposition parsing, metric extraction, and error isolation."""
    from app.services.prometheus_scraper import prometheus_scraper

    raw_exposition = """
    # HELP node_cpu_seconds_total Seconds the CPUs spent in each mode.
    # TYPE node_cpu_seconds_total counter
    node_cpu_seconds_total{cpu="0",mode="idle"} 12400.5
    node_cpu_seconds_total{cpu="0",mode="system"} 600.2
    # HELP node_memory_MemTotal_bytes Memory information.
    node_memory_MemTotal_bytes{instance="test-host"} 34359738368
    node_memory_MemAvailable_bytes{instance="test-host"} 17179869184
    # HELP http_server_requests_seconds_sum HTTP request duration.
    http_server_requests_seconds_sum{uri="/api/v1/checkout"} 250.0
    http_server_requests_seconds_count{uri="/api/v1/checkout",status="200"} 5000
    http_server_requests_seconds_count{uri="/api/v1/checkout",status="500"} 25
    """
    samples = prometheus_scraper.parse_prometheus_text(raw_exposition)
    assert len(samples) >= 6

    normalized = prometheus_scraper.extract_normalized_metrics(samples, "LINUX_SERVER")
    assert normalized["MEMORY"] == 50.0
    assert normalized["LATENCY"] == 49.8
    assert normalized["ERROR_RATE"] == 0.5

    # Test Error Isolation categories
    # 1. Target Down
    s_down, cat_down, msg_down, _, _, _ = await prometheus_scraper.scrape_endpoint("http://host-offline.internal:9100/metrics", "Offline-Host")
    assert s_down is False
    assert cat_down == "TARGET_DOWN"

    # 2. Exporter Down
    s_exp, cat_exp, msg_exp, _, _, _ = await prometheus_scraper.scrape_endpoint("http://host01.internal:9100/faulty-exp/metrics", "Host-Faulty")
    assert s_exp is False
    assert cat_exp == "EXPORTER_DOWN"


@pytest.mark.asyncio
async def test_prometheus_sd_promql_and_grafana_endpoints(client: AsyncClient, db_session: AsyncSession):
    """Validates Prometheus HTTP SD, Prometheus metrics exposition, PromQL queries, and Grafana dashboard endpoints."""
    # 1. GET /api/v1/monitoring/prometheus/targets.json (HTTP SD)
    sd_resp = await client.get("/api/v1/monitoring/prometheus/targets.json")
    assert sd_resp.status_code == 200
    sd_data = sd_resp.json()
    assert isinstance(sd_data, list)

    # 2. GET /api/v1/monitoring/prometheus/metrics (Text Exposition)
    metrics_resp = await client.get("/api/v1/monitoring/prometheus/metrics")
    assert metrics_resp.status_code == 200
    assert "text/plain" in metrics_resp.headers.get("content-type", "")
    assert "tem_monitored_environments_total" in metrics_resp.text
    assert "tem_fleet_average_health_score" in metrics_resp.text

    # 3. POST /api/v1/monitoring/prometheus/query (Instant PromQL)
    query_resp = await client.post("/api/v1/monitoring/prometheus/query", json={"query": "cpu_utilization"})
    assert query_resp.status_code == 200
    query_data = query_resp.json()
    assert query_data["status"] == "success"
    assert query_data["data"]["resultType"] == "vector"

    # 4. POST /api/v1/monitoring/prometheus/query_range (Range PromQL)
    range_resp = await client.post("/api/v1/monitoring/prometheus/query_range", json={"query": "cpu_utilization", "step": "30s"})
    assert range_resp.status_code == 200
    range_data = range_resp.json()
    assert range_data["status"] == "success"
    assert range_data["data"]["resultType"] == "matrix"

    # 5. GET /api/v1/monitoring/grafana/dashboards
    dash_resp = await client.get("/api/v1/monitoring/grafana/dashboards")
    assert dash_resp.status_code == 200
    dashboards = dash_resp.json()["data"]
    assert len(dashboards) >= 6
    uids = [d["uid"] for d in dashboards]
    assert "tem-fleet-overview" in uids
    assert "tem-env-dossier" in uids
    assert "tem-server-infrastructure" in uids
    assert "tem-app-apm" in uids
    assert "tem-database-pool" in uids
    assert "tem-test-correlation" in uids

    # 6. GET & PUT /api/v1/monitoring/grafana/config
    cfg_get = await client.get("/api/v1/monitoring/grafana/config")
    assert cfg_get.status_code == 200
    assert "server_url" in cfg_get.json()["data"]

    cfg_put = await client.put("/api/v1/monitoring/grafana/config", json={"server_url": "http://grafana.internal:3000", "kiosk_mode": True})
    assert cfg_put.status_code == 200
    assert cfg_put.json()["data"]["server_url"] == "http://grafana.internal:3000"


