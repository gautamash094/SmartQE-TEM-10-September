"""
Tests for LLM Client, RAG Engine, and Assistant Fallback Mechanism.
"""
from unittest.mock import AsyncMock, patch
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.services.llm_client import LLMClient, LLMResponse, llm_client
from app.services.assistant_rag_engine import assistant_rag_engine
from app.models.environment import Environment, EnvironmentStatus, EnvironmentTier


@pytest.mark.asyncio
async def test_llm_client_default_unconfigured():
    """Verify that by default (without API keys), LLM client reports not configured."""
    client = LLMClient()
    with patch.object(settings, "GEMINI_API_KEY", ""), patch.object(settings, "OPENAI_API_KEY", ""):
        assert client.resolve_provider() == "none"
        assert not client.is_configured()


@pytest.mark.asyncio
async def test_llm_client_provider_resolution():
    """Verify resolution order and explicit provider configuration."""
    client = LLMClient()
    with patch.object(settings, "LLM_ENABLED", True):
        # Auto mode with Gemini key
        with patch.object(settings, "LLM_PROVIDER", "auto"), patch.object(settings, "GEMINI_API_KEY", "dummy-gemini-key"):
            assert client.resolve_provider() == "gemini"
            assert client.is_configured()

        # Auto mode with OpenAI key
        with patch.object(settings, "LLM_PROVIDER", "auto"), patch.object(settings, "GEMINI_API_KEY", ""), patch.object(settings, "OPENAI_API_KEY", "dummy-openai-key"):
            assert client.resolve_provider() == "openai"
            assert client.is_configured()

        # Explicit Ollama mode
        with patch.object(settings, "LLM_PROVIDER", "ollama"):
            assert client.resolve_provider() == "ollama"
            assert client.is_configured()


from app.models.environment_profile import EnvironmentProfile


@pytest.mark.asyncio
async def test_rag_engine_build_context(db_session: AsyncSession):
    """Verify that RAG engine constructs live context from DB and domain knowledge."""
    env = EnvironmentProfile(
        id="test-rag-sit-01",
        name="SIT-01",
        type="SIT",
        status=EnvironmentStatus.HEALTHY,
        owner_team="QA Core",
        network_zone="us-east-1",
        is_active=True,
        created_by="Admin"
    )
    db_session.add(env)
    await db_session.commit()

    context = await assistant_rag_engine.build_rag_context(
        db=db_session,
        query="Tell me about SIT-01 and booking conflict detection"
    )

    assert "LIVE TEM SYSTEM CONTEXT" in context["system_instruction"]
    assert "SIT-01" in context["system_instruction"]
    assert len(context["suggested_prompts"]) > 0
    assert len(context["action_links"]) > 0
    assert context["matched_topic"] is not None


@pytest.mark.asyncio
async def test_assistant_chat_with_mocked_llm_success(client: AsyncClient, db_session: AsyncSession):
    """Verify that when an LLM provider is active, the assistant returns AI_RAG_RESPONSE."""
    mock_llm_resp = LLMResponse(
        content="### SIT-01 Fleet Status\nSIT-01 is currently healthy and active in region us-east-1.",
        provider="gemini",
        model="gemini-1.5-flash",
        success=True
    )

    with patch.object(llm_client, "is_configured", return_value=True), \
         patch.object(llm_client, "generate_response", new=AsyncMock(return_value=mock_llm_resp)):

        payload = {
            "message": "What is the status of SIT-01?",
            "history": [],
            "context_entity": {}
        }
        response = await client.post("/api/v1/assistant/chat", json=payload)
        assert response.status_code == 200
        data = response.json()["data"]

        assert data["category"] == "AI_ASSISTANT"
        assert data["intent"] == "AI_RAG_RESPONSE"
        assert "SIT-01 is currently healthy" in data["reply"]
        assert data["entities"]["provider"] == "gemini"


@pytest.mark.asyncio
async def test_assistant_chat_llm_failure_falls_back_to_deterministic(client: AsyncClient, db_session: AsyncSession):
    """Verify that if LLM call fails (e.g. timeout or API quota), system gracefully falls back."""
    mock_failed_resp = LLMResponse(
        content="",
        provider="gemini",
        model="gemini-1.5-flash",
        success=False,
        error_message="Connection timeout or quota exceeded"
    )

    with patch.object(llm_client, "is_configured", return_value=True), \
         patch.object(llm_client, "generate_response", new=AsyncMock(return_value=mock_failed_resp)):

        payload = {
            "message": "How does booking conflict detection work?",
            "history": [],
            "context_entity": {}
        }
        response = await client.post("/api/v1/assistant/chat", json=payload)
        assert response.status_code == 200
        data = response.json()["data"]

        # Graceful fallback: local deterministic knowledge base response
        assert data["category"] == "FUNCTIONAL_KNOWLEDGE"
        assert "conflict" in data["reply"].lower()


@pytest.mark.asyncio
async def test_cross_provider_failover_gemini_to_openai():
    """Verify that when Gemini encounters quota/rate limit error, it fails over to OpenAI."""
    client = LLMClient()
    mock_gemini_fail = LLMResponse(content="", provider="gemini", model="gemini-1.5-flash", success=False, error_message="ResourceExhausted: Quota exceeded")
    mock_openai_success = LLMResponse(content="OpenAI generated answer", provider="openai", model="gpt-4o-mini", success=True)

    with patch.object(settings, "LLM_ENABLED", True), \
         patch.object(settings, "GEMINI_API_KEY", "dummy-gemini-key"), \
         patch.object(settings, "OPENAI_API_KEY", "dummy-openai-key"), \
         patch.object(client, "_call_gemini", new=AsyncMock(return_value=mock_gemini_fail)), \
         patch.object(client, "_call_openai", new=AsyncMock(return_value=mock_openai_success)):

        resp = await client.generate_response("Tell me about SIT-01", requested_provider="gemini")
        assert resp.success
        assert resp.provider == "openai"
        assert resp.content == "OpenAI generated answer"


@pytest.mark.asyncio
async def test_requested_provider_and_model_override():
    """Verify that explicit provider and model overrides are respected."""
    client = LLMClient()
    mock_resp = LLMResponse(content="GPT-4o response", provider="openai", model="gpt-4o", success=True)

    with patch.object(settings, "LLM_ENABLED", True), \
         patch.object(settings, "OPENAI_API_KEY", "dummy-openai-key"), \
         patch.object(client, "_call_openai", new=AsyncMock(return_value=mock_resp)) as mock_call:

        resp = await client.generate_response("What is the release schedule?", requested_provider="openai", requested_model="gpt-4o")
        assert resp.success
        assert resp.provider == "openai"
        mock_call.assert_called_once()
        _, kwargs = mock_call.call_args
        assert kwargs["override_model"] == "gpt-4o"

