"""
Tests for Conversational Environment Booking Agent and Execution Endpoint.
"""
from datetime import datetime, timedelta, timezone
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.environment import EnvironmentStatus, EnvironmentTier
from app.models.environment_profile import EnvironmentProfile
from app.models.reservation import Reservation, ReservationMode, ReservationPriority, ReservationStatus
from app.services.assistant_booking_agent import assistant_booking_agent


def test_is_booking_request_detection():
    """Verify natural language trigger detection vs informational questions."""
    # Actionable booking requests
    assert assistant_booking_agent.is_booking_request("Book SIT-01 tomorrow from 10 to 4")
    assert assistant_booking_agent.is_booking_request("Reserve QA-01 for Regression Testing")
    assert assistant_booking_agent.is_booking_request("I want to book an environment")
    assert assistant_booking_agent.is_booking_request("Can I reserve DEV-02 next Monday?")
    assert assistant_booking_agent.is_booking_request("Schedule SIT-03 for deployment verification")

    # Informational queries (should NOT trigger booking wizard)
    assert not assistant_booking_agent.is_booking_request("Who booked SIT-01?")
    assert not assistant_booking_agent.is_booking_request("Is SIT-01 booked right now?")
    assert not assistant_booking_agent.is_booking_request("Show all active bookings")
    assert not assistant_booking_agent.is_booking_request("How does booking conflict detection work?")


@pytest.mark.asyncio
async def test_conversational_booking_preview_generation(client: AsyncClient, db_session: AsyncSession):
    """Verify that asking to book an environment generates a clean preview card with conflict check."""
    env = EnvironmentProfile(
        id="test-book-env-01",
        name="QA-99",
        type="QA",
        status=EnvironmentStatus.HEALTHY,
        owner_team="QA Core",
        network_zone="us-east-1",
        is_active=True,
        created_by="Admin"
    )
    db_session.add(env)
    await db_session.commit()

    payload = {
        "message": "Book QA-99 tomorrow from 10:00 to 16:00 for Payments Smoke Test",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]

    assert data["intent"] == "BOOKING_PREVIEW"
    assert "QA-99" in data["reply"]
    assert "raw_data" in data and "booking_preview" in data["raw_data"]

    preview = data["raw_data"]["booking_preview"]
    assert preview["environment_name"] == "QA-99"
    assert preview["has_conflict"] is False
    assert "Smoke Test" in preview["purpose"]

    # Action links should include EXECUTE_BOOKING
    action_types = [link["action_type"] for link in data["action_links"]]
    assert "EXECUTE_BOOKING" in action_types


async def seed_test_workflow(db_session: AsyncSession, bu_name: str, env_id: str, env_name: str, app_name: str = ""):
    from app.models.workflow import Workflow, WorkflowApprover
    from app.dao.user_dao import user_dao
    from app.dao.role_dao import role_dao
    from app.dao.portfolio_dao import business_unit_dao
    from app.core.security import create_access_token

    bu_list = await business_unit_dao.filter(db_session, {"name": bu_name})
    if bu_list:
        bu = bu_list[0]
    else:
        bu = await business_unit_dao.create(db_session, {
            "name": bu_name,
            "code": bu_name[:4].upper(),
            "description": f"{bu_name} BU",
            "is_active": True,
            "status": "ACTIVE"
        })

    dev_role = await role_dao.get_by_name(db_session, "Developer")
    if not dev_role:
        dev_role = await role_dao.create(db_session, {
            "name": "Developer",
            "description": "Developer",
            "role_order": 2,
            "is_system": False,
            "is_active": True,
            "status": "ACTIVE"
        })

    user = await user_dao.get_by_username(db_session, "approver_tester")
    if not user:
        user = await user_dao.create_user_with_roles(db_session, {
            "first_name": "Approver",
            "last_name": "Tester",
            "username": "approver_tester",
            "email": "approver_tester@test.com",
            "business_unit_id": bu.id,
            "is_active": True,
            "status": "ACTIVE",
        }, [dev_role])

    creator = await user_dao.get_by_username(db_session, "creator_tester")
    if not creator:
        creator = await user_dao.create_user_with_roles(db_session, {
            "first_name": "Creator",
            "last_name": "Tester",
            "username": "creator_tester",
            "email": "creator_tester@test.com",
            "business_unit_id": bu.id,
            "is_active": True,
            "status": "ACTIVE",
        }, [dev_role])

    wf = Workflow(
        bu_id=bu.id,
        environment_id=env_id,
        environment_name=env_name,
        application_id=app_name or "",
        service_code="ENVIRONMENT_RESERVATION",
        service_name="Environment Reservation",
        is_active=True,
        status="ACTIVE",
    )
    db_session.add(wf)
    await db_session.flush()

    appr = WorkflowApprover(
        workflow_id=wf.id,
        user_id=user.id,
        workflow_order=1,
    )
    db_session.add(appr)
    await db_session.commit()
    return wf, create_access_token(subject=creator.id), create_access_token(subject=user.id)


@pytest.mark.asyncio
async def test_conversational_booking_with_conflict(client: AsyncClient, db_session: AsyncSession):
    """Verify that an overlapping booking is detected during pre-flight check."""
    env = EnvironmentProfile(
        id="test-book-env-conflict",
        name="QA-CONFL",
        type="QA",
        status=EnvironmentStatus.HEALTHY,
        owner_team="QA Core",
        network_zone="us-east-1",
        is_active=True,
        created_by="Admin"
    )
    db_session.add(env)
    await db_session.flush()

    # Create overlapping disruptive reservation for tomorrow 09:00 - 17:00
    tomorrow = datetime.now(timezone.utc) + timedelta(days=1)
    st = tomorrow.replace(hour=9, minute=0, second=0, microsecond=0)
    et = tomorrow.replace(hour=17, minute=0, second=0, microsecond=0)

    res = Reservation(
        id="res-existing-99",
        environment_id=env.id,
        environment_name=env.name,
        business_unit="Enterprise QA",
        purpose="Existing Release Test",
        team="DevOps",
        requested_by="DevOps Lead",
        start_date=st,
        end_date=et,
        status=ReservationStatus.CONFIRMED,
        reservation_mode=ReservationMode.DISRUPTIVE,
        is_visible=True
    )
    db_session.add(res)
    await db_session.commit()

    payload = {
        "message": "Book QA-CONFL tomorrow from 10:00 to 14:00 as exclusive for Performance",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]

    assert data["intent"] == "BOOKING_PREVIEW"
    preview = data["raw_data"]["booking_preview"]
    assert preview["has_conflict"] is True
    assert preview["conflict_count"] >= 1


@pytest.mark.asyncio
async def test_execute_bot_booking_api(client: AsyncClient, db_session: AsyncSession):
    """Verify that calling /assistant/book-environment creates the reservation successfully."""
    env = EnvironmentProfile(
        id="test-exec-env-01",
        name="DEV-88",
        type="DEV",
        status=EnvironmentStatus.HEALTHY,
        owner_team="Dev Team",
        network_zone="us-east-1",
        is_active=True,
        created_by="Admin"
    )
    db_session.add(env)
    await db_session.commit()

    # Seed required approval workflow for the environment
    _, creator_token, _ = await seed_test_workflow(
        db_session, "Enterprise Engineering", env.id, env.name
    )

    tomorrow = datetime.now(timezone.utc) + timedelta(days=1)
    st_str = tomorrow.replace(hour=10, minute=0, second=0).strftime("%Y-%m-%d %H:%M:%S")
    et_str = tomorrow.replace(hour=15, minute=0, second=0).strftime("%Y-%m-%d %H:%M:%S")

    booking_payload = {
        "environment_id": env.id,
        "environment_name": env.name,
        "start_date": st_str,
        "end_date": et_str,
        "purpose": "Automated Microservice Test",
        "business_unit": "Enterprise Engineering",
        "team": "Dev Team",
        "reservation_mode": "SHARED",
        "priority": "MEDIUM",
        "requested_by": "Test Engineer"
    }

    response = await client.post(
        "/api/v1/assistant/book-environment",
        json=booking_payload,
        headers={"Authorization": f"Bearer {creator_token}"}
    )
    assert response.status_code == 200
    res_data = response.json()["data"]

    assert res_data["success"] is True
    assert res_data["reservation_id"] is not None
    assert res_data["environment_name"] == "DEV-88"
    assert res_data["status"] in ("CONFIRMED", "PENDING")
