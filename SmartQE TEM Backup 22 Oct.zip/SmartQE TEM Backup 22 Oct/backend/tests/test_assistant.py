from unittest.mock import patch
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
# from app.dao.environment_dao import environment_dao
from app.models.environment import EnvironmentStatus, EnvironmentTier
from app.models.environment_profile import EnvironmentProfile
from app.models.release import Release
from app.services.llm_client import llm_client


@pytest.fixture(autouse=True)
def disable_llm_for_deterministic_tests():
    """Ensure test_assistant.py tests local deterministic handlers without external API dependency."""
    with patch.object(llm_client, "is_configured", return_value=False):
        yield


@pytest.mark.asyncio

async def test_assistant_suggested_prompts(client: AsyncClient, db_session: AsyncSession):
    response = await client.get("/api/v1/assistant/suggested-prompts")
    assert response.status_code == 200
    data = response.json()["data"]
    assert len(data) > 0
    assert any("SIT" in p["prompt"] or "CPU" in p["prompt"] for p in data)


@pytest.mark.asyncio
async def test_assistant_functional_knowledge_query(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "How does booking conflict detection work?",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["category"] == "FUNCTIONAL_KNOWLEDGE"
    assert "conflict" in data["reply"].lower()
    assert "exclusive" in data["reply"].lower() or "disruptive" in data["reply"].lower()


@pytest.mark.asyncio
async def test_assistant_auto_heal_explanation(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "What does Auto-Heal do?",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["category"] == "FUNCTIONAL_KNOWLEDGE"
    assert "remediation" in data["reply"].lower() or "heal" in data["reply"].lower()


@pytest.mark.asyncio
async def test_assistant_environment_list_query(client: AsyncClient, db_session: AsyncSession):
    env1 = EnvironmentProfile(
        id="test-sit-01",
        name="SIT-01",
        type="SIT",
        status=EnvironmentStatus.HEALTHY,
        owner_team="QA Team",
        network_zone="us-east-1",
        is_active=True,
        created_by="Admin"
    )
    db_session.add(env1)
    await db_session.commit()

    payload = {
        "message": "Show me all SIT environments.",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["category"] == "DATA_QUERY"
    assert "SIT" in data["reply"]


@pytest.mark.asyncio
async def test_assistant_diagnosis_comparison_query(client: AsyncClient, db_session: AsyncSession):
    env_sit = EnvironmentProfile(
        id="test-comp-sit",
        name="SIT-COMP-01",
        type="SIT",
        status=EnvironmentStatus.HEALTHY,
        owner_team="QA",
        network_zone="us-east-1",
        is_active=True,
        created_by="Admin"
    )
    env_uat = EnvironmentProfile(
        id="test-comp-uat",
        name="UAT-COMP-01",
        type="UAT",
        status=EnvironmentStatus.HEALTHY,
        owner_team="QA",
        network_zone="us-east-1",
        is_active=True,
        created_by="Admin"
    )
    db_session.add(env_sit)
    db_session.add(env_uat)
    await db_session.commit()

    payload = {
        "message": "Compare SIT-COMP-01 and UAT-COMP-01",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["category"] == "DATA_QUERY"
    assert "Consistency Score" in data["reply"] or "Comparison" in data["reply"]


@pytest.mark.asyncio
async def test_assistant_monitoring_high_cpu_query(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "Which environments have high CPU usage?",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["category"] == "DATA_QUERY"
    assert "CPU" in data["reply"] or "Observability" in data["reply"]


@pytest.mark.asyncio
async def test_assistant_multi_turn_context_resolution(client: AsyncClient, db_session: AsyncSession):
    env_sit = EnvironmentProfile(
        id="test-sit-multi",
        name="SIT-09",
        type="SIT",
        status=EnvironmentStatus.HEALTHY,
        owner_team="QA",
        network_zone="us-east-1",
        is_active=True,
        created_by="Admin"
    )
    db_session.add(env_sit)
    await db_session.commit()

    history = [
        {"role": "user", "content": "Show me the SIT environments."},
        {"role": "assistant", "content": "Here are the SIT environments..."}
    ]
    payload = {
        "message": "Which ones are available right now?",
        "history": history,
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["category"] == "DATA_QUERY"
    assert "SIT" in data["reply"] or "Available" in data["reply"]


@pytest.mark.asyncio
async def test_assistant_fallback_help(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "xyz random non-tem query 12345",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert "SmartQE TEM" in data["reply"]
    assert len(data["suggested_prompts"]) > 0


@pytest.mark.asyncio
async def test_assistant_worklist_query(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "use of worklist",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["intent"] == "KB_WORKLIST"
    assert "Bookings Worklist" in data["reply"]
    assert "/worklist" in [link["route"] for link in data["action_links"]]


@pytest.mark.asyncio
async def test_assistant_define_workflow_query(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "how define workflow works?",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["intent"] == "KB_DEFINE_WORKFLOW"
    assert "Define Workflow" in data["reply"]
    assert "/settings/define-workflow" in [link["route"] for link in data["action_links"]]


@pytest.mark.asyncio
async def test_assistant_settings_and_submodules_query(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "Explain the module settings along with the submodules in it?",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    reply = data["reply"]
    assert "User Management" in reply
    assert "Role Management" in reply
    assert "Access Management" in reply
    assert "User Group Management" in reply
    assert "Define Workflow" in reply
    # Must NOT contain hallucinated submodules
    assert "/settings/governance" not in reply
    assert "/settings/integrations" not in reply
    assert "/settings/auto-heal" not in reply


@pytest.mark.asyncio
async def test_assistant_all_modules_query(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "what are all modules and submodules in tem",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    reply = data["reply"]
    assert "Settings" in reply
    assert "Environment Provisioning" in reply
    assert "Resource Management" in reply


@pytest.mark.asyncio
async def test_assistant_how_servers_are_added_query(client: AsyncClient, db_session: AsyncSession):
    payload = {
        "message": "how servers are added?",
        "history": [],
        "context_entity": {}
    }
    response = await client.post("/api/v1/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()["data"]
    reply = data["reply"]
    # Must instruct users to go to Environment Details (/environment-details)
    assert "Environment Details" in reply
    assert "/environment-details" in reply
    # Must detail the 2 types: On-Premises and Cloud Instances / VMs
    assert "On-Premises" in reply or "ON_PREMISES" in reply
    assert "Cloud" in reply
    # Must NOT advise adding servers via /inventory or /external-integrations
    assert "Manual Onboarding via Inventory Management" not in reply
    assert "Automated Cloud Discovery via External Integrations" not in reply



