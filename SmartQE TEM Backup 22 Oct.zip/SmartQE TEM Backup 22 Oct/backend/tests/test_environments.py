import pytest
from httpx import AsyncClient

# Legacy /api/v1/environments endpoint has been deactivated in favor of /api/v1/environment-profiles.
# See backend/tests/test_environment_profiles.py for the active EnvironmentProfile test suite.

@pytest.mark.asyncio
async def test_legacy_environments_endpoint_disabled(client: AsyncClient):
    response = await client.get("/api/v1/environments")
    assert response.status_code == 404

