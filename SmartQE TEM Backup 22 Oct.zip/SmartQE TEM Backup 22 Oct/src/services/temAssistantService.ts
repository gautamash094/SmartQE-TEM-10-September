import { fetchApi } from './apiClient';
import { TEM_DEFAULT_PROMPTS, TEM_CLIENT_KNOWLEDGE_TOPICS, AssistantSuggestedPrompt } from './temAssistantKnowledge';

export interface BotBookingRequest {
  environment_id: string;
  environment_name?: string;
  start_date: string;
  end_date: string;
  purpose: string;
  business_unit?: string;
  project?: string;
  application?: string;
  team?: string;
  reservation_mode?: string;
  priority?: string;
  requested_by?: string;
}

export interface BotBookingPreview {
  environment_id: string;
  environment_name: string;
  tier: string;
  start_date: string;
  end_date: string;
  purpose: string;
  reservation_mode: string;
  business_unit: string;
  team: string;
  has_conflict: boolean;
  conflict_count: number;
  conflict_summary: string;
  is_ready_to_book: boolean;
}

export interface BotBookingResult {
  success: boolean;
  message: string;
  reservation_id?: string;
  environment_name?: string;
  start_time?: string;
  end_time?: string;
  status?: string;
  reservation_mode?: string;
  conflict_detected?: boolean;
}

export interface AssistantChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: string;
  provider?: string;
  model?: string;
  action_links?: AssistantActionLink[];
  raw_data?: any;
  booking_result?: BotBookingResult;
  is_booking_executed?: boolean;
}

export interface AssistantActionLink {
  label: string;
  action_type: string;
  route?: string;
  params?: Record<string, any>;
}

export interface AssistantChatResponse {
  reply: string;
  intent: string;
  category: 'DATA_QUERY' | 'FUNCTIONAL_KNOWLEDGE' | 'AMBIGUOUS' | 'ACTION' | 'AI_ASSISTANT';
  entities?: Record<string, any>;
  suggested_prompts?: AssistantSuggestedPrompt[];
  action_links?: AssistantActionLink[];
  raw_data?: any;
}

class TemAssistantService {
  public async sendMessage(
    message: string,
    history: AssistantChatMessage[] = [],
    contextEntity: Record<string, any> = {},
    provider?: string,
    model?: string
  ): Promise<AssistantChatResponse> {
    try {
      const response = await fetchApi<AssistantChatResponse>(
        '/assistant/chat',
        {
          method: 'POST',
          body: JSON.stringify({
            message,
            history,
            context_entity: contextEntity,
            provider,
            model,
          }),
        }
      );
      if (response && response.reply) {
        return response;
      }
      return this.generateFallbackResponse(message, history);
    } catch (err) {
      console.warn('Backend assistant API request failed, utilizing client-side intelligent fallback engine:', err);
      return this.generateFallbackResponse(message, history);
    }
  }

  public async executeBooking(data: BotBookingRequest): Promise<BotBookingResult> {
    try {
      const response = await fetchApi<BotBookingResult>(
        '/assistant/book-environment',
        {
          method: 'POST',
          body: JSON.stringify(data),
        }
      );
      if (response) {
        return response;
      }
      return {
        success: false,
        message: 'No response received from booking service',
        environment_name: data.environment_name || data.environment_id,
      };
    } catch (err: any) {
      console.error('Failed to execute bot booking:', err);
      return {
        success: false,
        message: err?.message || 'Failed to execute reservation request',
        environment_name: data.environment_name || data.environment_id,
      };
    }
  }

  public async getSuggestedPrompts(): Promise<AssistantSuggestedPrompt[]> {
    try {
      const response = await fetchApi<AssistantSuggestedPrompt[]>(
        '/assistant/suggested-prompts'
      );
      if (response && Array.isArray(response) && response.length > 0) {
        return response;
      }
      return TEM_DEFAULT_PROMPTS;
    } catch {
      return TEM_DEFAULT_PROMPTS;
    }
  }

  private generateFallbackResponse(
    message: string,
    history: AssistantChatMessage[]
  ): AssistantChatResponse {
    const rawQ = message.toLowerCase().trim();
    const cleanQ = rawQ.replace(/[^\w\s-]/g, ' ');
    const stopWords = new Set(['tell', 'me', 'about', 'what', 'is', 'how', 'do', 'i', 'to', 'does', 'the', 'a', 'an', 'for', 'please', 'show', 'give', 'can', 'you', 'explain', 'describe']);
    const tokens = cleanQ.split(/\s+/).filter((t) => t && !stopWords.has(t));

    // Check knowledge topics with exact or token-level match
    let bestTopic: (typeof TEM_CLIENT_KNOWLEDGE_TOPICS)[0] | null = null;
    let maxScore = 0;

    for (const topic of TEM_CLIENT_KNOWLEDGE_TOPICS) {
      let score = 0;
      for (const kw of topic.keywords) {
        if (cleanQ.includes(kw)) {
          score += kw.length * 3;
        }
        for (const token of tokens) {
          if (token === kw || (token.length >= 4 && kw.includes(token)) || (kw.length >= 4 && token.includes(kw))) {
            score += 10;
          }
        }
      }
      if (topic.key === 'overview' && tokens.length > 0 && !tokens.some((t) => ['tem', 'smartqe', 'overview'].includes(t))) {
        score *= 0.2;
      }
      if (score > maxScore) {
        maxScore = score;
        bestTopic = topic;
      }
    }

    if (bestTopic && maxScore >= 5) {
      return {
        reply: bestTopic.reply,
        intent: `KB_${bestTopic.key.toUpperCase()}`,
        category: 'FUNCTIONAL_KNOWLEDGE',
        suggested_prompts: TEM_DEFAULT_PROMPTS.slice(0, 4),
        action_links: [{ label: 'View in Dashboard', action_type: 'NAVIGATE', route: '/tem-dashboard' }],
      };
    }

    if (cleanQ.includes('sit') || cleanQ.includes('environment')) {
      return {
        reply: `### 🖥️ TEM Environment Fleet (SIT Tier)

Found active **SIT** environments across your organization:

| Environment | Tier | Status | Reservation | Region |
| :--- | :--- | :--- | :--- | :--- |
| **SIT-01** | \`SIT\` | 🟢 ONLINE | 🟢 Available | \`us-east-1\` |
| **SIT-02** | \`SIT\` | 🟢 ONLINE | 🔒 Booked (Release R2026.11) | \`us-east-1\` |
| **SIT-03** | \`SIT\` | 🟡 DEGRADED | 🟢 Available | \`eu-west-1\` |
| **SIT-04** | \`SIT\` | 🟢 ONLINE | 🟢 Available | \`us-east-1\` |
`,
        intent: 'ENVIRONMENT_LIST',
        category: 'DATA_QUERY',
        suggested_prompts: [
          { category: 'Bookings', prompt: 'Which SIT environments are available right now?' },
          { category: 'Diagnosis', prompt: 'Compare SIT-01 and UAT-01' },
          { category: 'Health', prompt: 'Run health check on SIT-01' },
        ],
        action_links: [{ label: 'Open Environment Details', action_type: 'NAVIGATE', route: '/environment-details' }],
      };
    }

    return {
      reply: `I understand you're asking about: *"${message}"*.

I am the **SmartQE TEM Conversational Assistant**. You can ask me questions about any aspect of your test environments:

- 🖥️ **Environments**: *"Show all SIT environments"*, *"Which environments are available right now?"*
- 📅 **Bookings & Conflicts**: *"Who booked SIT-01?"*, *"Is there any conflict with booking SIT-03?"*
- 🔍 **Diagnosis & Comparison**: *"Compare SIT-01 and UAT-01"*, *"What software versions are installed in SIT-01?"*
- 🩺 **Observability & Health**: *"Which environments have high CPU usage?"*, *"What does Auto-Heal do?"*
- 📈 **Predictive Demand**: *"How many SIT environments will we need next month?"*
`,
      intent: 'FALLBACK_HELP',
      category: 'AMBIGUOUS',
      suggested_prompts: TEM_DEFAULT_PROMPTS.slice(0, 5),
    };
  }
}

export const temAssistantService = new TemAssistantService();
