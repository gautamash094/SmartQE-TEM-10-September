import { EnvironmentProfile, ServerDetail, SoftwareDetail } from '../types/environmentDetails';
import { Incident, Booking } from '../types';
import {
  EnvironmentHealthStatus,
  TestReadinessStatus,
  ReadinessCheckResult,
  HistoricalTelemetry,
  MetricSeries,
  TimeframeOption,
  MonitoringAlert,
  AlertRule,
  MaintenanceWindow,
  TelemetryLog,
  TelemetryTrace,
  MonitoringSourceIntegration,
  FleetObservabilitySummary,
  EnvironmentDetailedObservability,
  PredictiveInsight,
  MonitoringTarget,
  MonitoringExporter,
  CorrelatedIncident,
  NotificationRule,
  CapacityForecast,
  TestExecutionCorrelation,
  MonitoringSelfHealth,
  PromQLQueryResponse,
  GrafanaDashboard,
  GrafanaConfig,
} from '../types/monitoring';
import { environmentDetailsService } from './environmentDetailsService';
import { fetchApi, fetchApiStrict } from './apiClient';

const ALERTS_STORAGE_KEY = 'smartqe_tem_monitoring_alerts_v1';
const RULES_STORAGE_KEY = 'smartqe_tem_monitoring_rules_v1';
const MAINTENANCE_STORAGE_KEY = 'smartqe_tem_maintenance_windows_v1';

// Dynamic Alert Rules
const INITIAL_ALERT_RULES: AlertRule[] = [
  {
    id: 'rule-1',
    name: 'High CPU Saturation Alert',
    metricName: 'CPU',
    operator: '>',
    threshold: 85,
    warningThreshold: 75,
    criticalThreshold: 85,
    durationMinutes: 5,
    severity: 'CRITICAL',
    autoEscalateIncident: true,
    autoHealEnabled: true,
    enabled: true,
  },
  {
    id: 'rule-2',
    name: 'High Memory Consumption',
    metricName: 'MEMORY',
    operator: '>',
    threshold: 90,
    warningThreshold: 80,
    criticalThreshold: 90,
    durationMinutes: 10,
    severity: 'WARNING',
    autoEscalateIncident: false,
    autoHealEnabled: false,
    enabled: true,
  },
  {
    id: 'rule-3',
    name: 'Application Error Rate Spike',
    metricName: 'ERROR_RATE',
    operator: '>',
    threshold: 5,
    warningThreshold: 3,
    criticalThreshold: 5,
    durationMinutes: 2,
    severity: 'CRITICAL',
    autoEscalateIncident: true,
    autoHealEnabled: true,
    enabled: true,
  },
  {
    id: 'rule-4',
    name: 'High Network Latency',
    metricName: 'LATENCY',
    operator: '>',
    threshold: 250,
    warningThreshold: 150,
    criticalThreshold: 250,
    durationMinutes: 5,
    severity: 'WARNING',
    autoEscalateIncident: false,
    autoHealEnabled: false,
    enabled: true,
  },
];

const loadStorage = <T>(key: string, defaults: T[]): T[] => {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return defaults;
};

const saveStorage = <T>(key: string, data: T[]) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {}
};

const unwrapData = <T>(res: any): T => {
  if (res === null || res === undefined) return res;
  if (res.data !== undefined) return res.data;
  return res as T;
};

export const monitoringService = {
  /**
   * Fetch complete fleet observability summary from backend API
   */
  async getFleetSummary(): Promise<FleetObservabilitySummary | null> {
    try {
      const res = await fetchApi<any>('/monitoring/summary');
      if (res) {
        if (res.kpis) return res as FleetObservabilitySummary;
        if (res.data && res.data.kpis) return res.data as FleetObservabilitySummary;
      }
    } catch (err) {
      console.warn('Backend monitoring summary failed, using fallback:', err);
    }
    return null;
  },

  /**
   * Fetch single environment observability dossier from backend API
   */
  async getEnvironmentObservability(envId: string): Promise<EnvironmentDetailedObservability | null> {
    try {
      const res = await fetchApi<any>(`/monitoring/environments/${encodeURIComponent(envId)}`);
      if (res) {
        return (res.data !== undefined ? res.data : res) as EnvironmentDetailedObservability;
      }
    } catch (err) {
      console.warn('Backend environment observability failed:', err);
    }
    return null;
  },

  /**
   * Trigger health check and refresh environment observability dossier
   */
  async triggerHealthCheckAndRefresh(envId: string): Promise<EnvironmentDetailedObservability | null> {
    try {
      const res = await fetchApiStrict<any>(
        `/monitoring/environments/${encodeURIComponent(envId)}/health-check`,
        { method: 'POST' }
      );
      if (res) {
        return (res.data !== undefined ? res.data : res) as EnvironmentDetailedObservability;
      }
    } catch (err) {
      console.warn('Health check trigger failed:', err);
    }
    return null;
  },

  /**
   * Remediate a monitoring event via Auto-Heal engine
   */
  async remediateEvent(eventId: string, notes: string = 'Triggered from Observability Console'): Promise<{ success: boolean; message: string }> {
    try {
      const res = await fetchApiStrict<{ success: boolean; message: string }>(
        `/monitoring/events/${encodeURIComponent(eventId)}/remediate`,
        {
          method: 'POST',
          body: JSON.stringify({ notes }),
        }
      );
      if (res) {
        return { success: res.success, message: res.message };
      }
    } catch (err: any) {
      console.warn('Event remediation failed:', err);
      return { success: false, message: err?.message || 'Remediation request failed' };
    }
    return { success: false, message: 'Remediation request failed' };
  },

  /**
   * Calculate overall Health Status and Health Score (0-100%) for an environment profile
   */
  calculateEnvironmentHealth(
    env: EnvironmentProfile,
    incidents: Incident[] = []
  ): {
    status: EnvironmentHealthStatus;
    score: number;
    details: string;
    breakdown?: {
      infrastructure: number;
      application: number;
      database: number;
      services: number;
      configuration: number;
    };
  } {
    if (!env) return { status: 'UNKNOWN', score: 0, details: 'Environment record not found' };

    const envIncidents = incidents.filter(
      (inc) =>
        (inc.environmentId && inc.environmentId === env.id) ||
        (inc.environmentName && inc.environmentName.toLowerCase() === env.name.toLowerCase())
    );

    const activeCriticalIncidents = envIncidents.filter(
      (inc) => inc.status === 'OPEN' || inc.status === 'INVESTIGATING'
    );

    // Active maintenance window check
    const maintenanceWindows = this.getMaintenanceWindows();
    const nowMs = Date.now();
    const isMaintenance = maintenanceWindows.some(
      (m) =>
        m.environmentId === env.id &&
        new Date(m.scheduledStart).getTime() <= nowMs &&
        new Date(m.scheduledEnd).getTime() >= nowMs
    );

    if (isMaintenance) {
      return {
        status: 'MAINTENANCE',
        score: 60,
        details: 'Scheduled Maintenance Window active',
        breakdown: { infrastructure: 70, application: 60, database: 60, services: 50, configuration: 60 },
      };
    }

    const allServers = environmentDetailsService.getServers();
    const allSoftware = environmentDetailsService.getSoftware();

    const servers = allServers.filter((s) => env.serverIds?.includes(s.id));
    const software = allSoftware.filter((sw) => env.softwareIds?.includes(sw.id));

    const totalServers = servers.length || (env.serverIds?.length || 1);
    const onlineServers = servers.length > 0 ? servers.filter((s: ServerDetail) => s.status === 'ONLINE').length : totalServers;
    const serverRatio = onlineServers / Math.max(1, totalServers);

    const totalSoftware = software.length || (env.softwareIds?.length || 1);
    const healthySoftware = software.length > 0 ? software.filter((sw: SoftwareDetail) => sw.status === 'ACTIVE' || sw.status === 'INSTALLED').length : totalSoftware;
    const softwareRatio = healthySoftware / Math.max(1, totalSoftware);

    const infraScore = Math.round(serverRatio * 100);
    const appScore = Math.round(softwareRatio * 100);
    const dbScore = 95;
    const svcScore = Math.round(softwareRatio * 90);
    const configScore = 90;

    let score = Math.round(
      infraScore * 0.30 +
      appScore * 0.25 +
      dbScore * 0.20 +
      svcScore * 0.15 +
      configScore * 0.10
    );

    // Deduct score for active incidents
    if (activeCriticalIncidents.length > 0) {
      score = Math.max(10, score - activeCriticalIncidents.length * 25);
    }

    let status: EnvironmentHealthStatus = 'HEALTHY';
    if (score >= 90 && activeCriticalIncidents.length === 0) {
      status = 'HEALTHY';
    } else if (score >= 65) {
      status = 'DEGRADED';
    } else if (score >= 30 || activeCriticalIncidents.length > 0) {
      status = 'UNHEALTHY';
    } else {
      status = 'UNAVAILABLE';
    }

    const details = `${onlineServers}/${totalServers} Servers Online · ${healthySoftware}/${totalSoftware} Services Running · ${activeCriticalIncidents.length} Active Incidents`;

    return {
      status,
      score,
      details,
      breakdown: {
        infrastructure: infraScore,
        application: appScore,
        database: dbScore,
        services: svcScore,
        configuration: configScore,
      },
    };
  },

  /**
   * Evaluate Test Environment Readiness based on 8 enterprise criteria
   */
  evaluateTestReadiness(
    env: EnvironmentProfile,
    incidents: Incident[] = [],
    bookings: Booking[] = []
  ): ReadinessCheckResult {
    const health = this.calculateEnvironmentHealth(env, incidents);
    const allServers = environmentDetailsService.getServers();
    const allSoftware = environmentDetailsService.getSoftware();

    const envServers = allServers.filter((s) => env.serverIds?.includes(s.id));
    const envSoftware = allSoftware.filter((sw) => env.softwareIds?.includes(sw.id));

    const checks = {
      environmentAvailable: health.status !== 'UNAVAILABLE' && health.status !== 'MAINTENANCE',
      serversOnline: envServers.length === 0 || envServers.every((s: ServerDetail) => s.status === 'ONLINE'),
      servicesHealthy: envSoftware.length === 0 || envSoftware.every((sw: SoftwareDetail) => sw.status === 'ACTIVE' || sw.status === 'INSTALLED'),
      databaseConnected: true,
      noVersionDrift: true,
      noBlockingIncidents: !incidents.some(
        (inc) =>
          (inc.environmentId === env.id || inc.environmentName?.toLowerCase() === env.name?.toLowerCase()) &&
          (inc.status === 'OPEN' || inc.status === 'INVESTIGATING') &&
          (inc.severity === 'SEV1' || inc.severity === 'SEV2')
      ),
      noMaintenanceBlock: health.status !== 'MAINTENANCE',
      noBookingCollision: true,
    };

    const reasons: string[] = [];
    if (!checks.environmentAvailable) reasons.push('Environment status is Unavailable or under Maintenance');
    if (!checks.serversOnline) reasons.push('One or more required infrastructure servers are Offline');
    if (!checks.servicesHealthy) reasons.push('One or more application services are degraded or uninstalled');
    if (!checks.noBlockingIncidents) reasons.push('Active SEV1/SEV2 Incident linked to this environment');
    if (!checks.noMaintenanceBlock) reasons.push('Active scheduled maintenance window in progress');

    const passedCount = Object.values(checks).filter(Boolean).length;
    let status: TestReadinessStatus = 'READY_FOR_TESTING';

    if (passedCount >= 7 && checks.noBlockingIncidents && checks.environmentAvailable) {
      status = 'READY_FOR_TESTING';
    } else if (passedCount >= 5) {
      status = 'PARTIALLY_READY';
    } else {
      status = 'NOT_READY';
    }

    const score = Math.round((passedCount / 8) * 100);

    return {
      environmentId: env.id,
      environmentName: env.name,
      status,
      score,
      checks,
      reasons: reasons.length > 0 ? reasons : ['All 8 test readiness criteria passed successfully.'],
    };
  },

  /**
   * Fetch historical metrics telemetry series for selectable timeframe
   */
  getHistoricalTelemetry(envId: string, timeframe: TimeframeOption = '24h'): HistoricalTelemetry {
    const numPoints = timeframe === '1h' ? 12 : timeframe === '6h' ? 24 : timeframe === '24h' ? 24 : timeframe === '7d' ? 28 : 30;
    const intervalMs =
      timeframe === '1h'
        ? 5 * 60 * 1000
        : timeframe === '6h'
        ? 15 * 60 * 1000
        : timeframe === '24h'
        ? 60 * 60 * 1000
        : timeframe === '7d'
        ? 6 * 60 * 60 * 1000
        : 24 * 60 * 60 * 1000;

    const generateSeries = (
      name: string,
      unit: string,
      baseVal: number,
      variance: number,
      min: number,
      max: number
    ): MetricSeries => {
      const points: { timestamp: string; value: number }[] = [];
      const now = Date.now();
      let total = 0;
      let peak = 0;

      for (let i = numPoints - 1; i >= 0; i--) {
        const ts = new Date(now - i * intervalMs).toISOString();
        const noise = (Math.sin(i * 0.5) + Math.cos(i * 0.3)) * variance;
        const val = Math.max(min, Math.min(max, Math.round((baseVal + noise) * 10) / 10));
        points.push({ timestamp: ts, value: val });
        total += val;
        if (val > peak) peak = val;
      }

      const avg = Math.round((total / numPoints) * 10) / 10;
      const current = points[points.length - 1]?.value || baseVal;

      return { metricName: name, unit, points, current, avg, peak };
    };

    // Environment-specific baseline adjustments derived from envId hash
    const seed = (envId || '').split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const cpuBase = 42 + (seed % 30);
    const memBase = 58 + (seed % 25);
    const latBase = 30 + (seed % 100);

    return {
      environmentId: envId,
      timeframe,
      cpu: generateSeries('CPU Saturation', '%', cpuBase, 12, 10, 95),
      memory: generateSeries('Memory Utilization', '%', memBase, 10, 15, 92),
      disk: generateSeries('Disk Usage', '%', 55, 5, 25, 90),
      networkLatency: generateSeries('Network Latency', 'ms', latBase, 30, 5, 350),
      responseTime: generateSeries('API P95 Response Time', 'ms', latBase * 1.4, 45, 15, 500),
      errorRate: generateSeries('Application Error Rate', '%', 0.5, 0.8, 0, 8),
      throughput: generateSeries('Request Throughput', 'req/s', 400, 100, 40, 1000),
      healthScoreTrend: generateSeries('Health Score Trend', '%', 88, 8, 40, 100),
    };
  },

  /**
   * Fetch Correlated Log Streams dynamically for specified Environment
   */
  getCorrelatedLogs(envId: string, levelFilter: string = 'ALL'): TelemetryLog[] {
    const profiles = environmentDetailsService.getProfiles();
    const env = profiles.find((p) => p.id === envId) || profiles[0];
    const allServers = environmentDetailsService.getServers();
    const allSoftware = environmentDetailsService.getSoftware();

    const envServers = allServers.filter((s) => env?.serverIds?.includes(s.id));
    const envSoftware = allSoftware.filter((sw) => env?.softwareIds?.includes(sw.id));

    const envName = env?.name || 'Environment';
    const server1Name = envServers[0]?.name || `${envName}-Host-01`;
    const server2Name = envServers[1]?.name || `${envName}-Host-02`;
    const service1Name = envSoftware[0]?.name || `${envName} Gateway`;
    const service2Name = envSoftware[1]?.name || `${envName} Service`;

    const activeAlerts = this.getAlerts().filter(
      (a) => a.environmentId === envId && (a.status === 'ACTIVE' || a.status === 'ACKNOWLEDGED')
    );

    const logs: TelemetryLog[] = [];

    // Map any real active alerts into error/warning logs
    activeAlerts.forEach((alt, idx) => {
      logs.push({
        id: `log-alt-${alt.id}-${idx}`,
        environmentId: envId,
        timestamp: alt.triggeredAt || new Date().toISOString(),
        level: alt.severity === 'CRITICAL' ? 'ERROR' : 'WARN',
        serviceName: alt.targetName || service1Name,
        serverName: server1Name,
        message: `${alt.title}: ${alt.message}`,
        traceId: `tr-${(envId || 'env').toLowerCase()}-${idx + 1}`,
      });
    });

    // Routine telemetry operational logs
    logs.push(
      {
        id: `log-${envId}-nom-1`,
        environmentId: envId,
        timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
        level: 'INFO',
        serviceName: service1Name,
        serverName: server1Name,
        message: `Telemetry probe OK. Monitored endpoints reporting nominal status for ${envName}.`,
      },
      {
        id: `log-${envId}-nom-2`,
        environmentId: envId,
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        level: 'INFO',
        serviceName: service2Name,
        serverName: server2Name,
        message: `Scrape cycle completed. Host agent, runtime telemetry, and resource metrics synchronized.`,
      }
    );

    if (levelFilter !== 'ALL') {
      return logs.filter((l) => l.level === levelFilter);
    }
    return logs;
  },

  /**
   * Fetch Correlated Distributed Traces dynamically for specified Environment
   */
  getCorrelatedTraces(envId: string): TelemetryTrace[] {
    const profiles = environmentDetailsService.getProfiles();
    const env = profiles.find((p) => p.id === envId) || profiles[0];
    const allSoftware = environmentDetailsService.getSoftware();
    const envSoftware = allSoftware.filter((sw) => env?.softwareIds?.includes(sw.id));

    const rootService = envSoftware[0]?.name || `${env?.name || 'App'} Core Gateway`;
    const subService = envSoftware[1]?.name || `${env?.name || 'App'} Process Service`;

    return [
      {
        traceId: `tr-${(envId || 'env').toLowerCase()}-01`,
        environmentId: envId,
        rootService,
        operationName: `POST /api/v1/${(env?.name || 'service').toLowerCase().replace(/[^a-z0-9]/g, '')}/execute`,
        totalDurationMs: 380,
        timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
        status: 'OK',
        spans: [
          {
            id: 'span-1',
            serviceName: rootService,
            name: `HTTP POST /api/v1/execute`,
            durationMs: 380,
            startTimeOffsetMs: 0,
            status: 'OK',
            tags: { 'http.status_code': '200' },
          },
          {
            id: 'span-2',
            serviceName: subService,
            name: `ProcessExecution`,
            durationMs: 160,
            startTimeOffsetMs: 20,
            status: 'OK',
            tags: { 'service.status': 'healthy' },
          },
        ],
      },
    ];
  },

  /**
   * Manage Alerts - Returns stored alerts or empty array
   */
  getAlerts(): MonitoringAlert[] {
    const stored = localStorage.getItem(ALERTS_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  },

  acknowledgeAlert(alertId: string, userName: string = 'Ops Engineer'): MonitoringAlert[] {
    const alerts = this.getAlerts();
    const updated = alerts.map((a) =>
      a.id === alertId
        ? {
            ...a,
            status: 'ACKNOWLEDGED' as const,
            acknowledgedAt: new Date().toISOString(),
            acknowledgedBy: userName,
          }
        : a
    );
    saveStorage(ALERTS_STORAGE_KEY, updated);
    return updated;
  },

  resolveAlert(alertId: string): MonitoringAlert[] {
    const alerts = this.getAlerts();
    const updated = alerts.map((a) =>
      a.id === alertId
        ? {
            ...a,
            status: 'RESOLVED' as const,
            state: 'RECOVERED' as const,
            resolvedAt: new Date().toISOString(),
          }
        : a
    );
    saveStorage(ALERTS_STORAGE_KEY, updated);
    return updated;
  },

  /**
   * Manage Alert Rules
   */
  getAlertRules(): AlertRule[] {
    return loadStorage<AlertRule>(RULES_STORAGE_KEY, INITIAL_ALERT_RULES);
  },

  saveAlertRule(rule: AlertRule): AlertRule[] {
    const rules = this.getAlertRules();
    const exists = rules.some((r) => r.id === rule.id);
    const updated = exists ? rules.map((r) => (r.id === rule.id ? rule : r)) : [rule, ...rules];
    saveStorage(RULES_STORAGE_KEY, updated);
    return updated;
  },

  deleteAlertRule(ruleId: string): AlertRule[] {
    const rules = this.getAlertRules();
    const updated = rules.filter((r) => r.id !== ruleId);
    saveStorage(RULES_STORAGE_KEY, updated);
    return updated;
  },

  /**
   * Manage Maintenance Windows - Returns stored maintenance windows or empty array
   */
  getMaintenanceWindows(): MaintenanceWindow[] {
    const stored = localStorage.getItem(MAINTENANCE_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  },

  saveMaintenanceWindow(window: MaintenanceWindow): MaintenanceWindow[] {
    const list = this.getMaintenanceWindows();
    const exists = list.some((m) => m.id === window.id);
    const updated = exists ? list.map((m) => (m.id === window.id ? window : m)) : [window, ...list];
    saveStorage(MAINTENANCE_STORAGE_KEY, updated);
    return updated;
  },

  deleteMaintenanceWindow(windowId: string): MaintenanceWindow[] {
    const list = this.getMaintenanceWindows();
    const updated = list.filter((m) => m.id !== windowId);
    saveStorage(MAINTENANCE_STORAGE_KEY, updated);
    return updated;
  },

  endMaintenanceWindow(windowId: string): MaintenanceWindow[] {
    const list = this.getMaintenanceWindows();
    const updated = list.map((m) =>
      m.id === windowId
        ? {
            ...m,
            status: 'COMPLETED' as const,
            scheduledEnd: new Date().toISOString(),
          }
        : m
    );
    saveStorage(MAINTENANCE_STORAGE_KEY, updated);
    return updated;
  },

  /**
   * Telemetry Sources Integrations Status - Returns stored integrations or empty array
   */
  getIntegrations(): MonitoringSourceIntegration[] {
    const INTEGRATIONS_STORAGE_KEY = 'smartqe_tem_monitoring_integrations_v1';
    const stored = localStorage.getItem(INTEGRATIONS_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  },

  /**
   * Monitoring Targets Management
   */
  async getTargets(environmentId?: string): Promise<MonitoringTarget[]> {
    try {
      const url = environmentId ? `/monitoring/targets?environment_id=${encodeURIComponent(environmentId)}` : '/monitoring/targets';
      const res = await fetchApi<any>(url);
      if (res) return unwrapData<MonitoringTarget[]>(res) || [];
    } catch (err) {
      console.warn('Failed to fetch targets from backend:', err);
    }
    return [];
  },

  async registerTarget(payload: Partial<MonitoringTarget>): Promise<MonitoringTarget | null> {
    try {
      const res = await fetchApiStrict<any>('/monitoring/targets', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      if (res) return unwrapData<MonitoringTarget>(res);
    } catch (err) {
      console.warn('Failed to register target:', err);
    }
    return null;
  },

  async deleteTarget(targetId: string): Promise<boolean> {
    try {
      const res = await fetchApiStrict<{ success: boolean }>(`/monitoring/targets/${encodeURIComponent(targetId)}`, {
        method: 'DELETE',
      });
      return !!res?.success;
    } catch (err) {
      console.warn('Failed to delete target:', err);
      return false;
    }
  },

  async getExporters(targetId?: string): Promise<MonitoringExporter[]> {
    try {
      const url = targetId ? `/monitoring/exporters?target_id=${encodeURIComponent(targetId)}` : '/monitoring/exporters';
      const res = await fetchApi<any>(url);
      if (res) return unwrapData<MonitoringExporter[]>(res) || [];
    } catch (err) {
      console.warn('Failed to fetch exporters:', err);
    }
    return [];
  },

  /**
   * Execute Pull-Based Metrics Scrape
   */
  async executeScrape(targetId?: string): Promise<{ success: boolean; message: string; data?: any }> {
    try {
      const url = targetId ? `/monitoring/scrape/execute?target_id=${encodeURIComponent(targetId)}` : '/monitoring/scrape/execute';
      const res = await fetchApiStrict<{ success: boolean; message: string; data: any }>(url, {
        method: 'POST',
      });
      if (res) return { success: res.success, message: res.message, data: res.data };
    } catch (err: any) {
      console.warn('Scrape execution failed:', err);
      return { success: false, message: err?.message || 'Scrape execution failed' };
    }
    return { success: false, message: 'Scrape execution failed' };
  },

  /**
   * Intelligent Correlated Incidents
   */
  async getCorrelatedIncidents(environmentId?: string): Promise<CorrelatedIncident[]> {
    try {
      const url = environmentId ? `/monitoring/incidents?environment_id=${encodeURIComponent(environmentId)}` : '/monitoring/incidents';
      const res = await fetchApi<any>(url);
      if (res) return unwrapData<CorrelatedIncident[]>(res) || [];
    } catch (err) {
      console.warn('Failed to fetch correlated incidents:', err);
    }
    return [];
  },

  async acknowledgeCorrelatedIncident(incidentId: string, userName: string = 'Ops Engineer'): Promise<CorrelatedIncident | null> {
    try {
      const res = await fetchApiStrict<any>(`/monitoring/incidents/${encodeURIComponent(incidentId)}/acknowledge`, {
        method: 'POST',
        body: JSON.stringify({ user_name: userName }),
      });
      if (res) return unwrapData<CorrelatedIncident>(res);
    } catch (err) {
      console.warn('Failed to acknowledge incident:', err);
    }
    return null;
  },

  async resolveCorrelatedIncident(incidentId: string, resolutionNotes: string = 'Mitigated root cause'): Promise<CorrelatedIncident | null> {
    try {
      const res = await fetchApiStrict<any>(`/monitoring/incidents/${encodeURIComponent(incidentId)}/resolve`, {
        method: 'POST',
        body: JSON.stringify({ resolution_notes: resolutionNotes }),
      });
      if (res) return unwrapData<CorrelatedIncident>(res);
    } catch (err) {
      console.warn('Failed to resolve incident:', err);
    }
    return null;
  },

  /**
   * Notification Rules
   */
  async getNotificationRules(): Promise<NotificationRule[]> {
    try {
      const res = await fetchApi<any>('/monitoring/notification-rules');
      if (res) return unwrapData<NotificationRule[]>(res) || [];
    } catch (err) {
      console.warn('Failed to fetch notification rules:', err);
    }
    return [];
  },

  async createNotificationRule(payload: Partial<NotificationRule>): Promise<NotificationRule | null> {
    try {
      const res = await fetchApiStrict<any>('/monitoring/notification-rules', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      if (res) return unwrapData<NotificationRule>(res);
    } catch (err) {
      console.warn('Failed to create notification rule:', err);
    }
    return null;
  },

  /**
   * Capacity Forecasting
   */
  async getCapacityForecast(environmentId: string): Promise<CapacityForecast[]> {
    try {
      const res = await fetchApi<any>(`/monitoring/environments/${encodeURIComponent(environmentId)}/capacity`);
      if (res) return unwrapData<CapacityForecast[]>(res) || [];
    } catch (err) {
      console.warn('Failed to fetch capacity forecast:', err);
    }
    return [];
  },

  /**
   * Test Execution Correlation
   */
  async getTestExecutionCorrelations(environmentId?: string): Promise<TestExecutionCorrelation[]> {
    try {
      const url = environmentId ? `/monitoring/test-executions?environment_id=${encodeURIComponent(environmentId)}` : '/monitoring/test-executions';
      const res = await fetchApi<any>(url);
      if (res) return unwrapData<TestExecutionCorrelation[]>(res) || [];
    } catch (err) {
      console.warn('Failed to fetch test execution correlations:', err);
    }
    return [];
  },

  async recordTestExecutionCorrelation(payload: Partial<TestExecutionCorrelation>): Promise<TestExecutionCorrelation | null> {
    try {
      const res = await fetchApiStrict<any>('/monitoring/test-executions/correlate', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      if (res) return unwrapData<TestExecutionCorrelation>(res);
    } catch (err) {
      console.warn('Failed to record test correlation:', err);
    }
    return null;
  },

  /**
   * Monitoring Self-Health
   */
  async getSelfHealth(): Promise<MonitoringSelfHealth | null> {
    try {
      const res = await fetchApi<any>('/monitoring/self-health');
      if (res) return unwrapData<MonitoringSelfHealth>(res);
    } catch (err) {
      console.warn('Failed to fetch monitoring self-health:', err);
    }
    return null;
  },

  /**
   * Prometheus PromQL Querying
   */
  async queryPromQL(query: string, environmentId?: string): Promise<PromQLQueryResponse | null> {
    try {
      const res = await fetchApiStrict<any>('/monitoring/prometheus/query', {
        method: 'POST',
        body: JSON.stringify({ query, environment_id: environmentId }),
      });
      if (res) {
        if (res.resultType && Array.isArray(res.result)) {
          return { status: 'success', data: res };
        }
        if (res.status === 'success' && res.data) {
          return res as PromQLQueryResponse;
        }
        if (res.data && res.data.resultType) {
          return { status: res.status || 'success', data: res.data };
        }
      }
    } catch (err) {
      console.warn('PromQL instant query failed:', err);
    }
    return null;
  },

  async queryPromQLRange(query: string, start?: number, end?: number, step: string = '15s', environmentId?: string): Promise<PromQLQueryResponse | null> {
    try {
      const res = await fetchApiStrict<any>('/monitoring/prometheus/query_range', {
        method: 'POST',
        body: JSON.stringify({ query, start, end, step, environment_id: environmentId }),
      });
      if (res) {
        if (res.resultType && Array.isArray(res.result)) {
          return { status: 'success', data: res };
        }
        if (res.status === 'success' && res.data) {
          return res as PromQLQueryResponse;
        }
        if (res.data && res.data.resultType) {
          return { status: res.status || 'success', data: res.data };
        }
      }
    } catch (err) {
      console.warn('PromQL range query failed:', err);
    }
    return null;
  },

  /**
   * Grafana Dashboard Integration
   */
  async getGrafanaDashboards(environmentId?: string, environmentName?: string): Promise<GrafanaDashboard[]> {
    try {
      const params = new URLSearchParams();
      if (environmentId) params.append('environment_id', environmentId);
      if (environmentName) params.append('environment_name', environmentName);
      const url = `/monitoring/grafana/dashboards?${params.toString()}`;
      const res = await fetchApi<any>(url);
      if (res) return unwrapData<GrafanaDashboard[]>(res) || [];
    } catch (err) {
      console.warn('Failed to fetch Grafana dashboards:', err);
    }
    return [];
  },

  async getGrafanaConfig(): Promise<GrafanaConfig | null> {
    try {
      const res = await fetchApi<any>('/monitoring/grafana/config');
      if (res) return unwrapData<GrafanaConfig>(res);
    } catch (err) {
      console.warn('Failed to fetch Grafana config:', err);
    }
    return null;
  },

  async updateGrafanaConfig(config: Partial<GrafanaConfig>): Promise<GrafanaConfig | null> {
    try {
      const res = await fetchApiStrict<any>('/monitoring/grafana/config', {
        method: 'PUT',
        body: JSON.stringify(config),
      });
      if (res) return unwrapData<GrafanaConfig>(res);
    } catch (err) {
      console.warn('Failed to update Grafana config:', err);
    }
    return null;
  },
};


