export interface AssistantSuggestedPrompt {
  category: string;
  prompt: string;
  icon?: string;
}

export const TEM_DEFAULT_PROMPTS: AssistantSuggestedPrompt[] = [
  // Health & Monitoring
  { category: 'Health', prompt: 'Which environments are currently down?' },
  { category: 'Health', prompt: 'Which environments have high CPU usage?' },
  { category: 'Health', prompt: 'Run health check sweep on SIT environments' },
  { category: 'Health', prompt: 'Show fleet-wide test readiness scores' },

  // Bookings & Worklist
  { category: 'Bookings', prompt: 'Which SIT environments are available right now?' },
  { category: 'Bookings', prompt: 'Who booked SIT-01?' },
  { category: 'Bookings', prompt: 'Show active bookings in my worklist' },
  { category: 'Bookings', prompt: 'Are there any overlapping booking conflicts?' },

  // Diagnosis & Comparison
  { category: 'Diagnosis', prompt: 'Compare SIT-01 and UAT-01' },
  { category: 'Diagnosis', prompt: 'What software versions are installed in SIT-01?' },
  { category: 'Diagnosis', prompt: 'Is Python or Java mismatched across environments?' },
  { category: 'Diagnosis', prompt: 'Show software diagnosis baseline results' },

  // Releases
  { category: 'Releases', prompt: 'Show all upcoming releases' },
  { category: 'Releases', prompt: 'Which environments are mapped to upcoming releases?' },
  { category: 'Releases', prompt: 'What test phases are configured for Release R2026.11?' },
  { category: 'Releases', prompt: 'Show release calendar and milestones' },

  // Demand & Capacity
  { category: 'Demand', prompt: 'How many SIT environments will we need next month?' },
  { category: 'Demand', prompt: 'Do we have enough environments for upcoming releases?' },
  { category: 'Demand', prompt: 'What is our current capacity gap in UAT?' },
  { category: 'Demand', prompt: 'Show predictive demand contention heatmap' },

  // How-To Guides
  { category: 'How-To', prompt: 'How does booking conflict detection work?' },
  { category: 'How-To', prompt: 'What does Auto-Heal do?' },
  { category: 'How-To', prompt: 'How do I provision a new environment?' },
  { category: 'How-To', prompt: 'What is the use of worklist?' },
  { category: 'How-To', prompt: 'How does topology blast radius simulation work?' },
];

export const TEM_CLIENT_KNOWLEDGE_TOPICS = [
  {
    key: 'provisioning',
    keywords: [
      'provisioning', 'provision', 'provis', 'provisin', 'wizard', 'template',
      'orchestrator', 'preflight', 'how to provision', 'new environment',
      'provision environment', 'create environment', 'spin up'
    ],
    title: 'Environment Provisioning Engine & 7-Step Wizard',
    reply: `### 🛠️ Environment Provisioning Engine & Wizard

SmartQE TEM provides automated, template-driven environment provisioning through a **7-step wizard**:

1. **Step 1: Basic Info**: Environment Name, Tier (\`DEV\`/\`SIT\`/\`UAT\`/\`PERF\`), Business Unit, Project, and Owner.
2. **Step 2: Infrastructure**: Cloud Provider (AWS, Azure, GCP, On-Prem), Region, VM size, vCPU, RAM, Storage.
3. **Step 3: Software Stack**: Select required runtimes (Java, Python, Node), databases (Postgres, Oracle), and middleware.
4. **Step 4: Configuration**: Network ports, environment variables, and endpoint URLs.
5. **Step 5: Dependency Mapping**: Upstream APIs and downstream databases.
6. **Step 6: Resource Validation & Preflight**: Automated preflight checks verifying quota, subnet availability, and naming collisions.
7. **Step 7: Provisioning Plan & Execution**: Orchestrator step-by-step execution with live SSE log streaming and rollback support.`,
  },
  {
    key: 'overview',
    keywords: ['what is tem', 'tem platform', 'tem architecture', 'tem overview', 'control tower', 'how tem works', 'smartqe overview', 'tem summary', 'tem modules'],
    title: 'SmartQE TEM Control Tower Overview',
    reply: `### 🏢 SmartQE TEM (Test Environment Management) Overview

**SmartQE TEM** is the enterprise "Air Traffic Control" for software non-production environments. It unifies 15 core operational modules:

1. **Command Center (Dashboard)**: Fleet-wide health KPIs, capacity gauges, readiness matrix, and active incident/release sidebars.
2. **Portfolio Management**: Organizational master data hierarchy (\`Business Unit\` ➔ \`Project\` ➔ \`Component\` ➔ \`Application\`).
3. **Environment Details**: Configuration profiles, network endpoints, DB connection strings, and component topology mappings.
4. **Resource Inventory**: Physical & cloud infrastructure asset tracking (Servers, DBs, Queues, Gateways, Cloud Providers).
5. **Environment Topology**: Interactive graph visualization and **Blast Radius / Impact Analysis** simulations.
6. **Health Checks**: Multi-tier asynchronous health checks (Server, Software, Application, Database, Network).
7. **Enterprise Auto-Heal**: Automated fault detection, policy remediation rules, and operator approval workflows.
8. **Observability & Monitoring**: Real-time telemetry (CPU, Memory, Storage, Latency, Error Rate), readiness scores, and drift detection.
9. **Environment Diagnosis & Comparison**: Software inventory baselines, version mismatch detection, and **SIT vs UAT side-by-side comparison**.
10. **Booking & Reservation Engine**: Conflict-free scheduling with **Exclusive (Disruptive)** vs **Shared** reservation modes.
11. **Release Management & Calendar**: Deployment pipelines, risk ratings, and multi-view calendar (Gantt, Monthly, Quarterly, Yearly).
12. **Environment Provisioning Engine**: 7-step provisioning wizard, preflight validation, orchestrator execution, and SSE streaming.
13. **Usage Analysis & Utilization**: 4-tier environment classification (Frequently, Moderately, Rarely, Never Used).
14. **AI Predictive Demand & Capacity**: Contention risk heatmaps, upcoming release capacity gap forecasting, and recommendations.
15. **Incidents, Runbooks & Security**: SEV1-SEV4 incident triage, automated SOP execution, and fine-grained RBAC.`,
  },
  {
    key: 'booking_conflicts',
    keywords: ['booking', 'reservation', 'conflict', 'exclusive', 'shared', 'booking conflict', 'disruptive', 'how booking works', 'book environment'],
    title: 'Booking Modes & Conflict Detection',
    reply: `### 📅 Booking Engine, Reservation Modes & Conflict Prevention

SmartQE TEM eliminates double-booking and test collisions:

#### 1. Reservation Modes
- **Shared Mode**: Multiple testing teams can book and test concurrently for non-disruptive functional testing.
- **Exclusive (Disruptive) Mode**: Locks the entire environment exclusively for DB schema migrations, load testing, or destructive patching.

#### 2. Conflict Detection Algorithm
When requesting a booking window \`[T_start, T_end]\`:
1. Identifies any overlapping active/approved bookings on the same environment.
2. If either booking is **Exclusive/Disruptive**, TEM flags a **Hard Collision Conflict**.
3. If both bookings are **Shared**, TEM permits concurrency but warns of shared capacity.
4. If a booking window falls outside the associated Release dates, a **Release Boundary Conflict** is flagged.`,
  },
  {
    key: 'worklist',
    keywords: [
      'worklist', 'work list', 'use of worklist', 'worklist use', 'what is worklist',
      'approval queue', 'pending approvals', 'approve booking', 'reject booking',
      'conflict resolution', 'resolve conflict', 'check availability', 'available slots',
      'worklist table', 'booking approvals', 'approver', 'worklist purpose', 'why use worklist'
    ],
    title: 'Bookings Worklist & Approval Queue',
    reply: `### 📋 Bookings Worklist & Approval Queue

The **Worklist** (\`/worklist\`) is the central operational command center in TEM for managing environment bookings, approvals, and scheduling collisions:

#### 1. Centralized Approval Queue
- Displays all environment reservations across your fleet with statuses: \`PENDING\`, \`APPROVED\`, \`REJECTED\`, \`IN_PROGRESS\`, \`COMPLETED\`, \`CANCELLED\`.
- Designated **Approvers & Environment Managers** can review reservation requests submitted by QA, Dev, and Release teams.

#### 2. One-Click Approval & Rejection Workflows
- **Approve Booking**: Approvers can accept requests with optional review notes, confirming environment allocation and dispatching automated email notifications.
- **Reject Booking**: Enforces a mandatory **Rejection Reason** for transparency and audit compliance.

#### 3. Conflict Detection & Visual Collision Alerts
- Flags hard collisions between overlapping bookings (especially when either reservation is in **Exclusive / Disruptive** mode) and warns if dates violate release boundaries.

#### 4. Smart Conflict Resolution Workbench
When a collision is detected, the Worklist provides an interactive resolution wizard:
- **Reschedule Window**: Adjust reservation start and end dates.
- **Mode Adjustment**: Switch an Exclusive booking to Shared mode if non-disruptive.
- **Smart Slot Finder**: Click **Check Availability** to automatically find and select alternate non-conflicting time slots on the requested environment.

#### 5. Email Notification Audit Trail
- Inspect delivery logs for all automated notifications sent to requesters, environment owners, and approvers.

#### 6. CSV Export & Bulk Filtering
- Filter by status, date range, tier, or environment, and export reports via **Export CSV** (\`TEM_Bookings_Worklist.csv\`).`,
  },
  {
    key: 'define_workflow',
    keywords: [
      'define workflow', 'define workflows', 'how define workflow works', 'how workflow works',
      'workflow', 'workflows', 'approval workflow', 'approval pipeline', 'sequential approval',
      'workflow approver', 'approver chain', 'workflow order', 'tem service type',
      'workflow setup', 'create workflow', 'multi-level approval'
    ],
    title: 'Define Workflow & Multi-Stage Approval Pipelines',
    reply: `### 🔄 Define Workflow & Multi-Stage Approval Pipelines

The **Define Workflow** screen (\`/settings/define-workflow\`) allows Administrators to create and govern **Sequential Multi-Level Approval Chains** for critical TEM operational actions:

#### 1. 4-Dimensional Context Scoping
Every workflow is uniquely anchored to a 4-level context:
1. **Business Unit (BU)**: e.g. *Retail Banking*, *Wealth Management*, *Cards*.
2. **Environment**: Target environment profile (e.g. *SIT-01*, *UAT-02*, *DEV-01*).
3. **Application**: Associated application entity (e.g. *Payment Gateway*, *Core Banking API*).
4. **TEM Service Type**:
   - \`ENVIRONMENT_RESERVATION\`: Bookings and reservations.
   - \`ENVIRONMENT_PROVISIONING\`: Infrastructure spin-up and teardown.
   - \`ENVIRONMENT_MONITORING\`: Telemetry and threshold changes.
   - \`ENVIRONMENT_HEALTH_CHECK\`: Deep probe executions.

#### 2. Sequential Multi-Step Approvers
- Administrators configure an ordered chain of designated users (\`Order 1\`, \`Order 2\`, \`Order 3\`).
- Example: **Step 1 (QA Lead)** ➔ **Step 2 (Env Manager)** ➔ **Step 3 (Release Director)**.

#### 3. Execution & Integration with Worklist
1. When a user requests a reservation or provisioning on that target environment:
2. TEM matches the request against the configured Workflow for that BU + Environment + Application + Service.
3. The request enters the **Worklist (\`/worklist\`)** of the **Step 1 Approver**.
4. Once Step 1 approves, TEM automatically advances the request to **Step 2**, and so on.
5. If any approver rejects, the workflow halts, logs the rejection reason, and notifies the requester.
6. Once all steps approve, the environment reservation or provisioning automatically activates.

#### 4. Workflow Lifecycle & Auditing
- **Status**: Toggle workflows \`ACTIVE\` or \`INACTIVE\` at any time.
- **Audit Trails**: Full tracking of \`Created By\`, \`Modified By\`, timestamps, and historical execution steps.`,
  },
  {
    key: 'auto_heal',
    keywords: ['auto-heal', 'auto heal', 'autoheal', 'remediation', 'self-healing', 'restart service', 'flush cache', 'clean disk'],
    title: 'Enterprise Auto-Heal & Automated Remediation',
    reply: `### ⚡ Enterprise Auto-Heal & Automated Remediation

Auto-Heal continuously monitors health check failures and executes predefined remediation rules:

- **High Disk Usage (>90%)**: Executes log purge and temporary file cleanup.
- **Service Crash / HTTP 503**: Triggers automated service restart or container reboot.
- **Cache Eviction / High Memory**: Executes Redis cache flush or JVM heap compaction.
- **Execution Modes**: Fully Automated or Operator Approval Gate for high-impact actions.`,
  },
  {
    key: 'diagnosis',
    keywords: ['diagnosis', 'compare', 'comparison', 'sit vs uat', 'version mismatch', 'software inventory', 'missing software', 'drift'],
    title: 'Environment Diagnosis & Version Comparison',
    reply: `### 🔍 Environment Diagnosis & Comparison Workbench

Diagnosis verifies that test environments have the exact required runtimes, packages, and application versions:

- **MATCH**: Installed version matches expected baseline (e.g., Java \`17.0.10\` == \`17.0.10\`).
- **VERSION_MISMATCH**: Installed version differs from baseline (e.g., Python \`3.10.12\` vs expected \`3.11.5\`).
- **MISSING**: Mandatory package is not installed on the target environment.
- **Side-by-Side Comparison**: Compares any two environments (e.g., SIT vs UAT) and generates a consistency score and actionable upgrade recommendations.`,
  },
  {
    key: 'usage_analysis',
    keywords: ['usage', 'usage analysis', 'frequently used', 'moderately used', 'rarely used', 'never used', 'utilization', 'zombie'],
    title: 'Intelligent Environment Usage Analysis',
    reply: `### 📈 Intelligent Environment Usage Analysis

Usage Analysis classifies environments into 4 utilization tiers:
1. **Frequently Used (🔥 High Demand)**: Utilization $\\ge 60\\%$ OR $\\ge 15$ bookings in period.
2. **Moderately Used (⚖️ Healthy)**: Utilization $20\\% - 59\\%$ OR $5 - 14$ bookings in period.
3. **Rarely Used (⚠️ Low Utilization)**: Utilization $< 20\\%$ AND $< 5$ bookings.
4. **Never Used (🛑 Zombie Candidate)**: $0$ bookings recorded during analysis period (candidates for decommissioning).`,
  },
  {
    key: 'predictive_demand',
    keywords: ['predictive demand', 'demand', 'capacity', 'forecast', 'shortage', 'capacity gap', 'how many'],
    title: 'AI Predictive Demand & Capacity Planning',
    reply: `### 🔮 AI Predictive Environment Demand & Capacity Forecasting

The AI Predictive Demand engine forecasts future environment needs before release crunches occur:

- **Predictive Contention Heatmap**: Visualizes calendar dates with high probability of booking collisions.
- **Capacity Gap Calculation**: $\\text{Capacity Gap} = \\text{Forecasted Demand} - \\text{Available Online Environments}$.
- **Shortage Warnings**: Alerts 30, 60, and 90 days in advance so infrastructure teams can provision capacity before test cycles begin.`,
  },
  {
    key: 'topology',
    keywords: ['topology', 'blast radius', 'impact analysis', 'dependencies', 'graph', 'dependency tree'],
    title: 'Environment Topology & Blast Radius Impact Analysis',
    reply: `### 🕸️ Environment Topology & Blast Radius Impact Analysis

Topology visualizes interconnected architectures across microservices, databases, and gateways:

- **Interactive Graph**: Directional nodes & dependency edges with protocol labels.
- **Blast Radius Simulator**: Evaluates upstream outages and downstream orphaned services if a target node crashes.`,
  },
  {
    key: 'incidents_runbooks',
    keywords: ['incident', 'incidents', 'runbook', 'runbooks', 'sev1', 'sev2', 'rca', 'sop'],
    title: 'Incidents & Operational Runbooks',
    reply: `### 🚨 Incidents & Operational Runbooks

- **Incident Triage**: Tracks \`SEV1\`-\`SEV4\` outages with SLA tracking and RCA root-cause enforcement.
- **One-Click Runbooks**: Automated SOPs for Kafka offset resets, Redis cache eviction, and test DB sanitization.`,
  }
];
