import React from 'react';
import { MonitoringSelfHealth } from '../../types/monitoring';
import { ShieldCheck, Activity, Database, Clock, RefreshCw, Cpu, Layers } from 'lucide-react';

interface MonitoringSelfHealthSectionProps {
  selfHealth: MonitoringSelfHealth | null;
  onRefresh?: () => void;
  isLoading?: boolean;
}

export const MonitoringSelfHealthSection: React.FC<MonitoringSelfHealthSectionProps> = ({
  selfHealth,
  onRefresh,
  isLoading = false,
}) => {
  if (!selfHealth) {
    return (
      <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-6 text-center text-slate-400 font-mono text-xs">
        Loading Monitoring Self-Health diagnostics...
      </div>
    );
  }

  return (
    <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-5 shadow-xl font-mono text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> MONITORING PLATFORM SELF-HEALTH & OBSERVABILITY
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Internal telemetry tracking the operational health of the metrics scraper, collection engine, time-series store, and query engine.
          </p>
        </div>

        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 border border-slate-700"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isLoading ? 'animate-spin' : ''}`} />
            <span>DIAGNOSE PLATFORM</span>
          </button>
        )}
      </div>

      {/* Primary KPI Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-500 uppercase font-bold block">PLATFORM HEALTH</span>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-lg font-black text-emerald-400">{selfHealth.service_status}</span>
          </div>
          <span className="text-[10px] text-slate-400">Scraper: {selfHealth.scraper_status}</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-500 uppercase font-bold block">SCRAPE SUCCESS RATE</span>
          <span className="text-xl font-black text-white">{selfHealth.scrape_success_rate_pct}%</span>
          <span className="text-[10px] text-emerald-400">High Reliability</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-500 uppercase font-bold block">AVG SCRAPE LATENCY</span>
          <span className="text-xl font-black text-white">{selfHealth.avg_scrape_duration_ms} ms</span>
          <span className="text-[10px] text-slate-400">Sub-50ms target met</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-500 uppercase font-bold block">SAMPLES IN STORE</span>
          <span className="text-xl font-black text-orange-400">{selfHealth.stored_metric_samples_count.toLocaleString()}</span>
          <span className="text-[10px] text-slate-400">30-day retention window</span>
        </div>
      </div>

      {/* Subsystem Diagnostics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
        <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl space-y-3">
          <h4 className="text-xs font-bold text-white uppercase flex items-center gap-2 border-b border-slate-800 pb-2">
            <Activity className="w-4 h-4 text-orange-400" /> Scraper & Target Pipeline Subsystem
          </h4>

          <div className="space-y-2 text-[11px]">
            <div className="flex justify-between py-1 border-b border-slate-900 text-slate-300">
              <span className="text-slate-400">Metrics Scraping Engine:</span>
              <span className="font-bold text-emerald-400">{selfHealth.scraper_status} (Pull Architecture)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900 text-slate-300">
              <span className="text-slate-400">Active Monitored Targets:</span>
              <span className="font-bold text-white">{selfHealth.active_targets_count} registered</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900 text-slate-300">
              <span className="text-slate-400">Active Exporters:</span>
              <span className="font-bold text-white">{selfHealth.active_exporters_count} online</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900 text-slate-300">
              <span className="text-slate-400">Queue Ingestion Backlog:</span>
              <span className="font-bold text-emerald-400">{selfHealth.queue_backlog_size} items (Zero Lag)</span>
            </div>
            <div className="flex justify-between py-1 text-slate-300">
              <span className="text-slate-400">Last Telemetry Run:</span>
              <span className="font-mono text-slate-300">{selfHealth.last_scraper_run?.replace('T', ' ').substring(0, 19)}</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl space-y-3">
          <h4 className="text-xs font-bold text-white uppercase flex items-center gap-2 border-b border-slate-800 pb-2">
            <Database className="w-4 h-4 text-blue-400" /> Storage Engine & Query Layer Subsystem
          </h4>

          <div className="space-y-2 text-[11px]">
            <div className="flex justify-between py-1 border-b border-slate-900 text-slate-300">
              <span className="text-slate-400">Time-Series Storage Engine:</span>
              <span className="font-bold text-white">{selfHealth.storage_engine}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900 text-slate-300">
              <span className="text-slate-400">Collector Processing Status:</span>
              <span className="font-bold text-emerald-400">{selfHealth.collector_status}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900 text-slate-300">
              <span className="text-slate-400">Query Engine Status:</span>
              <span className="font-bold text-emerald-400">{selfHealth.query_engine_status}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900 text-slate-300">
              <span className="text-slate-400">Data Retention Policy:</span>
              <span className="font-bold text-slate-300">{selfHealth.metrics_retention_days} Days Rolling Window</span>
            </div>
            <div className="flex justify-between py-1 text-slate-300">
              <span className="text-slate-400">Daemon Process Uptime:</span>
              <span className="font-mono text-slate-300">{Math.round(selfHealth.uptime_seconds / 3600)} Hours (Nominal)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
