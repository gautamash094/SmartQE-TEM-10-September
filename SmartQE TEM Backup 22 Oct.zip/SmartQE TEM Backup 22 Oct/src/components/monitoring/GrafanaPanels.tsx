import React from 'react';
import { Activity, Server, Database, Cpu, HardDrive, Zap, CheckCircle2, AlertTriangle, AlertOctagon } from 'lucide-react';

// =========================================================================
// 1. RADIAL MULTI-THRESHOLD STAT GAUGE
// =========================================================================

interface RadialGaugeProps {
  label: string;
  value: number;
  unit?: string;
  min?: number;
  max?: number;
  warningThreshold?: number;
  criticalThreshold?: number;
  subtext?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const RadialStatGauge: React.FC<RadialGaugeProps> = ({
  label,
  value,
  unit = '%',
  min = 0,
  max = 100,
  warningThreshold = 75,
  criticalThreshold = 90,
  subtext,
  size = 'md',
}) => {
  const clampedVal = Math.max(min, Math.min(max, value));
  const pct = (clampedVal - min) / (max - min);

  // SVG dimensions
  const radius = size === 'sm' ? 36 : size === 'lg' ? 64 : 48;
  const strokeWidth = size === 'sm' ? 7 : size === 'lg' ? 12 : 9;
  const circumference = 2 * Math.PI * radius;
  // Use a 270-degree arc (3/4 of a circle)
  const arcLength = circumference * 0.75;
  const strokeDashoffset = arcLength - pct * arcLength;

  // Determine status color
  let strokeColor = '#10b981'; // emerald-500
  let badgeColor = 'text-emerald-400 bg-emerald-950/60 border-emerald-800';
  let statusText = 'NOMINAL';

  if (clampedVal >= criticalThreshold) {
    strokeColor = '#f43f5e'; // rose-500
    badgeColor = 'text-rose-400 bg-rose-950/60 border-rose-800';
    statusText = 'CRITICAL';
  } else if (clampedVal >= warningThreshold) {
    strokeColor = '#f59e0b'; // amber-500
    badgeColor = 'text-amber-400 bg-amber-950/60 border-amber-800';
    statusText = 'WARNING';
  }

  const svgDim = radius * 2 + strokeWidth * 2 + 10;
  const center = svgDim / 2;

  return (
    <div className="bg-[#0f172a]/90 border border-slate-800 rounded-xl p-4 flex flex-col items-center justify-between relative shadow-lg hover:border-slate-700 transition-all">
      {/* Top Header */}
      <div className="w-full flex items-center justify-between mb-2">
        <span className="text-[11px] font-mono font-bold text-slate-400 tracking-wider uppercase truncate">
          {label}
        </span>
        <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${badgeColor}`}>
          {statusText}
        </span>
      </div>

      {/* SVG Arc Gauge */}
      <div className="relative flex items-center justify-center my-1">
        <svg width={svgDim} height={svgDim} className="transform -rotate-[135deg]">
          {/* Background Track */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="transparent"
            stroke="#1e293b"
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeLinecap="round"
          />
          {/* Active Value Arc */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="transparent"
            stroke={strokeColor}
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-700 ease-out"
          />
        </svg>

        {/* Center Readout */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-2xl font-black font-mono text-white tracking-tight">
            {value.toFixed(1)}
            <span className="text-xs text-slate-400 ml-0.5">{unit}</span>
          </span>
          {subtext && <span className="text-[10px] text-slate-500 font-mono mt-0.5">{subtext}</span>}
        </div>
      </div>

      {/* Threshold Markers */}
      <div className="w-full flex items-center justify-between text-[10px] font-mono text-slate-500 pt-2 border-t border-slate-800/80 mt-2">
        <span>0{unit}</span>
        <span className="text-amber-500/80">Warn: {warningThreshold}{unit}</span>
        <span className="text-rose-500/80">Crit: {criticalThreshold}{unit}</span>
        <span>{max}{unit}</span>
      </div>
    </div>
  );
};


// =========================================================================
// 2. TIME-SERIES AREA GRAPH PANEL
// =========================================================================

interface AreaGraphPoint {
  time: string;
  value: number;
}

interface TimeSeriesAreaGraphProps {
  title: string;
  subtitle?: string;
  data: AreaGraphPoint[];
  color?: 'emerald' | 'blue' | 'amber' | 'purple' | 'cyan';
  unit?: string;
  currentValue?: number;
  height?: number;
}

export const TimeSeriesAreaGraph: React.FC<TimeSeriesAreaGraphProps> = ({
  title,
  subtitle,
  data,
  color = 'emerald',
  unit = '%',
  currentValue,
  height = 140,
}) => {
  if (!data || data.length === 0) {
    return (
      <div className="bg-[#0f172a]/90 border border-slate-800 rounded-xl p-4 flex items-center justify-center text-xs text-slate-500 font-mono">
        No time-series samples recorded
      </div>
    );
  }

  const values = data.map((d) => d.value);
  const minVal = Math.min(...values);
  const maxVal = Math.max(...values, 1.0);
  const range = maxVal - minVal || 1.0;

  const colorMap = {
    emerald: { stroke: '#10b981', fillStart: 'rgba(16, 185, 129, 0.45)', fillEnd: 'rgba(16, 185, 129, 0.02)' },
    blue: { stroke: '#3b82f6', fillStart: 'rgba(59, 130, 246, 0.45)', fillEnd: 'rgba(59, 130, 246, 0.02)' },
    amber: { stroke: '#f59e0b', fillStart: 'rgba(245, 158, 11, 0.45)', fillEnd: 'rgba(245, 158, 11, 0.02)' },
    purple: { stroke: '#a855f7', fillStart: 'rgba(168, 85, 247, 0.45)', fillEnd: 'rgba(168, 85, 247, 0.02)' },
    cyan: { stroke: '#06b6d4', fillStart: 'rgba(6, 182, 212, 0.45)', fillEnd: 'rgba(6, 182, 212, 0.02)' },
  };
  const theme = colorMap[color] || colorMap.emerald;

  // Build SVG Path
  const width = 500;
  const paddingX = 10;
  const paddingY = 15;
  const plotW = width - paddingX * 2;
  const plotH = height - paddingY * 2;

  const points = data.map((d, i) => {
    const x = paddingX + (i / Math.max(1, data.length - 1)) * plotW;
    const y = paddingY + plotH - ((d.value - minVal) / range) * plotH;
    return { x, y, ...d };
  });

  const lineD = points.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)},${p.y.toFixed(1)}`, '');
  const areaD = `${lineD} L ${points[points.length - 1].x.toFixed(1)},${height} L ${points[0].x.toFixed(1)},${height} Z`;
  const gradId = `area-grad-${title.replace(/[^a-zA-Z0-9]/g, '')}`;

  const latestVal = currentValue !== undefined ? currentValue : values[values.length - 1];

  return (
    <div className="bg-[#0f172a]/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-lg">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h4 className="text-xs font-mono font-bold text-white tracking-wide uppercase flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: theme.stroke }}></span>
            {title}
          </h4>
          {subtitle && <p className="text-[10px] text-slate-400 font-mono mt-0.5">{subtitle}</p>}
        </div>
        <div className="text-right">
          <span className="text-xl font-mono font-black text-white">
            {latestVal.toFixed(1)}
            <span className="text-xs text-slate-400 ml-0.5">{unit}</span>
          </span>
          <div className="text-[9px] text-slate-500 font-mono">
            Min: {minVal.toFixed(1)} / Max: {maxVal.toFixed(1)}
          </div>
        </div>
      </div>

      {/* SVG Time Series Area */}
      <div className="w-full overflow-hidden my-1">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-28" preserveAspectRatio="none">
          <defs>
            <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={theme.fillStart} />
              <stop offset="100%" stopColor={theme.fillEnd} />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line x1={0} y1={height * 0.25} x2={width} y2={height * 0.25} stroke="#1e293b" strokeDasharray="3 3" />
          <line x1={0} y1={height * 0.5} x2={width} y2={height * 0.5} stroke="#1e293b" strokeDasharray="3 3" />
          <line x1={0} y1={height * 0.75} x2={width} y2={height * 0.75} stroke="#1e293b" strokeDasharray="3 3" />

          {/* Gradient Filled Area */}
          <path d={areaD} fill={`url(#${gradId})`} />

          {/* Line Stroke */}
          <path d={lineD} fill="none" stroke={theme.stroke} strokeWidth="2.5" strokeLinecap="round" />

          {/* Current Value Marker */}
          {points.length > 0 && (
            <circle
              cx={points[points.length - 1].x}
              cy={points[points.length - 1].y}
              r="4.5"
              fill={theme.stroke}
              stroke="#0f172a"
              strokeWidth="2"
            />
          )}
        </svg>
      </div>

      {/* Time Axis Labels */}
      <div className="flex items-center justify-between text-[9px] font-mono text-slate-500 pt-1 border-t border-slate-800/80">
        <span>{data[0]?.time || 'start'}</span>
        <span>{data[Math.floor(data.length / 2)]?.time || 'mid'}</span>
        <span>{data[data.length - 1]?.time || 'now'}</span>
      </div>
    </div>
  );
};


// =========================================================================
// 3. HTTP STATUS CODES & THROUGHPUT BAR CHART
// =========================================================================

interface HttpStatusDistributionProps {
  status2xx: number;
  status3xx: number;
  status4xx: number;
  status5xx: number;
  totalThroughputRps: number;
}

export const HttpStatusDistribution: React.FC<HttpStatusDistributionProps> = ({
  status2xx = 94.5,
  status3xx = 2.1,
  status4xx = 2.8,
  status5xx = 0.6,
  totalThroughputRps = 1420,
}) => {
  const total = status2xx + status3xx + status4xx + status5xx || 100.0;
  const p2xx = (status2xx / total) * 100;
  const p3xx = (status3xx / total) * 100;
  const p4xx = (status4xx / total) * 100;
  const p5xx = (status5xx / total) * 100;

  return (
    <div className="bg-[#0f172a]/90 border border-slate-800 rounded-xl p-4 shadow-lg flex flex-col justify-between">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h4 className="text-xs font-mono font-bold text-white tracking-wide uppercase flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            HTTP Throughput & Status Distribution
          </h4>
          <p className="text-[10px] text-slate-400 font-mono mt-0.5">Scraped via JVM / API Micrometer Exporter</p>
        </div>
        <div className="text-right">
          <span className="text-lg font-mono font-black text-white">{totalThroughputRps}</span>
          <span className="text-[10px] text-slate-400 ml-1 font-mono">req/sec</span>
        </div>
      </div>

      {/* Segmented Bar */}
      <div className="w-full h-5 rounded-lg overflow-hidden flex bg-slate-800 p-0.5 gap-0.5 my-2">
        {p2xx > 0 && (
          <div
            style={{ width: `${p2xx}%` }}
            className="h-full bg-emerald-500 rounded-l flex items-center justify-center text-[9px] font-mono font-bold text-slate-950 transition-all duration-500"
            title={`2xx Success: ${status2xx.toFixed(1)}%`}
          >
            {p2xx > 10 ? `${p2xx.toFixed(0)}%` : ''}
          </div>
        )}
        {p3xx > 0 && (
          <div
            style={{ width: `${p3xx}%` }}
            className="h-full bg-blue-500 flex items-center justify-center text-[9px] font-mono font-bold text-slate-950 transition-all duration-500"
            title={`3xx Redirect: ${status3xx.toFixed(1)}%`}
          >
            {p3xx > 10 ? `${p3xx.toFixed(0)}%` : ''}
          </div>
        )}
        {p4xx > 0 && (
          <div
            style={{ width: `${p4xx}%` }}
            className="h-full bg-amber-500 flex items-center justify-center text-[9px] font-mono font-bold text-slate-950 transition-all duration-500"
            title={`4xx Client Error: ${status4xx.toFixed(1)}%`}
          >
            {p4xx > 8 ? `${p4xx.toFixed(0)}%` : ''}
          </div>
        )}
        {p5xx > 0 && (
          <div
            style={{ width: `${p5xx}%` }}
            className="h-full bg-rose-500 rounded-r flex items-center justify-center text-[9px] font-mono font-bold text-white transition-all duration-500"
            title={`5xx Server Error: ${status5xx.toFixed(1)}%`}
          >
            {p5xx > 5 ? `${p5xx.toFixed(0)}%` : ''}
          </div>
        )}
      </div>

      {/* Legend & Count */}
      <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-800/80 text-[10px] font-mono">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded bg-emerald-500"></span>
          <span className="text-slate-400">2xx:</span>
          <span className="text-emerald-400 font-bold">{status2xx.toFixed(1)}%</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded bg-blue-500"></span>
          <span className="text-slate-400">3xx:</span>
          <span className="text-blue-400 font-bold">{status3xx.toFixed(1)}%</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded bg-amber-500"></span>
          <span className="text-slate-400">4xx:</span>
          <span className="text-amber-400 font-bold">{status4xx.toFixed(1)}%</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded bg-rose-500"></span>
          <span className="text-slate-400">5xx:</span>
          <span className="text-rose-400 font-bold">{status5xx.toFixed(1)}%</span>
        </div>
      </div>
    </div>
  );
};


// =========================================================================
// 4. SERVER INFRASTRUCTURE HEATMAP MATRIX
// =========================================================================

interface HostHeatmapItem {
  id: string;
  name: string;
  environment: string;
  cpu: number;
  memory: number;
  disk: number;
  status: 'UP' | 'DOWN' | 'DEGRADED';
}

interface ServerHeatmapMatrixProps {
  hosts: HostHeatmapItem[];
  metricType?: 'cpu' | 'memory' | 'disk';
}

export const ServerHeatmapMatrix: React.FC<ServerHeatmapMatrixProps> = ({
  hosts,
  metricType = 'cpu',
}) => {
  const getCellBg = (val: number, isDown: boolean) => {
    if (isDown) return 'bg-rose-950/80 border-rose-600 text-rose-300';
    if (val >= 90) return 'bg-rose-900/80 border-rose-600 text-rose-200';
    if (val >= 80) return 'bg-orange-900/80 border-orange-500 text-orange-200';
    if (val >= 65) return 'bg-amber-900/60 border-amber-600 text-amber-200';
    if (val >= 40) return 'bg-emerald-950/70 border-emerald-800 text-emerald-300';
    return 'bg-slate-900/80 border-slate-800 text-slate-400';
  };

  return (
    <div className="bg-[#0f172a]/90 border border-slate-800 rounded-xl p-4 shadow-lg">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h4 className="text-xs font-mono font-bold text-white tracking-wide uppercase flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5 text-blue-400" />
            Server Fleet Heatmap ({hosts.length} Hosts Monitored)
          </h4>
          <p className="text-[10px] text-slate-400 font-mono mt-0.5">
            Node Exporter resource heat matrix across all environments
          </p>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-emerald-600"></span> &lt;65%</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-amber-600"></span> 65-80%</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-orange-600"></span> 80-90%</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-rose-600"></span> &gt;90%</span>
        </div>
      </div>

      {hosts.length === 0 ? (
        <div className="text-xs text-slate-500 font-mono py-6 text-center">
          No active server node targets registered.
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
          {hosts.map((h) => {
            const val = metricType === 'cpu' ? h.cpu : metricType === 'memory' ? h.memory : h.disk;
            const isDown = h.status === 'DOWN';
            const cellClass = getCellBg(val, isDown);

            return (
              <div
                key={h.id}
                className={`p-2.5 rounded-lg border flex flex-col justify-between transition-all hover:scale-105 cursor-pointer shadow-sm ${cellClass}`}
                title={`Host: ${h.name}\nEnv: ${h.environment}\nCPU: ${h.cpu}%\nRAM: ${h.memory}%\nDisk: ${h.disk}%\nStatus: ${h.status}`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-[10px] font-mono font-bold truncate text-white">{h.name}</span>
                  {isDown ? (
                    <AlertOctagon className="w-3 h-3 text-rose-400 shrink-0" />
                  ) : val >= 80 ? (
                    <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
                  ) : (
                    <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                  )}
                </div>
                <div className="text-[9px] font-mono text-slate-400 truncate mb-1.5">{h.environment}</div>
                <div className="flex items-baseline justify-between mt-auto">
                  <span className="text-xs font-mono font-bold">{isDown ? 'DOWN' : `${val.toFixed(1)}%`}</span>
                  <span className="text-[8px] font-mono text-slate-400 uppercase">{metricType}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
