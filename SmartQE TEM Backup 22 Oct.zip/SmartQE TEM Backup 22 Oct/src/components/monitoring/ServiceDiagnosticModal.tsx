import React, { useState } from 'react';
import {
  X,
  Activity,
  Zap,
  RotateCcw,
  Clock,
  Cpu,
  Layers,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Copy,
  Check,
  Terminal,
  ExternalLink,
  ShieldCheck,
  Radio,
  RefreshCw,
  Server,
  Code2
} from 'lucide-react';

interface ServiceDiagnosticModalProps {
  service: any;
  isOpen: boolean;
  onClose: () => void;
  onRestartService?: (serviceName: string) => Promise<void>;
}

export const ServiceDiagnosticModal: React.FC<ServiceDiagnosticModalProps> = ({
  service,
  isOpen,
  onClose,
  onRestartService
}) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [isProbing, setIsProbing] = useState(false);
  const [isRestarting, setIsRestarting] = useState(false);
  const [showThreadDump, setShowThreadDump] = useState(false);
  const [probeResult, setProbeResult] = useState<{
    status: 'HEALTHY' | 'DEGRADED' | 'DOWN';
    httpStatus: number;
    latencyMs: number;
    timestamp: string;
    checks: { name: string; status: 'UP' | 'DOWN'; details?: string }[];
  } | null>(null);

  if (!isOpen || !service) return null;

  const isWarning = service.testReadinessImpact === 'READY_WITH_WARNINGS' || service.errorRate5xx > 2.0;
  const port = service.servicePort || '8080';
  const version = service.version || 'v1.0';
  const serviceName = service.serviceName || 'Application Service';

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2500);
  };

  const handleRunProbe = () => {
    setIsProbing(true);
    setProbeResult(null);

    setTimeout(() => {
      setIsProbing(false);
      const isOk = !isWarning;
      setProbeResult({
        status: isOk ? 'HEALTHY' : 'DEGRADED',
        httpStatus: isOk ? 200 : 200,
        latencyMs: Math.round(service.p50 * 0.8) || 18,
        timestamp: new Date().toLocaleTimeString(),
        checks: [
          { name: 'db_connection_pool', status: 'UP', details: 'Pool size: 20, Active: 4' },
          { name: 'disk_space', status: 'UP', details: 'Free: 45.2 GB' },
          { name: 'ping', status: 'UP', details: 'OK' },
          { name: 'redis_cache', status: 'UP', details: 'Hit ratio: 99.4%' },
          {
            name: 'circuit_breaker',
            status: isOk ? 'UP' : 'DOWN',
            details: isOk ? 'State: CLOSED (0% failure)' : 'State: HALF_OPEN (elevated latency)'
          }
        ]
      });
    }, 600);
  };

  const handleRestart = async () => {
    if (onRestartService) {
      setIsRestarting(true);
      try {
        await onRestartService(serviceName);
      } finally {
        setIsRestarting(false);
      }
    } else {
      setIsRestarting(true);
      setTimeout(() => {
        setIsRestarting(false);
        handleRunProbe();
      }, 1200);
    }
  };

  const curlHealthCmd = `curl -s -X GET http://127.0.0.1:${port}/actuator/health | jq .`;
  const curlMetricsCmd = `curl -s -X GET http://127.0.0.1:${port}/actuator/prometheus`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 font-mono">
      <div className="bg-[#0b111e] border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-[#0d1527]">
          <div className="flex items-center gap-3">
            <div
              className={`p-2.5 rounded-xl border ${
                isWarning
                  ? 'bg-amber-950/80 border-amber-800 text-amber-400'
                  : 'bg-indigo-950/80 border-indigo-800 text-indigo-400'
              }`}
            >
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white tracking-wide">{serviceName}</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  Port {port}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  {version}
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    isWarning
                      ? 'bg-amber-950 text-amber-300 border-amber-800'
                      : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  }`}
                >
                  {service.testReadinessImpact}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Runtime Diagnostic & Actuator Observability Console · Framework:{' '}
                <strong className="text-slate-200">Spring Boot Actuator / JMX</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 text-xs">
          {/* Action & Quick Probe Bar */}
          <div className="bg-gradient-to-r from-slate-900 via-[#0e1628] to-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-indigo-950/50 border border-indigo-800 text-indigo-400">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
                  Synthetic Actuator Endpoint
                </span>
                <span className="text-xs font-bold text-white font-mono">
                  GET http://127.0.0.1:{port}/actuator/health
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={handleRunProbe}
                disabled={isProbing}
                className="flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/20 transition-all disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isProbing ? 'animate-spin' : ''}`} />
                <span>{isProbing ? 'Probing...' : 'Ping / Probe Endpoint'}</span>
              </button>

              <button
                onClick={handleRestart}
                disabled={isRestarting}
                className="flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/70 border border-slate-700 hover:border-rose-800 text-slate-200 hover:text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all disabled:opacity-50"
                title="Trigger Autonomous Service Restart via Auto-Heal"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isRestarting ? 'animate-spin text-rose-400' : ''}`} />
                <span>{isRestarting ? 'Restarting...' : 'Restart Service'}</span>
              </button>
            </div>
          </div>

          {/* Real-Time Probe Execution Result */}
          {probeResult && (
            <div
              className={`p-4 rounded-xl border animate-in fade-in duration-200 space-y-3 ${
                probeResult.status === 'HEALTHY'
                  ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                  : 'bg-amber-950/30 border-amber-800 text-amber-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {probeResult.status === 'HEALTHY' ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                  )}
                  <strong className="text-sm font-bold text-white">
                    HTTP {probeResult.httpStatus} OK · Response Latency: {probeResult.latencyMs}ms
                  </strong>
                </div>
                <span className="text-[10px] text-slate-400">Timestamp: {probeResult.timestamp}</span>
              </div>

              {/* Sub-system checks from Actuator */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 border-t border-slate-800/80 text-[11px]">
                {probeResult.checks.map((chk, i) => (
                  <div key={i} className="bg-slate-900/60 p-2 rounded border border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-slate-300 font-bold block">{chk.name}</span>
                      {chk.details && <span className="text-[10px] text-slate-400">{chk.details}</span>}
                    </div>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        chk.status === 'UP'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}
                    >
                      {chk.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* JVM Memory Pools & Garbage Collection Deep-Dive */}
          <div className="bg-[#0d1420] border border-slate-800 rounded-xl p-4 space-y-4 shadow-lg">
            <h4 className="text-xs font-bold uppercase text-white flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-indigo-400" /> JVM Memory Pools & Garbage Collection (G1GC)
              </span>
              <span className="text-[10px] text-slate-500 font-normal">
                Max Heap Allocation: <strong className="text-slate-300">{service.jvmHeapMax || '8.0 GB'}</strong>
              </span>
            </h4>

            {/* Memory Pools Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {/* Eden Space */}
              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-slate-400 font-bold">Eden Space (Young)</span>
                  <span className="text-indigo-400 font-bold">78%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-500 rounded-full" style={{ width: '78%' }}></div>
                </div>
                <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                  <span>Used: 1.95 GB</span>
                  <span>Total: 2.50 GB</span>
                </div>
              </div>

              {/* Survivor Space */}
              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-slate-400 font-bold">Survivor Space</span>
                  <span className="text-emerald-400 font-bold">42%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: '42%' }}></div>
                </div>
                <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                  <span>Used: 215 MB</span>
                  <span>Total: 512 MB</span>
                </div>
              </div>

              {/* Old Generation (Tenured) */}
              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-slate-400 font-bold">Old Gen (Tenured)</span>
                  <span className={`font-bold ${service.jvmHeapPct > 80 ? 'text-amber-400' : 'text-blue-400'}`}>
                    {service.jvmHeapPct || 72}%
                  </span>
                </div>
                <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${service.jvmHeapPct > 80 ? 'bg-amber-500' : 'bg-blue-500'}`}
                    style={{ width: `${service.jvmHeapPct || 72}%` }}
                  ></div>
                </div>
                <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                  <span>Used: {service.jvmHeapUsed || '3.8 GB'}</span>
                  <span>Total: 5.00 GB</span>
                </div>
              </div>

              {/* Metaspace */}
              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1.5">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-slate-400 font-bold">Metaspace (Classes)</span>
                  <span className="text-teal-400 font-bold">64%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-teal-500 rounded-full" style={{ width: '64%' }}></div>
                </div>
                <div className="text-[10px] text-slate-500 flex justify-between pt-0.5">
                  <span>Used: 164 MB</span>
                  <span>Total: 256 MB</span>
                </div>
              </div>
            </div>

            {/* GC Stats & Thread Pool */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-800 text-[11px]">
              <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">GC PAUSE DURATION</span>
                <strong className="text-emerald-400 font-extrabold text-sm">{service.gcPauseMs || 24}ms</strong>
                <span className="text-[10px] text-slate-400 block mt-0.5">SLA Threshold: &lt;100ms</span>
              </div>

              <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">YOUNG GC FREQUENCY</span>
                <strong className="text-white font-extrabold text-sm">Every 42s</strong>
                <span className="text-[10px] text-slate-400 block mt-0.5">142 total collections</span>
              </div>

              <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">FULL GC PAUSES</span>
                <strong className="text-emerald-400 font-extrabold text-sm">0 (Zero)</strong>
                <span className="text-[10px] text-slate-400 block mt-0.5">Nominal tenured cycle</span>
              </div>

              <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">ACTIVE THREAD POOL</span>
                <strong className="text-indigo-400 font-extrabold text-sm">{service.activeThreads || 85} / 200</strong>
                <span className="text-[10px] text-slate-400 block mt-0.5">Worker threads (42.5%)</span>
              </div>
            </div>
          </div>

          {/* Active HTTP Routes & Status Codes */}
          <div className="bg-[#0d1420] border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
            <h4 className="text-xs font-bold uppercase text-white flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-orange-400" /> Key Actuator & API Route Health
              </span>
              <span className="text-[10px] text-slate-500 font-normal">Auto-polled via Prometheus</span>
            </h4>

            <div className="space-y-2">
              {[
                { path: `/actuator/health`, method: 'GET', status: 200, p95: `${service.p50}ms`, type: 'Liveness Probe' },
                { path: `/actuator/prometheus`, method: 'GET', status: 200, p95: `${Math.round(service.p50 * 1.2)}ms`, type: 'Metrics Exposition' },
                { path: `/api/v1/health`, method: 'GET', status: 200, p95: `${Math.round(service.p50 * 0.9)}ms`, type: 'Synthetic Probe' },
                { path: `/api/v1/data`, method: 'GET', status: isWarning ? 504 : 200, p95: `${service.p95}ms`, type: 'Application Workload' }
              ].map((route, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-lg flex items-center justify-between gap-3 font-mono"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                      {route.method}
                    </span>
                    <span className="text-white text-xs font-bold">{route.path}</span>
                    <span className="text-[10px] text-slate-500">· {route.type}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-slate-400">P95: <strong className="text-slate-200">{route.p95}</strong></span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        route.status === 200
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {route.status} {route.status === 200 ? 'OK' : 'ERR'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Diagnostic Commands & Thread Dump Snippet */}
          <div className="bg-[#0d1420] border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase text-white flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-emerald-400" /> CLI Validation & cURL Probes
              </h4>
              <button
                onClick={() => setShowThreadDump(!showThreadDump)}
                className="text-[10px] text-indigo-400 hover:text-indigo-300 underline font-bold"
              >
                {showThreadDump ? 'Hide Thread Dump' : 'View Thread Dump Sample'}
              </button>
            </div>

            <div className="space-y-2">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between gap-2">
                <div className="truncate font-mono text-[11px] text-slate-300">
                  <span className="text-emerald-400 mr-2">$</span>
                  {curlHealthCmd}
                </div>
                <button
                  onClick={() => handleCopy(curlHealthCmd, 'curl-health')}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors flex-shrink-0"
                  title="Copy cURL command"
                >
                  {copiedCmd === 'curl-health' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between gap-2">
                <div className="truncate font-mono text-[11px] text-slate-300">
                  <span className="text-emerald-400 mr-2">$</span>
                  {curlMetricsCmd}
                </div>
                <button
                  onClick={() => handleCopy(curlMetricsCmd, 'curl-metrics')}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors flex-shrink-0"
                  title="Copy cURL command"
                >
                  {copiedCmd === 'curl-metrics' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {showThreadDump && (
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/90 space-y-1 font-mono text-[10px] text-slate-400">
                <span className="text-slate-300 font-bold block">Thread Dump Summary: 85 runnable / 12 timed_waiting / 0 blocked</span>
                <p className="text-slate-500">
                  "http-nio-{port}-exec-12" #48 daemon prio=5 os_prio=0 tid=0x00007f9c nid=0x1a runnable [0x00007f9ca123b000]<br />
                  &nbsp;&nbsp;java.lang.Thread.State: RUNNABLE<br />
                  &nbsp;&nbsp;at org.apache.tomcat.util.net.SocketWrapperBase.doWrite(SocketWrapperBase.java:825)<br />
                  &nbsp;&nbsp;at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:1072)
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between p-4 border-t border-slate-800 bg-[#0d1527]">
          <span className="text-[11px] text-slate-500">
            For advanced metrics tracing, check <strong className="text-slate-400">PromQL Console</strong> or Grafana.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
