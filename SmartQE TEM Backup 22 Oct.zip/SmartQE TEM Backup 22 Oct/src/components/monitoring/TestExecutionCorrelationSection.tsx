import React, { useState } from 'react';
import { TestExecutionCorrelation } from '../../types/monitoring';
import { Bug, CheckCircle2, XCircle, AlertTriangle, ShieldAlert, Sparkles, Filter, Plus } from 'lucide-react';

interface TestExecutionCorrelationSectionProps {
  correlations: TestExecutionCorrelation[];
  selectedEnvironmentName?: string;
  onRecordTestRun?: (payload: Partial<TestExecutionCorrelation>) => void;
}

export const TestExecutionCorrelationSection: React.FC<TestExecutionCorrelationSectionProps> = ({
  correlations,
  selectedEnvironmentName,
  onRecordTestRun,
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'ENV_CAUSED' | 'FAILED' | 'PASSED'>('ALL');
  const [isSimulateModalOpen, setIsSimulateModalOpen] = useState(false);
  const [newSuiteName, setNewSuiteName] = useState('Payment Gateway Smoke Tests');
  const [newStatus, setNewStatus] = useState<'PASSED' | 'FAILED'>('FAILED');
  const [newFailedCount, setNewFailedCount] = useState(14);

  const filtered = correlations.filter((c) => {
    if (filterType === 'ENV_CAUSED') return c.is_environment_caused;
    if (filterType === 'FAILED') return c.status === 'FAILED';
    if (filterType === 'PASSED') return c.status === 'PASSED';
    return true;
  });

  const envCausedCount = correlations.filter((c) => c.is_environment_caused).length;

  const handleSubmitSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    if (onRecordTestRun) {
      onRecordTestRun({
        test_run_id: `TR-SIM-${Math.floor(Date.now() / 1000) % 100000}`,
        test_suite_name: newSuiteName,
        test_phase: 'SIT',
        status: newStatus,
        total_tests: 100,
        passed_tests: newStatus === 'PASSED' ? 100 : 100 - newFailedCount,
        failed_tests: newStatus === 'PASSED' ? 0 : newFailedCount,
        started_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
        completed_at: new Date().toISOString(),
      });
    }
    setIsSimulateModalOpen(false);
  };

  return (
    <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Bug className="w-4 h-4 text-orange-400" /> TEST EXECUTION & ENVIRONMENT CORRELATION ({correlations.length})
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Integrates TEM test execution timelines with environment telemetry to determine if test failures were caused by environment defects or functional code bugs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[#161f2e] border border-slate-700 rounded-lg p-0.5">
            {(['ALL', 'ENV_CAUSED', 'FAILED', 'PASSED'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setFilterType(st)}
                className={`px-2.5 py-1 rounded text-[10px] font-bold transition-colors ${
                  filterType === st ? 'bg-orange-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                {st === 'ENV_CAUSED' ? `ENV CAUSED (${envCausedCount})` : st}
              </button>
            ))}
          </div>

          <button
            onClick={() => setIsSimulateModalOpen(true)}
            className="px-3 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center gap-1 shadow-md shadow-orange-950/40"
          >
            <Plus className="w-3.5 h-3.5" /> Correlate Test Run
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-10 border border-dashed border-slate-800 rounded-xl space-y-2">
          <CheckCircle2 className="w-8 h-8 text-slate-600 mx-auto" />
          <p className="text-white font-bold text-sm">No Test Runs Matching Filter</p>
          <p className="text-slate-500 text-[11px]">Click 'Correlate Test Run' to evaluate test run against environment telemetry.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => {
            const isFailed = item.status === 'FAILED';
            const isEnvCaused = item.is_environment_caused;

            return (
              <div
                key={item.id}
                className={`p-4 rounded-xl border space-y-3 transition-all ${
                  isEnvCaused
                    ? 'bg-[#1e100a]/80 border-orange-800 shadow-md shadow-orange-950/20'
                    : isFailed
                    ? 'bg-rose-950/20 border-rose-900/60'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-black/60 border border-slate-700 text-slate-300">
                        {item.test_run_id}
                      </span>
                      <span className="text-xs font-extrabold text-white">{item.test_suite_name}</span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-800 text-slate-300 uppercase">
                        {item.test_phase}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-[10px] text-slate-400">
                      <span>Environment: <strong className="text-orange-400">{item.environment_name}</strong></span>
                      <span>Run Time: {item.started_at?.replace('T', ' ').substring(0, 16)}</span>
                      <span>Tests: <strong className="text-white">{item.passed_tests}</strong> passed / <strong className={item.failed_tests > 0 ? 'text-rose-400' : 'text-slate-400'}>{item.failed_tests}</strong> failed</span>
                      <span>Health at Execution: <strong className={item.environment_health_at_run >= 80 ? 'text-emerald-400' : 'text-amber-400'}>{item.environment_health_at_run}%</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`px-2.5 py-1 rounded text-[10px] font-bold ${
                        item.status === 'PASSED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {item.status}
                    </span>

                    {isEnvCaused ? (
                      <span className="px-2.5 py-1 rounded text-[10px] font-extrabold bg-orange-950 text-orange-300 border border-orange-700 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-orange-400" /> ENVIRONMENT DEFECT
                      </span>
                    ) : isFailed ? (
                      <span className="px-2.5 py-1 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                        FUNCTIONAL DEFECT
                      </span>
                    ) : null}
                  </div>
                </div>

                {/* Root Cause Diagnostic & Anomalies */}
                {item.failure_root_cause && (
                  <div
                    className={`p-3 rounded-lg border text-[11px] space-y-1.5 ${
                      isEnvCaused
                        ? 'bg-orange-950/30 border-orange-800/80 text-orange-200'
                        : 'bg-black/40 border-slate-800 text-slate-300'
                    }`}
                  >
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase block flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-orange-400" /> AUTOMATED TEST FAILURE ROOT CAUSE:
                    </span>
                    <p className="leading-relaxed">{item.failure_root_cause}</p>

                    {item.correlated_anomalies && item.correlated_anomalies.length > 0 && (
                      <div className="flex items-center gap-2 pt-1">
                        <span className="text-[10px] text-slate-400">Overlapping Anomalies:</span>
                        {item.correlated_anomalies.map((anom, idx) => (
                          <span key={idx} className="px-2 py-0.5 rounded bg-black/60 border border-orange-800/60 text-[10px] font-mono text-orange-300">
                            {anom.metric}: {anom.value}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Correlate Test Run Modal */}
      {isSimulateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-[#0f1724] border border-slate-700 rounded-xl p-5 max-w-md w-full space-y-4 shadow-2xl">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Bug className="w-4 h-4 text-orange-400" /> Correlate Test Run with Live Telemetry
            </h4>
            <p className="text-xs text-slate-400">
              Evaluates test execution failures against concurrent CPU, latency, error spikes, and active alerts.
            </p>

            <form onSubmit={handleSubmitSimulation} className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Test Suite Name</label>
                <input
                  type="text"
                  value={newSuiteName}
                  onChange={(e) => setNewSuiteName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Outcome Status</label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  >
                    <option value="FAILED">FAILED</option>
                    <option value="PASSED">PASSED</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Failed Tests Count</label>
                  <input
                    type="number"
                    value={newFailedCount}
                    onChange={(e) => setNewFailedCount(parseInt(e.target.value) || 0)}
                    disabled={newStatus === 'PASSED'}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white disabled:opacity-40"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSimulateModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded"
                >
                  Analyze & Correlate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
