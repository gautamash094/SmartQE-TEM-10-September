import React, { useState, useEffect } from 'react';
import { MonitoringTarget, MonitoringExporter } from '../../types/monitoring';
import { EnvironmentProfile } from '../../types/environmentDetails';
import { Server, Database, Radio, RefreshCw, Trash2, CheckCircle2, AlertTriangle, XCircle, Plus, ExternalLink, Activity } from 'lucide-react';

interface TargetsAndExportersSectionProps {
  targets: MonitoringTarget[];
  onTriggerScrape: (targetId?: string) => void;
  onRegisterTarget?: (payload: any) => void;
  onDeleteTarget?: (targetId: string) => void;
  isScraping?: boolean;
  selectedEnvId?: string;
  selectedEnvName?: string;
  environments?: EnvironmentProfile[];
}

export const TargetsAndExportersSection: React.FC<TargetsAndExportersSectionProps> = ({
  targets,
  onTriggerScrape,
  onRegisterTarget,
  onDeleteTarget,
  isScraping = false,
  selectedEnvId,
  selectedEnvName,
  environments = [],
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [targetName, setTargetName] = useState('');
  const [targetType, setTargetType] = useState('LINUX_SERVER');
  const [targetEnvId, setTargetEnvId] = useState(selectedEnvId || environments[0]?.id || '');
  const [endpointUrl, setEndpointUrl] = useState('');
  const [scrapeInterval, setScrapeInterval] = useState(15);

  useEffect(() => {
    if (selectedEnvId) {
      setTargetEnvId(selectedEnvId);
    }
  }, [selectedEnvId]);

  const filtered = targets.filter((t) => {
    if (filterType !== 'ALL' && t.target_type !== filterType) return false;
    return true;
  });

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onRegisterTarget && targetName) {
      const chosenEnvId = targetEnvId || selectedEnvId || environments[0]?.id || 'env-001';
      const chosenEnvName =
        environments.find((env) => env.id === chosenEnvId)?.name || selectedEnvName || 'Environment';

      onRegisterTarget({
        name: targetName,
        environment_id: chosenEnvId,
        environment_name: chosenEnvName,
        target_type: targetType,
        endpoint_url: endpointUrl || 'http://localhost:9100/metrics',
        scrape_interval_seconds: scrapeInterval,
        scrape_timeout_seconds: 5,
        is_enabled: true,
        exporters: [
          {
            name: `${targetName.toLowerCase().replace(/[^a-z0-9]/g, '_')}_exporter`,
            exporter_type:
              targetType === 'LINUX_SERVER'
                ? 'NODE_EXPORTER'
                : targetType === 'DATABASE'
                ? 'DATABASE_EXPORTER'
                : 'API_EXPORTER',
            endpoint_url: endpointUrl || 'http://localhost:9100/metrics',
          },
        ],
      });
    }
    setIsRegisterModalOpen(false);
    setTargetName('');
    setEndpointUrl('');
  };

  return (
    <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Radio className="w-4 h-4 text-orange-400" /> MONITORING TARGETS & EXPORTERS ENGINE ({targets.length})
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Standardized pull-based scraping framework. Explicitly isolates <span className="text-emerald-400 font-bold">TARGET DOWN</span> vs <span className="text-amber-400 font-bold">EXPORTER DOWN</span> vs <span className="text-rose-400 font-bold">SCRAPING FAILURE</span>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onTriggerScrape()}
            disabled={isScraping}
            className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 border border-slate-700 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-orange-400 ${isScraping ? 'animate-spin' : ''}`} />
            <span>PULL SCRAPE ALL</span>
          </button>

          <button
            onClick={() => setIsRegisterModalOpen(true)}
            className="px-3.5 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-orange-950/40"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>ADD TARGET</span>
          </button>
        </div>
      </div>

      {/* Target Type Filter */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {(['ALL', 'LINUX_SERVER', 'APPLICATION', 'DATABASE', 'REST_API', 'CONTAINER'] as const).map((type) => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-2.5 py-1 rounded text-[10px] font-bold transition-colors whitespace-nowrap ${
              filterType === type ? 'bg-orange-600 text-white shadow-sm' : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {type.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Targets Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase font-bold bg-slate-950/40">
              <th className="py-2.5 px-3">Target Name & Environment</th>
              <th className="py-2.5 px-3">Type</th>
              <th className="py-2.5 px-3">Scrape Endpoint</th>
              <th className="py-2.5 px-3">Interval / Freshness</th>
              <th className="py-2.5 px-3">Target Health</th>
              <th className="py-2.5 px-3">Exporter Status</th>
              <th className="py-2.5 px-3">Scrape Status</th>
              <th className="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-[11px]">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500 italic">
                  No monitoring targets registered. Click 'Add Target' to configure a scrape target.
                </td>
              </tr>
            ) : (
              filtered.map((t) => {
                const isTargetUp = t.target_status === 'UP';
                const isScrapeOk = t.scrape_status === 'SUCCESS';
                const exporter = t.exporters?.[0];
                const isExporterUp = exporter?.status === 'EXPORTER_UP';

                return (
                  <tr key={t.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-bold text-white">{t.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{t.environment_name}</div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-slate-300">
                        {t.target_type}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-[10px] text-slate-400 max-w-xs truncate" title={t.endpoint_url}>
                      {t.endpoint_url}
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-white font-bold">{t.scrape_interval_seconds}s</div>
                      <div className="text-[10px] text-slate-500">
                        {t.is_stale ? (
                          <span className="text-rose-400 font-bold">STALE ({t.metrics_freshness_seconds}s)</span>
                        ) : (
                          <span className="text-emerald-400">{t.metrics_freshness_seconds}s ago</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                          isTargetUp
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-rose-950 text-rose-300 border border-rose-800 animate-pulse'
                        }`}
                      >
                        {isTargetUp ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <XCircle className="w-3 h-3 text-rose-400" />}
                        {t.target_status}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                          isExporterUp
                            ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800'
                            : 'bg-amber-950/80 text-amber-300 border border-amber-800'
                        }`}
                      >
                        {isExporterUp ? 'EXPORTER UP' : 'EXPORTER DOWN'}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="space-y-0.5">
                        <span
                          className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                            isScrapeOk
                              ? 'bg-emerald-950 text-emerald-300'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {t.scrape_status}
                        </span>
                        <div className="text-[9px] text-slate-500">{t.scrape_duration_ms}ms</div>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onTriggerScrape(t.id)}
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                          title="Trigger Scrape Now"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                        {onDeleteTarget && (
                          <button
                            onClick={() => onDeleteTarget(t.id)}
                            className="p-1 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400"
                            title="Delete Target"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Register Target Modal */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-[#0f1724] border border-slate-700 rounded-xl p-5 max-w-md w-full space-y-4 shadow-2xl">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-orange-400" /> Register Dynamic Monitoring Target
            </h4>

            <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Target Name</label>
                <input
                  type="text"
                  value={targetName}
                  onChange={(e) => setTargetName(e.target.value)}
                  placeholder="e.g. Payment Gateway Microservice Node"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Target Environment</label>
                <select
                  value={targetEnvId}
                  onChange={(e) => setTargetEnvId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                >
                  {environments && environments.length > 0 ? (
                    environments.map((env) => (
                      <option key={env.id} value={env.id}>
                        {env.name} ({env.type})
                      </option>
                    ))
                  ) : (
                    <option value={selectedEnvId || 'env-001'}>{selectedEnvName || 'Active Environment'}</option>
                  )}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Target Type</label>
                  <select
                    value={targetType}
                    onChange={(e) => setTargetType(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  >
                    <option value="LINUX_SERVER">Linux Server</option>
                    <option value="APPLICATION">Application Server</option>
                    <option value="DATABASE">Database</option>
                    <option value="REST_API">REST API Endpoint</option>
                    <option value="CONTAINER">Container Node</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Scrape Interval (sec)</label>
                  <input
                    type="number"
                    value={scrapeInterval}
                    onChange={(e) => setScrapeInterval(parseInt(e.target.value) || 15)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                    min={5}
                    max={300}
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Exporter Metrics Endpoint URL</label>
                <input
                  type="text"
                  value={endpointUrl}
                  onChange={(e) => setEndpointUrl(e.target.value)}
                  placeholder="http://host:9100/metrics or /actuator/prometheus"
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-white font-mono text-[11px]"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRegisterModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded"
                >
                  Register Target
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
