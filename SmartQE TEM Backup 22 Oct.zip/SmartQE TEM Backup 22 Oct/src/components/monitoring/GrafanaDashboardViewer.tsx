import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  ExternalLink,
  Maximize2,
  Minimize2,
  RefreshCw,
  Settings,
  Sliders,
  Layers,
  Server,
  Activity,
  Database,
  Bug,
  Globe,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { GrafanaDashboard, GrafanaConfig } from '../../types/monitoring';
import { monitoringService } from '../../services/monitoringService';
import {
  RadialStatGauge,
  TimeSeriesAreaGraph,
  HttpStatusDistribution,
  ServerHeatmapMatrix
} from './GrafanaPanels';

interface GrafanaDashboardViewerProps {
  selectedEnvId?: string;
  selectedEnvName?: string;
  currentTelemetry?: any;
  fleetSummary?: any;
  serverNodes?: any[];
}

export const GrafanaDashboardViewer: React.FC<GrafanaDashboardViewerProps> = ({
  selectedEnvId,
  selectedEnvName = 'All Environments',
  currentTelemetry,
  fleetSummary,
  serverNodes = [],
}) => {
  const [dashboards, setDashboards] = useState<GrafanaDashboard[]>([]);
  const [selectedDashboard, setSelectedDashboard] = useState<GrafanaDashboard | null>(null);
  const [grafanaConfig, setGrafanaConfig] = useState<GrafanaConfig | null>(null);
  const [viewMode, setViewMode] = useState<'NATIVE' | 'EMBEDDED'>('NATIVE');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [timeRange, setTimeRange] = useState('1h');
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [configUrl, setConfigUrl] = useState('http://localhost:3000');
  const [configTheme, setConfigTheme] = useState('dark');
  const [configKiosk, setConfigKiosk] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [heatmapMetric, setHeatmapMetric] = useState<'cpu' | 'memory' | 'disk'>('cpu');

  useEffect(() => {
    loadDashboardsAndConfig();
  }, [selectedEnvId, selectedEnvName]);

  const loadDashboardsAndConfig = async () => {
    setIsLoading(true);
    try {
      const [dashList, cfg] = await Promise.all([
        monitoringService.getGrafanaDashboards(selectedEnvId, selectedEnvName),
        monitoringService.getGrafanaConfig(),
      ]);
      setDashboards(dashList);
      if (dashList.length > 0 && !selectedDashboard) {
        setSelectedDashboard(dashList[0]);
      }
      if (cfg) {
        setGrafanaConfig(cfg);
        setConfigUrl(cfg.server_url);
        setConfigTheme(cfg.default_theme);
        setConfigKiosk(cfg.kiosk_mode);
      }
    } catch (err) {
      console.warn('Failed to load Grafana data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveConfig = async () => {
    const updated = await monitoringService.updateGrafanaConfig({
      server_url: configUrl,
      default_theme: configTheme,
      kiosk_mode: configKiosk,
    });
    if (updated) {
      setGrafanaConfig(updated);
      setIsConfigOpen(false);
      loadDashboardsAndConfig();
    }
  };

  // Build simulated time series trend curves from current readings
  const cpuCurrent = currentTelemetry?.cpuUsage?.current || 42.5;
  const memCurrent = currentTelemetry?.memoryUsage?.current || 56.0;
  const diskCurrent = currentTelemetry?.diskUsage?.current || 48.0;
  const latCurrent = currentTelemetry?.networkLatency?.current || 24.5;

  const generateTimeSeriesData = (baseVal: number, pointsCount = 20) => {
    return Array.from({ length: pointsCount }, (_, i) => {
      const minsAgo = (pointsCount - 1 - i) * 3;
      const tStr = minsAgo === 0 ? 'now' : `-${minsAgo}m`;
      const val = Math.max(5.0, Math.min(98.0, baseVal + Math.sin(i / 2.5) * 6.5 + (i % 2 === 0 ? 1.5 : -1.5)));
      return { time: tStr, value: round1(val) };
    });
  };

  const round1 = (v: number) => Math.round(v * 10) / 10;

  const cpuData = generateTimeSeriesData(cpuCurrent);
  const memData = generateTimeSeriesData(memCurrent);
  const diskData = generateTimeSeriesData(diskCurrent);
  const latData = generateTimeSeriesData(latCurrent);

  // Map server nodes for heatmap
  const heatmapHosts = (serverNodes || []).map((srv: any) => ({
    id: srv.id || srv.hostName,
    name: srv.hostName || srv.name || 'srv-host',
    environment: srv.environmentName || selectedEnvName,
    cpu: srv.cpuUsagePct || 42.0,
    memory: srv.memoryUsagePct || 54.0,
    disk: srv.diskUsagePct || 46.0,
    status: (srv.status === 'RUNNING' || srv.status === 'UP' ? 'UP' : srv.status === 'DOWN' ? 'DOWN' : 'DEGRADED') as 'UP' | 'DOWN' | 'DEGRADED',
  }));

  const categoryIcons: Record<string, any> = {
    ENTERPRISE: Layers,
    ENVIRONMENT: Activity,
    SERVER: Server,
    APPLICATION: Globe,
    DATABASE: Database,
    TEST_CORRELATION: Bug,
  };

  return (
    <div className={`space-y-6 ${isFullscreen ? 'fixed inset-0 z-50 bg-[#0b1120] p-6 overflow-y-auto' : ''}`}>
      {/* Top Controller Bar */}
      <div className="bg-[#0f172a]/95 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Left: Dashboard Selector & View Mode */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <LayoutDashboard className="w-5 h-5 text-orange-400" />
            <span className="text-sm font-mono font-bold text-white tracking-tight">GRAFANA DASHBOARDS</span>
          </div>

          <div className="h-5 w-px bg-slate-800 hidden sm:block"></div>

          {/* Mode Switcher */}
          <div className="flex items-center bg-[#161f2e] border border-slate-700/80 rounded-lg p-0.5 text-xs font-mono">
            <button
              onClick={() => setViewMode('NATIVE')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all ${
                viewMode === 'NATIVE'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Native Grafana Panels
            </button>
            <button
              onClick={() => setViewMode('EMBEDDED')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 ${
                viewMode === 'EMBEDDED'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ExternalLink className="w-3 h-3" />
              Embedded Iframe
            </button>
          </div>
        </div>

        {/* Right: Controls & Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Time Range Selector */}
          <div className="flex items-center gap-1.5 bg-[#161f2e] border border-slate-700/80 rounded-lg px-2.5 py-1 text-xs font-mono">
            <span className="text-[10px] text-slate-400 font-bold uppercase">WINDOW:</span>
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="bg-transparent text-white font-bold text-xs focus:outline-none cursor-pointer"
            >
              <option value="15m" className="bg-slate-900">Last 15m</option>
              <option value="1h" className="bg-slate-900">Last 1h</option>
              <option value="6h" className="bg-slate-900">Last 6h</option>
              <option value="24h" className="bg-slate-900">Last 24h</option>
              <option value="7d" className="bg-slate-900">Last 7d</option>
            </select>
          </div>

          {/* Refresh Button */}
          <button
            onClick={() => loadDashboardsAndConfig()}
            disabled={isLoading}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors shadow-sm"
            title="Refresh Dashboards"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-orange-400 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          {/* Config Settings Button */}
          <button
            onClick={() => setIsConfigOpen(!isConfigOpen)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-mono font-bold text-slate-300 transition-colors shadow-sm"
          >
            <Settings className="w-3.5 h-3.5 text-slate-400" />
            <span>GRAFANA HOST</span>
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors shadow-sm"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Grafana Server Configuration Modal / Drawer */}
      {isConfigOpen && (
        <div className="bg-[#161f2e] border border-orange-500/40 rounded-xl p-4 shadow-2xl space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
            <h4 className="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
              <Settings className="w-4 h-4 text-orange-400" />
              Grafana Server Integration & Embedding Parameters
            </h4>
            <button
              onClick={() => setIsConfigOpen(false)}
              className="text-slate-400 hover:text-white text-xs font-mono"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
            <div>
              <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                Grafana Server URL
              </label>
              <input
                type="text"
                value={configUrl}
                onChange={(e) => setConfigUrl(e.target.value)}
                placeholder="http://localhost:3000"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:border-orange-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                Default Theme
              </label>
              <select
                value={configTheme}
                onChange={(e) => setConfigTheme(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:border-orange-500 focus:outline-none"
              >
                <option value="dark">Dark Theme (Recommended)</option>
                <option value="light">Light Theme</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                Kiosk Embedding Mode
              </label>
              <select
                value={configKiosk ? 'true' : 'false'}
                onChange={(e) => setConfigKiosk(e.target.value === 'true')}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:border-orange-500 focus:outline-none"
              >
                <option value="true">Enabled (Hides Grafana Sidebar/Navbar)</option>
                <option value="false">Disabled (Full UI)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <span className="text-[10px] text-slate-400">
              Ensure <code className="text-orange-400">allow_embedding = true</code> is set in your Grafana <code className="text-orange-400">grafana.ini</code> configuration.
            </span>
            <button
              onClick={handleSaveConfig}
              className="px-4 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-xs font-mono font-bold text-white transition-colors shadow-md"
            >
              SAVE CONFIGURATION
            </button>
          </div>
        </div>
      )}

      {/* Dashboard Preset Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-800">
        {dashboards.map((dash) => {
          const Icon = categoryIcons[dash.category] || LayoutDashboard;
          const isSelected = selectedDashboard?.id === dash.id;

          return (
            <button
              key={dash.id}
              onClick={() => setSelectedDashboard(dash)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-mono font-bold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-slate-800 text-white border border-orange-500/50 shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40 border border-transparent'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-orange-400' : 'text-slate-500'}`} />
              <span>{dash.title}</span>
            </button>
          );
        })}
      </div>

      {/* VIEW MODE: EMBEDDED GRAFANA IFRAME */}
      {viewMode === 'EMBEDDED' ? (
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden shadow-2xl relative min-h-[640px] flex flex-col">
          {/* Iframe Header */}
          <div className="bg-[#161f2e] border-b border-slate-800 px-4 py-2.5 flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-white font-bold">{selectedDashboard?.title}</span>
              <span className="text-slate-500">|</span>
              <span className="text-slate-400">Environment: <strong className="text-orange-400">{selectedEnvName}</strong></span>
            </div>
            {selectedDashboard?.external_url && (
              <a
                href={selectedDashboard.external_url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-xs text-orange-400 hover:text-orange-300 font-mono font-bold"
              >
                <span>OPEN IN GRAFANA</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>

          {/* Responsive Embedded Iframe */}
          <div className="flex-1 w-full bg-[#0b1120] relative min-h-[600px]">
            <iframe
              src={selectedDashboard?.embed_url}
              title={selectedDashboard?.title || 'Grafana Dashboard'}
              className="w-full h-full min-h-[600px] border-0"
              allow="fullscreen"
            />
          </div>
        </div>
      ) : (
        /* VIEW MODE: NATIVE GRAFANA-STYLE VISUAL PANELS */
        <div className="space-y-6">
          {/* Tier 1: Circular Multi-Threshold Stat Gauges */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <RadialStatGauge
              label="CPU Saturation Rate"
              value={cpuCurrent}
              warningThreshold={75}
              criticalThreshold={90}
              subtext="8 Cores Allocated"
            />
            <RadialStatGauge
              label="JVM / Memory Saturation"
              value={memCurrent}
              warningThreshold={78}
              criticalThreshold={92}
              subtext="32 GB Committed"
            />
            <RadialStatGauge
              label="Disk Storage Fill"
              value={diskCurrent}
              warningThreshold={80}
              criticalThreshold={90}
              subtext="/data Ext4 Partition"
            />
            <RadialStatGauge
              label="DB Connection Pool"
              value={currentTelemetry?.databasePool?.current || 38.5}
              warningThreshold={75}
              criticalThreshold={88}
              subtext="100 Max Conns"
            />
          </div>

          {/* Tier 2: Stacked Time-Series Area Graphs */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <TimeSeriesAreaGraph
              title="Host CPU Utilization Trend"
              subtitle="Prometheus node_cpu_seconds_total exposition"
              data={cpuData}
              color="emerald"
              unit="%"
              currentValue={cpuCurrent}
            />
            <TimeSeriesAreaGraph
              title="Memory Utilization Curve"
              subtitle="Prometheus node_memory_MemAvailable_bytes"
              data={memData}
              color="blue"
              unit="%"
              currentValue={memCurrent}
            />
            <TimeSeriesAreaGraph
              title="API Gateway P95 Latency"
              subtitle="Prometheus http_server_requests_seconds_sum"
              data={latData}
              color="amber"
              unit="ms"
              currentValue={latCurrent}
            />
            <TimeSeriesAreaGraph
              title="Persistent Storage Volume"
              subtitle="Prometheus node_filesystem_size_bytes"
              data={diskData}
              color="purple"
              unit="%"
              currentValue={diskCurrent}
            />
          </div>

          {/* Tier 3: HTTP Status Code Breakdown & Throughput */}
          <HttpStatusDistribution
            status2xx={95.2}
            status3xx={1.8}
            status4xx={2.4}
            status5xx={0.6}
            totalThroughputRps={1420}
          />

          {/* Tier 4: Server Fleet Heatmap Matrix */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-slate-400 uppercase">
                FLEET HEATMAP METRIC:
              </span>
              <div className="flex items-center gap-1 bg-[#161f2e] border border-slate-800 rounded-lg p-0.5 text-xs font-mono">
                {(['cpu', 'memory', 'disk'] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => setHeatmapMetric(m)}
                    className={`px-2.5 py-1 rounded uppercase font-bold text-[10px] transition-all ${
                      heatmapMetric === m ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
            <ServerHeatmapMatrix hosts={heatmapHosts} metricType={heatmapMetric} />
          </div>
        </div>
      )}
    </div>
  );
};
