import React, { useState } from 'react';
import {
  X,
  Server,
  Cpu,
  HardDrive,
  Activity,
  Radio,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Copy,
  Check,
  Terminal,
  RefreshCw,
  ExternalLink,
  ShieldAlert,
  Info
} from 'lucide-react';

interface NodeDiagnosticModalProps {
  node: any;
  isOpen: boolean;
  onClose: () => void;
  onScrape?: (targetId?: string) => Promise<void>;
}

export const NodeDiagnosticModal: React.FC<NodeDiagnosticModalProps> = ({
  node,
  isOpen,
  onClose,
  onScrape
}) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [isProbing, setIsProbing] = useState(false);
  const [probeResult, setProbeResult] = useState<{
    status: 'SUCCESS' | 'EXPORTER_DOWN' | 'TARGET_DOWN';
    latencyMs: number;
    message: string;
  } | null>(null);
  const [isScrapingLocal, setIsScrapingLocal] = useState(false);

  if (!isOpen || !node) return null;

  const isWindows = /windows/i.test(node.role || '') || /windows/i.test(node.operatingSystem || '');
  const exporterPort = isWindows ? 9182 : 9100;
  const exporterName = isWindows ? 'windows_exporter' : 'node_exporter';
  const defaultCores = node.cpuCores || (isWindows ? 8 : 4);
  const totalRamGb = parseFloat(node.memTotal) || node.ramGb || 32;
  const totalStorageGb = node.storageGb || 500;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2500);
  };

  const handleRunProbe = () => {
    setIsProbing(true);
    setProbeResult(null);
    setTimeout(() => {
      setIsProbing(false);
      if (node.exporterStatus === 'UP' && node.isOnline) {
        setProbeResult({
          status: 'SUCCESS',
          latencyMs: node.scrapeLatencyMs || 18,
          message: `TCP handshake to ${node.ip}:${exporterPort} successful. HTTP 200 OK received with standard OpenMetrics exposition.`
        });
      } else if (node.isOnline) {
        setProbeResult({
          status: 'EXPORTER_DOWN',
          latencyMs: 34,
          message: `Host at ${node.ip} is reachable via ICMP/TCP ping, but port ${exporterPort} (${exporterName}) refused connection. The exporter process is stopped or blocked by firewall.`
        });
      } else {
        setProbeResult({
          status: 'TARGET_DOWN',
          latencyMs: 0,
          message: `Host ${node.ip} is unreachable. Network gateway timed out after 3000ms. Check host power state and VPC routing.`
        });
      }
    }, 750);
  };

  const handleQuickScrape = async () => {
    if (!onScrape) return;
    setIsScrapingLocal(true);
    try {
      await onScrape(node.targetId || node.id);
    } finally {
      setIsScrapingLocal(false);
    }
  };

  const windowsInstallCmd = `msiexec /i https://github.com/prometheus-community/windows_exporter/releases/download/v0.25.1/windows_exporter-0.25.1-amd64.msi LISTEN_PORT=${exporterPort} ENABLED_COLLECTORS="cpu,cs,logical_disk,net,os,system"`;
  const windowsCheckServiceCmd = `Get-Service -Name windows_exporter | Select-Object Status, StartType, DisplayName`;
  const windowsCurlTestCmd = `curl.exe http://${node.ip}:${exporterPort}/metrics`;

  const linuxInstallCmd = `wget https://github.com/prometheus/node_exporter/releases/download/v1.7.0/node_exporter-1.7.0.linux-amd64.tar.gz && tar xvf node_exporter-*.tar.gz && sudo mv node_exporter-*/node_exporter /usr/local/bin/`;
  const linuxSystemdCmd = `sudo systemctl status node_exporter --no-pager`;
  const linuxCurlTestCmd = `curl -s http://${node.ip}:${exporterPort}/metrics | head -n 20`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0b111e] border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-[#0d1527]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-950/80 border border-blue-800 text-blue-400">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white tracking-wide">{node.nodeName}</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  {node.ip}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-950 text-blue-300 border border-blue-800">
                  {isWindows ? 'Windows Server' : 'Linux Host'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{node.role}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {/* Hardware Specifications Grid */}
          <div>
            <h4 className="text-xs font-mono font-bold uppercase text-slate-400 mb-2.5 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-orange-400" /> Host Hardware Specifications
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#0f172a] border border-slate-800/80 p-3 rounded-xl">
                <span className="text-[10px] text-slate-500 uppercase font-bold block flex items-center gap-1">
                  <Cpu className="w-3 h-3 text-blue-400" /> CPU Allocation
                </span>
                <span className="text-base font-extrabold text-white block mt-0.5">
                  {defaultCores} vCPUs
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {node.cpu}% Saturation
                </span>
              </div>

              <div className="bg-[#0f172a] border border-slate-800/80 p-3 rounded-xl">
                <span className="text-[10px] text-slate-500 uppercase font-bold block flex items-center gap-1">
                  <HardDrive className="w-3 h-3 text-amber-400" /> Physical RAM
                </span>
                <span className="text-base font-extrabold text-white block mt-0.5">
                  {totalRamGb.toFixed(1)} GB
                </span>
                <span className="text-[10px] text-amber-400 font-mono">
                  {node.memPct}% Utilized
                </span>
              </div>

              <div className="bg-[#0f172a] border border-slate-800/80 p-3 rounded-xl">
                <span className="text-[10px] text-slate-500 uppercase font-bold block flex items-center gap-1">
                  <HardDrive className="w-3 h-3 text-emerald-400" /> Total Storage
                </span>
                <span className="text-base font-extrabold text-white block mt-0.5">
                  {totalStorageGb} GB NVMe
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {node.diskRoot} Used
                </span>
              </div>

              <div className="bg-[#0f172a] border border-slate-800/80 p-3 rounded-xl">
                <span className="text-[10px] text-slate-500 uppercase font-bold block flex items-center gap-1">
                  <Radio className="w-3 h-3 text-purple-400" /> Exporter Port
                </span>
                <span className="text-base font-extrabold text-white block mt-0.5">
                  :{exporterPort}
                </span>
                <span
                  className={`text-[10px] font-bold ${
                    node.exporterStatus === 'UP' ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {node.exporterStatus === 'UP' ? 'PORT LISTENING' : 'PORT UNREACHABLE'}
                </span>
              </div>
            </div>
          </div>

          {/* Disk Partition Breakdown Table */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5 text-blue-400" /> Filesystem & Drive Volumes
              </span>
              <span className="text-[10px] text-slate-500 lowercase font-normal">
                {isWindows ? 'NTFS logical volumes' : 'POSIX mounted filesystems'}
              </span>
            </h4>

            <div className="space-y-2 text-xs">
              {isWindows ? (
                <>
                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <strong className="text-white font-mono">C:\ (System Volume)</strong>
                      <span className="text-[10px] text-slate-500 block">Windows OS & Core System Binaries</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-white font-mono">{node.diskRoot}</span>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        {Math.round((parseInt(node.diskRoot) / 100) * 150)} GB / 150 GB
                      </span>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <strong className="text-white font-mono">D:\ (Data & Apps)</strong>
                      <span className="text-[10px] text-slate-500 block">Application Workspace & Deployments</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-white font-mono">{node.diskData}</span>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        {Math.round((parseInt(node.diskData) / 100) * (totalStorageGb - 150))} GB / {totalStorageGb - 150} GB
                      </span>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <strong className="text-white font-mono">/ (Root Partition)</strong>
                      <span className="text-[10px] text-slate-500 block">Linux ext4 system hierarchy</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-white font-mono">{node.diskRoot}</span>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        {Math.round((parseInt(node.diskRoot) / 100) * 100)} GB / 100 GB
                      </span>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <strong className="text-white font-mono">/data (Persistent Storage)</strong>
                      <span className="text-[10px] text-slate-500 block">Database & logs directory</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-white font-mono">{node.diskData}</span>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        {Math.round((parseInt(node.diskData) / 100) * (totalStorageGb - 100))} GB / {totalStorageGb - 100} GB
                      </span>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Live Exporter Diagnostics & Test Probe */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
              <div>
                <h4 className="text-xs font-mono font-bold uppercase text-white flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-emerald-400" /> Live Exporter Connectivity Probe
                </h4>
                <p className="text-[11px] text-slate-400">
                  Target: <code className="text-orange-400">http://{node.ip}:{exporterPort}/metrics</code>
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRunProbe}
                  disabled={isProbing}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-mono font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <Activity className={`w-3.5 h-3.5 ${isProbing ? 'animate-spin' : ''}`} />
                  <span>{isProbing ? 'Probing...' : 'Run Port Probe'}</span>
                </button>

                {onScrape && (
                  <button
                    onClick={handleQuickScrape}
                    disabled={isScrapingLocal}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-mono font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isScrapingLocal ? 'animate-spin' : ''}`} />
                    <span>Scrape Telemetry</span>
                  </button>
                )}
              </div>
            </div>

            {probeResult && (
              <div
                className={`p-3 rounded-lg border text-xs font-mono flex items-start gap-2.5 animate-in fade-in duration-150 ${
                  probeResult.status === 'SUCCESS'
                    ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                    : probeResult.status === 'EXPORTER_DOWN'
                    ? 'bg-amber-950/60 border-amber-800 text-amber-300'
                    : 'bg-rose-950/60 border-rose-800 text-rose-300'
                }`}
              >
                {probeResult.status === 'SUCCESS' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                ) : probeResult.status === 'EXPORTER_DOWN' ? (
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <strong className="uppercase">Result: {probeResult.status.replace(/_/g, ' ')}</strong>
                    {probeResult.latencyMs > 0 && (
                      <span className="text-[10px] opacity-80">({probeResult.latencyMs}ms)</span>
                    )}
                  </div>
                  <p className="text-[11px] leading-relaxed">{probeResult.message}</p>
                </div>
              </div>
            )}
          </div>

          {/* Exporter Troubleshooting Helper (Shown especially when DOWN) */}
          <div className="bg-[#10192e] border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center gap-2 text-white">
              <Terminal className="w-4 h-4 text-orange-400" />
              <h4 className="text-xs font-mono font-bold uppercase">
                {isWindows ? 'Windows Exporter Configuration & Setup' : 'Linux Node Exporter Setup Guide'}
              </h4>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                Port {exporterPort}
              </span>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              If the status indicates <strong className="text-rose-400">EXPORTER DOWN</strong>, ensure the exporter agent is running on{' '}
              <span className="text-white font-mono">{node.ip}</span> and listening on port{' '}
              <span className="text-white font-mono">{exporterPort}</span>:
            </p>

            <div className="space-y-2">
              {isWindows ? (
                <>
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">
                      1. Check Windows Service status via PowerShell:
                    </span>
                    <div className="bg-black/60 border border-slate-800 rounded-lg p-2 font-mono text-[11px] text-emerald-400 flex items-center justify-between">
                      <code className="truncate">{windowsCheckServiceCmd}</code>
                      <button
                        onClick={() => handleCopy(windowsCheckServiceCmd, 'win_svc')}
                        className="ml-2 text-slate-400 hover:text-white p-1 rounded"
                        title="Copy PowerShell Command"
                      >
                        {copiedCmd === 'win_svc' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">
                      2. Install or start Windows Exporter MSI:
                    </span>
                    <div className="bg-black/60 border border-slate-800 rounded-lg p-2 font-mono text-[11px] text-emerald-400 flex items-center justify-between">
                      <code className="truncate">{windowsInstallCmd}</code>
                      <button
                        onClick={() => handleCopy(windowsInstallCmd, 'win_inst')}
                        className="ml-2 text-slate-400 hover:text-white p-1 rounded"
                        title="Copy Install Command"
                      >
                        {copiedCmd === 'win_inst' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">
                      3. Verify metrics endpoint locally on {node.ip}:
                    </span>
                    <div className="bg-black/60 border border-slate-800 rounded-lg p-2 font-mono text-[11px] text-cyan-300 flex items-center justify-between">
                      <code className="truncate">{windowsCurlTestCmd}</code>
                      <button
                        onClick={() => handleCopy(windowsCurlTestCmd, 'win_curl')}
                        className="ml-2 text-slate-400 hover:text-white p-1 rounded"
                        title="Copy cURL Command"
                      >
                        {copiedCmd === 'win_curl' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">
                      1. Check systemd service status:
                    </span>
                    <div className="bg-black/60 border border-slate-800 rounded-lg p-2 font-mono text-[11px] text-emerald-400 flex items-center justify-between">
                      <code className="truncate">{linuxSystemdCmd}</code>
                      <button
                        onClick={() => handleCopy(linuxSystemdCmd, 'lin_svc')}
                        className="ml-2 text-slate-400 hover:text-white p-1 rounded"
                        title="Copy Systemd Command"
                      >
                        {copiedCmd === 'lin_svc' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">
                      2. Install Node Exporter binary:
                    </span>
                    <div className="bg-black/60 border border-slate-800 rounded-lg p-2 font-mono text-[11px] text-emerald-400 flex items-center justify-between">
                      <code className="truncate">{linuxInstallCmd}</code>
                      <button
                        onClick={() => handleCopy(linuxInstallCmd, 'lin_inst')}
                        className="ml-2 text-slate-400 hover:text-white p-1 rounded"
                        title="Copy Install Command"
                      >
                        {copiedCmd === 'lin_inst' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">
                      3. Test exposition response:
                    </span>
                    <div className="bg-black/60 border border-slate-800 rounded-lg p-2 font-mono text-[11px] text-cyan-300 flex items-center justify-between">
                      <code className="truncate">{linuxCurlTestCmd}</code>
                      <button
                        onClick={() => handleCopy(linuxCurlTestCmd, 'lin_curl')}
                        className="ml-2 text-slate-400 hover:text-white p-1 rounded"
                        title="Copy cURL Command"
                      >
                        {copiedCmd === 'lin_curl' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#0d1527] flex items-center justify-between">
          <div className="text-[11px] text-slate-500 font-mono">
            Error Isolation: <strong className="text-slate-300">{node.errorIsolation}</strong>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors"
          >
            Close Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
};
