import React, { useState } from 'react';
import { CorrelatedIncident, AlertSeverity } from '../../types/monitoring';
import { ShieldAlert, AlertTriangle, CheckCircle2, Zap, ArrowRight, Check, Wrench } from 'lucide-react';

interface CorrelatedIncidentsSectionProps {
  incidents: CorrelatedIncident[];
  onAcknowledge: (id: string) => void;
  onResolve: (id: string, notes?: string) => void;
  isLoading?: boolean;
}

export const CorrelatedIncidentsSection: React.FC<CorrelatedIncidentsSectionProps> = ({
  incidents,
  onAcknowledge,
  onResolve,
  isLoading = false,
}) => {
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [resolutionNotes, setResolutionNotes] = useState<string>('');

  const filtered = incidents.filter((inc) => {
    if (filterSeverity !== 'ALL' && inc.severity !== filterSeverity) return false;
    return true;
  });

  const handleConfirmResolve = (id: string) => {
    onResolve(id, resolutionNotes || 'Incident root cause mitigated and telemetry nominal');
    setResolvingId(null);
    setResolutionNotes('');
  };

  return (
    <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" /> INTELLIGENT ALERT CORRELATION & INCIDENT ANALYSIS ({incidents.length})
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Noise-reduction engine groups cascading infrastructure and application threshold breaches into correlated root-cause incidents.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500 uppercase font-bold">SEVERITY:</span>
          <div className="flex items-center bg-[#161f2e] border border-slate-700 rounded-lg p-0.5">
            {(['ALL', 'CRITICAL', 'HIGH', 'WARNING'] as const).map((sev) => (
              <button
                key={sev}
                onClick={() => setFilterSeverity(sev)}
                className={`px-2.5 py-1 rounded text-[10px] font-bold transition-colors ${
                  filterSeverity === sev ? 'bg-orange-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-10 border border-dashed border-slate-800 rounded-xl space-y-2">
          <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto opacity-70" />
          <p className="text-white font-bold text-sm">No Active Correlated Incidents</p>
          <p className="text-slate-500 text-[11px]">
            All environment component threshold events are nominal or individually mitigated.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((inc) => {
            const isCritical = inc.severity === 'CRITICAL';
            const isHigh = inc.severity === 'HIGH';
            const isOpen = inc.status === 'TRIGGERED';
            const isAck = inc.status === 'ACKNOWLEDGED';
            const isResolved = inc.status === 'RESOLVED';

            return (
              <div
                key={inc.id}
                className={`p-4 rounded-xl border space-y-3 transition-all ${
                  isCritical
                    ? 'bg-[#1c0c0e]/80 border-rose-900/80 shadow-lg shadow-rose-950/20'
                    : isHigh
                    ? 'bg-[#1d1208]/80 border-amber-900/80'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-black/60 border border-slate-700 text-orange-400">
                        {inc.incident_code}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase border ${
                          isCritical
                            ? 'bg-rose-950 text-rose-300 border-rose-700'
                            : isHigh
                            ? 'bg-amber-950 text-amber-300 border-amber-700'
                            : 'bg-blue-950 text-blue-300 border-blue-700'
                        }`}
                      >
                        {inc.severity}
                      </span>
                      <span className="text-xs font-extrabold text-white">{inc.title}</span>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-slate-400">
                      <span>Environment: <strong className="text-orange-400">{inc.environment_name}</strong></span>
                      <span>Root Cause: <strong className="text-white">{inc.root_cause_type}</strong></span>
                      <span>Created: {inc.created_at?.replace('T', ' ').substring(0, 19)}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`px-2.5 py-1 rounded text-[10px] font-bold ${
                        isOpen
                          ? 'bg-rose-950/80 text-rose-300 border border-rose-800 animate-pulse'
                          : isAck
                          ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                          : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                      }`}
                    >
                      {inc.status}
                    </span>

                    {isOpen && (
                      <button
                        onClick={() => onAcknowledge(inc.id)}
                        className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700"
                      >
                        Acknowledge
                      </button>
                    )}

                    {!isResolved && (
                      <button
                        onClick={() => setResolvingId(inc.id)}
                        className="px-3 py-1.5 rounded bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs border border-emerald-600 flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" /> Resolve
                      </button>
                    )}
                  </div>
                </div>

                {/* Root Cause & Blast Radius */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80 text-[11px]">
                  <div className="bg-black/30 p-2.5 rounded border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">AUTOMATED ROOT CAUSE DIAGNOSIS</span>
                    <p className="text-slate-200 leading-relaxed">{inc.root_cause_summary}</p>
                  </div>
                  <div className="bg-black/30 p-2.5 rounded border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">TEST BLAST RADIUS & IMPACT</span>
                    <p className="text-slate-300 leading-relaxed">{inc.blast_radius_summary || 'Dependent testing suites impacted.'}</p>
                    <div className="flex flex-wrap gap-1 pt-1">
                      {(inc.affected_components || []).map((comp, idx) => (
                        <span key={idx} className="px-1.5 py-0.5 rounded text-[9px] bg-slate-800 text-slate-300">
                          {comp}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {inc.recommended_action && (
                  <div className="bg-emerald-950/20 border border-emerald-900/40 p-2 rounded flex items-center gap-2 text-[11px] text-emerald-300">
                    <Zap className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span><strong>Recommended Action:</strong> {inc.recommended_action}</span>
                  </div>
                )}

                {/* Inline Resolve Modal/Input */}
                {resolvingId === inc.id && (
                  <div className="p-3 bg-slate-950 border border-emerald-800 rounded-lg space-y-2 animate-in fade-in">
                    <span className="text-[11px] font-bold text-emerald-400 block">Record Incident Resolution Notes:</span>
                    <input
                      type="text"
                      value={resolutionNotes}
                      onChange={(e) => setResolutionNotes(e.target.value)}
                      placeholder="e.g. Cleared stuck connection pool and restarted container worker..."
                      className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
                    />
                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        onClick={() => setResolvingId(null)}
                        className="px-2.5 py-1 text-slate-400 hover:text-white text-xs"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleConfirmResolve(inc.id)}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded"
                      >
                        Confirm Resolution
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
