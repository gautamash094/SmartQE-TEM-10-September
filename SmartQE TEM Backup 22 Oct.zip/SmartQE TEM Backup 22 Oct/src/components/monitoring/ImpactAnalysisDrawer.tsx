import React from 'react';
import { EnvironmentProfile, ServerDetail, SoftwareDetail } from '../../types/environmentDetails';
import { Booking, Incident } from '../../types';
import { environmentDetailsService } from '../../services/environmentDetailsService';
import { monitoringService } from '../../services/monitoringService';
import {
  X,
  AlertTriangle,
  Server,
  Cpu,
  Layers,
  Calendar,
  ArrowRight,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Boxes,
  Zap,
} from 'lucide-react';

interface ImpactAnalysisDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  targetNode: {
    type: 'SERVER' | 'SOFTWARE' | 'ENVIRONMENT';
    name: string;
    id: string;
    environmentName?: string;
  } | null;
  environments: EnvironmentProfile[];
  bookings: Booking[];
  incidents?: Incident[];
}

export const ImpactAnalysisDrawer: React.FC<ImpactAnalysisDrawerProps> = ({
  isOpen,
  onClose,
  targetNode,
  environments,
  bookings,
  incidents = [],
}) => {
  if (!isOpen || !targetNode) return null;

  const affectedEnv =
    environments.find(
      (e) => e.name.toLowerCase() === (targetNode.environmentName || targetNode.name).toLowerCase()
    ) ||
    environments.find((e) => e.id === targetNode.id) ||
    environments[0];

  const allSoftware = environmentDetailsService.getSoftware();
  const envSoftwareList = allSoftware.filter((sw) => affectedEnv?.softwareIds?.includes(sw.id));

  const allServers = environmentDetailsService.getServers();
  const serverObj = targetNode.type === 'SERVER' ? allServers.find((s) => s.id === targetNode.id || s.name === targetNode.name) : null;
  const softwareObj = targetNode.type === 'SOFTWARE' ? allSoftware.find((sw) => sw.id === targetNode.id || sw.name === targetNode.name) : null;

  // Real Health & Readiness calculated from live TEM state
  const health = affectedEnv ? monitoringService.calculateEnvironmentHealth(affectedEnv, incidents) : null;
  const readiness = affectedEnv ? monitoringService.evaluateTestReadiness(affectedEnv, incidents, bookings) : null;

  // Filter active incidents matching the triggering node or affected environment
  const activeIncidents = incidents.filter(
    (inc) =>
      (inc.status === 'OPEN' || inc.status === 'INVESTIGATING') &&
      (inc.componentId === targetNode.id ||
        inc.componentName?.toLowerCase() === targetNode.name?.toLowerCase() ||
        inc.environmentId === affectedEnv?.id ||
        inc.environmentName?.toLowerCase() === affectedEnv?.name?.toLowerCase())
  );

  const isServerOffline = serverObj?.status === 'OFFLINE';
  const isSoftwareFailed = softwareObj?.status === 'DEPRECATED' || softwareObj?.isActive === false;
  const hasCriticalIncident = activeIncidents.some((i) => i.severity === 'SEV1');
  const hasWarningIncident = activeIncidents.length > 0;

  // Real node status
  let nodeState: 'HEALTHY' | 'DEGRADED' | 'UNHEALTHY' | 'MAINTENANCE' = 'HEALTHY';
  if (health?.status === 'MAINTENANCE') {
    nodeState = 'MAINTENANCE';
  } else if (isServerOffline || isSoftwareFailed || hasCriticalIncident || health?.status === 'UNHEALTHY') {
    nodeState = 'UNHEALTHY';
  } else if (hasWarningIncident || health?.status === 'DEGRADED') {
    nodeState = 'DEGRADED';
  } else {
    nodeState = 'HEALTHY';
  }

  const isHealthy = nodeState === 'HEALTHY';

  const affectedBookings = bookings.filter(
    (b) =>
      b.status !== 'CANCELLED' &&
      b.status !== 'REJECTED' &&
      b.status !== 'AUTO_REJECTED' &&
      ((affectedEnv && b.environmentId === affectedEnv.id) ||
        (affectedEnv && b.environmentName?.toLowerCase() === affectedEnv.name?.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-xl bg-[#090d14] border-l border-slate-200 dark:border-slate-800 h-full overflow-y-auto p-6 space-y-6 shadow-2xl font-mono text-xs text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div
              className={`p-2.5 rounded-lg border ${
                isHealthy
                  ? 'bg-emerald-950/80 border-emerald-800 text-emerald-400'
                  : nodeState === 'MAINTENANCE'
                  ? 'bg-blue-950/80 border-blue-800 text-blue-400'
                  : 'bg-red-950/80 border-red-800 text-red-400 animate-pulse'
              }`}
            >
              {isHealthy ? <ShieldCheck className="w-6 h-6" /> : <ShieldAlert className="w-6 h-6" />}
            </div>
            <div>
              <span
                className={`text-[10px] font-bold uppercase tracking-widest ${
                  isHealthy ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                OBSERVABILITY BLAST RADIUS
              </span>
              <h2 className="text-xl font-extrabold text-white">Dependency Impact Analysis</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Target Node Focus Box */}
        <div
          className={`border rounded-xl p-4 space-y-2 ${
            isHealthy
              ? 'bg-emerald-950/20 border-emerald-800/60'
              : nodeState === 'DEGRADED'
              ? 'bg-amber-950/30 border-amber-800/80'
              : nodeState === 'MAINTENANCE'
              ? 'bg-blue-950/30 border-blue-800/80'
              : 'bg-red-950/40 border-red-800/80'
          }`}
        >
          <span
            className={`text-[10px] font-bold uppercase tracking-wider block ${
              isHealthy ? 'text-emerald-300' : 'text-red-300'
            }`}
          >
            TRIGGERING COMPONENT
          </span>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 font-bold text-white">
              {targetNode.type === 'SERVER' ? (
                <Server className="w-4 h-4 text-blue-400" />
              ) : (
                <Cpu className="w-4 h-4 text-purple-400" />
              )}
              <span>{targetNode.name}</span>
            </div>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                isHealthy
                  ? 'bg-emerald-900/80 text-emerald-200 border-emerald-700'
                  : nodeState === 'DEGRADED'
                  ? 'bg-amber-900/80 text-amber-200 border-amber-700'
                  : nodeState === 'MAINTENANCE'
                  ? 'bg-blue-900/80 text-blue-200 border-blue-700'
                  : 'bg-red-900/80 text-red-200 border-red-700'
              }`}
            >
              STATE: {nodeState}
            </span>
          </div>
          <p className="text-[11px] text-slate-300">
            Node ID: <code className="text-orange-400">{targetNode.id}</code> · Environment Target:{' '}
            <strong className="text-white">{targetNode.environmentName || affectedEnv?.name}</strong>
          </p>
        </div>

        {/* Dependency Cascade Flow Graph */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <Layers className="w-4 h-4 text-orange-400" /> CASCADING IMPACT CHAIN
          </h3>

          <div className="space-y-3 relative before:absolute before:left-4 before:top-4 before:bottom-4 before:w-0.5 before:bg-slate-800">
            {/* Step 1: Component Telemetry Status */}
            <div className="flex items-start gap-4 relative z-10">
              <div
                className={`w-8 h-8 rounded-full border flex items-center justify-center shrink-0 font-bold ${
                  isHealthy
                    ? 'bg-emerald-950 border-emerald-800 text-emerald-400'
                    : 'bg-red-950 border-red-800 text-red-400'
                }`}
              >
                1
              </div>
              <div className="flex-1 bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold uppercase block">
                  1. {targetNode.type} TELEMETRY STATUS
                </span>
                <p className="text-xs font-bold text-white">{targetNode.name}</p>
                <p className="text-[11px] text-slate-400">
                  {activeIncidents.length > 0
                    ? activeIncidents[0].title || activeIncidents[0].description
                    : isHealthy
                    ? 'Operating nominal telemetry. No active threshold breaches or process disruptions detected.'
                    : `Telemetry status is ${nodeState}. Requires monitoring check.`}
                </p>
              </div>
            </div>

            {/* Step 2: Impacted Application Services */}
            <div className="flex items-start gap-4 relative z-10">
              <div
                className={`w-8 h-8 rounded-full border flex items-center justify-center shrink-0 font-bold ${
                  isHealthy
                    ? 'bg-emerald-950 border-emerald-800 text-emerald-400'
                    : 'bg-amber-950 border-amber-800 text-amber-400'
                }`}
              >
                2
              </div>
              <div className="flex-1 bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold uppercase block">
                  2. ENVIRONMENT SERVICES ({envSoftwareList.length})
                </span>
                {envSoftwareList.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic">No software packages attached to this environment.</p>
                ) : (
                  <div className="space-y-1 pt-1">
                    {envSoftwareList.slice(0, 4).map((sw) => {
                      const isSwHealthy = sw.status === 'ACTIVE' || sw.status === 'INSTALLED';
                      return (
                        <div
                          key={sw.id}
                          className="flex items-center justify-between text-[11px] bg-slate-950/60 p-2 rounded border border-slate-200 dark:border-slate-800/80"
                        >
                          <span className="text-slate-200 font-bold">{sw.name}</span>
                          <span
                            className={`text-[10px] font-bold ${
                              isSwHealthy ? 'text-emerald-400' : 'text-amber-400'
                            }`}
                          >
                            {isSwHealthy ? 'HEALTHY (ACTIVE)' : sw.status || 'DEGRADED'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Step 3: Impacted Environment Profile */}
            <div className="flex items-start gap-4 relative z-10">
              <div
                className={`w-8 h-8 rounded-full border flex items-center justify-center shrink-0 font-bold ${
                  isHealthy
                    ? 'bg-emerald-950 border-emerald-800 text-emerald-400'
                    : 'bg-orange-950 border-orange-800 text-orange-400'
                }`}
              >
                3
              </div>
              <div className="flex-1 bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold uppercase block">
                  3. ENVIRONMENT HEALTH & TEST READINESS
                </span>
                <p className="text-xs font-bold text-white">{affectedEnv?.name}</p>
                <p className="text-[11px] text-slate-400">
                  Overall Health Score:{' '}
                  <strong
                    className={
                      health?.score && health.score >= 90
                        ? 'text-emerald-400'
                        : health?.score && health.score >= 65
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }
                  >
                    {health?.score ?? 100}%
                  </strong>{' '}
                  ({health?.status || 'HEALTHY'}). Test Readiness:{' '}
                  <strong
                    className={
                      readiness?.status === 'READY_FOR_TESTING'
                        ? 'text-emerald-400'
                        : readiness?.status === 'PARTIALLY_READY'
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }
                  >
                    {readiness?.status?.replace(/_/g, ' ') || 'READY FOR TESTING'}
                  </strong>
                  .
                </p>
                {readiness?.reasons && readiness.reasons.length > 0 && (
                  <ul className="text-[10px] text-slate-400 list-disc list-inside space-y-0.5 pt-1">
                    {readiness.reasons.slice(0, 2).map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            {/* Step 4: Affected Active Bookings */}
            <div className="flex items-start gap-4 relative z-10">
              <div className="w-8 h-8 rounded-full bg-blue-950 border border-blue-800 flex items-center justify-center text-blue-400 shrink-0 font-bold">
                4
              </div>
              <div className="flex-1 bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-2">
                <span className="text-[10px] text-slate-500 font-bold uppercase block flex items-center justify-between">
                  <span>4. AFFECTED RESERVATIONS ({affectedBookings.length})</span>
                  <Calendar className="w-3.5 h-3.5 text-blue-400" />
                </span>

                {affectedBookings.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic">No active test reservations scheduled for this environment.</p>
                ) : (
                  <div className="space-y-1.5">
                    {affectedBookings.map((b) => (
                      <div key={b.id} className="p-2.5 rounded bg-blue-950/30 border border-blue-800/50 space-y-1">
                        <div className="flex items-center justify-between font-bold text-white">
                          <span>{b.purpose}</span>
                          <span className="text-blue-300 text-[10px]">{b.businessUnit}</span>
                        </div>
                        <p className="text-[10px] text-slate-400">
                          App: {b.application} · Requested By: <span className="text-orange-300">{b.requestedBy}</span>
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
