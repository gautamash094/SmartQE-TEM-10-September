import React from 'react';
import { CapacityForecast } from '../../types/monitoring';
import { TrendingUp, AlertTriangle, CheckCircle2, Calendar, HardDrive, Cpu, Database, Zap } from 'lucide-react';

interface CapacityForecastingSectionProps {
  forecasts: CapacityForecast[];
  environmentName?: string;
}

export const CapacityForecastingSection: React.FC<CapacityForecastingSectionProps> = ({
  forecasts,
  environmentName,
}) => {
  return (
    <div className="bg-[#0d1420] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-xl font-mono text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-purple-400" /> PROACTIVE CAPACITY FORECASTING & TRENDS
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Predictive growth models calculate linear slope trends to project days until threshold breach and recommend preventative capacity adjustments.
          </p>
        </div>

        {environmentName && (
          <div className="px-3 py-1 bg-purple-950/60 border border-purple-800 rounded-lg text-purple-300 font-bold text-[11px]">
            Target: {environmentName}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {forecasts.map((f, idx) => {
          const isCritical = f.capacity_health === 'CRITICAL';
          const isApproaching = f.capacity_health === 'APPROACHING_LIMIT';

          return (
            <div
              key={idx}
              className={`p-4 rounded-xl border space-y-3 transition-all ${
                isCritical
                  ? 'bg-rose-950/30 border-rose-800 shadow-md shadow-rose-950/20'
                  : isApproaching
                  ? 'bg-amber-950/20 border-amber-800'
                  : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-white text-xs flex items-center gap-2">
                  {f.metric_name.includes('Disk') ? (
                    <HardDrive className="w-4 h-4 text-amber-400" />
                  ) : f.metric_name.includes('Memory') ? (
                    <Cpu className="w-4 h-4 text-purple-400" />
                  ) : (
                    <Database className="w-4 h-4 text-blue-400" />
                  )}
                  {f.metric_name}
                </span>

                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase border ${
                    isCritical
                      ? 'bg-rose-950 text-rose-300 border-rose-700'
                      : isApproaching
                      ? 'bg-amber-950 text-amber-300 border-amber-700'
                      : 'bg-emerald-950 text-emerald-300 border-emerald-700'
                  }`}
                >
                  {f.capacity_health.replace('_', ' ')}
                </span>
              </div>

              {/* Progress Bar & Values */}
              <div className="space-y-1.5">
                <div className="flex items-baseline justify-between text-xs">
                  <span className="text-slate-400 font-bold">Current Utilization:</span>
                  <span className="text-lg font-black text-white">
                    {f.current_value}
                    <span className="text-xs text-slate-400">{f.unit}</span>
                  </span>
                </div>

                <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800 flex">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isCritical
                        ? 'bg-gradient-to-r from-orange-500 to-rose-600'
                        : isApproaching
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500'
                        : 'bg-gradient-to-r from-emerald-500 to-blue-500'
                    }`}
                    style={{ width: `${Math.min(100, f.current_value)}%` }}
                  />
                </div>

                <div className="flex justify-between text-[10px] text-slate-500 pt-0.5">
                  <span>Warning: {f.warning_threshold}%</span>
                  <span>Critical: {f.critical_threshold}%</span>
                </div>
              </div>

              {/* Growth Model & Projections */}
              <div className="bg-black/40 p-2.5 rounded border border-slate-800 space-y-1.5 text-[11px]">
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Growth Rate:</span>
                  <span className="font-bold text-orange-400">+{f.growth_rate_daily}% / day</span>
                </div>

                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Days to Critical Breach:</span>
                  <span className={`font-black ${f.days_to_critical_breach !== undefined && f.days_to_critical_breach < 7 ? 'text-rose-400 animate-pulse' : 'text-white'}`}>
                    {f.days_to_critical_breach !== undefined ? `${f.days_to_critical_breach} days` : 'Stable (>30d)'}
                  </span>
                </div>

                {f.projected_breach_date && (
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-400">Projected Breach Date:</span>
                    <span className="font-bold text-slate-200 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-400" /> {f.projected_breach_date}
                    </span>
                  </div>
                )}
              </div>

              {/* Recommendation */}
              <div className="p-2 rounded bg-slate-950/60 border border-slate-800 text-[10px] text-slate-300 flex items-start gap-1.5">
                <Zap className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5" />
                <span>{f.recommendation}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
