import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bot,
  Sparkles,
  X,
  Send,
  Trash2,
  Maximize2,
  Minimize2,
  ChevronRight,
  ExternalLink,
  Activity,
  Calendar,
  Layers,
  GitBranch,
  TrendingUp,
  HelpCircle,
  GripHorizontal,
  CheckCircle2,
  AlertTriangle,
  Check,
  Loader2,
} from 'lucide-react';
import {
  temAssistantService,
  AssistantChatMessage,
  AssistantChatResponse,
  BotBookingRequest,
  BotBookingResult,
} from '../../services/temAssistantService';
import { AssistantSuggestedPrompt, TEM_DEFAULT_PROMPTS } from '../../services/temAssistantKnowledge';
import { useTEM } from '../../context/TEMContext';
import { useAuth } from '../../context/AuthContext';

interface AIModelOption {
  id: string;
  name: string;
  provider: string;
  model: string;
  badge: string;
}

const AI_MODELS: AIModelOption[] = [
  { id: 'auto', name: 'Auto (Failover)', provider: 'auto', model: '', badge: '✨ Auto' },
  { id: 'gemini-flash', name: 'Gemini 1.5 Flash (Fast)', provider: 'gemini', model: 'gemini-1.5-flash', badge: '⚡ Gemini Flash' },
  { id: 'gemini-pro', name: 'Gemini 1.5 Pro (Deep)', provider: 'gemini', model: 'gemini-1.5-pro', badge: '🧠 Gemini Pro' },
  { id: 'openai-mini', name: 'GPT-4o Mini (Fast)', provider: 'openai', model: 'gpt-4o-mini', badge: '🟢 GPT-4o Mini' },
  { id: 'openai-gpt4o', name: 'GPT-4o (Reasoning)', provider: 'openai', model: 'gpt-4o', badge: '🚀 GPT-4o' },
];

export const TemAssistantBot: React.FC = () => {
  const navigate = useNavigate();
  const { refreshData, showToast } = useTEM();
  const { currentUser } = useAuth();
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [inputMessage, setInputMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [bookingExecutingIdx, setBookingExecutingIdx] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [catalogPrompts, setCatalogPrompts] = useState<AssistantSuggestedPrompt[]>(TEM_DEFAULT_PROMPTS);
  const [recentDynamicPrompts, setRecentDynamicPrompts] = useState<AssistantSuggestedPrompt[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>(() => {
    return localStorage.getItem('tem_assistant_model') || 'auto';
  });

  const handleModelChange = (modelId: string) => {
    setSelectedModel(modelId);
    localStorage.setItem('tem_assistant_model', modelId);
  };

  // Messages State
  const [messages, setMessages] = useState<AssistantChatMessage[]>(() => {
    return [
      {
        role: 'assistant',
        content: `👋 **Hello! I am your Intelligent TEM Conversational Assistant.**

I have complete visibility over all **15 TEM modules** (Environments, Bookings, Releases, Observability, Health Checks, Auto-Heal, Diagnosis, Usage Analytics, and Predictive Demand).

Ask me anything in natural language, or pick a prompt below!`,
        timestamp: new Date().toISOString(),
      },
    ];
  });

  // Dragging detection & viewport boundary constraint
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragBoundaryRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    temAssistantService.getSuggestedPrompts().then((prompts) => {
      if (prompts && prompts.length > 0) {
        setCatalogPrompts(prompts);
      }
    });
  }, []);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen, messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || isLoading) return;

    const userMsg: AssistantChatMessage = {
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    const minDelayPromise = new Promise((resolve) => setTimeout(resolve, 3200));

    const modelConfig = AI_MODELS.find((m) => m.id === selectedModel) || AI_MODELS[0];

    const userContext: Record<string, any> = {};
    if (currentUser) {
      if (currentUser.fullName) userContext.user_name = currentUser.fullName;
      else if (currentUser.username) userContext.user_name = currentUser.username;
      if (currentUser.email) userContext.user_email = currentUser.email;
      if (currentUser.id) userContext.user_id = currentUser.id;
    }

    try {
      const historyPayload = messages.slice(-8);
      const [res] = await Promise.all([
        temAssistantService.sendMessage(
          text,
          historyPayload,
          userContext,
          modelConfig.provider === 'auto' ? undefined : modelConfig.provider,
          modelConfig.model || undefined
        ),
        minDelayPromise,
      ]);

      const assistantMsg: AssistantChatMessage = {
        role: 'assistant',
        content: res.reply,
        timestamp: new Date().toISOString(),
        provider: res.entities?.provider,
        model: res.entities?.model,
        action_links: res.action_links,
        raw_data: res.raw_data,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      if (res.suggested_prompts && res.suggested_prompts.length > 0) {
        setRecentDynamicPrompts(res.suggested_prompts);
      }
    } catch (error) {
      await minDelayPromise;
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: '⚠️ Failed to generate response. Please try again.',
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirmBooking = async (msgIndex: number, bookingReq: BotBookingRequest) => {
    setBookingExecutingIdx(msgIndex);
    try {
      const finalRequester =
        currentUser?.fullName ||
        currentUser?.username ||
        currentUser?.email ||
        bookingReq.requested_by ||
        'TEM Bot User';

      const bookingPayload: BotBookingRequest = {
        ...bookingReq,
        requested_by: finalRequester,
      };

      const res = await temAssistantService.executeBooking(bookingPayload);
      setMessages((prev) =>
        prev.map((m, idx) => {
          if (idx === msgIndex) {
            return {
              ...m,
              is_booking_executed: true,
              booking_result: res,
            };
          }
          return m;
        })
      );

      if (res.success) {
        // Instantly reload bookings in TEMContext so Worklist and Bookings grid update live without page refresh
        await refreshData(true);
        showToast(
          `Reservation confirmed for ${res.environment_name || bookingReq.environment_name}! (Ref: #${res.reservation_id})`,
          'success'
        );
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('booking_updated', { detail: res }));
        }
      } else {
        showToast(res.message || 'Failed to complete reservation', 'error');
      }
    } catch (err: any) {
      setMessages((prev) =>
        prev.map((m, idx) => {
          if (idx === msgIndex) {
            return {
              ...m,
              is_booking_executed: true,
              booking_result: {
                success: false,
                message: err?.message || 'Failed to complete reservation',
                environment_name: bookingReq.environment_name,
              },
            };
          }
          return m;
        })
      );
      showToast(err?.message || 'Failed to complete reservation', 'error');
    } finally {
      setBookingExecutingIdx(null);
    }
  };

  const handleClearHistory = () => {
    setRecentDynamicPrompts([]);
    setMessages([
      {
        role: 'assistant',
        content: `Chat history cleared. How can I assist you with your TEM environments today?`,
        timestamp: new Date().toISOString(),
      },
    ]);
  };

  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    let inTable = false;
    let tableHeader: string[] = [];
    let tableRows: string[][] = [];
    const elements: React.ReactNode[] = [];

    const flushTable = (key: number) => {
      if (tableHeader.length > 0 || tableRows.length > 0) {
        elements.push(
          <div key={`table-${key}`} className="my-3 overflow-x-auto rounded-lg border border-slate-700/80 bg-slate-900/90 text-xs">
            <table className="w-full text-left border-collapse">
              {tableHeader.length > 0 && (
                <thead>
                  <tr className="bg-slate-800/80 border-b border-slate-700 text-cyan-400 font-semibold">
                    {tableHeader.map((th, i) => (
                      <th key={i} className="p-2 whitespace-nowrap">
                        {th.trim()}
                      </th>
                    ))}
                  </tr>
                </thead>
              )}
              <tbody className="divide-y divide-slate-800">
                {tableRows.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-slate-800/40 transition-colors">
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} className="p-2 text-slate-200">
                        {renderInlineFormattedText(cell.trim())}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
        tableHeader = [];
        tableRows = [];
        inTable = false;
      }
    };

    lines.forEach((line, index) => {
      const trimmed = line.trim();

      // Table line detection
      if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
        const cells = trimmed
          .split('|')
          .slice(1, -1)
          .map((c) => c.trim());

        // Skip separator row like |:---|:---|
        if (cells.every((c) => /^:?-+:?$/.test(c))) {
          return;
        }

        if (!inTable) {
          inTable = true;
          tableHeader = cells;
        } else {
          tableRows.push(cells);
        }
        return;
      } else if (inTable) {
        flushTable(index);
      }

      // Headers
      if (trimmed.startsWith('### ')) {
        elements.push(
          <h3 key={index} className="text-sm md:text-base font-bold text-cyan-300 mt-2 mb-1">
            {trimmed.replace('### ', '')}
          </h3>
        );
      } else if (trimmed.startsWith('#### ')) {
        elements.push(
          <h4 key={index} className="text-xs md:text-sm font-semibold text-emerald-400 mt-2 mb-1">
            {trimmed.replace('#### ', '')}
          </h4>
        );
      } else if (trimmed.startsWith('> ')) {
        elements.push(
          <blockquote key={index} className="border-l-2 border-cyan-500 bg-cyan-950/30 text-cyan-100 p-2 my-2 rounded-r text-xs">
            {renderInlineFormattedText(trimmed.replace('> ', ''))}
          </blockquote>
        );
      } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        elements.push(
          <li key={index} className="ml-4 list-disc text-xs text-slate-300 my-0.5">
            {renderInlineFormattedText(trimmed.substring(2))}
          </li>
        );
      } else if (/^\d+\.\s/.test(trimmed)) {
        elements.push(
          <div key={index} className="text-xs text-slate-300 ml-2 my-0.5 flex items-start gap-1">
            <span className="font-semibold text-cyan-400">{trimmed.match(/^\d+\./)?.[0]}</span>
            <span>{renderInlineFormattedText(trimmed.replace(/^\d+\.\s/, ''))}</span>
          </div>
        );
      } else if (trimmed.length > 0) {
        elements.push(
          <p key={index} className="text-xs leading-relaxed text-slate-200 my-1">
            {renderInlineFormattedText(trimmed)}
          </p>
        );
      } else {
        elements.push(<div key={index} className="h-1" />);
      }
    });

    if (inTable) {
      flushTable(lines.length);
    }

    return elements;
  };

  const renderInlineFormattedText = (text: string): React.ReactNode => {
    // Replace markdown links [Label](/route)
    const linkRegex = /\[(.*?)\]\((.*?)\)/g;
    const parts: React.ReactNode[] = [];
    let lastIdx = 0;
    let match;

    while ((match = linkRegex.exec(text)) !== null) {
      if (match.index > lastIdx) {
        parts.push(renderBoldAndCode(text.substring(lastIdx, match.index)));
      }
      const label = match[1];
      const route = match[2];
      parts.push(
        <button
          key={match.index}
          onClick={() => navigate(route)}
          className="inline-flex items-center gap-0.5 text-cyan-400 hover:text-cyan-200 underline font-medium mx-1"
        >
          {label} <ExternalLink className="w-3 h-3 inline" />
        </button>
      );
      lastIdx = linkRegex.lastIndex;
    }

    if (lastIdx < text.length) {
      parts.push(renderBoldAndCode(text.substring(lastIdx)));
    }

    return <>{parts}</>;
  };

  const renderBoldAndCode = (text: string): React.ReactNode => {
    // Handle `code` and **bold**
    const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*)/g);
    return (
      <>
        {parts.map((part, idx) => {
          if (part.startsWith('`') && part.endsWith('`')) {
            return (
              <code key={idx} className="bg-slate-800 text-cyan-300 px-1 py-0.5 rounded text-[11px] font-mono border border-slate-700">
                {part.slice(1, -1)}
              </code>
            );
          }
          if (part.startsWith('**') && part.endsWith('**')) {
            return (
              <strong key={idx} className="text-slate-100 font-semibold">
                {part.slice(2, -2)}
              </strong>
            );
          }
          return part;
        })}
      </>
    );
  };

  const categories = [
    { id: 'All', label: 'All', icon: Sparkles },
    { id: 'Health', label: 'Health', icon: Activity },
    { id: 'Bookings', label: 'Bookings', icon: Calendar },
    { id: 'Diagnosis', label: 'Diagnosis', icon: Layers },
    { id: 'Releases', label: 'Releases', icon: GitBranch },
    { id: 'Demand', label: 'Demand', icon: TrendingUp },
    { id: 'How-To', label: 'How-To', icon: HelpCircle },
  ];

  const filteredPrompts = useMemo(() => {
    if (activeCategory === 'All') {
      const combined = [...recentDynamicPrompts];
      const seen = new Set(combined.map((p) => p.prompt.toLowerCase()));
      for (const p of catalogPrompts) {
        if (!seen.has(p.prompt.toLowerCase())) {
          combined.push(p);
          seen.add(p.prompt.toLowerCase());
        }
      }
      return combined.slice(0, 8);
    }

    const catKey = activeCategory.toLowerCase();
    const matched = catalogPrompts.filter((p) => {
      const pCat = p.category.toLowerCase();
      if (catKey === 'health') return pCat.includes('health') || pCat.includes('observability');
      if (catKey === 'bookings') return pCat.includes('book') || pCat.includes('reservation');
      if (catKey === 'diagnosis') return pCat.includes('diagnos') || pCat.includes('comparison');
      if (catKey === 'releases') return pCat.includes('release');
      if (catKey === 'demand') return pCat.includes('demand') || pCat.includes('capacity');
      if (catKey === 'how-to') return pCat.includes('how') || pCat.includes('provision') || pCat.includes('guide');
      return pCat.includes(catKey);
    });

    const dynamicMatching = recentDynamicPrompts.filter((p) => {
      const pCat = p.category.toLowerCase();
      return pCat.includes(catKey) || p.prompt.toLowerCase().includes(catKey);
    });

    const combined = [...dynamicMatching];
    const seen = new Set(combined.map((p) => p.prompt.toLowerCase()));
    for (const p of matched) {
      if (!seen.has(p.prompt.toLowerCase())) {
        combined.push(p);
        seen.add(p.prompt.toLowerCase());
      }
    }
    return combined.slice(0, 8);
  }, [activeCategory, catalogPrompts, recentDynamicPrompts]);

  return (
    <>
      {/* Invisible Viewport Boundary for Draggable Bot Trigger */}
      <div
        ref={dragBoundaryRef}
        className="fixed inset-3 md:inset-5 pointer-events-none z-0"
        aria-hidden="true"
      />

      {/* 1. Round Floating Draggable Trigger Orb */}
      <motion.div
        drag
        dragConstraints={dragBoundaryRef}
        dragElastic={0}
        dragMomentum={false}
        onDragStart={() => setIsDragging(true)}
        onDragEnd={() => {
          setTimeout(() => setIsDragging(false), 100);
        }}
        initial={{ x: 0, y: 0 }}
        className="fixed bottom-6 right-6 z-50 cursor-grab active:cursor-grabbing select-none"
      >
        <div className="relative group">
          {/* Pulsing Aura */}
          <div className="absolute -inset-1.5 bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-500 rounded-full blur opacity-70 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse" />

          {/* Round Action Button */}
          <button
            onClick={() => {
              if (!isDragging) {
                setIsOpen((prev) => !prev);
              }
            }}
            aria-label="Open TEM Conversational Assistant"
            className="relative w-14 h-14 md:w-16 md:h-16 rounded-full bg-[#080c14] border-2 border-cyan-400/80 flex items-center justify-center text-cyan-400 shadow-[0_0_25px_rgba(6,182,212,0.6)] hover:scale-105 active:scale-95 transition-transform"
          >
            {isOpen ? (
              <X className="w-7 h-7 text-cyan-300" />
            ) : (
              <div className="relative flex items-center justify-center">
                <Bot className="w-8 h-8 text-cyan-400" />
              </div>
            )}
          </button>

          {/* Floating Tooltip if closed */}
          {!isOpen && (
            <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-3 py-1 bg-slate-900/90 text-cyan-300 text-xs font-semibold rounded-full border border-cyan-500/40 shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              ✨ Ask TEM Assistant
            </div>
          )}
        </div>
      </motion.div>

      {/* 2. Glassmorphism Conversational Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.85, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.85, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className={`fixed z-50 bg-[#080c14]/95 backdrop-blur-2xl border border-cyan-500/40 rounded-2xl shadow-[0_10px_50px_rgba(0,0,0,0.8)] flex flex-col overflow-hidden text-slate-100 transition-all ${
              isExpanded
                ? 'top-4 left-4 right-4 bottom-4 md:top-8 md:left-12 md:right-12 md:bottom-8'
                : 'bottom-24 right-4 md:right-8 w-[calc(100vw-32px)] sm:w-[480px] md:w-[540px] h-[640px] max-h-[calc(100vh-120px)]'
            }`}
          >
            {/* Header */}
            <div className="p-3.5 bg-gradient-to-r from-slate-900/90 via-[#0d1527] to-slate-900/90 border-b border-cyan-500/30 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-cyan-950/80 border border-cyan-400 flex items-center justify-center text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.4)]">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h2 className="font-bold text-sm text-slate-100">TEM AI Assistant</h2>
                  </div>
                  <p className="text-[10px] text-slate-400">Autonomous co-pilot across all 15 TEM modules</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <select
                  value={selectedModel}
                  onChange={(e) => handleModelChange(e.target.value)}
                  className="bg-slate-800/90 hover:bg-slate-800 text-[11px] font-medium text-cyan-300 border border-cyan-500/40 rounded-lg px-2 py-1 outline-none cursor-pointer focus:border-cyan-400 max-w-[145px] sm:max-w-[185px] truncate transition-colors"
                  title="Select AI Model (Google Gemini or OpenAI)"
                >
                  {AI_MODELS.map((m) => (
                    <option key={m.id} value={m.id} className="bg-slate-900 text-slate-100">
                      {m.name}
                    </option>
                  ))}
                </select>

                <button
                  onClick={handleClearHistory}
                  title="Clear Chat History"
                  className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsExpanded((prev) => !prev)}
                  title={isExpanded ? 'Collapse' : 'Expand'}
                  className="p-1.5 text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/30 rounded-lg transition-colors"
                >
                  {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  title="Close Assistant"
                  className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Category Quick Tabs */}
            <div className="flex items-center gap-1.5 px-3 py-2 bg-slate-900/50 border-b border-slate-800/80 overflow-x-auto no-scrollbar">
              {categories.map((cat) => {
                const IconComponent = cat.icon;
                const active = activeCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium transition-all whitespace-nowrap ${
                      active
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_8px_rgba(6,182,212,0.3)]'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
                    }`}
                  >
                    <IconComponent className="w-3 h-3" />
                    {cat.label}
                  </button>
                );
              })}
            </div>

            {/* Message Thread */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {messages.map((msg, idx) => {
                const isUser = msg.role === 'user';
                return (
                  <div
                    key={idx}
                    className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    {!isUser && (
                      <div className="w-7 h-7 rounded-full bg-cyan-950/80 border border-cyan-500/50 flex-shrink-0 flex items-center justify-center text-cyan-400 mt-1">
                        <Bot className="w-3.5 h-3.5" />
                      </div>
                    )}
                    <div
                      className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs shadow-md ${
                        isUser
                          ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white rounded-tr-none'
                          : 'bg-slate-900/80 border border-slate-800 text-slate-200 rounded-tl-none'
                      }`}
                    >
                      {!isUser && msg.provider && msg.provider !== 'none' && (
                        <div className="flex items-center gap-1 text-[10px] text-cyan-300 font-semibold mb-1.5 pb-1 border-b border-cyan-500/20">
                          <Sparkles className="w-2.5 h-2.5 text-cyan-400" />
                          <span>
                            {msg.provider === 'gemini'
                              ? 'Google Gemini'
                              : msg.provider === 'openai'
                              ? 'OpenAI'
                              : msg.provider}{' '}
                            <span className="text-slate-400 font-normal">({msg.model || 'live'})</span>
                          </span>
                        </div>
                      )}
                      {isUser ? msg.content : renderFormattedContent(msg.content)}

                      {/* Interactive In-Chat Booking Preview Card */}
                      {!isUser && msg.raw_data?.booking_preview && (
                        <div className="mt-3 pt-3 border-t border-slate-700/60 space-y-2.5">
                          <div className="p-3 rounded-xl bg-slate-950/80 border border-cyan-500/30 text-xs shadow-inner">
                            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                              <span className="font-semibold text-cyan-300 flex items-center gap-1.5">
                                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                                Booking Reservation Preview
                              </span>
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-900/60 text-cyan-300 border border-cyan-500/40">
                                {msg.raw_data.booking_preview.environment_name} ({msg.raw_data.booking_preview.tier})
                              </span>
                            </div>

                            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300 mb-2.5">
                              <div>
                                <span className="text-slate-400 block text-[10px]">Start Date & Time</span>
                                <span className="font-medium text-slate-100">{msg.raw_data.booking_preview.start_date} UTC</span>
                              </div>
                              <div>
                                <span className="text-slate-400 block text-[10px]">End Date & Time</span>
                                <span className="font-medium text-slate-100">{msg.raw_data.booking_preview.end_date} UTC</span>
                              </div>
                              <div>
                                <span className="text-slate-400 block text-[10px]">Purpose</span>
                                <span className="font-medium text-slate-100">{msg.raw_data.booking_preview.purpose}</span>
                              </div>
                              <div>
                                <span className="text-slate-400 block text-[10px]">Reservation Mode</span>
                                <span
                                  className={`font-semibold ${
                                    msg.raw_data.booking_preview.reservation_mode === 'DISRUPTIVE'
                                      ? 'text-amber-400'
                                      : 'text-emerald-400'
                                  }`}
                                >
                                  {msg.raw_data.booking_preview.reservation_mode}
                                </span>
                              </div>
                            </div>

                            {/* Pre-Flight Conflict Status */}
                            {msg.raw_data.booking_preview.has_conflict ? (
                              <div className="flex items-start gap-2 p-2 rounded-lg bg-amber-950/40 border border-amber-500/50 text-amber-200 text-[11px] mb-2.5">
                                <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                                <div>
                                  <div className="font-semibold text-amber-300">Conflict Detected</div>
                                  <div className="text-[10px] text-amber-200/90">{msg.raw_data.booking_preview.conflict_summary}</div>
                                </div>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 p-2 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-[11px] mb-2.5">
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                                <span>Zero conflicts. Environment is free and available!</span>
                              </div>
                            )}

                            {/* Booking Action / Result State */}
                            {msg.is_booking_executed ? (
                              msg.booking_result?.success ? (
                                <div className="p-2.5 rounded-lg bg-emerald-900/30 border border-emerald-500/50 space-y-1.5">
                                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
                                    <CheckCircle2 className="w-4 h-4" />
                                    <span>Reservation Confirmed!</span>
                                  </div>
                                  <div className="text-[11px] text-slate-200">
                                    Reference ID:{' '}
                                    <span className="font-mono text-cyan-300 font-bold">
                                      #{msg.booking_result.reservation_id}
                                    </span>
                                    {msg.booking_result.status && (
                                      <span className="ml-2 px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                                        Status: {msg.booking_result.status}
                                      </span>
                                    )}
                                  </div>
                                  <div className="text-[10px] text-slate-400 italic">
                                    {msg.booking_result.message}
                                  </div>
                                  <div className="flex items-center gap-2.5 mt-1.5 pt-1.5 border-t border-emerald-500/20">
                                    <button
                                      onClick={() => navigate('/bookings')}
                                      className="text-[11px] text-cyan-400 hover:text-cyan-200 flex items-center gap-1 font-semibold transition-colors"
                                    >
                                      View in Calendar <ExternalLink className="w-3 h-3" />
                                    </button>
                                    <span className="text-slate-600">•</span>
                                    <button
                                      onClick={() => navigate('/worklist')}
                                      className="text-[11px] text-indigo-400 hover:text-indigo-200 flex items-center gap-1 font-semibold transition-colors"
                                    >
                                      View in Worklist <ExternalLink className="w-3 h-3" />
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-500/50 space-y-1.5">
                                  <div className="flex items-center gap-1.5 text-rose-400 font-bold text-xs">
                                    <AlertTriangle className="w-4 h-4" />
                                    <span>Reservation Request Failed</span>
                                  </div>
                                  <div className="text-[11px] text-rose-200">{msg.booking_result?.message}</div>
                                  <div className="flex items-center gap-2 mt-2">
                                    <button
                                      onClick={() => handleConfirmBooking(idx, msg.raw_data.booking_request)}
                                      disabled={bookingExecutingIdx === idx}
                                      className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[11px] font-medium transition-colors"
                                    >
                                      Retry Booking
                                    </button>
                                    <button
                                      onClick={() => navigate('/bookings')}
                                      className="text-[11px] text-slate-400 hover:text-slate-200 underline"
                                    >
                                      Go to Calendar
                                    </button>
                                  </div>
                                </div>
                              )
                            ) : (
                              <div className="flex items-center gap-2 pt-1">
                                <button
                                  onClick={() => handleConfirmBooking(idx, msg.raw_data.booking_request)}
                                  disabled={bookingExecutingIdx === idx}
                                  className="flex-1 py-1.5 px-3 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95 disabled:opacity-50"
                                >
                                  {bookingExecutingIdx === idx ? (
                                    <>
                                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                      Reserving...
                                    </>
                                  ) : (
                                    <>
                                      <Check className="w-3.5 h-3.5" />
                                      Confirm & Reserve Now
                                    </>
                                  )}
                                </button>
                                <button
                                  onClick={() => navigate('/bookings')}
                                  className="py-1.5 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
                                >
                                  Calendar
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Generic Action Links (when not a booking preview card) */}
                      {!isUser &&
                        msg.action_links &&
                        msg.action_links.length > 0 &&
                        !msg.raw_data?.booking_preview && (
                          <div className="mt-2.5 pt-2 border-t border-slate-700/60 flex flex-wrap gap-1.5">
                            {msg.action_links.map((link, lIdx) => (
                              <button
                                key={lIdx}
                                onClick={() => {
                                  if (link.route) {
                                    navigate(link.route);
                                  }
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-800 hover:bg-cyan-950/60 text-cyan-300 hover:text-cyan-200 border border-slate-700 hover:border-cyan-500/40 text-[11px] font-medium transition-colors"
                              >
                                <span>{link.label}</span>
                                <ExternalLink className="w-3 h-3 text-cyan-400" />
                              </button>
                            ))}
                          </div>
                        )}
                    </div>
                  </div>
                );
              })}

              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex gap-2.5 items-start text-xs text-cyan-400 my-1"
                >
                  <div className="w-7 h-7 rounded-full bg-cyan-950/80 border border-cyan-500/50 flex-shrink-0 flex items-center justify-center text-cyan-400 mt-0.5">
                    <Bot className="w-3.5 h-3.5 animate-pulse" />
                  </div>
                  <div className="bg-slate-900/90 border border-cyan-500/30 px-4 py-3 rounded-2xl rounded-tl-none flex items-center gap-3 shadow-lg">
                    <div className="flex items-center gap-1.5 py-0.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-bounce [animation-delay:-0.3s]" />
                      <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.15s]" />
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-bounce" />
                    </div>
                    <span className="text-[11px] font-medium text-slate-300">
                      Analyzing TEM fleet & generating response...
                    </span>
                  </div>
                </motion.div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Suggestions Chips */}
            {filteredPrompts.length > 0 && (
              <div className="px-3 py-2 bg-slate-900/40 border-t border-slate-800/60 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold whitespace-nowrap pl-1">
                  Suggestions:
                </span>
                {filteredPrompts.slice(0, 5).map((p, pIdx) => (
                  <button
                    key={pIdx}
                    onClick={() => handleSendMessage(p.prompt)}
                    className="flex-shrink-0 px-2.5 py-1 bg-slate-800/70 hover:bg-cyan-950/60 hover:text-cyan-300 hover:border-cyan-500/50 text-slate-300 border border-slate-700/60 rounded-full text-[11px] transition-all flex items-center gap-1 shadow-sm"
                  >
                    <span>{p.prompt}</span>
                    <ChevronRight className="w-3 h-3 text-cyan-500" />
                  </button>
                ))}
              </div>
            )}

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="p-3 bg-slate-900/90 border-t border-cyan-500/20 flex items-center gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask about SIT/UAT envs, bookings, releases, health, diagnosis..."
                className="flex-1 bg-slate-950/80 border border-slate-700/80 focus:border-cyan-400 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-all"
              />
              <button
                type="submit"
                disabled={!inputMessage.trim() || isLoading}
                className="w-9 h-9 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center text-white shadow-md transition-transform active:scale-95 flex-shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
