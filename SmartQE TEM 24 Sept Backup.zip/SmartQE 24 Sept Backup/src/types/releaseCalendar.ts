export type CalendarViewMode = 'calendar' | 'gantt';
export type CalendarDisplayScope = 'application' | 'environment';
export type CalendarTimePeriod = 'month' | 'quarter' | 'year';

export interface ReleaseCalendarPhase {
  phaseId: string;
  phaseName: string;
  testPhaseId?: string;
  color?: string;
  environmentId?: string;
  environmentName?: string;
  startDate: string;
  endDate: string;
  sequence: number;
  status: string;
  remarks?: string;
}

export interface ReleaseCalendarRelease {
  releaseId: string;
  releaseName: string;
  version: string;
  riskType: string;
  risk: string;
  status: string;
  releaseManager?: string;
  buId?: string;
  businessUnit?: string;
  projectId?: string;
  projectName?: string;
  applicationId?: string;
  applicationName?: string;
  environmentId?: string;
  environmentName?: string;
  startDate?: string;
  endDate?: string;
  repositoryUrl?: string;
  remarks?: string;
  phases: ReleaseCalendarPhase[];
}

export interface ReleaseCalendarGroup {
  groupKey: string;
  groupName: string;
  groupType: 'application' | 'environment';
  businessUnit?: string;
  projectId?: string;
  projectName?: string;
  releases: ReleaseCalendarRelease[];
}

export interface ReleaseCalendarConflictEntity {
  releaseId: string;
  releaseName: string;
  phaseId?: string;
  phaseName?: string;
  startDate?: string;
  endDate?: string;
}

export interface ReleaseCalendarConflict {
  id: string;
  type: 'application' | 'environment';
  entityId: string;
  entityName: string;
  releaseA: ReleaseCalendarConflictEntity;
  releaseB: ReleaseCalendarConflictEntity;
  conflictStartDate: string;
  conflictEndDate: string;
  severity: 'HIGH' | 'MEDIUM';
  message: string;
}

export interface ReleaseCalendarSummary {
  totalReleases: number;
  totalPhases: number;
  activeReleases: number;
  conflictsCount: number;
}

export interface ReleaseCalendarDateRange {
  startDate: string;
  endDate: string;
}

export interface ReleaseCalendarData {
  viewBy: CalendarDisplayScope;
  year: number;
  period: CalendarTimePeriod;
  month?: number;
  quarter?: number;
  dateRange: ReleaseCalendarDateRange;
  items: ReleaseCalendarGroup[];
  conflicts: ReleaseCalendarConflict[];
  summary: ReleaseCalendarSummary;
}

export interface ReleaseCalendarFilterState {
  search: string;
  buId: string;
  releaseId: string;
  applicationId: string;
  environmentId: string;
  riskType: string;
  status: string;
  showConflictsOnly: boolean;
}
