export type EnvironmentStatus = 'HEALTHY' | 'DOWN' | 'DEGRADED' | 'MAINTENANCE';
export type EnvironmentTier = 'DEV' | 'SIT' | 'UAT' | 'PRE-PROD' | 'PERF' | 'QA';

export interface ComponentTopology {
  id: string;
  name: string;
  category: 'SERVICE' | 'COMPUTE' | 'DATABASE' | 'CACHE' | 'QUEUE';
  version: string;
  status: EnvironmentStatus;
}

export interface Environment {
  id: string;
  name: string;
  tier: EnvironmentTier;
  team: string;
  owner: string;
  region: string;
  status: EnvironmentStatus;
  isActive?: boolean;
  isVisible?: boolean;
  createdBy?: string;
  ownerId?: string;
  uptime: number; // e.g. 97.54
  cpuUsage: number; // e.g. 63.4
  memoryUsage: number; // e.g. 76.0
  storageUsage: number; // e.g. 45.5
  techStack: string[];
  topology: ComponentTopology[];
}

export type ReservationMode = 'SHARED' | 'DISRUPTIVE';
export type AutoApprovalRule = 'ALL_REQUESTS' | 'PRIORITY_REQUESTS' | 'SHORT_REQUESTS';
export type ReservationPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface BookingAuditEntry {
  id: string;
  field: string;
  oldValue: string;
  newValue: string;
  changedBy: string;
  changedAt: string;
  comments?: string;
  stepOrder?: number;
  status?: string;
}

export interface Booking {
  id: string;
  environmentId: string;
  environmentName: string;
  businessUnit: string; // REQUIRED BY USER
  project?: string;     // OPTIONAL
  application?: string; // OPTIONAL
  purpose: string;
  team: string;
  requestedBy: string;
  priority?: ReservationPriority;
  autoApprovalEnabled?: boolean;
  autoApprovalRule?: AutoApprovalRule | null;
  startDate: string; // YYYY-MM-DDTHH:mm:ss (Includes Date, Hours, Minutes, Seconds)
  endDate: string;   // YYYY-MM-DDTHH:mm:ss (Includes Date, Hours, Minutes, Seconds)
  status: 'CONFIRMED' | 'APPROVED' | 'CONFLICT' | 'PENDING' | 'CANCELLED' | 'REJECTED' | 'AUTO_REJECTED';
  reservationMode?: ReservationMode; // 'SHARED' | 'DISRUPTIVE' (Default 'SHARED')
  workflowId?: string;
  currentWorkflowOrder?: number;
  currentApproverId?: string;
  currentApproverName?: string;
  rejectionReason?: string;
  rejectedAt?: string;
  rejectionType?: 'MANUAL' | 'AUTO';
  auditHistory?: BookingAuditEntry[];
  isVisible?: boolean;
  createdBy?: string;
  ownerId?: string;
  assignedUserId?: string;
}

export type ReleaseRisk = 'LOW RISK' | 'MEDIUM RISK' | 'HIGH RISK';
export type ReleaseRiskType = 'Major' | 'Minor' | 'Patch';
export type ReleaseStatus = 'SCHEDULED' | 'IN_PROGRESS' | 'DEPLOYED' | 'FAILED' | 'COMPLETED' | 'CANCELLED';

export interface TestPhase {
  id: string;
  name: string; // e.g. UNIT, UAT, SIT, QA, ST, PRE PROD, PROD, Performance
  displayName: string;
  description?: string;
  color: string; // Hex color e.g. #3B82F6
  isSystem: boolean;
  isActive: boolean;
  displayOrder: number;
  createdBy?: string;
  createdAt?: string;
  updatedBy?: string;
  updatedAt?: string;
}

export interface ReleasePhase {
  id: string;
  releaseId: string;
  testPhaseId?: string;
  phaseName: string;
  color?: string;
  environmentId?: string;
  environmentName?: string;
  startDate: string; // ISO string / YYYY-MM-DDTHH:mm:ss
  endDate: string;   // ISO string / YYYY-MM-DDTHH:mm:ss
  sequence: number;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'ON_HOLD' | 'SKIPPED' | string;
  remarks?: string;
  createdBy?: string;
  updatedBy?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Release {
  id: string;
  name: string;
  
  // Hierarchy
  buId?: string;
  businessUnit?: string;
  projectId?: string;
  project?: string;
  applicationId?: string;
  application?: string;

  // Risk & Manager
  riskType?: ReleaseRiskType | string;
  risk: ReleaseRisk;
  releaseManagerId?: string;
  releaseManager?: string;

  // Timeline
  startDate?: string; // YYYY-MM-DDTHH:mm:ss
  endDate?: string;   // YYYY-MM-DDTHH:mm:ss
  scheduledDate: string; // YYYY-MM-DDTHH:mm:ss (for compatibility)

  // Details
  repositoryUrl?: string;
  remarks?: string;

  // Child Phases
  phases?: ReleasePhase[];

  // Legacy compatibility fields
  version: string;
  environmentId: string;
  environmentName: string;
  lead: string;
  changeRef: string;
  status: ReleaseStatus;
  isVisible?: boolean;
  createdBy?: string;
  leadId?: string;
  createdAt?: string;
  updatedAt?: string;
}

export type ReleaseConflictType = 'APPLICATION_OVERLAP' | 'ENVIRONMENT_PHASE_CONTENTION' | 'ENVIRONMENT_BOOKING_COLLISION';
export type ReleaseConflictSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'WARNING';

export interface ReleaseConflictItem {
  id: string;
  conflictType: ReleaseConflictType | string;
  title: string;
  conflictingEntityName: string;
  conflictingItemName: string;
  startDate: string;
  endDate: string;
  severity: ReleaseConflictSeverity;
  detail: string;
}

export interface ReleaseRecommendedPhaseItem {
  testPhaseId?: string;
  phaseName?: string;
  color?: string;
  startDate: string;
  endDate: string;
  environmentId?: string;
  environmentName?: string;
}

export interface ReleaseDateRecommendation {
  id: string;
  startDate: string;
  endDate: string;
  durationDays: number;
  shiftedDays: number;
  confidenceScore: number;
  reasoning: string;
  phases: ReleaseRecommendedPhaseItem[];
}

export interface ReleaseConflictCheckResponse {
  hasConflicts: boolean;
  conflictCount: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'VERY_HIGH' | 'CRITICAL';
  conflictProbability: number;
  conflicts: ReleaseConflictItem[];
  recommendations: ReleaseDateRecommendation[];
  summary: string;
}


export interface ReleaseConflictCheckRequest {
  name?: string;
  buId?: string;
  businessUnit?: string;
  projectId?: string;
  project?: string;
  applicationId?: string;
  application?: string;
  riskType?: string;
  releaseManagerId?: string;
  startDate: string;
  endDate: string;
  environmentId?: string;
  phases?: Array<{
    testPhaseId?: string;
    phaseName?: string;
    color?: string;
    startDate?: string;
    endDate?: string;
    environmentId?: string;
    environmentName?: string;
  }>;
  excludeReleaseId?: string;
}


export type IncidentSeverity = 'SEV1' | 'SEV2' | 'SEV3' | 'SEV4';
export type IncidentStatus = 'OPEN' | 'INVESTIGATING' | 'RESOLVED';

export interface Incident {
  id: string; // Ticket e.g. INC-88252
  title: string;
  severity: IncidentSeverity;
  environmentId: string;
  environmentName: string;
  assignee: string;
  status: IncidentStatus;
  openedAt: string; // ISO datetime string with HH:mm:ss
  description?: string;
  isVisible?: boolean;
  createdBy?: string;
  assigneeId?: string;
}

export interface Runbook {
  id: string;
  name: string;
  category: string;
  estimatedTimeMinutes: number;
  lastExecuted: string;
  targetEnvironmentId?: string;
  steps: string[];
}

export interface OverviewMetrics {
  totalEnvironments: number;
  healthyEnvironments: number;
  activeBookings: number;
  utilizationRate: number;
  openIncidents: number;
  downEnvironmentsCount: number;
  upcomingReleases: number;
  trackedReleasesCount: number;
  cpuAverage: number;
  memoryAverage: number;
  storageAverage: number;
}

export interface EmailNotification {
  id: string;
  bookingId: string;
  notificationType: string;
  stepOrder?: number;
  recipientTo: string;
  recipientCc?: string;
  subject: string;
  body: string;
  status: 'PENDING' | 'SENT' | 'FAILED';
  sentAt?: string;
  errorMessage?: string;
  retryCount: number;
  createdAt: string;
}
