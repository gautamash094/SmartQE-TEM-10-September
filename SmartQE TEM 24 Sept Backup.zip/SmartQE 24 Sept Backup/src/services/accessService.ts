import { Role, roleService } from './roleService';
import { User } from './userService';
import { fetchApi } from './apiClient';

export interface ApplicationScreen {
  id: string;
  key: string;
  name: string;
  route: string;
  parentKey?: string | null;
  category: string;
  displayOrder: number;
  isActive: boolean;
}

export interface RoleScreenAccessItem {
  screenId: string;
  screenKey: string;
  screenName: string;
  route: string;
  parentKey?: string | null;
  category: string;
  displayOrder: number;
  hasAccess: boolean;
}

export interface RoleAccessData {
  roleId: string;
  roleName: string;
  isSuperAdmin: boolean;
  screens: RoleScreenAccessItem[];
}

export const INITIAL_APPLICATION_SCREENS: ApplicationScreen[] = [
  // Core
  { id: 'scr-dashboard', key: 'dashboard', name: 'TEM Dashboard', route: '/tem-dashboard', parentKey: null, category: 'Core', displayOrder: 1, isActive: true },
  { id: 'scr-entity-mgmt', key: 'entity_management', name: 'Entity Management', route: '/entity-management', parentKey: null, category: 'Core', displayOrder: 2, isActive: true },
  { id: 'scr-env-details', key: 'environment_details', name: 'Environment Details', route: '/environment-details', parentKey: null, category: 'Core', displayOrder: 3, isActive: true },

  // Operations
  { id: 'scr-worklist', key: 'worklist', name: 'Worklist', route: '/worklist', parentKey: null, category: 'Operations', displayOrder: 4, isActive: true },
  { id: 'scr-bookings', key: 'bookings', name: 'Bookings Grid', route: '/bookings', parentKey: null, category: 'Operations', displayOrder: 5, isActive: true },
  { id: 'scr-releases', key: 'releases', name: 'Releases', route: '/releases', parentKey: null, category: 'Operations', displayOrder: 6, isActive: true },
  { id: 'scr-release-calendar', key: 'release_calendar', name: 'Release Calendar', route: '/releases/calendar', parentKey: 'releases', category: 'Operations', displayOrder: 6.5, isActive: true },
  { id: 'scr-incidents', key: 'incidents', name: 'Incidents', route: '/incidents', parentKey: null, category: 'Operations', displayOrder: 7, isActive: true },

  // Provisioning
  { id: 'scr-provisioning', key: 'provisioning', name: 'Environment Provisioning', route: '/provisioning', parentKey: null, category: 'Provisioning', displayOrder: 8, isActive: true },
  { id: 'scr-prov-requests', key: 'provisioning_requests', name: 'Provisioning Requests', route: '/provisioning/requests', parentKey: 'provisioning', category: 'Provisioning', displayOrder: 9, isActive: true },
  { id: 'scr-prov-new', key: 'provisioning_new', name: 'New Request (Wizard)', route: '/provisioning/new', parentKey: 'provisioning', category: 'Provisioning', displayOrder: 10, isActive: true },
  { id: 'scr-prov-templates', key: 'provisioning_templates', name: 'Provisioning Templates', route: '/provisioning/templates', parentKey: 'provisioning', category: 'Provisioning', displayOrder: 11, isActive: true },
  { id: 'scr-prov-history', key: 'provisioning_history', name: 'Provisioning History', route: '/provisioning/history', parentKey: 'provisioning', category: 'Provisioning', displayOrder: 12, isActive: true },

  // Resource Management & Children
  { id: 'scr-res-mgmt', key: 'resource_management', name: 'Resource Management', route: '/inventory', parentKey: null, category: 'Resources', displayOrder: 13, isActive: true },
  { id: 'scr-inventory', key: 'inventory', name: 'Inventory Management', route: '/inventory', parentKey: 'resource_management', category: 'Resources', displayOrder: 14, isActive: true },
  { id: 'scr-topology', key: 'topology', name: 'Environment Topology', route: '/environment-topology', parentKey: 'resource_management', category: 'Resources', displayOrder: 15, isActive: true },
  { id: 'scr-monitoring', key: 'monitoring', name: 'Environment Monitoring', route: '/environment-monitoring', parentKey: 'resource_management', category: 'Resources', displayOrder: 16, isActive: true },
  { id: 'scr-predictive', key: 'predictive_demand', name: 'AI Predictive Demand', route: '/ai-predictive-demand', parentKey: 'resource_management', category: 'Resources', displayOrder: 17, isActive: true },

  // Settings & Children
  { id: 'scr-settings', key: 'settings', name: 'Settings', route: '/settings', parentKey: null, category: 'Administration', displayOrder: 18, isActive: true },
  { id: 'scr-settings-users', key: 'settings_users', name: 'User Management', route: '/settings/users', parentKey: 'settings', category: 'Administration', displayOrder: 19, isActive: true },
  { id: 'scr-settings-roles', key: 'settings_roles', name: 'Role Management', route: '/settings/roles', parentKey: 'settings', category: 'Administration', displayOrder: 20, isActive: true },
  { id: 'scr-settings-access', key: 'settings_access', name: 'Access Management', route: '/settings/access', parentKey: 'settings', category: 'Administration', displayOrder: 21, isActive: true },
  { id: 'scr-settings-user-groups', key: 'settings_user_groups', name: 'User Group Management', route: '/settings/user-groups', parentKey: 'settings', category: 'Administration', displayOrder: 22, isActive: true },
  { id: 'scr-settings-workflow', key: 'settings_define_workflow', name: 'Define Workflow', route: '/settings/define-workflow', parentKey: 'settings', category: 'Administration', displayOrder: 23, isActive: true },

  // Integrations & Automation
  { id: 'scr-integrations', key: 'integrations', name: 'External Integrations', route: '/external-integrations', parentKey: null, category: 'Advanced', displayOrder: 24, isActive: true },
  { id: 'scr-runbooks', key: 'runbooks', name: 'Runbooks', route: '/runbooks', parentKey: null, category: 'Advanced', displayOrder: 25, isActive: true },
];

const ACCESS_STORAGE_KEY = 'smartqe_tem_role_access_v2';

function loadFromStorage<T>(key: string, defaults: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed) return parsed;
    }
  } catch {}
  return defaults;
}

function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {}
}

export const accessService = {
  async getScreens(): Promise<ApplicationScreen[]> {
    try {
      const apiData = await fetchApi<any[]>('/access/screens');
      if (apiData && Array.isArray(apiData) && apiData.length > 0) {
        return apiData.map((s: any) => ({
          id: s.id,
          key: s.key,
          name: s.name,
          route: s.route,
          parentKey: s.parent_key || s.parentKey,
          category: s.category || 'Core',
          displayOrder: s.display_order ?? s.displayOrder ?? 1,
          isActive: s.is_active ?? s.isActive ?? true,
        }));
      }
    } catch {}

    return INITIAL_APPLICATION_SCREENS;
  },

  async getRoleAccess(roleId: string): Promise<RoleAccessData> {
    try {
      const apiData = await fetchApi<any>(`/access/roles/${roleId}`);
      if (apiData) {
        return {
          roleId: apiData.role_id || apiData.roleId,
          roleName: apiData.role_name || apiData.roleName,
          isSuperAdmin: apiData.is_super_admin ?? apiData.isSuperAdmin ?? false,
          screens: (apiData.screens || []).map((s: any) => ({
            screenId: s.screen_id || s.screenId,
            screenKey: s.screen_key || s.screenKey,
            screenName: s.screen_name || s.screenName,
            route: s.route,
            parentKey: s.parent_key || s.parentKey,
            category: s.category || 'Core',
            displayOrder: s.display_order ?? s.displayOrder ?? 1,
            hasAccess: s.has_access ?? s.hasAccess ?? false,
          })),
        };
      }
    } catch {}

    const allRoles = await roleService.getRoles();
    const role = allRoles.find((r) => r.id === roleId);
    const roleName = role?.name || 'Unknown Role';
    const isSuperAdmin = roleName.toLowerCase().trim() === 'super admin';

    const screens = await this.getScreens();
    const storageMap = loadFromStorage<Record<string, string[]>>(ACCESS_STORAGE_KEY, {});
    const allowedScreenIds = storageMap[roleId] !== undefined ? storageMap[roleId] : (isSuperAdmin ? screens.map((s) => s.id) : []);

    return {
      roleId,
      roleName,
      isSuperAdmin,
      screens: screens.map((s) => ({
        screenId: s.id,
        screenKey: s.key,
        screenName: s.name,
        route: s.route,
        parentKey: s.parentKey,
        category: s.category,
        displayOrder: s.displayOrder,
        hasAccess: isSuperAdmin ? true : allowedScreenIds.includes(s.id),
      })),
    };
  },

  async saveRoleAccess(roleId: string, screenIds: string[]): Promise<RoleAccessData> {
    const allRoles = await roleService.getRoles();
    const role = allRoles.find((r) => r.id === roleId);
    if (role && role.name.toLowerCase().trim() === 'super admin') {
      throw new Error('Super Admin role permanently maintains full access to all application screens and cannot be modified.');
    }

    try {
      const apiData = await fetchApi<any>(`/access/roles/${roleId}`, {
        method: 'PUT',
        body: JSON.stringify({ screen_ids: screenIds }),
      });

      if (apiData) {
        return this.getRoleAccess(roleId);
      }
    } catch (err: any) {
      if (err.message && !err.message.includes('Failed to fetch')) {
        throw err;
      }
    }

    const storageMap = loadFromStorage<Record<string, string[]>>(ACCESS_STORAGE_KEY, {});
    storageMap[roleId] = screenIds;
    saveToStorage(ACCESS_STORAGE_KEY, storageMap);

    return this.getRoleAccess(roleId);
  },

  async getEffectiveAllowedRoutes(userRoles?: { id: string; name: string }[]): Promise<string[]> {
    if (!userRoles || userRoles.length === 0) {
      return [];
    }

    const screens = await this.getScreens();
    const hasSuperAdmin = userRoles.some((r) => r.name.toLowerCase().trim() === 'super admin');
    if (hasSuperAdmin) {
      return screens.map((s) => s.route);
    }

    const allowedRoutes = new Set<string>();
    for (const r of userRoles) {
      const access = await this.getRoleAccess(r.id);
      access.screens.forEach((s) => {
        if (s.hasAccess) {
          allowedRoutes.add(s.route);
        }
      });
    }

    return Array.from(allowedRoutes);
  },

  getEffectiveAllowedRoutesLocal(userRoles?: { id: string; name: string }[]): string[] {
    if (!userRoles || userRoles.length === 0) {
      return [];
    }

    const screens = INITIAL_APPLICATION_SCREENS;
    const hasSuperAdmin = userRoles.some((r) => r.name.toLowerCase().trim() === 'super admin');
    if (hasSuperAdmin) {
      return screens.map((s) => s.route);
    }

    const storageMap = loadFromStorage<Record<string, string[]>>(ACCESS_STORAGE_KEY, {});
    const allowedRoutes = new Set<string>();

    for (const r of userRoles) {
      const allowedScreenIds = storageMap[r.id] !== undefined ? storageMap[r.id] : [];
      screens.forEach((s) => {
        if (allowedScreenIds.includes(s.id)) {
          allowedRoutes.add(s.route);
        }
      });
    }

    return Array.from(allowedRoutes);
  },
};
