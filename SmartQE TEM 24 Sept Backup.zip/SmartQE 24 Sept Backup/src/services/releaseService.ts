import { Release, ReleasePhase } from '../types';
import { fetchApi } from './apiClient';

const mapReleaseDto = (r: any): Release => ({
  id: r.id,
  name: r.name,
  buId: r.bu_id || r.buId,
  businessUnit: r.business_unit || r.businessUnit,
  projectId: r.project_id || r.projectId,
  project: r.project_name || r.project,
  applicationId: r.application_id || r.applicationId,
  application: r.application_name || r.application,
  riskType: r.risk_type || r.riskType || 'Major',
  risk: r.risk || 'LOW RISK',
  releaseManagerId: r.release_manager_id || r.releaseManagerId,
  releaseManager: r.release_manager_name || r.releaseManager || r.lead,
  startDate: r.start_date || r.startDate || r.scheduled_date || r.scheduledDate,
  endDate: r.end_date || r.endDate,
  scheduledDate: r.scheduled_date || r.scheduledDate || r.start_date || r.startDate,
  repositoryUrl: r.repository_url || r.repositoryUrl,
  remarks: r.remarks,
  phases: (r.phases || []).map(mapPhaseDto),
  version: r.version || 'v1.0.0',
  environmentId: r.environment_id || r.environmentId || 'env-all',
  environmentName: r.environment_name || r.environmentName || 'All Environments',
  lead: r.lead || r.release_manager_name || 'Release Lead',
  changeRef: r.change_ref || r.changeRef || 'CR-REL',
  status: r.status || 'SCHEDULED',
  isVisible: r.is_visible ?? r.isVisible ?? true,
  createdBy: r.created_by || r.createdBy,
  createdAt: r.created_at || r.createdAt,
  updatedAt: r.updated_at || r.updatedAt,
});

const mapPhaseDto = (p: any): ReleasePhase => ({
  id: p.id,
  releaseId: p.release_id || p.releaseId,
  testPhaseId: p.test_phase_id || p.testPhaseId,
  phaseName: p.phase_name || p.phaseName,
  color: p.color,
  environmentId: p.environment_id || p.environmentId,
  environmentName: p.environment_name || p.environmentName,
  startDate: p.start_date || p.startDate,
  endDate: p.end_date || p.endDate,
  sequence: p.sequence || 1,
  status: p.status || 'NOT_STARTED',
  remarks: p.remarks,
  createdBy: p.created_by || p.createdBy,
  updatedBy: p.updated_by || p.updatedBy,
  createdAt: p.created_at || p.createdAt,
  updatedAt: p.updated_at || p.updatedAt,
});

export const releaseService = {
  async getReleases(params?: { search?: string; buId?: string; projectId?: string; status?: string }): Promise<Release[]> {
    let query = '';
    if (params) {
      const q = new URLSearchParams();
      if (params.search) q.append('search', params.search);
      if (params.buId) q.append('buId', params.buId);
      if (params.projectId) q.append('projectId', params.projectId);
      if (params.status) q.append('status', params.status);
      query = `?${q.toString()}`;
    }

    const apiData = await fetchApi<any[]>(`/releases${query}`);
    if (apiData && Array.isArray(apiData)) {
      return apiData.map(mapReleaseDto);
    }
    return [];
  },

  async getReleaseById(id: string): Promise<Release | null> {
    const apiData = await fetchApi<any>(`/releases/${id}`);
    if (apiData) {
      return mapReleaseDto(apiData);
    }
    return null;
  },

  async createRelease(relData: Partial<Release> & { initialPhases?: Partial<ReleasePhase>[] }): Promise<Release> {
    const payload = {
      name: relData.name,
      bu_id: relData.buId,
      business_unit: relData.businessUnit,
      project_id: relData.projectId,
      project_name: relData.project,
      application_id: relData.applicationId,
      application_name: relData.application,
      risk_type: relData.riskType || 'Major',
      risk: relData.risk || 'LOW RISK',
      release_manager_id: relData.releaseManagerId,
      release_manager_name: relData.releaseManager,
      start_date: relData.startDate,
      end_date: relData.endDate,
      scheduled_date: relData.scheduledDate || relData.startDate,
      repository_url: relData.repositoryUrl,
      remarks: relData.remarks,
      version: relData.version || 'v1.0.0',
      environment_id: relData.environmentId || 'env-all',
      environment_name: relData.environmentName || 'All Environments',
      lead: relData.lead || relData.releaseManager || 'Release Lead',
      change_ref: relData.changeRef || 'CR-REL',
      status: relData.status || 'SCHEDULED',
      initial_phases: (relData.initialPhases || []).map((ph) => ({
        test_phase_id: ph.testPhaseId,
        phase_name: ph.phaseName,
        color: ph.color,
        environment_id: ph.environmentId,
        environment_name: ph.environmentName,
        start_date: ph.startDate,
        end_date: ph.endDate,
        sequence: ph.sequence || 1,
        status: ph.status || 'NOT_STARTED',
        remarks: ph.remarks,
      })),
    };

    const apiData = await fetchApi<any>('/releases', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    if (apiData) {
      return mapReleaseDto(apiData);
    }

    const newId = `rel-${Date.now()}`;
    return {
      id: newId,
      name: relData.name || 'Untitled Release',
      buId: relData.buId,
      businessUnit: relData.businessUnit,
      projectId: relData.projectId,
      project: relData.project,
      applicationId: relData.applicationId,
      application: relData.application,
      riskType: relData.riskType || 'Major',
      risk: relData.risk || 'LOW RISK',
      releaseManagerId: relData.releaseManagerId,
      releaseManager: relData.releaseManager || 'Release Manager',
      startDate: relData.startDate,
      endDate: relData.endDate,
      scheduledDate: relData.scheduledDate || relData.startDate || new Date().toISOString(),
      repositoryUrl: relData.repositoryUrl,
      remarks: relData.remarks,
      version: relData.version || 'v1.0.0',
      environmentId: relData.environmentId || 'env-all',
      environmentName: relData.environmentName || 'All Environments',
      lead: relData.lead || 'Release Lead',
      changeRef: relData.changeRef || 'CR-REL',
      status: (relData.status as any) || 'SCHEDULED',
      phases: (relData.initialPhases || []).map((p, idx) => ({
        id: `ph-${Date.now()}-${idx}`,
        releaseId: newId,
        testPhaseId: p.testPhaseId,
        phaseName: p.phaseName || 'Phase',
        color: p.color || '#3B82F6',
        environmentId: p.environmentId,
        environmentName: p.environmentName,
        startDate: p.startDate || '',
        endDate: p.endDate || '',
        sequence: p.sequence || idx + 1,
        status: p.status || 'NOT_STARTED',
        remarks: p.remarks,
      })),
    };
  },

  async updateRelease(id: string, relData: Partial<Release>): Promise<Release> {
    const payload: any = {};
    if (relData.name !== undefined) payload.name = relData.name;
    if (relData.buId !== undefined) payload.bu_id = relData.buId;
    if (relData.businessUnit !== undefined) payload.business_unit = relData.businessUnit;
    if (relData.projectId !== undefined) payload.project_id = relData.projectId;
    if (relData.project !== undefined) payload.project_name = relData.project;
    if (relData.applicationId !== undefined) payload.application_id = relData.applicationId;
    if (relData.application !== undefined) payload.application_name = relData.application;
    if (relData.riskType !== undefined) payload.risk_type = relData.riskType;
    if (relData.risk !== undefined) payload.risk = relData.risk;
    if (relData.releaseManagerId !== undefined) payload.release_manager_id = relData.releaseManagerId;
    if (relData.releaseManager !== undefined) payload.release_manager_name = relData.releaseManager;
    if (relData.startDate !== undefined) payload.start_date = relData.startDate;
    if (relData.endDate !== undefined) payload.end_date = relData.endDate;
    if (relData.scheduledDate !== undefined) payload.scheduled_date = relData.scheduledDate;
    if (relData.repositoryUrl !== undefined) payload.repository_url = relData.repositoryUrl;
    if (relData.remarks !== undefined) payload.remarks = relData.remarks;
    if (relData.version !== undefined) payload.version = relData.version;
    if (relData.environmentId !== undefined) payload.environment_id = relData.environmentId;
    if (relData.environmentName !== undefined) payload.environment_name = relData.environmentName;
    if (relData.lead !== undefined) payload.lead = relData.lead;
    if (relData.changeRef !== undefined) payload.change_ref = relData.changeRef;
    if (relData.status !== undefined) payload.status = relData.status;

    const apiData = await fetchApi<any>(`/releases/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });

    if (apiData) {
      return mapReleaseDto(apiData);
    }
    return relData as Release;
  },

  async deleteRelease(id: string): Promise<boolean> {
    await fetchApi<any>(`/releases/${id}`, {
      method: 'DELETE',
    });
    return true;
  },

  // --- Phase Management ---
  async getReleasePhases(releaseId: string): Promise<ReleasePhase[]> {
    const apiData = await fetchApi<any[]>(`/releases/${releaseId}/phases`);
    if (apiData && Array.isArray(apiData)) {
      return apiData.map(mapPhaseDto);
    }
    return [];
  },

  async addReleasePhase(releaseId: string, phaseData: Partial<ReleasePhase>): Promise<ReleasePhase> {
    const payload = {
      test_phase_id: phaseData.testPhaseId,
      phase_name: phaseData.phaseName,
      color: phaseData.color,
      environment_id: phaseData.environmentId,
      environment_name: phaseData.environmentName,
      start_date: phaseData.startDate,
      end_date: phaseData.endDate,
      sequence: phaseData.sequence || 1,
      status: phaseData.status || 'NOT_STARTED',
      remarks: phaseData.remarks,
    };

    const apiData = await fetchApi<any>(`/releases/${releaseId}/phases`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    if (apiData) {
      return mapPhaseDto(apiData);
    }

    return {
      id: `ph-${Date.now()}`,
      releaseId,
      testPhaseId: phaseData.testPhaseId,
      phaseName: phaseData.phaseName || 'Phase',
      color: phaseData.color || '#3B82F6',
      environmentId: phaseData.environmentId,
      environmentName: phaseData.environmentName,
      startDate: phaseData.startDate || '',
      endDate: phaseData.endDate || '',
      sequence: phaseData.sequence || 1,
      status: phaseData.status || 'NOT_STARTED',
      remarks: phaseData.remarks,
    };
  },

  async updateReleasePhase(releaseId: string, phaseId: string, phaseData: Partial<ReleasePhase>): Promise<ReleasePhase> {
    const payload: any = {};
    if (phaseData.testPhaseId !== undefined) payload.test_phase_id = phaseData.testPhaseId;
    if (phaseData.phaseName !== undefined) payload.phase_name = phaseData.phaseName;
    if (phaseData.color !== undefined) payload.color = phaseData.color;
    if (phaseData.environmentId !== undefined) payload.environment_id = phaseData.environmentId;
    if (phaseData.environmentName !== undefined) payload.environment_name = phaseData.environmentName;
    if (phaseData.startDate !== undefined) payload.start_date = phaseData.startDate;
    if (phaseData.endDate !== undefined) payload.end_date = phaseData.endDate;
    if (phaseData.sequence !== undefined) payload.sequence = phaseData.sequence;
    if (phaseData.status !== undefined) payload.status = phaseData.status;
    if (phaseData.remarks !== undefined) payload.remarks = phaseData.remarks;

    const apiData = await fetchApi<any>(`/releases/${releaseId}/phases/${phaseId}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });

    if (apiData) {
      return mapPhaseDto(apiData);
    }

    return phaseData as ReleasePhase;
  },

  async deleteReleasePhase(releaseId: string, phaseId: string): Promise<boolean> {
    await fetchApi<any>(`/releases/${releaseId}/phases/${phaseId}`, {
      method: 'DELETE',
    });
    return true;
  },

  async reorderReleasePhases(releaseId: string, phases: { id: string; sequence: number }[]): Promise<ReleasePhase[]> {
    const apiData = await fetchApi<any[]>(`/releases/${releaseId}/phases/reorder`, {
      method: 'POST',
      body: JSON.stringify({ phases }),
    });

    if (apiData && Array.isArray(apiData)) {
      return apiData.map(mapPhaseDto);
    }
    return [];
  },

  async checkReleaseConflicts(req: any): Promise<any> {
    const payload = {
      name: req.name,
      bu_id: req.buId,
      business_unit: req.businessUnit,
      project_id: req.projectId,
      project: req.project,
      application_id: req.applicationId,
      application: req.application,
      risk_type: req.riskType || 'Major',
      release_manager_id: req.releaseManagerId,
      start_date: req.startDate,
      end_date: req.endDate,
      environment_id: req.environmentId,
      phases: (req.phases || []).map((p: any) => ({
        test_phase_id: p.testPhaseId,
        phase_name: p.phaseName,
        color: p.color,
        start_date: p.startDate,
        end_date: p.endDate,
        environment_id: p.environmentId,
        environment_name: p.environmentName,
      })),
      exclude_release_id: req.excludeReleaseId,
    };

    const res = await fetchApi<any>('/releases/check-conflicts', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    if (res) {
      return {
        hasConflicts: Boolean(res.has_conflicts ?? res.hasConflicts),
        conflictCount: res.conflict_count ?? res.conflictCount ?? 0,
        riskLevel: res.risk_level || res.riskLevel || 'LOW',
        conflictProbability: res.conflict_probability ?? res.conflictProbability ?? 0,
        conflicts: (res.conflicts || []).map((c: any) => ({
          id: c.id,
          conflictType: c.conflict_type || c.conflictType,
          title: c.title,
          conflictingEntityName: c.conflicting_entity_name || c.conflictingEntityName,
          conflictingItemName: c.conflicting_item_name || c.conflictingItemName,
          startDate: c.start_date || c.startDate,
          endDate: c.end_date || c.endDate,
          severity: c.severity || 'HIGH',
          detail: c.detail,
        })),
        recommendations: (res.recommendations || []).map((r: any) => ({
          id: r.id,
          startDate: r.start_date || r.startDate,
          endDate: r.end_date || r.endDate,
          durationDays: r.duration_days ?? r.durationDays ?? 0,
          shiftedDays: r.shifted_days ?? r.shiftedDays ?? 0,
          confidenceScore: r.confidence_score ?? r.confidenceScore ?? 90,
          reasoning: r.reasoning,
          phases: (r.phases || []).map((rp: any) => ({
            testPhaseId: rp.test_phase_id || rp.testPhaseId,
            phaseName: rp.phase_name || rp.phaseName,
            color: rp.color,
            startDate: rp.start_date || rp.startDate,
            endDate: rp.end_date || rp.endDate,
            environmentId: rp.environment_id || rp.environmentId,
            environmentName: rp.environment_name || rp.environmentName,
          })),
        })),
        summary: res.summary || '',
      };
    }

    return {
      hasConflicts: false,
      conflictCount: 0,
      riskLevel: 'LOW',
      conflictProbability: 0,
      conflicts: [],
      recommendations: [],
      summary: 'No conflicts detected.',
    };
  },
};

