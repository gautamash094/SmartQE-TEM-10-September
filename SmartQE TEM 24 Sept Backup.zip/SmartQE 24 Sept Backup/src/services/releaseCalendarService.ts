import { fetchApi } from './apiClient';
import {
  CalendarDisplayScope,
  CalendarTimePeriod,
  ReleaseCalendarData,
  ReleaseCalendarGroup,
  ReleaseCalendarRelease,
  ReleaseCalendarPhase,
  ReleaseCalendarConflict,
  ReleaseCalendarSummary,
} from '../types/releaseCalendar';
import { Release, TestPhase } from '../types';

interface GetCalendarParams {
  viewBy: CalendarDisplayScope;
  year: number;
  period: CalendarTimePeriod;
  month?: number;
  quarter?: number;
  buId?: string;
  releaseId?: string;
  applicationId?: string;
  environmentId?: string;
}

const mapBackendCalendarResponse = (apiData: any): ReleaseCalendarData => {
  return {
    viewBy: apiData.view_by || apiData.viewBy || 'application',
    year: apiData.year || 2026,
    period: apiData.period || 'month',
    month: apiData.month,
    quarter: apiData.quarter,
    dateRange: {
      startDate: apiData.date_range?.start_date || apiData.dateRange?.startDate || '',
      endDate: apiData.date_range?.end_date || apiData.dateRange?.endDate || '',
    },
    items: (apiData.items || []).map((g: any): ReleaseCalendarGroup => ({
      groupKey: g.group_key || g.groupKey,
      groupName: g.group_name || g.groupName,
      groupType: g.group_type || g.groupType,
      businessUnit: g.business_unit || g.businessUnit,
      projectId: g.project_id || g.projectId,
      projectName: g.project_name || g.projectName,
      releases: (g.releases || []).map((r: any): ReleaseCalendarRelease => ({
        releaseId: r.release_id || r.releaseId,
        releaseName: r.release_name || r.releaseName,
        version: r.version || 'v1.0.0',
        riskType: r.risk_type || r.riskType || 'Major',
        risk: r.risk || 'LOW RISK',
        status: r.status || 'SCHEDULED',
        releaseManager: r.release_manager || r.releaseManager,
        buId: r.bu_id || r.buId,
        businessUnit: r.business_unit || r.businessUnit,
        projectId: r.project_id || r.projectId,
        projectName: r.project_name || r.projectName,
        applicationId: r.application_id || r.applicationId,
        applicationName: r.application_name || r.applicationName,
        environmentId: r.environment_id || r.environmentId,
        environmentName: r.environment_name || r.environmentName,
        startDate: r.start_date || r.startDate,
        endDate: r.end_date || r.endDate,
        repositoryUrl: r.repository_url || r.repositoryUrl,
        remarks: r.remarks,
        phases: (r.phases || []).map((p: any): ReleaseCalendarPhase => ({
          phaseId: p.phase_id || p.phaseId || p.id,
          phaseName: p.phase_name || p.phaseName,
          testPhaseId: p.test_phase_id || p.testPhaseId,
          color: p.color,
          environmentId: p.environment_id || p.environmentId,
          environmentName: p.environment_name || p.environmentName,
          startDate: p.start_date || p.startDate,
          endDate: p.end_date || p.endDate,
          sequence: p.sequence || 1,
          status: p.status || 'NOT_STARTED',
          remarks: p.remarks,
        })),
      })),
    })),
    conflicts: (apiData.conflicts || []).map((c: any): ReleaseCalendarConflict => ({
      id: c.id,
      type: c.type,
      entityId: c.entity_id || c.entityId,
      entityName: c.entity_name || c.entityName,
      releaseA: {
        releaseId: c.release_a?.release_id || c.releaseA?.releaseId,
        releaseName: c.release_a?.release_name || c.releaseA?.releaseName,
        phaseId: c.release_a?.phase_id || c.releaseA?.phaseId,
        phaseName: c.release_a?.phase_name || c.releaseA?.phaseName,
        startDate: c.release_a?.start_date || c.releaseA?.startDate,
        endDate: c.release_a?.end_date || c.releaseA?.endDate,
      },
      releaseB: {
        releaseId: c.release_b?.release_id || c.releaseB?.releaseId,
        releaseName: c.release_b?.release_name || c.releaseB?.releaseName,
        phaseId: c.release_b?.phase_id || c.releaseB?.phaseId,
        phaseName: c.release_b?.phase_name || c.releaseB?.phaseName,
        startDate: c.release_b?.start_date || c.releaseB?.startDate,
        endDate: c.release_b?.end_date || c.releaseB?.endDate,
      },
      conflictStartDate: c.conflict_start_date || c.conflictStartDate,
      conflictEndDate: c.conflict_end_date || c.conflictEndDate,
      severity: c.severity || 'HIGH',
      message: c.message || '',
    })),
    summary: {
      totalReleases: apiData.summary?.total_releases ?? apiData.summary?.totalReleases ?? 0,
      totalPhases: apiData.summary?.total_phases ?? apiData.summary?.totalPhases ?? 0,
      activeReleases: apiData.summary?.active_releases ?? apiData.summary?.activeReleases ?? 0,
      conflictsCount: apiData.summary?.conflicts_count ?? apiData.summary?.conflictsCount ?? 0,
    },
  };
};

export const releaseCalendarService = {
  async getCalendarTimeline(params: GetCalendarParams): Promise<ReleaseCalendarData | null> {
    try {
      const q = new URLSearchParams();
      q.append('viewBy', params.viewBy);
      q.append('year', String(params.year));
      q.append('period', params.period);
      if (params.month !== undefined) q.append('month', String(params.month));
      if (params.quarter !== undefined) q.append('quarter', String(params.quarter));
      if (params.buId && params.buId !== 'ALL') q.append('buId', params.buId);
      if (params.releaseId && params.releaseId !== 'ALL') q.append('releaseId', params.releaseId);
      if (params.applicationId && params.applicationId !== 'ALL') q.append('applicationId', params.applicationId);
      if (params.environmentId && params.environmentId !== 'ALL') q.append('environmentId', params.environmentId);

      const apiData = await fetchApi<any>(`/releases/calendar?${q.toString()}`);
      if (apiData) {
        return mapBackendCalendarResponse(apiData);
      }
    } catch (err) {
      console.warn('Release calendar API fetch fallback:', err);
    }
    return null;
  },

  /**
   * Client-side aggregation fallback for offline or synchronized state
   */
  computeClientCalendarData(
    releases: Release[],
    testPhases: TestPhase[],
    params: GetCalendarParams
  ): ReleaseCalendarData {
    const { viewBy, year, period, month = 9, quarter = 3 } = params;

    let startDate: Date;
    let endDate: Date;

    if (period === 'month') {
      startDate = new Date(Date.UTC(year, month - 1, 1, 0, 0, 0));
      const lastDay = new Date(Date.UTC(year, month, 0)).getDate();
      endDate = new Date(Date.UTC(year, month - 1, lastDay, 23, 59, 59));
    } else if (period === 'quarter') {
      const startM = (quarter - 1) * 3;
      const endM = startM + 2;
      startDate = new Date(Date.UTC(year, startM, 1, 0, 0, 0));
      const lastDay = new Date(Date.UTC(year, endM + 1, 0)).getDate();
      endDate = new Date(Date.UTC(year, endM, lastDay, 23, 59, 59));
    } else {
      startDate = new Date(Date.UTC(year, 0, 1, 0, 0, 0));
      endDate = new Date(Date.UTC(year, 11, 31, 23, 59, 59));
    }

    const startMs = startDate.getTime();
    const endMs = endDate.getTime();

    const phaseColorMap = new Map<string, string>();
    testPhases.forEach((tp) => {
      phaseColorMap.set(tp.name.toLowerCase(), tp.color);
      phaseColorMap.set(tp.displayName.toLowerCase(), tp.color);
    });

    const getPhaseColor = (name: string, fallback?: string) => {
      if (fallback) return fallback;
      return phaseColorMap.get(name.toLowerCase()) || '#3B82F6';
    };

    // Filter releases by timeframe & filters
    const matchedReleases = releases.filter((r) => {
      if (params.buId && params.buId !== 'ALL' && r.businessUnit !== params.buId && r.buId !== params.buId) return false;
      if (params.releaseId && params.releaseId !== 'ALL' && r.id !== params.releaseId) return false;
      if (params.applicationId && params.applicationId !== 'ALL' && r.application !== params.applicationId && r.applicationId !== params.applicationId) return false;
      if (params.environmentId && params.environmentId !== 'ALL') {
        const matchesRelEnv = r.environmentName === params.environmentId || r.environmentId === params.environmentId;
        const matchesPhaseEnv = (r.phases || []).some((p) => p.environmentName === params.environmentId || p.environmentId === params.environmentId);
        if (!matchesRelEnv && !matchesPhaseEnv) return false;
      }

      const rStart = r.startDate ? new Date(r.startDate).getTime() : (r.scheduledDate ? new Date(r.scheduledDate).getTime() : 0);
      const rEnd = r.endDate ? new Date(r.endDate).getTime() : rStart;
      const phaseOverlaps = (r.phases || []).some((p) => {
        const pStart = p.startDate ? new Date(p.startDate).getTime() : 0;
        const pEnd = p.endDate ? new Date(p.endDate).getTime() : pStart;
        return pStart <= endMs && pEnd >= startMs;
      });

      const relOverlaps = rStart <= endMs && rEnd >= startMs;
      return relOverlaps || phaseOverlaps;
    });

    const groupMap = new Map<string, ReleaseCalendarGroup>();
    let totalPhasesCount = 0;
    let activeReleasesCount = 0;
    const nowMs = Date.now();

    matchedReleases.forEach((r) => {
      const rStart = r.startDate || r.scheduledDate;
      const rEnd = r.endDate || rStart;
      const rStartMs = rStart ? new Date(rStart).getTime() : 0;
      const rEndMs = rEnd ? new Date(rEnd).getTime() : 0;

      if ((r.status === 'IN_PROGRESS' || r.status === 'SCHEDULED') && rStartMs <= nowMs && rEndMs >= nowMs) {
        activeReleasesCount++;
      } else if (r.status === 'IN_PROGRESS') {
        activeReleasesCount++;
      }

      const calendarPhases: ReleaseCalendarPhase[] = (r.phases || []).map((p) => {
        totalPhasesCount++;
        return {
          phaseId: p.id,
          phaseName: p.phaseName,
          testPhaseId: p.testPhaseId,
          color: getPhaseColor(p.phaseName, p.color),
          environmentId: p.environmentId || r.environmentId,
          environmentName: p.environmentName || r.environmentName || 'All Environments',
          startDate: p.startDate,
          endDate: p.endDate,
          sequence: p.sequence || 1,
          status: p.status || 'NOT_STARTED',
          remarks: p.remarks,
        };
      });

      const calRel: ReleaseCalendarRelease = {
        releaseId: r.id,
        releaseName: r.name,
        version: r.version || 'v1.0.0',
        riskType: r.riskType || 'Major',
        risk: r.risk || 'LOW RISK',
        status: r.status || 'SCHEDULED',
        releaseManager: r.releaseManager || r.lead,
        buId: r.buId,
        businessUnit: r.businessUnit || 'General',
        projectId: r.projectId,
        projectName: r.project || 'Core Platform',
        applicationId: r.applicationId,
        applicationName: r.application || 'Core Service',
        environmentId: r.environmentId,
        environmentName: r.environmentName || 'All Environments',
        startDate: rStart,
        endDate: rEnd,
        repositoryUrl: r.repositoryUrl,
        remarks: r.remarks,
        phases: calendarPhases,
      };

      if (viewBy === 'application') {
        const appKey = r.applicationId || `app-${(r.application || 'unassigned').toLowerCase().replace(/\s+/g, '-')}`;
        const appName = r.application || 'Unassigned Application';
        if (!groupMap.has(appKey)) {
          groupMap.set(appKey, {
            groupKey: appKey,
            groupName: appName,
            groupType: 'application',
            businessUnit: r.businessUnit,
            projectId: r.projectId,
            projectName: r.project,
            releases: [],
          });
        }
        groupMap.get(appKey)!.releases.push(calRel);
      } else {
        const envSet = new Set<string>();
        calendarPhases.forEach((p) => {
          if (p.environmentName) envSet.add(p.environmentName);
        });
        if (envSet.size === 0) {
          envSet.add(r.environmentName || 'All Environments');
        }

        envSet.forEach((envName) => {
          const envKey = `env-${envName.toLowerCase().replace(/\s+/g, '-')}`;
          if (!groupMap.has(envKey)) {
            groupMap.set(envKey, {
              groupKey: envKey,
              groupName: envName,
              groupType: 'environment',
              businessUnit: r.businessUnit,
              projectId: r.projectId,
              projectName: r.project,
              releases: [],
            });
          }
          const envPhases = calendarPhases.filter((p) => p.environmentName === envName);
          groupMap.get(envKey)!.releases.push({
            ...calRel,
            phases: envPhases.length > 0 ? envPhases : calRel.phases,
          });
        });
      }
    });

    const items = Array.from(groupMap.values());

    // Detect conflicts
    const conflicts: ReleaseCalendarConflict[] = [];
    let conflictIdx = 1;

    if (viewBy === 'application') {
      items.forEach((g) => {
        const relList = g.releases;
        for (let i = 0; i < relList.length; i++) {
          for (let j = i + 1; j < relList.length; j++) {
            const rA = relList[i];
            const rB = relList[j];
            if (rA.startDate && rA.endDate && rB.startDate && rB.endDate) {
              const aStart = new Date(rA.startDate).getTime();
              const aEnd = new Date(rA.endDate).getTime();
              const bStart = new Date(rB.startDate).getTime();
              const bEnd = new Date(rB.endDate).getTime();
              const cStart = Math.max(aStart, bStart);
              const cEnd = Math.min(aEnd, bEnd);
              if (cStart <= cEnd) {
                conflicts.push({
                  id: `conf-app-${conflictIdx++}`,
                  type: 'application',
                  entityId: g.groupKey,
                  entityName: g.groupName,
                  releaseA: {
                    releaseId: rA.releaseId,
                    releaseName: rA.releaseName,
                    startDate: rA.startDate,
                    endDate: rA.endDate,
                  },
                  releaseB: {
                    releaseId: rB.releaseId,
                    releaseName: rB.releaseName,
                    startDate: rB.startDate,
                    endDate: rB.endDate,
                  },
                  conflictStartDate: new Date(cStart).toISOString(),
                  conflictEndDate: new Date(cEnd).toISOString(),
                  severity: rA.riskType === 'Major' || rB.riskType === 'Major' ? 'HIGH' : 'MEDIUM',
                  message: `Releases "${rA.releaseName}" and "${rB.releaseName}" run concurrently on Application "${g.groupName}".`,
                });
              }
            }
          }
        }
      });
    } else {
      items.forEach((g) => {
        const phaseList: { release: ReleaseCalendarRelease; phase: ReleaseCalendarPhase }[] = [];
        g.releases.forEach((r) => {
          r.phases.forEach((p) => {
            phaseList.push({ release: r, phase: p });
          });
        });

        for (let i = 0; i < phaseList.length; i++) {
          for (let j = i + 1; j < phaseList.length; j++) {
            const itemA = phaseList[i];
            const itemB = phaseList[j];
            if (itemA.release.releaseId !== itemB.release.releaseId) {
              const aStart = new Date(itemA.phase.startDate).getTime();
              const aEnd = new Date(itemA.phase.endDate).getTime();
              const bStart = new Date(itemB.phase.startDate).getTime();
              const bEnd = new Date(itemB.phase.endDate).getTime();
              const cStart = Math.max(aStart, bStart);
              const cEnd = Math.min(aEnd, bEnd);
              if (cStart <= cEnd) {
                conflicts.push({
                  id: `conf-env-${conflictIdx++}`,
                  type: 'environment',
                  entityId: g.groupKey,
                  entityName: g.groupName,
                  releaseA: {
                    releaseId: itemA.release.releaseId,
                    releaseName: itemA.release.releaseName,
                    phaseId: itemA.phase.phaseId,
                    phaseName: itemA.phase.phaseName,
                    startDate: itemA.phase.startDate,
                    endDate: itemA.phase.endDate,
                  },
                  releaseB: {
                    releaseId: itemB.release.releaseId,
                    releaseName: itemB.release.releaseName,
                    phaseId: itemB.phase.phaseId,
                    phaseName: itemB.phase.phaseName,
                    startDate: itemB.phase.startDate,
                    endDate: itemB.phase.endDate,
                  },
                  conflictStartDate: new Date(cStart).toISOString(),
                  conflictEndDate: new Date(cEnd).toISOString(),
                  severity: 'HIGH',
                  message: `Environment "${g.groupName}" contention: "${itemA.release.releaseName}" (${itemA.phase.phaseName}) and "${itemB.release.releaseName}" (${itemB.phase.phaseName}) are scheduled simultaneously.`,
                });
              }
            }
          }
        }
      });
    }

    return {
      viewBy,
      year,
      period,
      month,
      quarter,
      dateRange: {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      },
      items,
      conflicts,
      summary: {
        totalReleases: matchedReleases.length,
        totalPhases: totalPhasesCount,
        activeReleases: activeReleasesCount,
        conflictsCount: conflicts.length,
      },
    };
  },
};
