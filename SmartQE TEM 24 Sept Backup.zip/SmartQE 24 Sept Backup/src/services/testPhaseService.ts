import { TestPhase } from '../types';
import { fetchApi } from './apiClient';

export const DEFAULT_TEST_PHASES: TestPhase[] = [];

const LOCAL_STORAGE_KEY = 'smartqe_tem_test_phases';

function getLocalPhases(): TestPhase[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return [];
}

function saveLocalPhases(phases: TestPhase[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(phases));
  } catch {}
}

export const testPhaseService = {
  /**
   * Fetch system-defined Test Phases master data from the backend.
   * Ordered by displayOrder and filtered to active records.
   */
  async getTestPhases(onlyActive: boolean = true): Promise<TestPhase[]> {
    try {
      const query = onlyActive ? '?only_active=true' : '';
      const apiData = await fetchApi<any[]>(`/test-phases${query}`);
      if (apiData && Array.isArray(apiData) && apiData.length > 0) {
        const mapped = apiData
          .map((p) => ({
            id: String(p.id),
            name: p.name,
            displayName: p.display_name || p.displayName || p.name,
            description: p.description || '',
            color: p.color || '#3B82F6',
            isSystem: Boolean(p.is_system ?? p.isSystem ?? true),
            isActive: Boolean(p.is_active ?? p.isActive ?? true),
            displayOrder: Number(p.display_order ?? p.displayOrder ?? 1),
            createdBy: p.created_by || p.createdBy,
            createdAt: p.created_at || p.createdAt,
            updatedBy: p.updated_by || p.updatedBy,
            updatedAt: p.updated_at || p.updatedAt,
          }))
          .sort((a, b) => a.displayOrder - b.displayOrder);
        saveLocalPhases(mapped);
        return onlyActive ? mapped.filter((p) => p.isActive) : mapped;
      }
    } catch (err) {
      console.warn('Failed to fetch test phases from API, using fallback cache:', err);
    }
    const local = getLocalPhases().sort((a, b) => (a.displayOrder || 1) - (b.displayOrder || 1));
    return onlyActive ? local.filter((p) => p.isActive) : local;
  },
};

