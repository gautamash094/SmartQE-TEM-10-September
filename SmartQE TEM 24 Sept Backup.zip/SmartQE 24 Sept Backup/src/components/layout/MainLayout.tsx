import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { ToastContainer } from '../ui/ToastContainer';

interface MainLayoutProps {
  children: React.ReactNode;
}

const SIDEBAR_COLLAPSED_STORAGE_KEY = 'smartqe_tem_sidebar_collapsed_v1';

export const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState<boolean>(false);
  const [isCollapsed, setIsCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem(SIDEBAR_COLLAPSED_STORAGE_KEY) === 'true';
    } catch {
      return false;
    }
  });

  const toggleSidebar = () => {
    if (typeof window !== 'undefined' && window.innerWidth < 1024) {
      setMobileOpen((prev) => !prev);
    } else {
      setIsCollapsed((prev) => {
        const next = !prev;
        try {
          localStorage.setItem(SIDEBAR_COLLAPSED_STORAGE_KEY, String(next));
        } catch {}
        return next;
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col relative">
      {/* 1. Permanent Brand Logo Header & Collapsible Sidebar Menu */}
      <Sidebar
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
        isCollapsed={isCollapsed}
      />

      {/* 2. Top Header Bar - Fixed at top of screen (non-scrollable) */}
      <div
        className={`fixed top-0 left-0 right-0 z-40 h-16 transition-all duration-300 ease-in-out ${
          isCollapsed ? 'pl-0' : 'pl-0 lg:pl-64'
        }`}
      >
        <Header
          isSidebarCollapsed={isCollapsed}
          onToggleSidebar={toggleSidebar}
        />
      </div>

      {/* 3. Main Content Area - Starts below fixed header (pt-16), smoothly shifts right on desktop */}
      <div
        className={`flex-1 pt-16 transition-all duration-300 ease-in-out ${
          isCollapsed ? 'lg:pl-0' : 'lg:pl-64'
        }`}
      >
        <main className="p-4 md:p-6 lg:p-8 max-w-[1700px] w-full mx-auto min-w-0">{children}</main>
      </div>

      {/* Toast Notification Container */}
      <ToastContainer />
    </div>
  );
};
