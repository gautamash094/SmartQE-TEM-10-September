import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Modal } from '../ui/Modal';
import { useTEM } from '../../context/TEMContext';
import {
  Release,
  ReleasePhase,
  ReleaseRiskType,
  ReleaseRisk,
  ReleaseConflictCheckResponse,
  ReleaseDateRecommendation,
} from '../../types';
import { DateTimePicker } from '../common/DateTimePicker';
import { ButtonLoader } from '../common/ButtonLoader';
import { userService, User } from '../../services/userService';
import { releaseService } from '../../services/releaseService';
import {
  Plus,
  Trash2,
  Calendar,
  GitFork,
  Link as LinkIcon,
  AlertCircle,
  Layers,
  X,
  BrainCircuit,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  CheckCircle2,
  Zap,
  AlertTriangle,
  RefreshCw,
} from 'lucide-react';

const formatDateTimeLocal = (date: Date) => {
  const pad = (n: number) => n.toString().padStart(2, '0');
  const yyyy = date.getFullYear();
  const MM = pad(date.getMonth() + 1);
  const dd = pad(date.getDate());
  const hh = pad(date.getHours());
  const mm = pad(date.getMinutes());
  const ss = pad(date.getSeconds());
  return `${yyyy}-${MM}-${dd}T${hh}:${mm}:${ss}`;
};

const formatDisplayDateTime = (dtStr: string) => {
  if (!dtStr) return 'N/A';
  try {
    const d = new Date(dtStr);
    if (isNaN(d.getTime())) return dtStr.replace('T', ' ');
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dtStr.replace('T', ' ');
  }
};

const releaseSchema = z
  .object({
    name: z.string().trim().min(2, 'Release Name is required'),
    businessUnit: z.string().trim().min(1, 'Business Unit is required'),
    project: z.string().trim().min(1, 'Project is required'),
    application: z.string().trim().min(1, 'Application is required'),
    riskType: z.enum(['Major', 'Minor', 'Patch'], {
      errorMap: () => ({ message: 'Risk Type is required' }),
    }),
    releaseManagerId: z.string().trim().min(1, 'Release Manager is required'),
    startDate: z.string().trim().min(1, 'Start Date & Time is required'),
    endDate: z.string().trim().min(1, 'End Date & Time is required'),
    repositoryUrl: z
      .string()
      .optional()
      .refine((val) => !val || /^https?:\/\/.+/.test(val), {
        message: 'Enter a valid URL starting with http:// or https://',
      }),
    remarks: z.string().optional().default(''),
    version: z.string().optional().default(''),
    environmentId: z.string().optional().default(''),
  })
  .refine(
    (data) => {
      if (!data.startDate || !data.endDate) return true;
      const start = new Date(data.startDate).getTime();
      const end = new Date(data.endDate).getTime();
      return end > start;
    },
    {
      message: 'Start date and time cannot be greater than end date and time.',
      path: ['endDate'],
    }
  );

type ReleaseFormData = z.infer<typeof releaseSchema>;

interface ReleaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingRelease?: Release | null;
  initialTab?: 'details' | 'phases';
}

export const ReleaseModal: React.FC<ReleaseModalProps> = ({
  isOpen,
  onClose,
  editingRelease,
  initialTab = 'details',
}) => {
  const {
    businessUnits,
    projects,
    applications,
    environmentProfiles,
    testPhases,
    releases,
    addRelease,
    updateRelease,
    addReleasePhase,
    updateReleasePhase,
    deleteReleasePhase,
    showToast,
    isLoading,
  } = useTEM();

  const [users, setUsers] = useState<User[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'phases'>('details');
  const [deleteConfirmIndex, setDeleteConfirmIndex] = useState<number | null>(null);

  // AI Conflict Check State
  const [isCheckingConflicts, setIsCheckingConflicts] = useState(false);
  const [conflictResult, setConflictResult] = useState<ReleaseConflictCheckResponse | null>(null);

  const defaultSinglePhaseRow = useMemo(
    () => ({
      testPhaseId: '',
      phaseName: '',
      color: '',
      startDate: '',
      endDate: '',
      environmentId: '',
      status: 'NOT_STARTED',
      remarks: '',
    }),
    []
  );

  // Initial Phases configuration builder state
  const [selectedPhases, setSelectedPhases] = useState<
    Array<{
      id?: string;
      testPhaseId: string;
      phaseName: string;
      color: string;
      startDate: string;
      endDate: string;
      environmentId?: string;
      status?: string;
      remarks?: string;
    }>
  >([
    {
      testPhaseId: '',
      phaseName: '',
      color: '',
      startDate: '',
      endDate: '',
      environmentId: '',
      status: 'NOT_STARTED',
      remarks: '',
    },
  ]);

  // Load active Users for Release Manager dropdown
  useEffect(() => {
    userService.getUsers().then((fetched) => {
      if (Array.isArray(fetched) && fetched.length > 0) {
        setUsers(fetched.filter((u) => u.isActive !== false));
      }
    });
  }, []);

  const activeProfiles = useMemo(() => {
    return environmentProfiles.filter((env) => env.isActive !== false);
  }, [environmentProfiles]);

  const activeTestPhases = useMemo(() => {
    return testPhases.filter((p) => p.isActive !== false);
  }, [testPhases]);

  const prevIsOpenRef = React.useRef(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    trigger,
    clearErrors,
    formState: { errors },
  } = useForm<ReleaseFormData>({
    resolver: zodResolver(releaseSchema),
    mode: 'onChange',
    defaultValues: {
      name: '',
      businessUnit: '',
      project: '',
      application: '',
      riskType: '' as any,
      releaseManagerId: '',
      startDate: '',
      endDate: '',
      repositoryUrl: '',
      remarks: '',
      version: '',
      environmentId: '',
    },
  });

  const nameVal = watch('name');
  const selectedBU = watch('businessUnit');
  const selectedProj = watch('project');
  const selectedApp = watch('application');
  const riskTypeVal = watch('riskType');
  const releaseManagerIdVal = watch('releaseManagerId');
  const startDateVal = watch('startDate');
  const endDateVal = watch('endDate');
  const repositoryUrlVal = watch('repositoryUrl');
  const versionVal = watch('version');
  const remarksVal = watch('remarks');

  // Populate or reset form ONLY when modal opens (transition from closed to open)
  useEffect(() => {
    if (isOpen && !prevIsOpenRef.current) {
      setActiveTab(initialTab || 'details');
      clearErrors();
      setConflictResult(null);
      if (editingRelease) {
        reset({
          name: editingRelease.name || '',
          businessUnit: editingRelease.businessUnit || editingRelease.buId || '',
          project: editingRelease.project || editingRelease.projectId || '',
          application: editingRelease.application || editingRelease.applicationId || '',
          riskType: (editingRelease.riskType as any) || '',
          releaseManagerId: editingRelease.releaseManagerId || editingRelease.leadId || '',
          startDate: editingRelease.startDate || editingRelease.scheduledDate || '',
          endDate: editingRelease.endDate || '',
          repositoryUrl: editingRelease.repositoryUrl || '',
          remarks: editingRelease.remarks || '',
          version: editingRelease.version || '',
          environmentId: editingRelease.environmentId || '',
        });
        setSelectedPhases(
          editingRelease.phases && editingRelease.phases.length > 0
            ? editingRelease.phases.map((p) => ({
                id: p.id,
                testPhaseId: p.testPhaseId || '',
                phaseName: p.phaseName,
                color: p.color || '',
                startDate: p.startDate,
                endDate: p.endDate,
                environmentId: p.environmentId || '',
                status: p.status || 'NOT_STARTED',
                remarks: p.remarks || '',
              }))
            : [{ ...defaultSinglePhaseRow }]
        );
      } else {
        reset({
          name: '',
          businessUnit: '',
          project: '',
          application: '',
          riskType: '' as any,
          releaseManagerId: '',
          startDate: '',
          endDate: '',
          repositoryUrl: '',
          remarks: '',
          version: '',
          environmentId: '',
        });
        setSelectedPhases([{ ...defaultSinglePhaseRow }]);
      }
    }
    prevIsOpenRef.current = isOpen;
  }, [isOpen, editingRelease, initialTab, reset, clearErrors, defaultSinglePhaseRow]);

  // Live Date Order Validation
  const isDateOrderInvalid = useMemo(() => {
    if (!startDateVal || !endDateVal) return false;
    const s = new Date(startDateVal).getTime();
    const e = new Date(endDateVal).getTime();
    return !isNaN(s) && !isNaN(e) && s >= e;
  }, [startDateVal, endDateVal]);

  const isDetailsComplete = useMemo(() => {
    return Boolean(
      nameVal && nameVal.trim().length >= 2 &&
      selectedBU && selectedBU.trim() &&
      selectedProj && selectedProj.trim() &&
      selectedApp && selectedApp.trim() &&
      riskTypeVal &&
      releaseManagerIdVal && releaseManagerIdVal.trim() &&
      startDateVal && startDateVal.trim() &&
      endDateVal && endDateVal.trim() &&
      !isDateOrderInvalid
    );
  }, [
    nameVal,
    selectedBU,
    selectedProj,
    selectedApp,
    riskTypeVal,
    releaseManagerIdVal,
    startDateVal,
    endDateVal,
    isDateOrderInvalid,
  ]);

  // Dynamically filtered Projects based on selected BU
  const filteredProjects = useMemo(() => {
    if (!selectedBU) return [];
    return projects.filter(
      (p) =>
        p.businessUnit?.toLowerCase().trim() === selectedBU.toLowerCase().trim() ||
        p.businessUnit === selectedBU
    );
  }, [projects, selectedBU]);

  // Dynamically filtered Applications based on selected Project
  const filteredApplications = useMemo(() => {
    if (!selectedProj) return [];
    return applications.filter(
      (a) =>
        a.projectName?.toLowerCase().trim() === selectedProj.toLowerCase().trim() ||
        a.projectName === selectedProj
    );
  }, [applications, selectedProj]);

  // When BU changes, reset project and application
  const handleBUChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newBU = e.target.value;
    setValue('businessUnit', newBU, { shouldValidate: true });
    setValue('project', '', { shouldValidate: true });
    setValue('application', '', { shouldValidate: true });
  };

  // When Project changes, reset application
  const handleProjectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newProj = e.target.value;
    setValue('project', newProj, { shouldValidate: true });
    setValue('application', '', { shouldValidate: true });
  };

  // AUTOMATIC AI CONFLICT CHECK: Evaluates seamlessly as soon as dates or relevant fields change
  useEffect(() => {
    if (!isOpen) {
      setConflictResult(null);
      return;
    }

    if (!startDateVal || !endDateVal || isDateOrderInvalid) {
      setConflictResult(null);
      return;
    }

    const s = new Date(startDateVal).getTime();
    const e = new Date(endDateVal).getTime();
    if (isNaN(s) || isNaN(e) || s >= e) {
      setConflictResult(null);
      return;
    }

    let isCurrent = true;
    setIsCheckingConflicts(true);

    const timer = setTimeout(async () => {
      try {
        const buObj = businessUnits.find((b) => b.name?.toLowerCase().trim() === (selectedBU || '').toLowerCase().trim());
        const projObj = projects.find((p) => p.name?.toLowerCase().trim() === (selectedProj || '').toLowerCase().trim());
        const appObj = applications.find((a) => a.name?.toLowerCase().trim() === (selectedApp || '').toLowerCase().trim());

        const res = await releaseService.checkReleaseConflicts({
          name: nameVal || 'Release Schedule',
          buId: buObj?.id,
          businessUnit: selectedBU,
          projectId: projObj?.id,
          project: selectedProj,
          applicationId: appObj?.id,
          application: selectedApp,
          riskType: riskTypeVal || 'Major',
          releaseManagerId: releaseManagerIdVal,
          startDate: startDateVal,
          endDate: endDateVal,
          environmentId: watch('environmentId'),
          phases: selectedPhases
            .filter((p) => p.testPhaseId && p.startDate && p.endDate)
            .map((p) => {
              const env = environmentProfiles.find((ep) => ep.id === p.environmentId);
              return {
                testPhaseId: p.testPhaseId,
                phaseName: p.phaseName,
                color: p.color,
                startDate: p.startDate,
                endDate: p.endDate,
                environmentId: p.environmentId,
                environmentName: env?.name,
              };
            }),
          excludeReleaseId: editingRelease?.id,
        });

        if (isCurrent) {
          setConflictResult(res);
        }
      } catch (err) {
        console.error('Auto release conflict evaluation failed:', err);
      } finally {
        if (isCurrent) {
          setIsCheckingConflicts(false);
        }
      }
    }, 250);

    return () => {
      isCurrent = false;
      clearTimeout(timer);
    };
  }, [
    isOpen,
    startDateVal,
    endDateVal,
    selectedBU,
    selectedProj,
    selectedApp,
    riskTypeVal,
    releaseManagerIdVal,
    nameVal,
    selectedPhases,
    isDateOrderInvalid,
    businessUnits,
    projects,
    applications,
    environmentProfiles,
    editingRelease?.id,
    watch,
  ]);

  const handleApplyRecommendation = (rec: ReleaseDateRecommendation) => {
    setValue('startDate', rec.startDate, { shouldValidate: true });
    setValue('endDate', rec.endDate, { shouldValidate: true });

    if (rec.phases && rec.phases.length > 0 && selectedPhases.length > 0) {
      const updatedPhases = selectedPhases.map((phase, idx) => {
        const matchingRecPhase = rec.phases[idx] || rec.phases.find((p) => p.testPhaseId === phase.testPhaseId || p.phaseName === phase.phaseName);
        if (matchingRecPhase) {
          return {
            ...phase,
            startDate: matchingRecPhase.startDate,
            endDate: matchingRecPhase.endDate,
          };
        }
        return phase;
      });
      setSelectedPhases(updatedPhases);
    } else if (rec.shiftedDays && selectedPhases.length > 0) {
      const shiftMs = rec.shiftedDays * 86400000;
      const updatedPhases = selectedPhases.map((phase) => {
        if (!phase.startDate || !phase.endDate) return phase;
        const s = new Date(phase.startDate).getTime() + shiftMs;
        const e = new Date(phase.endDate).getTime() + shiftMs;
        return {
          ...phase,
          startDate: formatDateTimeLocal(new Date(s)),
          endDate: formatDateTimeLocal(new Date(e)),
        };
      });
      setSelectedPhases(updatedPhases);
    }

    showToast(`Applied AI recommended dates: ${formatDisplayDateTime(rec.startDate)} to ${formatDisplayDateTime(rec.endDate)}`, 'success');
  };

  const handleNextToPhases = async () => {
    const isValid = await trigger();
    if (!isValid) return;

    if (isDateOrderInvalid) {
      showToast('Release End Date & Time must be strictly after Start Date & Time.', 'error');
      return;
    }

    // Check duplicate release name
    const currentName = (watch('name') || '').trim();
    const isDuplicate = releases.some(
      (r) =>
        r.name.toLowerCase().trim() === currentName.toLowerCase().trim() &&
        (!editingRelease || r.id !== editingRelease.id)
    );
    if (isDuplicate) {
      showToast(`A release named "${currentName}" already exists.`, 'error');
      return;
    }

    setActiveTab('phases');
  };

  const handleAddPhaseRow = () => {
    setSelectedPhases((prev) => [
      ...prev,
      {
        testPhaseId: '',
        phaseName: '',
        color: '',
        startDate: '',
        endDate: '',
        environmentId: '',
      },
    ]);
  };

  const handleConfirmDeletePhase = () => {
    if (deleteConfirmIndex === null) return;
    if (selectedPhases.length <= 1) {
      showToast('Cannot delete all phases.', 'error');
      setDeleteConfirmIndex(null);
      return;
    }
    setSelectedPhases((prev) => prev.filter((_, i) => i !== deleteConfirmIndex));
    setDeleteConfirmIndex(null);
    showToast('Phase removed successfully.', 'success');
  };

  const handlePhaseChange = (index: number, field: string, value: any) => {
    setSelectedPhases((prev) =>
      prev.map((item, idx) => {
        if (idx === index) {
          if (field === 'testPhaseId') {
            const tp = testPhases.find((p) => p.id === value);
            return {
              ...item,
              testPhaseId: value,
              phaseName: tp ? tp.name : '',
              color: tp ? tp.color : '',
            };
          }
          return { ...item, [field]: value };
        }
        return item;
      })
    );
  };

  const onSubmit = async (data: ReleaseFormData) => {
    if (isDateOrderInvalid) {
      showToast('Release End Date & Time must be strictly after Start Date & Time.', 'error');
      return;
    }

    // Check release name uniqueness within existing releases
    const isDuplicate = releases.some(
      (r) =>
        r.name.toLowerCase().trim() === data.name.toLowerCase().trim() &&
        (!editingRelease || r.id !== editingRelease.id)
    );
    if (isDuplicate) {
      showToast(`A release named "${data.name}" already exists.`, 'error');
      return;
    }

    // Validate phase rows if any added
    if (selectedPhases.length > 0) {
      for (let i = 0; i < selectedPhases.length; i++) {
        const p = selectedPhases[i];
        if (!p.testPhaseId) {
          showToast(`Please select a Phase for row ${i + 1}.`, 'error');
          return;
        }
        if (!p.startDate || !p.endDate) {
          showToast(`Please specify both Start Date and Target Date for phase row ${i + 1}.`, 'error');
          return;
        }
        if (new Date(p.endDate).getTime() <= new Date(p.startDate).getTime()) {
          showToast(`Target Date must be strictly after Start Date for phase row ${i + 1}.`, 'error');
          return;
        }
      }
    }

    // Resolve BU, Project, App IDs
    const buObj = businessUnits.find(
      (b) => b.name?.toLowerCase().trim() === data.businessUnit.toLowerCase().trim()
    );
    const projObj = projects.find(
      (p) => p.name?.toLowerCase().trim() === data.project.toLowerCase().trim()
    );
    const appObj = applications.find(
      (a) => a.name?.toLowerCase().trim() === data.application.toLowerCase().trim()
    );
    const userObj = users.find((u) => u.id === data.releaseManagerId);
    const envObj = environmentProfiles.find((e) => e.id === data.environmentId);

    // Map risk for backward compatibility
    const riskMap: Record<ReleaseRiskType, ReleaseRisk> = {
      Major: 'HIGH RISK',
      Minor: 'MEDIUM RISK',
      Patch: 'LOW RISK',
    };

    setIsSubmitting(true);
    try {
      if (editingRelease) {
        await updateRelease(editingRelease.id, {
          name: data.name,
          buId: buObj?.id,
          businessUnit: data.businessUnit,
          projectId: projObj?.id,
          project: data.project,
          applicationId: appObj?.id,
          application: data.application,
          riskType: data.riskType,
          risk: riskMap[data.riskType],
          releaseManagerId: data.releaseManagerId,
          releaseManager: userObj?.fullName || userObj?.username || 'Release Manager',
          startDate: data.startDate,
          endDate: data.endDate,
          scheduledDate: data.startDate,
          repositoryUrl: data.repositoryUrl,
          remarks: data.remarks,
          version: data.version,
          environmentId: data.environmentId || 'env-all',
          environmentName: envObj?.name || 'All Environments',
        });

        // Sync phases
        const existingPhases = editingRelease.phases || [];
        const currentPhaseIds = new Set(selectedPhases.map((p) => p.id).filter(Boolean));

        // Delete removed phases
        for (const ep of existingPhases) {
          if (!currentPhaseIds.has(ep.id)) {
            await deleteReleasePhase(editingRelease.id, ep.id);
          }
        }

        // Update existing or add new phases
        for (let idx = 0; idx < selectedPhases.length; idx++) {
          const p = selectedPhases[idx];
          if (!p.testPhaseId || !p.phaseName) continue;
          const pEnv = environmentProfiles.find((e) => e.id === p.environmentId);
          if (p.id) {
            await updateReleasePhase(editingRelease.id, p.id, {
              testPhaseId: p.testPhaseId,
              phaseName: p.phaseName,
              color: p.color,
              environmentId: p.environmentId,
              environmentName: pEnv?.name || 'Assigned Env',
              startDate: p.startDate,
              endDate: p.endDate,
              sequence: idx + 1,
              status: p.status || 'NOT_STARTED',
              remarks: p.remarks,
            });
          } else {
            await addReleasePhase(editingRelease.id, {
              testPhaseId: p.testPhaseId,
              phaseName: p.phaseName,
              color: p.color,
              environmentId: p.environmentId,
              environmentName: pEnv?.name || 'Assigned Env',
              startDate: p.startDate,
              endDate: p.endDate,
              sequence: idx + 1,
              status: 'NOT_STARTED',
              remarks: p.remarks,
            });
          }
        }
      } else {
        await addRelease({
          name: data.name,
          buId: buObj?.id,
          businessUnit: data.businessUnit,
          projectId: projObj?.id,
          project: data.project,
          applicationId: appObj?.id,
          application: data.application,
          riskType: data.riskType,
          risk: riskMap[data.riskType],
          releaseManagerId: data.releaseManagerId,
          releaseManager: userObj?.fullName || userObj?.username || 'Release Manager',
          startDate: data.startDate,
          endDate: data.endDate,
          scheduledDate: data.startDate,
          repositoryUrl: data.repositoryUrl,
          remarks: data.remarks,
          version: data.version || 'v1.0.0',
          environmentId: data.environmentId || 'env-all',
          environmentName: envObj?.name || 'All Environments',
          initialPhases: selectedPhases
            .filter((p) => p.testPhaseId && p.phaseName)
            .map((p, idx) => {
              const pEnv = environmentProfiles.find((e) => e.id === p.environmentId);
              return {
                testPhaseId: p.testPhaseId,
                phaseName: p.phaseName,
                color: p.color,
                environmentId: p.environmentId,
                environmentName: pEnv?.name || 'Assigned Env',
                startDate: p.startDate,
                endDate: p.endDate,
                sequence: idx + 1,
                status: 'NOT_STARTED',
                remarks: p.remarks,
              };
            }),
        });
      }
      onClose();
    } catch {
      // Handled in context
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        categoryTag="DEPLOYMENT"
        title={editingRelease ? `Edit Release: ${editingRelease.name}` : 'Schedule New Release'}
        size="3xl"
        footer={
          activeTab === 'details' ? (
            <>
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors disabled:opacity-50 ml-auto"
              >
                CANCEL
              </button>
              <button
                type="button"
                onClick={handleNextToPhases}
                className="px-5 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)] flex items-center gap-1.5"
              >
                NEXT &rarr;
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setActiveTab('details')}
                disabled={isSubmitting}
                className="px-4 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors disabled:opacity-50 mr-auto"
              >
                &larr; BACK
              </button>
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors disabled:opacity-50"
              >
                CANCEL
              </button>
              <ButtonLoader
                type="submit"
                form="schedule-release-form"
                isLoading={isSubmitting || isLoading}
                loadingText="SAVING..."
                className="px-6 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_12px_rgba(249,115,22,0.4)]"
              >
                {editingRelease ? 'UPDATE RELEASE' : 'CONFIRM RELEASE'}
              </ButtonLoader>
            </>
          )
        }
      >
        {/* Navigation tabs inside modal */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 mb-4">
          <button
            type="button"
            onClick={() => setActiveTab('details')}
            className={`px-4 py-2 rounded text-xs font-mono font-bold uppercase tracking-wider transition-colors ${
              activeTab === 'details'
                ? 'bg-orange-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            RELEASE DETAILS
          </button>
          <button
            type="button"
            onClick={() => {
              if (activeTab === 'phases') return;
              if (isDetailsComplete) {
                handleNextToPhases();
              }
            }}
            disabled={!isDetailsComplete && activeTab !== 'phases'}
            title={
              !isDetailsComplete && activeTab !== 'phases'
                ? 'Complete required fields in Release Details to unlock Add Phase'
                : 'Add and configure release phases'
            }
            className={`px-4 py-2 rounded text-xs font-mono font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
              activeTab === 'phases'
                ? 'bg-orange-600 text-white shadow-sm'
                : isDetailsComplete
                ? 'bg-slate-800 text-slate-300 hover:text-white'
                : 'bg-slate-800/40 text-slate-500 opacity-50 backdrop-blur-sm cursor-not-allowed border border-slate-700/40'
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> ADD PHASE
          </button>
        </div>

        <form id="schedule-release-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4 font-mono text-xs">
          {activeTab === 'details' ? (
            <>
              {/* Release Name */}
              <div>
                <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  RELEASE NAME *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Payment Gateway Release 2.5"
                  value={nameVal}
                  onChange={(e) => setValue('name', e.target.value, { shouldValidate: true })}
                  className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 font-sans"
                />
                {errors.name && <p className="text-xs text-red-400 mt-1 font-mono">{errors.name.message}</p>}
              </div>

              {/* BU & Project & Application Hierarchical Dropdowns */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Business Unit */}
                <div>
                  <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    BUSINESS UNIT (BU) *
                  </label>
                  <select
                    value={selectedBU}
                    onChange={handleBUChange}
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
                  >
                    <option value="">Select Business Unit (BU)</option>
                    {businessUnits.map((bu) => (
                      <option key={bu.id} value={bu.name}>
                        {bu.name}
                      </option>
                    ))}
                  </select>
                  {errors.businessUnit && (
                    <p className="text-xs text-red-400 mt-1 font-mono">{errors.businessUnit.message}</p>
                  )}
                </div>

                {/* Project */}
                <div>
                  <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    PROJECT *
                  </label>
                  <select
                    value={selectedProj}
                    onChange={handleProjectChange}
                    disabled={!selectedBU}
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500 disabled:opacity-50"
                  >
                    <option value="">{selectedBU ? 'Select Project' : 'Select BU first'}</option>
                    {filteredProjects.map((p) => (
                      <option key={p.id} value={p.name}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                  {errors.project && <p className="text-xs text-red-400 mt-1 font-mono">{errors.project.message}</p>}
                </div>

                {/* Application */}
                <div>
                  <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    APPLICATION *
                  </label>
                  <select
                    value={selectedApp}
                    onChange={(e) => setValue('application', e.target.value, { shouldValidate: true })}
                    disabled={!selectedProj}
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500 disabled:opacity-50"
                  >
                    <option value="">{selectedProj ? 'Select Application' : 'Select Project first'}</option>
                    {filteredApplications.map((app) => (
                      <option key={app.id} value={app.name}>
                        {app.name}
                      </option>
                    ))}
                  </select>
                  {errors.application && (
                    <p className="text-xs text-red-400 mt-1 font-mono">{errors.application.message}</p>
                  )}
                </div>
              </div>

              {/* Risk Type & Release Manager */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Risk Type */}
                <div>
                  <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    RISK TYPE *
                  </label>
                  <select
                    value={riskTypeVal}
                    onChange={(e) => setValue('riskType', e.target.value as any, { shouldValidate: true })}
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
                  >
                    <option value="">Select Risk Type</option>
                    <option value="Major">Major (High Impact Release)</option>
                    <option value="Minor">Minor (Feature Release)</option>
                    <option value="Patch">Patch (Bugfix / Hotfix)</option>
                  </select>
                  {errors.riskType && <p className="text-xs text-red-400 mt-1 font-mono">{errors.riskType.message}</p>}
                </div>

                {/* Release Manager */}
                <div>
                  <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    RELEASE MANAGER *
                  </label>
                  <select
                    value={releaseManagerIdVal}
                    onChange={(e) => setValue('releaseManagerId', e.target.value, { shouldValidate: true })}
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
                  >
                    <option value="">Select Release Manager</option>
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.fullName || u.username} ({u.email || u.username})
                      </option>
                    ))}
                  </select>
                  {errors.releaseManagerId && (
                    <p className="text-xs text-red-400 mt-1 font-mono">{errors.releaseManagerId.message}</p>
                  )}
                </div>
              </div>

              {/* Timeline: Start Date & End Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <DateTimePicker
                  label="RELEASE START DATE & TIME *"
                  subLabel="HH:MM:SS"
                  placeholder="Select Release Start Date & Time..."
                  value={startDateVal}
                  onChange={(val) => {
                    setValue('startDate', val, { shouldValidate: true });
                    if (endDateVal && new Date(val).getTime() >= new Date(endDateVal).getTime()) {
                      setValue('endDate', '', { shouldValidate: true });
                    }
                  }}
                  error={errors.startDate?.message}
                />

                <DateTimePicker
                  label="RELEASE END DATE & TIME *"
                  subLabel="HH:MM:SS"
                  placeholder="Select Release End Date & Time..."
                  value={endDateVal}
                  minDateTime={startDateVal || undefined}
                  onChange={(val) => setValue('endDate', val, { shouldValidate: true })}
                  error={
                    isDateOrderInvalid
                      ? 'Release End Date & Time must be strictly after Start Date & Time.'
                      : errors.endDate?.message
                  }
                />
              </div>

              {/* Repository URL & Version */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1">
                    <LinkIcon className="w-3 h-3 text-orange-500" /> REPOSITORY URL (OPTIONAL)
                  </label>
                  <input
                    type="url"
                    placeholder="e.g. https://github.com/company/repo"
                    value={repositoryUrlVal}
                    onChange={(e) => setValue('repositoryUrl', e.target.value, { shouldValidate: true })}
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
                  />
                  {errors.repositoryUrl && (
                    <p className="text-xs text-red-400 mt-1 font-mono">{errors.repositoryUrl.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    VERSION TAG
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. v1.0.0 or v2.5.0"
                    value={versionVal}
                    onChange={(e) => setValue('version', e.target.value)}
                    className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              {/* Remarks */}
              <div>
                <label className="block text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  REMARKS / RELEASE NOTES (OPTIONAL)
                </label>
                <textarea
                  rows={2}
                  placeholder="Key deliverables, change ticket references, or deployment notes..."
                  value={remarksVal}
                  onChange={(e) => setValue('remarks', e.target.value)}
                  className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 font-sans"
                />
              </div>
            </>
          ) : (
            /* Add Phase Tab */
            <div className="space-y-3">
              {/* Top Action Bar */}
              <div className="flex items-center justify-between pb-1">
                <span className="text-[10px] text-slate-400 font-mono">
                  Configure execution phases and assign target environments.
                </span>
                <button
                  type="button"
                  onClick={handleAddPhaseRow}
                  className="flex items-center gap-1.5 px-4 py-2 rounded text-xs font-mono font-bold uppercase tracking-wider text-orange-400 bg-orange-950/40 border border-orange-500/50 hover:bg-orange-950/70 hover:border-orange-500 transition-all shadow-sm"
                >
                  <Plus className="w-4 h-4" /> ADD PHASE
                </button>
              </div>

              {selectedPhases.length > 0 && (
                <div className="space-y-2">
                  {/* Column Headers */}
                  <div className="hidden sm:grid sm:grid-cols-12 gap-3 px-3 py-1 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                    <div className="sm:col-span-4">PHASE *</div>
                    <div className="sm:col-span-4">START DATE *</div>
                    <div className="sm:col-span-3">TARGET DATE *</div>
                    <div className="sm:col-span-1 text-center">ACTION</div>
                  </div>

                  <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                    {selectedPhases.map((phase, idx) => {
                      const isPhaseDateInvalid = Boolean(
                        phase.startDate &&
                        phase.endDate &&
                        new Date(phase.startDate).getTime() >= new Date(phase.endDate).getTime()
                      );

                      return (
                        <div
                          key={idx}
                          className="p-3 bg-[#131b28] border border-slate-800 rounded-lg grid grid-cols-1 sm:grid-cols-12 gap-3 items-center"
                        >
                          {/* 1. Phase Dropdown */}
                          <div className="sm:col-span-4 flex items-center gap-2">
                            {phase.testPhaseId && phase.color ? (
                              <span
                                className="w-3.5 h-3.5 rounded-full shrink-0 shadow-sm"
                                style={{ backgroundColor: phase.color }}
                              />
                            ) : (
                              <span className="w-3.5 h-3.5 rounded-full shrink-0 border border-dashed border-slate-600 bg-slate-800/40" />
                            )}
                            <select
                              value={phase.testPhaseId}
                              onChange={(e) => handlePhaseChange(idx, 'testPhaseId', e.target.value)}
                              className="w-full bg-[#161f2e] border border-slate-700/80 rounded px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                            >
                              <option value="">Please Select</option>
                              {activeTestPhases.map((tp) => (
                                <option key={tp.id} value={tp.id}>
                                  {tp.name}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* 2. Start Date */}
                          <div className="sm:col-span-4">
                            <DateTimePicker
                              placeholder="Select start date"
                              value={phase.startDate}
                              minDateTime={startDateVal || undefined}
                              maxDateTime={endDateVal || undefined}
                              onChange={(val) => {
                                handlePhaseChange(idx, 'startDate', val);
                                if (phase.endDate && new Date(val).getTime() >= new Date(phase.endDate).getTime()) {
                                  handlePhaseChange(idx, 'endDate', '');
                                }
                              }}
                            />
                          </div>

                          {/* 3. Target Date */}
                          <div className="sm:col-span-3">
                            <DateTimePicker
                              placeholder="Select target date"
                              value={phase.endDate}
                              minDateTime={phase.startDate || startDateVal || undefined}
                              maxDateTime={endDateVal || undefined}
                              error={isPhaseDateInvalid ? 'Target Date must be after Start Date' : undefined}
                              onChange={(val) => handlePhaseChange(idx, 'endDate', val)}
                            />
                          </div>

                          {/* 4. Delete Action Button */}
                          <div className="sm:col-span-1 flex items-center justify-center">
                            <button
                              type="button"
                              onClick={() => setDeleteConfirmIndex(idx)}
                              className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                              title="Delete Phase"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* LIVE DATE ORDER ERROR BANNER */}
          {isDateOrderInvalid && (
            <div className="bg-red-950/90 border-2 border-red-600 rounded p-3 text-red-200 text-xs flex items-center gap-2.5 animate-pulse font-mono">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              <span className="font-bold">Start date time is greater than the end date time.</span>
            </div>
          )}

          {/* AI RELEASE INTELLIGENCE CARD (Automated on date/field selection) */}
          {(conflictResult || isCheckingConflicts) && !isDateOrderInvalid && (
            <div className="bg-[#0b1320] border border-orange-500/50 rounded-lg p-3.5 space-y-2.5 text-xs font-mono shadow-[0_0_15px_rgba(249,115,22,0.15)] animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 font-bold text-orange-400">
                  <BrainCircuit className={`w-4 h-4 text-orange-400 ${isCheckingConflicts ? 'animate-pulse' : ''}`} /> AI RELEASE INTELLIGENCE
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    isCheckingConflicts
                      ? 'bg-slate-800 text-slate-300 border border-slate-700'
                      : conflictResult?.riskLevel === 'CRITICAL' || conflictResult?.riskLevel === 'VERY_HIGH'
                      ? 'bg-red-950 text-red-400 border border-red-800'
                      : conflictResult?.riskLevel === 'HIGH'
                      ? 'bg-orange-950 text-orange-400 border border-orange-800'
                      : conflictResult?.riskLevel === 'MEDIUM'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  }`}
                >
                  {isCheckingConflicts
                    ? 'ANALYZING...'
                    : `RISK: ${conflictResult?.riskLevel || 'NONE'} (${conflictResult?.conflictProbability || 0}%)`}
                </span>
              </div>

              {/* Explanations & Conflict Details */}
              <div className="space-y-1.5 bg-black/40 p-2.5 rounded border border-slate-800 text-[11px]">
                {isCheckingConflicts ? (
                  <div className="flex items-center gap-2 text-slate-400 py-1">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-orange-400" />
                    <span>Evaluating release timeline, application schedule, and phase environments...</span>
                  </div>
                ) : !conflictResult?.hasConflicts ? (
                  <div className="flex items-start gap-1.5 text-slate-300">
                    <span className="text-orange-400 shrink-0">•</span>
                    <span>
                      <strong className="text-white">Optimal Availability Window:</strong> No overlapping reservations or release pipeline collisions detected for this window.
                    </span>
                  </div>
                ) : (
                  conflictResult.conflicts.map((c) => (
                    <div key={c.id} className="flex items-start gap-1.5 text-slate-300">
                      <span className="text-orange-400 shrink-0">•</span>
                      <span>
                        <strong className="text-white">{c.title}:</strong> {c.detail}
                      </span>
                    </div>
                  ))
                )}
              </div>

              {/* Recommended Alternatives Section */}
              {conflictResult && conflictResult.hasConflicts && conflictResult.recommendations.length > 0 && (
                <div className="space-y-1.5 pt-1 border-t border-slate-800">
                  <span className="text-[10px] text-emerald-400 font-bold uppercase flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-emerald-400" /> RECOMMENDED ALTERNATIVES (LOWER CONFLICT RISK)
                  </span>

                  <div className="space-y-1.5">
                    {conflictResult.recommendations.map((rec) => (
                      <div
                        key={rec.id}
                        className="bg-slate-900/90 p-2.5 rounded border border-slate-800 flex items-center justify-between gap-2 hover:border-slate-700 transition-colors"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <strong className="text-white text-xs truncate">
                              {formatDisplayDateTime(rec.startDate)} &rarr; {formatDisplayDateTime(rec.endDate)}
                            </strong>
                            <span className="text-[10px] text-emerald-400 font-bold">{rec.confidenceScore}% MATCH</span>
                            <span className="text-[9px] text-slate-400 font-mono">({rec.durationDays}d duration)</span>
                          </div>
                          <p className="text-[10px] text-slate-400 truncate mt-0.5">{rec.reasoning}</p>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleApplyRecommendation(rec)}
                          className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] shrink-0 flex items-center gap-1 transition-colors uppercase"
                        >
                          USE THIS <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={deleteConfirmIndex !== null}
        onClose={() => setDeleteConfirmIndex(null)}
        categoryTag="CONFIRMATION"
        title="Delete Phase"
        size="sm"
        footer={
          <>
            <button
              type="button"
              onClick={() => setDeleteConfirmIndex(null)}
              className="px-4 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              CANCEL
            </button>
            <button
              type="button"
              onClick={handleConfirmDeletePhase}
              className="px-5 py-2 rounded text-xs font-mono font-semibold uppercase tracking-wider text-white bg-red-600 hover:bg-red-500 transition-colors shadow-[0_0_12px_rgba(239,68,68,0.4)]"
            >
              CONFIRM
            </button>
          </>
        }
      >
        <div className="py-2 text-sm text-slate-300 font-sans">
          Are you sure you want to delete this phase?
        </div>
      </Modal>
    </>
  );
};
