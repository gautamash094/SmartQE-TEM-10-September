import React from 'react';
import { Release } from '../../types';
import { useTEM } from '../../context/TEMContext';
import {
  X,
  Edit3,
  Trash2,
  Plus,
  Calendar,
  Layers,
  ArrowUp,
  ArrowDown,
  ExternalLink,
  User,
  Clock,
  Building,
  Briefcase,
  Cpu,
} from 'lucide-react';

interface ReleaseDetailsModalProps {
  release: Release | null;
  isOpen: boolean;
  onClose: () => void;
  onEditRelease?: (release: Release, initialTab?: 'details' | 'phases') => void;
}

const formatDisplayDate = (dStr?: string) => {
  if (!dStr) return 'N/A';
  try {
    const d = new Date(dStr);
    return d.toLocaleDateString('en-US', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dStr;
  }
};

const calculateDurationDays = (sStr?: string, eStr?: string) => {
  if (!sStr || !eStr) return '-';
  try {
    const s = new Date(sStr).getTime();
    const e = new Date(eStr).getTime();
    const diff = Math.max(0, e - s);
    const days = Math.round(diff / (1000 * 60 * 60 * 24));
    return `${days} ${days === 1 ? 'day' : 'days'}`;
  } catch {
    return '-';
  }
};

export const ReleaseDetailsModal: React.FC<ReleaseDetailsModalProps> = ({
  release,
  isOpen,
  onClose,
  onEditRelease,
}) => {
  const {
    deleteRelease,
    deleteReleasePhase,
    reorderReleasePhases,
    updateRelease,
    getTestPhaseColor,
  } = useTEM();

  if (!isOpen || !release) return null;

  const phases = [...(release.phases || [])].sort((a, b) => (a.sequence || 0) - (b.sequence || 0));

  // Compute release timeline bounds for Gantt visualization
  const releaseStartMs = release.startDate ? new Date(release.startDate).getTime() : Date.now();
  const releaseEndMs = release.endDate ? new Date(release.endDate).getTime() : releaseStartMs + 14 * 24 * 3600 * 1000;
  const totalReleaseDurationMs = Math.max(1, releaseEndMs - releaseStartMs);

  const handleDeletePhase = async (phaseId: string) => {
    if (window.confirm('Are you sure you want to remove this phase from the release?')) {
      await deleteReleasePhase(release.id, phaseId);
    }
  };

  const handleMovePhase = async (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === phases.length - 1) return;

    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    const newPhases = [...phases];
    const temp = newPhases[index];
    newPhases[index] = newPhases[targetIdx];
    newPhases[targetIdx] = temp;

    const reordered = newPhases.map((p, idx) => ({ id: p.id, sequence: idx + 1 }));
    await reorderReleasePhases(release.id, reordered);
  };

  const handleDeleteRelease = async () => {
    if (window.confirm(`Are you sure you want to delete Release "${release.name}"? This action cannot be undone.`)) {
      await deleteRelease(release.id);
      onClose();
    }
  };

  const handleStatusChange = async (newStatus: any) => {
    await updateRelease(release.id, { status: newStatus });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl bg-[#090d14] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8 max-h-[92vh] flex flex-col">
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-[#121927] to-[#182338] border-b border-slate-800 p-6 flex items-start justify-between gap-4 shrink-0">
          <div className="space-y-1.5 flex-1">
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <span className="px-2.5 py-0.5 rounded font-bold uppercase tracking-wider text-orange-400 bg-orange-950/40 border border-orange-500/40">
                {release.version || 'v1.0.0'}
              </span>
              <span
                className={`px-2.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                  release.riskType === 'Major' || release.risk === 'HIGH RISK'
                    ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                    : release.riskType === 'Minor' || release.risk === 'MEDIUM RISK'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                    : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                }`}
              >
                {release.riskType || release.risk || 'Major'} Risk
              </span>
              <span className="text-slate-400 text-[11px]">ID: {release.id.substring(0, 8)}</span>
            </div>

            <h2 className="text-2xl font-extrabold text-white tracking-tight font-sans">{release.name}</h2>

            <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-1">
              <div className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-500" />
                <span>Manager: <strong className="text-slate-200">{release.releaseManager || release.lead}</strong></span>
              </div>
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span>
                  {formatDisplayDate(release.startDate || release.scheduledDate)} &rarr; {formatDisplayDate(release.endDate)}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions & Status Dropdown */}
          <div className="flex items-center gap-3">
            <select
              value={release.status}
              onChange={(e) => handleStatusChange(e.target.value)}
              className="bg-[#1a2536] border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono font-bold text-white uppercase focus:outline-none focus:border-orange-500"
            >
              <option value="SCHEDULED">Scheduled</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="DEPLOYED">Deployed</option>
              <option value="COMPLETED">Completed</option>
              <option value="FAILED">Failed</option>
              <option value="CANCELLED">Cancelled</option>
            </select>

            {onEditRelease && (
              <button
                onClick={() => {
                  onClose();
                  onEditRelease(release, 'details');
                }}
                className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Edit Release"
              >
                <Edit3 className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={handleDeleteRelease}
              className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
              title="Delete Release"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-2"
              title="Close Details"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1 font-mono text-xs">
          {/* Metadata Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3.5 bg-[#121927] border border-slate-800 rounded-xl space-y-1">
              <span className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-1">
                <Building className="w-3 h-3 text-orange-500" /> BUSINESS UNIT
              </span>
              <p className="text-sm font-bold text-white font-sans truncate">
                {release.businessUnit || release.buId || 'Not Specified'}
              </p>
            </div>

            <div className="p-3.5 bg-[#121927] border border-slate-800 rounded-xl space-y-1">
              <span className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-1">
                <Briefcase className="w-3 h-3 text-cyan-500" /> PROJECT
              </span>
              <p className="text-sm font-bold text-white font-sans truncate">
                {release.project || release.projectId || 'Not Specified'}
              </p>
            </div>

            <div className="p-3.5 bg-[#121927] border border-slate-800 rounded-xl space-y-1">
              <span className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-1">
                <Cpu className="w-3 h-3 text-purple-500" /> APPLICATION
              </span>
              <p className="text-sm font-bold text-white font-sans truncate">
                {release.application || release.applicationId || 'Not Specified'}
              </p>
            </div>

            <div className="p-3.5 bg-[#121927] border border-slate-800 rounded-xl space-y-1">
              <span className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-1">
                <Clock className="w-3 h-3 text-emerald-500" /> TOTAL DURATION
              </span>
              <p className="text-sm font-bold text-white font-sans">
                {calculateDurationDays(release.startDate || release.scheduledDate, release.endDate)}
              </p>
            </div>
          </div>

          {/* Repository URL & Remarks Section */}
          {(release.repositoryUrl || release.remarks) && (
            <div className="p-4 bg-[#121927] border border-slate-800 rounded-xl space-y-3">
              {release.repositoryUrl && (
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider shrink-0 font-bold">
                    REPOSITORY:
                  </span>
                  <a
                    href={release.repositoryUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-orange-400 hover:text-orange-300 transition-colors flex items-center gap-1 underline truncate"
                  >
                    {release.repositoryUrl} <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
              {release.remarks && (
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold mb-1">
                    REMARKS & NOTES:
                  </span>
                  <p className="text-slate-300 font-sans leading-relaxed text-xs">{release.remarks}</p>
                </div>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* RELEASE TIMELINE (GANTT VISUALIZATION) */}
          {/* ========================================================================= */}
          <div className="p-5 bg-[#121927] border border-slate-800 rounded-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-orange-500" />
                <h3 className="text-sm font-extrabold uppercase tracking-wider text-white">Release Timeline (Gantt)</h3>
              </div>
              <span className="text-[11px] text-slate-400">
                {phases.length} {phases.length === 1 ? 'Phase' : 'Phases'} Configured
              </span>
            </div>

            {phases.length === 0 ? (
              <div className="p-8 text-center border border-dashed border-slate-800 rounded-lg text-slate-500">
                No release phases added yet. Click &quot;+ Add Phase&quot; below to configure execution milestones.
              </div>
            ) : (
              <div className="space-y-3 pt-2">
                {phases.map((ph) => {
                  const pStart = ph.startDate ? new Date(ph.startDate).getTime() : releaseStartMs;
                  const pEnd = ph.endDate ? new Date(ph.endDate).getTime() : releaseEndMs;
                  const startOffsetPercent = Math.max(
                    0,
                    Math.min(100, ((pStart - releaseStartMs) / totalReleaseDurationMs) * 100)
                  );
                  const durationPercent = Math.max(
                    4,
                    Math.min(100 - startOffsetPercent, ((pEnd - pStart) / totalReleaseDurationMs) * 100)
                  );
                  const colorHex = ph.color || getTestPhaseColor(ph.phaseName);

                  return (
                    <div key={ph.id} className="space-y-1 group">
                      <div className="flex items-center justify-between text-[11px]">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2.5 h-2.5 rounded-full shadow-sm"
                            style={{ backgroundColor: colorHex }}
                          />
                          <strong className="text-white uppercase">{ph.phaseName}</strong>
                        </div>
                        <div className="text-slate-400">
                          {formatDisplayDate(ph.startDate)} &rarr; {formatDisplayDate(ph.endDate)} (
                          {calculateDurationDays(ph.startDate, ph.endDate)})
                        </div>
                      </div>

                      {/* Timeline Bar Track */}
                      <div className="h-6 w-full bg-[#182338]/80 rounded-md relative overflow-hidden border border-slate-800">
                        <div
                          className="h-full rounded transition-all duration-300 shadow-md flex items-center px-2 text-[10px] font-bold text-white truncate"
                          style={{
                            marginLeft: `${startOffsetPercent}%`,
                            width: `${durationPercent}%`,
                            backgroundColor: colorHex,
                          }}
                          title={`${ph.phaseName}: ${formatDisplayDate(ph.startDate)} -> ${formatDisplayDate(ph.endDate)}`}
                        >
                          <span className="drop-shadow truncate">{ph.phaseName}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* ========================================================================= */}
          {/* PHASES MANAGEMENT TABLE */}
          {/* ========================================================================= */}
          <div className="p-5 bg-[#121927] border border-slate-800 rounded-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-extrabold uppercase tracking-wider text-white">Release Phases Management</h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Order and dates for execution milestones. Phase timelines must remain within the release schedule.
                </p>
              </div>

              {onEditRelease && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onEditRelease(release, 'phases');
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_12px_rgba(249,115,22,0.4)]"
                >
                  <Plus className="w-3.5 h-3.5" /> ADD PHASE
                </button>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="bg-slate-900/60 border-b border-slate-800 text-slate-500 uppercase tracking-wider text-[11px]">
                    <th className="px-3 py-2.5 font-bold w-12 text-center">Order</th>
                    <th className="px-3 py-2.5 font-bold">Phase</th>
                    <th className="px-3 py-2.5 font-bold">Start Date</th>
                    <th className="px-3 py-2.5 font-bold">End Date</th>
                    <th className="px-3 py-2.5 font-bold">Duration</th>
                    <th className="px-3 py-2.5 font-bold">Status</th>
                    <th className="px-3 py-2.5 font-bold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {phases.map((p, idx) => {
                    const colorHex = p.color || getTestPhaseColor(p.phaseName);
                    return (
                      <tr key={p.id} className="hover:bg-slate-800/30 transition-colors">
                        {/* Order & Reorder arrows */}
                        <td className="px-3 py-3 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <span className="font-bold text-slate-400">{idx + 1}</span>
                            <div className="flex flex-col">
                              <button
                                type="button"
                                onClick={() => handleMovePhase(idx, 'up')}
                                disabled={idx === 0}
                                className="text-slate-500 hover:text-white disabled:opacity-20 p-0.5"
                                title="Move Phase Up"
                              >
                                <ArrowUp className="w-3 h-3" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleMovePhase(idx, 'down')}
                                disabled={idx === phases.length - 1}
                                className="text-slate-500 hover:text-white disabled:opacity-20 p-0.5"
                                title="Move Phase Down"
                              >
                                <ArrowDown className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </td>

                        {/* Phase Name & Color Indicator */}
                        <td className="px-3 py-3 font-bold text-white">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-3 h-3 rounded-full shrink-0 shadow-sm"
                              style={{ backgroundColor: colorHex }}
                            />
                            <span>{p.phaseName}</span>
                          </div>
                        </td>

                        {/* Start Date */}
                        <td className="px-3 py-3 text-slate-400">{formatDisplayDate(p.startDate)}</td>

                        {/* End Date */}
                        <td className="px-3 py-3 text-slate-400">{formatDisplayDate(p.endDate)}</td>

                        {/* Duration */}
                        <td className="px-3 py-3 text-slate-400">{calculateDurationDays(p.startDate, p.endDate)}</td>

                        {/* Status */}
                        <td className="px-3 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              p.status === 'COMPLETED'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                : p.status === 'IN_PROGRESS'
                                ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                                : p.status === 'ON_HOLD'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            {p.status || 'NOT_STARTED'}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="px-3 py-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            {onEditRelease && (
                              <button
                                onClick={() => {
                                  onClose();
                                  onEditRelease(release, 'phases');
                                }}
                                className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                                title="Edit Phases"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              onClick={() => handleDeletePhase(p.id)}
                              className="p-1.5 rounded text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
                              title="Delete Phase"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
