import React, { useMemo } from 'react';
import {
  ReleaseCalendarGroup,
  ReleaseCalendarRelease,
  ReleaseCalendarPhase,
  ReleaseCalendarConflict,
} from '../../types/releaseCalendar';
import { Rocket, Layers, Cpu, AlertTriangle, ShieldAlert } from 'lucide-react';

interface ReleaseMonthlyCalendarProps {
  currentDate: Date;
  groups: ReleaseCalendarGroup[];
  conflicts: ReleaseCalendarConflict[];
  onSelectRelease: (release: ReleaseCalendarRelease) => void;
  onSelectPhase: (phase: ReleaseCalendarPhase, release: ReleaseCalendarRelease) => void;
  getPhaseColor: (phaseName: string, defaultColor?: string) => string;
}

const safeParseDate = (dateVal?: string | Date | null): Date | null => {
  if (!dateVal) return null;
  if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
  const isoStr = String(dateVal).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d;
  const dRaw = new Date(dateVal);
  return isNaN(dRaw.getTime()) ? null : dRaw;
};

export const ReleaseMonthlyCalendar: React.FC<ReleaseMonthlyCalendarProps> = ({
  currentDate,
  groups,
  conflicts,
  onSelectRelease,
  onSelectPhase,
  getPhaseColor,
}) => {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Mon = 0, Sun = 6
  const startDayOfWeek = (firstDayOfMonth.getDay() + 6) % 7;
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const calendarCells: { date: Date; isCurrentMonth: boolean; key: string }[] = [];

  // Previous month trailing days
  for (let i = startDayOfWeek - 1; i >= 0; i--) {
    calendarCells.push({
      date: new Date(year, month - 1, daysInPrevMonth - i),
      isCurrentMonth: false,
      key: `prev-${i}`,
    });
  }

  // Current month days
  for (let d = 1; d <= daysInMonth; d++) {
    calendarCells.push({
      date: new Date(year, month, d),
      isCurrentMonth: true,
      key: `curr-${d}`,
    });
  }

  // Next month leading days
  const totalCellsNeeded = calendarCells.length > 35 ? 42 : 35;
  const remainingCells = totalCellsNeeded - calendarCells.length;
  for (let d = 1; d <= remainingCells; d++) {
    calendarCells.push({
      date: new Date(year, month + 1, d),
      isCurrentMonth: false,
      key: `next-${d}`,
    });
  }

  const isSameDay = (d1: Date, d2: Date) =>
    d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate();

  const today = new Date();
  const isToday = (d: Date) => isSameDay(d, today);

  const dayHeaders = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  // Flatten all releases & phases for date matching
  const flattenedPhases = useMemo(() => {
    const list: {
      group: ReleaseCalendarGroup;
      release: ReleaseCalendarRelease;
      phase: ReleaseCalendarPhase;
      startMs: number;
      endMs: number;
    }[] = [];

    groups.forEach((g) => {
      g.releases.forEach((r) => {
        (r.phases || []).forEach((p) => {
          const s = safeParseDate(p.startDate);
          const e = safeParseDate(p.endDate);
          if (s && e) {
            list.push({
              group: g,
              release: r,
              phase: p,
              startMs: new Date(s.getFullYear(), s.getMonth(), s.getDate(), 0, 0, 0).getTime(),
              endMs: new Date(e.getFullYear(), e.getMonth(), e.getDate(), 23, 59, 59).getTime(),
            });
          }
        });
      });
    });

    return list;
  }, [groups]);

  // Check if a specific cell date has conflicts
  const isDateInConflict = (cellDate: Date) => {
    const time = cellDate.getTime();
    return conflicts.some((c) => {
      const s = safeParseDate(c.conflictStartDate)?.getTime() || 0;
      const e = safeParseDate(c.conflictEndDate)?.getTime() || 0;
      return time >= s && time <= e;
    });
  };

  return (
    <div className="bg-[#0f1724] border border-slate-800 rounded-xl overflow-hidden shadow-lg font-mono text-xs">
      {/* Day Headers */}
      <div className="grid grid-cols-7 bg-slate-900/80 border-b border-slate-800 text-center font-bold text-slate-400 uppercase tracking-wider text-[11px] py-2.5">
        {dayHeaders.map((dh, idx) => (
          <div key={dh} className={idx >= 5 ? 'text-slate-500' : ''}>
            {dh}
          </div>
        ))}
      </div>

      {/* Month Calendar Grid */}
      <div className="grid grid-cols-7 auto-rows-fr divide-x divide-y divide-slate-800/60 bg-[#0a0f18]">
        {calendarCells.map((cell) => {
          const cellDayStartMs = new Date(
            cell.date.getFullYear(),
            cell.date.getMonth(),
            cell.date.getDate(),
            0,
            0,
            0
          ).getTime();
          const cellDayEndMs = new Date(
            cell.date.getFullYear(),
            cell.date.getMonth(),
            cell.date.getDate(),
            23,
            59,
            59
          ).getTime();

          // Match phases covering this day
          const dayPhases = flattenedPhases.filter(
            (item) => item.startMs <= cellDayEndMs && item.endMs >= cellDayStartMs
          );

          const cellHasConflict = isDateInConflict(cell.date);
          const currentIsToday = isToday(cell.date);

          return (
            <div
              key={cell.key}
              className={`min-h-[110px] sm:min-h-[125px] p-1.5 flex flex-col justify-between transition-colors ${
                cell.isCurrentMonth
                  ? 'bg-[#0f1724]/90 hover:bg-[#141e2e]'
                  : 'bg-[#0a0f18]/60 text-slate-600'
              } ${currentIsToday ? 'ring-2 ring-orange-500/80 bg-orange-500/5' : ''}`}
            >
              {/* Day Number Header */}
              <div className="flex items-center justify-between">
                <div>
                  {cellHasConflict && (
                    <span
                      className="text-red-400 animate-pulse"
                      title="Schedule conflict / overlap on this date"
                    >
                      <AlertTriangle className="w-3 h-3" />
                    </span>
                  )}
                </div>
                <span
                  className={`text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center ${
                    currentIsToday
                      ? 'bg-orange-500 text-white shadow-xs'
                      : cell.isCurrentMonth
                      ? 'text-slate-300'
                      : 'text-slate-600'
                  }`}
                >
                  {cell.date.getDate()}
                </span>
              </div>

              {/* Day Phase Chips List */}
              <div className="space-y-1 my-1 overflow-y-auto max-h-[85px] pr-0.5">
                {dayPhases.slice(0, 3).map((item, pIdx) => {
                  const phaseColor =
                    item.phase.color || getPhaseColor(item.phase.phaseName, '#3B82F6');

                  return (
                    <div
                      key={`${item.phase.phaseId}-${pIdx}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectPhase(item.phase, item.release);
                      }}
                      className="group relative px-1.5 py-1 rounded text-[10px] font-bold text-white truncate cursor-pointer transition-all shadow-xs flex items-center justify-between gap-1 hover:scale-[1.02]"
                      style={{
                        backgroundColor: `${phaseColor}dd`,
                        borderLeft: `3px solid ${phaseColor}`,
                      }}
                      title={`${item.release.releaseName} | ${item.phase.phaseName} (${item.phase.status})`}
                    >
                      <span className="truncate font-sans font-semibold">
                        {item.phase.phaseName}
                      </span>
                      <span className="text-[9px] opacity-90 truncate max-w-[65px] font-mono">
                        {item.release.version || item.release.releaseName.substring(0, 8)}
                      </span>
                    </div>
                  );
                })}

                {dayPhases.length > 3 && (
                  <div
                    onClick={() => onSelectRelease(dayPhases[0].release)}
                    className="text-[9px] font-bold text-orange-400 hover:text-orange-300 px-1 py-0.5 rounded bg-slate-900/60 text-center cursor-pointer"
                  >
                    +{dayPhases.length - 3} more
                  </div>
                )}
              </div>

              <div />
            </div>
          );
        })}
      </div>
    </div>
  );
};
