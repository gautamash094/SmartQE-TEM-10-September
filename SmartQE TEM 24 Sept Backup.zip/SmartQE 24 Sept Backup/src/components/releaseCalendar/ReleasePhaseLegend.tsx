import React from 'react';
import { TestPhase } from '../../types';
import { Palette, ShieldAlert } from 'lucide-react';

interface ReleasePhaseLegendProps {
  testPhases: TestPhase[];
  activePhaseFilter?: string;
  onSelectPhaseFilter?: (phaseName: string) => void;
}

export const ReleasePhaseLegend: React.FC<ReleasePhaseLegendProps> = ({
  testPhases,
  activePhaseFilter,
  onSelectPhaseFilter,
}) => {
  const activePhases = (testPhases || []).filter((tp) => tp.isActive !== false);

  return (
    <div className="bg-[#0f1724] border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 font-mono text-xs shadow-sm">
      <div className="flex items-center gap-2 text-slate-400">
        <Palette className="w-4 h-4 text-orange-400" />
        <span className="font-bold uppercase tracking-wider text-[11px] text-slate-300">
          TEST PHASE LEGEND:
        </span>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        {activePhases.map((tp) => {
          const isSelected = activePhaseFilter === tp.name;

          return (
            <button
              key={tp.id || tp.name}
              type="button"
              onClick={() => onSelectPhaseFilter?.(isSelected ? '' : tp.name)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                isSelected
                  ? 'bg-slate-800 border border-slate-600 ring-1 ring-orange-500'
                  : 'bg-[#161f2e] border border-slate-800 hover:border-slate-700'
              }`}
              title={tp.description || `${tp.name} phase`}
            >
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs"
                style={{ backgroundColor: tp.color || '#3B82F6' }}
              />
              <span className="text-white text-[11px] font-bold">{tp.name}</span>
            </button>
          );
        })}

        {/* Conflict indicator legend chip */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-red-500/10 border border-red-500/30 text-red-400">
          <ShieldAlert className="w-3 h-3 text-red-400" />
          <span className="text-[11px] font-bold">Schedule Conflict</span>
        </div>
      </div>
    </div>
  );
};
