import React from 'react';
import { ReleaseCalendarRelease, ReleaseCalendarPhase } from '../../types/releaseCalendar';
import {
  X,
  Rocket,
  Layers,
  Cpu,
  User,
  Calendar,
  Clock,
  Shield,
  ExternalLink,
  Edit3,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface ReleaseDetailDrawerProps {
  release: ReleaseCalendarRelease | null;
  isOpen: boolean;
  onClose: () => void;
  onViewRelease?: (releaseId: string) => void;
  onSelectPhase?: (phase: ReleaseCalendarPhase) => void;
  getPhaseColor: (phaseName: string, defaultColor?: string) => string;
}

export const ReleaseDetailDrawer: React.FC<ReleaseDetailDrawerProps> = ({
  release,
  isOpen,
  onClose,
  onViewRelease,
  onSelectPhase,
  getPhaseColor,
}) => {
  if (!isOpen || !release) return null;

  const calculateDuration = (startStr?: string, endStr?: string) => {
    if (!startStr || !endStr) return '-';
    try {
      const s = new Date(startStr).getTime();
      const e = new Date(endStr).getTime();
      const days = Math.round(Math.max(0, e - s) / (1000 * 60 * 60 * 24));
      return `${days} ${days === 1 ? 'day' : 'days'}`;
    } catch {
      return '-';
    }
  };

  const formatDate = (dStr?: string) => {
    if (!dStr) return '-';
    try {
      return new Date(dStr).toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dStr;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-mono text-xs">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
      />

      {/* Slide-over Drawer Panel */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-xl bg-[#0d131f] border-l border-slate-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
          {/* Drawer Header */}
          <div className="p-5 border-b border-slate-800 bg-[#090e17] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10 border border-orange-500/30 text-orange-400">
                <Rocket className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-orange-400 font-bold uppercase tracking-widest">
                  RELEASE DETAILS &bull; {release.version || 'v1.0.0'}
                </span>
                <h2 className="text-lg font-bold text-white tracking-tight font-sans">
                  {release.releaseName}
                </h2>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-5">
            {/* Quick Status / Risk Badges */}
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  release.status === 'DEPLOYED' || release.status === 'COMPLETED'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : release.status === 'IN_PROGRESS'
                    ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                    : 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
                }`}
              >
                {release.status}
              </span>

              <span
                className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  release.riskType === 'Major' || release.risk === 'HIGH RISK'
                    ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                    : release.riskType === 'Minor' || release.risk === 'MEDIUM RISK'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                    : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                }`}
              >
                Risk: {release.riskType || release.risk || 'Major'}
              </span>

              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-slate-900 border border-slate-800 text-slate-400">
                ID: {release.releaseId}
              </span>
            </div>

            {/* Release Core Metadata Grid */}
            <div className="bg-[#141e2e] border border-slate-800 rounded-xl p-4 grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  Business Unit
                </span>
                <span className="text-white font-bold">{release.businessUnit || '-'}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  Project
                </span>
                <span className="text-cyan-400 font-bold">{release.projectName || '-'}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  Application
                </span>
                <span className="text-purple-400 font-bold">{release.applicationName || '-'}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  Release Manager
                </span>
                <span className="text-slate-200 font-bold">{release.releaseManager || 'Release Lead'}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  Start Date
                </span>
                <span className="text-slate-300">{formatDate(release.startDate)}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  End Date
                </span>
                <span className="text-slate-300">{formatDate(release.endDate)}</span>
              </div>

              <div className="col-span-2">
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  Default Environment
                </span>
                <span className="text-slate-300">{release.environmentName || 'All Environments'}</span>
              </div>

              {release.repositoryUrl && (
                <div className="col-span-2">
                  <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                    Repository URL
                  </span>
                  <a
                    href={release.repositoryUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-orange-400 hover:text-orange-300 flex items-center gap-1 truncate"
                  >
                    {release.repositoryUrl} <ExternalLink className="w-3 h-3 shrink-0" />
                  </a>
                </div>
              )}

              {release.remarks && (
                <div className="col-span-2">
                  <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                    Remarks & Notes
                  </span>
                  <p className="text-slate-300 font-sans text-xs bg-[#0a0f18] p-2.5 rounded-lg border border-slate-800">
                    {release.remarks}
                  </p>
                </div>
              )}
            </div>

            {/* Test Phases Table */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-orange-400" />
                  Release Phases ({(release.phases || []).length})
                </h3>
              </div>

              <div className="bg-[#141e2e] border border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 text-[10px] uppercase font-bold">
                      <th className="px-3 py-2">Phase</th>
                      <th className="px-3 py-2">Environment</th>
                      <th className="px-3 py-2">Timeline Range</th>
                      <th className="px-3 py-2">Duration</th>
                      <th className="px-3 py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {(release.phases || []).length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-3 py-4 text-center text-slate-500">
                          No release phases configured.
                        </td>
                      </tr>
                    ) : (
                      (release.phases || []).map((ph) => {
                        const phaseColor =
                          ph.color || getPhaseColor(ph.phaseName, '#3B82F6');

                        return (
                          <tr
                            key={ph.phaseId}
                            onClick={() => onSelectPhase?.(ph)}
                            className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                          >
                            <td className="px-3 py-2.5">
                              <div className="flex items-center gap-1.5">
                                <span
                                  className="w-2.5 h-2.5 rounded-full shrink-0"
                                  style={{ backgroundColor: phaseColor }}
                                />
                                <span className="font-bold text-white">{ph.phaseName}</span>
                              </div>
                            </td>
                            <td className="px-3 py-2.5 text-slate-300">
                              {ph.environmentName || release.environmentName || '-'}
                            </td>
                            <td className="px-3 py-2.5 text-slate-400 text-[11px]">
                              {formatDate(ph.startDate)} &rarr; {formatDate(ph.endDate)}
                            </td>
                            <td className="px-3 py-2.5 text-slate-300">
                              {calculateDuration(ph.startDate, ph.endDate)}
                            </td>
                            <td className="px-3 py-2.5">
                              <span className="px-2 py-0.5 rounded text-[9px] uppercase font-bold bg-slate-900 border border-slate-800 text-slate-300">
                                {ph.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Drawer Footer Actions */}
          <div className="p-4 border-t border-slate-800 bg-[#090e17] flex items-center justify-between">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Close
            </button>

            {onViewRelease && (
              <button
                onClick={() => onViewRelease(release.releaseId)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-sm"
              >
                <Rocket className="w-3.5 h-3.5" />
                View in Release Management
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
