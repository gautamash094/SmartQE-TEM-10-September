import React from 'react';
import { ReleaseCalendarPhase, ReleaseCalendarRelease } from '../../types/releaseCalendar';
import {
  X,
  Layers,
  Rocket,
  Cpu,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface PhaseDetailDrawerProps {
  phase: ReleaseCalendarPhase | null;
  release?: ReleaseCalendarRelease | null;
  isOpen: boolean;
  onClose: () => void;
  getPhaseColor: (phaseName: string, defaultColor?: string) => string;
}

export const PhaseDetailDrawer: React.FC<PhaseDetailDrawerProps> = ({
  phase,
  release,
  isOpen,
  onClose,
  getPhaseColor,
}) => {
  if (!isOpen || !phase) return null;

  const phaseColor = phase.color || getPhaseColor(phase.phaseName, '#3B82F6');

  const calculateDuration = (startStr?: string, endStr?: string) => {
    if (!startStr || !endStr) return '-';
    try {
      const s = new Date(startStr).getTime();
      const e = new Date(endStr).getTime();
      const days = Math.round(Math.max(0, e - s) / (1000 * 60 * 60 * 24));
      return `${days} ${days === 1 ? 'day' : 'days'}`;
    } catch {
      return '-';
    }
  };

  const formatDate = (dStr?: string) => {
    if (!dStr) return '-';
    try {
      return new Date(dStr).toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dStr;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-mono text-xs">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
      />

      {/* Drawer Panel */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0d131f] border-l border-slate-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
          {/* Drawer Header */}
          <div className="p-5 border-b border-slate-800 bg-[#090e17] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span
                className="w-5 h-5 rounded-md shrink-0 shadow-sm"
                style={{ backgroundColor: phaseColor }}
              />
              <div>
                <span className="text-[10px] text-orange-400 font-bold uppercase tracking-widest">
                  TEST PHASE DETAILS
                </span>
                <h2 className="text-lg font-bold text-white tracking-tight font-sans">
                  {phase.phaseName}
                </h2>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {/* Status & Sequence */}
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-900 border border-slate-800 text-slate-300">
                Status: {phase.status}
              </span>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-slate-900 border border-slate-800 text-slate-400">
                Sequence: #{phase.sequence}
              </span>
            </div>

            {/* Metadata Card */}
            <div className="bg-[#141e2e] border border-slate-800 rounded-xl p-4 space-y-3">
              {release && (
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                    Parent Release
                  </span>
                  <div className="flex items-center gap-1.5 text-white font-bold font-sans">
                    <Rocket className="w-3.5 h-3.5 text-orange-400" />
                    <span>{release.releaseName}</span>
                    <span className="text-[10px] font-mono text-orange-400">
                      ({release.version || 'v1.0.0'})
                    </span>
                  </div>
                </div>
              )}

              {release?.applicationName && (
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                    Application
                  </span>
                  <span className="text-purple-400 font-bold">{release.applicationName}</span>
                </div>
              )}

              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  Assigned Environment
                </span>
                <div className="flex items-center gap-1.5 text-slate-200 font-bold">
                  <Cpu className="w-3.5 h-3.5 text-orange-400" />
                  <span>{phase.environmentName || release?.environmentName || 'All Environments'}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                    Start Date
                  </span>
                  <span className="text-slate-300">{formatDate(phase.startDate)}</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                    End Date
                  </span>
                  <span className="text-slate-300">{formatDate(phase.endDate)}</span>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                  Phase Duration
                </span>
                <span className="text-emerald-400 font-bold">
                  {calculateDuration(phase.startDate, phase.endDate)}
                </span>
              </div>

              {phase.remarks && (
                <div className="pt-2 border-t border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase font-bold block mb-0.5">
                    Remarks & Instructions
                  </span>
                  <p className="text-slate-300 font-sans text-xs bg-[#0a0f18] p-2.5 rounded-lg border border-slate-800">
                    {phase.remarks}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Drawer Footer */}
          <div className="p-4 border-t border-slate-800 bg-[#090e17] flex items-center justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
