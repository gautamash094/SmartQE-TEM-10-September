import React, { useMemo } from 'react';
import {
  ReleaseCalendarGroup,
  ReleaseCalendarRelease,
  ReleaseCalendarPhase,
  ReleaseCalendarConflict,
} from '../../types/releaseCalendar';
import {
  Layers,
  Cpu,
  Rocket,
  Calendar as CalendarIcon,
  Clock,
  AlertTriangle,
  User,
} from 'lucide-react';

interface ReleaseQuarterlyCalendarProps {
  year: number;
  quarter: number;
  groups: ReleaseCalendarGroup[];
  conflicts: ReleaseCalendarConflict[];
  onSelectRelease: (release: ReleaseCalendarRelease) => void;
  onSelectPhase: (phase: ReleaseCalendarPhase, release: ReleaseCalendarRelease) => void;
  getPhaseColor: (phaseName: string, defaultColor?: string) => string;
}

const safeParseDate = (dateVal?: string | Date | null): Date | null => {
  if (!dateVal) return null;
  if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
  const isoStr = String(dateVal).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d;
  const dRaw = new Date(dateVal);
  return isNaN(dRaw.getTime()) ? null : dRaw;
};

const formatDateShort = (d?: Date | null) => {
  if (!d) return '';
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

const calculateDays = (s?: Date | null, e?: Date | null) => {
  if (!s || !e) return '';
  const diff = Math.max(0, e.getTime() - s.getTime());
  const days = Math.round(diff / (1000 * 60 * 60 * 24)) + 1;
  return `${days} ${days === 1 ? 'day' : 'days'}`;
};

export const ReleaseQuarterlyCalendar: React.FC<ReleaseQuarterlyCalendarProps> = ({
  year,
  quarter,
  groups,
  conflicts,
  onSelectRelease,
  onSelectPhase,
  getPhaseColor,
}) => {
  const startMonthIdx = (quarter - 1) * 3;

  // Timeline Boundaries (3 months in quarter)
  const { quarterStartMs, quarterEndMs, totalQuarterDurationMs, monthsMeta, dateTicks } =
    useMemo(() => {
      const start = new Date(year, startMonthIdx, 1, 0, 0, 0);
      const end = new Date(year, startMonthIdx + 3, 0, 23, 59, 59);
      const sMs = start.getTime();
      const eMs = end.getTime();
      const totalMs = Math.max(1, eMs - sMs);

      const mMeta = [0, 1, 2].map((offset) => {
        const mIdx = startMonthIdx + offset;
        const mDate = new Date(year, mIdx, 1);
        const daysInMonth = new Date(year, mIdx + 1, 0).getDate();
        const mStartMs = new Date(year, mIdx, 1, 0, 0, 0).getTime();
        const mEndMs = new Date(year, mIdx, daysInMonth, 23, 59, 59).getTime();

        return {
          monthIdx: mIdx,
          monthName: mDate.toLocaleDateString('en-US', { month: 'long' }).toUpperCase(),
          shortName: mDate.toLocaleDateString('en-US', { month: 'short' }).toUpperCase(),
          daysInMonth,
          widthPercent: ((mEndMs - mStartMs) / totalMs) * 100,
          startMs: mStartMs,
          endMs: mEndMs,
        };
      });

      // 5 Date ticks per month: 01, 08, 15, 22, 29+
      const ticks: { key: string; label: string; subLabel: string; offsetPercent: number }[] = [];

      mMeta.forEach((m) => {
        const dayIntervals = [1, 8, 15, 22, m.daysInMonth >= 30 ? 29 : m.daysInMonth];
        dayIntervals.forEach((dayNum) => {
          const tDate = new Date(year, m.monthIdx, dayNum, 12, 0, 0);
          const tOffset = ((tDate.getTime() - sMs) / totalMs) * 100;
          ticks.push({
            key: `tick-${m.monthIdx}-${dayNum}`,
            label: `${String(dayNum).padStart(2, '0')}`,
            subLabel: m.shortName,
            offsetPercent: Math.max(0, Math.min(100, tOffset)),
          });
        });
      });

      return {
        quarterStartMs: sMs,
        quarterEndMs: eMs,
        totalQuarterDurationMs: totalMs,
        monthsMeta: mMeta,
        dateTicks: ticks,
      };
    }, [year, startMonthIdx]);

  return (
    <div className="bg-[#0f1724] border border-slate-800 rounded-xl overflow-hidden shadow-xl font-mono text-xs flex flex-col">
      {/* ========================================================================= */}
      {/* 1. SYNCHRONIZED TIMELINE HEADER WITH MONTHS & EXPLICIT DATES */}
      {/* ========================================================================= */}
      <div className="bg-[#090e17] border-b border-slate-800 select-none">
        {/* Tier 1: 3 Month Blocks */}
        <div className="grid grid-cols-3 border-b border-slate-800/80">
          {monthsMeta.map((m, idx) => (
            <div
              key={m.monthIdx}
              className="py-2.5 px-4 border-r last:border-r-0 border-slate-800 flex items-center justify-between bg-slate-900/60"
            >
              <div className="flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-orange-400 shrink-0" />
                <span className="font-bold text-white text-xs sm:text-sm tracking-wider">
                  {m.monthName} {year}
                </span>
              </div>
              <span className="text-[10px] font-bold text-slate-400 px-2 py-0.5 rounded bg-slate-800/90 border border-slate-700">
                M{idx + 1} OF Q{quarter}
              </span>
            </div>
          ))}
        </div>

        {/* Tier 2: Date Grid Tick Headers (01, 08, 15, 22, 29) */}
        <div className="grid grid-cols-3 bg-[#0c121e]">
          {monthsMeta.map((m) => (
            <div
              key={m.monthIdx}
              className="grid grid-cols-5 border-r last:border-r-0 border-slate-800/60 py-1.5 text-center text-[10px]"
            >
              {['01', '08', '15', '22', m.daysInMonth >= 30 ? '29+' : String(m.daysInMonth)].map(
                (dayStr, dIdx) => (
                  <div key={dIdx} className="border-r last:border-r-0 border-slate-800/30">
                    <span className="text-slate-300 font-bold block">{dayStr}</span>
                    <span className="text-[8px] text-slate-500 block">{m.shortName}</span>
                  </div>
                )
              )}
            </div>
          ))}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. GROUPS & ALIGNED RELEASE TIMELINE TRACKS */}
      {/* ========================================================================= */}
      <div className="p-4 space-y-4 overflow-x-auto">
        {groups.length === 0 ? (
          <div className="text-center py-12 text-slate-500 font-sans">
            No release timelines found for Q{quarter} {year}.
          </div>
        ) : (
          groups.map((group) => {
            const isEnv = group.groupType === 'environment';

            return (
              <div
                key={group.groupKey}
                className="bg-[#141e2e] border border-slate-800 rounded-xl p-4 space-y-4 shadow-md"
              >
                {/* Group Title Header */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                  <div className="flex items-center gap-2">
                    {isEnv ? (
                      <Cpu className="w-4 h-4 text-orange-400" />
                    ) : (
                      <Layers className="w-4 h-4 text-blue-400" />
                    )}
                    <h3 className="font-bold text-white text-sm tracking-wide">
                      {group.groupName}
                    </h3>
                    {group.businessUnit && (
                      <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 text-[10px]">
                        {group.businessUnit}
                      </span>
                    )}
                  </div>
                  <span className="text-slate-400 text-[11px] font-bold">
                    {group.releases.length} {group.releases.length === 1 ? 'Release' : 'Releases'}
                  </span>
                </div>

                {/* Releases List */}
                <div className="space-y-4">
                  {group.releases.map((rel) => {
                    const rStart = safeParseDate(rel.startDate);
                    const rEnd = safeParseDate(rel.endDate);
                    const rStartMs = rStart ? rStart.getTime() : quarterStartMs;
                    const rEndMs = rEnd ? rEnd.getTime() : quarterEndMs;

                    const relOffsetPercent = Math.max(
                      0,
                      Math.min(
                        100,
                        ((rStartMs - quarterStartMs) / totalQuarterDurationMs) * 100
                      )
                    );
                    const relWidthPercent = Math.max(
                      3,
                      Math.min(
                        100 - relOffsetPercent,
                        ((rEndMs - rStartMs) / totalQuarterDurationMs) * 100
                      )
                    );

                    return (
                      <div
                        key={rel.releaseId}
                        className="p-3.5 bg-[#0a0f18] border border-slate-800 rounded-xl space-y-2.5 hover:border-slate-700 transition-colors"
                      >
                        {/* Release Header Row: Name & Date Info */}
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div
                            onClick={() => onSelectRelease(rel)}
                            className="flex items-center gap-2 cursor-pointer group"
                          >
                            <Rocket className="w-4 h-4 text-orange-400 group-hover:text-orange-300" />
                            <span className="font-bold text-white group-hover:text-orange-300 font-sans text-xs sm:text-sm">
                              {rel.releaseName}
                            </span>
                            <span className="text-xs text-orange-400 font-bold">
                              ({rel.version || 'v1.0.0'})
                            </span>
                          </div>

                          {/* Explicit Date Interval Badge */}
                          <div className="flex items-center gap-3 text-xs text-slate-300">
                            {rel.releaseManager && (
                              <span className="text-slate-400 flex items-center gap-1 hidden sm:inline-flex">
                                <User className="w-3.5 h-3.5 text-slate-500" />
                                {rel.releaseManager}
                              </span>
                            )}
                            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-orange-400 font-bold">
                              <CalendarIcon className="w-3.5 h-3.5" />
                              <span>
                                {formatDateShort(rStart)} &rarr; {formatDateShort(rEnd)}
                              </span>
                              <span className="text-slate-400 font-normal text-[10px]">
                                ({calculateDays(rStart, rEnd)})
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Synchronized Timeline Grid Track */}
                        <div className="relative h-11 w-full bg-[#101725] rounded-lg overflow-hidden border border-slate-800/90 flex items-center p-1">
                          {/* 15 Vertical Date Grid Guidelines (3 Months x 5 intervals) */}
                          <div className="absolute inset-0 grid grid-cols-3 pointer-events-none divide-x divide-slate-700/40">
                            {monthsMeta.map((m) => (
                              <div
                                key={m.monthIdx}
                                className="grid grid-cols-5 h-full divide-x divide-slate-800/40"
                              />
                            ))}
                          </div>

                          {/* Outer Release Span Shading */}
                          <div
                            className="absolute h-9 rounded-md bg-slate-800/40 border border-dashed border-slate-600/60 pointer-events-none z-0"
                            style={{
                              left: `${relOffsetPercent}%`,
                              width: `${relWidthPercent}%`,
                            }}
                          />

                          {/* Individual Test Phase Blocks */}
                          {(rel.phases || []).map((ph, pIdx) => {
                            const pStart = safeParseDate(ph.startDate);
                            const pEnd = safeParseDate(ph.endDate);
                            const pStartMs = pStart ? pStart.getTime() : rStartMs;
                            const pEndMs = pEnd ? pEnd.getTime() : rEndMs;

                            const pOffset = Math.max(
                              0,
                              Math.min(
                                100,
                                ((pStartMs - quarterStartMs) / totalQuarterDurationMs) * 100
                              )
                            );
                            const pWidth = Math.max(
                              2.5,
                              Math.min(
                                100 - pOffset,
                                ((pEndMs - pStartMs) / totalQuarterDurationMs) * 100
                              )
                            );

                            const colorHex =
                              ph.color || getPhaseColor(ph.phaseName, '#3B82F6');

                            return (
                              <div
                                key={ph.phaseId || pIdx}
                                onClick={() => onSelectPhase(ph, rel)}
                                className="absolute h-8 rounded-md transition-all hover:scale-y-105 flex items-center justify-between px-2 text-[10px] font-bold text-white truncate shadow-md cursor-pointer z-10 hover:ring-2 hover:ring-white/80"
                                style={{
                                  left: `${pOffset}%`,
                                  width: `${pWidth}%`,
                                  backgroundColor: colorHex,
                                }}
                                title={`${ph.phaseName}: ${formatDateShort(pStart)} -> ${formatDateShort(pEnd)} (${calculateDays(pStart, pEnd)}) [${ph.status}]`}
                              >
                                <span className="font-bold drop-shadow truncate">
                                  {ph.phaseName}
                                </span>
                                <span className="text-[9px] opacity-90 truncate ml-1 font-mono hidden md:inline">
                                  {formatDateShort(pStart)}–{formatDateShort(pEnd)}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
