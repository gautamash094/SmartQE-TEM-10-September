import React, { useMemo } from 'react';
import {
  CalendarDisplayScope,
  ReleaseCalendarFilterState,
} from '../../types/releaseCalendar';
import { Release, Environment } from '../../types';
import { BusinessUnit, Project, ApplicationEntity } from '../../services/portfolioService';
import {
  Search,
  Filter,
  RotateCcw,
  AlertTriangle,
  Building,
  Rocket,
  Layers,
  Cpu,
  Check,
} from 'lucide-react';

interface ReleaseCalendarFiltersProps {
  displayScope: CalendarDisplayScope;
  filters: ReleaseCalendarFilterState;
  onFilterChange: (updates: Partial<ReleaseCalendarFilterState>) => void;
  onResetFilters: () => void;
  onApplyFilters: () => void;
  releases: Release[];
  businessUnits: BusinessUnit[];
  applications: ApplicationEntity[];
  environments: Environment[];
  conflictsCount: number;
}

export const ReleaseCalendarFilters: React.FC<ReleaseCalendarFiltersProps> = ({
  displayScope,
  filters,
  onFilterChange,
  onResetFilters,
  onApplyFilters,
  releases,
  businessUnits,
  applications,
  environments,
  conflictsCount,
}) => {
  // Cascading logic:
  // 1. Available Releases filtered by selected BU
  const availableReleases = useMemo(() => {
    return releases.filter((r) => {
      if (!filters.buId || filters.buId === 'ALL') return true;
      return r.businessUnit === filters.buId || r.buId === filters.buId;
    });
  }, [releases, filters.buId]);

  // 2. Available Applications filtered by selected BU and selected Release
  const availableApplications = useMemo(() => {
    if (filters.releaseId && filters.releaseId !== 'ALL') {
      const selectedRel = releases.find((r) => r.id === filters.releaseId);
      if (selectedRel?.application) {
        return applications.filter((app) => app.name === selectedRel.application || app.id === selectedRel.applicationId);
      }
    }

    if (filters.buId && filters.buId !== 'ALL') {
      const buObj = businessUnits.find((b) => b.name === filters.buId || b.id === filters.buId);
      if (buObj) {
        return applications.filter((app) => app.businessUnit === buObj.name || app.businessUnit === buObj.id);
      }
    }

    return applications;
  }, [applications, businessUnits, releases, filters.buId, filters.releaseId]);

  // 3. Available Environments filtered by selected Release (if specified)
  const availableEnvironments = useMemo(() => {
    if (filters.releaseId && filters.releaseId !== 'ALL') {
      const selectedRel = releases.find((r) => r.id === filters.releaseId);
      if (selectedRel) {
        const envNames = new Set<string>();
        if (selectedRel.environmentName && selectedRel.environmentName !== 'All Environments') {
          envNames.add(selectedRel.environmentName);
        }
        (selectedRel.phases || []).forEach((p) => {
          if (p.environmentName) envNames.add(p.environmentName);
        });
        if (envNames.size > 0) {
          return environments.filter((env) => envNames.has(env.name) || envNames.has(env.id));
        }
      }
    }
    return environments;
  }, [environments, releases, filters.releaseId]);

  const hasActiveFilters =
    filters.search ||
    (filters.buId && filters.buId !== 'ALL') ||
    (filters.releaseId && filters.releaseId !== 'ALL') ||
    (filters.applicationId && filters.applicationId !== 'ALL') ||
    (filters.environmentId && filters.environmentId !== 'ALL') ||
    (filters.riskType && filters.riskType !== 'ALL') ||
    (filters.status && filters.status !== 'ALL') ||
    filters.showConflictsOnly;

  return (
    <div className="bg-[#0f1724] border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs shadow-sm">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Search */}
        <div className="relative lg:col-span-2">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search releases, apps, envs..."
            value={filters.search}
            onChange={(e) => onFilterChange({ search: e.target.value })}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg pl-9 pr-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 font-sans text-xs"
          />
        </div>

        {/* BU Cascading Filter */}
        <div>
          <label className="block text-[10px] text-slate-400 uppercase tracking-wider mb-1 font-bold">
            Business Unit
          </label>
          <select
            value={filters.buId}
            onChange={(e) => {
              onFilterChange({
                buId: e.target.value,
                releaseId: 'ALL',
                applicationId: 'ALL',
              });
            }}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-2.5 py-2 text-white focus:outline-none focus:border-orange-500 text-xs cursor-pointer"
          >
            <option value="ALL">All Business Units</option>
            {businessUnits.map((bu) => (
              <option key={bu.id} value={bu.name}>
                {bu.name}
              </option>
            ))}
          </select>
        </div>

        {/* Release Cascading Filter */}
        <div>
          <label className="block text-[10px] text-slate-400 uppercase tracking-wider mb-1 font-bold">
            Release
          </label>
          <select
            value={filters.releaseId}
            onChange={(e) => {
              onFilterChange({
                releaseId: e.target.value,
                applicationId: 'ALL',
              });
            }}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-2.5 py-2 text-white focus:outline-none focus:border-orange-500 text-xs cursor-pointer truncate"
          >
            <option value="ALL">All Releases</option>
            {availableReleases.map((rel) => (
              <option key={rel.id} value={rel.id}>
                {rel.name}
              </option>
            ))}
          </select>
        </div>

        {/* Application Cascading Filter */}
        <div>
          <label className="block text-[10px] text-slate-400 uppercase tracking-wider mb-1 font-bold">
            Application
          </label>
          <select
            value={filters.applicationId}
            onChange={(e) => onFilterChange({ applicationId: e.target.value })}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-2.5 py-2 text-white focus:outline-none focus:border-orange-500 text-xs cursor-pointer truncate"
          >
            <option value="ALL">All Applications</option>
            {availableApplications.map((app) => (
              <option key={app.id} value={app.name}>
                {app.name}
              </option>
            ))}
          </select>
        </div>

        {/* Environment Filter */}
        <div>
          <label className="block text-[10px] text-slate-400 uppercase tracking-wider mb-1 font-bold">
            Environment
          </label>
          <select
            value={filters.environmentId}
            onChange={(e) => onFilterChange({ environmentId: e.target.value })}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-2.5 py-2 text-white focus:outline-none focus:border-orange-500 text-xs cursor-pointer truncate"
          >
            <option value="ALL">All Environments</option>
            {availableEnvironments.map((env) => (
              <option key={env.id} value={env.name}>
                {env.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Bottom Row: Additional filters & Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
        <div className="flex flex-wrap items-center gap-3">
          {/* Risk Type Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 text-[11px]">Risk:</span>
            <select
              value={filters.riskType}
              onChange={(e) => onFilterChange({ riskType: e.target.value })}
              className="bg-[#161f2e] border border-slate-700/80 text-white text-xs rounded-md px-2 py-1 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="ALL">All Risks</option>
              <option value="Major">Major</option>
              <option value="Minor">Minor</option>
              <option value="Patch">Patch</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 text-[11px]">Status:</span>
            <select
              value={filters.status}
              onChange={(e) => onFilterChange({ status: e.target.value })}
              className="bg-[#161f2e] border border-slate-700/80 text-white text-xs rounded-md px-2 py-1 focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="ALL">All Statuses</option>
              <option value="SCHEDULED">Scheduled</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="DEPLOYED">Deployed</option>
              <option value="COMPLETED">Completed</option>
              <option value="FAILED">Failed</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
          </div>

          {/* Conflict Toggle */}
          <button
            type="button"
            onClick={() => onFilterChange({ showConflictsOnly: !filters.showConflictsOnly })}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
              filters.showConflictsOnly
                ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                : 'text-slate-400 hover:text-slate-200 bg-[#161f2e] border border-slate-800'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            <span>Show Conflicts Only</span>
            {conflictsCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-red-500/30 text-red-300 font-bold">
                {conflictsCount}
              </span>
            )}
          </button>
        </div>

        {/* Buttons: [Apply Filters] [Reset Filters] */}
        <div className="flex items-center gap-2">
          {hasActiveFilters && (
            <button
              type="button"
              onClick={onResetFilters}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer border border-transparent hover:border-slate-700"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Filters
            </button>
          )}

          <button
            type="button"
            onClick={onApplyFilters}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-sm cursor-pointer"
          >
            <Filter className="w-3.5 h-3.5" />
            Apply Filters
          </button>
        </div>
      </div>
    </div>
  );
};
