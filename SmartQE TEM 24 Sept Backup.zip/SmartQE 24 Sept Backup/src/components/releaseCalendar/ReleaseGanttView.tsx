import React, { useState, useMemo, useRef } from 'react';
import {
  CalendarDisplayScope,
  CalendarTimePeriod,
  ReleaseCalendarGroup,
  ReleaseCalendarRelease,
  ReleaseCalendarPhase,
  ReleaseCalendarConflict,
} from '../../types/releaseCalendar';
import {
  ChevronRight,
  ChevronDown,
  Rocket,
  Layers,
  Cpu,
  AlertTriangle,
  Calendar as CalendarIcon,
} from 'lucide-react';

interface ReleaseGanttViewProps {
  displayScope: CalendarDisplayScope;
  timePeriod: CalendarTimePeriod;
  year: number;
  month: number;
  quarter: number;
  groups: ReleaseCalendarGroup[];
  conflicts: ReleaseCalendarConflict[];
  onSelectRelease: (release: ReleaseCalendarRelease) => void;
  onSelectPhase: (phase: ReleaseCalendarPhase, release: ReleaseCalendarRelease) => void;
  getPhaseColor: (phaseName: string, defaultColor?: string) => string;
}

const safeParseDate = (dateVal?: string | Date | null): Date | null => {
  if (!dateVal) return null;
  if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
  const isoStr = String(dateVal).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d;
  const dRaw = new Date(dateVal);
  return isNaN(dRaw.getTime()) ? null : dRaw;
};

const formatDateShort = (d?: Date | null) => {
  if (!d) return '';
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

const MONTH_NAMES = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

interface TopTierHeader {
  key: string;
  label: string;
  subLabel?: string;
  widthPercent: number;
}

interface SubTierColumn {
  key: string;
  label: string;
  subLabel?: string;
  widthPercent: number;
}

export const ReleaseGanttView: React.FC<ReleaseGanttViewProps> = ({
  displayScope,
  timePeriod,
  year,
  month,
  quarter,
  groups,
  conflicts,
  onSelectRelease,
  onSelectPhase,
  getPhaseColor,
}) => {
  // Collapsible state for groups and releases
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const [collapsedReleases, setCollapsedReleases] = useState<Record<string, boolean>>({});

  const toggleGroup = (key: string) => {
    setCollapsedGroups((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleRelease = (id: string) => {
    setCollapsedReleases((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Compute timeline boundaries, top-tier headers, and sub-tier column headers
  const {
    timelineStartMs,
    timelineEndMs,
    totalDurationMs,
    topTierHeaders,
    gridColumns,
  } = useMemo(() => {
    let start: Date;
    let end: Date;
    const topTiers: TopTierHeader[] = [];
    const cols: SubTierColumn[] = [];

    if (timePeriod === 'month') {
      start = new Date(year, month - 1, 1, 0, 0, 0);
      const daysInM = new Date(year, month, 0).getDate();
      end = new Date(year, month - 1, daysInM, 23, 59, 59);

      const mName = new Date(year, month - 1, 1).toLocaleDateString('en-US', {
        month: 'long',
      });

      topTiers.push({
        key: `month-${month}`,
        label: `${mName.toUpperCase()} ${year}`,
        subLabel: `${daysInM} DAYS`,
        widthPercent: 100,
      });

      for (let d = 1; d <= daysInM; d++) {
        const dObj = new Date(year, month - 1, d);
        const dayOfWeek = dObj.toLocaleDateString('en-US', { weekday: 'narrow' });
        cols.push({
          key: `day-${d}`,
          label: String(d).padStart(2, '0'),
          subLabel: dayOfWeek,
          widthPercent: 100 / daysInM,
        });
      }
    } else if (timePeriod === 'quarter') {
      const startM = (quarter - 1) * 3;
      start = new Date(year, startM, 1, 0, 0, 0);
      const endM = startM + 2;
      const lastDay = new Date(year, endM + 1, 0).getDate();
      end = new Date(year, endM, lastDay, 23, 59, 59);

      // 3 Months in Quarter
      const monthMeta = [0, 1, 2].map((offset) => {
        const mDate = new Date(year, startM + offset, 1);
        const days = new Date(year, startM + offset + 1, 0).getDate();
        return {
          monthDate: mDate,
          monthName: mDate.toLocaleDateString('en-US', { month: 'short' }).toUpperCase(),
          fullMonthName: mDate.toLocaleDateString('en-US', { month: 'long' }),
          days,
          offset,
        };
      });

      const totalDays = monthMeta.reduce((acc, curr) => acc + curr.days, 0);

      monthMeta.forEach((m, idx) => {
        const mPercent = (m.days / totalDays) * 100;
        topTiers.push({
          key: `q-top-${idx}`,
          label: `${m.fullMonthName.toUpperCase()} ${year}`,
          subLabel: `M${idx + 1} OF Q${quarter}`,
          widthPercent: mPercent,
        });

        // 5 sub-intervals per month: 01, 08, 15, 22, 29+
        const ticks = [
          { label: '01', sub: 'W1' },
          { label: '08', sub: 'W2' },
          { label: '15', sub: 'W3' },
          { label: '22', sub: 'W4' },
          {
            label: m.days >= 30 ? (m.days === 31 ? '29-31' : '29-30') : '28',
            sub: 'W5',
          },
        ];

        const tickPercent = mPercent / 5;
        ticks.forEach((tick, tIdx) => {
          cols.push({
            key: `q-m${idx}-t${tIdx}`,
            label: tick.label,
            subLabel: m.monthName,
            widthPercent: tickPercent,
          });
        });
      });
    } else {
      // Year: 4 Quarters Top Tier + 12 Months Sub Tier
      start = new Date(year, 0, 1, 0, 0, 0);
      end = new Date(year, 11, 31, 23, 59, 59);

      const quarterNames = ['Q1 • JAN–MAR', 'Q2 • APR–JUN', 'Q3 • JUL–SEP', 'Q4 • OCT–DEC'];
      quarterNames.forEach((qn, qIdx) => {
        topTiers.push({
          key: `y-quarter-${qIdx}`,
          label: `${qn} ${year}`,
          widthPercent: 25,
        });
      });

      MONTH_NAMES.forEach((mn, idx) => {
        cols.push({
          key: `y-month-${idx}`,
          label: mn.toUpperCase(),
          subLabel: '01 & 15',
          widthPercent: 100 / 12,
        });
      });
    }

    const startMs = start.getTime();
    const endMs = end.getTime();
    const durMs = Math.max(1, endMs - startMs);

    return {
      timelineStartMs: startMs,
      timelineEndMs: endMs,
      totalDurationMs: durMs,
      topTierHeaders: topTiers,
      gridColumns: cols,
    };
  }, [timePeriod, year, month, quarter]);

  // Conflict helper
  const isPhaseInConflict = (releaseId: string, phaseId: string) => {
    return conflicts.some(
      (c) =>
        (c.releaseA.releaseId === releaseId && c.releaseA.phaseId === phaseId) ||
        (c.releaseB.releaseId === releaseId && c.releaseB.phaseId === phaseId)
    );
  };

  const isReleaseInConflict = (releaseId: string) => {
    return conflicts.some(
      (c) => c.releaseA.releaseId === releaseId || c.releaseB.releaseId === releaseId
    );
  };

  // Synchronized scrolling ref
  const timelineCanvasRef = useRef<HTMLDivElement>(null);

  const minCanvasWidth =
    timePeriod === 'month' ? 'min-w-[900px]' : timePeriod === 'quarter' ? 'min-w-[850px]' : 'min-w-[850px]';

  return (
    <div className="bg-[#0f1724] border border-slate-800 rounded-xl overflow-hidden shadow-xl font-mono text-xs flex flex-col">
      {/* Dual Pane Layout */}
      <div className="flex flex-col lg:flex-row divide-y lg:divide-y-0 lg:divide-x divide-slate-800">
        {/* ========================================================================= */}
        {/* LEFT PANE: Hierarchy Tree (Group -> Release -> Phase) */}
        {/* ========================================================================= */}
        <div className="w-full lg:w-[380px] shrink-0 bg-[#0a0f18] flex flex-col">
          {/* Header matching 2-tier height */}
          <div className="h-16 px-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between font-bold text-slate-400 uppercase tracking-wider text-[11px]">
            <span className="flex items-center gap-1.5">
              {displayScope === 'application' ? (
                <>
                  <Layers className="w-3.5 h-3.5 text-blue-400" /> Application / Release / Phase
                </>
              ) : (
                <>
                  <Cpu className="w-3.5 h-3.5 text-orange-400" /> Environment / Release / Phase
                </>
              )}
            </span>
            <span className="text-[10px] text-slate-500 font-bold px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700">
              Hierarchy
            </span>
          </div>

          {/* Tree Rows */}
          <div className="divide-y divide-slate-800/40 overflow-y-auto max-h-[600px]">
            {groups.length === 0 ? (
              <div className="p-8 text-center text-slate-500 font-sans">
                No items found for the current filters.
              </div>
            ) : (
              groups.map((group) => {
                const isGroupCollapsed = !!collapsedGroups[group.groupKey];

                return (
                  <div key={group.groupKey} className="group-row">
                    {/* Level 1: Group Row (Application or Environment) */}
                    <div
                      onClick={() => toggleGroup(group.groupKey)}
                      className="h-10 px-3 flex items-center justify-between bg-[#101725] hover:bg-[#162032] cursor-pointer transition-colors border-l-4 border-blue-500"
                    >
                      <div className="flex items-center gap-2 truncate flex-1 min-w-0">
                        {isGroupCollapsed ? (
                          <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                        )}
                        {group.groupType === 'environment' ? (
                          <Cpu className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                        ) : (
                          <Layers className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                        )}
                        <span className="font-bold text-white truncate text-xs">
                          {group.groupName}
                        </span>
                      </div>

                      <span className="text-[10px] font-bold text-slate-400 px-2 py-0.5 rounded bg-slate-900 border border-slate-800 shrink-0">
                        {group.releases.length}
                      </span>
                    </div>

                    {/* Group Children: Releases */}
                    {!isGroupCollapsed && (
                      <div className="divide-y divide-slate-800/30">
                        {group.releases.map((rel) => {
                          const isRelCollapsed = !!collapsedReleases[rel.releaseId];
                          const hasRelConflict = isReleaseInConflict(rel.releaseId);
                          const phasesCount = (rel.phases || []).length;

                          return (
                            <div key={rel.releaseId} className="release-row">
                              {/* Level 2: Release Row */}
                              <div
                                className={`h-9 pl-7 pr-3 flex items-center justify-between hover:bg-[#141e2e] transition-colors cursor-pointer border-l-2 ${
                                  hasRelConflict
                                    ? 'border-red-500 bg-red-500/5'
                                    : 'border-slate-700 bg-[#0c121e]'
                                }`}
                              >
                                <div
                                  onClick={() => toggleRelease(rel.releaseId)}
                                  className="flex items-center gap-1.5 truncate flex-1 min-w-0"
                                >
                                  {phasesCount > 0 ? (
                                    isRelCollapsed ? (
                                      <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                    ) : (
                                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                    )
                                  ) : (
                                    <span className="w-3.5" />
                                  )}
                                  <Rocket className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                                  <span
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onSelectRelease(rel);
                                    }}
                                    className="font-bold text-slate-200 hover:text-orange-300 truncate text-[11px]"
                                    title={rel.releaseName}
                                  >
                                    {rel.releaseName}
                                  </span>
                                </div>

                                <div className="flex items-center gap-1.5 shrink-0">
                                  {hasRelConflict && (
                                    <span title="Conflict detected">
                                      <AlertTriangle className="w-3 h-3 text-red-400" />
                                    </span>
                                  )}
                                  <span className="text-[9px] text-orange-400 font-bold px-1 rounded bg-orange-500/10">
                                    {rel.version || 'v1.0'}
                                  </span>
                                </div>
                              </div>

                              {/* Level 3: Phase Rows */}
                              {!isRelCollapsed &&
                                (rel.phases || []).map((ph) => {
                                  const phaseColor =
                                    ph.color || getPhaseColor(ph.phaseName, '#3B82F6');
                                  const hasPhConflict = isPhaseInConflict(
                                    rel.releaseId,
                                    ph.phaseId
                                  );

                                  return (
                                    <div
                                      key={ph.phaseId}
                                      onClick={() => onSelectPhase(ph, rel)}
                                      className={`h-8 pl-12 pr-3 flex items-center justify-between hover:bg-[#162030] transition-colors cursor-pointer text-[11px] ${
                                        hasPhConflict ? 'bg-red-500/10' : 'bg-[#080d15]'
                                      }`}
                                    >
                                      <div className="flex items-center gap-2 truncate">
                                        <span
                                          className="w-2 h-2 rounded-full shrink-0"
                                          style={{ backgroundColor: phaseColor }}
                                        />
                                        <span className="text-slate-300 hover:text-white font-sans font-medium truncate">
                                          {ph.phaseName}
                                        </span>
                                      </div>

                                      <div className="flex items-center gap-2 text-[10px] text-slate-500 shrink-0">
                                        <span className="truncate max-w-[90px]">
                                          {ph.environmentName || rel.environmentName}
                                        </span>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* ========================================================================= */}
        {/* RIGHT PANE: Synchronized Horizontal Gantt Timeline Canvas */}
        {/* ========================================================================= */}
        <div
          ref={timelineCanvasRef}
          className="flex-1 overflow-x-auto overflow-y-hidden bg-[#070b12]"
        >
          <div className={`${minCanvasWidth} flex flex-col`}>
            {/* 2-Tier Timeline Column Header with Dates */}
            <div className="h-16 bg-slate-900/90 border-b border-slate-800 flex flex-col select-none">
              {/* Top Tier: Quarter / Month blocks */}
              <div className="h-8 flex border-b border-slate-800/80 bg-slate-900 font-bold text-slate-200 uppercase tracking-wider text-[11px]">
                {topTierHeaders.map((top) => (
                  <div
                    key={top.key}
                    className="h-full border-r last:border-r-0 border-slate-800 flex items-center justify-between px-3 text-center"
                    style={{ width: `${top.widthPercent}%` }}
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      <CalendarIcon className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                      <span className="truncate">{top.label}</span>
                    </div>
                    {top.subLabel && (
                      <span className="text-[9px] text-slate-400 font-bold px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 shrink-0">
                        {top.subLabel}
                      </span>
                    )}
                  </div>
                ))}
              </div>

              {/* Sub Tier: Explicit Date Markers and Column Headers */}
              <div className="h-8 flex bg-[#0c121e] text-center text-[10px] text-slate-400 font-bold">
                {gridColumns.map((col) => (
                  <div
                    key={col.key}
                    className="h-full border-r border-slate-800/70 flex flex-col items-center justify-center px-0.5"
                    style={{ width: `${col.widthPercent}%` }}
                  >
                    <span className="text-white font-bold text-[10px] leading-tight">
                      {col.label}
                    </span>
                    {col.subLabel && (
                      <span className="text-[8px] text-slate-400 font-normal leading-tight">
                        {col.subLabel}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Timeline Canvas Rows */}
            <div className="divide-y divide-slate-800/40">
              {groups.map((group) => {
                const isGroupCollapsed = !!collapsedGroups[group.groupKey];

                return (
                  <div key={group.groupKey}>
                    {/* Level 1 Group Placeholder Row */}
                    <div className="h-10 bg-[#101725]/50 border-r border-slate-800/40 relative flex items-center">
                      <div className="absolute inset-0 flex pointer-events-none opacity-20">
                        {gridColumns.map((col) => (
                          <div
                            key={col.key}
                            className="border-r border-slate-600 h-full"
                            style={{ width: `${col.widthPercent}%` }}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Level 2 Releases & Phases Canvas Rows */}
                    {!isGroupCollapsed &&
                      group.releases.map((rel) => {
                        const isRelCollapsed = !!collapsedReleases[rel.releaseId];
                        const rStart = safeParseDate(rel.startDate);
                        const rEnd = safeParseDate(rel.endDate);
                        const rStartMs = rStart ? rStart.getTime() : timelineStartMs;
                        const rEndMs = rEnd ? rEnd.getTime() : timelineEndMs;

                        const relOffset = Math.max(
                          0,
                          Math.min(100, ((rStartMs - timelineStartMs) / totalDurationMs) * 100)
                        );
                        const relWidth = Math.max(
                          2,
                          Math.min(100 - relOffset, ((rEndMs - rStartMs) / totalDurationMs) * 100)
                        );

                        const hasRelConflict = isReleaseInConflict(rel.releaseId);

                        return (
                          <div key={rel.releaseId}>
                            {/* Release Bar Row */}
                            <div className="h-9 relative bg-[#0c121e]/60 flex items-center">
                              {/* Grid lines background aligned with dates */}
                              <div className="absolute inset-0 flex pointer-events-none">
                                {gridColumns.map((col) => (
                                  <div
                                    key={col.key}
                                    className="border-r border-slate-800/30 h-full"
                                    style={{ width: `${col.widthPercent}%` }}
                                  />
                                ))}
                              </div>

                              {/* Release Gantt Timeline Bar with Date Markers */}
                              <div
                                onClick={() => onSelectRelease(rel)}
                                className={`absolute h-6 rounded-md px-2 flex items-center justify-between text-[10px] font-bold text-white cursor-pointer shadow-md transition-all hover:scale-y-105 z-10 ${
                                  hasRelConflict
                                    ? 'bg-gradient-to-r from-red-600 to-orange-600 border border-red-400'
                                    : 'bg-gradient-to-r from-slate-700 to-slate-800 border border-slate-600 hover:border-orange-500'
                                }`}
                                style={{
                                  left: `${relOffset}%`,
                                  width: `${relWidth}%`,
                                }}
                                title={`${rel.releaseName} (${formatDateShort(rStart)} - ${formatDateShort(rEnd)}) [${rel.status}]`}
                              >
                                <span className="truncate drop-shadow flex-1 mr-1">{rel.releaseName}</span>
                                {rStart && rEnd && (
                                  <span className="text-[9px] text-slate-300 font-normal mr-1 shrink-0 hidden sm:inline">
                                    {formatDateShort(rStart)} &ndash; {formatDateShort(rEnd)}
                                  </span>
                                )}
                                <span className="text-[9px] text-orange-300 font-bold px-1 rounded bg-black/30 shrink-0">
                                  {rel.version || 'v1.0'}
                                </span>
                              </div>
                            </div>

                            {/* Phase Bar Rows */}
                            {!isRelCollapsed &&
                              (rel.phases || []).map((ph) => {
                                const pStart = safeParseDate(ph.startDate);
                                const pEnd = safeParseDate(ph.endDate);
                                const pStartMs = pStart ? pStart.getTime() : rStartMs;
                                const pEndMs = pEnd ? pEnd.getTime() : rEndMs;

                                const pOffset = Math.max(
                                  0,
                                  Math.min(100, ((pStartMs - timelineStartMs) / totalDurationMs) * 100)
                                );
                                const pWidth = Math.max(
                                  1.5,
                                  Math.min(100 - pOffset, ((pEndMs - pStartMs) / totalDurationMs) * 100)
                                );

                                const phaseColor =
                                  ph.color || getPhaseColor(ph.phaseName, '#3B82F6');
                                const hasPhConflict = isPhaseInConflict(
                                  rel.releaseId,
                                  ph.phaseId
                                );

                                return (
                                  <div
                                    key={ph.phaseId}
                                    className="h-8 relative bg-[#080d15]/40 flex items-center"
                                  >
                                    {/* Grid lines background aligned with dates */}
                                    <div className="absolute inset-0 flex pointer-events-none">
                                      {gridColumns.map((col) => (
                                        <div
                                          key={col.key}
                                          className="border-r border-slate-800/20 h-full"
                                          style={{ width: `${col.widthPercent}%` }}
                                        />
                                      ))}
                                    </div>

                                    {/* Phase Bar with Dates */}
                                    <div
                                      onClick={() => onSelectPhase(ph, rel)}
                                      className="absolute h-5 rounded px-1.5 flex items-center justify-between text-[10px] font-bold text-white cursor-pointer shadow-xs transition-transform hover:scale-y-110 z-10"
                                      style={{
                                        left: `${pOffset}%`,
                                        width: `${pWidth}%`,
                                        backgroundColor: phaseColor,
                                        border: hasPhConflict ? '1.5px solid #EF4444' : undefined,
                                      }}
                                      title={`${ph.phaseName}: ${ph.startDate?.substring(0, 10)} -> ${ph.endDate?.substring(0, 10)} (${ph.status})`}
                                    >
                                      <span className="truncate drop-shadow flex-1 mr-1">{ph.phaseName}</span>
                                      {pStart && pEnd && (
                                        <span className="text-[8px] opacity-90 font-mono font-normal mr-1 shrink-0 hidden sm:inline">
                                          {formatDateShort(pStart)} &ndash; {formatDateShort(pEnd)}
                                        </span>
                                      )}
                                      {hasPhConflict && (
                                        <AlertTriangle className="w-3 h-3 text-red-200 shrink-0 ml-1" />
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                          </div>
                        );
                      })}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
