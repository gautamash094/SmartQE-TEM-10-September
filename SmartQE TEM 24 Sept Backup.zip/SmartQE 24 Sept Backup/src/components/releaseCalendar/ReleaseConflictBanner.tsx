import React, { useState } from 'react';
import { ReleaseCalendarConflict } from '../../types/releaseCalendar';
import { AlertTriangle, ChevronDown, ChevronUp, Layers, Cpu, Calendar, X } from 'lucide-react';

interface ReleaseConflictBannerProps {
  conflicts: ReleaseCalendarConflict[];
  onSelectConflict?: (conflict: ReleaseCalendarConflict) => void;
}

export const ReleaseConflictBanner: React.FC<ReleaseConflictBannerProps> = ({
  conflicts,
  onSelectConflict,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [dismissed, setDismissed] = useState<boolean>(false);

  if (!conflicts || conflicts.length === 0 || dismissed) {
    return null;
  }

  const formatShortDate = (dtStr: string) => {
    try {
      const d = new Date(dtStr);
      return d.toLocaleDateString('en-US', { day: '2-digit', month: 'short' });
    } catch {
      return dtStr;
    }
  };

  return (
    <div className="bg-red-500/10 border border-red-500/30 rounded-xl overflow-hidden font-mono text-xs shadow-md animate-in fade-in duration-200">
      {/* Banner Header */}
      <div className="p-3.5 flex items-center justify-between gap-3 bg-red-500/15 border-b border-red-500/20">
        <div className="flex items-center gap-2.5">
          <div className="p-1 rounded bg-red-500/20 text-red-400">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-red-300 uppercase tracking-wider text-[11px]">
              {conflicts.length} {conflicts.length === 1 ? 'Schedule Conflict / Overlap' : 'Schedule Conflicts / Overlaps'} Detected
            </span>
            <p className="text-[11px] text-red-200/80 font-sans">
              Concurrent release activities or environment contentions require operational attention.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-red-500/20 hover:bg-red-500/30 text-red-300 font-bold text-[11px] transition-colors cursor-pointer"
          >
            {isExpanded ? (
              <>
                <ChevronUp className="w-3.5 h-3.5" /> Hide Details
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5" /> View ({conflicts.length})
              </>
            )}
          </button>
          <button
            type="button"
            onClick={() => setDismissed(true)}
            className="p-1 rounded text-red-400 hover:text-white hover:bg-red-500/30 transition-colors cursor-pointer"
            title="Dismiss banner"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Expanded Conflict List */}
      {isExpanded && (
        <div className="p-3 space-y-2 max-h-56 overflow-y-auto divide-y divide-red-500/15">
          {conflicts.map((conf) => {
            const isEnv = conf.type === 'environment';

            return (
              <div
                key={conf.id}
                onClick={() => onSelectConflict?.(conf)}
                className="pt-2 first:pt-0 flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2 rounded-lg hover:bg-red-500/10 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  {isEnv ? (
                    <Cpu className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                  ) : (
                    <Layers className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-white truncate">{conf.entityName}</span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[9px] uppercase font-bold tracking-wider ${
                          isEnv ? 'bg-orange-500/20 text-orange-300' : 'bg-blue-500/20 text-blue-300'
                        }`}
                      >
                        {conf.type}
                      </span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] bg-red-500/20 text-red-300 uppercase font-bold">
                        {conf.severity}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 font-sans mt-0.5">{conf.message}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 text-[11px] text-red-300 bg-red-500/20 px-2 py-1 rounded font-mono">
                  <Calendar className="w-3 h-3 text-red-400" />
                  <span>
                    {formatShortDate(conf.conflictStartDate)} &rarr; {formatShortDate(conf.conflictEndDate)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
