import React, { useMemo } from 'react';
import {
  ReleaseCalendarGroup,
  ReleaseCalendarRelease,
  ReleaseCalendarPhase,
  ReleaseCalendarConflict,
} from '../../types/releaseCalendar';
import {
  Layers,
  Cpu,
  Rocket,
  Calendar as CalendarIcon,
  User,
} from 'lucide-react';

interface ReleaseYearlyCalendarProps {
  year: number;
  groups: ReleaseCalendarGroup[];
  conflicts: ReleaseCalendarConflict[];
  onSelectRelease: (release: ReleaseCalendarRelease) => void;
  onSelectPhase: (phase: ReleaseCalendarPhase, release: ReleaseCalendarRelease) => void;
  getPhaseColor: (phaseName: string, defaultColor?: string) => string;
}

const safeParseDate = (dateVal?: string | Date | null): Date | null => {
  if (!dateVal) return null;
  if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
  const isoStr = String(dateVal).replace(' ', 'T');
  const d = new Date(isoStr);
  if (!isNaN(d.getTime())) return d;
  const dRaw = new Date(dateVal);
  return isNaN(dRaw.getTime()) ? null : dRaw;
};

const formatDateShort = (d?: Date | null) => {
  if (!d) return '';
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

const calculateDays = (s?: Date | null, e?: Date | null) => {
  if (!s || !e) return '';
  const diff = Math.max(0, e.getTime() - s.getTime());
  const days = Math.round(diff / (1000 * 60 * 60 * 24)) + 1;
  return `${days} ${days === 1 ? 'day' : 'days'}`;
};

const MONTH_NAMES = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

const QUARTERS = [
  { name: 'Q1', months: 'Jan – Mar' },
  { name: 'Q2', months: 'Apr – Jun' },
  { name: 'Q3', months: 'Jul – Sep' },
  { name: 'Q4', months: 'Oct – Dec' },
];

export const ReleaseYearlyCalendar: React.FC<ReleaseYearlyCalendarProps> = ({
  year,
  groups,
  conflicts,
  onSelectRelease,
  onSelectPhase,
  getPhaseColor,
}) => {
  const { yearStartMs, yearEndMs, totalYearDurationMs, monthsMeta } = useMemo(() => {
    const start = new Date(year, 0, 1, 0, 0, 0);
    const end = new Date(year, 11, 31, 23, 59, 59);
    const sMs = start.getTime();
    const eMs = end.getTime();
    const totalMs = Math.max(1, eMs - sMs);

    const mMeta = MONTH_NAMES.map((name, idx) => {
      const mDate = new Date(year, idx, 1);
      const daysInMonth = new Date(year, idx + 1, 0).getDate();
      const mStartMs = new Date(year, idx, 1, 0, 0, 0).getTime();
      const mEndMs = new Date(year, idx, daysInMonth, 23, 59, 59).getTime();

      return {
        monthIdx: idx,
        name,
        fullName: mDate.toLocaleDateString('en-US', { month: 'long' }),
        daysInMonth,
        startMs: mStartMs,
        endMs: mEndMs,
        widthPercent: ((mEndMs - mStartMs) / totalMs) * 100,
      };
    });

    return {
      yearStartMs: sMs,
      yearEndMs: eMs,
      totalYearDurationMs: totalMs,
      monthsMeta: mMeta,
    };
  }, [year]);

  return (
    <div className="bg-[#0f1724] border border-slate-800 rounded-xl overflow-hidden shadow-xl font-mono text-xs flex flex-col">
      {/* ========================================================================= */}
      {/* 1. SYNCHRONIZED TIMELINE HEADER (QUARTERS & 12 MONTH TICK COLUMNS)        */}
      {/* ========================================================================= */}
      <div className="bg-[#090e17] border-b border-slate-800 select-none overflow-x-auto">
        {/* Tier 1: 4 Quarters Header */}
        <div className="min-w-[850px] grid grid-cols-4 border-b border-slate-800/80">
          {QUARTERS.map((q, qIdx) => (
            <div
              key={q.name}
              className="py-2.5 px-4 border-r last:border-r-0 border-slate-800 flex items-center justify-between bg-slate-900/60"
            >
              <div className="flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-orange-400 shrink-0" />
                <span className="font-bold text-white text-xs sm:text-sm tracking-wider">
                  {q.name} {year}
                </span>
              </div>
              <span className="text-[10px] font-bold text-slate-400 px-2 py-0.5 rounded bg-slate-800/90 border border-slate-700">
                {q.months}
              </span>
            </div>
          ))}
        </div>

        {/* Tier 2: 12 Month Sub-Columns with Day Graduations (01 & 15) */}
        <div className="min-w-[850px] grid grid-cols-12 bg-[#0c121e]">
          {monthsMeta.map((m) => (
            <div
              key={m.monthIdx}
              className="border-r last:border-r-0 border-slate-800/60 py-1.5 px-1 flex flex-col items-center justify-center text-center"
            >
              <div className="flex items-center justify-between w-full px-1 text-[9px] text-slate-400 font-bold">
                <span className="text-white">{m.name.toUpperCase()}</span>
                <span className="text-[8px] text-slate-500">{m.daysInMonth}d</span>
              </div>
              <div className="flex justify-between w-full px-1 text-[8px] text-slate-500 mt-0.5">
                <span>01</span>
                <span>15</span>
                <span>{m.daysInMonth}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. GROUPS & ALIGNED RELEASE TIMELINE TRACKS                               */}
      {/* ========================================================================= */}
      <div className="p-4 space-y-4 overflow-x-auto">
        {groups.length === 0 ? (
          <div className="text-center py-12 text-slate-500 font-sans">
            No releases scheduled for the year {year}.
          </div>
        ) : (
          groups.map((group) => {
            const isEnv = group.groupType === 'environment';

            return (
              <div
                key={group.groupKey}
                className="bg-[#141e2e] border border-slate-800 rounded-xl p-4 space-y-4 shadow-md min-w-[850px]"
              >
                {/* Group Title Header */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                  <div className="flex items-center gap-2">
                    {isEnv ? (
                      <Cpu className="w-4 h-4 text-orange-400" />
                    ) : (
                      <Layers className="w-4 h-4 text-blue-400" />
                    )}
                    <h3 className="font-bold text-white text-sm tracking-wide">
                      {group.groupName}
                    </h3>
                    {group.businessUnit && (
                      <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 text-[10px]">
                        {group.businessUnit}
                      </span>
                    )}
                  </div>
                  <span className="text-slate-400 text-[11px] font-bold">
                    {group.releases.length} {group.releases.length === 1 ? 'Release' : 'Releases'}
                  </span>
                </div>

                {/* Release Rows */}
                <div className="space-y-4">
                  {group.releases.map((rel) => {
                    const rStart = safeParseDate(rel.startDate);
                    const rEnd = safeParseDate(rel.endDate);
                    const rStartMs = rStart ? rStart.getTime() : yearStartMs;
                    const rEndMs = rEnd ? rEnd.getTime() : yearEndMs;

                    const relOffsetPercent = Math.max(
                      0,
                      Math.min(100, ((rStartMs - yearStartMs) / totalYearDurationMs) * 100)
                    );
                    const relWidthPercent = Math.max(
                      2.5,
                      Math.min(100 - relOffsetPercent, ((rEndMs - rStartMs) / totalYearDurationMs) * 100)
                    );

                    return (
                      <div
                        key={rel.releaseId}
                        className="p-3.5 bg-[#0a0f18] border border-slate-800 rounded-xl space-y-2.5 hover:border-slate-700 transition-colors"
                      >
                        {/* Release Header Row: Name & Explicit Date Info */}
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div
                            onClick={() => onSelectRelease(rel)}
                            className="flex items-center gap-2 cursor-pointer group"
                          >
                            <Rocket className="w-4 h-4 text-orange-400 group-hover:text-orange-300" />
                            <span className="font-bold text-white group-hover:text-orange-300 font-sans text-xs sm:text-sm">
                              {rel.releaseName}
                            </span>
                            <span className="text-xs text-orange-400 font-bold">
                              ({rel.version || 'v1.0.0'})
                            </span>
                          </div>

                          {/* Explicit Date Interval Badge */}
                          <div className="flex items-center gap-3 text-xs text-slate-300">
                            {rel.releaseManager && (
                              <span className="text-slate-400 flex items-center gap-1 hidden sm:inline-flex">
                                <User className="w-3.5 h-3.5 text-slate-500" />
                                {rel.releaseManager}
                              </span>
                            )}
                            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-orange-400 font-bold">
                              <CalendarIcon className="w-3.5 h-3.5" />
                              <span>
                                {formatDateShort(rStart)} &rarr; {formatDateShort(rEnd)}
                              </span>
                              <span className="text-slate-400 font-normal text-[10px]">
                                ({calculateDays(rStart, rEnd)})
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Synchronized Year Timeline Track */}
                        <div className="relative h-11 w-full bg-[#101725] rounded-lg overflow-hidden border border-slate-800/90 flex items-center p-1">
                          {/* 12 Vertical Month Grid Guidelines + 4 Quarters Divider */}
                          <div className="absolute inset-0 grid grid-cols-4 pointer-events-none divide-x divide-slate-700/50">
                            {[0, 1, 2, 3].map((qIdx) => (
                              <div
                                key={qIdx}
                                className="grid grid-cols-3 h-full divide-x divide-slate-800/40"
                              />
                            ))}
                          </div>

                          {/* Outer Release Span Shading */}
                          <div
                            className="absolute h-9 rounded-md bg-slate-800/40 border border-dashed border-slate-600/60 pointer-events-none z-0"
                            style={{
                              left: `${relOffsetPercent}%`,
                              width: `${relWidthPercent}%`,
                            }}
                          />

                          {/* Individual Test Phase Blocks */}
                          {(rel.phases || []).map((ph, pIdx) => {
                            const pStart = safeParseDate(ph.startDate);
                            const pEnd = safeParseDate(ph.endDate);
                            const pStartMs = pStart ? pStart.getTime() : rStartMs;
                            const pEndMs = pEnd ? pEnd.getTime() : rEndMs;

                            const pOffset = Math.max(
                              0,
                              Math.min(
                                100,
                                ((pStartMs - yearStartMs) / totalYearDurationMs) * 100
                              )
                            );
                            const pWidth = Math.max(
                              1.8,
                              Math.min(
                                100 - pOffset,
                                ((pEndMs - pStartMs) / totalYearDurationMs) * 100
                              )
                            );

                            const colorHex =
                              ph.color || getPhaseColor(ph.phaseName, '#3B82F6');

                            return (
                              <div
                                key={ph.phaseId || pIdx}
                                onClick={() => onSelectPhase(ph, rel)}
                                className="absolute h-8 rounded-md transition-all hover:scale-y-105 flex items-center justify-between px-2 text-[10px] font-bold text-white truncate shadow-md cursor-pointer z-10 hover:ring-2 hover:ring-white/80"
                                style={{
                                  left: `${pOffset}%`,
                                  width: `${pWidth}%`,
                                  backgroundColor: colorHex,
                                }}
                                title={`${ph.phaseName}: ${formatDateShort(pStart)} -> ${formatDateShort(pEnd)} (${calculateDays(pStart, pEnd)}) [${ph.status}]`}
                              >
                                <span className="font-bold drop-shadow truncate">
                                  {ph.phaseName}
                                </span>
                                <span className="text-[9px] opacity-90 truncate ml-1 font-mono hidden md:inline">
                                  {formatDateShort(pStart)}–{formatDateShort(pEnd)}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
