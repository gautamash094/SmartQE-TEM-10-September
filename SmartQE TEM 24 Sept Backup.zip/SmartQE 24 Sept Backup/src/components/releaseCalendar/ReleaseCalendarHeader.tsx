import React from 'react';
import {
  CalendarViewMode,
  CalendarDisplayScope,
  CalendarTimePeriod,
  ReleaseCalendarSummary,
} from '../../types/releaseCalendar';
import {
  Calendar as CalendarIcon,
  BarChart3,
  Layers,
  Cpu,
  ChevronLeft,
  ChevronRight,
  Clock,
  AlertTriangle,
  Rocket,
  CheckCircle2,
} from 'lucide-react';

interface ReleaseCalendarHeaderProps {
  viewMode: CalendarViewMode;
  onViewModeChange: (mode: CalendarViewMode) => void;
  displayScope: CalendarDisplayScope;
  onDisplayScopeChange: (scope: CalendarDisplayScope) => void;
  timePeriod: CalendarTimePeriod;
  onTimePeriodChange: (period: CalendarTimePeriod) => void;
  year: number;
  onYearChange: (year: number) => void;
  availableYears: number[];
  month: number;
  quarter: number;
  onNavigatePrev: () => void;
  onNavigateNext: () => void;
  onNavigateToday: () => void;
  summary?: ReleaseCalendarSummary;
  formattedRangeLabel: string;
}

export const ReleaseCalendarHeader: React.FC<ReleaseCalendarHeaderProps> = ({
  viewMode,
  onViewModeChange,
  displayScope,
  onDisplayScopeChange,
  timePeriod,
  onTimePeriodChange,
  year,
  onYearChange,
  availableYears,
  onNavigatePrev,
  onNavigateNext,
  onNavigateToday,
  summary,
  formattedRangeLabel,
}) => {
  return (
    <div className="space-y-4">
      {/* 1. Header Title & Top Summary */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            <span>ENTERPRISE CHANGE PIPELINE</span>
            <span>&bull;</span>
            <span className="text-orange-400">RELEASE TIMELINE & GANTT</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Rocket className="w-7 h-7 text-orange-500" />
            Release Calendar
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Release planning, phase scheduling and environment allocation timeline.
          </p>
        </div>

        {/* Summary Metric Badges */}
        {summary && (
          <div className="flex flex-wrap items-center gap-2.5 font-mono text-xs shrink-0">
            <div className="px-3 py-1.5 rounded-lg bg-[#0f1724] border border-slate-800 flex items-center gap-2">
              <Rocket className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-slate-400">Releases:</span>
              <span className="font-bold text-white">{summary.totalReleases}</span>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-[#0f1724] border border-slate-800 flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-400">Active:</span>
              <span className="font-bold text-emerald-400">{summary.activeReleases}</span>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-[#0f1724] border border-slate-800 flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-purple-400" />
              <span className="text-slate-400">Phases:</span>
              <span className="font-bold text-purple-300">{summary.totalPhases}</span>
            </div>
            {summary.conflictsCount > 0 && (
              <div className="px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center gap-2 animate-pulse">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                <span className="text-red-300 font-bold">Conflicts:</span>
                <span className="font-bold text-red-400">{summary.conflictsCount}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 2. Controls Toolbar */}
      <div className="bg-[#0f1724] border border-slate-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 shadow-md">
        {/* Left Side: View Mode & Display Scope Selectors */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Primary View Switcher: [ Calendar View ] [ Gantt View ] */}
          <div className="bg-[#161f2e] border border-slate-700/80 p-1 rounded-lg flex items-center gap-1 font-mono text-xs">
            <button
              type="button"
              onClick={() => onViewModeChange('calendar')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
                viewMode === 'calendar'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <CalendarIcon className="w-3.5 h-3.5" />
              Calendar View
            </button>
            <button
              type="button"
              onClick={() => onViewModeChange('gantt')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
                viewMode === 'gantt'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              Gantt View
            </button>
          </div>

          {/* Display Scope Switcher: View By [ Application ] [ Environment ] */}
          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-slate-400 font-bold uppercase tracking-wider text-[11px] hidden sm:inline">
              View By:
            </span>
            <div className="bg-[#161f2e] border border-slate-700/80 p-1 rounded-lg flex items-center gap-1">
              <button
                type="button"
                onClick={() => onDisplayScopeChange('application')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
                  displayScope === 'application'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                Application
              </button>
              <button
                type="button"
                onClick={() => onDisplayScopeChange('environment')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
                  displayScope === 'environment'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                Environment
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Year, Period & Date Navigation */}
        <div className="flex flex-wrap items-center gap-2.5 font-mono text-xs">
          {/* Year Dropdown */}
          <div className="flex items-center gap-1.5">
            <select
              value={year}
              onChange={(e) => onYearChange(Number(e.target.value))}
              className="bg-[#161f2e] border border-slate-700/80 text-white text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-orange-500 font-mono font-bold cursor-pointer"
            >
              {availableYears.map((yr) => (
                <option key={yr} value={yr}>
                  {yr}
                </option>
              ))}
            </select>
          </div>

          {/* Time Period Switcher: [ Month ] [ Quarter ] [ Year ] */}
          <div className="bg-[#161f2e] border border-slate-700/80 p-1 rounded-lg flex items-center gap-0.5">
            <button
              type="button"
              onClick={() => onTimePeriodChange('month')}
              className={`px-2.5 py-1 rounded font-bold transition-all cursor-pointer ${
                timePeriod === 'month'
                  ? 'bg-orange-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Month
            </button>
            <button
              type="button"
              onClick={() => onTimePeriodChange('quarter')}
              className={`px-2.5 py-1 rounded font-bold transition-all cursor-pointer ${
                timePeriod === 'quarter'
                  ? 'bg-orange-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Quarter
            </button>
            <button
              type="button"
              onClick={() => onTimePeriodChange('year')}
              className={`px-2.5 py-1 rounded font-bold transition-all cursor-pointer ${
                timePeriod === 'year'
                  ? 'bg-orange-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Year
            </button>
          </div>

          {/* Navigation [ < ] [ Range Label ] [ > ] [ Today ] */}
          <div className="flex items-center gap-1 bg-[#161f2e] border border-slate-700/80 p-1 rounded-lg">
            <button
              type="button"
              onClick={onNavigatePrev}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Previous period"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-bold text-white text-xs select-none min-w-[100px] text-center">
              {formattedRangeLabel}
            </span>
            <button
              type="button"
              onClick={onNavigateNext}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Next period"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            type="button"
            onClick={onNavigateToday}
            className="px-3 py-1.5 rounded-lg bg-[#161f2e] border border-slate-700/80 text-orange-400 hover:text-orange-300 hover:bg-slate-800 font-bold transition-colors cursor-pointer text-xs"
          >
            Today
          </button>
        </div>
      </div>
    </div>
  );
};
