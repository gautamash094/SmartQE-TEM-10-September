import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTEM } from '../context/TEMContext';
import {
  CalendarViewMode,
  CalendarDisplayScope,
  CalendarTimePeriod,
  ReleaseCalendarData,
  ReleaseCalendarFilterState,
  ReleaseCalendarRelease,
  ReleaseCalendarPhase,
  ReleaseCalendarConflict,
} from '../types/releaseCalendar';
import { releaseCalendarService } from '../services/releaseCalendarService';
import { ReleaseCalendarHeader } from '../components/releaseCalendar/ReleaseCalendarHeader';
import { ReleaseCalendarFilters } from '../components/releaseCalendar/ReleaseCalendarFilters';
import { ReleaseConflictBanner } from '../components/releaseCalendar/ReleaseConflictBanner';
import { ReleasePhaseLegend } from '../components/releaseCalendar/ReleasePhaseLegend';
import { ReleaseMonthlyCalendar } from '../components/releaseCalendar/ReleaseMonthlyCalendar';
import { ReleaseQuarterlyCalendar } from '../components/releaseCalendar/ReleaseQuarterlyCalendar';
import { ReleaseYearlyCalendar } from '../components/releaseCalendar/ReleaseYearlyCalendar';
import { ReleaseGanttView } from '../components/releaseCalendar/ReleaseGanttView';
import { ReleaseDetailDrawer } from '../components/releaseCalendar/ReleaseDetailDrawer';
import { PhaseDetailDrawer } from '../components/releaseCalendar/PhaseDetailDrawer';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { CardSkeleton } from '../components/common/Skeleton';
import { AlertTriangle, Rocket, Calendar as CalendarIcon } from 'lucide-react';

export const ReleaseCalendarPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    releases,
    testPhases,
    businessUnits,
    applications,
    environments,
    getTestPhaseColor,
    isLoading: isContextLoading,
  } = useTEM();

  // Primary State
  const [viewMode, setViewMode] = useState<CalendarViewMode>('calendar');
  const [displayScope, setDisplayScope] = useState<CalendarDisplayScope>('application');
  const [timePeriod, setTimePeriod] = useState<CalendarTimePeriod>('month');

  // Date Navigation State
  const [currentDate, setCurrentDate] = useState<Date>(() => new Date());
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth() + 1; // 1-12
  const quarter = Math.floor(currentDate.getMonth() / 3) + 1; // 1-4

  // Available Years
  const availableYears = useMemo(() => {
    const yearsSet = new Set<number>();
    yearsSet.add(new Date().getFullYear());
    yearsSet.add(new Date().getFullYear() + 1);
    yearsSet.add(new Date().getFullYear() - 1);
    releases.forEach((r) => {
      if (r.startDate) yearsSet.add(new Date(r.startDate).getFullYear());
      if (r.endDate) yearsSet.add(new Date(r.endDate).getFullYear());
      if (r.scheduledDate) yearsSet.add(new Date(r.scheduledDate).getFullYear());
    });
    return Array.from(yearsSet).sort((a, b) => a - b);
  }, [releases]);

  // Filters State
  const [filters, setFilters] = useState<ReleaseCalendarFilterState>({
    search: '',
    buId: 'ALL',
    releaseId: 'ALL',
    applicationId: 'ALL',
    environmentId: 'ALL',
    riskType: 'ALL',
    status: 'ALL',
    showConflictsOnly: false,
  });

  // Master Phase filter
  const [activePhaseFilter, setActivePhaseFilter] = useState<string>('');

  // Calendar Data & Loading State
  const [calendarData, setCalendarData] = useState<ReleaseCalendarData | null>(null);
  const [isFetchingCalendar, setIsFetchingCalendar] = useState<boolean>(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // Detail Drawers State
  const [selectedRelease, setSelectedRelease] = useState<ReleaseCalendarRelease | null>(null);
  const [selectedPhase, setSelectedPhase] = useState<ReleaseCalendarPhase | null>(null);
  const [selectedPhaseParentRelease, setSelectedPhaseParentRelease] = useState<ReleaseCalendarRelease | null>(null);

  // Fetch Calendar Data from Backend with Client Fallback
  const fetchCalendar = useCallback(async () => {
    setIsFetchingCalendar(true);
    setFetchError(null);

    try {
      const serverData = await releaseCalendarService.getCalendarTimeline({
        viewBy: displayScope,
        year,
        period: timePeriod,
        month,
        quarter,
        buId: filters.buId,
        releaseId: filters.releaseId,
        applicationId: filters.applicationId,
        environmentId: filters.environmentId,
      });

      if (serverData) {
        setCalendarData(serverData);
      } else {
        // Compute client-side fallback from context
        const clientData = releaseCalendarService.computeClientCalendarData(
          releases,
          testPhases,
          {
            viewBy: displayScope,
            year,
            period: timePeriod,
            month,
            quarter,
            buId: filters.buId,
            releaseId: filters.releaseId,
            applicationId: filters.applicationId,
            environmentId: filters.environmentId,
          }
        );
        setCalendarData(clientData);
      }
    } catch (err: any) {
      console.error('Failed to load release calendar data:', err);
      // Client-side calculation fallback
      const clientData = releaseCalendarService.computeClientCalendarData(
        releases,
        testPhases,
        {
          viewBy: displayScope,
          year,
          period: timePeriod,
          month,
          quarter,
          buId: filters.buId,
          releaseId: filters.releaseId,
          applicationId: filters.applicationId,
          environmentId: filters.environmentId,
        }
      );
      setCalendarData(clientData);
    } finally {
      setIsFetchingCalendar(false);
    }
  }, [displayScope, year, timePeriod, month, quarter, filters, releases, testPhases]);

  useEffect(() => {
    fetchCalendar();
  }, [fetchCalendar]);

  // Date Navigation Handlers
  const handleNavigatePrev = () => {
    setCurrentDate((prev) => {
      const d = new Date(prev);
      if (timePeriod === 'month') {
        d.setMonth(d.getMonth() - 1);
      } else if (timePeriod === 'quarter') {
        d.setMonth(d.getMonth() - 3);
      } else {
        d.setFullYear(d.getFullYear() - 1);
      }
      return d;
    });
  };

  const handleNavigateNext = () => {
    setCurrentDate((prev) => {
      const d = new Date(prev);
      if (timePeriod === 'month') {
        d.setMonth(d.getMonth() + 1);
      } else if (timePeriod === 'quarter') {
        d.setMonth(d.getMonth() + 3);
      } else {
        d.setFullYear(d.getFullYear() + 1);
      }
      return d;
    });
  };

  const handleNavigateToday = () => {
    setCurrentDate(new Date());
  };

  const handleYearChange = (newYear: number) => {
    setCurrentDate((prev) => {
      const d = new Date(prev);
      d.setFullYear(newYear);
      return d;
    });
  };

  const formattedRangeLabel = useMemo(() => {
    if (timePeriod === 'month') {
      return currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    } else if (timePeriod === 'quarter') {
      return `Q${quarter} ${year}`;
    } else {
      return `Year ${year}`;
    }
  }, [timePeriod, currentDate, quarter, year]);

  // Filter handlers
  const handleFilterChange = (updates: Partial<ReleaseCalendarFilterState>) => {
    setFilters((prev) => ({ ...prev, ...updates }));
  };

  const handleResetFilters = () => {
    setFilters({
      search: '',
      buId: 'ALL',
      releaseId: 'ALL',
      applicationId: 'ALL',
      environmentId: 'ALL',
      riskType: 'ALL',
      status: 'ALL',
      showConflictsOnly: false,
    });
    setActivePhaseFilter('');
  };

  // Filtered Calendar Groups based on Search, Risk, Status, Conflicts Only, and Phase Filter
  const filteredGroups = useMemo(() => {
    if (!calendarData?.items) return [];

    let groups = calendarData.items;

    if (filters.search.trim()) {
      const term = filters.search.toLowerCase().trim();
      groups = groups
        .map((g) => {
          const groupMatches = g.groupName.toLowerCase().includes(term);
          const filteredRels = g.releases.filter((r) => {
            const relMatches =
              r.releaseName.toLowerCase().includes(term) ||
              (r.businessUnit && r.businessUnit.toLowerCase().includes(term)) ||
              (r.projectName && r.projectName.toLowerCase().includes(term)) ||
              (r.applicationName && r.applicationName.toLowerCase().includes(term)) ||
              (r.releaseManager && r.releaseManager.toLowerCase().includes(term)) ||
              (r.environmentName && r.environmentName.toLowerCase().includes(term)) ||
              (r.phases || []).some((p) => p.phaseName.toLowerCase().includes(term) || (p.environmentName && p.environmentName.toLowerCase().includes(term)));
            return groupMatches || relMatches;
          });
          return { ...g, releases: filteredRels };
        })
        .filter((g) => g.releases.length > 0);
    }

    if (filters.riskType && filters.riskType !== 'ALL') {
      groups = groups
        .map((g) => ({
          ...g,
          releases: g.releases.filter(
            (r) => r.riskType === filters.riskType || r.risk === filters.riskType
          ),
        }))
        .filter((g) => g.releases.length > 0);
    }

    if (filters.status && filters.status !== 'ALL') {
      groups = groups
        .map((g) => ({
          ...g,
          releases: g.releases.filter((r) => r.status === filters.status),
        }))
        .filter((g) => g.releases.length > 0);
    }

    if (activePhaseFilter) {
      const phaseTarget = activePhaseFilter.toLowerCase();
      groups = groups
        .map((g) => ({
          ...g,
          releases: g.releases.filter((r) =>
            (r.phases || []).some((p) => p.phaseName.toLowerCase() === phaseTarget)
          ),
        }))
        .filter((g) => g.releases.length > 0);
    }

    if (filters.showConflictsOnly) {
      const conflictReleaseIds = new Set<string>();
      (calendarData.conflicts || []).forEach((c) => {
        conflictReleaseIds.add(c.releaseA.releaseId);
        conflictReleaseIds.add(c.releaseB.releaseId);
      });
      groups = groups
        .map((g) => ({
          ...g,
          releases: g.releases.filter((r) => conflictReleaseIds.has(r.releaseId)),
        }))
        .filter((g) => g.releases.length > 0);
    }

    return groups;
  }, [calendarData, filters, activePhaseFilter]);

  const conflicts = calendarData?.conflicts || [];

  const handleOpenReleaseDetails = (rel: ReleaseCalendarRelease) => {
    setSelectedRelease(rel);
  };

  const handleOpenPhaseDetails = (phase: ReleaseCalendarPhase, rel?: ReleaseCalendarRelease | null) => {
    setSelectedPhase(phase);
    setSelectedPhaseParentRelease(rel || selectedRelease || null);
  };

  const isLoading = isContextLoading || isFetchingCalendar;

  return (
    <div className="space-y-6 pb-14 font-mono text-xs animate-in fade-in duration-150">
      {/* 1. Header Toolbar */}
      <ReleaseCalendarHeader
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        displayScope={displayScope}
        onDisplayScopeChange={setDisplayScope}
        timePeriod={timePeriod}
        onTimePeriodChange={setTimePeriod}
        year={year}
        onYearChange={handleYearChange}
        availableYears={availableYears}
        month={month}
        quarter={quarter}
        onNavigatePrev={handleNavigatePrev}
        onNavigateNext={handleNavigateNext}
        onNavigateToday={handleNavigateToday}
        summary={calendarData?.summary}
        formattedRangeLabel={formattedRangeLabel}
      />

      {/* 2. Cascading Filters */}
      <ReleaseCalendarFilters
        displayScope={displayScope}
        filters={filters}
        onFilterChange={handleFilterChange}
        onResetFilters={handleResetFilters}
        onApplyFilters={fetchCalendar}
        releases={releases}
        businessUnits={businessUnits}
        applications={applications}
        environments={environments}
        conflictsCount={conflicts.length}
      />

      {/* 3. Conflict / Overlap Alert Banner */}
      <ReleaseConflictBanner
        conflicts={conflicts}
        onSelectConflict={(c) => {
          const matchedRel = releases.find((r) => r.id === c.releaseA.releaseId);
          if (matchedRel) {
            handleOpenReleaseDetails({
              releaseId: matchedRel.id,
              releaseName: matchedRel.name,
              version: matchedRel.version || 'v1.0.0',
              riskType: matchedRel.riskType || 'Major',
              risk: matchedRel.risk || 'LOW RISK',
              status: matchedRel.status || 'SCHEDULED',
              businessUnit: matchedRel.businessUnit,
              projectName: matchedRel.project,
              applicationName: matchedRel.application,
              environmentName: matchedRel.environmentName,
              startDate: matchedRel.startDate,
              endDate: matchedRel.endDate,
              phases: (matchedRel.phases || []).map((p) => ({
                phaseId: p.id,
                phaseName: p.phaseName,
                startDate: p.startDate,
                endDate: p.endDate,
                sequence: p.sequence || 1,
                status: p.status || 'NOT_STARTED',
              })),
            });
          }
        }}
      />

      {/* 4. Test Phase Master Color Legend */}
      <ReleasePhaseLegend
        testPhases={testPhases}
        activePhaseFilter={activePhaseFilter}
        onSelectPhaseFilter={setActivePhaseFilter}
      />

      {/* 5. Main Visualization Canvas */}
      {isLoading ? (
        <div className="space-y-4">
          <div className="bg-[#0f1724] border border-slate-800 rounded-xl p-8 flex items-center justify-center shadow-xl">
            <LoadingSpinner size="md" variant="primary" />
          </div>
          <CardSkeleton count={2} className="min-h-[300px]" />
        </div>
      ) : fetchError ? (
        <div className="bg-[#0f1724] border border-red-500/30 rounded-xl p-8 text-center space-y-3 font-sans">
          <AlertTriangle className="w-8 h-8 text-red-400 mx-auto" />
          <h3 className="text-base font-bold text-white">Unable to load release calendar</h3>
          <p className="text-xs text-slate-400">{fetchError}</p>
          <button
            onClick={fetchCalendar}
            className="px-4 py-2 rounded-lg bg-orange-600 text-white font-mono text-xs font-bold hover:bg-orange-500 transition-colors"
          >
            Retry Connection
          </button>
        </div>
      ) : filteredGroups.length === 0 ? (
        <div className="bg-[#0f1724] border border-slate-800 rounded-xl p-12 text-center space-y-3 font-sans shadow-md">
          <div className="w-12 h-12 rounded-xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center mx-auto text-slate-400">
            <CalendarIcon className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-white">No releases found for the selected filters</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            No active releases match the selected Business Unit, Release, Application, and Environment for {formattedRangeLabel}.
          </p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs transition-colors border border-slate-700"
          >
            Reset Filters
          </button>
        </div>
      ) : viewMode === 'calendar' ? (
        /* Calendar Visualization Mode */
        timePeriod === 'month' ? (
          <ReleaseMonthlyCalendar
            currentDate={currentDate}
            groups={filteredGroups}
            conflicts={conflicts}
            onSelectRelease={handleOpenReleaseDetails}
            onSelectPhase={handleOpenPhaseDetails}
            getPhaseColor={getTestPhaseColor}
          />
        ) : timePeriod === 'quarter' ? (
          <ReleaseQuarterlyCalendar
            year={year}
            quarter={quarter}
            groups={filteredGroups}
            conflicts={conflicts}
            onSelectRelease={handleOpenReleaseDetails}
            onSelectPhase={handleOpenPhaseDetails}
            getPhaseColor={getTestPhaseColor}
          />
        ) : (
          <ReleaseYearlyCalendar
            year={year}
            groups={filteredGroups}
            conflicts={conflicts}
            onSelectRelease={handleOpenReleaseDetails}
            onSelectPhase={handleOpenPhaseDetails}
            getPhaseColor={getTestPhaseColor}
          />
        )
      ) : (
        /* Gantt Visualization Mode */
        <ReleaseGanttView
          displayScope={displayScope}
          timePeriod={timePeriod}
          year={year}
          month={month}
          quarter={quarter}
          groups={filteredGroups}
          conflicts={conflicts}
          onSelectRelease={handleOpenReleaseDetails}
          onSelectPhase={handleOpenPhaseDetails}
          getPhaseColor={getTestPhaseColor}
        />
      )}

      {/* 6. Release Details Side Drawer */}
      <ReleaseDetailDrawer
        release={selectedRelease}
        isOpen={Boolean(selectedRelease)}
        onClose={() => setSelectedRelease(null)}
        onViewRelease={(id) => navigate('/releases')}
        onSelectPhase={(phase) => handleOpenPhaseDetails(phase, selectedRelease)}
        getPhaseColor={getTestPhaseColor}
      />

      {/* 7. Phase Details Side Drawer */}
      <PhaseDetailDrawer
        phase={selectedPhase}
        release={selectedPhaseParentRelease}
        isOpen={Boolean(selectedPhase)}
        onClose={() => setSelectedPhase(null)}
        getPhaseColor={getTestPhaseColor}
      />
    </div>
  );
};
