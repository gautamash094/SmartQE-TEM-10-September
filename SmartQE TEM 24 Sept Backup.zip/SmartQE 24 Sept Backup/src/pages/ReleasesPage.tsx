import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTEM } from '../context/TEMContext';
import { RiskBadge } from '../components/common/RiskBadge';
import { ReleaseModal } from '../components/features/ReleaseModal';
import { ReleaseDetailsModal } from '../components/features/ReleaseDetailsModal';
import { CardSkeleton } from '../components/common/Skeleton';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import {
  Plus,
  Rocket,
  LayoutGrid,
  List,
  Calendar,
  Layers,
  Search,
  Filter,
  Eye,
  Edit3,
  Trash2,
  Building,
  Briefcase,
  Cpu,
  User,
  ExternalLink,
} from 'lucide-react';
import { Release, ReleaseStatus } from '../types';

export const ReleasesPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    releases,
    businessUnits,
    projects,
    testPhases,
    getTestPhaseColor,
    deleteRelease,
    isLoading,
  } = useTEM();

  // View state: 'kanban' | 'list' | 'timeline'
  const [viewMode, setViewMode] = useState<'kanban' | 'list' | 'timeline'>('kanban');

  // Modal States
  const [isReleaseModalOpen, setIsReleaseModalOpen] = useState<boolean>(false);
  const [releaseModalTab, setReleaseModalTab] = useState<'details' | 'phases'>('details');
  const [editingRelease, setEditingRelease] = useState<Release | null>(null);
  const [selectedDetailsRelease, setSelectedDetailsRelease] = useState<Release | null>(null);

  // Filters State
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedBU, setSelectedBU] = useState<string>('');
  const [selectedProject, setSelectedProject] = useState<string>('');
  const [selectedRisk, setSelectedRisk] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');

  // Filtered releases
  const filteredReleases = useMemo(() => {
    return releases.filter((r) => {
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase().trim();
        const matchesName = r.name?.toLowerCase().includes(term);
        const matchesBu = r.businessUnit?.toLowerCase().includes(term);
        const matchesProj = r.project?.toLowerCase().includes(term);
        const matchesApp = r.application?.toLowerCase().includes(term);
        const matchesMgr = (r.releaseManager || r.lead)?.toLowerCase().includes(term);
        if (!matchesName && !matchesBu && !matchesProj && !matchesApp && !matchesMgr) {
          return false;
        }
      }

      if (selectedBU && r.businessUnit !== selectedBU && r.buId !== selectedBU) {
        return false;
      }

      if (selectedProject && r.project !== selectedProject && r.projectId !== selectedProject) {
        return false;
      }

      if (selectedRisk && r.riskType !== selectedRisk && r.risk !== selectedRisk) {
        return false;
      }

      if (selectedStatus && r.status !== selectedStatus) {
        return false;
      }

      return true;
    });
  }, [releases, searchTerm, selectedBU, selectedProject, selectedRisk, selectedStatus]);

  // Keep details modal synchronized if underlying release updates
  const activeDetailRelease = useMemo(() => {
    if (!selectedDetailsRelease) return null;
    return releases.find((r) => r.id === selectedDetailsRelease.id) || selectedDetailsRelease;
  }, [releases, selectedDetailsRelease]);

  const columns: { status: ReleaseStatus; label: string }[] = [
    { status: 'SCHEDULED', label: 'SCHEDULED' },
    { status: 'IN_PROGRESS', label: 'IN PROGRESS' },
    { status: 'DEPLOYED', label: 'DEPLOYED' },
  ];

  const handleOpenAdd = () => {
    setEditingRelease(null);
    setReleaseModalTab('details');
    setIsReleaseModalOpen(true);
  };

  const handleOpenEdit = (rel: Release, initialTab: 'details' | 'phases' = 'details') => {
    setEditingRelease(rel);
    setReleaseModalTab(initialTab);
    setIsReleaseModalOpen(true);
  };

  const handleOpenDetails = (rel: Release) => {
    setSelectedDetailsRelease(rel);
  };

  const handleDelete = async (e: React.MouseEvent, rel: Release) => {
    e.stopPropagation();
    if (window.confirm(`Are you sure you want to delete Release "${rel.name}"?`)) {
      await deleteRelease(rel.id);
      if (selectedDetailsRelease?.id === rel.id) {
        setSelectedDetailsRelease(null);
      }
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
            ENTERPRISE CHANGE PIPELINE &bull; RELEASE ORCHESTRATION
          </span>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Releases</h1>
          <p className="text-sm text-slate-400 mt-1">
            Orchestrate multi-phase deployments, test phase timelines, environment allocations, and risk management.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {/* View Switcher Tabs */}
          <div className="bg-[#0f1724] border border-slate-800 p-1 rounded-lg flex items-center gap-1 font-mono text-xs">
            <button
              onClick={() => setViewMode('kanban')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-bold transition-all ${
                viewMode === 'kanban'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
              title="Kanban Board View"
            >
              <LayoutGrid className="w-3.5 h-3.5" /> KANBAN
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-bold transition-all ${
                viewMode === 'list'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
              title="List Table View"
            >
              <List className="w-3.5 h-3.5" /> LIST
            </button>
            <button
              onClick={() => setViewMode('timeline')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-bold transition-all ${
                viewMode === 'timeline'
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
              title="Timeline / Gantt View"
            >
              <Calendar className="w-3.5 h-3.5" /> TIMELINE
            </button>
          </div>

          <button
            onClick={handleOpenAdd}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-colors shadow-[0_0_16px_rgba(249,115,22,0.4)] shrink-0"
          >
            <Plus className="w-4 h-4" /> NEW RELEASE
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#0f1724] border border-slate-800 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 font-mono text-xs">
        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search releases..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg pl-9 pr-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 font-sans"
          />
        </div>

        {/* BU Filter */}
        <div>
          <select
            value={selectedBU}
            onChange={(e) => {
              setSelectedBU(e.target.value);
              setSelectedProject('');
            }}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500"
          >
            <option value="">All Business Units</option>
            {businessUnits.map((bu) => (
              <option key={bu.id} value={bu.name}>
                {bu.name}
              </option>
            ))}
          </select>
        </div>

        {/* Project Filter */}
        <div>
          <select
            value={selectedProject}
            onChange={(e) => setSelectedProject(e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500"
          >
            <option value="">All Projects</option>
            {projects
              .filter((p) => !selectedBU || p.businessUnit?.toLowerCase().trim() === selectedBU.toLowerCase().trim())
              .map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
          </select>
        </div>

        {/* Risk Type Filter */}
        <div>
          <select
            value={selectedRisk}
            onChange={(e) => setSelectedRisk(e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500"
          >
            <option value="">All Risk Types</option>
            <option value="Major">Major</option>
            <option value="Minor">Minor</option>
            <option value="Patch">Patch</option>
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full bg-[#161f2e] border border-slate-700/80 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500"
          >
            <option value="">All Statuses</option>
            <option value="SCHEDULED">Scheduled</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="DEPLOYED">Deployed</option>
            <option value="COMPLETED">Completed</option>
            <option value="FAILED">Failed</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Main View Content */}
      {isLoading ? (
        <div className="space-y-4">
          <div className="bg-[#0f1724] border border-slate-800 rounded-lg p-5 flex items-center justify-center shadow-xl">
            <LoadingSpinner size="md" variant="primary" />
          </div>
          <CardSkeleton count={3} className="grid grid-cols-1 md:grid-cols-3 gap-6 min-h-[400px]" />
        </div>
      ) : viewMode === 'kanban' ? (
        /* ========================================================================= */
        /* KANBAN BOARD VIEW */
        /* ========================================================================= */
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {columns.map((col) => {
            const colReleases = filteredReleases.filter((r) => r.status === col.status);

            return (
              <div
                key={col.status}
                className="bg-[#0f1724] border border-slate-800 rounded-xl p-4 flex flex-col min-h-[500px]"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                    {col.label}
                  </h3>
                  <span className="text-xs font-mono font-bold text-slate-400 px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                    {colReleases.length}
                  </span>
                </div>

                {/* Cards List */}
                <div className="space-y-3 flex-1 overflow-y-auto pr-1">
                  {colReleases.map((rel) => {
                    const phasesCount = (rel.phases || []).length;
                    return (
                      <div
                        key={rel.id}
                        onClick={() => handleOpenDetails(rel)}
                        className="p-4 rounded-xl bg-[#141e2e] border border-slate-800 hover:border-slate-700 transition-all shadow-md space-y-3 group cursor-pointer hover:shadow-lg relative"
                      >
                        {/* Top Row: Version & Risk & Actions */}
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-xs font-mono font-bold text-orange-400">
                            <Rocket className="w-3.5 h-3.5" />
                            {rel.version || 'v1.0.0'}
                          </span>
                          <div className="flex items-center gap-2">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider ${
                                rel.riskType === 'Major' || rel.risk === 'HIGH RISK'
                                  ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                                  : rel.riskType === 'Minor' || rel.risk === 'MEDIUM RISK'
                                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                  : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              }`}
                            >
                              {rel.riskType || 'Major'}
                            </span>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenEdit(rel);
                              }}
                              className="text-slate-500 hover:text-white p-1 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                              title="Edit Release"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Title */}
                        <h4 className="text-sm font-bold text-white group-hover:text-orange-300 transition-colors line-clamp-2">
                          {rel.name}
                        </h4>

                        {/* Hierarchy Tags */}
                        <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-mono text-slate-400">
                          {rel.businessUnit && (
                            <span className="px-2 py-0.5 rounded bg-slate-900/80 border border-slate-800">
                              {rel.businessUnit}
                            </span>
                          )}
                          {rel.project && (
                            <span className="px-2 py-0.5 rounded bg-slate-900/80 border border-slate-800 text-cyan-400">
                              {rel.project}
                            </span>
                          )}
                          {rel.application && (
                            <span className="px-2 py-0.5 rounded bg-slate-900/80 border border-slate-800 text-purple-400">
                              {rel.application}
                            </span>
                          )}
                        </div>

                        {/* Phases Mini Progress Bar */}
                        {phasesCount > 0 && (
                          <div className="space-y-1 pt-1">
                            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                              <span className="flex items-center gap-1">
                                <Layers className="w-3 h-3 text-orange-500" /> {phasesCount}{' '}
                                {phasesCount === 1 ? 'Phase' : 'Phases'}
                              </span>
                              <span>
                                {(rel.phases || []).filter((p) => p.status === 'COMPLETED').length}/{phasesCount} Done
                              </span>
                            </div>
                            <div className="flex h-1.5 rounded-full overflow-hidden bg-slate-800 gap-0.5">
                              {(rel.phases || []).map((p, idx) => (
                                <div
                                  key={idx}
                                  className="h-full flex-1"
                                  style={{ backgroundColor: p.color || getTestPhaseColor(p.phaseName) }}
                                  title={`${p.phaseName} (${p.status})`}
                                />
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Lead & Change Ref & Date */}
                        <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-2 border-t border-slate-800/80">
                          <span className="truncate max-w-[150px]">
                            {rel.releaseManager || rel.lead}
                          </span>
                          <span className="shrink-0 text-slate-400">
                            {rel.startDate ? rel.startDate.substring(0, 10) : rel.scheduledDate?.substring(0, 10)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      ) : viewMode === 'list' ? (
        /* ========================================================================= */
        /* LIST / TABLE VIEW */
        /* ========================================================================= */
        <div className="bg-[#0f1724] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="bg-slate-900/60 border-b border-slate-800 text-slate-500 uppercase tracking-wider text-[11px]">
                  <th className="px-4 py-3 font-bold">Release Name</th>
                  <th className="px-4 py-3 font-bold">BU &bull; Project &bull; App</th>
                  <th className="px-4 py-3 font-bold">Risk Type</th>
                  <th className="px-4 py-3 font-bold">Release Manager</th>
                  <th className="px-4 py-3 font-bold">Timeline Range</th>
                  <th className="px-4 py-3 font-bold">Phases Progress</th>
                  <th className="px-4 py-3 font-bold">Status</th>
                  <th className="px-4 py-3 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredReleases.map((rel) => {
                  const phasesCount = (rel.phases || []).length;
                  return (
                    <tr
                      key={rel.id}
                      onClick={() => handleOpenDetails(rel)}
                      className="hover:bg-slate-800/30 transition-colors cursor-pointer"
                    >
                      {/* Name & Version */}
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-2">
                          <Rocket className="w-4 h-4 text-orange-400 shrink-0" />
                          <div>
                            <span className="text-sm font-bold text-white font-sans block hover:text-orange-300">
                              {rel.name}
                            </span>
                            <span className="text-[11px] text-slate-400">{rel.version || 'v1.0.0'}</span>
                          </div>
                        </div>
                      </td>

                      {/* Hierarchy */}
                      <td className="px-4 py-3.5 text-slate-300">
                        <div className="space-y-0.5">
                          <div className="text-white font-bold">{rel.businessUnit || '-'}</div>
                          <div className="text-[11px] text-cyan-400">
                            {rel.project || '-'} &bull; <span className="text-purple-400">{rel.application || '-'}</span>
                          </div>
                        </div>
                      </td>

                      {/* Risk */}
                      <td className="px-4 py-3.5">
                        <span
                          className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                            rel.riskType === 'Major' || rel.risk === 'HIGH RISK'
                              ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                              : rel.riskType === 'Minor' || rel.risk === 'MEDIUM RISK'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                              : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          {rel.riskType || rel.risk || 'Major'}
                        </span>
                      </td>

                      {/* Manager */}
                      <td className="px-4 py-3.5 text-slate-300">
                        <div className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-500" />
                          <span>{rel.releaseManager || rel.lead}</span>
                        </div>
                      </td>

                      {/* Dates */}
                      <td className="px-4 py-3.5 text-slate-400">
                        <div>{rel.startDate?.substring(0, 10) || rel.scheduledDate?.substring(0, 10)}</div>
                        <div className="text-[10px] text-slate-500">&rarr; {rel.endDate?.substring(0, 10) || '-'}</div>
                      </td>

                      {/* Phases Bar */}
                      <td className="px-4 py-3.5 w-40">
                        {phasesCount > 0 ? (
                          <div className="space-y-1">
                            <div className="flex justify-between text-[10px] text-slate-400">
                              <span>{phasesCount} Phases</span>
                              <span>
                                {(rel.phases || []).filter((p) => p.status === 'COMPLETED').length}/{phasesCount}
                              </span>
                            </div>
                            <div className="flex h-2 rounded-full overflow-hidden bg-slate-800 gap-0.5">
                              {(rel.phases || []).map((p, idx) => (
                                <div
                                  key={idx}
                                  className="h-full flex-1"
                                  style={{ backgroundColor: p.color || getTestPhaseColor(p.phaseName) }}
                                  title={`${p.phaseName} (${p.status})`}
                                />
                              ))}
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-500 text-[11px]">No phases</span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3.5">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            rel.status === 'DEPLOYED' || rel.status === 'COMPLETED'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : rel.status === 'IN_PROGRESS'
                              ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                              : 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
                          }`}
                        >
                          {rel.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => handleOpenDetails(rel)}
                            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                            title="View Release Details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleOpenEdit(rel)}
                            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                            title="Edit Release"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={(e) => handleDelete(e, rel)}
                            className="p-1.5 rounded text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
                            title="Delete Release"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* ========================================================================= */
        /* CROSS-RELEASE TIMELINE / GANTT VIEW */
        /* ========================================================================= */
        <div className="bg-[#0f1724] border border-slate-800 rounded-xl p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white font-sans">Enterprise Release Gantt Timeline</h3>
              <p className="text-xs text-slate-400">
                Visual progression of active releases and test phases rendered in their configured colors.
              </p>
            </div>

            {/* Test Phase Color Legend */}
            <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono">
              <span className="text-slate-500 uppercase tracking-widest font-bold">Phases:</span>
              {testPhases
                .filter((tp) => tp.isActive)
                .map((tp) => (
                  <div key={tp.id} className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: tp.color }} />
                    <span className="text-slate-300">{tp.name}</span>
                  </div>
                ))}
            </div>
          </div>

          <div className="space-y-6">
            {filteredReleases.map((rel) => {
              const rStartMs = rel.startDate ? new Date(rel.startDate).getTime() : Date.now();
              const rEndMs = rel.endDate ? new Date(rel.endDate).getTime() : rStartMs + 14 * 24 * 3600 * 1000;
              const rDurationMs = Math.max(1, rEndMs - rStartMs);
              const phasesList = rel.phases || [];

              return (
                <div
                  key={rel.id}
                  onClick={() => handleOpenDetails(rel)}
                  className="p-4 bg-[#141e2e] border border-slate-800 rounded-xl space-y-3 hover:border-slate-700 transition-all cursor-pointer group shadow-sm"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Rocket className="w-4 h-4 text-orange-500" />
                      <h4 className="text-sm font-bold text-white group-hover:text-orange-300 transition-colors font-sans">
                        {rel.name}
                      </h4>
                      <span className="text-xs font-mono text-orange-400 font-bold">({rel.version || 'v1.0.0'})</span>
                      <span className="text-xs font-mono text-slate-400">&bull; {rel.businessUnit} &bull; {rel.project}</span>
                    </div>

                    <div className="flex items-center gap-3 text-xs font-mono text-slate-400">
                      <span>Manager: <strong className="text-slate-300">{rel.releaseManager || rel.lead}</strong></span>
                      <span>
                        {rel.startDate?.substring(0, 10)} &rarr; {rel.endDate?.substring(0, 10)}
                      </span>
                    </div>
                  </div>

                  {/* Horizontal Timeline Track */}
                  {phasesList.length > 0 ? (
                    <div className="h-7 w-full bg-[#0a0f18] rounded-lg relative overflow-hidden border border-slate-800 flex items-center p-1 gap-1">
                      {phasesList.map((ph, pIdx) => {
                        const phStart = ph.startDate ? new Date(ph.startDate).getTime() : rStartMs;
                        const phEnd = ph.endDate ? new Date(ph.endDate).getTime() : rEndMs;
                        const offsetPercent = Math.max(
                          0,
                          Math.min(100, ((phStart - rStartMs) / rDurationMs) * 100)
                        );
                        const durPercent = Math.max(
                          5,
                          Math.min(100 - offsetPercent, ((phEnd - phStart) / rDurationMs) * 100)
                        );
                        const colorHex = ph.color || getTestPhaseColor(ph.phaseName);

                        return (
                          <div
                            key={ph.id || pIdx}
                            className="h-full rounded transition-all flex items-center justify-center text-[10px] font-bold text-white truncate px-1 shadow-sm"
                            style={{
                              width: `${durPercent}%`,
                              backgroundColor: colorHex,
                            }}
                            title={`${ph.phaseName}: ${ph.startDate?.substring(0, 10)} -> ${ph.endDate?.substring(0, 10)} (${ph.status})`}
                          >
                            <span className="drop-shadow truncate">{ph.phaseName}</span>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="h-6 w-full bg-[#0a0f18] rounded border border-dashed border-slate-800 flex items-center justify-center text-[11px] text-slate-500">
                      No release phases configured
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Schedule / Edit Release Modal */}
      <ReleaseModal
        isOpen={isReleaseModalOpen}
        onClose={() => {
          setIsReleaseModalOpen(false);
          setEditingRelease(null);
          setReleaseModalTab('details');
        }}
        editingRelease={editingRelease}
        initialTab={releaseModalTab}
      />

      {/* Release Details & Timeline Gantt Modal */}
      <ReleaseDetailsModal
        isOpen={Boolean(activeDetailRelease)}
        release={activeDetailRelease}
        onClose={() => setSelectedDetailsRelease(null)}
        onEditRelease={(r, tab) => {
          setSelectedDetailsRelease(null);
          handleOpenEdit(r, tab || 'details');
        }}
      />
    </div>
  );
};
