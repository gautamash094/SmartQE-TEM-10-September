import React, { useState, useEffect } from 'react';
import { useSearchParams, useLocation } from 'react-router-dom';
import { useTEM } from '../context/TEMContext';
import { Users, Shield, Sliders, Database, Bell, Save } from 'lucide-react';
import { UserManagementPage } from './UserManagementPage';
import { RoleManagementPage } from './RoleManagementPage';

export const SettingsPage: React.FC = () => {
  const { showToast } = useTEM();
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();

  // Tab state: 'users' | 'roles' | 'system'
  const [activeTab, setActiveTab] = useState<'users' | 'roles' | 'system'>(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam === 'roles' || location.pathname === '/settings/roles') return 'roles';
    if (tabParam === 'system') return 'system';
    return 'users';
  });

  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam === 'roles' || location.pathname === '/settings/roles') {
      setActiveTab('roles');
    } else if (tabParam === 'system') {
      setActiveTab('system');
    } else if (tabParam === 'users' || location.pathname === '/settings/users' || location.pathname === '/settings') {
      setActiveTab('users');
    }
  }, [searchParams, location.pathname]);

  const handleTabChange = (tab: 'users' | 'roles' | 'system') => {
    setActiveTab(tab);
    setSearchParams({ tab });
  };

  const [fastApiEndpoint, setFastApiEndpoint] = useState<string>('http://localhost:8000/api/v1');
  const [syncInterval, setSyncInterval] = useState<number>(30);
  const [enableAlerts, setEnableAlerts] = useState<boolean>(true);
  const [defaultRegion, setDefaultRegion] = useState<string>('us-west-2');

  const handleSaveSystemConfig = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('System preferences and FastAPI endpoint configuration saved successfully!', 'success');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800/80 pb-px overflow-x-auto">
        <button
          type="button"
          onClick={() => handleTabChange('users')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'users'
              ? 'border-orange-500 text-orange-600 dark:text-orange-400 bg-orange-50/50 dark:bg-orange-950/20'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:border-slate-300'
          }`}
        >
          <Users className="w-4 h-4" /> User Management
        </button>

        <button
          type="button"
          onClick={() => handleTabChange('roles')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'roles'
              ? 'border-orange-500 text-orange-600 dark:text-orange-400 bg-orange-50/50 dark:bg-orange-950/20'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:border-slate-300'
          }`}
        >
          <Shield className="w-4 h-4" /> Role Management
        </button>

        <button
          type="button"
          onClick={() => handleTabChange('system')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'system'
              ? 'border-orange-500 text-orange-600 dark:text-orange-400 bg-orange-50/50 dark:bg-orange-950/20'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:border-slate-300'
          }`}
        >
          <Sliders className="w-4 h-4" /> System & API Preferences
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'users' ? (
        <UserManagementPage />
      ) : activeTab === 'roles' ? (
        <RoleManagementPage />
      ) : (
        <div className="space-y-6 max-w-4xl">
          <div>
            <span className="text-[10px] font-mono font-semibold uppercase tracking-widest text-slate-400">
              SYSTEM PREFERENCES
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
              General System Settings
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              Configure FastAPI backend integration endpoints, synchronization frequency, and real-time incident alerting triggers.
            </p>
          </div>

          <form autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} data-lpignore="true" onSubmit={handleSaveSystemConfig} className="space-y-6">
            {/* Backend API Integration */}
            <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-6 space-y-4 shadow-sm">
              <div className="flex items-center gap-3 border-b border-slate-200 dark:border-slate-800/80 pb-3">
                <Database className="w-5 h-5 text-orange-500" />
                <h2 className="text-base font-bold text-slate-900 dark:text-white">FastAPI Backend Integration</h2>
              </div>

              <div>
                <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1.5 uppercase">
                  FASTAPI BASE URL ENDPOINT
                </label>
                <input autoComplete="off" data-lpignore="true"
                  type="text"
                  value={fastApiEndpoint}
                  onChange={(e) => setFastApiEndpoint(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
                <p className="text-[11px] font-mono text-slate-500 mt-1">
                  Default: http://localhost:8000/api/v1 (with automatic local state failover fallback).
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1.5 uppercase">
                    SYNC REFRESH INTERVAL (SECONDS)
                  </label>
                  <input autoComplete="off" data-lpignore="true"
                    type="number"
                    value={syncInterval}
                    onChange={(e) => setSyncInterval(parseInt(e.target.value, 10))}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mb-1.5 uppercase">
                    DEFAULT ENVIRONMENT REGION
                  </label>
                  <select
                    value={defaultRegion}
                    onChange={(e) => setDefaultRegion(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-[#161f2e] border border-slate-300 dark:border-slate-700/80 rounded-lg px-3.5 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="us-west-2">us-west-2 (Oregon)</option>
                    <option value="us-east-1">us-east-1 (N. Virginia)</option>
                    <option value="eu-west-2">eu-west-2 (London)</option>
                    <option value="ap-south-1">ap-south-1 (Mumbai)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Notifications & Alerting */}
            <div className="bg-white dark:bg-[#0f1724] border border-slate-200 dark:border-slate-800/80 rounded-xl p-6 space-y-4 shadow-sm">
              <div className="flex items-center gap-3 border-b border-slate-200 dark:border-slate-800/80 pb-3">
                <Bell className="w-5 h-5 text-orange-500" />
                <h2 className="text-base font-bold text-slate-900 dark:text-white">Alerts & Notifications</h2>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">Enable Real-Time SEV1/SEV2 Alerts</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Receive instant toast banners when high severity environment incidents are raised.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={enableAlerts}
                  onChange={(e) => setEnableAlerts(e.target.checked)}
                  className="w-5 h-5 accent-orange-500 rounded cursor-pointer"
                />
              </div>
            </div>

            {/* Save Button */}
            <div className="flex justify-end">
              <button
                type="submit"
                className="flex items-center gap-2 px-6 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 transition-all shadow-[0_0_16px_rgba(249,115,22,0.35)]"
              >
                <Save className="w-4 h-4" /> SAVE PREFERENCES
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
