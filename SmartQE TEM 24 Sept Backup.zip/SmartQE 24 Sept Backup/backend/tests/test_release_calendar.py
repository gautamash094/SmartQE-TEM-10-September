import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.services.release_service import release_service
from app.schemas.release import ReleaseCreate, ReleasePhaseCreate


@pytest.mark.asyncio
async def test_release_calendar_endpoint(client: AsyncClient):
    # Test default application view
    response = await client.get("/api/v1/releases/calendar?viewBy=application&year=2026&period=month&month=9")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "items" in data["data"]
    assert "conflicts" in data["data"]
    assert "summary" in data["data"]
    assert data["data"]["view_by"] == "application"
    assert data["data"]["year"] == 2026
    assert data["data"]["period"] == "month"
    assert data["data"]["month"] == 9

    # Test environment view with quarter period
    response_env = await client.get("/api/v1/releases/calendar?viewBy=environment&year=2026&period=quarter&quarter=3")
    assert response_env.status_code == 200
    data_env = response_env.json()
    assert data_env["success"] is True
    assert data_env["data"]["view_by"] == "environment"
    assert data_env["data"]["period"] == "quarter"
    assert data_env["data"]["quarter"] == 3

    # Test year view
    response_yr = await client.get("/api/v1/releases/calendar?viewBy=application&year=2026&period=year")
    assert response_yr.status_code == 200
    data_yr = response_yr.json()
    assert data_yr["success"] is True
    assert data_yr["data"]["period"] == "year"


@pytest.mark.asyncio
async def test_release_calendar_service_calculation(db_session: AsyncSession):
    cal_res = await release_service.get_calendar_timeline(
        db=db_session,
        view_by="application",
        year=2026,
        period="month",
        month=9
    )
    assert cal_res.view_by == "application"
    assert cal_res.year == 2026
    assert cal_res.month == 9
    assert isinstance(cal_res.items, list)
    assert isinstance(cal_res.conflicts, list)
    assert cal_res.summary.total_releases >= 0


@pytest.mark.asyncio
async def test_release_conflict_check_endpoint(client: AsyncClient, db_session: AsyncSession):
    # 1. Create a baseline release
    payload_base = {
        "name": "Base Payment Rel 1",
        "business_unit": "Retail Banking",
        "project_name": "Digital Core",
        "application_name": "Payment Gateway",
        "risk_type": "Major",
        "start_date": "2026-10-01T09:00:00",
        "end_date": "2026-10-10T18:00:00",
        "initial_phases": [
            {
                "phase_name": "UAT",
                "start_date": "2026-10-01T09:00:00",
                "end_date": "2026-10-05T18:00:00",
                "environment_id": "env-uat-01",
                "environment_name": "UAT-Primary"
            }
        ]
    }
    create_res = await client.post("/api/v1/releases", json=payload_base)
    assert create_res.status_code == 201

    # 2. Check conflicts for an overlapping release on same application
    check_payload = {
        "name": "Conflicting Payment Rel 2",
        "business_unit": "Retail Banking",
        "application": "Payment Gateway",
        "risk_type": "Major",
        "start_date": "2026-10-04T09:00:00",
        "end_date": "2026-10-14T18:00:00",
        "phases": [
            {
                "phase_name": "UAT",
                "start_date": "2026-10-04T09:00:00",
                "end_date": "2026-10-08T18:00:00",
                "environment_id": "env-uat-01",
                "environment_name": "UAT-Primary"
            }
        ]
    }
    check_res = await client.post("/api/v1/releases/check-conflicts", json=check_payload)
    assert check_res.status_code == 200
    data = check_res.json()["data"]
    assert data["has_conflicts"] is True
    assert data["conflict_count"] >= 1
    assert data["risk_level"] in ("CRITICAL", "HIGH")
    assert len(data["conflicts"]) >= 1
    assert len(data["recommendations"]) >= 1
    # Verify recommended dates preserve duration
    rec = data["recommendations"][0]
    assert rec["duration_days"] == 10
    assert rec["confidence_score"] > 80
    assert len(rec["phases"]) == 1

    # 3. Check conflict-free window
    clear_payload = {
        "name": "Clear Payment Rel 3",
        "business_unit": "Retail Banking",
        "application": "Payment Gateway",
        "risk_type": "Minor",
        "start_date": "2026-11-01T09:00:00",
        "end_date": "2026-11-10T18:00:00",
        "phases": []
    }
    clear_res = await client.post("/api/v1/releases/check-conflicts", json=clear_payload)
    assert clear_res.status_code == 200
    clear_data = clear_res.json()["data"]
    assert clear_data["has_conflicts"] is False
    assert clear_data["conflict_count"] == 0
    assert clear_data["risk_level"] == "LOW"

