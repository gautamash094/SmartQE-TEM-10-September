from sqlalchemy import Column, String, Boolean, Integer
from sqlalchemy.orm import relationship
from app.database.base import Base


class TestPhase(Base):
    __test__ = False
    __tablename__ = "test_phases"

    name = Column(String, unique=True, index=True, nullable=False)
    display_name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    color = Column(String, default="#3B82F6", nullable=False)
    is_system = Column(Boolean, default=False, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    display_order = Column(Integer, default=1, nullable=False)
    created_by = Column(String, default="System", nullable=False)
    updated_by = Column(String, default="System", nullable=False)

    # Relationships
    release_phases = relationship("ReleasePhase", back_populates="test_phase", cascade="all, delete-orphan")
