﻿import enum
from sqlalchemy import Column, String, DateTime, Enum as SQLEnum, ForeignKey, Boolean, Integer
from sqlalchemy.orm import relationship
from app.database.base import Base


class ReleaseRisk(str, enum.Enum):
    LOW_RISK = "LOW RISK"
    MEDIUM_RISK = "MEDIUM RISK"
    HIGH_RISK = "HIGH RISK"


class ReleaseRiskType(str, enum.Enum):
    MAJOR = "Major"
    MINOR = "Minor"
    PATCH = "Patch"


class ReleaseStatus(str, enum.Enum):
    SCHEDULED = "SCHEDULED"
    IN_PROGRESS = "IN_PROGRESS"
    DEPLOYED = "DEPLOYED"
    FAILED = "FAILED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class Release(Base):
    __tablename__ = "releases"

    # Core required fields
    name = Column(String, nullable=False, index=True)
    
    # BU / Project / Application hierarchy
    bu_id = Column(String, ForeignKey("business_units.id", ondelete="SET NULL"), nullable=True, index=True)
    business_unit = Column(String, nullable=True, index=True)
    project_id = Column(String, ForeignKey("projects.id", ondelete="SET NULL"), nullable=True, index=True)
    project_name = Column(String, nullable=True, index=True)
    application_id = Column(String, ForeignKey("applications.id", ondelete="SET NULL"), nullable=True, index=True)
    application_name = Column(String, nullable=True, index=True)
    
    # Risk Type (Major, Minor, Patch)
    risk_type = Column(String, default="Major", nullable=False)
    
    # Release Manager
    release_manager_id = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    release_manager_name = Column(String, nullable=True)
    
    # Timeline
    start_date = Column(DateTime(timezone=True), nullable=True)
    end_date = Column(DateTime(timezone=True), nullable=True)
    
    # Details & Links
    repository_url = Column(String, nullable=True)
    remarks = Column(String, nullable=True)

    # Legacy/Compatibility fields
    version = Column(String, default="v1.0.0", nullable=False)
    environment_id = Column(String, ForeignKey("environments.id", ondelete="SET NULL"), nullable=True, index=True)
    environment_name = Column(String, default="All Environments", nullable=False)
    lead = Column(String, default="Release Lead", nullable=False)
    lead_id = Column(String, nullable=True, index=True)
    change_ref = Column(String, default="CR-REL", nullable=False)
    scheduled_date = Column(DateTime(timezone=True), nullable=True)
    risk = Column(SQLEnum(ReleaseRisk), default=ReleaseRisk.LOW_RISK, nullable=False)
    status = Column(SQLEnum(ReleaseStatus), default=ReleaseStatus.SCHEDULED, nullable=False)
    
    # Visibility and audit tracking
    is_visible = Column(Boolean, default=True, nullable=False, index=True)
    created_by = Column(String, nullable=True, index=True)
    owner_id = Column(String, nullable=True, index=True)
    modified_by = Column(String, nullable=True)

    # Relationships
    environment = relationship("Environment", back_populates="releases", lazy="selectin")
    phases = relationship("ReleasePhase", back_populates="release", cascade="all, delete-orphan", order_by="ReleasePhase.sequence", lazy="selectin")


class ReleasePhase(Base):
    __tablename__ = "release_phases"

    release_id = Column(String, ForeignKey("releases.id", ondelete="CASCADE"), nullable=False, index=True)
    test_phase_id = Column(String, ForeignKey("test_phases.id", ondelete="SET NULL"), nullable=True, index=True)
    phase_name = Column(String, nullable=False)
    color = Column(String, nullable=True)
    environment_id = Column(String, nullable=True)
    environment_name = Column(String, nullable=True)
    
    start_date = Column(DateTime(timezone=True), nullable=False)
    end_date = Column(DateTime(timezone=True), nullable=False)
    sequence = Column(Integer, default=1, nullable=False)
    status = Column(String, default="NOT_STARTED", nullable=False)
    remarks = Column(String, nullable=True)
    
    created_by = Column(String, default="System", nullable=False)
    updated_by = Column(String, default="System", nullable=False)

    # Relationships
    release = relationship("Release", back_populates="phases")
    test_phase = relationship("TestPhase", back_populates="release_phases", lazy="selectin")
