from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import get_password_hash
from app.dao.user_dao import user_dao
from app.dao.role_dao import role_dao
from app.dao.setting_dao import setting_dao
from app.dao.test_phase_dao import test_phase_dao
from app.models.role import Role


DEFAULT_SYSTEM_TEST_PHASES = [
    {
        "name": "UNIT",
        "display_name": "UNIT",
        "description": "Component and isolated module level unit testing phase.",
        "color": "#3B82F6",  # Enterprise Blue
        "is_system": True,
        "is_active": True,
        "display_order": 1,
    },
    {
        "name": "UAT",
        "display_name": "UAT",
        "description": "User Acceptance Testing phase.",
        "color": "#F59E0B",  # Enterprise Amber
        "is_system": True,
        "is_active": True,
        "display_order": 2,
    },
    {
        "name": "SIT",
        "display_name": "SIT",
        "description": "System Integration Testing phase.",
        "color": "#06B6D4",  # Enterprise Cyan
        "is_system": True,
        "is_active": True,
        "display_order": 3,
    },
    {
        "name": "QA",
        "display_name": "QA",
        "description": "Quality Assurance testing phase.",
        "color": "#10B981",  # Enterprise Emerald
        "is_system": True,
        "is_active": True,
        "display_order": 4,
    },
    {
        "name": "ST",
        "display_name": "ST",
        "description": "System Testing phase.",
        "color": "#8B5CF6",  # Enterprise Violet
        "is_system": True,
        "is_active": True,
        "display_order": 5,
    },
    {
        "name": "PRE PROD",
        "display_name": "PRE PROD",
        "description": "Pre-Production Staging phase.",
        "color": "#F97316",  # Enterprise Orange
        "is_system": True,
        "is_active": True,
        "display_order": 6,
    },
    {
        "name": "PROD",
        "display_name": "PROD",
        "description": "Live production deployment and verification phase.",
        "color": "#F43F5E",  # Enterprise Rose
        "is_system": True,
        "is_active": True,
        "display_order": 7,
    },
]


async def seed_initial_data(db: AsyncSession) -> None:
    """
    Seed initial system administrator accounts, default Super Admin role,
    initial role hierarchy, default configuration, and default Test Phases.
    """
    # 1. Seed Roles (Only Super Admin initial system role)
    super_admin_role = None
    if await role_dao.count(db) == 0:
        super_admin_role = await role_dao.create(db, {
            "name": "Super Admin",
            "description": "Default initial system role with top-level administrative authority across the TEM application.",
            "role_order": 1,
            "is_system": True,
            "is_active": True,
            "status": "ACTIVE"
        })

        # Seed initial default settings pointing to Super Admin
        await setting_dao.set_value(db, "default_role_id", super_admin_role.id, "Default role assigned to new users")
        await setting_dao.set_value(db, "default_role_name", super_admin_role.name, "Default role name")
    else:
        super_admin_role = await role_dao.get_by_name(db, "Super Admin")

    # 2. Seed Initial Administrator User
    if await user_dao.count(db) == 0 and super_admin_role:
        admin_data = {
            "first_name": "System",
            "last_name": "Admin",
            "username": "admin",
            "email": "admin@testops.io",
            "hashed_password": get_password_hash("Admin@123"),
            "is_active": True,
            "status": "ACTIVE",
            "created_by": "System",
            "updated_by": "System",
        }
        await user_dao.create_user_with_roles(db, admin_data, [super_admin_role])

    # 3. Seed Default System Test Phases (Idempotent: inserts or updates system master records)
    for phase_data in DEFAULT_SYSTEM_TEST_PHASES:
        existing = await test_phase_dao.get_by_name(db, phase_data["name"])
        if not existing:
            await test_phase_dao.create(db, {
                **phase_data,
                "created_by": "System",
                "updated_by": "System",
            })
        else:
            await test_phase_dao.update(db, existing, {
                "display_name": phase_data["display_name"],
                "color": phase_data["color"],
                "display_order": phase_data["display_order"],
                "is_active": True,
                "is_system": True,
                "updated_by": "System",
            })
