from datetime import datetime, timezone, timedelta
from typing import List, Tuple, Dict, Optional, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.exceptions import EntityNotFoundException, PermissionDeniedException, ValidationException
from app.dao.release_dao import release_dao, release_phase_dao
from app.dao.test_phase_dao import test_phase_dao
from app.dao.portfolio_dao import business_unit_dao, project_dao, application_dao
from app.dao.user_dao import user_dao
from app.dao.reservation_dao import reservation_dao
from app.models.reservation import Reservation, ReservationStatus
from app.models.release import Release, ReleasePhase
from app.schemas.release import (
    ReleaseCreate, ReleaseUpdate, ReleaseRead,
    ReleasePhaseCreate, ReleasePhaseUpdate, ReleasePhaseRead, ReleasePhaseReorder,
    ReleaseCalendarPhaseItem, ReleaseCalendarReleaseItem, ReleaseCalendarGroupItem,
    ReleaseCalendarConflict, ReleaseCalendarConflictEntity, ReleaseCalendarSummary,
    ReleaseCalendarDateRange, ReleaseCalendarResponse,
    ReleaseConflictCheckRequest, ReleaseConflictCheckResponse, ReleaseConflictItem,
    ReleaseDateRecommendation, ReleaseRecommendedPhaseItem, ReleaseConflictPhaseInput
)


def _normalize_dt(dt: Optional[datetime]) -> Optional[datetime]:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class ReleaseService:
    async def create_release(
        self, db: AsyncSession, rel_in: ReleaseCreate, current_user: Optional[any] = None
    ) -> ReleaseRead:
        # 1. Uniqueness check for release name
        existing = await release_dao.get_by_name(db, rel_in.name)
        if existing:
            raise ValidationException(f"Release with name '{rel_in.name}' already exists.")

        # 2. Date validations
        if rel_in.start_date and rel_in.end_date and _normalize_dt(rel_in.end_date) < _normalize_dt(rel_in.start_date):
            raise ValidationException("End Date cannot be earlier than Start Date.")

        data = rel_in.model_dump(exclude={"initial_phases"})

        # Synchronize scheduled_date and start_date
        if data.get("start_date") and not data.get("scheduled_date"):
            data["scheduled_date"] = data["start_date"]
        elif data.get("scheduled_date") and not data.get("start_date"):
            data["start_date"] = data["scheduled_date"]

        # Backward compatibility fallbacks
        if not data.get("environment_id"):
            data["environment_id"] = "env-all"
        if not data.get("environment_name"):
            data["environment_name"] = "All Environments"
        if not data.get("version"):
            data["version"] = "v1.0.0"
        if not data.get("lead"):
            data["lead"] = data.get("release_manager_name") or "Release Lead"
        if not data.get("change_ref"):
            data["change_ref"] = "CR-REL"

        # Audit columns
        username = getattr(current_user, "username", "System") if current_user else "System"
        user_id = str(getattr(current_user, "id", "") or "") if current_user else None
        data["created_by"] = username
        data["owner_id"] = user_id
        if not data.get("lead_id") and user_id:
            data["lead_id"] = user_id

        # Resolve BU / Project / App names if IDs are given
        if data.get("bu_id") and not data.get("business_unit"):
            bu = await business_unit_dao.get_by_id(db, data["bu_id"])
            if bu:
                data["business_unit"] = bu.name
        if data.get("project_id") and not data.get("project_name"):
            proj = await project_dao.get_by_id(db, data["project_id"])
            if proj:
                data["project_name"] = proj.name
        if data.get("application_id") and not data.get("application_name"):
            app = await application_dao.get_by_id(db, data["application_id"])
            if app:
                data["application_name"] = app.name

        # Resolve Release Manager Name if manager_id is given
        if data.get("release_manager_id") and not data.get("release_manager_name"):
            mgr = await user_dao.get_by_id(db, data["release_manager_id"])
            if mgr:
                data["release_manager_name"] = mgr.full_name or mgr.username

        rel = await release_dao.create(db, data)
        rel_id = rel.id

        # 3. Create initial phases if provided
        if rel_in.initial_phases:
            for idx, phase_in in enumerate(rel_in.initial_phases, start=1):
                phase_data = phase_in.model_dump()
                phase_data["release_id"] = rel_id
                phase_data["sequence"] = phase_data.get("sequence") or idx
                phase_data["created_by"] = username
                phase_data["updated_by"] = username
                
                # If color not provided, grab from TestPhase
                if not phase_data.get("color") and phase_data.get("test_phase_id"):
                    tp = await test_phase_dao.get_by_id(db, phase_data["test_phase_id"])
                    if tp:
                        phase_data["color"] = tp.color
                        if not phase_data.get("phase_name"):
                            phase_data["phase_name"] = tp.name

                await release_phase_dao.create(db, phase_data)

        # Explicitly fetch phases for reliable population
        phases = await release_phase_dao.get_by_release_id(db, rel_id)
        rel_read = ReleaseRead.model_validate(rel)
        rel_read.phases = [ReleasePhaseRead.model_validate(p) for p in phases]
        return rel_read

    async def get_release_by_id(
        self, db: AsyncSession, rel_id: str, current_user: Optional[any] = None
    ) -> ReleaseRead:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("You do not have permission to access this resource.")
        phases = await release_phase_dao.get_by_release_id(db, rel_id)
        rel_read = ReleaseRead.model_validate(rel)
        rel_read.phases = [ReleasePhaseRead.model_validate(p) for p in phases]
        return rel_read

    async def update_release(
        self, db: AsyncSession, rel_id: str, rel_in: ReleaseUpdate, current_user: Optional[any] = None
    ) -> ReleaseRead:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("You do not have permission to access this resource.")

        update_data = rel_in.model_dump(exclude_unset=True)

        # Uniqueness check if name is updated
        if "name" in update_data and update_data["name"] and update_data["name"] != rel.name:
            existing = await release_dao.get_by_name(db, update_data["name"])
            if existing and existing.id != rel.id:
                raise ValidationException(f"Release with name '{update_data['name']}' already exists.")

        # Date validations
        start_date = update_data.get("start_date") or rel.start_date
        end_date = update_data.get("end_date") or rel.end_date
        if start_date and end_date and _normalize_dt(end_date) < _normalize_dt(start_date):
            raise ValidationException("End Date cannot be earlier than Start Date.")

        update_data.pop("created_by", None)
        update_data.pop("owner_id", None)
        if current_user:
            update_data["modified_by"] = getattr(current_user, "username", "System")

        # Resolve Release Manager Name if manager_id is changed
        if "release_manager_id" in update_data and update_data["release_manager_id"]:
            mgr = await user_dao.get_by_id(db, update_data["release_manager_id"])
            if mgr:
                update_data["release_manager_name"] = mgr.full_name or mgr.username

        updated = await release_dao.update(db, rel, update_data)
        reloaded = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        return ReleaseRead.model_validate(reloaded or updated)

    async def delete_release(
        self, db: AsyncSession, rel_id: str, current_user: Optional[any] = None
    ) -> bool:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("You do not have permission to access this resource.")
        return await release_dao.delete(db, rel_id)

    async def get_releases_paginated(
        self,
        db: AsyncSession,
        page: int = 1,
        page_size: int = 20,
        search: Optional[str] = None,
        bu_id: Optional[str] = None,
        project_id: Optional[str] = None,
        status: Optional[str] = None,
        current_user: Optional[any] = None
    ) -> Tuple[List[ReleaseRead], int]:
        items, total = await release_dao.paginate_for_user(
            db, current_user, page=page, page_size=page_size,
            search=search, bu_id=bu_id, project_id=project_id, status=status
        )
        return [ReleaseRead.model_validate(r) for r in items], total

    async def get_kanban_board(self, db: AsyncSession, current_user: Optional[any] = None) -> Dict[str, List[ReleaseRead]]:
        kanban = await release_dao.get_kanban_data(db, current_user=current_user)
        return {
            status: [ReleaseRead.model_validate(r) for r in items]
            for status, items in kanban.items()
        }

    # --- Phase Management ---
    async def get_phases_for_release(
        self, db: AsyncSession, rel_id: str, current_user: Optional[any] = None
    ) -> List[ReleasePhaseRead]:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("You do not have permission to access this resource.")
        phases = await release_phase_dao.get_by_release_id(db, rel_id)
        return [ReleasePhaseRead.model_validate(p) for p in phases]

    async def add_phase_to_release(
        self, db: AsyncSession, rel_id: str, phase_in: ReleasePhaseCreate, current_user: Optional[any] = None
    ) -> ReleasePhaseRead:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("Release not found or inaccessible.")

        # Phase start/end validations
        if _normalize_dt(phase_in.end_date) < _normalize_dt(phase_in.start_date):
            raise ValidationException("Phase End Date cannot be earlier than Phase Start Date.")

        if rel.start_date and _normalize_dt(phase_in.start_date) < _normalize_dt(rel.start_date):
            raise ValidationException(f"Phase Start Date cannot be earlier than Release Start Date ({rel.start_date.isoformat()}).")

        if rel.end_date and _normalize_dt(phase_in.end_date) > _normalize_dt(rel.end_date):
            raise ValidationException(f"Phase End Date cannot exceed Release End Date ({rel.end_date.isoformat()}).")

        data = phase_in.model_dump()
        data["release_id"] = rel.id

        # Resolve color from TestPhase if needed
        if not data.get("color") and data.get("test_phase_id"):
            tp = await test_phase_dao.get_by_id(db, data["test_phase_id"])
            if tp:
                data["color"] = tp.color
                if not data.get("phase_name"):
                    data["phase_name"] = tp.name

        username = getattr(current_user, "username", "System") if current_user else "System"
        data["created_by"] = username
        data["updated_by"] = username

        # Sequence assignment
        if not data.get("sequence"):
            existing_phases = await release_phase_dao.get_by_release_id(db, rel_id)
            data["sequence"] = len(existing_phases) + 1

        created = await release_phase_dao.create(db, data)
        return ReleasePhaseRead.model_validate(created)

    async def update_release_phase(
        self, db: AsyncSession, rel_id: str, phase_id: str, phase_in: ReleasePhaseUpdate, current_user: Optional[any] = None
    ) -> ReleasePhaseRead:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("Release not found or inaccessible.")

        phase = await release_phase_dao.get_phase_by_id(db, phase_id)
        if not phase or phase.release_id != rel_id:
            raise EntityNotFoundException("ReleasePhase", phase_id)

        update_data = phase_in.model_dump(exclude_unset=True)

        start_date = update_data.get("start_date") or phase.start_date
        end_date = update_data.get("end_date") or phase.end_date

        if start_date and end_date and _normalize_dt(end_date) < _normalize_dt(start_date):
            raise ValidationException("Phase End Date cannot be earlier than Phase Start Date.")

        if rel.start_date and start_date and _normalize_dt(start_date) < _normalize_dt(rel.start_date):
            raise ValidationException("Phase Start Date cannot be earlier than Release Start Date.")

        if rel.end_date and end_date and _normalize_dt(end_date) > _normalize_dt(rel.end_date):
            raise ValidationException("Phase End Date cannot exceed Release End Date.")

        if "test_phase_id" in update_data and update_data["test_phase_id"] and not update_data.get("color"):
            tp = await test_phase_dao.get_by_id(db, update_data["test_phase_id"])
            if tp:
                update_data["color"] = tp.color

        username = getattr(current_user, "username", "System") if current_user else "System"
        update_data["updated_by"] = username

        updated = await release_phase_dao.update(db, phase, update_data)
        return ReleasePhaseRead.model_validate(updated)

    async def delete_release_phase(
        self, db: AsyncSession, rel_id: str, phase_id: str, current_user: Optional[any] = None
    ) -> bool:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("Release not found or inaccessible.")

        phase = await release_phase_dao.get_phase_by_id(db, phase_id)
        if not phase or phase.release_id != rel_id:
            raise EntityNotFoundException("ReleasePhase", phase_id)

        return await release_phase_dao.delete(db, phase_id)

    async def reorder_release_phases(
        self, db: AsyncSession, rel_id: str, reorder_in: ReleasePhaseReorder, current_user: Optional[any] = None
    ) -> List[ReleasePhaseRead]:
        rel = await release_dao.get_by_id_for_user(db, rel_id, current_user)
        if not rel:
            raise PermissionDeniedException("Release not found or inaccessible.")

        for item in reorder_in.phases:
            phase = await release_phase_dao.get_phase_by_id(db, item.id)
            if phase and phase.release_id == rel_id:
                await release_phase_dao.update(db, phase, {"sequence": item.sequence})

        updated_phases = await release_phase_dao.get_by_release_id(db, rel_id)
        return [ReleasePhaseRead.model_validate(p) for p in updated_phases]

    async def get_calendar_timeline(
        self,
        db: AsyncSession,
        view_by: str = "application",
        year: int = 2026,
        period: str = "month",
        month: Optional[int] = None,
        quarter: Optional[int] = None,
        bu_id: Optional[str] = None,
        release_id: Optional[str] = None,
        application_id: Optional[str] = None,
        environment_id: Optional[str] = None,
        current_user: Optional[any] = None
    ) -> ReleaseCalendarResponse:
        import calendar

        # Normalize period & date range
        period = (period or "month").lower()
        if period not in ("month", "quarter", "year"):
            period = "month"

        current_utc = datetime.now(timezone.utc)
        if year is None or year < 2000 or year > 2100:
            year = current_utc.year

        if period == "month":
            if month is None or month < 1 or month > 12:
                month = current_utc.month
            last_day = calendar.monthrange(year, month)[1]
            start_date = datetime(year, month, 1, 0, 0, 0, tzinfo=timezone.utc)
            end_date = datetime(year, month, last_day, 23, 59, 59, 999999, tzinfo=timezone.utc)
            effective_quarter = (month - 1) // 3 + 1
        elif period == "quarter":
            if quarter is None or quarter < 1 or quarter > 4:
                quarter = (current_utc.month - 1) // 3 + 1
            start_m = (quarter - 1) * 3 + 1
            end_m = start_m + 2
            last_day = calendar.monthrange(year, end_m)[1]
            start_date = datetime(year, start_m, 1, 0, 0, 0, tzinfo=timezone.utc)
            end_date = datetime(year, end_m, last_day, 23, 59, 59, 999999, tzinfo=timezone.utc)
            effective_quarter = quarter
            month = start_m
        else:  # year
            start_date = datetime(year, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
            end_date = datetime(year, 12, 31, 23, 59, 59, 999999, tzinfo=timezone.utc)
            month = 1
            effective_quarter = 1

        # Fetch releases within calendar scope
        releases = await release_dao.get_releases_for_calendar(
            db=db,
            current_user=current_user,
            start_date=start_date,
            end_date=end_date,
            bu_id=bu_id,
            release_id=release_id,
            application_id=application_id,
            environment_id=environment_id
        )

        # Build group map based on view_by
        view_by_norm = (view_by or "application").lower()
        if view_by_norm not in ("application", "environment"):
            view_by_norm = "application"

        group_map: Dict[str, Dict[str, Any]] = {}
        all_phases: List[Tuple[Release, Any]] = []
        active_releases_count = 0

        for r in releases:
            r_start = _normalize_dt(r.start_date or r.scheduled_date)
            r_end = _normalize_dt(r.end_date or r.start_date or r.scheduled_date)

            is_active = False
            if r.status in ("IN_PROGRESS", "SCHEDULED"):
                if r_start and r_end and r_start <= current_utc <= r_end:
                    is_active = True
                elif r.status == "IN_PROGRESS":
                    is_active = True
            if is_active:
                active_releases_count += 1

            # Convert phases
            phase_items: List[ReleaseCalendarPhaseItem] = []
            for p in (r.phases or []):
                p_start = _normalize_dt(p.start_date) or r_start or start_date
                p_end = _normalize_dt(p.end_date) or r_end or end_date
                phase_item = ReleaseCalendarPhaseItem(
                    phase_id=p.id,
                    phase_name=p.phase_name,
                    test_phase_id=p.test_phase_id,
                    color=p.color,
                    environment_id=p.environment_id or r.environment_id,
                    environment_name=p.environment_name or r.environment_name or "Unassigned",
                    start_date=p_start,
                    end_date=p_end,
                    sequence=p.sequence or 1,
                    status=p.status or "NOT_STARTED",
                    remarks=p.remarks
                )
                phase_items.append(phase_item)
                all_phases.append((r, phase_item))

            rel_item = ReleaseCalendarReleaseItem(
                release_id=r.id,
                release_name=r.name,
                version=r.version or "v1.0.0",
                risk_type=r.risk_type or "Major",
                risk=r.risk.value if hasattr(r.risk, "value") else str(r.risk or "LOW RISK"),
                status=r.status.value if hasattr(r.status, "value") else str(r.status or "SCHEDULED"),
                release_manager=r.release_manager_name or r.lead,
                bu_id=r.bu_id,
                business_unit=r.business_unit or "General",
                project_id=r.project_id,
                project_name=r.project_name or "Core Platform",
                application_id=r.application_id,
                application_name=r.application_name or "Core Service",
                environment_id=r.environment_id,
                environment_name=r.environment_name or "All Environments",
                start_date=r_start,
                end_date=r_end,
                repository_url=r.repository_url,
                remarks=r.remarks,
                phases=phase_items
            )

            if view_by_norm == "application":
                g_key = r.application_id or (f"app-{r.application_name.lower().replace(' ', '-')}" if r.application_name else "app-unassigned")
                g_name = r.application_name or "Unassigned Application"
                if g_key not in group_map:
                    group_map[g_key] = {
                        "group_key": g_key,
                        "group_name": g_name,
                        "group_type": "application",
                        "business_unit": r.business_unit,
                        "project_id": r.project_id,
                        "project_name": r.project_name,
                        "releases": []
                    }
                group_map[g_key]["releases"].append(rel_item)
            else:  # environment
                # Group by environment (from phases or release)
                assigned_envs = set()
                for ph in phase_items:
                    env_name = ph.environment_name or "Unassigned Environment"
                    env_key = ph.environment_id or f"env-{env_name.lower().replace(' ', '-')}"
                    assigned_envs.add((env_key, env_name))
                if not assigned_envs:
                    env_name = r.environment_name or "All Environments"
                    env_key = r.environment_id or f"env-{env_name.lower().replace(' ', '-')}"
                    assigned_envs.add((env_key, env_name))

                for env_key, env_name in assigned_envs:
                    if env_key not in group_map:
                        group_map[env_key] = {
                            "group_key": env_key,
                            "group_name": env_name,
                            "group_type": "environment",
                            "business_unit": r.business_unit,
                            "project_id": r.project_id,
                            "project_name": r.project_name,
                            "releases": []
                        }
                    # Filter release phases specific to this environment
                    env_phases = [p for p in phase_items if (p.environment_id == env_key or p.environment_name == env_name)]
                    env_rel = rel_item.model_copy()
                    if env_phases:
                        env_rel.phases = env_phases
                    group_map[env_key]["releases"].append(env_rel)

        # Convert group map to list
        group_items: List[ReleaseCalendarGroupItem] = [
            ReleaseCalendarGroupItem(**g_data) for g_data in group_map.values()
        ]

        # Calculate conflicts / overlaps
        conflicts: List[ReleaseCalendarConflict] = []
        conflict_idx = 1

        if view_by_norm == "application":
            # Detect overlapping releases for the same application
            for g in group_items:
                rel_list = g.releases
                for i in range(len(rel_list)):
                    for j in range(i + 1, len(rel_list)):
                        r_a = rel_list[i]
                        r_b = rel_list[j]
                        if r_a.start_date and r_a.end_date and r_b.start_date and r_b.end_date:
                            c_start = max(r_a.start_date, r_b.start_date)
                            c_end = min(r_a.end_date, r_b.end_date)
                            if c_start <= c_end:
                                conflicts.append(
                                    ReleaseCalendarConflict(
                                        id=f"conf-app-{conflict_idx}",
                                        type="application",
                                        entity_id=g.group_key,
                                        entity_name=g.group_name,
                                        release_a=ReleaseCalendarConflictEntity(
                                            release_id=r_a.release_id,
                                            release_name=r_a.release_name,
                                            start_date=r_a.start_date,
                                            end_date=r_a.end_date
                                        ),
                                        release_b=ReleaseCalendarConflictEntity(
                                            release_id=r_b.release_id,
                                            release_name=r_b.release_name,
                                            start_date=r_b.start_date,
                                            end_date=r_b.end_date
                                        ),
                                        conflict_start_date=c_start,
                                        conflict_end_date=c_end,
                                        severity="HIGH" if (r_a.risk_type == "Major" or r_b.risk_type == "Major") else "MEDIUM",
                                        message=f"Releases '{r_a.release_name}' and '{r_b.release_name}' overlap on Application '{g.group_name}' from {c_start.strftime('%d %b %Y')} to {c_end.strftime('%d %b %Y')}."
                                    )
                                )
                                conflict_idx += 1
        else:  # environment
            # Detect overlapping phases or releases on the same environment
            for g in group_items:
                env_phase_list: List[Tuple[ReleaseCalendarReleaseItem, ReleaseCalendarPhaseItem]] = []
                for r_item in g.releases:
                    for p_item in r_item.phases:
                        env_phase_list.append((r_item, p_item))

                for i in range(len(env_phase_list)):
                    for j in range(i + 1, len(env_phase_list)):
                        r_a, p_a = env_phase_list[i]
                        r_b, p_b = env_phase_list[j]
                        if r_a.release_id != r_b.release_id:  # Different releases
                            c_start = max(p_a.start_date, p_b.start_date)
                            c_end = min(p_a.end_date, p_b.end_date)
                            if c_start <= c_end:
                                conflicts.append(
                                    ReleaseCalendarConflict(
                                        id=f"conf-env-{conflict_idx}",
                                        type="environment",
                                        entity_id=g.group_key,
                                        entity_name=g.group_name,
                                        release_a=ReleaseCalendarConflictEntity(
                                            release_id=r_a.release_id,
                                            release_name=r_a.release_name,
                                            phase_id=p_a.phase_id,
                                            phase_name=p_a.phase_name,
                                            start_date=p_a.start_date,
                                            end_date=p_a.end_date
                                        ),
                                        release_b=ReleaseCalendarConflictEntity(
                                            release_id=r_b.release_id,
                                            release_name=r_b.release_name,
                                            phase_id=p_b.phase_id,
                                            phase_name=p_b.phase_name,
                                            start_date=p_b.start_date,
                                            end_date=p_b.end_date
                                        ),
                                        conflict_start_date=c_start,
                                        conflict_end_date=c_end,
                                        severity="HIGH",
                                        message=f"Environment '{g.group_name}' contention: '{r_a.release_name}' ({p_a.phase_name}) and '{r_b.release_name}' ({p_b.phase_name}) are simultaneously scheduled from {c_start.strftime('%d %b %Y')} to {c_end.strftime('%d %b %Y')}."
                                    )
                                )
                                conflict_idx += 1

        total_phases_count = sum(len(r.phases or []) for r in releases)

        summary = ReleaseCalendarSummary(
            total_releases=len(releases),
            total_phases=total_phases_count,
            active_releases=active_releases_count,
            conflicts_count=len(conflicts)
        )

        return ReleaseCalendarResponse(
            view_by=view_by_norm,
            year=year,
            period=period,
            month=month,
            quarter=effective_quarter,
            date_range=ReleaseCalendarDateRange(
                start_date=start_date,
                end_date=end_date
            ),
            items=group_items,
            conflicts=conflicts,
            summary=summary
        )

    async def check_release_conflicts(
        self, db: AsyncSession, req: ReleaseConflictCheckRequest, current_user: Optional[any] = None
    ) -> ReleaseConflictCheckResponse:
        req_start = _normalize_dt(req.start_date)
        req_end = _normalize_dt(req.end_date)
        if not req_start or not req_end or req_end <= req_start:
            return ReleaseConflictCheckResponse(
                has_conflicts=False,
                conflict_count=0,
                risk_level="LOW",
                conflict_probability=5,
                conflicts=[],
                recommendations=[],
                summary="Please provide valid start and end dates to compute release conflicts."
            )

        duration = req_end - req_start
        duration_days = max(1, round(duration.total_seconds() / 86400))

        # Resolve application and BU names if not provided
        app_name = (req.application or req.application_id or "").strip().lower()
        if req.application_id and not req.application:
            app_obj = await application_dao.get_by_id(db, req.application_id)
            if app_obj:
                app_name = app_obj.name.strip().lower()

        # Fetch active releases
        all_releases = await release_dao.get_releases_for_calendar(
            db=db,
            current_user=current_user,
            start_date=None,
            end_date=None
        )
        active_releases = [
            r for r in all_releases
            if r.status not in ("CANCELLED", "COMPLETED")
            and (not req.exclude_release_id or r.id != req.exclude_release_id)
        ]

        # Fetch active reservations
        res_stmt = select(Reservation).where(
            Reservation.status.in_([
                ReservationStatus.CONFIRMED,
                ReservationStatus.APPROVED,
                ReservationStatus.CONFLICT,
                ReservationStatus.PENDING,
            ])
        )
        res_result = await db.execute(res_stmt)
        active_reservations = list(res_result.scalars().all())

        conflicts: List[ReleaseConflictItem] = []
        conflict_idx = 1

        # 1. Application Schedule Collisions
        if app_name:
            for r in active_releases:
                r_app = (r.application_name or r.application_id or "").strip().lower()
                if r_app and (r_app == app_name or (req.application_id and r.application_id == req.application_id)):
                    r_start = _normalize_dt(r.start_date or r.scheduled_date)
                    r_end = _normalize_dt(r.end_date or r.start_date or r.scheduled_date)
                    if r_start and r_end and req_start < r_end and req_end > r_start:
                        c_start = max(req_start, r_start)
                        c_end = min(req_end, r_end)
                        is_crit = (req.risk_type == "Major" or r.risk_type == "Major")
                        conflicts.append(
                            ReleaseConflictItem(
                                id=f"rel-conf-{conflict_idx}",
                                conflict_type="APPLICATION_OVERLAP",
                                title=f"Application Schedule Collision: {r.application_name or req.application or 'Application'}",
                                conflicting_entity_name=r.application_name or req.application or "Application",
                                conflicting_item_name=f"Release '{r.name}' ({r.risk_type or 'Major'})",
                                start_date=c_start,
                                end_date=c_end,
                                severity="CRITICAL" if is_crit else "HIGH",
                                detail=f"Existing release '{r.name}' is scheduled on application '{r.application_name or req.application}' during this overlapping window ({c_start.strftime('%d %b %Y')} - {c_end.strftime('%d %b %Y')})."
                            )
                        )
                        conflict_idx += 1

        # 2. Environment Phase Contention & Booking Contention
        cand_phases = req.phases or []
        for p_idx, p in enumerate(cand_phases, start=1):
            p_env_id = (p.environment_id or "").strip()
            p_env_name = (p.environment_name or "").strip()
            if not p_env_id and not p_env_name:
                continue
            if p_env_id.lower() == "env-all":
                continue

            p_start = _normalize_dt(p.start_date) or req_start
            p_end = _normalize_dt(p.end_date) or req_end
            if p_end <= p_start:
                continue

            # Check other release phases
            for r in active_releases:
                for other_p in (r.phases or []):
                    other_env_id = (other_p.environment_id or "").strip()
                    other_env_name = (other_p.environment_name or "").strip()
                    env_match = (
                        (p_env_id and other_env_id and p_env_id.lower() == other_env_id.lower()) or
                        (p_env_name and other_env_name and p_env_name.lower() == other_env_name.lower())
                    )
                    if env_match:
                        other_p_start = _normalize_dt(other_p.start_date) or _normalize_dt(r.start_date)
                        other_p_end = _normalize_dt(other_p.end_date) or _normalize_dt(r.end_date)
                        if other_p_start and other_p_end and p_start < other_p_end and p_end > other_p_start:
                            c_start = max(p_start, other_p_start)
                            c_end = min(p_end, other_p_end)
                            conflicts.append(
                                ReleaseConflictItem(
                                    id=f"rel-conf-{conflict_idx}",
                                    conflict_type="ENVIRONMENT_PHASE_CONTENTION",
                                    title=f"Environment Contention: {p_env_name or p_env_id}",
                                    conflicting_entity_name=p_env_name or p_env_id,
                                    conflicting_item_name=f"Release '{r.name}' (Phase: {other_p.phase_name})",
                                    start_date=c_start,
                                    end_date=c_end,
                                    severity="HIGH",
                                    detail=f"Environment '{p_env_name or p_env_id}' is allocated to '{r.name}' ({other_p.phase_name}) from {c_start.strftime('%d %b %Y')} to {c_end.strftime('%d %b %Y')}."
                                )
                            )
                            conflict_idx += 1

            # Check active bookings
            for b in active_reservations:
                b_env_id = (b.environment_id or "").strip()
                b_env_name = (b.environment_name or "").strip()
                env_match = (
                    (p_env_id and b_env_id and p_env_id.lower() == b_env_id.lower()) or
                    (p_env_name and b_env_name and p_env_name.lower() == b_env_name.lower())
                )
                if env_match and b.start_date and b.end_date:
                    b_start = _normalize_dt(b.start_date)
                    b_end = _normalize_dt(b.end_date)
                    if b_start and b_end and p_start < b_end and p_end > b_start:
                        c_start = max(p_start, b_start)
                        c_end = min(p_end, b_end)
                        is_disruptive = (getattr(b, "reservation_mode", "SHARED") == "DISRUPTIVE")
                        conflicts.append(
                            ReleaseConflictItem(
                                id=f"rel-conf-{conflict_idx}",
                                conflict_type="ENVIRONMENT_BOOKING_COLLISION",
                                title=f"Environment Reservation Collision: {p_env_name or p_env_id}",
                                conflicting_entity_name=p_env_name or p_env_id,
                                conflicting_item_name=f"Booking #{b.id} ({b.purpose or 'Reserved'})",
                                start_date=c_start,
                                end_date=c_end,
                                severity="HIGH" if is_disruptive else "MEDIUM",
                                detail=f"Active reservation #{b.id} ({b.team or 'Team'}) occupies '{p_env_name or p_env_id}' from {c_start.strftime('%d %b %Y')} to {c_end.strftime('%d %b %Y')}."
                            )
                        )
                        conflict_idx += 1

        # 3. AI Date Recommendation Generator
        recommendations: List[ReleaseDateRecommendation] = []

        if conflicts:
            def is_window_conflict_free(test_start: datetime, test_end: datetime) -> bool:
                # Check application collisions
                if app_name:
                    for r in active_releases:
                        r_app = (r.application_name or r.application_id or "").strip().lower()
                        if r_app and (r_app == app_name or (req.application_id and r.application_id == req.application_id)):
                            r_s = _normalize_dt(r.start_date or r.scheduled_date)
                            r_e = _normalize_dt(r.end_date or r.start_date or r.scheduled_date)
                            if r_s and r_e and test_start < r_e and test_end > r_s:
                                return False

                # Check phase environment contention
                for p in cand_phases:
                    p_env_id = (p.environment_id or "").strip()
                    p_env_name = (p.environment_name or "").strip()
                    if not p_env_id and not p_env_name:
                        continue
                    if p_env_id.lower() == "env-all":
                        continue

                    orig_p_start = _normalize_dt(p.start_date) or req_start
                    orig_p_end = _normalize_dt(p.end_date) or req_end
                    p_offset = orig_p_start - req_start
                    p_dur = orig_p_end - orig_p_start
                    shift_p_start = test_start + p_offset
                    shift_p_end = shift_p_start + p_dur

                    # Check release phases
                    for r in active_releases:
                        for other_p in (r.phases or []):
                            other_env_id = (other_p.environment_id or "").strip()
                            other_env_name = (other_p.environment_name or "").strip()
                            env_match = (
                                (p_env_id and other_env_id and p_env_id.lower() == other_env_id.lower()) or
                                (p_env_name and other_env_name and p_env_name.lower() == other_env_name.lower())
                            )
                            if env_match:
                                other_s = _normalize_dt(other_p.start_date) or _normalize_dt(r.start_date)
                                other_e = _normalize_dt(other_p.end_date) or _normalize_dt(r.end_date)
                                if other_s and other_e and shift_p_start < other_e and shift_p_end > other_s:
                                    return False

                    # Check active reservations
                    for b in active_reservations:
                        b_env_id = (b.environment_id or "").strip()
                        b_env_name = (b.environment_name or "").strip()
                        env_match = (
                            (p_env_id and b_env_id and p_env_id.lower() == b_env_id.lower()) or
                            (p_env_name and b_env_name and p_env_name.lower() == b_env_name.lower())
                        )
                        if env_match and b.start_date and b.end_date:
                            b_s = _normalize_dt(b.start_date)
                            b_e = _normalize_dt(b.end_date)
                            if b_s and b_e and shift_p_start < b_e and shift_p_end > b_s:
                                return False

                return True

            latest_conflict_end = max((c.end_date for c in conflicts), default=req_end)
            candidate_dates: List[datetime] = []

            base_next = (latest_conflict_end + timedelta(days=1)).replace(hour=req_start.hour, minute=req_start.minute, second=req_start.second)
            candidate_dates.append(base_next)

            for d in range(1, 45):
                cand = (req_start + timedelta(days=d)).replace(hour=req_start.hour, minute=req_start.minute, second=req_start.second)
                candidate_dates.append(cand)
                cand_from_conflict = (latest_conflict_end + timedelta(days=d)).replace(hour=req_start.hour, minute=req_start.minute, second=req_start.second)
                candidate_dates.append(cand_from_conflict)

            seen_starts = set()
            rec_idx = 1
            for cand_s in candidate_dates:
                if cand_s <= req_start:
                    continue
                cand_key = cand_s.strftime("%Y-%m-%d %H:%M")
                if cand_key in seen_starts:
                    continue
                seen_starts.add(cand_key)

                cand_e = cand_s + duration
                if is_window_conflict_free(cand_s, cand_e):
                    shift_days = (cand_s.date() - req_start.date()).days
                    
                    rec_phases: List[ReleaseRecommendedPhaseItem] = []
                    for p in cand_phases:
                        orig_p_start = _normalize_dt(p.start_date) or req_start
                        orig_p_end = _normalize_dt(p.end_date) or req_end
                        p_offset = orig_p_start - req_start
                        p_dur = orig_p_end - orig_p_start
                        shifted_p_s = cand_s + p_offset
                        shifted_p_e = shifted_p_s + p_dur
                        rec_phases.append(
                            ReleaseRecommendedPhaseItem(
                                test_phase_id=p.test_phase_id,
                                phase_name=p.phase_name,
                                color=p.color,
                                start_date=shifted_p_s,
                                end_date=shifted_p_e,
                                environment_id=p.environment_id,
                                environment_name=p.environment_name
                            )
                        )

                    reasoning = f"Shift by +{shift_days} days ({cand_s.strftime('%d %b %Y')} - {cand_e.strftime('%d %b %Y')}). Resolves all collisions and environment contention while preserving {duration_days}-day duration."
                    recommendations.append(
                        ReleaseDateRecommendation(
                            id=f"rec-rel-{rec_idx}",
                            start_date=cand_s,
                            end_date=cand_e,
                            duration_days=duration_days,
                            shifted_days=shift_days,
                            confidence_score=max(85, 99 - (rec_idx - 1) * 4),
                            reasoning=reasoning,
                            phases=rec_phases
                        )
                    )
                    rec_idx += 1
                    if len(recommendations) >= 3:
                        break

        has_conf = len(conflicts) > 0
        risk_lvl = "LOW"
        prob = 5
        if has_conf:
            has_crit = any(c.severity == "CRITICAL" for c in conflicts)
            risk_lvl = "CRITICAL" if has_crit else "HIGH"
            prob = min(98, 60 + len(conflicts) * 12)
            summary_msg = f"AI Release Conflict Analysis detected {len(conflicts)} collision(s). Review conflict details and choose an alternative date recommendation or keep your existing dates."
        else:
            summary_msg = "AI verified: No schedule collisions or environment contention detected for this release window."

        return ReleaseConflictCheckResponse(
            has_conflicts=has_conf,
            conflict_count=len(conflicts),
            risk_level=risk_lvl,
            conflict_probability=prob,
            conflicts=conflicts,
            recommendations=recommendations,
            summary=summary_msg
        )



release_service = ReleaseService()

