from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import EntityNotFoundException
from app.dao.test_phase_dao import test_phase_dao
from app.schemas.test_phase import TestPhaseRead


class TestPhaseService:
    async def get_all_test_phases(
        self, db: AsyncSession, only_active: bool = True
    ) -> List[TestPhaseRead]:
        phases = await test_phase_dao.get_all_ordered(db, only_active=only_active)
        return [TestPhaseRead.model_validate(p) for p in phases]

    async def get_test_phase_by_id(self, db: AsyncSession, phase_id: str) -> TestPhaseRead:
        phase = await test_phase_dao.get_by_id(db, phase_id)
        if not phase:
            raise EntityNotFoundException("TestPhase", phase_id)
        return TestPhaseRead.model_validate(phase)


test_phase_service = TestPhaseService()

