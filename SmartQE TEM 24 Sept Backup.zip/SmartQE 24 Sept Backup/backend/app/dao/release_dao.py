from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy import func, select, and_, or_, asc, desc
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.release import Release, ReleasePhase, ReleaseStatus


class ReleaseDAO(BaseDAO[Release]):
    def __init__(self):
        super().__init__(Release)

    def _build_user_filter_condition(self, current_user: Optional[any]):
        from sqlalchemy import false
        from app.dependencies.auth import is_user_super_admin
        visible_condition = or_(Release.is_visible == True, Release.is_visible.is_(None))
        if is_user_super_admin(current_user) or current_user is None:
            return [visible_condition]

        user_id = str(getattr(current_user, "id", "") or "")
        username = str(getattr(current_user, "username", "") or "")
        full_name = str(getattr(current_user, "full_name", "") or username)

        user_or_clauses = [
            Release.owner_id == user_id,
            Release.lead_id == user_id,
            Release.release_manager_id == user_id,
            Release.created_by.ilike(username),
            Release.created_by.ilike(full_name),
            Release.lead.ilike(username),
            Release.lead.ilike(full_name),
            Release.release_manager_name.ilike(username),
            Release.release_manager_name.ilike(full_name),
        ]

        return [
            visible_condition,
            or_(*user_or_clauses)
        ]

    async def get_by_name(self, db: AsyncSession, name: str) -> Optional[Release]:
        query = select(Release).where(Release.name.ilike(name.strip()))
        result = await db.execute(query)
        return result.scalars().first()

    async def paginate_for_user(
        self,
        db: AsyncSession,
        current_user: Optional[any],
        page: int = 1,
        page_size: int = 20,
        search: Optional[str] = None,
        bu_id: Optional[str] = None,
        project_id: Optional[str] = None,
        status: Optional[str] = None
    ) -> Tuple[List[Release], int]:
        conditions = self._build_user_filter_condition(current_user)

        if search and search.strip():
            term = f"%{search.strip()}%"
            conditions.append(
                or_(
                    Release.name.ilike(term),
                    Release.business_unit.ilike(term),
                    Release.project_name.ilike(term),
                    Release.application_name.ilike(term),
                    Release.release_manager_name.ilike(term),
                    Release.change_ref.ilike(term)
                )
            )

        if bu_id and bu_id.strip():
            conditions.append(or_(Release.bu_id == bu_id.strip(), Release.business_unit.ilike(bu_id.strip())))

        if project_id and project_id.strip():
            conditions.append(or_(Release.project_id == project_id.strip(), Release.project_name.ilike(project_id.strip())))

        if status and status.strip():
            conditions.append(Release.status == status.strip())

        count_query = select(func.count(Release.id)).where(and_(*conditions))
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        start = (page - 1) * page_size
        query = (
            select(Release)
            .options(selectinload(Release.phases))
            .where(and_(*conditions))
            .order_by(desc(Release.created_at))
            .offset(start)
            .limit(page_size)
        )
        result = await db.execute(query)
        items = list(result.scalars().all())
        return items, total

    async def get_by_id_for_user(
        self, db: AsyncSession, rel_id: str, current_user: Optional[any]
    ) -> Optional[Release]:
        conditions = [Release.id == rel_id] + self._build_user_filter_condition(current_user)
        query = select(Release).options(selectinload(Release.phases)).where(and_(*conditions))
        result = await db.execute(query)
        return result.scalars().first()

    async def get_by_status(self, db: AsyncSession, status: ReleaseStatus, current_user: Optional[any] = None) -> List[Release]:
        conditions = [Release.status == status] + self._build_user_filter_condition(current_user)
        query = select(Release).options(selectinload(Release.phases)).where(and_(*conditions)).order_by(desc(Release.created_at))
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_kanban_data(self, db: AsyncSession, current_user: Optional[any] = None) -> Dict[str, List[Release]]:
        scheduled = await self.get_by_status(db, ReleaseStatus.SCHEDULED, current_user=current_user)
        in_progress = await self.get_by_status(db, ReleaseStatus.IN_PROGRESS, current_user=current_user)
        deployed = await self.get_by_status(db, ReleaseStatus.DEPLOYED, current_user=current_user)
        return {
            "SCHEDULED": scheduled,
            "IN_PROGRESS": in_progress,
            "DEPLOYED": deployed
        }

    async def get_releases_for_calendar(
        self,
        db: AsyncSession,
        current_user: Optional[any] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        bu_id: Optional[str] = None,
        release_id: Optional[str] = None,
        application_id: Optional[str] = None,
        environment_id: Optional[str] = None
    ) -> List[Release]:
        conditions = self._build_user_filter_condition(current_user)

        if release_id and release_id.strip() and release_id.lower() != "all":
            conditions.append(Release.id == release_id.strip())

        if bu_id and bu_id.strip() and bu_id.lower() != "all":
            conditions.append(or_(Release.bu_id == bu_id.strip(), Release.business_unit.ilike(bu_id.strip())))

        if application_id and application_id.strip() and application_id.lower() != "all":
            conditions.append(or_(Release.application_id == application_id.strip(), Release.application_name.ilike(application_id.strip())))

        if environment_id and environment_id.strip() and environment_id.lower() != "all":
            # Either release matches environment or has phases in environment
            conditions.append(
                or_(
                    Release.environment_id == environment_id.strip(),
                    Release.environment_name.ilike(environment_id.strip()),
                    Release.phases.any(
                        or_(
                            ReleasePhase.environment_id == environment_id.strip(),
                            ReleasePhase.environment_name.ilike(environment_id.strip())
                        )
                    )
                )
            )

        if start_date and end_date:
            # Overlap condition:
            # (release start <= end_date and release end >= start_date) OR
            # (release scheduled_date between start and end) OR
            # (any phase overlaps [start_date, end_date])
            conditions.append(
                or_(
                    and_(Release.start_date <= end_date, Release.end_date >= start_date),
                    and_(Release.scheduled_date >= start_date, Release.scheduled_date <= end_date),
                    Release.phases.any(
                        and_(ReleasePhase.start_date <= end_date, ReleasePhase.end_date >= start_date)
                    )
                )
            )

        query = (
            select(Release)
            .options(selectinload(Release.phases))
            .where(and_(*conditions))
            .order_by(asc(Release.start_date), asc(Release.scheduled_date), asc(Release.name))
        )
        result = await db.execute(query)
        return list(result.scalars().all())


class ReleasePhaseDAO(BaseDAO[ReleasePhase]):
    def __init__(self):
        super().__init__(ReleasePhase)

    async def get_by_release_id(self, db: AsyncSession, release_id: str) -> List[ReleasePhase]:
        query = (
            select(ReleasePhase)
            .where(ReleasePhase.release_id == release_id)
            .order_by(asc(ReleasePhase.sequence), asc(ReleasePhase.start_date))
        )
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_phase_by_id(self, db: AsyncSession, phase_id: str) -> Optional[ReleasePhase]:
        query = select(ReleasePhase).where(ReleasePhase.id == phase_id)
        result = await db.execute(query)
        return result.scalars().first()


release_dao = ReleaseDAO()
release_phase_dao = ReleasePhaseDAO()
