from typing import List, Optional
from sqlalchemy import select, asc
from sqlalchemy.ext.asyncio import AsyncSession
from app.dao.base_dao import BaseDAO
from app.models.test_phase import TestPhase


class TestPhaseDAO(BaseDAO[TestPhase]):
    __test__ = False
    def __init__(self):
        super().__init__(TestPhase)

    async def get_all_ordered(self, db: AsyncSession, only_active: bool = False) -> List[TestPhase]:
        query = select(TestPhase).order_by(asc(TestPhase.display_order), asc(TestPhase.name))
        if only_active:
            query = query.where(TestPhase.is_active == True)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def get_by_name(self, db: AsyncSession, name: str) -> Optional[TestPhase]:
        query = select(TestPhase).where(TestPhase.name.ilike(name.strip()))
        result = await db.execute(query)
        return result.scalars().first()

    async def get_system_phases(self, db: AsyncSession) -> List[TestPhase]:
        query = select(TestPhase).where(TestPhase.is_system == True).order_by(asc(TestPhase.display_order))
        result = await db.execute(query)
        return list(result.scalars().all())


test_phase_dao = TestPhaseDAO()
