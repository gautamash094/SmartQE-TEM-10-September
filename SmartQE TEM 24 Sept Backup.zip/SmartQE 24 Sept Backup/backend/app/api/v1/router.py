from fastapi import APIRouter
from app.api.v1.endpoints import (
    auth, users, environments, reservations, releases, incidents, runbooks,
    portfolio, health, environment_profiles, inventory, topology, roles, settings, access,
    user_groups, workflows, notifications, provisioning, test_phases
)

api_router = APIRouter()

api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(roles.router)
api_router.include_router(access.router)
api_router.include_router(user_groups.router)
api_router.include_router(workflows.router)
api_router.include_router(settings.router)
api_router.include_router(environments.router)
api_router.include_router(portfolio.router)
api_router.include_router(reservations.router)
api_router.include_router(notifications.router)
api_router.include_router(test_phases.router)
api_router.include_router(releases.router)
api_router.include_router(incidents.router)
api_router.include_router(runbooks.router)
api_router.include_router(environment_profiles.router)
api_router.include_router(inventory.router)
api_router.include_router(provisioning.router)
api_router.include_router(topology.router, prefix="/topology", tags=["Topology"])

