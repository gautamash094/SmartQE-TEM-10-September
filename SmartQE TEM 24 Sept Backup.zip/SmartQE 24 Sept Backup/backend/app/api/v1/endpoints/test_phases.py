from typing import List
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.test_phase import TestPhaseRead
from app.schemas.common import StandardResponse
from app.services.test_phase_service import test_phase_service

router = APIRouter(prefix="/test-phases", tags=["Test Phases Master"])


@router.get("", response_model=StandardResponse[List[TestPhaseRead]])
async def get_test_phases(
    only_active: bool = Query(default=True),
    db: AsyncSession = Depends(get_db)
):
    """
    Read-only endpoint to retrieve system-defined test phases ordered by display_order.
    Only active phases are returned by default.
    """
    phases = await test_phase_service.get_all_test_phases(db, only_active=only_active)
    return StandardResponse(
        success=True,
        message="Test phases retrieved successfully",
        data=phases
    )


@router.get("/{phase_id}", response_model=StandardResponse[TestPhaseRead])
async def get_test_phase_by_id(
    phase_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Read-only endpoint to retrieve a test phase by its unique identifier.
    """
    phase = await test_phase_service.get_test_phase_by_id(db, phase_id)
    return StandardResponse(
        success=True,
        message="Test phase details retrieved",
        data=phase
    )
