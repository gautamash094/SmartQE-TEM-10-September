from typing import List, Dict, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.dependencies.auth import get_current_user_optional
from app.models.user import User
from app.schemas.release import (
    ReleaseCreate, ReleaseUpdate, ReleaseRead,
    ReleasePhaseCreate, ReleasePhaseUpdate, ReleasePhaseRead, ReleasePhaseReorder,
    ReleaseCalendarResponse, ReleaseConflictCheckRequest, ReleaseConflictCheckResponse
)
from app.schemas.common import StandardResponse, MetaParams
from app.services.release_service import release_service

router = APIRouter(prefix="/releases", tags=["Releases"])


@router.post("/check-conflicts", response_model=StandardResponse[ReleaseConflictCheckResponse])
async def check_release_conflicts(
    conflict_in: ReleaseConflictCheckRequest,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    result = await release_service.check_release_conflicts(db, conflict_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release conflict check evaluated successfully",
        data=result
    )



@router.get("/calendar", response_model=StandardResponse[ReleaseCalendarResponse])
async def get_release_calendar(
    viewBy: str = Query(default="application", pattern="^(application|environment)$"),
    year: int = Query(default=2026, ge=2000, le=2100),
    period: str = Query(default="month", pattern="^(month|quarter|year)$"),
    month: Optional[int] = Query(default=None, ge=1, le=12),
    quarter: Optional[int] = Query(default=None, ge=1, le=4),
    buId: Optional[str] = None,
    releaseId: Optional[str] = None,
    applicationId: Optional[str] = None,
    environmentId: Optional[str] = None,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    calendar_data = await release_service.get_calendar_timeline(
        db=db,
        view_by=viewBy,
        year=year,
        period=period,
        month=month,
        quarter=quarter,
        bu_id=buId,
        release_id=releaseId,
        application_id=applicationId,
        environment_id=environmentId,
        current_user=current_user
    )
    return StandardResponse(
        success=True,
        message="Release calendar timeline retrieved successfully",
        data=calendar_data
    )



@router.get("", response_model=StandardResponse[List[ReleaseRead]])
async def get_releases(
    page: int = Query(default=1, ge=1),
    pageSize: int = Query(default=20, ge=1, le=100),
    search: Optional[str] = None,
    buId: Optional[str] = None,
    projectId: Optional[str] = None,
    status: Optional[str] = None,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    items, total = await release_service.get_releases_paginated(
        db, page=page, page_size=pageSize,
        search=search, bu_id=buId, project_id=projectId, status=status,
        current_user=current_user
    )
    return StandardResponse(
        success=True,
        message="Releases retrieved successfully",
        data=items,
        meta=MetaParams(page=page, pageSize=pageSize, total=total)
    )


@router.get("/kanban", response_model=StandardResponse[Dict[str, List[ReleaseRead]]])
async def get_kanban_board(
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    kanban = await release_service.get_kanban_board(db, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Kanban board populated",
        data=kanban
    )


@router.post("", response_model=StandardResponse[ReleaseRead], status_code=status.HTTP_201_CREATED)
async def create_release(
    rel_in: ReleaseCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    created = await release_service.create_release(db, rel_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release created successfully",
        data=created
    )


@router.get("/{rel_id}", response_model=StandardResponse[ReleaseRead])
async def get_release_by_id(
    rel_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    res = await release_service.get_release_by_id(db, rel_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release details retrieved",
        data=res
    )


@router.put("/{rel_id}", response_model=StandardResponse[ReleaseRead])
async def update_release(
    rel_id: str,
    rel_in: ReleaseUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await release_service.update_release(db, rel_id, rel_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release updated successfully",
        data=updated
    )


@router.delete("/{rel_id}", response_model=StandardResponse[dict])
async def delete_release(
    rel_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    await release_service.delete_release(db, rel_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release deleted successfully",
        data={"id": rel_id}
    )


# --- Release Phase Sub-Endpoints ---

@router.get("/{rel_id}/phases", response_model=StandardResponse[List[ReleasePhaseRead]])
async def get_release_phases(
    rel_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    phases = await release_service.get_phases_for_release(db, rel_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release phases retrieved successfully",
        data=phases
    )


@router.post("/{rel_id}/phases", response_model=StandardResponse[ReleasePhaseRead], status_code=status.HTTP_201_CREATED)
async def add_release_phase(
    rel_id: str,
    phase_in: ReleasePhaseCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    created = await release_service.add_phase_to_release(db, rel_id, phase_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Phase added to release successfully",
        data=created
    )


@router.put("/{rel_id}/phases/{phase_id}", response_model=StandardResponse[ReleasePhaseRead])
async def update_release_phase(
    rel_id: str,
    phase_id: str,
    phase_in: ReleasePhaseUpdate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    updated = await release_service.update_release_phase(db, rel_id, phase_id, phase_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release phase updated successfully",
        data=updated
    )


@router.delete("/{rel_id}/phases/{phase_id}", response_model=StandardResponse[dict])
async def delete_release_phase(
    rel_id: str,
    phase_id: str,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    await release_service.delete_release_phase(db, rel_id, phase_id, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release phase deleted successfully",
        data={"id": phase_id}
    )


@router.post("/{rel_id}/phases/reorder", response_model=StandardResponse[List[ReleasePhaseRead]])
async def reorder_release_phases(
    rel_id: str,
    reorder_in: ReleasePhaseReorder,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: AsyncSession = Depends(get_db)
):
    phases = await release_service.reorder_release_phases(db, rel_id, reorder_in, current_user=current_user)
    return StandardResponse(
        success=True,
        message="Release phases reordered successfully",
        data=phases
    )
