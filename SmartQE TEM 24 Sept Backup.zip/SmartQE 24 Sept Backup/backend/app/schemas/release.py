from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.models.release import ReleaseRisk, ReleaseRiskType, ReleaseStatus


# --- Release Phase Schemas ---
class ReleasePhaseBase(BaseModel):
    test_phase_id: Optional[str] = None
    phase_name: str = Field(..., min_length=1, description="Phase name, e.g. UNIT, SIT, QA")
    color: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    start_date: datetime = Field(..., description="Phase Start Date & Time")
    end_date: datetime = Field(..., description="Phase End Date & Time")
    sequence: Optional[int] = 1
    status: Optional[str] = "NOT_STARTED"
    remarks: Optional[str] = None

    @field_validator("phase_name", mode="before")
    @classmethod
    def validate_phase_name(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Phase name cannot be empty")
            return trimmed
        return v


class ReleasePhaseCreate(ReleasePhaseBase):
    pass


class ReleasePhaseUpdate(BaseModel):
    test_phase_id: Optional[str] = None
    phase_name: Optional[str] = None
    color: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    sequence: Optional[int] = None
    status: Optional[str] = None
    remarks: Optional[str] = None


class ReleasePhaseReorderItem(BaseModel):
    id: str
    sequence: int


class ReleasePhaseReorder(BaseModel):
    phases: List[ReleasePhaseReorderItem]


class ReleasePhaseRead(ReleasePhaseBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    release_id: str
    created_by: str
    updated_by: str
    created_at: datetime
    updated_at: datetime


# --- Release Schemas ---
class ReleaseBase(BaseModel):
    name: str = Field(..., min_length=1, description="Release Name")
    
    # Hierarchy
    bu_id: Optional[str] = None
    business_unit: Optional[str] = None
    project_id: Optional[str] = None
    project_name: Optional[str] = None
    application_id: Optional[str] = None
    application_name: Optional[str] = None
    
    # Risk
    risk_type: Optional[str] = "Major"
    risk: Optional[ReleaseRisk] = ReleaseRisk.LOW_RISK
    
    # Manager
    release_manager_id: Optional[str] = None
    release_manager_name: Optional[str] = None
    
    # Timeline
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    scheduled_date: Optional[datetime] = None
    
    # Links & Notes
    repository_url: Optional[str] = None
    remarks: Optional[str] = None

    # Legacy compatibility fields
    version: Optional[str] = "v1.0.0"
    environment_id: Optional[str] = None
    environment_name: Optional[str] = "All Environments"
    lead: Optional[str] = "Release Lead"
    lead_id: Optional[str] = None
    change_ref: Optional[str] = "CR-REL"
    status: Optional[ReleaseStatus] = ReleaseStatus.SCHEDULED
    is_visible: Optional[bool] = True
    created_by: Optional[str] = None
    modified_by: Optional[str] = None

    @field_validator("name", mode="before")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Release Name cannot be empty")
            return trimmed
        return v


class ReleaseCreate(ReleaseBase):
    initial_phases: Optional[List[ReleasePhaseCreate]] = None


class ReleaseUpdate(BaseModel):
    name: Optional[str] = None
    bu_id: Optional[str] = None
    business_unit: Optional[str] = None
    project_id: Optional[str] = None
    project_name: Optional[str] = None
    application_id: Optional[str] = None
    application_name: Optional[str] = None
    risk_type: Optional[str] = None
    risk: Optional[ReleaseRisk] = None
    release_manager_id: Optional[str] = None
    release_manager_name: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    scheduled_date: Optional[datetime] = None
    repository_url: Optional[str] = None
    remarks: Optional[str] = None
    version: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    lead: Optional[str] = None
    lead_id: Optional[str] = None
    change_ref: Optional[str] = None
    status: Optional[ReleaseStatus] = None
    is_visible: Optional[bool] = None
    modified_by: Optional[str] = None


class ReleaseRead(ReleaseBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    phases: List[ReleasePhaseRead] = []
    created_at: datetime
    updated_at: datetime


# --- Release Calendar Schemas ---
class ReleaseCalendarPhaseItem(BaseModel):
    phase_id: str
    phase_name: str
    test_phase_id: Optional[str] = None
    color: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    start_date: datetime
    end_date: datetime
    sequence: int = 1
    status: str = "NOT_STARTED"
    remarks: Optional[str] = None


class ReleaseCalendarReleaseItem(BaseModel):
    release_id: str
    release_name: str
    version: Optional[str] = "v1.0.0"
    risk_type: Optional[str] = "Major"
    risk: Optional[str] = "LOW RISK"
    status: Optional[str] = "SCHEDULED"
    release_manager: Optional[str] = None
    bu_id: Optional[str] = None
    business_unit: Optional[str] = None
    project_id: Optional[str] = None
    project_name: Optional[str] = None
    application_id: Optional[str] = None
    application_name: Optional[str] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    repository_url: Optional[str] = None
    remarks: Optional[str] = None
    phases: List[ReleaseCalendarPhaseItem] = []


class ReleaseCalendarGroupItem(BaseModel):
    group_key: str
    group_name: str
    group_type: str  # "application" or "environment"
    business_unit: Optional[str] = None
    project_id: Optional[str] = None
    project_name: Optional[str] = None
    releases: List[ReleaseCalendarReleaseItem] = []


class ReleaseCalendarConflictEntity(BaseModel):
    release_id: str
    release_name: str
    phase_id: Optional[str] = None
    phase_name: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None


class ReleaseCalendarConflict(BaseModel):
    id: str
    type: str  # "environment" or "application"
    entity_id: str
    entity_name: str
    release_a: ReleaseCalendarConflictEntity
    release_b: ReleaseCalendarConflictEntity
    conflict_start_date: datetime
    conflict_end_date: datetime
    severity: str = "HIGH"
    message: str


class ReleaseCalendarSummary(BaseModel):
    total_releases: int = 0
    total_phases: int = 0
    active_releases: int = 0
    conflicts_count: int = 0


class ReleaseCalendarDateRange(BaseModel):
    start_date: datetime
    end_date: datetime


class ReleaseCalendarResponse(BaseModel):
    view_by: str  # "application" or "environment"
    year: int
    period: str  # "month", "quarter", "year"
    month: Optional[int] = None
    quarter: Optional[int] = None
    date_range: ReleaseCalendarDateRange
    items: List[ReleaseCalendarGroupItem] = []
    conflicts: List[ReleaseCalendarConflict] = []
    summary: ReleaseCalendarSummary


# --- AI Release Conflict & Date Recommendation Schemas ---
class ReleaseConflictPhaseInput(BaseModel):
    test_phase_id: Optional[str] = None
    phase_name: Optional[str] = None
    color: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None


class ReleaseConflictCheckRequest(BaseModel):
    name: Optional[str] = None
    bu_id: Optional[str] = None
    business_unit: Optional[str] = None
    project_id: Optional[str] = None
    project: Optional[str] = None
    application_id: Optional[str] = None
    application: Optional[str] = None
    risk_type: Optional[str] = "Major"
    release_manager_id: Optional[str] = None
    start_date: datetime
    end_date: datetime
    environment_id: Optional[str] = None
    phases: Optional[List[ReleaseConflictPhaseInput]] = []
    exclude_release_id: Optional[str] = None


class ReleaseConflictItem(BaseModel):
    id: str
    conflict_type: str  # "APPLICATION_OVERLAP" | "ENVIRONMENT_PHASE_CONTENTION" | "ENVIRONMENT_BOOKING_COLLISION"
    title: str
    conflicting_entity_name: str
    conflicting_item_name: str
    start_date: datetime
    end_date: datetime
    severity: str  # "CRITICAL" | "HIGH" | "MEDIUM" | "WARNING"
    detail: str


class ReleaseRecommendedPhaseItem(BaseModel):
    test_phase_id: Optional[str] = None
    phase_name: Optional[str] = None
    color: Optional[str] = None
    start_date: datetime
    end_date: datetime
    environment_id: Optional[str] = None
    environment_name: Optional[str] = None


class ReleaseDateRecommendation(BaseModel):
    id: str
    start_date: datetime
    end_date: datetime
    duration_days: int
    shifted_days: int
    confidence_score: int
    reasoning: str
    phases: List[ReleaseRecommendedPhaseItem] = []


class ReleaseConflictCheckResponse(BaseModel):
    has_conflicts: bool
    conflict_count: int
    risk_level: str  # "LOW" | "MEDIUM" | "HIGH" | "VERY_HIGH"
    conflict_probability: int
    conflicts: List[ReleaseConflictItem] = []
    recommendations: List[ReleaseDateRecommendation] = []
    summary: str


