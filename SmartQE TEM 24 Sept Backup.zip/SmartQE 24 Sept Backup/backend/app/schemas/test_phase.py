from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator


class TestPhaseBase(BaseModel):
    __test__ = False
    name: str = Field(..., min_length=1, description="Test Phase Name, e.g. UNIT, SIT, QA, Performance")
    display_name: str = Field(..., min_length=1, description="Display Name")
    description: Optional[str] = None
    color: str = Field(default="#3B82F6", description="Hex Color code")
    is_system: Optional[bool] = True
    is_active: Optional[bool] = True
    display_order: Optional[int] = 1

    @field_validator("name", "display_name", mode="before")
    @classmethod
    def validate_non_empty_trimmed(cls, v: str) -> str:
        if isinstance(v, str):
            trimmed = v.strip()
            if not trimmed:
                raise ValueError("Field cannot be empty or whitespace only")
            return trimmed
        return v

    @field_validator("color", mode="before")
    @classmethod
    def validate_color_code(cls, v: Optional[str]) -> str:
        if isinstance(v, str) and v.strip():
            trimmed = v.strip()
            if not trimmed.startswith("#") and len(trimmed) in (3, 6, 8):
                return f"#{trimmed}"
            return trimmed
        return "#3B82F6"


class TestPhaseRead(TestPhaseBase):
    __test__ = False
    model_config = ConfigDict(from_attributes=True)

    id: str
    created_by: Optional[str] = "System"
    updated_by: Optional[str] = "System"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

