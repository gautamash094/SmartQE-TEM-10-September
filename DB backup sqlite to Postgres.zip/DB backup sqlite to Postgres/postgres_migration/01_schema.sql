-- =============================================================================
-- SmartQE TEM PostgreSQL Schema (01_schema.sql)
-- Creates all 56 tables, primary keys, and check constraints
-- Generated: 2026-11-23 16:07:51
-- =============================================================================

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

DROP VIEW IF EXISTS "environments" CASCADE;
DROP TABLE IF EXISTS "workflows" CASCADE;
DROP TABLE IF EXISTS "workflow_executions" CASCADE;
DROP TABLE IF EXISTS "workflow_execution_steps" CASCADE;
DROP TABLE IF EXISTS "workflow_approvers" CASCADE;
DROP TABLE IF EXISTS "users" CASCADE;
DROP TABLE IF EXISTS "user_sessions" CASCADE;
DROP TABLE IF EXISTS "user_roles" CASCADE;
DROP TABLE IF EXISTS "user_groups" CASCADE;
DROP TABLE IF EXISTS "user_group_members" CASCADE;
DROP TABLE IF EXISTS "topology_relationships" CASCADE;
DROP TABLE IF EXISTS "test_phases" CASCADE;
DROP TABLE IF EXISTS "system_settings" CASCADE;
DROP TABLE IF EXISTS "runbooks" CASCADE;
DROP TABLE IF EXISTS "roles" CASCADE;
DROP TABLE IF EXISTS "role_screen_access" CASCADE;
DROP TABLE IF EXISTS "reservations" CASCADE;
DROP TABLE IF EXISTS "releases" CASCADE;
DROP TABLE IF EXISTS "release_phases" CASCADE;
DROP TABLE IF EXISTS "provisioning_templates" CASCADE;
DROP TABLE IF EXISTS "provisioning_steps" CASCADE;
DROP TABLE IF EXISTS "provisioning_resources" CASCADE;
DROP TABLE IF EXISTS "provisioning_requests" CASCADE;
DROP TABLE IF EXISTS "provisioning_logs" CASCADE;
DROP TABLE IF EXISTS "provisioning_dependencies" CASCADE;
DROP TABLE IF EXISTS "provisioning_audits" CASCADE;
DROP TABLE IF EXISTS "provisioning_approvals" CASCADE;
DROP TABLE IF EXISTS "projects" CASCADE;
DROP TABLE IF EXISTS "password_reset_tokens" CASCADE;
DROP TABLE IF EXISTS "monitoring_tool_configs" CASCADE;
DROP TABLE IF EXISTS "monitoring_time_series_metrics" CASCADE;
DROP TABLE IF EXISTS "monitoring_threshold_rules" CASCADE;
DROP TABLE IF EXISTS "monitoring_test_execution_correlations" CASCADE;
DROP TABLE IF EXISTS "monitoring_targets" CASCADE;
DROP TABLE IF EXISTS "monitoring_notification_rules" CASCADE;
DROP TABLE IF EXISTS "monitoring_exporters" CASCADE;
DROP TABLE IF EXISTS "monitoring_events" CASCADE;
DROP TABLE IF EXISTS "monitoring_correlated_incidents" CASCADE;
DROP TABLE IF EXISTS "monitoring_config_audit_logs" CASCADE;
DROP TABLE IF EXISTS "incidents" CASCADE;
DROP TABLE IF EXISTS "health_check_results" CASCADE;
DROP TABLE IF EXISTS "health_check_executions" CASCADE;
DROP TABLE IF EXISTS "health_check_definitions" CASCADE;
DROP TABLE IF EXISTS "environment_softwares" CASCADE;
DROP TABLE IF EXISTS "environment_profiles" CASCADE;
DROP TABLE IF EXISTS "email_notifications" CASCADE;
DROP TABLE IF EXISTS "components" CASCADE;
DROP TABLE IF EXISTS "business_units" CASCADE;
DROP TABLE IF EXISTS "auto_heal_rules" CASCADE;
DROP TABLE IF EXISTS "auto_heal_executions" CASCADE;
DROP TABLE IF EXISTS "auth_audit_logs" CASCADE;
DROP TABLE IF EXISTS "assets" CASCADE;
DROP TABLE IF EXISTS "asset_audit_logs" CASCADE;
DROP TABLE IF EXISTS "applications" CASCADE;
DROP TABLE IF EXISTS "application_screens" CASCADE;
DROP TABLE IF EXISTS "app_version_detection_logs" CASCADE;
DROP TABLE IF EXISTS "app_version_detection_configs" CASCADE;


CREATE TABLE "app_version_detection_configs" (
    "application_id" VARCHAR,
    "application_name" VARCHAR NOT NULL,
    "environment_id" VARCHAR,
    "environment_name" VARCHAR NOT NULL,
    "source_type" VARCHAR(16) NOT NULL,
    "source_path" VARCHAR NOT NULL,
    "version_key" VARCHAR,
    "extraction_pattern" VARCHAR,
    "detection_method" VARCHAR NOT NULL,
    "auth_type" VARCHAR NOT NULL,
    "auth_secret" VARCHAR,
    "custom_headers" JSONB NOT NULL,
    "timeout_seconds" INTEGER NOT NULL,
    "expected_version" VARCHAR,
    "last_detected_version" VARCHAR,
    "last_status" VARCHAR(14) NOT NULL,
    "last_checked" TIMESTAMP WITHOUT TIME ZONE,
    "last_error" TEXT,
    "last_response_time_ms" INTEGER,
    "is_active" BOOLEAN NOT NULL,
    "is_visible" BOOLEAN NOT NULL,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "app_version_detection_configs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "app_version_detection_logs" (
    "config_id" VARCHAR,
    "application_name" VARCHAR NOT NULL,
    "environment_id" VARCHAR,
    "environment_name" VARCHAR NOT NULL,
    "detected_version" VARCHAR,
    "expected_version" VARCHAR,
    "previous_version" VARCHAR,
    "status" VARCHAR(14) NOT NULL,
    "source_type" VARCHAR NOT NULL,
    "source_path" VARCHAR NOT NULL,
    "detection_duration_ms" INTEGER NOT NULL,
    "error_message" TEXT,
    "raw_payload_snippet" TEXT,
    "triggered_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "app_version_detection_logs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "application_screens" (
    "key" VARCHAR NOT NULL,
    "name" VARCHAR NOT NULL,
    "route" VARCHAR NOT NULL,
    "parent_key" VARCHAR,
    "category" VARCHAR NOT NULL,
    "display_order" INTEGER NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "application_screens_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "applications" (
    "name" VARCHAR NOT NULL,
    "code" VARCHAR NOT NULL,
    "business_unit" VARCHAR NOT NULL,
    "project_name" VARCHAR,
    "owner" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "status" VARCHAR,
    "is_active" BOOLEAN,
    "component_name" VARCHAR,
    "is_visible" BOOLEAN,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    CONSTRAINT "applications_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "asset_audit_logs" (
    "asset_id" VARCHAR NOT NULL,
    "action" VARCHAR NOT NULL,
    "changed_by" VARCHAR NOT NULL,
    "changed_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "field_name" VARCHAR,
    "old_value" VARCHAR,
    "new_value" VARCHAR,
    "notes" TEXT,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "asset_audit_logs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "assets" (
    "asset_id" VARCHAR NOT NULL,
    "name" VARCHAR NOT NULL,
    "asset_type" VARCHAR(17) NOT NULL,
    "infrastructure_type" VARCHAR(11) NOT NULL,
    "cloud_provider" VARCHAR(13) NOT NULL,
    "business_unit" VARCHAR NOT NULL,
    "account_name" VARCHAR NOT NULL,
    "environment_id" VARCHAR,
    "environment_name" VARCHAR,
    "environment_type" VARCHAR,
    "application_name" VARCHAR,
    "ip_address" VARCHAR,
    "hostname" VARCHAR,
    "operating_system" VARCHAR,
    "os_version" VARCHAR,
    "runtime_stack" VARCHAR,
    "cpu_cores" INTEGER,
    "ram_gb" DOUBLE PRECISION,
    "storage_gb" DOUBLE PRECISION,
    "region" VARCHAR,
    "availability_zone" VARCHAR,
    "datacenter" VARCHAR,
    "rack_unit" VARCHAR,
    "instance_id" VARCHAR,
    "instance_type" VARCHAR,
    "vpc_subnet" VARCHAR,
    "installed_software" JSONB NOT NULL,
    "status" VARCHAR(14) NOT NULL,
    "owner_team" VARCHAR NOT NULL,
    "responsible_person" VARCHAR,
    "cost_center" VARCHAR,
    "end_of_life_date" VARCHAR,
    "notes" TEXT,
    "tags" JSONB NOT NULL,
    "created_by" VARCHAR NOT NULL,
    "updated_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "is_active" BOOLEAN,
    "is_visible" BOOLEAN,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    CONSTRAINT "assets_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "auth_audit_logs" (
    "user_id" VARCHAR,
    "username" VARCHAR NOT NULL,
    "event_type" VARCHAR NOT NULL,
    "status" VARCHAR NOT NULL,
    "ip_address" VARCHAR,
    "details" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "auth_audit_logs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "auto_heal_executions" (
    "rule_id" VARCHAR,
    "rule_name" VARCHAR NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "application_name" VARCHAR,
    "trigger_source" VARCHAR NOT NULL,
    "trigger_reason" TEXT NOT NULL,
    "action_type" VARCHAR(20) NOT NULL,
    "action_target" VARCHAR NOT NULL,
    "execution_mode" VARCHAR(17) NOT NULL,
    "status" VARCHAR(16) NOT NULL,
    "attempt_number" INTEGER NOT NULL,
    "max_retries" INTEGER NOT NULL,
    "before_health_status" VARCHAR(11) NOT NULL,
    "after_health_status" VARCHAR(11),
    "started_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "completed_at" TIMESTAMP WITHOUT TIME ZONE,
    "duration_seconds" DOUBLE PRECISION NOT NULL,
    "output_log" TEXT,
    "error_details" TEXT,
    "linked_incident_id" VARCHAR,
    "executed_by" VARCHAR NOT NULL,
    "approved_by" VARCHAR,
    "approved_at" TIMESTAMP WITHOUT TIME ZONE,
    "is_visible" BOOLEAN NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "auto_heal_executions_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "auto_heal_rules" (
    "name" VARCHAR NOT NULL,
    "description" VARCHAR,
    "environment_id" VARCHAR,
    "environment_name" VARCHAR,
    "application_id" VARCHAR,
    "application_name" VARCHAR,
    "trigger_type" VARCHAR(20) NOT NULL,
    "trigger_check_type" VARCHAR(8),
    "trigger_criticality" VARCHAR(8) NOT NULL,
    "action_type" VARCHAR(20) NOT NULL,
    "action_target" VARCHAR NOT NULL,
    "runbook_id" VARCHAR,
    "execution_mode" VARCHAR(17) NOT NULL,
    "max_retries" INTEGER NOT NULL,
    "retry_interval_seconds" INTEGER NOT NULL,
    "grace_period_seconds" INTEGER NOT NULL,
    "is_enabled" BOOLEAN NOT NULL,
    "create_incident_on_exhaustion" BOOLEAN NOT NULL,
    "incident_severity" VARCHAR NOT NULL,
    "is_visible" BOOLEAN NOT NULL,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "script_type" VARCHAR(10),
    "script_content" TEXT,
    "script_parameters" TEXT,
    "script_timeout_seconds" INTEGER,
    CONSTRAINT "auto_heal_rules_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "business_units" (
    "name" VARCHAR NOT NULL,
    "code" VARCHAR NOT NULL,
    "lead" VARCHAR,
    "description" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "status" VARCHAR,
    "is_active" BOOLEAN,
    "is_visible" BOOLEAN,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    CONSTRAINT "business_units_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "components" (
    "id" VARCHAR NOT NULL,
    "name" VARCHAR NOT NULL,
    "code" VARCHAR,
    "description" VARCHAR,
    "business_unit" VARCHAR NOT NULL,
    "project_name" VARCHAR,
    "endpoint_url" VARCHAR,
    "status" VARCHAR NOT NULL DEFAULT 'ACTIVE',
    "is_active" BOOLEAN NOT NULL DEFAULT TRUE,
    "is_visible" BOOLEAN NOT NULL DEFAULT TRUE,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "components_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "email_notifications" (
    "booking_id" VARCHAR NOT NULL,
    "notification_type" VARCHAR NOT NULL,
    "step_order" INTEGER,
    "recipient_to" VARCHAR NOT NULL,
    "recipient_cc" VARCHAR,
    "subject" VARCHAR NOT NULL,
    "body" VARCHAR NOT NULL,
    "status" VARCHAR NOT NULL,
    "sent_at" TIMESTAMP WITHOUT TIME ZONE,
    "error_message" VARCHAR,
    "retry_count" INTEGER NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "email_notifications_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "environment_profiles" (
    "name" VARCHAR NOT NULL,
    "type" VARCHAR NOT NULL,
    "description" VARCHAR,
    "status" VARCHAR(11) NOT NULL,
    "owner_team" VARCHAR,
    "network_zone" VARCHAR,
    "server_ids" JSONB NOT NULL,
    "software_ids" JSONB NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "is_active" BOOLEAN,
    "is_visible" BOOLEAN,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    "business_unit" VARCHAR,
    "business_units" JSONB,
    CONSTRAINT "environment_profiles_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "environment_softwares" (
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "software_name" VARCHAR NOT NULL,
    "category" VARCHAR(10) NOT NULL,
    "installed_version" VARCHAR,
    "expected_version" VARCHAR,
    "status" VARCHAR(16) NOT NULL,
    "port" VARCHAR,
    "process_path" VARCHAR,
    "service_name" VARCHAR,
    "vendor" VARCHAR,
    "last_checked" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "check_details" TEXT,
    "is_active" BOOLEAN NOT NULL,
    "is_visible" BOOLEAN NOT NULL,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "environment_softwares_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "health_check_definitions" (
    "name" VARCHAR NOT NULL,
    "check_type" VARCHAR(8) NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR,
    "application_id" VARCHAR,
    "application_name" VARCHAR,
    "server_id" VARCHAR,
    "server_name" VARCHAR,
    "target_host" VARCHAR,
    "target_port" INTEGER,
    "target_url" VARCHAR,
    "http_method" VARCHAR NOT NULL,
    "expected_http_status" INTEGER,
    "expected_response_substring" VARCHAR,
    "timeout_seconds" DOUBLE PRECISION NOT NULL,
    "retry_count" INTEGER NOT NULL,
    "retry_interval_seconds" DOUBLE PRECISION NOT NULL,
    "criticality" VARCHAR(8) NOT NULL,
    "weight" INTEGER NOT NULL,
    "is_enabled" BOOLEAN NOT NULL,
    "auto_heal_runbook_id" VARCHAR,
    "auto_heal_enabled" BOOLEAN NOT NULL,
    "is_visible" BOOLEAN NOT NULL,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "health_check_definitions_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "health_check_executions" (
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "overall_status" VARCHAR(11) NOT NULL,
    "health_score" DOUBLE PRECISION NOT NULL,
    "triggered_by" VARCHAR NOT NULL,
    "trigger_type" VARCHAR NOT NULL,
    "started_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "completed_at" TIMESTAMP WITHOUT TIME ZONE,
    "duration_ms" INTEGER NOT NULL,
    "total_checks" INTEGER NOT NULL,
    "passed_checks" INTEGER NOT NULL,
    "failed_checks" INTEGER NOT NULL,
    "warning_checks" INTEGER NOT NULL,
    "summary_message" TEXT,
    "auto_heal_triggered" BOOLEAN NOT NULL,
    "linked_incident_id" VARCHAR,
    "is_visible" BOOLEAN NOT NULL,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "health_check_executions_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "health_check_results" (
    "execution_id" VARCHAR NOT NULL,
    "check_definition_id" VARCHAR,
    "check_name" VARCHAR NOT NULL,
    "check_type" VARCHAR(8) NOT NULL,
    "criticality" VARCHAR(8) NOT NULL,
    "target" VARCHAR,
    "status" VARCHAR(11) NOT NULL,
    "response_time_ms" INTEGER NOT NULL,
    "output_message" TEXT,
    "error_details" TEXT,
    "executed_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "health_check_results_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "incidents" (
    "incident_code" VARCHAR NOT NULL,
    "title" VARCHAR NOT NULL,
    "severity" VARCHAR(4) NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "assignee" VARCHAR NOT NULL,
    "status" VARCHAR(13) NOT NULL,
    "opened_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "resolved_at" TIMESTAMP WITHOUT TIME ZONE,
    "description" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "assignee_id" VARCHAR,
    "created_by" VARCHAR,
    "modified_by" VARCHAR,
    "is_visible" BOOLEAN,
    "owner_id" VARCHAR,
    CONSTRAINT "incidents_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_config_audit_logs" (
    "config_id" VARCHAR(64) NOT NULL,
    "tool_identifier" VARCHAR(64) NOT NULL,
    "action" VARCHAR(32) NOT NULL,
    "changed_fields" JSONB NOT NULL,
    "performed_by" VARCHAR(128) NOT NULL,
    "ip_address" VARCHAR(64),
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "monitoring_config_audit_logs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_correlated_incidents" (
    "incident_code" VARCHAR NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "title" VARCHAR NOT NULL,
    "severity" VARCHAR NOT NULL,
    "status" VARCHAR NOT NULL,
    "root_cause_type" VARCHAR NOT NULL,
    "root_cause_summary" TEXT NOT NULL,
    "recommended_action" TEXT,
    "correlated_alert_ids" JSONB NOT NULL,
    "affected_components" JSONB NOT NULL,
    "blast_radius_summary" TEXT,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "acknowledged_at" TIMESTAMP WITHOUT TIME ZONE,
    "acknowledged_by" VARCHAR,
    "resolved_at" TIMESTAMP WITHOUT TIME ZONE,
    "resolved_by" VARCHAR,
    "id" VARCHAR NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "monitoring_correlated_incidents_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_events" (
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "target_type" VARCHAR NOT NULL,
    "target_id" VARCHAR,
    "target_name" VARCHAR NOT NULL,
    "event_type" VARCHAR(17) NOT NULL,
    "severity" VARCHAR(8) NOT NULL,
    "state" VARCHAR(9) NOT NULL,
    "title" VARCHAR NOT NULL,
    "message" TEXT NOT NULL,
    "current_value" DOUBLE PRECISION,
    "threshold_value" DOUBLE PRECISION,
    "triggered_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "acknowledged_at" TIMESTAMP WITHOUT TIME ZONE,
    "acknowledged_by" VARCHAR,
    "recovered_at" TIMESTAMP WITHOUT TIME ZONE,
    "impact_metadata" JSONB NOT NULL,
    "linked_incident_id" VARCHAR,
    "auto_heal_triggered" BOOLEAN NOT NULL,
    "auto_heal_execution_id" VARCHAR,
    "is_visible" BOOLEAN NOT NULL,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "server_id" VARCHAR,
    "server_name" VARCHAR,
    "resource" VARCHAR,
    "fingerprint" VARCHAR,
    "labels" JSONB,
    "annotations" JSONB,
    CONSTRAINT "monitoring_events_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_exporters" (
    "target_id" VARCHAR NOT NULL,
    "name" VARCHAR NOT NULL,
    "exporter_type" VARCHAR NOT NULL,
    "endpoint_url" VARCHAR NOT NULL,
    "status" VARCHAR NOT NULL,
    "version" VARCHAR,
    "last_scrape_time" TIMESTAMP WITHOUT TIME ZONE,
    "scrape_duration_ms" DOUBLE PRECISION NOT NULL,
    "success_count" INTEGER NOT NULL,
    "failure_count" INTEGER NOT NULL,
    "error_message" TEXT,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "monitoring_exporters_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_notification_rules" (
    "name" VARCHAR NOT NULL,
    "environment_id" VARCHAR,
    "min_severity" VARCHAR NOT NULL,
    "channel" VARCHAR NOT NULL,
    "recipients" VARCHAR NOT NULL,
    "is_enabled" BOOLEAN NOT NULL,
    "template" TEXT,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "monitoring_notification_rules_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_targets" (
    "name" VARCHAR NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "application_name" VARCHAR,
    "service_name" VARCHAR,
    "server_name" VARCHAR,
    "target_type" VARCHAR NOT NULL,
    "endpoint_url" VARCHAR NOT NULL,
    "scrape_interval_seconds" INTEGER NOT NULL,
    "scrape_timeout_seconds" INTEGER NOT NULL,
    "is_enabled" BOOLEAN NOT NULL,
    "target_status" VARCHAR NOT NULL,
    "scrape_status" VARCHAR NOT NULL,
    "last_scrape_time" TIMESTAMP WITHOUT TIME ZONE,
    "last_successful_scrape" TIMESTAMP WITHOUT TIME ZONE,
    "last_failed_scrape" TIMESTAMP WITHOUT TIME ZONE,
    "scrape_duration_ms" DOUBLE PRECISION NOT NULL,
    "metrics_freshness_seconds" DOUBLE PRECISION NOT NULL,
    "is_stale" BOOLEAN NOT NULL,
    "error_message" TEXT,
    "labels" JSONB NOT NULL,
    "is_visible" BOOLEAN NOT NULL,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "monitoring_targets_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_test_execution_correlations" (
    "test_run_id" VARCHAR NOT NULL,
    "test_suite_name" VARCHAR NOT NULL,
    "test_phase" VARCHAR NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "started_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "completed_at" TIMESTAMP WITHOUT TIME ZONE,
    "status" VARCHAR NOT NULL,
    "total_tests" INTEGER NOT NULL,
    "passed_tests" INTEGER NOT NULL,
    "failed_tests" INTEGER NOT NULL,
    "is_environment_caused" BOOLEAN NOT NULL,
    "failure_root_cause" TEXT,
    "correlated_anomalies" JSONB NOT NULL,
    "environment_health_at_run" DOUBLE PRECISION NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "linked_incident_id" VARCHAR,
    CONSTRAINT "monitoring_test_execution_correlations_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_threshold_rules" (
    "name" VARCHAR NOT NULL,
    "environment_id" VARCHAR,
    "metric_type" VARCHAR(17) NOT NULL,
    "operator" VARCHAR NOT NULL,
    "warning_threshold" DOUBLE PRECISION NOT NULL,
    "critical_threshold" DOUBLE PRECISION NOT NULL,
    "duration_minutes" INTEGER NOT NULL,
    "is_enabled" BOOLEAN NOT NULL,
    "auto_heal_enabled" BOOLEAN NOT NULL,
    "auto_heal_runbook_id" VARCHAR,
    "is_visible" BOOLEAN NOT NULL,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "server_id" VARCHAR,
    "target_resource" VARCHAR,
    "metric_category" VARCHAR,
    "severe_threshold" DOUBLE PRECISION,
    "unit" VARCHAR,
    CONSTRAINT "monitoring_threshold_rules_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_time_series_metrics" (
    "target_id" VARCHAR,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "component_type" VARCHAR NOT NULL,
    "component_name" VARCHAR NOT NULL,
    "metric_category" VARCHAR NOT NULL,
    "metric_name" VARCHAR NOT NULL,
    "metric_value" DOUBLE PRECISION NOT NULL,
    "unit" VARCHAR NOT NULL,
    "timestamp" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "labels" JSONB NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "monitoring_time_series_metrics_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_tool_configs" (
    "tool_identifier" VARCHAR(64) NOT NULL,
    "tool_type" VARCHAR(13) NOT NULL,
    "display_name" VARCHAR(128) NOT NULL,
    "description" TEXT,
    "is_enabled" BOOLEAN NOT NULL,
    "base_url" VARCHAR(512) NOT NULL,
    "tls_verify" BOOLEAN NOT NULL,
    "ca_cert_path" VARCHAR(512),
    "timeout_seconds" DOUBLE PRECISION NOT NULL,
    "retry_count" INTEGER NOT NULL,
    "retry_backoff_factor" DOUBLE PRECISION NOT NULL,
    "auth_type" VARCHAR(14) NOT NULL,
    "encrypted_credentials" TEXT,
    "custom_headers" JSONB NOT NULL,
    "capabilities" JSONB NOT NULL,
    "metric_mappings" JSONB NOT NULL,
    "environment_scope" JSONB NOT NULL,
    "priority" INTEGER NOT NULL,
    "is_default_for_scope" BOOLEAN NOT NULL,
    "scrape_interval_seconds" INTEGER NOT NULL,
    "health_check_path" VARCHAR(256) NOT NULL,
    "health_check_interval_seconds" INTEGER NOT NULL,
    "tool_parameters" JSONB NOT NULL,
    "target_assignments" JSONB NOT NULL,
    "version" INTEGER NOT NULL,
    "modified_by" VARCHAR(128),
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "monitoring_tool_configs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "password_reset_tokens" (
    "user_id" VARCHAR NOT NULL,
    "token" VARCHAR NOT NULL,
    "expires_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "is_used" BOOLEAN NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "password_reset_tokens_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "projects" (
    "name" VARCHAR NOT NULL,
    "code" VARCHAR NOT NULL,
    "business_unit" VARCHAR NOT NULL,
    "lead" VARCHAR,
    "status" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "is_active" BOOLEAN,
    "is_visible" BOOLEAN,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    CONSTRAINT "projects_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "provisioning_approvals" (
    "request_id" VARCHAR NOT NULL,
    "approver_role" VARCHAR NOT NULL,
    "approver_user" VARCHAR,
    "status" VARCHAR NOT NULL,
    "comments" TEXT,
    "auto_approved" BOOLEAN NOT NULL,
    "decision_reason" VARCHAR,
    "approved_at" TIMESTAMP WITHOUT TIME ZONE,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "provisioning_approvals_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "provisioning_audits" (
    "request_id" VARCHAR NOT NULL,
    "action" VARCHAR NOT NULL,
    "performed_by" VARCHAR NOT NULL,
    "old_status" VARCHAR,
    "new_status" VARCHAR,
    "details" JSONB NOT NULL,
    "ip_address" VARCHAR,
    "timestamp" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "provisioning_audits_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "provisioning_dependencies" (
    "request_id" VARCHAR NOT NULL,
    "name" VARCHAR NOT NULL,
    "dependency_type" VARCHAR NOT NULL,
    "target_endpoint" VARCHAR,
    "required" BOOLEAN NOT NULL,
    "status" VARCHAR NOT NULL,
    "health_status" VARCHAR NOT NULL,
    "details" JSONB NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "provisioning_dependencies_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "provisioning_logs" (
    "request_id" VARCHAR NOT NULL,
    "step_id" VARCHAR,
    "step_key" VARCHAR,
    "log_level" VARCHAR NOT NULL,
    "message" TEXT NOT NULL,
    "source" VARCHAR NOT NULL,
    "details" JSONB NOT NULL,
    "timestamp" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "provisioning_logs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "provisioning_requests" (
    "request_number" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "environment_type" VARCHAR NOT NULL,
    "business_unit" VARCHAR NOT NULL,
    "project_name" VARCHAR NOT NULL,
    "application_name" VARCHAR NOT NULL,
    "component_name" VARCHAR,
    "environment_owner" VARCHAR NOT NULL,
    "requested_by" VARCHAR NOT NULL,
    "description" TEXT,
    "provisioning_mode" VARCHAR(14) NOT NULL,
    "template_id" VARCHAR,
    "scheduled_start" TIMESTAMP WITHOUT TIME ZONE,
    "scheduled_end" TIMESTAMP WITHOUT TIME ZONE,
    "execution_started_at" TIMESTAMP WITHOUT TIME ZONE,
    "execution_completed_at" TIMESTAMP WITHOUT TIME ZONE,
    "status" VARCHAR(16) NOT NULL,
    "progress_percentage" DOUBLE PRECISION NOT NULL,
    "current_step_index" INTEGER NOT NULL,
    "total_steps" INTEGER NOT NULL,
    "health_status" VARCHAR NOT NULL,
    "failure_reason" TEXT,
    "failure_step_id" VARCHAR,
    "retry_count" INTEGER NOT NULL,
    "environment_id" VARCHAR,
    "booking_id" VARCHAR,
    "incident_id" VARCHAR,
    "resource_specs" JSONB NOT NULL,
    "software_stack" JSONB NOT NULL,
    "configuration_payload" JSONB NOT NULL,
    "dependency_graph" JSONB NOT NULL,
    "validation_results" JSONB NOT NULL,
    "health_check_results" JSONB NOT NULL,
    "custom_tags" JSONB NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "provisioning_requests_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "provisioning_resources" (
    "request_id" VARCHAR NOT NULL,
    "resource_type" VARCHAR NOT NULL,
    "resource_name" VARCHAR NOT NULL,
    "resource_id" VARCHAR NOT NULL,
    "provider" VARCHAR NOT NULL,
    "status" VARCHAR NOT NULL,
    "configuration" JSONB NOT NULL,
    "allocated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "released_at" TIMESTAMP WITHOUT TIME ZONE,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "provisioning_resources_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "provisioning_steps" (
    "request_id" VARCHAR NOT NULL,
    "step_order" INTEGER NOT NULL,
    "step_key" VARCHAR NOT NULL,
    "step_name" VARCHAR NOT NULL,
    "category" VARCHAR(14) NOT NULL,
    "provider_type" VARCHAR NOT NULL,
    "status" VARCHAR(11) NOT NULL,
    "estimated_duration_sec" INTEGER NOT NULL,
    "actual_duration_sec" DOUBLE PRECISION NOT NULL,
    "started_at" TIMESTAMP WITHOUT TIME ZONE,
    "completed_at" TIMESTAMP WITHOUT TIME ZONE,
    "error_message" TEXT,
    "retry_count" INTEGER NOT NULL,
    "max_retries" INTEGER NOT NULL,
    "parameters" JSONB NOT NULL,
    "execution_output" JSONB NOT NULL,
    "rollback_supported" BOOLEAN NOT NULL,
    "rollback_status" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "provisioning_steps_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "provisioning_templates" (
    "name" VARCHAR NOT NULL,
    "description" VARCHAR,
    "environment_type" VARCHAR NOT NULL,
    "business_unit" VARCHAR,
    "project_name" VARCHAR,
    "compute_type" VARCHAR NOT NULL,
    "cpu_cores" INTEGER NOT NULL,
    "ram_gb" DOUBLE PRECISION NOT NULL,
    "storage_gb" DOUBLE PRECISION NOT NULL,
    "os_disk_gb" DOUBLE PRECISION NOT NULL,
    "data_disk_gb" DOUBLE PRECISION NOT NULL,
    "software_stack" JSONB NOT NULL,
    "network_config" JSONB NOT NULL,
    "env_vars" JSONB NOT NULL,
    "secrets_references" JSONB NOT NULL,
    "health_check_config" JSONB NOT NULL,
    "estimated_duration_min" INTEGER NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "tags" JSONB NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "provisioning_templates_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "release_phases" (
    "release_id" VARCHAR NOT NULL,
    "test_phase_id" VARCHAR,
    "phase_name" VARCHAR NOT NULL,
    "color" VARCHAR,
    "environment_id" VARCHAR,
    "environment_name" VARCHAR,
    "start_date" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "end_date" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "sequence" INTEGER NOT NULL,
    "status" VARCHAR NOT NULL,
    "remarks" VARCHAR,
    "created_by" VARCHAR NOT NULL,
    "updated_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "release_phases_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "releases" (
    "name" VARCHAR NOT NULL,
    "version" VARCHAR NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "lead" VARCHAR NOT NULL,
    "change_ref" VARCHAR NOT NULL,
    "scheduled_date" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "risk" VARCHAR(11) NOT NULL,
    "status" VARCHAR(11) NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "lead_id" VARCHAR,
    "created_by" VARCHAR,
    "modified_by" VARCHAR,
    "is_visible" BOOLEAN,
    "owner_id" VARCHAR,
    "bu_id" VARCHAR,
    "business_unit" VARCHAR,
    "project_id" VARCHAR,
    "project_name" VARCHAR,
    "application_id" VARCHAR,
    "application_name" VARCHAR,
    "risk_type" VARCHAR,
    "release_manager_id" VARCHAR,
    "release_manager_name" VARCHAR,
    "start_date" TIMESTAMP WITHOUT TIME ZONE,
    "end_date" TIMESTAMP WITHOUT TIME ZONE,
    "repository_url" VARCHAR,
    "remarks" VARCHAR,
    CONSTRAINT "releases_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "reservations" (
    "id" VARCHAR NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR NOT NULL,
    "business_unit" VARCHAR NOT NULL,
    "project" VARCHAR DEFAULT '',
    "application" VARCHAR DEFAULT '',
    "purpose" VARCHAR NOT NULL,
    "team" VARCHAR NOT NULL,
    "requested_by" VARCHAR NOT NULL,
    "start_date" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "end_date" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "status" VARCHAR NOT NULL DEFAULT 'CONFIRMED',
    "reservation_mode" VARCHAR NOT NULL DEFAULT 'SHARED',
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "assigned_user_id" VARCHAR,
    "is_visible" BOOLEAN NOT NULL DEFAULT TRUE,
    "modified_by" VARCHAR,
    "rejection_reason" VARCHAR,
    "rejected_at" TIMESTAMP WITHOUT TIME ZONE,
    "rejection_type" VARCHAR,
    "audit_history" VARCHAR,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "priority" VARCHAR(8),
    "auto_approval_enabled" BOOLEAN,
    "auto_approval_rule" VARCHAR(17),
    "workflow_id" VARCHAR,
    "current_workflow_order" INTEGER,
    "current_approver_id" VARCHAR,
    "current_approver_name" VARCHAR,
    "release_id" VARCHAR,
    "release_name" VARCHAR,
    "test_phase_id" VARCHAR,
    "test_phase_name" VARCHAR,
    "release_phase_id" VARCHAR,
    CONSTRAINT "reservations_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "chk_reservation_dates" CHECK ("end_date" > "start_date")
);

CREATE TABLE "role_screen_access" (
    "role_id" VARCHAR NOT NULL,
    "screen_id" VARCHAR NOT NULL,
    "has_access" BOOLEAN NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "role_screen_access_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "roles" (
    "name" VARCHAR NOT NULL,
    "description" VARCHAR,
    "role_order" INTEGER NOT NULL,
    "is_system" BOOLEAN NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "status" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "roles_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "runbooks" (
    "name" VARCHAR NOT NULL,
    "category" VARCHAR NOT NULL,
    "estimated_time_minutes" INTEGER NOT NULL,
    "last_executed" VARCHAR,
    "target_environment_id" VARCHAR,
    "status" VARCHAR(7) NOT NULL,
    "steps" JSONB NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "is_visible" BOOLEAN,
    "created_by" VARCHAR,
    "owner_id" VARCHAR,
    "modified_by" VARCHAR,
    CONSTRAINT "runbooks_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "system_settings" (
    "key" VARCHAR NOT NULL,
    "value" TEXT,
    "description" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "system_settings_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "test_phases" (
    "name" VARCHAR NOT NULL,
    "display_name" VARCHAR NOT NULL,
    "description" VARCHAR,
    "color" VARCHAR NOT NULL,
    "is_system" BOOLEAN NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "display_order" INTEGER NOT NULL,
    "created_by" VARCHAR NOT NULL,
    "updated_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "test_phases_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "topology_relationships" (
    "source_id" VARCHAR NOT NULL,
    "source_type" VARCHAR NOT NULL,
    "source_name" VARCHAR NOT NULL,
    "target_id" VARCHAR NOT NULL,
    "target_type" VARCHAR NOT NULL,
    "target_name" VARCHAR NOT NULL,
    "relationship_type" VARCHAR(13) NOT NULL,
    "environment_id" VARCHAR,
    "environment_name" VARCHAR,
    "port" VARCHAR,
    "protocol" VARCHAR,
    "latency_ms" DOUBLE PRECISION,
    "is_active" BOOLEAN NOT NULL,
    "notes" TEXT,
    "created_by" VARCHAR NOT NULL,
    "updated_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "topology_relationships_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "user_group_members" (
    "group_id" VARCHAR NOT NULL,
    "user_id" VARCHAR NOT NULL,
    "created_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "user_group_members_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "user_groups" (
    "name" VARCHAR NOT NULL,
    "description" VARCHAR,
    "bu_id" VARCHAR NOT NULL,
    "status" VARCHAR NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "created_by" VARCHAR NOT NULL,
    "modified_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "user_groups_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "user_roles" (
    "user_id" VARCHAR NOT NULL,
    "role_id" VARCHAR NOT NULL,
    CONSTRAINT "user_roles_pkey" PRIMARY KEY ("user_id", "role_id")
);

CREATE TABLE "user_sessions" (
    "id" VARCHAR NOT NULL,
    "session_id" VARCHAR NOT NULL,
    "user_id" VARCHAR NOT NULL,
    "ip_address" VARCHAR,
    "user_agent" VARCHAR,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "last_activity_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "absolute_expires_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "logout_at" TIMESTAMP WITHOUT TIME ZONE,
    "status" VARCHAR NOT NULL DEFAULT 'ACTIVE',
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "user_sessions_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "users" (
    "username" VARCHAR NOT NULL,
    "email" VARCHAR NOT NULL,
    "hashed_password" VARCHAR NOT NULL,
    "full_name" VARCHAR,
    "role" VARCHAR(9) NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "first_name" VARCHAR,
    "last_name" VARCHAR,
    "business_unit_id" VARCHAR,
    "status" VARCHAR,
    "created_by" VARCHAR,
    "updated_by" VARCHAR,
    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "workflow_approvers" (
    "workflow_id" VARCHAR NOT NULL,
    "user_id" VARCHAR NOT NULL,
    "workflow_order" INTEGER NOT NULL,
    "created_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "workflow_approvers_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "workflow_execution_steps" (
    "execution_id" VARCHAR NOT NULL,
    "user_id" VARCHAR NOT NULL,
    "workflow_order" INTEGER NOT NULL,
    "status" VARCHAR NOT NULL,
    "action_by" VARCHAR,
    "action_at" TIMESTAMP WITHOUT TIME ZONE,
    "comments" VARCHAR,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "workflow_execution_steps_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "workflow_executions" (
    "workflow_id" VARCHAR,
    "entity_type" VARCHAR NOT NULL,
    "entity_id" VARCHAR NOT NULL,
    "current_step_order" INTEGER NOT NULL,
    "total_steps" INTEGER NOT NULL,
    "status" VARCHAR NOT NULL,
    "created_by" VARCHAR NOT NULL,
    "modified_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "workflow_executions_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "workflows" (
    "bu_id" VARCHAR NOT NULL,
    "environment_id" VARCHAR NOT NULL,
    "environment_name" VARCHAR,
    "application_id" VARCHAR NOT NULL,
    "application_name" VARCHAR,
    "service_code" VARCHAR NOT NULL,
    "service_name" VARCHAR NOT NULL,
    "status" VARCHAR NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "created_by" VARCHAR NOT NULL,
    "modified_by" VARCHAR NOT NULL,
    "id" VARCHAR NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT "workflows_pkey" PRIMARY KEY ("id")
);
