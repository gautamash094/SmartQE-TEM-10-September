-- =============================================================================
-- SmartQE TEM PostgreSQL Migration Verification Script
-- Run this script in pgAdmin Query Tool after running the dump.
-- Expected: 56 Tables, 4,220 Records, 236 Indexes, 39 Foreign Keys
-- =============================================================================

-- 1. Check Total Table Count (Expected: 56 tables)
SELECT count(*) AS total_tables 
FROM information_schema.tables 
WHERE table_schema = 'public' AND table_type = 'BASE TABLE';

-- 2. Check Total Record Count across all 56 tables (Expected: 4,220 rows)
WITH table_counts AS (
SELECT 'app_version_detection_configs' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "app_version_detection_configs"
UNION ALL
SELECT 'app_version_detection_logs' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "app_version_detection_logs"
UNION ALL
SELECT 'application_screens' AS table_name, count(*) AS row_count, 29 AS expected_count FROM "application_screens"
UNION ALL
SELECT 'applications' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "applications"
UNION ALL
SELECT 'asset_audit_logs' AS table_name, count(*) AS row_count, 2 AS expected_count FROM "asset_audit_logs"
UNION ALL
SELECT 'assets' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "assets"
UNION ALL
SELECT 'auth_audit_logs' AS table_name, count(*) AS row_count, 1276 AS expected_count FROM "auth_audit_logs"
UNION ALL
SELECT 'auto_heal_executions' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "auto_heal_executions"
UNION ALL
SELECT 'auto_heal_rules' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "auto_heal_rules"
UNION ALL
SELECT 'business_units' AS table_name, count(*) AS row_count, 8 AS expected_count FROM "business_units"
UNION ALL
SELECT 'components' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "components"
UNION ALL
SELECT 'email_notifications' AS table_name, count(*) AS row_count, 233 AS expected_count FROM "email_notifications"
UNION ALL
SELECT 'environment_profiles' AS table_name, count(*) AS row_count, 8 AS expected_count FROM "environment_profiles"
UNION ALL
SELECT 'environment_softwares' AS table_name, count(*) AS row_count, 9 AS expected_count FROM "environment_softwares"
UNION ALL
SELECT 'health_check_definitions' AS table_name, count(*) AS row_count, 24 AS expected_count FROM "health_check_definitions"
UNION ALL
SELECT 'health_check_executions' AS table_name, count(*) AS row_count, 251 AS expected_count FROM "health_check_executions"
UNION ALL
SELECT 'health_check_results' AS table_name, count(*) AS row_count, 1124 AS expected_count FROM "health_check_results"
UNION ALL
SELECT 'incidents' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "incidents"
UNION ALL
SELECT 'monitoring_config_audit_logs' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "monitoring_config_audit_logs"
UNION ALL
SELECT 'monitoring_correlated_incidents' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "monitoring_correlated_incidents"
UNION ALL
SELECT 'monitoring_events' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "monitoring_events"
UNION ALL
SELECT 'monitoring_exporters' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "monitoring_exporters"
UNION ALL
SELECT 'monitoring_notification_rules' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "monitoring_notification_rules"
UNION ALL
SELECT 'monitoring_targets' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "monitoring_targets"
UNION ALL
SELECT 'monitoring_test_execution_correlations' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "monitoring_test_execution_correlations"
UNION ALL
SELECT 'monitoring_threshold_rules' AS table_name, count(*) AS row_count, 8 AS expected_count FROM "monitoring_threshold_rules"
UNION ALL
SELECT 'monitoring_time_series_metrics' AS table_name, count(*) AS row_count, 701 AS expected_count FROM "monitoring_time_series_metrics"
UNION ALL
SELECT 'monitoring_tool_configs' AS table_name, count(*) AS row_count, 2 AS expected_count FROM "monitoring_tool_configs"
UNION ALL
SELECT 'password_reset_tokens' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "password_reset_tokens"
UNION ALL
SELECT 'projects' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "projects"
UNION ALL
SELECT 'provisioning_approvals' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "provisioning_approvals"
UNION ALL
SELECT 'provisioning_audits' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "provisioning_audits"
UNION ALL
SELECT 'provisioning_dependencies' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "provisioning_dependencies"
UNION ALL
SELECT 'provisioning_logs' AS table_name, count(*) AS row_count, 21 AS expected_count FROM "provisioning_logs"
UNION ALL
SELECT 'provisioning_requests' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "provisioning_requests"
UNION ALL
SELECT 'provisioning_resources' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "provisioning_resources"
UNION ALL
SELECT 'provisioning_steps' AS table_name, count(*) AS row_count, 9 AS expected_count FROM "provisioning_steps"
UNION ALL
SELECT 'provisioning_templates' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "provisioning_templates"
UNION ALL
SELECT 'release_phases' AS table_name, count(*) AS row_count, 7 AS expected_count FROM "release_phases"
UNION ALL
SELECT 'releases' AS table_name, count(*) AS row_count, 6 AS expected_count FROM "releases"
UNION ALL
SELECT 'reservations' AS table_name, count(*) AS row_count, 18 AS expected_count FROM "reservations"
UNION ALL
SELECT 'role_screen_access' AS table_name, count(*) AS row_count, 66 AS expected_count FROM "role_screen_access"
UNION ALL
SELECT 'roles' AS table_name, count(*) AS row_count, 5 AS expected_count FROM "roles"
UNION ALL
SELECT 'runbooks' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "runbooks"
UNION ALL
SELECT 'system_settings' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "system_settings"
UNION ALL
SELECT 'test_phases' AS table_name, count(*) AS row_count, 10 AS expected_count FROM "test_phases"
UNION ALL
SELECT 'topology_relationships' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "topology_relationships"
UNION ALL
SELECT 'user_group_members' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "user_group_members"
UNION ALL
SELECT 'user_groups' AS table_name, count(*) AS row_count, 2 AS expected_count FROM "user_groups"
UNION ALL
SELECT 'user_roles' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "user_roles"
UNION ALL
SELECT 'user_sessions' AS table_name, count(*) AS row_count, 289 AS expected_count FROM "user_sessions"
UNION ALL
SELECT 'users' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "users"
UNION ALL
SELECT 'workflow_approvers' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "workflow_approvers"
UNION ALL
SELECT 'workflow_execution_steps' AS table_name, count(*) AS row_count, 37 AS expected_count FROM "workflow_execution_steps"
UNION ALL
SELECT 'workflow_executions' AS table_name, count(*) AS row_count, 19 AS expected_count FROM "workflow_executions"
UNION ALL
SELECT 'workflows' AS table_name, count(*) AS row_count, 2 AS expected_count FROM "workflows"
)
SELECT 
    table_name, 
    row_count, 
    expected_count,
    CASE WHEN row_count = expected_count THEN 'MATCH' ELSE 'MISMATCH' END AS status
FROM table_counts
ORDER BY table_name;

-- 3. Summary Check: Total Migrated Rows vs Expected (Expected: 4220 rows, 0 mismatches)
WITH table_counts AS (
SELECT 'app_version_detection_configs' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "app_version_detection_configs"
UNION ALL
SELECT 'app_version_detection_logs' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "app_version_detection_logs"
UNION ALL
SELECT 'application_screens' AS table_name, count(*) AS row_count, 29 AS expected_count FROM "application_screens"
UNION ALL
SELECT 'applications' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "applications"
UNION ALL
SELECT 'asset_audit_logs' AS table_name, count(*) AS row_count, 2 AS expected_count FROM "asset_audit_logs"
UNION ALL
SELECT 'assets' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "assets"
UNION ALL
SELECT 'auth_audit_logs' AS table_name, count(*) AS row_count, 1276 AS expected_count FROM "auth_audit_logs"
UNION ALL
SELECT 'auto_heal_executions' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "auto_heal_executions"
UNION ALL
SELECT 'auto_heal_rules' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "auto_heal_rules"
UNION ALL
SELECT 'business_units' AS table_name, count(*) AS row_count, 8 AS expected_count FROM "business_units"
UNION ALL
SELECT 'components' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "components"
UNION ALL
SELECT 'email_notifications' AS table_name, count(*) AS row_count, 233 AS expected_count FROM "email_notifications"
UNION ALL
SELECT 'environment_profiles' AS table_name, count(*) AS row_count, 8 AS expected_count FROM "environment_profiles"
UNION ALL
SELECT 'environment_softwares' AS table_name, count(*) AS row_count, 9 AS expected_count FROM "environment_softwares"
UNION ALL
SELECT 'health_check_definitions' AS table_name, count(*) AS row_count, 24 AS expected_count FROM "health_check_definitions"
UNION ALL
SELECT 'health_check_executions' AS table_name, count(*) AS row_count, 251 AS expected_count FROM "health_check_executions"
UNION ALL
SELECT 'health_check_results' AS table_name, count(*) AS row_count, 1124 AS expected_count FROM "health_check_results"
UNION ALL
SELECT 'incidents' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "incidents"
UNION ALL
SELECT 'monitoring_config_audit_logs' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "monitoring_config_audit_logs"
UNION ALL
SELECT 'monitoring_correlated_incidents' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "monitoring_correlated_incidents"
UNION ALL
SELECT 'monitoring_events' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "monitoring_events"
UNION ALL
SELECT 'monitoring_exporters' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "monitoring_exporters"
UNION ALL
SELECT 'monitoring_notification_rules' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "monitoring_notification_rules"
UNION ALL
SELECT 'monitoring_targets' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "monitoring_targets"
UNION ALL
SELECT 'monitoring_test_execution_correlations' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "monitoring_test_execution_correlations"
UNION ALL
SELECT 'monitoring_threshold_rules' AS table_name, count(*) AS row_count, 8 AS expected_count FROM "monitoring_threshold_rules"
UNION ALL
SELECT 'monitoring_time_series_metrics' AS table_name, count(*) AS row_count, 701 AS expected_count FROM "monitoring_time_series_metrics"
UNION ALL
SELECT 'monitoring_tool_configs' AS table_name, count(*) AS row_count, 2 AS expected_count FROM "monitoring_tool_configs"
UNION ALL
SELECT 'password_reset_tokens' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "password_reset_tokens"
UNION ALL
SELECT 'projects' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "projects"
UNION ALL
SELECT 'provisioning_approvals' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "provisioning_approvals"
UNION ALL
SELECT 'provisioning_audits' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "provisioning_audits"
UNION ALL
SELECT 'provisioning_dependencies' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "provisioning_dependencies"
UNION ALL
SELECT 'provisioning_logs' AS table_name, count(*) AS row_count, 21 AS expected_count FROM "provisioning_logs"
UNION ALL
SELECT 'provisioning_requests' AS table_name, count(*) AS row_count, 1 AS expected_count FROM "provisioning_requests"
UNION ALL
SELECT 'provisioning_resources' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "provisioning_resources"
UNION ALL
SELECT 'provisioning_steps' AS table_name, count(*) AS row_count, 9 AS expected_count FROM "provisioning_steps"
UNION ALL
SELECT 'provisioning_templates' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "provisioning_templates"
UNION ALL
SELECT 'release_phases' AS table_name, count(*) AS row_count, 7 AS expected_count FROM "release_phases"
UNION ALL
SELECT 'releases' AS table_name, count(*) AS row_count, 6 AS expected_count FROM "releases"
UNION ALL
SELECT 'reservations' AS table_name, count(*) AS row_count, 18 AS expected_count FROM "reservations"
UNION ALL
SELECT 'role_screen_access' AS table_name, count(*) AS row_count, 66 AS expected_count FROM "role_screen_access"
UNION ALL
SELECT 'roles' AS table_name, count(*) AS row_count, 5 AS expected_count FROM "roles"
UNION ALL
SELECT 'runbooks' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "runbooks"
UNION ALL
SELECT 'system_settings' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "system_settings"
UNION ALL
SELECT 'test_phases' AS table_name, count(*) AS row_count, 10 AS expected_count FROM "test_phases"
UNION ALL
SELECT 'topology_relationships' AS table_name, count(*) AS row_count, 0 AS expected_count FROM "topology_relationships"
UNION ALL
SELECT 'user_group_members' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "user_group_members"
UNION ALL
SELECT 'user_groups' AS table_name, count(*) AS row_count, 2 AS expected_count FROM "user_groups"
UNION ALL
SELECT 'user_roles' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "user_roles"
UNION ALL
SELECT 'user_sessions' AS table_name, count(*) AS row_count, 289 AS expected_count FROM "user_sessions"
UNION ALL
SELECT 'users' AS table_name, count(*) AS row_count, 4 AS expected_count FROM "users"
UNION ALL
SELECT 'workflow_approvers' AS table_name, count(*) AS row_count, 3 AS expected_count FROM "workflow_approvers"
UNION ALL
SELECT 'workflow_execution_steps' AS table_name, count(*) AS row_count, 37 AS expected_count FROM "workflow_execution_steps"
UNION ALL
SELECT 'workflow_executions' AS table_name, count(*) AS row_count, 19 AS expected_count FROM "workflow_executions"
UNION ALL
SELECT 'workflows' AS table_name, count(*) AS row_count, 2 AS expected_count FROM "workflows"
)
SELECT 
    sum(row_count) AS total_migrated_rows,
    4220 AS total_expected_rows,
    count(CASE WHEN row_count != expected_count THEN 1 END) AS mismatched_tables
FROM table_counts;

-- 4. Check Index Count (Expected: ~292 total including PK indexes and 236 secondary indexes)
SELECT count(*) AS total_indexes 
FROM pg_indexes 
WHERE schemaname = 'public';

-- 5. Check Foreign Key Constraints (Expected: 39 constraints)
SELECT 
    tc.table_name, 
    kcu.column_name, 
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name,
    tc.constraint_name
FROM information_schema.table_constraints AS tc 
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
  AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
  AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = 'public'
ORDER BY tc.table_name, kcu.column_name;
