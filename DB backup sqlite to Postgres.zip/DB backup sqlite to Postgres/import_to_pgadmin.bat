@echo off
setlocal enabledelayedexpansion

echo ===============================================================================
echo SmartQE TEM PostgreSQL Database Import Tool
echo ===============================================================================
echo.

set PGHOST=localhost
set PGPORT=5432
set PGUSER=postgres
set PGDATABASE=smartqe_tem

set /p HOST_INPUT="Enter PostgreSQL Host [default: localhost]: "
if not "!HOST_INPUT!"=="" set PGHOST=!HOST_INPUT!

set /p PORT_INPUT="Enter PostgreSQL Port [default: 5432]: "
if not "!PORT_INPUT!"=="" set PGPORT=!PORT_INPUT!

set /p USER_INPUT="Enter PostgreSQL Username [default: postgres]: "
if not "!USER_INPUT!"=="" set PGUSER=!USER_INPUT!

set /p DB_INPUT="Enter Target Database Name [default: smartqe_tem]: "
if not "!DB_INPUT!"=="" set PGDATABASE=!DB_INPUT!

echo.
echo Connecting to PostgreSQL (%PGHOST%:%PGPORT% as %PGUSER%)...
echo.

:: Try to find psql in PATH or standard Program Files locations
set PSQL_CMD=psql
where psql >nul 2>nul
if %errorlevel% neq 0 (
    set FOUND=0
    for /d %%D in ("C:\Program Files\PostgreSQL\*") do (
        if exist "%%D\bin\psql.exe" (
            set PSQL_CMD="%%D\bin\psql.exe"
            set FOUND=1
        )
    )
    if !FOUND! equ 0 (
        for /d %%D in ("C:\Users\%USERNAME%\Downloads\postgresql*\pgsql\bin") do (
            if exist "%%D\psql.exe" (
                set PSQL_CMD="%%D\psql.exe"
                set FOUND=1
            )
        )
    )
)

echo Using PSQL: %PSQL_CMD%
echo.

:: Create database if it doesn't exist
echo [1/3] Ensuring database %PGDATABASE% exists...
%PSQL_CMD% -h %PGHOST% -p %PGPORT% -U %PGUSER% -d postgres -tc "SELECT 1 FROM pg_database WHERE datname = '%PGDATABASE%'" | findstr 1 >nul
if %errorlevel% neq 0 (
    echo Database %PGDATABASE% not found. Creating database...
    %PSQL_CMD% -h %PGHOST% -p %PGPORT% -U %PGUSER% -d postgres -c "CREATE DATABASE \"%PGDATABASE%\" WITH ENCODING 'UTF8';"
) else (
    echo Database %PGDATABASE% already exists.
)

echo.
echo [2/3] Importing complete dump (56 tables, 4,220 rows, 236 indexes, 39 FKs)...
%PSQL_CMD% -h %PGHOST% -p %PGPORT% -U %PGUSER% -d %PGDATABASE% -f "%~dp0smartqe_tem_postgres_dump.sql"

echo.
echo [3/3] Running verification checks...
%PSQL_CMD% -h %PGHOST% -p %PGPORT% -U %PGUSER% -d %PGDATABASE% -f "%~dp0verify_migration.sql"

echo.
echo ===============================================================================
echo Import completed! Open pgAdmin and refresh the database to view your data.
echo ===============================================================================
pause
